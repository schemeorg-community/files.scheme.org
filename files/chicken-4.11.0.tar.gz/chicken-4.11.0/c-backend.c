/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:51
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: c-backend.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -extend private-namespace.scm -no-trace -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[844];
static double C_possibly_force_alignment;


#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
C_regparm static C_word C_fcall stub2088(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
C_regparm static C_word C_fcall stub2084(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(f_10145)
static void C_ccall f_10145(C_word c,C_word *av) C_noret;
C_noret_decl(f_7349)
static void C_ccall f_7349(C_word c,C_word *av) C_noret;
C_noret_decl(f_6226)
static void C_ccall f_6226(C_word c,C_word *av) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word *av) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word *av) C_noret;
C_noret_decl(f_9794)
static void C_ccall f_9794(C_word c,C_word *av) C_noret;
C_noret_decl(f_6240)
static void C_ccall f_6240(C_word c,C_word *av) C_noret;
C_noret_decl(f_6243)
static void C_ccall f_6243(C_word c,C_word *av) C_noret;
C_noret_decl(f_6246)
static void C_ccall f_6246(C_word c,C_word *av) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word *av) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word *av) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word *av) C_noret;
C_noret_decl(f_6234)
static void C_ccall f_6234(C_word c,C_word *av) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word *av) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word *av) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word *av) C_noret;
C_noret_decl(f_4911)
static void C_fcall f_4911(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6604)
static void C_ccall f_6604(C_word c,C_word *av) C_noret;
C_noret_decl(f_6607)
static void C_ccall f_6607(C_word c,C_word *av) C_noret;
C_noret_decl(f_6601)
static void C_ccall f_6601(C_word c,C_word *av) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word *av) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word *av) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word *av) C_noret;
C_noret_decl(f_10097)
static void C_ccall f_10097(C_word c,C_word *av) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word *av) C_noret;
C_noret_decl(f_6704)
static void C_ccall f_6704(C_word c,C_word *av) C_noret;
C_noret_decl(f_4909)
static void C_ccall f_4909(C_word c,C_word *av) C_noret;
C_noret_decl(f_5634)
static void C_fcall f_5634(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4192)
static void C_ccall f_4192(C_word c,C_word *av) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word *av) C_noret;
C_noret_decl(f_8005)
static void C_ccall f_8005(C_word c,C_word *av) C_noret;
C_noret_decl(f_8002)
static void C_ccall f_8002(C_word c,C_word *av) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word *av) C_noret;
C_noret_decl(f_8014)
static void C_ccall f_8014(C_word c,C_word *av) C_noret;
C_noret_decl(f_8010)
static void C_ccall f_8010(C_word c,C_word *av) C_noret;
C_noret_decl(f_10082)
static void C_fcall f_10082(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173(C_word c,C_word *av) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word *av) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word *av) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word *av) C_noret;
C_noret_decl(f_3396)
static void C_fcall f_3396(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8029)
static void C_ccall f_8029(C_word c,C_word *av) C_noret;
C_noret_decl(f_5672)
static void C_fcall f_5672(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5678)
static void C_ccall f_5678(C_word c,C_word *av) C_noret;
C_noret_decl(f_6799)
static void C_ccall f_6799(C_word c,C_word *av) C_noret;
C_noret_decl(f_8438)
static void C_ccall f_8438(C_word c,C_word *av) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word *av) C_noret;
C_noret_decl(f_8041)
static void C_ccall f_8041(C_word c,C_word *av) C_noret;
C_noret_decl(f_8045)
static void C_fcall f_8045(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8043)
static void C_ccall f_8043(C_word c,C_word *av) C_noret;
C_noret_decl(f_8444)
static void C_fcall f_8444(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word *av) C_noret;
C_noret_decl(f_5656)
static void C_ccall f_5656(C_word c,C_word *av) C_noret;
C_noret_decl(f_5807)
static void C_fcall f_5807(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8050)
static void C_fcall f_8050(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8455)
static void C_ccall f_8455(C_word c,C_word *av) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word *av) C_noret;
C_noret_decl(f_5665)
static void C_fcall f_5665(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10010)
static void C_ccall f_10010(C_word c,C_word *av) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109(C_word c,C_word *av) C_noret;
C_noret_decl(f_8596)
static void C_ccall f_8596(C_word c,C_word *av) C_noret;
C_noret_decl(f_5728)
static void C_ccall f_5728(C_word c,C_word *av) C_noret;
C_noret_decl(f_10031)
static void C_ccall f_10031(C_word c,C_word *av) C_noret;
C_noret_decl(f_10034)
static void C_ccall f_10034(C_word c,C_word *av) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word *av) C_noret;
C_noret_decl(f_10007)
static void C_ccall f_10007(C_word c,C_word *av) C_noret;
C_noret_decl(f_8562)
static void C_ccall f_8562(C_word c,C_word *av) C_noret;
C_noret_decl(f_10004)
static void C_ccall f_10004(C_word c,C_word *av) C_noret;
C_noret_decl(f_8572)
static void C_fcall f_8572(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8579)
static void C_ccall f_8579(C_word c,C_word *av) C_noret;
C_noret_decl(f_8427)
static void C_fcall f_8427(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10028)
static void C_ccall f_10028(C_word c,C_word *av) C_noret;
C_noret_decl(f_10022)
static void C_ccall f_10022(C_word c,C_word *av) C_noret;
C_noret_decl(f_5949)
static void C_fcall f_5949(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7219)
static void C_fcall f_7219(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955(C_word c,C_word *av) C_noret;
C_noret_decl(f_5959)
static void C_ccall f_5959(C_word c,C_word *av) C_noret;
C_noret_decl(f_5000)
static void C_fcall f_5000(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6738)
static void C_ccall f_6738(C_word c,C_word *av) C_noret;
C_noret_decl(f_7201)
static void C_ccall f_7201(C_word c,C_word *av) C_noret;
C_noret_decl(f_6768)
static void C_ccall f_6768(C_word c,C_word *av) C_noret;
C_noret_decl(f_8589)
static void C_fcall f_8589(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6765)
static void C_ccall f_6765(C_word c,C_word *av) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word *av) C_noret;
C_noret_decl(f_6759)
static void C_ccall f_6759(C_word c,C_word *av) C_noret;
C_noret_decl(f_5989)
static void C_ccall f_5989(C_word c,C_word *av) C_noret;
C_noret_decl(f_5986)
static void C_ccall f_5986(C_word c,C_word *av) C_noret;
C_noret_decl(f_5983)
static void C_ccall f_5983(C_word c,C_word *av) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word *av) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word *av) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word *av) C_noret;
C_noret_decl(f_6756)
static void C_ccall f_6756(C_word c,C_word *av) C_noret;
C_noret_decl(f_6752)
static void C_ccall f_6752(C_word c,C_word *av) C_noret;
C_noret_decl(f_6725)
static void C_ccall f_6725(C_word c,C_word *av) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word *av) C_noret;
C_noret_decl(f_5992)
static void C_ccall f_5992(C_word c,C_word *av) C_noret;
C_noret_decl(f_5998)
static void C_ccall f_5998(C_word c,C_word *av) C_noret;
C_noret_decl(f_5995)
static void C_ccall f_5995(C_word c,C_word *av) C_noret;
C_noret_decl(f_2614)
static void C_ccall f_2614(C_word c,C_word *av) C_noret;
C_noret_decl(f_2610)
static void C_fcall f_2610(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6715)
static void C_fcall f_6715(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6710)
static void C_ccall f_6710(C_word c,C_word *av) C_noret;
C_noret_decl(f_5040)
static void C_fcall f_5040(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2625)
static void C_fcall f_2625(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2622)
static void C_fcall f_2622(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6773)
static void C_ccall f_6773(C_word c,C_word *av) C_noret;
C_noret_decl(f_6777)
static void C_ccall f_6777(C_word c,C_word *av) C_noret;
C_noret_decl(f_5019)
static void C_ccall f_5019(C_word c,C_word *av) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word *av) C_noret;
C_noret_decl(f_5010)
static void C_ccall f_5010(C_word c,C_word *av) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word *av) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word *av) C_noret;
C_noret_decl(f_5025)
static void C_ccall f_5025(C_word c,C_word *av) C_noret;
C_noret_decl(f_3758)
static void C_ccall f_3758(C_word c,C_word *av) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word *av) C_noret;
C_noret_decl(f_9346)
static void C_fcall f_9346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3773)
static void C_fcall f_3773(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7957)
static void C_fcall f_7957(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3749)
static void C_ccall f_3749(C_word c,C_word *av) C_noret;
C_noret_decl(f_5077)
static void C_ccall f_5077(C_word c,C_word *av) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word *av) C_noret;
C_noret_decl(f_7967)
static void C_ccall f_7967(C_word c,C_word *av) C_noret;
C_noret_decl(f_7980)
static void C_ccall f_7980(C_word c,C_word *av) C_noret;
C_noret_decl(f_3791)
static void C_ccall f_3791(C_word c,C_word *av) C_noret;
C_noret_decl(f_5143)
static void C_fcall f_5143(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word *av) C_noret;
C_noret_decl(f_7990)
static void C_ccall f_7990(C_word c,C_word *av) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word *av) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word *av) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word *av) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word *av) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word *av) C_noret;
C_noret_decl(f_7987)
static void C_ccall f_7987(C_word c,C_word *av) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159(C_word c,C_word *av) C_noret;
C_noret_decl(f_7984)
static void C_ccall f_7984(C_word c,C_word *av) C_noret;
C_noret_decl(f_5067)
static void C_fcall f_5067(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word *av) C_noret;
C_noret_decl(f_7999)
static void C_ccall f_7999(C_word c,C_word *av) C_noret;
C_noret_decl(f_7012)
static void C_ccall f_7012(C_word c,C_word *av) C_noret;
C_noret_decl(f_7993)
static void C_ccall f_7993(C_word c,C_word *av) C_noret;
C_noret_decl(f_5120)
static void C_fcall f_5120(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7395)
static void C_fcall f_7395(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7027)
static void C_fcall f_7027(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word *av) C_noret;
C_noret_decl(f_7025)
static void C_ccall f_7025(C_word c,C_word *av) C_noret;
C_noret_decl(f_6893)
static void C_ccall f_6893(C_word c,C_word *av) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word *av) C_noret;
C_noret_decl(f_6899)
static void C_ccall f_6899(C_word c,C_word *av) C_noret;
C_noret_decl(f_5962)
static void C_ccall f_5962(C_word c,C_word *av) C_noret;
C_noret_decl(f_7368)
static void C_ccall f_7368(C_word c,C_word *av) C_noret;
C_noret_decl(f_5965)
static void C_ccall f_5965(C_word c,C_word *av) C_noret;
C_noret_decl(f_5968)
static void C_ccall f_5968(C_word c,C_word *av) C_noret;
C_noret_decl(f_7364)
static void C_fcall f_7364(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7362)
static void C_ccall f_7362(C_word c,C_word *av) C_noret;
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word *av) C_noret;
C_noret_decl(f_7037)
static void C_ccall f_7037(C_word c,C_word *av) C_noret;
C_noret_decl(f_7031)
static void C_ccall f_7031(C_word c,C_word *av) C_noret;
C_noret_decl(f_7034)
static void C_ccall f_7034(C_word c,C_word *av) C_noret;
C_noret_decl(f_5971)
static void C_ccall f_5971(C_word c,C_word *av) C_noret;
C_noret_decl(f_5974)
static void C_ccall f_5974(C_word c,C_word *av) C_noret;
C_noret_decl(f_5977)
static void C_fcall f_5977(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7339)
static void C_fcall f_7339(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7049)
static void C_ccall f_7049(C_word c,C_word *av) C_noret;
C_noret_decl(f_7046)
static void C_ccall f_7046(C_word c,C_word *av) C_noret;
C_noret_decl(f_7043)
static void C_ccall f_7043(C_word c,C_word *av) C_noret;
C_noret_decl(f_8623)
static void C_fcall f_8623(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7385)
static void C_ccall f_7385(C_word c,C_word *av) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word *av) C_noret;
C_noret_decl(f_7383)
static void C_ccall f_7383(C_word c,C_word *av) C_noret;
C_noret_decl(f_7055)
static void C_ccall f_7055(C_word c,C_word *av) C_noret;
C_noret_decl(f_9124)
static void C_fcall f_9124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7052)
static void C_ccall f_7052(C_word c,C_word *av) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word *av) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word *av) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word *av) C_noret;
C_noret_decl(f_8630)
static void C_ccall f_8630(C_word c,C_word *av) C_noret;
C_noret_decl(f_7064)
static void C_ccall f_7064(C_word c,C_word *av) C_noret;
C_noret_decl(f_7067)
static void C_ccall f_7067(C_word c,C_word *av) C_noret;
C_noret_decl(f_7061)
static void C_ccall f_7061(C_word c,C_word *av) C_noret;
C_noret_decl(f_10799)
static void C_ccall f_10799(C_word c,C_word *av) C_noret;
C_noret_decl(f_9986)
static void C_ccall f_9986(C_word c,C_word *av) C_noret;
C_noret_decl(f_10795)
static void C_ccall f_10795(C_word c,C_word *av) C_noret;
C_noret_decl(f_9983)
static void C_ccall f_9983(C_word c,C_word *av) C_noret;
C_noret_decl(f_8640)
static void C_fcall f_8640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9980)
static void C_ccall f_9980(C_word c,C_word *av) C_noret;
C_noret_decl(f_6469)
static void C_ccall f_6469(C_word c,C_word *av) C_noret;
C_noret_decl(f_7121)
static void C_ccall f_7121(C_word c,C_word *av) C_noret;
C_noret_decl(f_7073)
static void C_ccall f_7073(C_word c,C_word *av) C_noret;
C_noret_decl(f_6492)
static void C_fcall f_6492(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7076)
static void C_ccall f_7076(C_word c,C_word *av) C_noret;
C_noret_decl(f_7079)
static void C_ccall f_7079(C_word c,C_word *av) C_noret;
C_noret_decl(f_7070)
static void C_ccall f_7070(C_word c,C_word *av) C_noret;
C_noret_decl(f_9974)
static void C_ccall f_9974(C_word c,C_word *av) C_noret;
C_noret_decl(f_8659)
static void C_ccall f_8659(C_word c,C_word *av) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word *av) C_noret;
C_noret_decl(f_7130)
static void C_ccall f_7130(C_word c,C_word *av) C_noret;
C_noret_decl(f_7377)
static void C_ccall f_7377(C_word c,C_word *av) C_noret;
C_noret_decl(f_7374)
static void C_ccall f_7374(C_word c,C_word *av) C_noret;
C_noret_decl(f_7371)
static void C_ccall f_7371(C_word c,C_word *av) C_noret;
C_noret_decl(f_7088)
static void C_ccall f_7088(C_word c,C_word *av) C_noret;
C_noret_decl(f_7127)
static void C_ccall f_7127(C_word c,C_word *av) C_noret;
C_noret_decl(f_7096)
static void C_ccall f_7096(C_word c,C_word *av) C_noret;
C_noret_decl(f_6433)
static void C_ccall f_6433(C_word c,C_word *av) C_noret;
C_noret_decl(f_9998)
static void C_ccall f_9998(C_word c,C_word *av) C_noret;
C_noret_decl(f_7092)
static void C_ccall f_7092(C_word c,C_word *av) C_noret;
C_noret_decl(f_7133)
static void C_ccall f_7133(C_word c,C_word *av) C_noret;
C_noret_decl(f_7139)
static void C_ccall f_7139(C_word c,C_word *av) C_noret;
C_noret_decl(f_10787)
static void C_ccall f_10787(C_word c,C_word *av) C_noret;
C_noret_decl(f_9151)
static void C_fcall f_9151(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8606)
static void C_fcall f_8606(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7142)
static void C_ccall f_7142(C_word c,C_word *av) C_noret;
C_noret_decl(f_10757)
static void C_ccall f_10757(C_word c,C_word *av) C_noret;
C_noret_decl(f_5873)
static void C_ccall f_5873(C_word c,C_word *av) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877(C_word c,C_word *av) C_noret;
C_noret_decl(f_6846)
static void C_fcall f_6846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8613)
static void C_ccall f_8613(C_word c,C_word *av) C_noret;
C_noret_decl(f_10765)
static void C_ccall f_10765(C_word c,C_word *av) C_noret;
C_noret_decl(f_5883)
static void C_fcall f_5883(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word *av) C_noret;
C_noret_decl(f_7949)
static void C_ccall f_7949(C_word c,C_word *av) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word *av) C_noret;
C_noret_decl(f_6856)
static void C_ccall f_6856(C_word c,C_word *av) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word *av) C_noret;
C_noret_decl(f_10718)
static void C_ccall f_10718(C_word c,C_word *av) C_noret;
C_noret_decl(f_3639)
static void C_fcall f_3639(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3633)
static void C_ccall f_3633(C_word c,C_word *av) C_noret;
C_noret_decl(f_5278)
static void C_ccall f_5278(C_word c,C_word *av) C_noret;
C_noret_decl(f_5275)
static void C_ccall f_5275(C_word c,C_word *av) C_noret;
C_noret_decl(f_5272)
static void C_ccall f_5272(C_word c,C_word *av) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word *av) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word *av) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523(C_word c,C_word *av) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526(C_word c,C_word *av) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word *av) C_noret;
C_noret_decl(f_3617)
static void C_ccall f_3617(C_word c,C_word *av) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word *av) C_noret;
C_noret_decl(f_10705)
static void C_ccall f_10705(C_word c,C_word *av) C_noret;
C_noret_decl(f_10700)
static void C_ccall f_10700(C_word c,C_word *av) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620(C_word c,C_word *av) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word *av) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word *av) C_noret;
C_noret_decl(f_4394)
static void C_ccall f_4394(C_word c,C_word *av) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word *av) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word *av) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word *av) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word *av) C_noret;
C_noret_decl(f_10734)
static void C_ccall f_10734(C_word c,C_word *av) C_noret;
C_noret_decl(f_5858)
static void C_ccall f_5858(C_word c,C_word *av) C_noret;
C_noret_decl(f_9959)
static void C_ccall f_9959(C_word c,C_word *av) C_noret;
C_noret_decl(f_9956)
static void C_ccall f_9956(C_word c,C_word *av) C_noret;
C_noret_decl(f_9953)
static void C_ccall f_9953(C_word c,C_word *av) C_noret;
C_noret_decl(f_8228)
static void C_fcall f_8228(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3267)
static void C_ccall f_3267(C_word c,C_word *av) C_noret;
C_noret_decl(f_5219)
static void C_fcall f_5219(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5838)
static void C_fcall f_5838(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5849)
static void C_ccall f_5849(C_word c,C_word *av) C_noret;
C_noret_decl(f_5845)
static void C_ccall f_5845(C_word c,C_word *av) C_noret;
C_noret_decl(f_5893)
static void C_ccall f_5893(C_word c,C_word *av) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890(C_word c,C_word *av) C_noret;
C_noret_decl(f_4761)
static void C_fcall f_4761(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word *av) C_noret;
C_noret_decl(f_4758)
static void C_fcall f_4758(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word *av) C_noret;
C_noret_decl(f_4746)
static void C_ccall f_4746(C_word c,C_word *av) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word *av) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word *av) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word *av) C_noret;
C_noret_decl(f_4730)
static void C_ccall f_4730(C_word c,C_word *av) C_noret;
C_noret_decl(f_9896)
static void C_ccall f_9896(C_word c,C_word *av) C_noret;
C_noret_decl(f_7434)
static void C_ccall f_7434(C_word c,C_word *av) C_noret;
C_noret_decl(f_7438)
static void C_fcall f_7438(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word *av) C_noret;
C_noret_decl(f_10519)
static void C_fcall f_10519(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10510)
static void C_ccall f_10510(C_word c,C_word *av) C_noret;
C_noret_decl(f_9875)
static void C_ccall f_9875(C_word c,C_word *av) C_noret;
C_noret_decl(f_9878)
static void C_ccall f_9878(C_word c,C_word *av) C_noret;
C_noret_decl(f_6559)
static void C_ccall f_6559(C_word c,C_word *av) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word *av) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word *av) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word *av) C_noret;
C_noret_decl(f_3921)
static void C_fcall f_3921(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word *av) C_noret;
C_noret_decl(f_4815)
static void C_ccall f_4815(C_word c,C_word *av) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word *av) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word *av) C_noret;
C_noret_decl(f_9857)
static void C_ccall f_9857(C_word c,C_word *av) C_noret;
C_noret_decl(f_9854)
static void C_ccall f_9854(C_word c,C_word *av) C_noret;
C_noret_decl(f_9851)
static void C_ccall f_9851(C_word c,C_word *av) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word *av) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word *av) C_noret;
C_noret_decl(f_9881)
static void C_ccall f_9881(C_word c,C_word *av) C_noret;
C_noret_decl(f_6590)
static void C_ccall f_6590(C_word c,C_word *av) C_noret;
C_noret_decl(f_6597)
static void C_ccall f_6597(C_word c,C_word *av) C_noret;
C_noret_decl(f_6594)
static void C_ccall f_6594(C_word c,C_word *av) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word *av) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word *av) C_noret;
C_noret_decl(f_3449)
static void C_fcall f_3449(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5183)
static void C_ccall f_5183(C_word c,C_word *av) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word *av) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word *av) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word *av) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word *av) C_noret;
C_noret_decl(f_6545)
static void C_ccall f_6545(C_word c,C_word *av) C_noret;
C_noret_decl(f_6542)
static void C_ccall f_6542(C_word c,C_word *av) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189(C_word c,C_word *av) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195(C_word c,C_word *av) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word *av) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word *av) C_noret;
C_noret_decl(f_9869)
static void C_ccall f_9869(C_word c,C_word *av) C_noret;
C_noret_decl(f_5168)
static void C_ccall f_5168(C_word c,C_word *av) C_noret;
C_noret_decl(f_5165)
static void C_ccall f_5165(C_word c,C_word *av) C_noret;
C_noret_decl(f_5162)
static void C_fcall f_5162(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177(C_word c,C_word *av) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word *av) C_noret;
C_noret_decl(f_5171)
static void C_ccall f_5171(C_word c,C_word *av) C_noret;
C_noret_decl(f_6520)
static void C_ccall f_6520(C_word c,C_word *av) C_noret;
C_noret_decl(f_9094)
static void C_ccall f_9094(C_word c,C_word *av) C_noret;
C_noret_decl(f_9096)
static void C_fcall f_9096(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7002)
static void C_fcall f_7002(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5331)
static void C_ccall f_5331(C_word c,C_word *av) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word *av) C_noret;
C_noret_decl(f_5347)
static void C_ccall f_5347(C_word c,C_word *av) C_noret;
C_noret_decl(f_7160)
static void C_ccall f_7160(C_word c,C_word *av) C_noret;
C_noret_decl(f_8472)
static void C_ccall f_8472(C_word c,C_word *av) C_noret;
C_noret_decl(f_8476)
static void C_ccall f_8476(C_word c,C_word *av) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word *av) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word *av) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470(C_word c,C_word *av) C_noret;
C_noret_decl(f_7169)
static void C_ccall f_7169(C_word c,C_word *av) C_noret;
C_noret_decl(f_7166)
static void C_ccall f_7166(C_word c,C_word *av) C_noret;
C_noret_decl(f_7163)
static void C_ccall f_7163(C_word c,C_word *av) C_noret;
C_noret_decl(f_5321)
static void C_fcall f_5321(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8494)
static void C_ccall f_8494(C_word c,C_word *av) C_noret;
C_noret_decl(f_8496)
static void C_fcall f_8496(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7172)
static void C_ccall f_7172(C_word c,C_word *av) C_noret;
C_noret_decl(f_6686)
static void C_ccall f_6686(C_word c,C_word *av) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word *av) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word *av) C_noret;
C_noret_decl(f_9364)
static void C_ccall f_9364(C_word c,C_word *av) C_noret;
C_noret_decl(f_6671)
static void C_ccall f_6671(C_word c,C_word *av) C_noret;
C_noret_decl(f_6676)
static void C_fcall f_6676(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3484)
static void C_fcall f_3484(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7197)
static void C_ccall f_7197(C_word c,C_word *av) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word *av) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word *av) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word *av) C_noret;
C_noret_decl(f_9355)
static void C_fcall f_9355(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6255)
static void C_fcall f_6255(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3462)
static void C_ccall f_3462(C_word c,C_word *av) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word *av) C_noret;
C_noret_decl(f_4806)
static void C_ccall f_4806(C_word c,C_word *av) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word *av) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word *av) C_noret;
C_noret_decl(f_4800)
static void C_ccall f_4800(C_word c,C_word *av) C_noret;
C_noret_decl(f_6288)
static void C_ccall f_6288(C_word c,C_word *av) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word *av) C_noret;
C_noret_decl(f_8468)
static void C_ccall f_8468(C_word c,C_word *av) C_noret;
C_noret_decl(f_8461)
static void C_fcall f_8461(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7303)
static void C_ccall f_7303(C_word c,C_word *av) C_noret;
C_noret_decl(f_7300)
static void C_ccall f_7300(C_word c,C_word *av) C_noret;
C_noret_decl(f_6279)
static void C_ccall f_6279(C_word c,C_word *av) C_noret;
C_noret_decl(f_6662)
static void C_ccall f_6662(C_word c,C_word *av) C_noret;
C_noret_decl(f_6658)
static void C_ccall f_6658(C_word c,C_word *av) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word *av) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word *av) C_noret;
C_noret_decl(f_7310)
static void C_ccall f_7310(C_word c,C_word *av) C_noret;
C_noret_decl(f_7318)
static void C_ccall f_7318(C_word c,C_word *av) C_noret;
C_noret_decl(f_3114)
static void C_fcall f_3114(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word *av) C_noret;
C_noret_decl(f_6209)
static void C_ccall f_6209(C_word c,C_word *av) C_noret;
C_noret_decl(f_6644)
static void C_ccall f_6644(C_word c,C_word *av) C_noret;
C_noret_decl(f_6640)
static void C_ccall f_6640(C_word c,C_word *av) C_noret;
C_noret_decl(f_10586)
static void C_ccall f_10586(C_word c,C_word *av) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word *av) C_noret;
C_noret_decl(f_10059)
static void C_fcall f_10059(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947(C_word c,C_word *av) C_noret;
C_noret_decl(f_10055)
static void C_ccall f_10055(C_word c,C_word *av) C_noret;
C_noret_decl(f_5465)
static void C_ccall f_5465(C_word c,C_word *av) C_noret;
C_noret_decl(f_5462)
static void C_ccall f_5462(C_word c,C_word *av) C_noret;
C_noret_decl(f_5473)
static void C_ccall f_5473(C_word c,C_word *av) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word *av) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word *av) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word *av) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word *av) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word *av) C_noret;
C_noret_decl(f_3857)
static void C_ccall f_3857(C_word c,C_word *av) C_noret;
C_noret_decl(f_5253)
static void C_ccall f_5253(C_word c,C_word *av) C_noret;
C_noret_decl(f_3850)
static void C_ccall f_3850(C_word c,C_word *av) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word *av) C_noret;
C_noret_decl(f_5256)
static void C_ccall f_5256(C_word c,C_word *av) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word *av) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word *av) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word *av) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word *av) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word *av) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word *av) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word *av) C_noret;
C_noret_decl(f_9391)
static void C_fcall f_9391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word *av) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word *av) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word *av) C_noret;
C_noret_decl(f_7471)
static void C_fcall f_7471(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word *av) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word *av) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word *av) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word *av) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word *av) C_noret;
C_noret_decl(f_5415)
static void C_ccall f_5415(C_word c,C_word *av) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word *av) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word *av) C_noret;
C_noret_decl(f_5417)
static void C_fcall f_5417(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word *av) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word *av) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word *av) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word *av) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word *av) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word *av) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word *av) C_noret;
C_noret_decl(f_9830)
static void C_ccall f_9830(C_word c,C_word *av) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word *av) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word *av) C_noret;
C_noret_decl(f_7428)
static void C_fcall f_7428(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word *av) C_noret;
C_noret_decl(f_8555)
static void C_fcall f_8555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9818)
static void C_ccall f_9818(C_word c,C_word *av) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word *av) C_noret;
C_noret_decl(f_8521)
static void C_ccall f_8521(C_word c,C_word *av) C_noret;
C_noret_decl(f_9845)
static void C_ccall f_9845(C_word c,C_word *av) C_noret;
C_noret_decl(f_6382)
static void C_ccall f_6382(C_word c,C_word *av) C_noret;
C_noret_decl(f_4128)
static void C_ccall f_4128(C_word c,C_word *av) C_noret;
C_noret_decl(f_9842)
static void C_fcall f_9842(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8538)
static void C_fcall f_8538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_fcall f_4971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word *av) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word *av) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word *av) C_noret;
C_noret_decl(f_6373)
static void C_ccall f_6373(C_word c,C_word *av) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word *av) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word *av) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word *av) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word *av) C_noret;
C_noret_decl(f_9827)
static void C_ccall f_9827(C_word c,C_word *av) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word *av) C_noret;
C_noret_decl(f_9824)
static void C_ccall f_9824(C_word c,C_word *av) C_noret;
C_noret_decl(f_4969)
static void C_ccall f_4969(C_word c,C_word *av) C_noret;
C_noret_decl(f_5404)
static void C_ccall f_5404(C_word c,C_word *av) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word *av) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word *av) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word *av) C_noret;
C_noret_decl(f_6396)
static void C_fcall f_6396(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10850)
static void C_ccall f_10850(C_word c,C_word *av) C_noret;
C_noret_decl(f_10854)
static void C_ccall f_10854(C_word c,C_word *av) C_noret;
C_noret_decl(f_10858)
static void C_ccall f_10858(C_word c,C_word *av) C_noret;
C_noret_decl(f_7226)
static void C_fcall f_7226(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word *av) C_noret;
C_noret_decl(f_9803)
static void C_ccall f_9803(C_word c,C_word *av) C_noret;
C_noret_decl(f_9806)
static void C_ccall f_9806(C_word c,C_word *av) C_noret;
C_noret_decl(f_9800)
static void C_ccall f_9800(C_word c,C_word *av) C_noret;
C_noret_decl(f_3716)
static void C_ccall f_3716(C_word c,C_word *av) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word *av) C_noret;
C_noret_decl(f_8545)
static void C_ccall f_8545(C_word c,C_word *av) C_noret;
C_noret_decl(f_9727)
static void C_fcall f_9727(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9725)
static void C_ccall f_9725(C_word c,C_word *av) C_noret;
C_noret_decl(f_10840)
static void C_ccall f_10840(C_word c,C_word *av) C_noret;
C_noret_decl(f_10843)
static void C_ccall f_10843(C_word c,C_word *av) C_noret;
C_noret_decl(f_10846)
static void C_ccall f_10846(C_word c,C_word *av) C_noret;
C_noret_decl(f_5375)
static void C_ccall f_5375(C_word c,C_word *av) C_noret;
C_noret_decl(f_5378)
static void C_ccall f_5378(C_word c,C_word *av) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word *av) C_noret;
C_noret_decl(f_5387)
static void C_ccall f_5387(C_word c,C_word *av) C_noret;
C_noret_decl(f_5384)
static void C_ccall f_5384(C_word c,C_word *av) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word *av) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word *av) C_noret;
C_noret_decl(f_5357)
static void C_ccall f_5357(C_word c,C_word *av) C_noret;
C_noret_decl(f_5351)
static void C_ccall f_5351(C_word c,C_word *av) C_noret;
C_noret_decl(f_10831)
static void C_ccall f_10831(C_word c,C_word *av) C_noret;
C_noret_decl(f_10837)
static void C_ccall f_10837(C_word c,C_word *av) C_noret;
C_noret_decl(f_10834)
static void C_ccall f_10834(C_word c,C_word *av) C_noret;
C_noret_decl(f_3402)
static void C_fcall f_3402(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3406)
static void C_ccall f_3406(C_word c,C_word *av) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word *av) C_noret;
C_noret_decl(f_5366)
static void C_fcall f_5366(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5363)
static void C_fcall f_5363(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word *av) C_noret;
C_noret_decl(f_10801)
static void C_ccall f_10801(C_word c,C_word *av) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738(C_word c,C_word *av) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word *av) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word *av) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word *av) C_noret;
C_noret_decl(f_7910)
static void C_ccall f_7910(C_word c,C_word *av) C_noret;
C_noret_decl(f_6313)
static void C_fcall f_6313(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4696)
static void C_ccall f_4696(C_word c,C_word *av) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699(C_word c,C_word *av) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word *av) C_noret;
C_noret_decl(f_6807)
static void C_ccall f_6807(C_word c,C_word *av) C_noret;
C_noret_decl(f_4282)
static void C_ccall f_4282(C_word c,C_word *av) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word *av) C_noret;
C_noret_decl(f_7900)
static void C_fcall f_7900(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5548)
static void C_fcall f_5548(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word *av) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word *av) C_noret;
C_noret_decl(f_5543)
static void C_ccall f_5543(C_word c,C_word *av) C_noret;
C_noret_decl(f_10825)
static void C_ccall f_10825(C_word c,C_word *av) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word *av) C_noret;
C_noret_decl(f11661)
static void C_ccall f11661(C_word c,C_word *av) C_noret;
C_noret_decl(f11669)
static void C_ccall f11669(C_word c,C_word *av) C_noret;
C_noret_decl(f_5397)
static void C_ccall f_5397(C_word c,C_word *av) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word *av) C_noret;
C_noret_decl(f_4261)
static void C_ccall f_4261(C_word c,C_word *av) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word *av) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word *av) C_noret;
C_noret_decl(f_8120)
static void C_fcall f_8120(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5308)
static void C_fcall f_5308(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5587)
static void C_ccall f_5587(C_word c,C_word *av) C_noret;
C_noret_decl(f_4642)
static void C_ccall f_4642(C_word c,C_word *av) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word *av) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word *av) C_noret;
C_noret_decl(f_10205)
static void C_ccall f_10205(C_word c,C_word *av) C_noret;
C_noret_decl(f_10202)
static void C_ccall f_10202(C_word c,C_word *av) C_noret;
C_noret_decl(f_4632)
static void C_fcall f_4632(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word *av) C_noret;
C_noret_decl(f_5536)
static void C_ccall f_5536(C_word c,C_word *av) C_noret;
C_noret_decl(f_5605)
static void C_ccall f_5605(C_word c,C_word *av) C_noret;
C_noret_decl(f_4686)
static void C_fcall f_4686(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word *av) C_noret;
C_noret_decl(f_8663)
static void C_ccall f_8663(C_word c,C_word *av) C_noret;
C_noret_decl(f_4671)
static void C_fcall f_4671(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word *av) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word *av) C_noret;
C_noret_decl(f_2577)
static void C_fcall f_2577(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4661)
static void C_fcall f_4661(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word *av) C_noret;
C_noret_decl(f_8684)
static void C_ccall f_8684(C_word c,C_word *av) C_noret;
C_noret_decl(f_8686)
static void C_fcall f_8686(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word *av) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word *av) C_noret;
C_noret_decl(f_10281)
static void C_ccall f_10281(C_word c,C_word *av) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word *av) C_noret;
C_noret_decl(f_8249)
static void C_fcall f_8249(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word *av) C_noret;
C_noret_decl(f_10287)
static void C_ccall f_10287(C_word c,C_word *av) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word *av) C_noret;
C_noret_decl(f_2540)
static void C_fcall f_2540(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10290)
static void C_ccall f_10290(C_word c,C_word *av) C_noret;
C_noret_decl(f_10293)
static void C_ccall f_10293(C_word c,C_word *av) C_noret;
C_noret_decl(f_7115)
static void C_ccall f_7115(C_word c,C_word *av) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word *av) C_noret;
C_noret_decl(f_6421)
static void C_fcall f_6421(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6423)
static void C_fcall f_6423(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word *av) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word *av) C_noret;
C_noret_decl(f_7100)
static void C_ccall f_7100(C_word c,C_word *av) C_noret;
C_noret_decl(f_6459)
static void C_fcall f_6459(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word *av) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word *av) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word *av) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word *av) C_noret;
C_noret_decl(f_3521)
static void C_fcall f_3521(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6818)
static void C_fcall f_6818(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3662)
static void C_ccall f_3662(C_word c,C_word *av) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word *av) C_noret;
C_noret_decl(f_7898)
static void C_ccall f_7898(C_word c,C_word *av) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word *av) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word *av) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word *av) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word *av) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word *av) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word *av) C_noret;
C_noret_decl(f_3699)
static void C_ccall f_3699(C_word c,C_word *av) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word *av) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word *av) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word *av) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word *av) C_noret;
C_noret_decl(f_5459)
static void C_ccall f_5459(C_word c,C_word *av) C_noret;
C_noret_decl(f_5456)
static void C_ccall f_5456(C_word c,C_word *av) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word *av) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word *av) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587(C_word c,C_word *av) C_noret;
C_noret_decl(f_5423)
static void C_fcall f_5423(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7276)
static void C_fcall f_7276(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7271)
static void C_ccall f_7271(C_word c,C_word *av) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word *av) C_noret;
C_noret_decl(f_6915)
static void C_ccall f_6915(C_word c,C_word *av) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word *av) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word *av) C_noret;
C_noret_decl(f_6909)
static void C_ccall f_6909(C_word c,C_word *av) C_noret;
C_noret_decl(f_6907)
static void C_ccall f_6907(C_word c,C_word *av) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word *av) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word *av) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word *av) C_noret;
C_noret_decl(f_6991)
static void C_ccall f_6991(C_word c,C_word *av) C_noret;
C_noret_decl(f_6969)
static void C_ccall f_6969(C_word c,C_word *av) C_noret;
C_noret_decl(f_6004)
static void C_ccall f_6004(C_word c,C_word *av) C_noret;
C_noret_decl(f_6007)
static void C_ccall f_6007(C_word c,C_word *av) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word *av) C_noret;
C_noret_decl(f_6001)
static void C_ccall f_6001(C_word c,C_word *av) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word *av) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word *av) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word *av) C_noret;
C_noret_decl(f_6982)
static void C_ccall f_6982(C_word c,C_word *av) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word *av) C_noret;
C_noret_decl(f_5612)
static void C_ccall f_5612(C_word c,C_word *av) C_noret;
C_noret_decl(f_6171)
static void C_ccall f_6171(C_word c,C_word *av) C_noret;
C_noret_decl(f_6174)
static void C_ccall f_6174(C_word c,C_word *av) C_noret;
C_noret_decl(f_6929)
static void C_ccall f_6929(C_word c,C_word *av) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word *av) C_noret;
C_noret_decl(f_6925)
static void C_ccall f_6925(C_word c,C_word *av) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word *av) C_noret;
C_noret_decl(f_6923)
static void C_ccall f_6923(C_word c,C_word *av) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word *av) C_noret;
C_noret_decl(f_3086)
static void C_fcall f_3086(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7286)
static void C_ccall f_7286(C_word c,C_word *av) C_noret;
C_noret_decl(f_6988)
static void C_ccall f_6988(C_word c,C_word *av) C_noret;
C_noret_decl(f_6022)
static void C_ccall f_6022(C_word c,C_word *av) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word *av) C_noret;
C_noret_decl(f_6025)
static void C_ccall f_6025(C_word c,C_word *av) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word *av) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word *av) C_noret;
C_noret_decl(f_6177)
static void C_ccall f_6177(C_word c,C_word *av) C_noret;
C_noret_decl(f_7837)
static void C_ccall f_7837(C_word c,C_word *av) C_noret;
C_noret_decl(f_6013)
static void C_ccall f_6013(C_word c,C_word *av) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word *av) C_noret;
C_noret_decl(f_6010)
static void C_ccall f_6010(C_word c,C_word *av) C_noret;
C_noret_decl(f_6019)
static void C_ccall f_6019(C_word c,C_word *av) C_noret;
C_noret_decl(f_6016)
static void C_ccall f_6016(C_word c,C_word *av) C_noret;
C_noret_decl(f_6167)
static void C_ccall f_6167(C_word c,C_word *av) C_noret;
C_noret_decl(f_7849)
static void C_ccall f_7849(C_word c,C_word *av) C_noret;
C_noret_decl(f_7846)
static void C_ccall f_7846(C_word c,C_word *av) C_noret;
C_noret_decl(f_7843)
static void C_ccall f_7843(C_word c,C_word *av) C_noret;
C_noret_decl(f_6043)
static void C_fcall f_6043(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6040)
static void C_ccall f_6040(C_word c,C_word *av) C_noret;
C_noret_decl(f_6183)
static void C_ccall f_6183(C_word c,C_word *av) C_noret;
C_noret_decl(f_6180)
static void C_ccall f_6180(C_word c,C_word *av) C_noret;
C_noret_decl(f_7840)
static void C_ccall f_7840(C_word c,C_word *av) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word *av) C_noret;
C_noret_decl(f_6046)
static void C_ccall f_6046(C_word c,C_word *av) C_noret;
C_noret_decl(f_7404)
static void C_fcall f_7404(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word *av) C_noret;
C_noret_decl(f_6195)
static void C_ccall f_6195(C_word c,C_word *av) C_noret;
C_noret_decl(f_6031)
static void C_ccall f_6031(C_word c,C_word *av) C_noret;
C_noret_decl(f_6034)
static void C_ccall f_6034(C_word c,C_word *av) C_noret;
C_noret_decl(f_7852)
static void C_ccall f_7852(C_word c,C_word *av) C_noret;
C_noret_decl(f_6037)
static void C_ccall f_6037(C_word c,C_word *av) C_noret;
C_noret_decl(f_6186)
static void C_ccall f_6186(C_word c,C_word *av) C_noret;
C_noret_decl(f_7867)
static void C_ccall f_7867(C_word c,C_word *av) C_noret;
C_noret_decl(f_7864)
static void C_ccall f_7864(C_word c,C_word *av) C_noret;
C_noret_decl(f_8711)
static void C_ccall f_8711(C_word c,C_word *av) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word *av) C_noret;
C_noret_decl(f_7861)
static void C_ccall f_7861(C_word c,C_word *av) C_noret;
C_noret_decl(f_6069)
static void C_ccall f_6069(C_word c,C_word *av) C_noret;
C_noret_decl(f_5774)
static void C_ccall f_5774(C_word c,C_word *av) C_noret;
C_noret_decl(f_7876)
static void C_ccall f_7876(C_word c,C_word *av) C_noret;
C_noret_decl(f_7879)
static void C_ccall f_7879(C_word c,C_word *av) C_noret;
C_noret_decl(f_6055)
static void C_ccall f_6055(C_word c,C_word *av) C_noret;
C_noret_decl(f_6052)
static void C_ccall f_6052(C_word c,C_word *av) C_noret;
C_noret_decl(f_7873)
static void C_ccall f_7873(C_word c,C_word *av) C_noret;
C_noret_decl(f_7870)
static void C_ccall f_7870(C_word c,C_word *av) C_noret;
C_noret_decl(f_6058)
static void C_ccall f_6058(C_word c,C_word *av) C_noret;
C_noret_decl(f_7416)
static void C_fcall f_7416(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085(C_word c,C_word *av) C_noret;
C_noret_decl(f_6088)
static void C_ccall f_6088(C_word c,C_word *av) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word *av) C_noret;
C_noret_decl(f_6121)
static void C_ccall f_6121(C_word c,C_word *av) C_noret;
C_noret_decl(f_6136)
static void C_ccall f_6136(C_word c,C_word *av) C_noret;
C_noret_decl(f_6139)
static void C_ccall f_6139(C_word c,C_word *av) C_noret;
C_noret_decl(f_3987)
static void C_fcall f_3987(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_9468)
static void C_ccall f_9468(C_word c,C_word *av) C_noret;
C_noret_decl(f_6097)
static void C_fcall f_6097(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word *av) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word *av) C_noret;
C_noret_decl(f_6951)
static void C_ccall f_6951(C_word c,C_word *av) C_noret;
C_noret_decl(f_8388)
static void C_fcall f_8388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8384)
static void C_ccall f_8384(C_word c,C_word *av) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625(C_word c,C_word *av) C_noret;
C_noret_decl(f_6622)
static void C_ccall f_6622(C_word c,C_word *av) C_noret;
C_noret_decl(f_6628)
static void C_ccall f_6628(C_word c,C_word *av) C_noret;
C_noret_decl(f_10199)
static void C_ccall f_10199(C_word c,C_word *av) C_noret;
C_noret_decl(f_4878)
static void C_ccall f_4878(C_word c,C_word *av) C_noret;
C_noret_decl(f_10193)
static void C_ccall f_10193(C_word c,C_word *av) C_noret;
C_noret_decl(f_6959)
static void C_fcall f_6959(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3950)
static void C_fcall f_3950(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2885)
static void C_ccall f_2885(C_word c,C_word *av) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word *av) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word *av) C_noret;
C_noret_decl(f_2830)
static void C_fcall f_2830(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6613)
static void C_ccall f_6613(C_word c,C_word *av) C_noret;
C_noret_decl(f_6619)
static void C_ccall f_6619(C_word c,C_word *av) C_noret;
C_noret_decl(f_6616)
static void C_ccall f_6616(C_word c,C_word *av) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word *av) C_noret;
C_noret_decl(f_6610)
static void C_ccall f_6610(C_word c,C_word *av) C_noret;
C_noret_decl(f_6107)
static void C_ccall f_6107(C_word c,C_word *av) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942(C_word c,C_word *av) C_noret;
C_noret_decl(f_8369)
static void C_fcall f_8369(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10178)
static void C_ccall f_10178(C_word c,C_word *av) C_noret;
C_noret_decl(f_10175)
static void C_ccall f_10175(C_word c,C_word *av) C_noret;
C_noret_decl(f_10608)
static void C_ccall f_10608(C_word c,C_word *av) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word *av) C_noret;
C_noret_decl(f_10181)
static void C_ccall f_10181(C_word c,C_word *av) C_noret;
C_noret_decl(f_4482)
static void C_ccall f_4482(C_word c,C_word *av) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word *av) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word *av) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word *av) C_noret;
C_noret_decl(f_8357)
static void C_fcall f_8357(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5761)
static void C_fcall f_5761(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5767)
static void C_ccall f_5767(C_word c,C_word *av) C_noret;
C_noret_decl(f_5764)
static void C_ccall f_5764(C_word c,C_word *av) C_noret;
C_noret_decl(f_4479)
static void C_ccall f_4479(C_word c,C_word *av) C_noret;
C_noret_decl(f_4476)
static void C_ccall f_4476(C_word c,C_word *av) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word *av) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word *av) C_noret;
C_noret_decl(f_5734)
static void C_ccall f_5734(C_word c,C_word *av) C_noret;
C_noret_decl(f_4463)
static void C_ccall f_4463(C_word c,C_word *av) C_noret;
C_noret_decl(f_4460)
static void C_ccall f_4460(C_word c,C_word *av) C_noret;
C_noret_decl(f_4450)
static void C_fcall f_4450(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10233)
static void C_ccall f_10233(C_word c,C_word *av) C_noret;
C_noret_decl(f_10239)
static void C_ccall f_10239(C_word c,C_word *av) C_noret;
C_noret_decl(f_5511)
static void C_ccall f_5511(C_word c,C_word *av) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word *av) C_noret;
C_noret_decl(f_10242)
static void C_ccall f_10242(C_word c,C_word *av) C_noret;
C_noret_decl(f_10245)
static void C_ccall f_10245(C_word c,C_word *av) C_noret;
C_noret_decl(f_9908)
static void C_ccall f_9908(C_word c,C_word *av) C_noret;
C_noret_decl(f_10121)
static void C_ccall f_10121(C_word c,C_word *av) C_noret;
C_noret_decl(f_9905)
static void C_ccall f_9905(C_word c,C_word *av) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word *av) C_noret;
C_noret_decl(f_9902)
static void C_ccall f_9902(C_word c,C_word *av) C_noret;
C_noret_decl(f_10127)
static void C_ccall f_10127(C_word c,C_word *av) C_noret;
C_noret_decl(f_10257)
static void C_ccall f_10257(C_word c,C_word *av) C_noret;
C_noret_decl(f_5817)
static void C_ccall f_5817(C_word c,C_word *av) C_noret;
C_noret_decl(f_10269)
static void C_ccall f_10269(C_word c,C_word *av) C_noret;
C_noret_decl(f_10263)
static void C_ccall f_10263(C_word c,C_word *av) C_noret;
C_noret_decl(f_10266)
static void C_ccall f_10266(C_word c,C_word *av) C_noret;
C_noret_decl(f_10103)
static void C_ccall f_10103(C_word c,C_word *av) C_noret;
C_noret_decl(f_9929)
static void C_ccall f_9929(C_word c,C_word *av) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word *av) C_noret;
C_noret_decl(f_5822)
static void C_fcall f_5822(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10109)
static void C_ccall f_10109(C_word c,C_word *av) C_noret;
C_noret_decl(f_9923)
static void C_ccall f_9923(C_word c,C_word *av) C_noret;
C_noret_decl(f_10106)
static void C_ccall f_10106(C_word c,C_word *av) C_noret;
C_noret_decl(f_10151)
static void C_ccall f_10151(C_word c,C_word *av) C_noret;
C_noret_decl(f_10154)
static void C_ccall f_10154(C_word c,C_word *av) C_noret;
C_noret_decl(f_4837)
static void C_fcall f_4837(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10157)
static void C_ccall f_10157(C_word c,C_word *av) C_noret;
C_noret_decl(f_9947)
static void C_ccall f_9947(C_word c,C_word *av) C_noret;
C_noret_decl(f_7328)
static void C_ccall f_7328(C_word c,C_word *av) C_noret;
C_noret_decl(f_10169)
static void C_ccall f_10169(C_word c,C_word *av) C_noret;
C_noret_decl(f_9935)
static void C_ccall f_9935(C_word c,C_word *av) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word *av) C_noret;
C_noret_decl(f_10130)
static void C_ccall f_10130(C_word c,C_word *av) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word *av) C_noret;
C_noret_decl(f_10133)
static void C_ccall f_10133(C_word c,C_word *av) C_noret;
C_noret_decl(f_9932)
static void C_ccall f_9932(C_word c,C_word *av) C_noret;

C_noret_decl(trf_4911)
static void C_ccall trf_4911(C_word c,C_word *av) C_noret;
static void C_ccall trf_4911(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4911(t0,t1,t2);}

C_noret_decl(trf_5634)
static void C_ccall trf_5634(C_word c,C_word *av) C_noret;
static void C_ccall trf_5634(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5634(t0,t1,t2,t3);}

C_noret_decl(trf_10082)
static void C_ccall trf_10082(C_word c,C_word *av) C_noret;
static void C_ccall trf_10082(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10082(t0,t1);}

C_noret_decl(trf_3396)
static void C_ccall trf_3396(C_word c,C_word *av) C_noret;
static void C_ccall trf_3396(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3396(t0,t1);}

C_noret_decl(trf_5672)
static void C_ccall trf_5672(C_word c,C_word *av) C_noret;
static void C_ccall trf_5672(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5672(t0,t1);}

C_noret_decl(trf_8045)
static void C_ccall trf_8045(C_word c,C_word *av) C_noret;
static void C_ccall trf_8045(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8045(t0,t1);}

C_noret_decl(trf_8444)
static void C_ccall trf_8444(C_word c,C_word *av) C_noret;
static void C_ccall trf_8444(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8444(t0,t1);}

C_noret_decl(trf_5807)
static void C_ccall trf_5807(C_word c,C_word *av) C_noret;
static void C_ccall trf_5807(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5807(t0,t1,t2);}

C_noret_decl(trf_8050)
static void C_ccall trf_8050(C_word c,C_word *av) C_noret;
static void C_ccall trf_8050(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8050(t0,t1,t2);}

C_noret_decl(trf_5665)
static void C_ccall trf_5665(C_word c,C_word *av) C_noret;
static void C_ccall trf_5665(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5665(t0,t1,t2,t3);}

C_noret_decl(trf_8572)
static void C_ccall trf_8572(C_word c,C_word *av) C_noret;
static void C_ccall trf_8572(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8572(t0,t1);}

C_noret_decl(trf_8427)
static void C_ccall trf_8427(C_word c,C_word *av) C_noret;
static void C_ccall trf_8427(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8427(t0,t1);}

C_noret_decl(trf_5949)
static void C_ccall trf_5949(C_word c,C_word *av) C_noret;
static void C_ccall trf_5949(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5949(t0,t1);}

C_noret_decl(trf_7219)
static void C_ccall trf_7219(C_word c,C_word *av) C_noret;
static void C_ccall trf_7219(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_7219(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5000)
static void C_ccall trf_5000(C_word c,C_word *av) C_noret;
static void C_ccall trf_5000(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5000(t0,t1,t2,t3);}

C_noret_decl(trf_8589)
static void C_ccall trf_8589(C_word c,C_word *av) C_noret;
static void C_ccall trf_8589(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8589(t0,t1);}

C_noret_decl(trf_2610)
static void C_ccall trf_2610(C_word c,C_word *av) C_noret;
static void C_ccall trf_2610(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2610(t0,t1,t2);}

C_noret_decl(trf_6715)
static void C_ccall trf_6715(C_word c,C_word *av) C_noret;
static void C_ccall trf_6715(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6715(t0,t1,t2);}

C_noret_decl(trf_5040)
static void C_ccall trf_5040(C_word c,C_word *av) C_noret;
static void C_ccall trf_5040(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5040(t0,t1,t2);}

C_noret_decl(trf_2625)
static void C_ccall trf_2625(C_word c,C_word *av) C_noret;
static void C_ccall trf_2625(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2625(t0,t1,t2,t3);}

C_noret_decl(trf_2622)
static void C_ccall trf_2622(C_word c,C_word *av) C_noret;
static void C_ccall trf_2622(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_2622(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9346)
static void C_ccall trf_9346(C_word c,C_word *av) C_noret;
static void C_ccall trf_9346(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9346(t0,t1);}

C_noret_decl(trf_3773)
static void C_ccall trf_3773(C_word c,C_word *av) C_noret;
static void C_ccall trf_3773(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3773(t0,t1);}

C_noret_decl(trf_7957)
static void C_ccall trf_7957(C_word c,C_word *av) C_noret;
static void C_ccall trf_7957(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7957(t0,t1,t2);}

C_noret_decl(trf_5143)
static void C_ccall trf_5143(C_word c,C_word *av) C_noret;
static void C_ccall trf_5143(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5143(t0,t1);}

C_noret_decl(trf_5067)
static void C_ccall trf_5067(C_word c,C_word *av) C_noret;
static void C_ccall trf_5067(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5067(t0,t1,t2);}

C_noret_decl(trf_5120)
static void C_ccall trf_5120(C_word c,C_word *av) C_noret;
static void C_ccall trf_5120(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5120(t0,t1,t2);}

C_noret_decl(trf_7395)
static void C_ccall trf_7395(C_word c,C_word *av) C_noret;
static void C_ccall trf_7395(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7395(t0,t1);}

C_noret_decl(trf_7027)
static void C_ccall trf_7027(C_word c,C_word *av) C_noret;
static void C_ccall trf_7027(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7027(t0,t1,t2);}

C_noret_decl(trf_7364)
static void C_ccall trf_7364(C_word c,C_word *av) C_noret;
static void C_ccall trf_7364(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7364(t0,t1,t2);}

C_noret_decl(trf_5977)
static void C_ccall trf_5977(C_word c,C_word *av) C_noret;
static void C_ccall trf_5977(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5977(t0,t1);}

C_noret_decl(trf_7339)
static void C_ccall trf_7339(C_word c,C_word *av) C_noret;
static void C_ccall trf_7339(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7339(t0,t1,t2);}

C_noret_decl(trf_8623)
static void C_ccall trf_8623(C_word c,C_word *av) C_noret;
static void C_ccall trf_8623(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8623(t0,t1);}

C_noret_decl(trf_9124)
static void C_ccall trf_9124(C_word c,C_word *av) C_noret;
static void C_ccall trf_9124(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9124(t0,t1);}

C_noret_decl(trf_8640)
static void C_ccall trf_8640(C_word c,C_word *av) C_noret;
static void C_ccall trf_8640(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8640(t0,t1);}

C_noret_decl(trf_6492)
static void C_ccall trf_6492(C_word c,C_word *av) C_noret;
static void C_ccall trf_6492(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6492(t0,t1);}

C_noret_decl(trf_9151)
static void C_ccall trf_9151(C_word c,C_word *av) C_noret;
static void C_ccall trf_9151(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9151(t0,t1);}

C_noret_decl(trf_8606)
static void C_ccall trf_8606(C_word c,C_word *av) C_noret;
static void C_ccall trf_8606(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8606(t0,t1);}

C_noret_decl(trf_6846)
static void C_ccall trf_6846(C_word c,C_word *av) C_noret;
static void C_ccall trf_6846(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6846(t0,t1);}

C_noret_decl(trf_5883)
static void C_ccall trf_5883(C_word c,C_word *av) C_noret;
static void C_ccall trf_5883(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5883(t0,t1,t2,t3);}

C_noret_decl(trf_3639)
static void C_ccall trf_3639(C_word c,C_word *av) C_noret;
static void C_ccall trf_3639(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3639(t0,t1);}

C_noret_decl(trf_8228)
static void C_ccall trf_8228(C_word c,C_word *av) C_noret;
static void C_ccall trf_8228(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8228(t0,t1);}

C_noret_decl(trf_5219)
static void C_ccall trf_5219(C_word c,C_word *av) C_noret;
static void C_ccall trf_5219(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5219(t0,t1);}

C_noret_decl(trf_5838)
static void C_ccall trf_5838(C_word c,C_word *av) C_noret;
static void C_ccall trf_5838(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5838(t0,t1);}

C_noret_decl(trf_4761)
static void C_ccall trf_4761(C_word c,C_word *av) C_noret;
static void C_ccall trf_4761(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4761(t0,t1);}

C_noret_decl(trf_4758)
static void C_ccall trf_4758(C_word c,C_word *av) C_noret;
static void C_ccall trf_4758(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4758(t0,t1);}

C_noret_decl(trf_7438)
static void C_ccall trf_7438(C_word c,C_word *av) C_noret;
static void C_ccall trf_7438(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7438(t0,t1,t2);}

C_noret_decl(trf_10519)
static void C_ccall trf_10519(C_word c,C_word *av) C_noret;
static void C_ccall trf_10519(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10519(t0,t1);}

C_noret_decl(trf_3921)
static void C_ccall trf_3921(C_word c,C_word *av) C_noret;
static void C_ccall trf_3921(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3921(t0,t1,t2,t3);}

C_noret_decl(trf_3449)
static void C_ccall trf_3449(C_word c,C_word *av) C_noret;
static void C_ccall trf_3449(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3449(t0,t1,t2,t3);}

C_noret_decl(trf_5162)
static void C_ccall trf_5162(C_word c,C_word *av) C_noret;
static void C_ccall trf_5162(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5162(t0,t1);}

C_noret_decl(trf_9096)
static void C_ccall trf_9096(C_word c,C_word *av) C_noret;
static void C_ccall trf_9096(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9096(t0,t1);}

C_noret_decl(trf_7002)
static void C_ccall trf_7002(C_word c,C_word *av) C_noret;
static void C_ccall trf_7002(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7002(t0,t1,t2);}

C_noret_decl(trf_5321)
static void C_ccall trf_5321(C_word c,C_word *av) C_noret;
static void C_ccall trf_5321(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5321(t0,t1,t2,t3);}

C_noret_decl(trf_8496)
static void C_ccall trf_8496(C_word c,C_word *av) C_noret;
static void C_ccall trf_8496(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8496(t0,t1,t2);}

C_noret_decl(trf_6676)
static void C_ccall trf_6676(C_word c,C_word *av) C_noret;
static void C_ccall trf_6676(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6676(t0,t1,t2);}

C_noret_decl(trf_3484)
static void C_ccall trf_3484(C_word c,C_word *av) C_noret;
static void C_ccall trf_3484(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3484(t0,t1,t2,t3);}

C_noret_decl(trf_9355)
static void C_ccall trf_9355(C_word c,C_word *av) C_noret;
static void C_ccall trf_9355(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9355(t0,t1);}

C_noret_decl(trf_6255)
static void C_ccall trf_6255(C_word c,C_word *av) C_noret;
static void C_ccall trf_6255(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6255(t0,t1);}

C_noret_decl(trf_8461)
static void C_ccall trf_8461(C_word c,C_word *av) C_noret;
static void C_ccall trf_8461(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8461(t0,t1);}

C_noret_decl(trf_3114)
static void C_ccall trf_3114(C_word c,C_word *av) C_noret;
static void C_ccall trf_3114(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3114(t0,t1,t2,t3);}

C_noret_decl(trf_10059)
static void C_ccall trf_10059(C_word c,C_word *av) C_noret;
static void C_ccall trf_10059(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10059(t0,t1,t2);}

C_noret_decl(trf_9391)
static void C_ccall trf_9391(C_word c,C_word *av) C_noret;
static void C_ccall trf_9391(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9391(t0,t1);}

C_noret_decl(trf_7471)
static void C_ccall trf_7471(C_word c,C_word *av) C_noret;
static void C_ccall trf_7471(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7471(t0,t1);}

C_noret_decl(trf_5417)
static void C_ccall trf_5417(C_word c,C_word *av) C_noret;
static void C_ccall trf_5417(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5417(t0,t1);}

C_noret_decl(trf_7428)
static void C_ccall trf_7428(C_word c,C_word *av) C_noret;
static void C_ccall trf_7428(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7428(t0,t1);}

C_noret_decl(trf_8555)
static void C_ccall trf_8555(C_word c,C_word *av) C_noret;
static void C_ccall trf_8555(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8555(t0,t1);}

C_noret_decl(trf_9842)
static void C_ccall trf_9842(C_word c,C_word *av) C_noret;
static void C_ccall trf_9842(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9842(t0,t1);}

C_noret_decl(trf_8538)
static void C_ccall trf_8538(C_word c,C_word *av) C_noret;
static void C_ccall trf_8538(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8538(t0,t1);}

C_noret_decl(trf_4971)
static void C_ccall trf_4971(C_word c,C_word *av) C_noret;
static void C_ccall trf_4971(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4971(t0,t1);}

C_noret_decl(trf_6396)
static void C_ccall trf_6396(C_word c,C_word *av) C_noret;
static void C_ccall trf_6396(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6396(t0,t1,t2);}

C_noret_decl(trf_7226)
static void C_ccall trf_7226(C_word c,C_word *av) C_noret;
static void C_ccall trf_7226(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7226(t0,t1);}

C_noret_decl(trf_9727)
static void C_ccall trf_9727(C_word c,C_word *av) C_noret;
static void C_ccall trf_9727(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9727(t0,t1);}

C_noret_decl(trf_3402)
static void C_ccall trf_3402(C_word c,C_word *av) C_noret;
static void C_ccall trf_3402(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3402(t0,t1);}

C_noret_decl(trf_5366)
static void C_ccall trf_5366(C_word c,C_word *av) C_noret;
static void C_ccall trf_5366(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5366(t0,t1);}

C_noret_decl(trf_5363)
static void C_ccall trf_5363(C_word c,C_word *av) C_noret;
static void C_ccall trf_5363(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5363(t0,t1);}

C_noret_decl(trf_6313)
static void C_ccall trf_6313(C_word c,C_word *av) C_noret;
static void C_ccall trf_6313(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6313(t0,t1);}

C_noret_decl(trf_7900)
static void C_ccall trf_7900(C_word c,C_word *av) C_noret;
static void C_ccall trf_7900(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7900(t0,t1,t2,t3);}

C_noret_decl(trf_5548)
static void C_ccall trf_5548(C_word c,C_word *av) C_noret;
static void C_ccall trf_5548(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5548(t0,t1,t2);}

C_noret_decl(trf_8120)
static void C_ccall trf_8120(C_word c,C_word *av) C_noret;
static void C_ccall trf_8120(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8120(t0,t1);}

C_noret_decl(trf_5308)
static void C_ccall trf_5308(C_word c,C_word *av) C_noret;
static void C_ccall trf_5308(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5308(t0,t1);}

C_noret_decl(trf_4632)
static void C_ccall trf_4632(C_word c,C_word *av) C_noret;
static void C_ccall trf_4632(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4632(t0,t1,t2,t3);}

C_noret_decl(trf_4686)
static void C_ccall trf_4686(C_word c,C_word *av) C_noret;
static void C_ccall trf_4686(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4686(t0,t1,t2,t3);}

C_noret_decl(trf_4671)
static void C_ccall trf_4671(C_word c,C_word *av) C_noret;
static void C_ccall trf_4671(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4671(t0,t1);}

C_noret_decl(trf_2577)
static void C_ccall trf_2577(C_word c,C_word *av) C_noret;
static void C_ccall trf_2577(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2577(t0,t1,t2);}

C_noret_decl(trf_4661)
static void C_ccall trf_4661(C_word c,C_word *av) C_noret;
static void C_ccall trf_4661(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_4661(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8686)
static void C_ccall trf_8686(C_word c,C_word *av) C_noret;
static void C_ccall trf_8686(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8686(t0,t1,t2);}

C_noret_decl(trf_8249)
static void C_ccall trf_8249(C_word c,C_word *av) C_noret;
static void C_ccall trf_8249(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8249(t0,t1);}

C_noret_decl(trf_2540)
static void C_ccall trf_2540(C_word c,C_word *av) C_noret;
static void C_ccall trf_2540(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2540(t0,t1,t2);}

C_noret_decl(trf_6421)
static void C_ccall trf_6421(C_word c,C_word *av) C_noret;
static void C_ccall trf_6421(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6421(t0,t1);}

C_noret_decl(trf_6423)
static void C_ccall trf_6423(C_word c,C_word *av) C_noret;
static void C_ccall trf_6423(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6423(t0,t1,t2,t3);}

C_noret_decl(trf_6459)
static void C_ccall trf_6459(C_word c,C_word *av) C_noret;
static void C_ccall trf_6459(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6459(t0,t1,t2);}

C_noret_decl(trf_3521)
static void C_ccall trf_3521(C_word c,C_word *av) C_noret;
static void C_ccall trf_3521(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3521(t0,t1,t2,t3);}

C_noret_decl(trf_6818)
static void C_ccall trf_6818(C_word c,C_word *av) C_noret;
static void C_ccall trf_6818(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6818(t0,t1,t2);}

C_noret_decl(trf_5423)
static void C_ccall trf_5423(C_word c,C_word *av) C_noret;
static void C_ccall trf_5423(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5423(t0,t1,t2,t3);}

C_noret_decl(trf_7276)
static void C_ccall trf_7276(C_word c,C_word *av) C_noret;
static void C_ccall trf_7276(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7276(t0,t1,t2);}

C_noret_decl(trf_3086)
static void C_ccall trf_3086(C_word c,C_word *av) C_noret;
static void C_ccall trf_3086(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3086(t0,t1,t2,t3);}

C_noret_decl(trf_6043)
static void C_ccall trf_6043(C_word c,C_word *av) C_noret;
static void C_ccall trf_6043(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6043(t0,t1);}

C_noret_decl(trf_7404)
static void C_ccall trf_7404(C_word c,C_word *av) C_noret;
static void C_ccall trf_7404(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7404(t0,t1);}

C_noret_decl(trf_7416)
static void C_ccall trf_7416(C_word c,C_word *av) C_noret;
static void C_ccall trf_7416(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7416(t0,t1);}

C_noret_decl(trf_3987)
static void C_ccall trf_3987(C_word c,C_word *av) C_noret;
static void C_ccall trf_3987(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3987(t0,t1,t2,t3);}

C_noret_decl(trf_6097)
static void C_ccall trf_6097(C_word c,C_word *av) C_noret;
static void C_ccall trf_6097(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6097(t0,t1,t2,t3);}

C_noret_decl(trf_8388)
static void C_ccall trf_8388(C_word c,C_word *av) C_noret;
static void C_ccall trf_8388(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8388(t0,t1,t2);}

C_noret_decl(trf_6959)
static void C_ccall trf_6959(C_word c,C_word *av) C_noret;
static void C_ccall trf_6959(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6959(t0,t1,t2);}

C_noret_decl(trf_3950)
static void C_ccall trf_3950(C_word c,C_word *av) C_noret;
static void C_ccall trf_3950(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3950(t0,t1,t2,t3);}

C_noret_decl(trf_2830)
static void C_ccall trf_2830(C_word c,C_word *av) C_noret;
static void C_ccall trf_2830(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_2830(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8369)
static void C_ccall trf_8369(C_word c,C_word *av) C_noret;
static void C_ccall trf_8369(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8369(t0,t1);}

C_noret_decl(trf_8357)
static void C_ccall trf_8357(C_word c,C_word *av) C_noret;
static void C_ccall trf_8357(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8357(t0,t1);}

C_noret_decl(trf_5761)
static void C_ccall trf_5761(C_word c,C_word *av) C_noret;
static void C_ccall trf_5761(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5761(t0,t1);}

C_noret_decl(trf_4450)
static void C_ccall trf_4450(C_word c,C_word *av) C_noret;
static void C_ccall trf_4450(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4450(t0,t1,t2,t3);}

C_noret_decl(trf_5822)
static void C_ccall trf_5822(C_word c,C_word *av) C_noret;
static void C_ccall trf_5822(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5822(t0,t1,t2,t3);}

C_noret_decl(trf_4837)
static void C_ccall trf_4837(C_word c,C_word *av) C_noret;
static void C_ccall trf_4837(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4837(t0,t1,t2);}

/* k10143 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10145(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_10145,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10151,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1333: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[815];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k7347 in for-each-loop1143 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7349(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7349,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7339(t3,((C_word*)t0)[4],t2);}

/* a6225 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in ... */
static void C_ccall f_6226(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6226,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6234,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:792: literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
f_5473(3,av2);}}

/* k3313 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3315(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3315,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:217: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k3316 in k3313 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3318(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3318,2,av);}
/* c-backend.scm:218: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k9792 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9794(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_9794,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9800,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1307: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[795];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k6238 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in ... */
static void C_ccall f_6240(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_6240,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6255,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[136]+1);
if(C_truep(*((C_word*)lf[136]+1))){
t5=t3;
f_6255(t5,C_SCHEME_FALSE);}
else{
t5=*((C_word*)lf[410]+1);
if(C_truep(*((C_word*)lf[410]+1))){
t6=t3;
f_6255(t6,C_SCHEME_FALSE);}
else{
t6=C_i_greaterp(((C_word*)t0)[3],C_fix(2));
t7=t3;
f_6255(t7,(C_truep(t6)?C_i_not(((C_word*)t0)[6]):C_SCHEME_FALSE));}}}

/* k6241 in k6238 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in ... */
static void C_ccall f_6243(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,9))){C_save_and_reclaim((void *)f_6243,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(*((C_word*)lf[405]+1))){
/* c-backend.scm:825: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[406];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
/* c-backend.scm:826: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 10) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(10);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[401];
av2[4]=((C_word*)t0)[3];
av2[5]=lf[402];
av2[6]=((C_word*)t0)[4];
av2[7]=lf[403];
av2[8]=((C_word*)t0)[5];
av2[9]=lf[404];
((C_proc)(void*)(*((C_word*)t3+1)))(10,av2);}}}

/* k6244 in k6241 in k6238 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in ... */
static void C_ccall f_6246(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,9))){C_save_and_reclaim((void *)f_6246,2,av);}
/* c-backend.scm:826: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 10) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(10);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[401];
av2[4]=((C_word*)t0)[3];
av2[5]=lf[402];
av2[6]=((C_word*)t0)[4];
av2[7]=lf[403];
av2[8]=((C_word*)t0)[5];
av2[9]=lf[404];
((C_proc)(void*)(*((C_word*)t2+1)))(10,av2);}}

/* k4934 in map-loop557 in k4904 in k4888 in k4884 in k4880 in k4876 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4936(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4936,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4911(t6,((C_word*)t0)[5],t5);}

/* k4415 in k4412 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4417(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4417,2,av);}
/* c-backend.scm:441: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4412 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4414(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4414,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4417,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:440: expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4632(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k6232 in a6225 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in ... */
static void C_ccall f_6234(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,1))){C_save_and_reclaim((void *)f_6234,2,av);}
a=C_alloc(4);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_plus(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3337 in k3334 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3339(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3339,2,av);}
/* c-backend.scm:223: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3334 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3336(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3336,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3339,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:222: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k3331 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3333(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3333,2,av);}
/* c-backend.scm:216: uncommentify */
t2=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop557 in k4904 in k4888 in k4884 in k4880 in k4876 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_4911(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_4911,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4936,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:518: g580 */
t5=*((C_word*)lf[114]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[258];
av2[3]=t4;
av2[4]=lf[259];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6602 in k6599 in k6595 in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_6604,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:880: generate-external-variables */
t3=*((C_word*)lf[480]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[481]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6605 in k6602 in k6599 in k6595 in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_6607,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:881: generate-foreign-stubs */
t3=*((C_word*)lf[478]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[479]+1);
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6599 in k6595 in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6601(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_6601,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:879: declarations */
t3=((C_word*)((C_word*)t0)[10])[1];
f_4971(t3,t2);}

/* k2933 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2935(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_2935,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2938,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:133: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k2936 in k2933 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2938(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2938,2,av);}
/* c-backend.scm:134: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[40];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4904 in k4888 in k4884 in k4880 in k4876 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4906(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_4906,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4909,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4911,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4911(t6,t2,t1);}

/* k10095 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10097(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_10097,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10103,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1329: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[811];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2906 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_2908,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:128: expr */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2625(t4,t2,t3,((C_word*)t0)[6]);}

/* k6702 in k6642 in emit-debug-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6704(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_6704,2,av);}
a=C_alloc(8);
t2=C_i_check_list_2(t1,lf[57]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6710,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6715,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_6715(t7,t3,t1);}

/* k4907 in k4904 in k4888 in k4884 in k4880 in k4876 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4909(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4909,2,av);}
/* c-backend.scm:517: string-intersperse */
t2=*((C_word*)lf[256]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[257];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* loop in k5603 in k5585 in k5478 in literal-size in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5634(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,2))){
C_save_and_reclaim_args((void *)trf_5634,4,t0,t1,t2,t3);}
a=C_alloc(10);
if(C_truep(C_i_greater_or_equalp(t2,((C_word*)t0)[2]))){
t4=t3;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_a_i_plus(&a,2,t2,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5656,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(((C_word*)t0)[4],t2);
/* c-backend.scm:669: literal-size */
t8=((C_word*)((C_word*)t0)[5])[1];{
C_word av2[3];
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
f_5473(3,av2);}}}

/* k4190 in k4187 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4192(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4192,2,av);}
/* c-backend.scm:393: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2909 in k2906 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2911,2,av);}
a=C_alloc(4);
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_plus(&a,2,t2,C_fix(1));
/* c-backend.scm:129: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[37];
av2[3]=t3;
av2[4]=C_make_character(93);
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k8003 in k8000 in k7997 in k7991 in k7988 in k7985 in k7982 in generate-foreign-callback-header in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8005(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_8005,2,av);}
/* c-backend.scm:1126: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8000 in k7997 in k7991 in k7988 in k7985 in k7982 in generate-foreign-callback-header in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8002(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_8002,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8005,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8010,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm:1121: pair-for-each */
t4=*((C_word*)lf[219]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4187 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4189(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4189,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4192,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:392: expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4632(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k8012 in a8009 in k8000 in k7997 in k7991 in k7988 in k7985 in k7982 in generate-foreign-callback-header in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8014(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_8014,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_pairp(t3))){
/* c-backend.scm:1124: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* a8009 in k8000 in k7997 in k7991 in k7988 in k7985 in k7982 in generate-foreign-callback-header in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8010(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_8010,4,av);}
a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8014,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8029,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_i_car(t3);
t7=C_i_car(t2);
/* c-backend.scm:1123: foreign-type-declaration */
t8=*((C_word*)lf[190]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t5;
av2[2]=t6;
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_10082(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_10082,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_eqp(t2,lf[584]);
t4=(C_truep(t3)?t3:C_eqp(t2,lf[585]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10097,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1329: open-output-string */
t6=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_eqp(t2,lf[580]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10121,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1331: open-output-string */
t7=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=C_eqp(t2,lf[587]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10145,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1333: open-output-string */
t8=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=C_eqp(t2,lf[588]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1335: open-output-string */
t9=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t8=C_eqp(t2,lf[589]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10193,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1337: open-output-string */
t10=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t10;
av2[1]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t9=C_eqp(t2,lf[582]);
if(C_truep(t9)){
t10=C_i_cadr(((C_word*)t0)[2]);
/* c-backend.scm:1338: foreign-result-conversion */
t11=*((C_word*)lf[184]+1);{
C_word av2[4];
av2[0]=t11;
av2[1]=((C_word*)t0)[3];
av2[2]=t10;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}
else{
t10=C_eqp(t2,lf[433]);
t11=(C_truep(t10)?t10:C_eqp(t2,lf[583]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10233,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1340: open-output-string */
t13=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t13;
av2[1]=t12;
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t12=C_eqp(t2,lf[586]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10257,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1341: open-output-string */
t14=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t14;
av2[1]=t13;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
else{
t13=C_eqp(t2,lf[723]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10281,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1342: open-output-string */
t15=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t15;
av2[1]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
/* c-backend.scm:1343: err */
t14=((C_word*)t0)[5];
f_9727(t14,((C_word*)t0)[3]);}}}}}}}}}}
else{
/* c-backend.scm:1344: err */
t2=((C_word*)t0)[5];
f_9727(t2,((C_word*)t0)[3]);}}

/* k4171 in k4168 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4173(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4173,2,av);}
/* c-backend.scm:388: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[172];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4168 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4170(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4170,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4173,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:387: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3399(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,2))){C_save_and_reclaim((void *)f_3399,2,av);}
a=C_alloc(26);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_3402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3864,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3868,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:239: find-lambda */
t6=((C_word*)((C_word*)t0)[19])[1];
f_2610(t6,t5,((C_word*)t0)[8]);}
else{
t4=t3;
f_3402(t4,C_SCHEME_FALSE);}}

/* k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3393(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,2))){C_save_and_reclaim((void *)f_3393,2,av);}
a=C_alloc(20);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_3396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t2,a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
if(C_truep(((C_word*)t0)[19])){
t4=C_i_cdddr(((C_word*)t0)[18]);
t5=C_i_pairp(t4);
t6=t3;
f_3396(t6,(C_truep(t5)?C_i_cadddr(((C_word*)t0)[18]):C_SCHEME_FALSE));}
else{
t4=t3;
f_3396(t4,C_SCHEME_FALSE);}}

/* k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_3396(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(20,0,2))){
C_save_and_reclaim_args((void *)trf_3396,2,t0,t1);}
a=C_alloc(20);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_3399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
if(C_truep(t2)){
/* c-backend.scm:238: fifth */
t4=*((C_word*)lf[158]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[19];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_3399(2,av2);}}}

/* k8027 in a8009 in k8000 in k7997 in k7991 in k7988 in k7985 in k7982 in generate-foreign-callback-header in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8029(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_8029,2,av);}
/* c-backend.scm:1123: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5670 in gen-lit in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5672(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,6))){
C_save_and_reclaim_args((void *)trf_5672,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
/* c-backend.scm:675: gen */
t2=*((C_word*)lf[1]+1);{
C_word av2[7];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[3];
av2[4]=lf[330];
av2[5]=((C_word*)t0)[4];
av2[6]=lf[331];
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:676: block-variable-literal? */
t3=*((C_word*)lf[328]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k5676 in k5670 in gen-lit in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5678(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,6))){C_save_and_reclaim((void *)f_5678,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=*((C_word*)lf[332]+1);
t3=C_eqp(((C_word*)t0)[3],*((C_word*)lf[332]+1));
if(C_truep(t3)){
/* c-backend.scm:678: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[4];
av2[4]=lf[333];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
if(C_truep(C_booleanp(((C_word*)t0)[3]))){
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm:680: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[4];
av2[4]=C_make_character(61);
av2[5]=lf[334];
av2[6]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}}
else{
/* c-backend.scm:680: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[4];
av2[4]=C_make_character(61);
av2[5]=lf[335];
av2[6]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}}}
else{
if(C_truep(C_charp(((C_word*)t0)[3]))){
t4=C_fix(C_character_code(((C_word*)t0)[3]));
/* c-backend.scm:682: gen */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[4];
av2[4]=lf[336];
av2[5]=t4;
av2[6]=lf[337];
((C_proc)(void*)(*((C_word*)t5+1)))(7,av2);}}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
t4=C_slot(((C_word*)t0)[3],C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5728,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:685: c-ify-string */
t7=*((C_word*)lf[72]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[3]))){
/* c-backend.scm:690: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[4];
av2[4]=lf[341];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=C_immp(((C_word*)t0)[3]);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_lambdainfop(((C_word*)t0)[3]));
if(C_truep(t5)){
t6=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_fixnump(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_5761(t8,t6);}
else{
t8=C_immp(((C_word*)t0)[3]);
t9=t7;
f_5761(t9,C_i_not(t8));}}}}}}}}}

/* k6797 in a6772 in k6754 in emit-procedure-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6799(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,7))){C_save_and_reclaim((void *)f_6799,2,av);}
/* c-backend.scm:915: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[509];
av2[4]=((C_word*)t0)[3];
av2[5]=C_make_character(58);
av2[6]=t1;
av2[7]=lf[510];
((C_proc)(void*)(*((C_word*)t2+1)))(8,av2);}}

/* k8436 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8438(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8438,2,av);}
/* c-backend.scm:1179: foreign-type-declaration */
t2=*((C_word*)lf[190]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3348 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3350(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_3350,2,av);}
/* c-backend.scm:220: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[90];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[91];
av2[5]=t1;
av2[6]=lf[92];
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* k8039 in k7997 in k7991 in k7988 in k7985 in k7982 in generate-foreign-callback-header in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8041(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,9))){C_save_and_reclaim((void *)f_8041,2,av);}
/* c-backend.scm:1120: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 10) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(10);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[3];
av2[4]=C_make_character(32);
av2[5]=t1;
av2[6]=((C_word*)t0)[4];
av2[7]=C_make_character(32);
av2[8]=((C_word*)t0)[5];
av2[9]=C_make_character(40);
((C_proc)(void*)(*((C_word*)t2+1)))(10,av2);}}

/* err in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8045(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_8045,2,t0,t1);}
/* c-backend.scm:1132: quit */
t2=*((C_word*)lf[646]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[647];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##compiler#foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8043(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_8043,4,av);}
a=C_alloc(14);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8045,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8050,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=C_eqp(t6,lf[614]);
if(C_truep(t7)){
/* c-backend.scm:1135: str */
t8=t5;
f_8050(t8,t1,lf[649]);}
else{
t8=C_eqp(t6,lf[15]);
t9=(C_truep(t8)?t8:C_eqp(t6,lf[618]));
if(C_truep(t9)){
/* c-backend.scm:1136: str */
t10=t5;
f_8050(t10,t1,lf[650]);}
else{
t10=C_eqp(t6,lf[615]);
t11=(C_truep(t10)?t10:C_eqp(t6,lf[619]));
if(C_truep(t11)){
/* c-backend.scm:1137: str */
t12=t5;
f_8050(t12,t1,lf[651]);}
else{
t12=C_eqp(t6,lf[616]);
t13=(C_truep(t12)?t12:C_eqp(t6,lf[599]));
if(C_truep(t13)){
/* c-backend.scm:1138: str */
t14=t5;
f_8050(t14,t1,lf[652]);}
else{
t14=C_eqp(t6,lf[617]);
t15=(C_truep(t14)?t14:C_eqp(t6,lf[600]));
if(C_truep(t15)){
/* c-backend.scm:1139: str */
t16=t5;
f_8050(t16,t1,lf[653]);}
else{
t16=C_eqp(t6,lf[435]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8120,a[2]=t5,a[3]=t1,a[4]=t6,a[5]=t3,a[6]=t2,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_8120(t18,t16);}
else{
t18=C_eqp(t6,lf[602]);
t19=t17;
f_8120(t19,(C_truep(t18)?t18:C_eqp(t6,lf[12])));}}}}}}}

/* k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8444(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_8444,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8455,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1182: string-append */
t5=*((C_word*)lf[114]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[697];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8461,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[7],C_fix(2)))){
t3=C_i_car(((C_word*)t0)[2]);
t4=t2;
f_8461(t4,C_eqp(lf[726],t3));}
else{
t3=t2;
f_8461(t3,C_SCHEME_FALSE);}}}

/* k5803 in gen-lit in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5805(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5805,2,av);}
t2=((C_word*)t0)[2];
f_5672(t2,C_i_not(t1));}

/* k5654 in loop in k5603 in k5585 in k5478 in literal-size in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5656(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_5656,2,av);}
a=C_alloc(4);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],t1);
/* c-backend.scm:669: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5634(t3,((C_word*)t0)[4],((C_word*)t0)[5],t2);}

/* gen-string-constant in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5807(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_5807,3,t0,t1,t2);}
a=C_alloc(7);
t3=C_block_size(t2);
t4=t3;
t5=C_fixnum_divide(t4,C_fix(80));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5817,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:702: modulo */
t8=*((C_word*)lf[346]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=t7;
av2[2]=t4;
av2[3]=C_fix(80);
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* str in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8050(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_8050,3,t0,t1,t2);}
/* c-backend.scm:1133: string-append */
t3=*((C_word*)lf[114]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[648];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k8453 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8455(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8455,2,av);}
/* c-backend.scm:1182: foreign-type-declaration */
t2=*((C_word*)lf[190]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3352 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3354(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3354,2,av);}
/* c-backend.scm:221: uncommentify */
t2=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* gen-lit in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5665(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_5665,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5672,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5805,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:674: big-fixnum? */
t6=*((C_word*)lf[345]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=t4;
f_5672(t5,C_SCHEME_FALSE);}}

/* k10008 in k10005 in k10002 in k9996 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10010(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10010,2,av);}
/* c-backend.scm:1318: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4107 in k4074 in k4126 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4109(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4109,2,av);}
t2=C_i_not(((C_word*)t0)[2]);
if(C_truep(t2)){
if(C_truep(t2)){
/* c-backend.scm:369: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
f_4079(2,av2);}}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm:369: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
f_4079(2,av2);}}}}

/* k8594 in k8587 in k8570 in k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8596(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_8596,2,av);}
/* c-backend.scm:1200: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[709];
av2[3]=t1;
av2[4]=lf[710];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k5726 in k5676 in k5670 in gen-lit in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5728(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_5728,2,av);}
a=C_alloc(6);
t2=t1;
t3=C_block_size(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5734,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:687: gen */
t6=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[4];
av2[4]=lf[340];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10029 in k10026 in k10020 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10031(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_10031,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1319: ##sys#write-char-0 */
t3=*((C_word*)lf[317]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(44);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k10032 in k10029 in k10026 in k10020 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10034(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10034,2,av);}
/* c-backend.scm:1319: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3327 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3329(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_3329,2,av);}
/* c-backend.scm:215: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[87];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[88];
av2[5]=t1;
av2[6]=lf[89];
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* k10005 in k10002 in k9996 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10007(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_10007,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1318: ##sys#write-char-0 */
t3=*((C_word*)lf[317]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(44);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k8560 in k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_8562,2,av);}
/* c-backend.scm:1196: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[705];
av2[3]=t1;
av2[4]=lf[706];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k10002 in k9996 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10004(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10004,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1318: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k8570 in k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8572(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_8572,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1198: ->string */
t4=*((C_word*)lf[490]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[6],C_fix(2));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=t2;
f_8589(t5,C_eqp(lf[723],t4));}
else{
t4=t2;
f_8589(t4,C_SCHEME_FALSE);}}}

/* k8577 in k8570 in k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8579(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_8579,2,av);}
/* c-backend.scm:1198: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[707];
av2[3]=t1;
av2[4]=lf[708];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8427(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_8427,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8438,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1179: string-append */
t5=*((C_word*)lf[114]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[696];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_eqp(C_fix(2),((C_word*)t0)[7]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[2]);
t5=t2;
f_8444(t5,C_eqp(lf[580],t4));}
else{
t4=t2;
f_8444(t4,C_SCHEME_FALSE);}}}

/* k10026 in k10020 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10028(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10028,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1319: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10020 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10022(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_10022,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10028,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1319: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[807];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5949(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_5949,2,t0,t1);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:727: ##sys#hash-table-for-each */
t3=*((C_word*)lf[302]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* for-each-loop1181 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in ... */
static void C_fcall f_7219(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_7219,5,t0,t1,t2,t3,t4);}
a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7226,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(t2))){
t6=C_i_pairp(t3);
t7=t5;
f_7226(t7,(C_truep(t6)?C_i_pairp(t4):C_SCHEME_FALSE));}
else{
t6=t5;
f_7226(t6,C_SCHEME_FALSE);}}

/* a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5955(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_5955,4,av);}
a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5959,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:729: lambda-literal-argument-count */
t5=*((C_word*)lf[301]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5959(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_5959,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5962,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:730: real-name */
t4=*((C_word*)lf[470]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[10];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* doloop639 in k4993 in k4990 in k4987 in k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5000(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_5000,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5010,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
/* c-backend.scm:559: ##sys#lambda-info->string */
t6=*((C_word*)lf[269]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* a6737 in k6642 in emit-debug-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6738(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6738,4,av);}
t4=C_i_car(t2);
t5=C_i_car(t3);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_i_lessp(t4,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k7199 in k7161 in k7158 in k7128 in k7125 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in ... */
static void C_ccall f_7201(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7201,2,av);}
/* c-backend.scm:1044: intersperse */
t2=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6766 in k6763 in k6760 in k6757 in k6754 in emit-procedure-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6768(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,14))){C_save_and_reclaim((void *)f_6768,2,av);}
/* c-backend.scm:925: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 15) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(15);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[495];
av2[3]=C_SCHEME_TRUE;
av2[4]=lf[496];
av2[5]=C_SCHEME_TRUE;
av2[6]=lf[497];
av2[7]=C_SCHEME_TRUE;
av2[8]=lf[498];
av2[9]=C_SCHEME_TRUE;
av2[10]=lf[499];
av2[11]=C_SCHEME_TRUE;
av2[12]=lf[500];
av2[13]=C_SCHEME_TRUE;
av2[14]=lf[501];
((C_proc)(void*)(*((C_word*)t2+1)))(15,av2);}}

/* k8587 in k8570 in k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_8589,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1200: ->string */
t4=*((C_word*)lf[490]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[6],C_fix(3));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=t2;
f_8606(t5,C_u_i_memq(t4,lf[722]));}
else{
t4=t2;
f_8606(t4,C_SCHEME_FALSE);}}}

/* k6763 in k6760 in k6757 in k6754 in emit-procedure-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_6765,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6768,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:924: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=C_SCHEME_TRUE;
av2[4]=lf[502];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6760 in k6757 in k6754 in emit-procedure-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6762(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_6762,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6765,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:923: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[503];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6757 in k6754 in emit-procedure-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6759(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_6759,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6762,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:922: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[504];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5989(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,3))){C_save_and_reclaim((void *)f_5989,2,av);}
a=C_alloc(19);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t2,a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
if(C_truep(((C_word*)t0)[16])){
t4=C_i_cdr(((C_word*)t0)[18]);
/* c-backend.scm:740: intersperse */
t5=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
/* c-backend.scm:740: intersperse */
t4=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[18];
av2[3]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5986(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,3))){C_save_and_reclaim((void *)f_5986,2,av);}
a=C_alloc(19);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=t2,tmp=(C_word)a,a+=19,tmp);
if(C_truep(((C_word*)t0)[16])){
t4=C_i_cdr(((C_word*)t0)[18]);
/* c-backend.scm:739: intersperse */
t5=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
/* c-backend.scm:739: intersperse */
t4=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[18];
av2[3]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,3))){C_save_and_reclaim((void *)f_5983,2,av);}
a=C_alloc(19);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=t2,tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm:738: make-argument-list */
t4=*((C_word*)lf[304]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
av2[3]=lf[466];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2608(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word *a;
if(!C_demand(C_calculate_demand(81,c,5))){C_save_and_reclaim((void *)f_2608,2,av);}
a=C_alloc(81);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));
t27=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t28=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp));
t29=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4971,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp));
t30=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5143,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));
t31=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5308,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));
t32=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5417,a[2]=t19,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp));
t33=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5473,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t34=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5665,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t35=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5807,a[2]=t23,tmp=(C_word)a,a+=3,tmp));
t36=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5883,tmp=(C_word)a,a+=2,tmp));
t37=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5949,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=t15,a[6]=t17,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp));
t38=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6597,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=t25,a[7]=((C_word*)t0)[10],a[8]=t13,a[9]=((C_word*)t0)[7],a[10]=t11,a[11]=t9,a[12]=t7,tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm:876: debugging */
t39=*((C_word*)lf[459]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t39;
av2[1]=t38;
av2[2]=lf[482];
av2[3]=lf[483];
((C_proc)(void*)(*((C_word*)t39+1)))(4,av2);}}

/* k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2602(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_demand(C_calculate_demand(30,c,10))){C_save_and_reclaim((void *)f_2602,2,av);}
a=C_alloc(30);
t2=C_mutate2((C_word*)lf[6]+1 /* (set! ##compiler#unique-id ...) */,t1);
t3=C_mutate2((C_word*)lf[7]+1 /* (set! ##compiler#generate-code ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2604,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate2((C_word*)lf[476]+1 /* (set! emit-debug-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6640,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate2((C_word*)lf[475]+1 /* (set! emit-procedure-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6752,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2((C_word*)lf[458]+1 /* (set! ##compiler#cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6809,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate2((C_word*)lf[299]+1 /* (set! ##compiler#make-variable-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6893,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate2((C_word*)lf[304]+1 /* (set! ##compiler#make-argument-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6909,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate2((C_word*)lf[480]+1 /* (set! ##compiler#generate-external-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6925,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate2((C_word*)lf[239]+1 /* (set! ##compiler#generate-foreign-callback-stub-prototypes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6982,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate2((C_word*)lf[478]+1 /* (set! ##compiler#generate-foreign-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7025,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate2((C_word*)lf[477]+1 /* (set! generate-foreign-callback-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7362,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2((C_word*)lf[521]+1 /* (set! ##compiler#generate-foreign-callback-header ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7980,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate2((C_word*)lf[190]+1 /* (set! ##compiler#foreign-type-declaration ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8043,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2((C_word*)lf[189]+1 /* (set! ##compiler#foreign-argument-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9094,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate2((C_word*)lf[184]+1 /* (set! ##compiler#foreign-result-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9725,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate2((C_word*)lf[343]+1 /* (set! ##compiler#encode-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10510,tmp=(C_word)a,a+=2,tmp));
t18=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t18;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}

/* ##compiler#generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8=av[8];
C_word t9=av[9];
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,2))){C_save_and_reclaim((void *)f_2604,10,av);}
a=C_alloc(17);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2608,a[2]=t4,a[3]=t11,a[4]=t6,a[5]=t2,a[6]=t3,a[7]=t8,a[8]=t5,a[9]=t1,a[10]=t9,tmp=(C_word)a,a+=11,tmp);
t13=C_a_i_plus(&a,2,*((C_word*)lf[484]+1),C_fix(1));
/* c-backend.scm:67: flonum-print-precision */
t14=*((C_word*)lf[485]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
((C_proc)(void*)(*((C_word*)t14+1)))(3,av2);}}

/* k6754 in emit-procedure-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6756(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_6756,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6759,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6773,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:913: ##sys#hash-table-for-each */
t4=*((C_word*)lf[302]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* emit-procedure-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6752(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_6752,4,av);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6756,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6807,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:912: ##sys#hash-table-size */
t6=*((C_word*)lf[515]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k6723 in for-each-loop1012 in k6702 in k6642 in emit-debug-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6725,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6715(t3,((C_word*)t0)[4],t2);}

/* k3784 in k3756 in k3753 in k3750 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3786(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3786,2,av);}
/* c-backend.scm:324: push-args */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4661(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,2))){C_save_and_reclaim((void *)f_5992,2,av);}
a=C_alloc(20);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_5995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm:741: lambda-literal-external */
t4=*((C_word*)lf[465]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5998(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,2))){C_save_and_reclaim((void *)f_5998,2,av);}
a=C_alloc(22);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_6001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=t2,a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm:743: lambda-literal-direct */
t4=*((C_word*)lf[235]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5995(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,2))){C_save_and_reclaim((void *)f_5995,2,av);}
a=C_alloc(21);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=t2,a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm:742: lambda-literal-looping */
t4=*((C_word*)lf[107]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2612 in find-lambda in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2614(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2614,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* c-backend.scm:73: bomb */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[9];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* find-lambda in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_2610(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_2610,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2614,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:72: ##sys#hash-table-ref */
t4=*((C_word*)lf[10]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* for-each-loop1012 in k6702 in k6642 in emit-debug-table in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_6715(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,5))){
C_save_and_reclaim_args((void *)trf_6715,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6725,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6649,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_i_cadr(t6);
/* c-backend.scm:898: gen */
t9=*((C_word*)lf[1]+1);{
C_word av2[6];
av2[0]=t9;
av2[1]=t7;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[491];
av2[4]=t8;
av2[5]=lf[492];
((C_proc)(void*)(*((C_word*)t9+1)))(6,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6708 in k6702 in k6642 in emit-debug-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6710(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6710,2,av);}
/* c-backend.scm:905: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[486];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* doloop650 in k5017 in k5014 in k5008 in doloop639 in k4993 in k4990 in k4987 in k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5040(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_5040,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_zerop(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5050,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:571: gen */
t4=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[266];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_2625(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word *a;
if(!C_demand(C_calculate_demand(24,0,6))){
C_save_and_reclaim_args((void *)trf_2625,4,t0,t1,t2,t3);}
a=C_alloc(24);
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=C_eqp(t11,lf[11]);
if(C_truep(t12)){
t13=C_i_car(t9);
t14=C_eqp(t13,lf[12]);
if(C_truep(t14)){
if(C_truep(C_i_cadr(t9))){
/* c-backend.scm:85: gen */
t15=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t15;
av2[1]=t1;
av2[2]=lf[13];
((C_proc)(void*)(*((C_word*)t15+1)))(3,av2);}}
else{
/* c-backend.scm:85: gen */
t15=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t15;
av2[1]=t1;
av2[2]=lf[14];
((C_proc)(void*)(*((C_word*)t15+1)))(3,av2);}}}
else{
t15=C_eqp(t13,lf[15]);
if(C_truep(t15)){
t16=C_i_cadr(t9);
t17=C_fix(C_character_code(t16));
/* c-backend.scm:86: gen */
t18=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t18;
av2[1]=t1;
av2[2]=lf[16];
av2[3]=t17;
av2[4]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t18+1)))(5,av2);}}
else{
t16=C_eqp(t13,lf[17]);
if(C_truep(t16)){
/* c-backend.scm:87: gen */
t17=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t17;
av2[1]=t1;
av2[2]=lf[18];
((C_proc)(void*)(*((C_word*)t17+1)))(3,av2);}}
else{
t17=C_eqp(t13,lf[19]);
if(C_truep(t17)){
t18=C_i_cadr(t9);
/* c-backend.scm:88: gen */
t19=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t19;
av2[1]=t1;
av2[2]=lf[20];
av2[3]=t18;
av2[4]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t19+1)))(5,av2);}}
else{
t18=C_eqp(t13,lf[21]);
if(C_truep(t18)){
/* c-backend.scm:89: gen */
t19=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t19;
av2[1]=t1;
av2[2]=lf[22];
((C_proc)(void*)(*((C_word*)t19+1)))(3,av2);}}
else{
/* c-backend.scm:90: bomb */
t19=*((C_word*)lf[8]+1);{
C_word av2[3];
av2[0]=t19;
av2[1]=t1;
av2[2]=lf[23];
((C_proc)(void*)(*((C_word*)t19+1)))(3,av2);}}}}}}}
else{
t13=C_eqp(t11,lf[24]);
if(C_truep(t13)){
t14=C_i_car(t9);
if(C_truep(C_i_vectorp(t14))){
t15=C_i_vector_ref(t14,C_fix(0));
/* c-backend.scm:95: gen */
t16=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t16;
av2[1]=t1;
av2[2]=lf[25];
av2[3]=t15;
av2[4]=lf[26];
((C_proc)(void*)(*((C_word*)t16+1)))(5,av2);}}
else{
t15=C_u_i_car(t9);
/* c-backend.scm:96: gen */
t16=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t16;
av2[1]=t1;
av2[2]=lf[27];
av2[3]=t15;
av2[4]=C_make_character(93);
((C_proc)(void*)(*((C_word*)t16+1)))(5,av2);}}}
else{
t14=C_eqp(t11,lf[28]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2772,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:99: gen */
t16=*((C_word*)lf[1]+1);{
C_word av2[4];
av2[0]=t16;
av2[1]=t15;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[31];
((C_proc)(void*)(*((C_word*)t16+1)))(4,av2);}}
else{
t15=C_eqp(t11,lf[32]);
if(C_truep(t15)){
t16=C_i_car(t9);
/* c-backend.scm:108: gen */
t17=*((C_word*)lf[1]+1);{
C_word av2[4];
av2[0]=t17;
av2[1]=t1;
av2[2]=lf[33];
av2[3]=t16;
((C_proc)(void*)(*((C_word*)t17+1)))(4,av2);}}
else{
t16=C_eqp(t11,lf[34]);
if(C_truep(t16)){
t17=C_i_car(t9);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2830,a[2]=t19,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t21=((C_word*)t19)[1];
f_2830(t21,t1,t6,t3,t17);}
else{
t17=C_eqp(t11,lf[35]);
if(C_truep(t17)){
t18=C_i_car(t9);
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2882,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:121: gen */
t20=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t20;
av2[1]=t19;
av2[2]=C_SCHEME_TRUE;
av2[3]=t18;
av2[4]=C_make_character(61);
((C_proc)(void*)(*((C_word*)t20+1)))(5,av2);}}
else{
t18=C_eqp(t11,lf[36]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2908,a[2]=t9,a[3]=t1,a[4]=t6,a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:127: gen */
t20=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t20;
av2[1]=t19;
av2[2]=lf[38];
((C_proc)(void*)(*((C_word*)t20+1)))(3,av2);}}
else{
t19=C_eqp(t11,lf[39]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2935,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:132: gen */
t21=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t21;
av2[1]=t20;
av2[2]=lf[41];
((C_proc)(void*)(*((C_word*)t21+1)))(3,av2);}}
else{
t20=C_eqp(t11,lf[42]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2954,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:137: gen */
t22=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t22;
av2[1]=t21;
av2[2]=lf[43];
((C_proc)(void*)(*((C_word*)t22+1)))(3,av2);}}
else{
t21=C_eqp(t11,lf[44]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2987,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:144: gen */
t23=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t23;
av2[1]=t22;
av2[2]=lf[47];
((C_proc)(void*)(*((C_word*)t23+1)))(3,av2);}}
else{
t22=C_eqp(t11,lf[48]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3024,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:151: gen */
t24=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t24;
av2[1]=t23;
av2[2]=lf[50];
((C_proc)(void*)(*((C_word*)t24+1)))(3,av2);}}
else{
t23=C_eqp(t11,lf[51]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3053,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:158: gen */
t25=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t25;
av2[1]=t24;
av2[2]=lf[53];
((C_proc)(void*)(*((C_word*)t25+1)))(3,av2);}}
else{
t24=C_eqp(t11,lf[54]);
if(C_truep(t24)){
t25=C_i_car(t9);
t26=t25;
t27=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3085,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t6,a[5]=t26,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:166: gen */
t28=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t28;
av2[1]=t27;
av2[2]=lf[61];
av2[3]=t26;
av2[4]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t28+1)))(5,av2);}}
else{
t25=C_eqp(t11,lf[62]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3158,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:176: gen */
t27=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t27;
av2[1]=t26;
av2[2]=lf[64];
((C_proc)(void*)(*((C_word*)t27+1)))(3,av2);}}
else{
t26=C_eqp(t11,lf[65]);
if(C_truep(t26)){
t27=C_i_car(t9);
/* c-backend.scm:180: gen */
t28=*((C_word*)lf[1]+1);{
C_word av2[4];
av2[0]=t28;
av2[1]=t1;
av2[2]=C_make_character(116);
av2[3]=t27;
((C_proc)(void*)(*((C_word*)t28+1)))(4,av2);}}
else{
t27=C_eqp(t11,lf[66]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3190,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t29=C_i_car(t9);
/* c-backend.scm:183: gen */
t30=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t30;
av2[1]=t28;
av2[2]=C_make_character(116);
av2[3]=t29;
av2[4]=C_make_character(61);
((C_proc)(void*)(*((C_word*)t30+1)))(5,av2);}}
else{
t28=C_eqp(t11,lf[67]);
if(C_truep(t28)){
t29=C_i_car(t9);
t30=t29;
t31=C_i_cadr(t9);
if(C_truep(C_i_caddr(t9))){
if(C_truep(t31)){
/* c-backend.scm:192: gen */
t32=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t32;
av2[1]=t1;
av2[2]=lf[68];
av2[3]=t30;
av2[4]=lf[69];
((C_proc)(void*)(*((C_word*)t32+1)))(5,av2);}}
else{
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3232,a[2]=t1,a[3]=t30,tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3236,a[2]=t32,tmp=(C_word)a,a+=3,tmp);
t34=C_i_cadddr(t9);
/* c-backend.scm:194: ##sys#symbol->qualified-string */
t35=*((C_word*)lf[73]+1);{
C_word av2[3];
av2[0]=t35;
av2[1]=t33;
av2[2]=t34;
((C_proc)(void*)(*((C_word*)t35+1)))(3,av2);}}}
else{
if(C_truep(t31)){
/* c-backend.scm:196: gen */
t32=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t32;
av2[1]=t1;
av2[2]=lf[74];
av2[3]=t30;
av2[4]=lf[75];
((C_proc)(void*)(*((C_word*)t32+1)))(5,av2);}}
else{
/* c-backend.scm:197: gen */
t32=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t32;
av2[1]=t1;
av2[2]=lf[76];
av2[3]=t30;
av2[4]=lf[77];
((C_proc)(void*)(*((C_word*)t32+1)))(5,av2);}}}}
else{
t29=C_eqp(t11,lf[78]);
if(C_truep(t29)){
t30=C_i_car(t9);
t31=C_i_cadr(t9);
t32=C_i_caddr(t9);
t33=t32;
t34=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3267,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t33,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t31)){
/* c-backend.scm:204: gen */
t35=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t35;
av2[1]=t34;
av2[2]=lf[82];
av2[3]=t30;
av2[4]=lf[83];
((C_proc)(void*)(*((C_word*)t35+1)))(5,av2);}}
else{
/* c-backend.scm:205: gen */
t35=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t35;
av2[1]=t34;
av2[2]=lf[84];
av2[3]=t30;
av2[4]=lf[85];
((C_proc)(void*)(*((C_word*)t35+1)))(5,av2);}}}
else{
t30=C_eqp(t11,lf[86]);
if(C_truep(t30)){
t31=C_i_car(t9);
t32=t31;
t33=C_i_cadr(t9);
t34=C_i_caddr(t9);
if(C_truep(t33)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3315,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t36=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3329,a[2]=t35,a[3]=t32,tmp=(C_word)a,a+=4,tmp);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3333,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:216: ##sys#symbol->qualified-string */
t38=*((C_word*)lf[73]+1);{
C_word av2[3];
av2[0]=t38;
av2[1]=t37;
av2[2]=t34;
((C_proc)(void*)(*((C_word*)t38+1)))(3,av2);}}
else{
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3336,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t36=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3350,a[2]=t35,a[3]=t32,tmp=(C_word)a,a+=4,tmp);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3354,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:221: ##sys#symbol->qualified-string */
t38=*((C_word*)lf[73]+1);{
C_word av2[3];
av2[0]=t38;
av2[1]=t37;
av2[2]=t34;
((C_proc)(void*)(*((C_word*)t38+1)))(3,av2);}}}
else{
t31=C_eqp(t11,lf[93]);
if(C_truep(t31)){
/* c-backend.scm:225: gen */
t32=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t32;
av2[1]=t1;
av2[2]=lf[94];
((C_proc)(void*)(*((C_word*)t32+1)))(3,av2);}}
else{
t32=C_eqp(t11,lf[95]);
if(C_truep(t32)){
t33=C_i_cdr(t6);
t34=t33;
t35=C_i_length(t34);
t36=t35;
t37=t3;
t38=C_a_i_plus(&a,2,t36,C_fix(1));
t39=t38;
t40=C_i_car(t9);
t41=t40;
t42=C_i_cadr(t9);
t43=t42;
t44=C_u_i_cdr(t9);
t45=C_u_i_cdr(t44);
t46=C_i_pairp(t45);
t47=t46;
t48=(C_truep(t47)?C_i_caddr(t9):C_SCHEME_FALSE);
t49=t48;
t50=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_3393,a[2]=t6,a[3]=t1,a[4]=t39,a[5]=((C_word*)t0)[3],a[6]=t34,a[7]=t3,a[8]=((C_word*)t0)[2],a[9]=t36,a[10]=((C_word*)t0)[4],a[11]=((C_word*)t0)[5],a[12]=t37,a[13]=t43,a[14]=t49,a[15]=t41,a[16]=((C_word*)t0)[6],a[17]=((C_word*)t0)[7],a[18]=t9,a[19]=t47,tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm:236: source-info->string */
t51=*((C_word*)lf[159]+1);{
C_word av2[3];
av2[0]=t51;
av2[1]=t50;
av2[2]=t49;
((C_proc)(void*)(*((C_word*)t51+1)))(3,av2);}}
else{
t33=C_eqp(t11,lf[160]);
if(C_truep(t33)){
t34=C_i_length(t6);
t35=t34;
t36=C_a_i_plus(&a,2,t35,C_fix(1));
t37=t36;
t38=C_i_car(t9);
t39=t38;
t40=C_i_cadr(t9);
t41=t40;
t42=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4045,a[2]=t39,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t35,a[7]=t6,a[8]=t37,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t41,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:336: lambda-literal-closure-size */
t43=*((C_word*)lf[157]+1);{
C_word av2[3];
av2[0]=t43;
av2[1]=t42;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t43+1)))(3,av2);}}
else{
t34=C_eqp(t11,lf[164]);
if(C_truep(t34)){
t35=C_i_cdr(t6);
t36=t35;
t37=C_i_length(t36);
t38=C_a_i_plus(&a,2,t37,C_fix(1));
t39=C_i_caddr(t9);
t40=t39;
t41=C_i_cadddr(t9);
t42=t41;
t43=C_i_zerop(t42);
t44=C_i_not(t43);
t45=t44;
t46=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4128,a[2]=t6,a[3]=t1,a[4]=t36,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t45,a[9]=t42,a[10]=t40,tmp=(C_word)a,a+=11,tmp);
t47=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4132,a[2]=t46,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:364: find-lambda */
t48=((C_word*)((C_word*)t0)[7])[1];
f_2610(t48,t47,t40);}
else{
t35=C_eqp(t11,lf[166]);
if(C_truep(t35)){
t36=C_i_length(t6);
t37=C_a_i_plus(&a,2,t36,C_fix(1));
t38=t37;
t39=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4151,a[2]=t9,a[3]=t1,a[4]=t38,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:381: gen */
t40=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t40;
av2[1]=t39;
av2[2]=C_make_character(123);
((C_proc)(void*)(*((C_word*)t40+1)))(3,av2);}}
else{
t36=C_eqp(t11,lf[171]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4170,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:386: gen */
t38=*((C_word*)lf[1]+1);{
C_word av2[4];
av2[0]=t38;
av2[1]=t37;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[173];
((C_proc)(void*)(*((C_word*)t38+1)))(4,av2);}}
else{
t37=C_eqp(t11,lf[174]);
if(C_truep(t37)){
t38=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4189,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t39=C_i_car(t9);
/* c-backend.scm:391: gen */
t40=*((C_word*)lf[1]+1);{
C_word av2[4];
av2[0]=t40;
av2[1]=t38;
av2[2]=t39;
av2[3]=C_make_character(40);
((C_proc)(void*)(*((C_word*)t40+1)))(4,av2);}}
else{
t38=C_eqp(t11,lf[175]);
if(C_truep(t38)){
t39=C_i_car(t9);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
/* c-backend.scm:396: gen */
t40=*((C_word*)lf[1]+1);{
C_word av2[7];
av2[0]=t40;
av2[1]=t1;
av2[2]=lf[176];
av2[3]=t39;
av2[4]=lf[177];
av2[5]=lf[178];
av2[6]=lf[179];
((C_proc)(void*)(*((C_word*)t40+1)))(7,av2);}}
else{
/* c-backend.scm:396: gen */
t40=*((C_word*)lf[1]+1);{
C_word av2[7];
av2[0]=t40;
av2[1]=t1;
av2[2]=lf[176];
av2[3]=t39;
av2[4]=lf[177];
av2[5]=lf[180];
av2[6]=lf[179];
((C_proc)(void*)(*((C_word*)t40+1)))(7,av2);}}}
else{
t39=C_eqp(t11,lf[181]);
if(C_truep(t39)){
t40=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4225,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t41=C_i_car(t9);
t42=C_i_length(t6);
/* c-backend.scm:400: gen */
t43=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t43;
av2[1]=t40;
av2[2]=t41;
av2[3]=lf[182];
av2[4]=t42;
((C_proc)(void*)(*((C_word*)t43+1)))(5,av2);}}
else{
t40=C_eqp(t11,lf[183]);
if(C_truep(t40)){
t41=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4261,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t42=C_i_cadr(t9);
/* c-backend.scm:408: foreign-result-conversion */
t43=*((C_word*)lf[184]+1);{
C_word av2[4];
av2[0]=t43;
av2[1]=t41;
av2[2]=t42;
av2[3]=lf[185];
((C_proc)(void*)(*((C_word*)t43+1)))(4,av2);}}
else{
t41=C_eqp(t11,lf[186]);
if(C_truep(t41)){
t42=C_i_cadr(t9);
t43=t42;
t44=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4279,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t45=C_u_i_car(t9);
t46=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4295,a[2]=t44,a[3]=t45,a[4]=t43,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:412: foreign-type-declaration */
t47=*((C_word*)lf[190]+1);{
C_word av2[4];
av2[0]=t47;
av2[1]=t46;
av2[2]=t43;
av2[3]=lf[191];
((C_proc)(void*)(*((C_word*)t47+1)))(4,av2);}}
else{
t42=C_eqp(t11,lf[192]);
if(C_truep(t42)){
t43=C_i_car(t9);
t44=t43;
t45=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4311,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t46=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4325,a[2]=t45,a[3]=t44,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:418: foreign-result-conversion */
t47=*((C_word*)lf[184]+1);{
C_word av2[4];
av2[0]=t47;
av2[1]=t46;
av2[2]=t44;
av2[3]=lf[197];
((C_proc)(void*)(*((C_word*)t47+1)))(4,av2);}}
else{
t43=C_eqp(t11,lf[198]);
if(C_truep(t43)){
t44=C_i_car(t9);
t45=t44;
t46=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4341,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t45,tmp=(C_word)a,a+=7,tmp);
t47=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4369,a[2]=t46,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:424: foreign-type-declaration */
t48=*((C_word*)lf[190]+1);{
C_word av2[4];
av2[0]=t48;
av2[1]=t47;
av2[2]=t45;
av2[3]=lf[203];
((C_proc)(void*)(*((C_word*)t48+1)))(4,av2);}}
else{
t44=C_eqp(t11,lf[204]);
if(C_truep(t44)){
t45=C_i_car(t9);
/* c-backend.scm:431: gen */
t46=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t46;
av2[1]=t1;
av2[2]=t45;
((C_proc)(void*)(*((C_word*)t46+1)))(3,av2);}}
else{
t45=C_eqp(t11,lf[205]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4391,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t47=C_i_car(t9);
/* c-backend.scm:434: gen */
t48=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t48;
av2[1]=t46;
av2[2]=lf[207];
av2[3]=t47;
av2[4]=C_make_character(61);
((C_proc)(void*)(*((C_word*)t48+1)))(5,av2);}}
else{
t46=C_eqp(t11,lf[208]);
if(C_truep(t46)){
t47=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4414,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t48=C_i_car(t9);
/* c-backend.scm:439: gen */
t49=*((C_word*)lf[1]+1);{
C_word av2[4];
av2[0]=t49;
av2[1]=t47;
av2[2]=t48;
av2[3]=lf[209];
((C_proc)(void*)(*((C_word*)t49+1)))(4,av2);}}
else{
t47=C_eqp(t11,lf[210]);
if(C_truep(t47)){
t48=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4433,a[2]=t9,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:444: gen */
t49=*((C_word*)lf[1]+1);{
C_word av2[4];
av2[0]=t49;
av2[1]=t48;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[214];
((C_proc)(void*)(*((C_word*)t49+1)))(4,av2);}}
else{
t48=C_eqp(t11,lf[215]);
if(C_truep(t48)){
t49=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4514,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:459: gen */
t50=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t50;
av2[1]=t49;
av2[2]=lf[217];
((C_proc)(void*)(*((C_word*)t50+1)))(3,av2);}}
else{
t49=t2;
t50=C_slot(t49,C_fix(1));
/* c-backend.scm:467: bomb */
t51=*((C_word*)lf[8]+1);{
C_word av2[4];
av2[0]=t51;
av2[1]=t1;
av2[2]=lf[218];
av2[3]=t50;
((C_proc)(void*)(*((C_word*)t51+1)))(4,av2);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_2622(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(21,0,5))){
C_save_and_reclaim_args((void *)trf_2622,5,t0,t1,t2,t3,t4);}
a=C_alloc(21);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2625,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=t8,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp));
t12=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4632,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4661,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
/* c-backend.scm:501: expr */
t14=((C_word*)t6)[1];
f_2625(t14,t1,t2,t3);}

/* a6772 in k6754 in emit-procedure-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6773(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_6773,4,av);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6777,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6799,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:915: string->c-identifier */
t6=*((C_word*)lf[511]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k6775 in a6772 in k6754 in emit-procedure-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6777(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6777,2,av);}
t2=C_eqp(lf[282],((C_word*)t0)[2]);
if(C_truep(t2)){
if(C_truep(*((C_word*)lf[246]+1))){
/* c-backend.scm:918: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[505];
av2[3]=*((C_word*)lf[246]+1);
av2[4]=lf[506];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
/* c-backend.scm:919: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[507];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
/* c-backend.scm:920: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
av2[3]=lf[508];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k5017 in k5014 in k5008 in doloop639 in k4993 in k4990 in k4987 in k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5019(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,3))){C_save_and_reclaim((void *)f_5019,2,av);}
a=C_alloc(23);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(7));
t4=C_a_i_bitwise_and(&a,2,C_fix(16777208),t3);
t5=C_a_i_minus(&a,2,t4,((C_word*)t0)[6]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5040,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_5040(t9,t2,t5);}

/* k5014 in k5008 in doloop639 in k4993 in k4990 in k4987 in k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5016(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_5016,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5067,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5067(t6,t2,C_fix(0));}

/* k5008 in doloop639 in k4993 in k4990 in k4987 in k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5010(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,11))){C_save_and_reclaim((void *)f_5010,2,av);}
a=C_alloc(20);
t2=t1;
t3=C_i_string_length(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=C_a_i_arithmetic_shift(&a,2,t4,C_fix(-16));
t7=C_a_i_arithmetic_shift(&a,2,t4,C_fix(-8));
t8=C_a_i_bitwise_and(&a,2,C_fix(255),t7);
t9=C_fixnum_and(C_fix(255),t4);
/* c-backend.scm:561: gen */
t10=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 12) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(12);
}
av2[0]=t10;
av2[1]=t5;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[267];
av2[4]=((C_word*)t0)[2];
av2[5]=lf[268];
av2[6]=t6;
av2[7]=C_make_character(44);
av2[8]=t8;
av2[9]=C_make_character(44);
av2[10]=t9;
av2[11]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t10+1)))(12,av2);}}

/* k3740 in k3657 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3742(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3742,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* c-backend.scm:316: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[129];
av2[3]=((C_word*)t0)[4];
av2[4]=lf[130];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3753 in k3750 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_3755,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:323: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[144];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5023 in k5020 in k5017 in k5014 in k5008 in doloop639 in k4993 in k4990 in k4987 in k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5025(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_5025,2,av);}
a=C_alloc(4);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=((C_word*)((C_word*)t0)[4])[1];
f_5000(t5,((C_word*)t0)[5],t2,t4);}

/* k3756 in k3753 in k3750 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_3758,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3786,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3791,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:324: number->string */
t5=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5020 in k5017 in k5014 in k5008 in doloop639 in k4993 in k4990 in k4987 in k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5022(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5022,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:572: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[265];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k9344 in k9149 in k9122 in foreign-argument-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_9346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_9346,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[771];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[577]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9355(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[591]);
if(C_truep(t4)){
t5=t3;
f_9355(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[592]);
if(C_truep(t5)){
t6=t3;
f_9355(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[593]);
t7=t3;
f_9355(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[3],lf[594])));}}}}}

/* k3771 in k3762 in k3759 in k3756 in k3753 in k3750 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_3773(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_3773,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:327: gen */
t2=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[137];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[138];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
/* c-backend.scm:328: gen */
t2=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[139];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[140];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}}

/* for-each-loop1255 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_7957(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_7957,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7967,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:1055: g1256 */
t5=((C_word*)t0)[3];
f_7364(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k3747 in k3657 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3749(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3749,2,av);}
/* c-backend.scm:315: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[131];
av2[3]=t1;
av2[4]=lf[132];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5075 in doloop645 in k5014 in k5008 in doloop639 in k4993 in k4990 in k4987 in k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5077,2,av);}
a=C_alloc(4);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5067(t3,((C_word*)t0)[4],t2);}

/* k3759 in k3756 in k3753 in k3750 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3761(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_3761,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:325: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[142];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k7965 in for-each-loop1255 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7967(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7967,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7957(t3,((C_word*)t0)[4],t2);}

/* ##compiler#generate-foreign-callback-header in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7980(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_7980,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7984,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1114: foreign-callback-stub-name */
t5=*((C_word*)lf[645]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3789 in k3756 in k3753 in k3750 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3791(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3791,2,av);}
/* ##sys#string-append */
t2=*((C_word*)lf[104]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[143];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5143(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_5143,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5147,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:575: gen */
t3=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5147(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(2,c,4))){C_save_and_reclaim((void *)f_5147,2,av);}
a=C_alloc(2);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5152,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm:576: ##sys#hash-table-for-each */
t3=*((C_word*)lf[302]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k7988 in k7985 in k7982 in generate-foreign-callback-header in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7990(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_7990,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:1117: foreign-callback-stub-argument-types */
t4=*((C_word*)lf[639]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3765 in k3762 in k3759 in k3756 in k3753 in k3750 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3767,2,av);}
/* c-backend.scm:329: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[134];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[135];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3762 in k3759 in k3756 in k3753 in k3750 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3764(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_3764,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[136]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3773,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(*((C_word*)lf[136]+1))){
t5=t4;
f_3773(t5,*((C_word*)lf[136]+1));}
else{
t5=*((C_word*)lf[141]+1);
if(C_truep(*((C_word*)lf[141]+1))){
t6=*((C_word*)lf[141]+1);
t7=t4;
f_3773(t7,*((C_word*)lf[141]+1));}
else{
t6=t4;
f_3773(t6,((C_word*)t0)[5]);}}}

/* k5048 in doloop650 in k5017 in k5014 in k5008 in doloop639 in k4993 in k4990 in k4987 in k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5050(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5050,2,av);}
a=C_alloc(4);
t2=C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5040(t3,((C_word*)t0)[4],t2);}

/* a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5152(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5152,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5156,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:578: lambda-literal-argument-count */
t5=*((C_word*)lf[301]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5156,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:579: lambda-literal-customizable */
t4=*((C_word*)lf[236]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7985 in k7982 in generate-foreign-callback-header in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7987(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_7987,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:1116: foreign-callback-stub-return-type */
t4=*((C_word*)lf[640]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5159(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_5159,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5162,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5306,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:580: lambda-literal-closure-size */
t5=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=t3;
f_5162(t4,C_SCHEME_FALSE);}}

/* k7982 in generate-foreign-callback-header in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7984(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_7984,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1115: foreign-callback-stub-qualifiers */
t4=*((C_word*)lf[644]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* doloop645 in k5014 in k5008 in doloop639 in k4993 in k4990 in k4987 in k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5067(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_5067,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_greater_or_equalp(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5077,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_string_ref(((C_word*)t0)[4],t2);
t5=C_fix(C_character_code(t4));
/* c-backend.scm:568: gen */
t6=*((C_word*)lf[1]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=C_make_character(44);
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}

/* k3159 in k3156 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3161(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3161,2,av);}
/* c-backend.scm:178: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[63];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7997 in k7991 in k7988 in k7985 in k7982 in generate-foreign-callback-header in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_7999,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8002,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8041,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1120: foreign-type-declaration */
t5=*((C_word*)lf[190]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[7];
av2[3]=lf[642];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k7010 in for-each-loop1120 in generate-foreign-callback-stub-prototypes in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7012,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7002(t3,((C_word*)t0)[4],t2);}

/* k7991 in k7988 in k7985 in k7982 in generate-foreign-callback-header in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7993(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_7993,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7999,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:1119: make-argument-list */
t5=*((C_word*)lf[304]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
av2[3]=lf[643];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* for-each-loop623 in k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5120(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,9))){
C_save_and_reclaim_args((void *)trf_5120,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5130,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:550: gen */
t5=*((C_word*)lf[1]+1);{
C_word av2[10];
av2[0]=t5;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[273];
av2[4]=t4;
av2[5]=lf[274];
av2[6]=C_SCHEME_TRUE;
av2[7]=lf[275];
av2[8]=t4;
av2[9]=lf[276];
((C_proc)(void*)(*((C_word*)t5+1)))(10,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7393 in compute-size in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_7395(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_7395,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[571]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7404,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_7404(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[598]);
if(C_truep(t4)){
t5=t3;
f_7404(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[583]);
if(C_truep(t5)){
t6=t3;
f_7404(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[599]);
if(C_truep(t6)){
t7=t3;
f_7404(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[600]);
if(C_truep(t7)){
t8=t3;
f_7404(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[601]);
if(C_truep(t8)){
t9=t3;
f_7404(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[602]);
if(C_truep(t9)){
t10=t3;
f_7404(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[603]);
if(C_truep(t10)){
t11=t3;
f_7404(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[604]);
if(C_truep(t11)){
t12=t3;
f_7404(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[605]);
if(C_truep(t12)){
t13=t3;
f_7404(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[585]);
if(C_truep(t13)){
t14=t3;
f_7404(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[606]);
if(C_truep(t14)){
t15=t3;
f_7404(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[4],lf[607]);
if(C_truep(t15)){
t16=t3;
f_7404(t16,t15);}
else{
t16=C_eqp(((C_word*)t0)[4],lf[608]);
if(C_truep(t16)){
t17=t3;
f_7404(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[4],lf[609]);
t18=t3;
f_7404(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[4],lf[610])));}}}}}}}}}}}}}}}}

/* g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_7027(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_7027,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7031,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:991: foreign-stub-id */
t4=*((C_word*)lf[570]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3188 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3190(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3190,2,av);}
t2=C_i_car(((C_word*)t0)[2]);
/* c-backend.scm:184: expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2625(t3,((C_word*)t0)[4],t2,((C_word*)t0)[5]);}

/* ##compiler#generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7025(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_7025,4,av);}
a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7027,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_check_list_2(t2,lf[57]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7339,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_7339(t9,t1,t2);}

/* ##compiler#make-variable-list in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_6893,4,av);}
a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6899,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:955: list-tabulate */
t5=*((C_word*)lf[518]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k5128 in for-each-loop623 in k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5130,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5120(t3,((C_word*)t0)[4],t2);}

/* a6898 in make-variable-list in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6899(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6899,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6907,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:957: number->string */
t4=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5962(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_5962,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:731: lambda-literal-allocated */
t4=*((C_word*)lf[296]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7368(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_7368,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7371,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1059: real-name2 */
t4=*((C_word*)lf[569]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_5965,2,av);}
a=C_alloc(16);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6594,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:732: lambda-literal-callee-signatures */
t5=*((C_word*)lf[469]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5968(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_5968,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm:733: lambda-literal-rest-argument */
t4=*((C_word*)lf[298]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_7364(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_7364,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7368,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1058: foreign-callback-stub-id */
t4=*((C_word*)lf[641]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7362(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_7362,4,av);}
a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7364,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_check_list_2(t2,lf[57]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7957,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_7957(t9,t1,t2);}

/* k3750 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3752(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_3752,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:322: expr */
t3=((C_word*)((C_word*)t0)[9])[1];
f_2625(t3,t2,((C_word*)t0)[10],((C_word*)t0)[8]);}

/* k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_7037,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_i_length(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7043,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:995: foreign-stub-return-type */
t6=*((C_word*)lf[567]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7031(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_7031,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7034,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:992: real-name2 */
t4=*((C_word*)lf[569]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7034(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_7034,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:993: foreign-stub-argument-types */
t4=*((C_word*)lf[568]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5971(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,2))){C_save_and_reclaim((void *)f_5971,2,av);}
a=C_alloc(17);
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm:734: lambda-literal-customizable */
t5=*((C_word*)lf[236]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5974(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,2))){C_save_and_reclaim((void *)f_5974,2,av);}
a=C_alloc(19);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6590,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:735: lambda-literal-closure-size */
t5=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=t3;
f_5977(t4,C_SCHEME_FALSE);}}

/* k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(22,0,3))){
C_save_and_reclaim_args((void *)trf_5977,2,t0,t1);}
a=C_alloc(22);
t2=t1;
t3=(C_truep(t2)?C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1)):C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(0)));
t4=t3;
t5=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5983,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t4,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=t2,a[17]=((C_word*)t0)[15],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm:737: make-variable-list */
t6=*((C_word*)lf[299]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[467];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* for-each-loop1143 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_7339(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_7339,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7349,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:988: g1144 */
t5=((C_word*)t0)[3];
f_7027(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7049(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_7049,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:998: foreign-stub-argument-names */
t4=*((C_word*)lf[564]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7046(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_7046,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:997: foreign-stub-body */
t4=*((C_word*)lf[565]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7043(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_7043,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:996: foreign-stub-name */
t4=*((C_word*)lf[566]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k8621 in k8604 in k8587 in k8570 in k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8623(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8623,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1204: ->string */
t4=*((C_word*)lf[490]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8640,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)t0)[6],C_fix(3)))){
t3=C_i_car(((C_word*)t0)[4]);
t4=t2;
f_8640(t4,C_eqp(lf[586],t3));}
else{
t3=t2;
f_8640(t3,C_SCHEME_FALSE);}}}

/* compute-size in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7385(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_7385,5,av);}
a=C_alloc(8);
t5=t2;
t6=C_eqp(t5,lf[15]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7395,a[2]=t4,a[3]=t1,a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7395(t8,t6);}
else{
t8=C_eqp(t5,lf[435]);
if(C_truep(t8)){
t9=t7;
f_7395(t9,t8);}
else{
t9=C_eqp(t5,lf[611]);
if(C_truep(t9)){
t10=t7;
f_7395(t10,t9);}
else{
t10=C_eqp(t5,lf[612]);
if(C_truep(t10)){
t11=t7;
f_7395(t11,t10);}
else{
t11=C_eqp(t5,lf[12]);
if(C_truep(t11)){
t12=t7;
f_7395(t12,t11);}
else{
t12=C_eqp(t5,lf[534]);
if(C_truep(t12)){
t13=t7;
f_7395(t13,t12);}
else{
t13=C_eqp(t5,lf[613]);
if(C_truep(t13)){
t14=t7;
f_7395(t14,t13);}
else{
t14=C_eqp(t5,lf[614]);
if(C_truep(t14)){
t15=t7;
f_7395(t15,t14);}
else{
t15=C_eqp(t5,lf[615]);
if(C_truep(t15)){
t16=t7;
f_7395(t16,t15);}
else{
t16=C_eqp(t5,lf[616]);
if(C_truep(t16)){
t17=t7;
f_7395(t17,t16);}
else{
t17=C_eqp(t5,lf[617]);
if(C_truep(t17)){
t18=t7;
f_7395(t18,t17);}
else{
t18=C_eqp(t5,lf[618]);
t19=t7;
f_7395(t19,(C_truep(t18)?t18:C_eqp(t5,lf[619])));}}}}}}}}}}}}

/* k3122 in for-each-loop185 in k3097 in k3083 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3124(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3124,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_3114(t4,((C_word*)t0)[5],t2,t3);}

/* k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7383(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,5))){C_save_and_reclaim((void *)f_7383,2,av);}
a=C_alloc(15);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7385,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:1092: fold */
t7=*((C_word*)lf[400]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t4)[1];
av2[3]=lf[637];
av2[4]=((C_word*)t0)[6];
av2[5]=t2;
((C_proc)(void*)(*((C_word*)t7+1)))(6,av2);}}

/* k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7055(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_7055,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7058,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:999: foreign-result-conversion */
t4=*((C_word*)lf[184]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=lf[562];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k9122 in foreign-argument-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_9124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_9124,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[736];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[612]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[737];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[3],lf[613]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[738];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[604]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t5;
av2[1]=lf[739];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eqp(((C_word*)t0)[3],lf[598]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_9151(t7,t5);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[606]);
t8=t6;
f_9151(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[3],lf[571])));}}}}}}

/* k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7052(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_7052,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t1)){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t1;
f_7055(2,av2);}}
else{
/* c-backend.scm:998: make-list */
t3=*((C_word*)lf[563]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_7058,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm:1000: foreign-stub-cps */
t4=*((C_word*)lf[561]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[11];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4226 in k4223 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4228(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4228,2,av);}
/* c-backend.scm:405: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4223 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4225(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_4225,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4228,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4237,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:403: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
/* c-backend.scm:405: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k8628 in k8621 in k8604 in k8587 in k8570 in k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8630(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8630,2,av);}
/* c-backend.scm:1204: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[712];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7064(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_7064,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm:1002: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7067(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_7067,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[13])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7328,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1004: cleanup */
t4=*((C_word*)lf[458]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[13];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_7070(2,av2);}}}

/* k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7061(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_7061,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm:1001: foreign-stub-callback */
t4=*((C_word*)lf[560]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[12];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k10797 in k10793 in encode-literal in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10799(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10799,2,av);}
/* c-backend.scm:1411: cons* */
t2=*((C_word*)lf[841]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k9984 in k9981 in k9978 in k9972 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9986(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9986,2,av);}
/* c-backend.scm:1317: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k10793 in encode-literal in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10795(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_10795,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10801,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1414: list-tabulate */
t5=*((C_word*)lf[518]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k9981 in k9978 in k9972 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_9983,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1317: ##sys#write-char-0 */
t3=*((C_word*)lf[317]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(44);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k8638 in k8621 in k8604 in k8587 in k8570 in k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8640(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_8640,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_caddr(((C_word*)t0)[2]);
t4=t3;
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_i_nullp(t8);
t10=(C_truep(t9)?lf[713]:C_i_car(t8));
t11=t10;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8659,a[2]=((C_word*)t0)[3],a[3]=t11,a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1210: foreign-type-declaration */
t13=*((C_word*)lf[190]+1);{
C_word av2[4];
av2[0]=t13;
av2[1]=t12;
av2[2]=t2;
av2[3]=lf[721];
((C_proc)(void*)(*((C_word*)t13+1)))(4,av2);}}
else{
/* c-backend.scm:1221: err */
t2=((C_word*)t0)[5];
f_8045(t2,((C_word*)t0)[3]);}}

/* k9978 in k9972 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9980(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_9980,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1317: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6467 in doloop872 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in ... */
static void C_ccall f_6469(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6469,2,av);}
a=C_alloc(4);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6459(t3,((C_word*)t0)[4],t2);}

/* k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in ... */
static void C_ccall f_7121(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,5))){C_save_and_reclaim((void *)f_7121,2,av);}
a=C_alloc(15);
t2=C_i_check_list_2(((C_word*)t0)[2],lf[57]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7127,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7219,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_7219(t7,t3,((C_word*)t0)[11],t1,((C_word*)t0)[2]);}

/* k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,11))){C_save_and_reclaim((void *)f_7073,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[7])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7271,a[2]=((C_word*)t0)[9],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1009: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 12) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(12);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[547];
av2[4]=((C_word*)t0)[12];
av2[5]=lf[548];
av2[6]=C_SCHEME_TRUE;
av2[7]=lf[549];
av2[8]=((C_word*)t0)[12];
av2[9]=lf[550];
av2[10]=C_SCHEME_TRUE;
av2[11]=lf[551];
((C_proc)(void*)(*((C_word*)t4+1)))(12,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7300,a[2]=t2,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1016: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[555];
av2[4]=((C_word*)t0)[12];
av2[5]=C_make_character(40);
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}}

/* k6490 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in ... */
static void C_fcall f_6492(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_6492,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:768: gen */
t3=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[446];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_6034(2,av2);}}}

/* k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_7076,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:1019: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[543];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 in ... */
static void C_ccall f_7079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_7079,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7121,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:1028: iota */
t4=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7070(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,5))){C_save_and_reclaim((void *)f_7070,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm:1006: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[556];
av2[4]=((C_word*)t0)[11];
av2[5]=lf[557];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_7073(2,av2);}}}

/* k9972 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9974(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_9974,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9980,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1317: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[805];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k8657 in k8638 in k8621 in k8604 in k8587 in k8570 in k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 in ... */
static void C_ccall f_8659(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,3))){C_save_and_reclaim((void *)f_8659,2,av);}
a=C_alloc(21);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8663,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_i_check_list_2(((C_word*)t0)[5],lf[700]);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8684,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8686,a[2]=t6,a[3]=t11,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_8686(t13,t9,((C_word*)t0)[5]);}

/* k6493 in k6490 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in ... */
static void C_ccall f_6495(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6495,2,av);}
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
/* c-backend.scm:769: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
f_6034(2,av2);}}}

/* k7128 in k7125 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in ... */
static void C_ccall f_7130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,5))){C_save_and_reclaim((void *)f_7130,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7133,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7139,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1031: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[3];
av2[4]=C_SCHEME_TRUE;
av2[5]=lf[528];
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7160,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t4=C_eqp(((C_word*)t0)[6],lf[534]);
if(C_truep(t4)){
/* c-backend.scm:1042: gen */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
/* c-backend.scm:1041: gen */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[536];
av2[4]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}}

/* k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7377(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_7377,2,av);}
a=C_alloc(9);
t2=t1;
t3=C_i_length(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:1063: make-argument-list */
t6=*((C_word*)lf[304]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
av2[3]=lf[638];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7374(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_7374,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7377,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:1061: foreign-callback-stub-argument-types */
t4=*((C_word*)lf[639]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7371(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_7371,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1060: foreign-callback-stub-return-type */
t4=*((C_word*)lf[640]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7086 in k7224 in for-each-loop1181 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in ... */
static void C_ccall f_7088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_7088,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7092,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1026: foreign-type-declaration */
t4=*((C_word*)lf[190]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[541];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k7125 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in ... */
static void C_ccall f_7127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_7127,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:1029: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[537];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_7130(2,av2);}}}

/* k7094 in k7090 in k7086 in k7224 in for-each-loop1181 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in ... */
static void C_ccall f_7096(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,10))){C_save_and_reclaim((void *)f_7096,2,av);}
/* c-backend.scm:1022: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 11) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(11);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[3];
av2[4]=lf[538];
av2[5]=((C_word*)t0)[4];
av2[6]=C_make_character(41);
av2[7]=t1;
av2[8]=lf[539];
av2[9]=((C_word*)t0)[5];
av2[10]=lf[540];
((C_proc)(void*)(*((C_word*)t2+1)))(11,av2);}}

/* k6431 in doloop877 in k6419 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in ... */
static void C_ccall f_6433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_6433,2,av);}
a=C_alloc(8);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=C_a_i_minus(&a,2,((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_6423(t4,((C_word*)t0)[5],t2,t3);}

/* k9996 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9998(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_9998,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10004,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1318: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[806];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k7090 in k7086 in k7224 in for-each-loop1181 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in ... */
static void C_ccall f_7092(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_7092,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1027: foreign-argument-conversion */
t4=*((C_word*)lf[189]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7131 in k7128 in k7125 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in ... */
static void C_ccall f_7133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7133,2,av);}
/* c-backend.scm:1052: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(125);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7137 in k7128 in k7125 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in ... */
static void C_ccall f_7139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_7139,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1033: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[527];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10785 in encode-literal in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10787(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_10787,2,av);}
/* c-backend.scm:1410: string-intersperse */
t2=*((C_word*)lf[256]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[840];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k9149 in k9122 in foreign-argument-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_9151(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_9151,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[740];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[602]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[3],lf[603]));
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[741];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[608]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t5;
av2[1]=lf[742];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eqp(((C_word*)t0)[3],lf[605]);
if(C_truep(t5)){
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=lf[743];
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(((C_word*)t0)[3],lf[607]);
if(C_truep(t6)){
t7=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t7;
av2[1]=lf[744];
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_eqp(((C_word*)t0)[3],lf[601]);
if(C_truep(t7)){
t8=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t8;
av2[1]=lf[745];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_eqp(((C_word*)t0)[3],lf[599]);
t9=(C_truep(t8)?t8:C_eqp(((C_word*)t0)[3],lf[600]));
if(C_truep(t9)){
t10=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t10;
av2[1]=lf[746];
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=C_eqp(((C_word*)t0)[3],lf[731]);
if(C_truep(t10)){
t11=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t11;
av2[1]=lf[747];
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t11=C_eqp(((C_word*)t0)[3],lf[732]);
if(C_truep(t11)){
t12=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t12;
av2[1]=lf[748];
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
else{
t12=C_eqp(((C_word*)t0)[3],lf[583]);
if(C_truep(t12)){
t13=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t13;
av2[1]=lf[749];
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t13=C_eqp(((C_word*)t0)[3],lf[585]);
if(C_truep(t13)){
t14=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t14;
av2[1]=lf[750];
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
else{
t14=C_eqp(((C_word*)t0)[3],lf[667]);
if(C_truep(t14)){
t15=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t15;
av2[1]=lf[751];
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t15=C_eqp(((C_word*)t0)[3],lf[728]);
if(C_truep(t15)){
t16=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t16;
av2[1]=lf[752];
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}
else{
t16=C_eqp(((C_word*)t0)[3],lf[729]);
if(C_truep(t16)){
t17=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t17;
av2[1]=lf[753];
((C_proc)(void*)(*((C_word*)t17+1)))(2,av2);}}
else{
t17=C_eqp(((C_word*)t0)[3],lf[730]);
if(C_truep(t17)){
t18=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t18;
av2[1]=lf[754];
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}
else{
t18=C_eqp(((C_word*)t0)[3],lf[669]);
if(C_truep(t18)){
t19=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t19;
av2[1]=lf[755];
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}
else{
t19=C_eqp(((C_word*)t0)[3],lf[670]);
if(C_truep(t19)){
t20=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t20;
av2[1]=lf[756];
((C_proc)(void*)(*((C_word*)t20+1)))(2,av2);}}
else{
t20=C_eqp(((C_word*)t0)[3],lf[675]);
if(C_truep(t20)){
t21=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t21;
av2[1]=lf[757];
((C_proc)(void*)(*((C_word*)t21+1)))(2,av2);}}
else{
t21=C_eqp(((C_word*)t0)[3],lf[676]);
if(C_truep(t21)){
t22=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t22;
av2[1]=lf[758];
((C_proc)(void*)(*((C_word*)t22+1)))(2,av2);}}
else{
t22=C_eqp(((C_word*)t0)[3],lf[672]);
if(C_truep(t22)){
t23=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t23;
av2[1]=lf[759];
((C_proc)(void*)(*((C_word*)t23+1)))(2,av2);}}
else{
t23=C_eqp(((C_word*)t0)[3],lf[673]);
if(C_truep(t23)){
t24=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t24;
av2[1]=lf[760];
((C_proc)(void*)(*((C_word*)t24+1)))(2,av2);}}
else{
t24=C_eqp(((C_word*)t0)[3],lf[678]);
if(C_truep(t24)){
t25=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t25;
av2[1]=lf[761];
((C_proc)(void*)(*((C_word*)t25+1)))(2,av2);}}
else{
t25=C_eqp(((C_word*)t0)[3],lf[679]);
if(C_truep(t25)){
t26=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t26;
av2[1]=lf[762];
((C_proc)(void*)(*((C_word*)t26+1)))(2,av2);}}
else{
t26=C_eqp(((C_word*)t0)[3],lf[681]);
if(C_truep(t26)){
t27=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t27;
av2[1]=lf[763];
((C_proc)(void*)(*((C_word*)t27+1)))(2,av2);}}
else{
t27=C_eqp(((C_word*)t0)[3],lf[682]);
if(C_truep(t27)){
t28=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t28;
av2[1]=lf[764];
((C_proc)(void*)(*((C_word*)t28+1)))(2,av2);}}
else{
t28=C_eqp(((C_word*)t0)[3],lf[684]);
if(C_truep(t28)){
t29=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t29;
av2[1]=lf[765];
((C_proc)(void*)(*((C_word*)t29+1)))(2,av2);}}
else{
t29=C_eqp(((C_word*)t0)[3],lf[685]);
if(C_truep(t29)){
t30=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t30;
av2[1]=lf[766];
((C_proc)(void*)(*((C_word*)t30+1)))(2,av2);}}
else{
t30=C_eqp(((C_word*)t0)[3],lf[687]);
if(C_truep(t30)){
t31=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t31;
av2[1]=lf[767];
((C_proc)(void*)(*((C_word*)t31+1)))(2,av2);}}
else{
t31=C_eqp(((C_word*)t0)[3],lf[688]);
if(C_truep(t31)){
t32=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t32;
av2[1]=lf[768];
((C_proc)(void*)(*((C_word*)t32+1)))(2,av2);}}
else{
t32=C_eqp(((C_word*)t0)[3],lf[690]);
if(C_truep(t32)){
t33=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t33;
av2[1]=lf[769];
((C_proc)(void*)(*((C_word*)t33+1)))(2,av2);}}
else{
t33=C_eqp(((C_word*)t0)[3],lf[691]);
if(C_truep(t33)){
t34=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t34;
av2[1]=lf[770];
((C_proc)(void*)(*((C_word*)t34+1)))(2,av2);}}
else{
t34=C_eqp(((C_word*)t0)[3],lf[573]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_9346(t36,t34);}
else{
t36=C_eqp(((C_word*)t0)[3],lf[595]);
if(C_truep(t36)){
t37=t35;
f_9346(t37,t36);}
else{
t37=C_eqp(((C_word*)t0)[3],lf[596]);
t38=t35;
f_9346(t38,(C_truep(t37)?t37:C_eqp(((C_word*)t0)[3],lf[597])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k8604 in k8587 in k8570 in k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8606(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_8606,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1202: ->string */
t4=*((C_word*)lf[490]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8623,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[6],C_fix(3));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=t2;
f_8623(t5,C_eqp(lf[589],t4));}
else{
t4=t2;
f_8623(t4,C_SCHEME_FALSE);}}}

/* k7140 in k7137 in k7128 in k7125 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in ... */
static void C_ccall f_7142(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_7142,2,av);}
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:1035: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[523];
av2[4]=C_SCHEME_TRUE;
av2[5]=lf[524];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}
else{
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:1037: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[525];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
/* c-backend.scm:1038: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[526];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}}

/* k10755 in encode-literal in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10757(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_10757,2,av);}
/* c-backend.scm:1403: ##sys#string-append */
t2=*((C_word*)lf[104]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5871 in doloop811 in k5815 in gen-string-constant in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5873(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5873,2,av);}
/* c-backend.scm:708: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5875 in doloop811 in k5815 in gen-string-constant in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5877(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5877,2,av);}
/* c-backend.scm:708: c-ify-string */
t2=*((C_word*)lf[72]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6844 in loop in cleanup in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_6846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_6846,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=C_i_string_set(((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3],C_make_character(126));
t3=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* c-backend.scm:949: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_6818(t4,((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:946: string-copy */
t3=*((C_word*)lf[516]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=C_i_string_set(((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3],((C_word*)t0)[7]);
t3=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* c-backend.scm:949: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_6818(t4,((C_word*)t0)[5],t3);}
else{
t2=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* c-backend.scm:949: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6818(t3,((C_word*)t0)[5],t2);}}}

/* k8611 in k8604 in k8587 in k8570 in k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8613,2,av);}
/* c-backend.scm:1202: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[711];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k10763 in encode-literal in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_10765,2,av);}
/* c-backend.scm:1404: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* string-like-substring in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5883(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,2))){
C_save_and_reclaim_args((void *)trf_5883,4,t1,t2,t3,t4);}
a=C_alloc(10);
t5=C_a_i_minus(&a,2,t4,t3);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5890,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:712: make-string */
t8=*((C_word*)lf[348]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k3601 in k3582 in k3561 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3603(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3603,2,av);}
/* c-backend.scm:283: push-args */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4661(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k7947 in k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_7949,2,av);}
/* c-backend.scm:1095: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[635];
av2[4]=t1;
av2[5]=lf[636];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k5290 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5292(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5292,2,av);}
/* c-backend.scm:581: intersperse */
t2=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6854 in k6844 in loop in cleanup in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6856(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6856,2,av);}
a=C_alloc(4);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_i_string_set(((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3],C_make_character(126));
t4=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* c-backend.scm:949: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6818(t5,((C_word*)t0)[5],t4);}

/* k5220 in k5217 in k5187 in k5184 in k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in ... */
static void C_ccall f_5222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5222,2,av);}
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
/* c-backend.scm:604: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
f_5192(2,av2);}}}

/* k10716 in encode-literal in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10718(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10718,2,av);}
/* c-backend.scm:1393: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[836];
av2[3]=t1;
av2[4]=lf[837];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_3639(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,5))){
C_save_and_reclaim_args((void *)trf_3639,2,t0,t1);}
a=C_alloc(14);
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=t2;
t4=C_i_car(t3);
t5=t4;
t6=C_i_cadr(t3);
t7=t6;
t8=C_i_caddr(t3);
t9=t8;
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3659,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t11,a[8]=t9,a[9]=t5,a[10]=t7,a[11]=t3,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:296: gen */
t13=*((C_word*)lf[1]+1);{
C_word av2[4];
av2[0]=t13;
av2[1]=t12;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[133];
((C_proc)(void*)(*((C_word*)t13+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3752,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[2],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:321: gen */
t3=*((C_word*)lf[1]+1);{
C_word av2[6];
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=C_make_character(116);
av2[4]=((C_word*)t0)[8];
av2[5]=C_make_character(61);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}}

/* k3631 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3633(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3633,2,av);}
t2=C_eqp(((C_word*)t0)[2],t1);
if(C_truep(t2)){
/* c-backend.scm:257: lambda-literal-looping */
t3=*((C_word*)lf[107]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_3442(2,av2);}}}

/* k5276 in k5273 in k5270 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5278(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5278,2,av);}
/* c-backend.scm:599: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[283];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5273 in k5270 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5275(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5275,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:598: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[284];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5270 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5272(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,5))){C_save_and_reclaim((void *)f_5272,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5275,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:597: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[285];
av2[3]=t2;
av2[4]=lf[286];
av2[5]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}

/* k4774 in pad0 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4776(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4776,2,av);}
/* ##sys#string-append */
t2=*((C_word*)lf[104]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[237];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4779(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,2))){C_save_and_reclaim((void *)f_4779,2,av);}
a=C_alloc(20);
t2=C_i_vector_ref(t1,C_fix(1));
t3=t2;
t4=C_i_vector_ref(t1,C_fix(2));
t5=t4;
t6=C_i_vector_ref(t1,C_fix(3));
t7=t6;
t8=C_i_vector_ref(t1,C_fix(4));
t9=C_i_vector_ref(t1,C_fix(5));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4797,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=C_a_i_plus(&a,2,C_fix(1900),t9);
t12=t11;
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4878,a[2]=t10,a[3]=((C_word*)t0)[3],a[4]=t12,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t5,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t14=C_a_i_plus(&a,2,t8,C_fix(1));
/* c-backend.scm:516: pad0 */
f_4761(t13,t14);}

/* k6521 in k6518 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in ... */
static void C_ccall f_6523(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6523,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:757: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[451];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
/* c-backend.scm:758: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[452];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k6524 in k6521 in k6518 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in ... */
static void C_ccall f_6526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6526,2,av);}
/* c-backend.scm:759: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6404 in for-each-loop885 in k6371 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in ... */
static void C_ccall f_6406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6406,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6396(t3,((C_word*)t0)[4],t2);}

/* k3615 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3617(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3617,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3620,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:274: expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2625(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k3612 in k3582 in k3561 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3614(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3614,2,av);}
/* ##sys#string-append */
t2=*((C_word*)lf[104]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[105];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k10703 in encode-literal in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(29,c,3))){C_save_and_reclaim((void *)f_10705,2,av);}
a=C_alloc(29);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10700,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
/* ##sys#fixnum->string */
t4=*((C_word*)lf[834]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=C_a_i_arithmetic_shift(&a,2,((C_word*)t0)[3],C_fix(-24));
t3=C_a_i_bitwise_and(&a,2,C_fix(255),t2);
t4=C_make_character(C_unfix(t3));
t5=C_a_i_arithmetic_shift(&a,2,((C_word*)t0)[3],C_fix(-16));
t6=C_a_i_bitwise_and(&a,2,C_fix(255),t5);
t7=C_make_character(C_unfix(t6));
t8=C_a_i_arithmetic_shift(&a,2,((C_word*)t0)[3],C_fix(-8));
t9=C_a_i_bitwise_and(&a,2,C_fix(255),t8);
t10=C_make_character(C_unfix(t9));
t11=((C_word*)t0)[3];
t12=C_fixnum_and(C_fix(255),t11);
t13=C_make_character(C_unfix(t12));
t14=C_a_i_string(&a,4,t4,t7,t10,t13);
/* ##sys#string-append */
t15=*((C_word*)lf[104]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t15;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[835];
av2[3]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}}

/* k10698 in k10703 in encode-literal in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10700,2,av);}
/* c-backend.scm:1391: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[832];
av2[3]=t1;
av2[4]=lf[833];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3618 in k3615 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3620(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3620,2,av);}
/* c-backend.scm:275: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4367 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4369(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4369,2,av);}
/* c-backend.scm:424: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[201];
av2[3]=t1;
av2[4]=lf[202];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4359 in k4342 in k4339 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4361(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4361,2,av);}
/* c-backend.scm:426: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[200];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4392 in k4389 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4394(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4394,2,av);}
/* c-backend.scm:436: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[206];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4389 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4391(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4391,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:435: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k4345 in k4342 in k4339 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4347(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4347,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4350,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:427: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k4339 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4341(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4341,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:425: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k4342 in k4339 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4344(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_4344,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4361,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:426: foreign-argument-conversion */
t4=*((C_word*)lf[189]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k10732 in encode-literal in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10734(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10734,2,av);}
/* c-backend.scm:1396: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[838];
av2[3]=t1;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5856 in doloop811 in k5815 in gen-string-constant in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5858(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_5858,2,av);}
a=C_alloc(8);
t2=C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(80));
t4=((C_word*)((C_word*)t0)[4])[1];
f_5822(t4,((C_word*)t0)[5],t2,t3);}

/* k9957 in k9954 in k9951 in k9945 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9959(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9959,2,av);}
/* c-backend.scm:1316: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k9954 in k9951 in k9945 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9956(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_9956,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1316: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[803];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k9951 in k9945 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_9953,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1316: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8228(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_8228,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
/* c-backend.scm:1151: str */
t2=((C_word*)t0)[2];
f_8050(t2,((C_word*)t0)[3],lf[665]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[609]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[610]));
if(C_truep(t3)){
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[666];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[4],lf[667]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_8249(t6,t4);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[728]);
if(C_truep(t6)){
t7=t5;
f_8249(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[729]);
t8=t5;
f_8249(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[4],lf[730])));}}}}}

/* k3265 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3267(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_3267,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3284,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3288,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:206: ##sys#symbol->qualified-string */
t5=*((C_word*)lf[73]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5217 in k5187 in k5184 in k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 in ... */
static void C_fcall f_5219(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_5219,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:603: gen */
t3=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[280];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_5192(2,av2);}}}

/* k5836 in doloop811 in k5815 in gen-string-constant in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_5838,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5845,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5849,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:707: string-like-substring */
f_5883(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k5847 in k5836 in doloop811 in k5815 in gen-string-constant in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5849(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5849,2,av);}
/* c-backend.scm:707: c-ify-string */
t2=*((C_word*)lf[72]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5843 in k5836 in doloop811 in k5815 in gen-string-constant in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5845,2,av);}
/* c-backend.scm:707: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5891 in k5888 in string-like-substring in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5893,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5888 in string-like-substring in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,6))){C_save_and_reclaim((void *)f_5890,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5893,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:713: ##sys#copy-bytes */
t4=*((C_word*)lf[347]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
av2[4]=((C_word*)t0)[4];
av2[5]=C_fix(0);
av2[6]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}}

/* pad0 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_4761(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_4761,2,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_lessp(t2,C_fix(10)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4776,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:506: number->string */
t4=*((C_word*)lf[106]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5199 in k5196 in k5193 in k5190 in k5187 in k5184 in k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in ... */
static void C_ccall f_5201(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5201,2,av);}
/* c-backend.scm:611: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_4758(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_4758,2,t0,t1);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4761,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4779,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4955,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:508: current-seconds */
t5=*((C_word*)lf[264]+1);{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k4741 in push-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4743(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4743,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4746,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t1;
t4=((C_word*)t0)[2];
f_4671(t4,C_i_not(t3));}
else{
/* c-backend.scm:480: lambda-literal-direct */
t3=*((C_word*)lf[235]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k4744 in k4741 in push-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4746(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4746,2,av);}
t2=((C_word*)t0)[2];
f_4671(t2,C_i_not(t1));}

/* k4309 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4311(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4311,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:419: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k4312 in k4309 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4314(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4314,2,av);}
/* c-backend.scm:420: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[193];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4731 in k4728 in k4725 in k4722 in k4719 in k4669 in push-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4733,2,av);}
/* c-backend.scm:491: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[225];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4728 in k4725 in k4722 in k4719 in k4669 in push-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4730(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_4730,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:490: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[226];
av2[4]=((C_word*)t0)[3];
av2[5]=lf[227];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k9894 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9896(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_9896,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9902,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1314: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[801];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k7432 in k7426 in k7414 in k7402 in k7393 in compute-size in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7434(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_7434,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1080: g1394 */
t3=t2;
f_7438(t3,((C_word*)t0)[5],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[6]))){
t2=((C_word*)t0)[6];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[580]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7471,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_7471(t6,t4);}
else{
t6=C_eqp(t3,lf[433]);
if(C_truep(t6)){
t7=t5;
f_7471(t7,t6);}
else{
t7=C_eqp(t3,lf[583]);
if(C_truep(t7)){
t8=t5;
f_7471(t8,t7);}
else{
t8=C_eqp(t3,lf[584]);
if(C_truep(t8)){
t9=t5;
f_7471(t9,t8);}
else{
t9=C_eqp(t3,lf[585]);
if(C_truep(t9)){
t10=t5;
f_7471(t10,t9);}
else{
t10=C_eqp(t3,lf[586]);
if(C_truep(t10)){
t11=t5;
f_7471(t11,t10);}
else{
t11=C_eqp(t3,lf[587]);
if(C_truep(t11)){
t12=t5;
f_7471(t12,t11);}
else{
t12=C_eqp(t3,lf[588]);
t13=t5;
f_7471(t13,(C_truep(t12)?t12:C_eqp(t3,lf[589])));}}}}}}}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* g1394 in k7432 in k7426 in k7414 in k7402 in k7393 in compute-size in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_7438(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_7438,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* c-backend.scm:1082: compute-size */
t4=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
f_7385(5,av2);}}
else{
t3=t2;
/* c-backend.scm:1082: compute-size */
t4=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
f_7385(5,av2);}}}

/* k4795 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4797(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4797,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4800,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:522: gen-list */
t3=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[250]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* encode-size in encode-literal in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_10519(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(28,0,3))){
C_save_and_reclaim_args((void *)trf_10519,2,t1,t2);}
a=C_alloc(28);
t3=C_a_i_arithmetic_shift(&a,2,t2,C_fix(-24));
if(C_truep(C_u_i_zerop(t3))){
t4=C_a_i_arithmetic_shift(&a,2,t2,C_fix(-16));
t5=C_a_i_bitwise_and(&a,2,C_fix(255),t4);
t6=C_make_character(C_unfix(t5));
t7=C_a_i_arithmetic_shift(&a,2,t2,C_fix(-8));
t8=C_a_i_bitwise_and(&a,2,C_fix(255),t7);
t9=C_make_character(C_unfix(t8));
t10=C_a_i_bitwise_and(&a,2,C_fix(255),t2);
t11=C_make_character(C_unfix(t10));
t12=t1;{
C_word av2[2];
av2[0]=t12;
av2[1]=C_a_i_string(&a,3,t6,t9,t11);
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
else{
/* c-backend.scm:1369: quit */
t4=*((C_word*)lf[646]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[825];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* ##compiler#encode-literal in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10510(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_10510,3,av);}
a=C_alloc(16);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10519,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10586,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t5)){
t6=t1;
t7=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1375: string-append */
t8=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=lf[826];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t6=C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t6)){
t7=t1;
t8=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1375: string-append */
t9=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
av2[3]=lf[827];
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
if(C_truep(C_charp(t2))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10608,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t8=C_fix(C_character_code(t2));
/* c-backend.scm:1379: encode-size */
f_10519(t7,t8);}
else{
if(C_truep(C_i_nullp(t2))){
t7=t1;
t8=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1375: string-append */
t9=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
av2[3]=lf[829];
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
if(C_truep(C_eofp(t2))){
t7=t1;
t8=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1375: string-append */
t9=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
av2[3]=lf[830];
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
t7=*((C_word*)lf[332]+1);
t8=C_eqp(*((C_word*)lf[332]+1),t2);
if(C_truep(t8)){
t9=t1;
t10=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1375: string-append */
t11=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t11;
av2[1]=t9;
av2[2]=t10;
av2[3]=lf[831];
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}
else{
if(C_truep(C_fixnump(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10705,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1384: big-fixnum? */
t10=*((C_word*)lf[345]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}
else{
if(C_truep(C_i_numberp(t2))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10718,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1393: number->string */
t10=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
t9=C_slot(t2,C_fix(1));
t10=t9;
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10734,a[2]=t4,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=C_i_string_length(t10);
/* c-backend.scm:1398: encode-size */
f_10519(t11,t12);}
else{
if(C_truep(C_immp(t2))){
/* c-backend.scm:1401: bomb */
t9=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t4;
av2[2]=lf[839];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
if(C_truep(C_byteblockp(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10757,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=t2;
t11=stub2084(C_SCHEME_UNDEFINED,t10);
t12=C_make_character(C_unfix(t11));
t13=C_a_i_string(&a,1,t12);
t14=t13;
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10765,a[2]=t9,a[3]=t14,tmp=(C_word)a,a+=4,tmp);
t16=t2;
t17=stub2088(C_SCHEME_UNDEFINED,t16);
/* c-backend.scm:1406: encode-size */
f_10519(t15,t17);}
else{
t9=t2;
t10=stub2088(C_SCHEME_UNDEFINED,t9);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10787,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t13=t2;
t14=stub2084(C_SCHEME_UNDEFINED,t13);
t15=C_make_character(C_unfix(t14));
t16=C_a_i_string(&a,1,t15);
t17=t16;
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10795,a[2]=t12,a[3]=t17,a[4]=t2,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1413: encode-size */
f_10519(t18,t11);}}}}}}}}}}}}

/* k9873 in k9867 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9875(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_9875,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1313: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k9876 in k9873 in k9867 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9878(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_9878,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1313: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[799];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6557 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in ... */
static void C_ccall f_6559(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_6559,2,av);}
/* c-backend.scm:752: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[456];
av2[3]=t1;
av2[4]=lf[457];
av2[5]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k4825 in k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4827,2,av);}
a=C_alloc(5);
t2=*((C_word*)lf[241]+1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4837,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4837(t6,((C_word*)t0)[2],*((C_word*)lf[241]+1));}

/* k3923 in g395 in k3918 in k3915 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3925(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3925,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3928,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:343: expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2625(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k3926 in k3923 in g395 in k3918 in k3915 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3928(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3928,2,av);}
/* c-backend.scm:344: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* g395 in k3918 in k3915 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_3921(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,5))){
C_save_and_reclaim_args((void *)trf_3921,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3925,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:342: gen */
t5=*((C_word*)lf[1]+1);{
C_word av2[6];
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
av2[3]=C_make_character(116);
av2[4]=t3;
av2[5]=C_make_character(61);
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}

/* k3918 in k3915 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3920(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,4))){C_save_and_reclaim((void *)f_3920,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3934,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3987,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3987(t8,t4,((C_word*)t0)[6],t2);}

/* k4813 in k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4815(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4815,2,av);}
if(C_truep(*((C_word*)lf[238]+1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* c-backend.scm:535: generate-foreign-callback-stub-prototypes */
t2=*((C_word*)lf[239]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[240]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4812(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_4812,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4815,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(*((C_word*)lf[241]+1)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4827,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:532: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
if(C_truep(*((C_word*)lf[238]+1))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* c-backend.scm:535: generate-foreign-callback-stub-prototypes */
t3=*((C_word*)lf[239]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[240]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}}

/* k3932 in k3918 in k3915 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3934(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_3934,2,av);}
a=C_alloc(4);
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3942,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:348: iota */
t4=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=C_fix(1);
av2[4]=C_fix(1);
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k9855 in k9852 in k9849 in k9843 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9857,2,av);}
/* c-backend.scm:1312: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k9852 in k9849 in k9843 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_9854,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1312: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[797];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k9849 in k9843 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_9851,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1312: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3416 in k3413 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_3418,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=C_i_car(t2);
/* c-backend.scm:254: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_TRUE;
av2[3]=t3;
av2[4]=C_make_character(40);
av2[5]=((C_word*)t0)[4];
av2[6]=lf[96];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}}

/* k3413 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3415(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_3415,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:252: push-args */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4661(t3,t2,((C_word*)t0)[6],((C_word*)t0)[7],lf[97]);}

/* k9879 in k9876 in k9873 in k9867 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9881,2,av);}
/* c-backend.scm:1313: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6588 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6590(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6590,2,av);}
t2=((C_word*)t0)[2];
f_5977(t2,C_i_zerop(t1));}

/* k6595 in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6597(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_6597,2,av);}
a=C_alloc(11);
t2=C_mutate2((C_word*)lf[0]+1 /* (set! ##compiler#output ...) */,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:878: header */
t4=((C_word*)((C_word*)t0)[12])[1];
f_4758(t4,t3);}

/* k6592 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6594(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6594,2,av);}{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[468]+1);
av2[3]=C_fix(0);
av2[4]=t1;
C_apply(5,av2);}}

/* k3915 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3917(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_3917,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_a_i_plus(&a,2,t1,((C_word*)t0)[7]);
/* c-backend.scm:339: iota */
t4=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=t3;
av2[4]=C_fix(1);
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k5184 in k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5186,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5189(2,av2);}}
else{
/* c-backend.scm:601: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[281];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* g280 in k3446 in k3443 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_3449(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,5))){
C_save_and_reclaim_args((void *)trf_3449,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3453,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:262: gen */
t5=*((C_word*)lf[1]+1);{
C_word av2[6];
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
av2[3]=C_make_character(116);
av2[4]=t3;
av2[5]=C_make_character(61);
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}

/* k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5183(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5183,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:600: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(40);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3443 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3445(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,4))){C_save_and_reclaim((void *)f_3445,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_a_i_plus(&a,2,t1,((C_word*)t0)[6]);
/* c-backend.scm:259: iota */
t4=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=t3;
av2[4]=C_fix(1);
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k3446 in k3443 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3448(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,4))){C_save_and_reclaim((void *)f_3448,2,av);}
a=C_alloc(17);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3462,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3521,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3521(t8,t4,((C_word*)t0)[8],t2);}

/* k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5180(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,5))){C_save_and_reclaim((void *)f_5180,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(lf[282],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5272,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[246]+1))){
/* c-backend.scm:596: string-append */
t5=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[246]+1);
av2[3]=lf[287];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=lf[288];
f_5272(2,av2);}}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5247,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:588: gen */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[294];
av2[3]=((C_word*)t0)[7];
av2[4]=lf[295];
av2[5]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}}

/* k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3442(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,5))){C_save_and_reclaim((void *)f_3442,2,av);}
a=C_alloc(18);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:258: lambda-literal-temporaries */
t3=*((C_word*)lf[101]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3563,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[14],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[11])){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_3563(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3617,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:273: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
av2[3]=C_make_character(116);
av2[4]=((C_word*)t0)[12];
av2[5]=C_make_character(61);
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}}}

/* k6543 in k6540 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in ... */
static void C_ccall f_6545(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_6545,2,av);}
/* c-backend.scm:764: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=C_SCHEME_TRUE;
av2[4]=lf[448];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k6540 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in ... */
static void C_ccall f_6542(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,5))){C_save_and_reclaim((void *)f_6542,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(*((C_word*)lf[246]+1))){
/* c-backend.scm:764: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=C_SCHEME_TRUE;
av2[4]=lf[448];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}
else{
/* c-backend.scm:763: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[449];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k5187 in k5184 in k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5189(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_5189,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5219,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=C_i_zerop(((C_word*)t0)[6]);
t5=t3;
f_5219(t5,C_i_not(t4));}
else{
t4=t3;
f_5219(t4,C_SCHEME_FALSE);}}

/* k5193 in k5190 in k5187 in k5184 in k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in ... */
static void C_ccall f_5195(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5195,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:608: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5196 in k5193 in k5190 in k5187 in k5184 in k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in ... */
static void C_ccall f_5198(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5198,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5201,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm:611: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
/* c-backend.scm:610: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[278];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k5190 in k5187 in k5184 in k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 in ... */
static void C_ccall f_5192(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_5192,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(((C_word*)t0)[4])){{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t2;
av2[2]=*((C_word*)lf[1]+1);
av2[3]=((C_word*)t0)[5];
C_apply(4,av2);}}
else{
/* c-backend.scm:607: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[279];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
if(C_truep(((C_word*)t0)[3])){{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t2;
av2[2]=*((C_word*)lf[1]+1);
av2[3]=((C_word*)t0)[5];
C_apply(4,av2);}}
else{
/* c-backend.scm:607: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[279];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}}

/* k9867 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9869(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_9869,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9875,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1313: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[800];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5168(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5168,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:583: lambda-literal-rest-argument-mode */
t3=*((C_word*)lf[297]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5165(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5165,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:582: lambda-literal-rest-argument */
t4=*((C_word*)lf[298]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5162(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(13,0,3))){
C_save_and_reclaim_args((void *)trf_5162,2,t0,t1);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5292,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=C_a_i_minus(&a,2,((C_word*)t0)[6],C_fix(1));
/* c-backend.scm:581: make-variable-list */
t5=*((C_word*)lf[299]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[300];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
/* c-backend.scm:581: make-variable-list */
t4=*((C_word*)lf[299]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
av2[3]=lf[300];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5177(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_5177,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:586: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5174(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5174,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5177,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:585: lambda-literal-allocated */
t4=*((C_word*)lf[296]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5171,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:584: lambda-literal-direct */
t3=*((C_word*)lf[235]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6518 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in ... */
static void C_ccall f_6520(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_6520,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm:755: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[453];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
/* c-backend.scm:755: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[454];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* ##compiler#foreign-argument-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9094(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_9094,3,av);}
a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9096,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=C_eqp(t4,lf[614]);
if(C_truep(t5)){
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=lf[734];
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(t4,lf[15]);
t7=(C_truep(t6)?t6:C_eqp(t4,lf[615]));
if(C_truep(t7)){
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=lf[735];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_eqp(t4,lf[618]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9124,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_9124(t10,t8);}
else{
t10=C_eqp(t4,lf[435]);
if(C_truep(t10)){
t11=t9;
f_9124(t11,t10);}
else{
t11=C_eqp(t4,lf[611]);
if(C_truep(t11)){
t12=t9;
f_9124(t12,t11);}
else{
t12=C_eqp(t4,lf[616]);
if(C_truep(t12)){
t13=t9;
f_9124(t13,t12);}
else{
t13=C_eqp(t4,lf[617]);
t14=t9;
f_9124(t14,(C_truep(t13)?t13:C_eqp(t4,lf[619])));}}}}}}}

/* err in foreign-argument-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_9096(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_9096,2,t0,t1);}
/* c-backend.scm:1228: quit */
t2=*((C_word*)lf[646]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[733];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* for-each-loop1120 in generate-foreign-callback-stub-prototypes in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_7002(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_7002,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7012,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6988,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:983: gen */
t8=*((C_word*)lf[1]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5329 in doloop705 in k5376 in k5373 in k5402 in k5364 in k5361 in k5358 in k5355 in k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5331(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_5331,2,av);}
a=C_alloc(8);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=C_a_i_minus(&a,2,((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_5321(t4,((C_word*)t0)[5],t2,t3);}

/* k3492 in for-each-loop305 in k3468 in k3460 in k3446 in k3443 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3494(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3494,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_3484(t4,((C_word*)t0)[5],t2,t3);}

/* a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5347(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5347,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5351,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:627: lambda-literal-argument-count */
t5=*((C_word*)lf[301]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7158 in k7128 in k7125 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in ... */
static void C_ccall f_7160(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_7160,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:1043: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=C_make_character(40);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k8470 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8472(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,3))){C_save_and_reclaim((void *)f_8472,2,av);}
a=C_alloc(19);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8476,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_i_cddr(((C_word*)t0)[3]);
t9=C_i_check_list_2(t8,lf[700]);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8494,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8496,a[2]=t6,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_8496(t14,t10,t8);}

/* k8474 in k8470 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8476(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_8476,2,av);}
/* c-backend.scm:1186: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[698];
av2[4]=t1;
av2[5]=lf[699];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k3471 in k3468 in k3460 in k3446 in k3443 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3473(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_3473,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3476,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm:270: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[98];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
/* c-backend.scm:269: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[99];
av2[4]=((C_word*)t0)[4];
av2[5]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}}

/* k3474 in k3471 in k3468 in k3460 in k3446 in k3443 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3476(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3476,2,av);}
/* c-backend.scm:270: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[98];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3468 in k3460 in k3446 in k3443 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3470(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_3470,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3484,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3484(t6,t2,((C_word*)t0)[5],t1);}

/* k7167 in k7164 in k7161 in k7158 in k7128 in k7125 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in ... */
static void C_ccall f_7169(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_7169,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7172,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1046: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[533];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7164 in k7161 in k7158 in k7128 in k7125 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in ... */
static void C_ccall f_7166(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_7166,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(((C_word*)t0)[5],lf[534]);
if(C_truep(t3)){
t4=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_7169(2,av2);}}
else{
/* c-backend.scm:1045: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k7161 in k7158 in k7128 in k7125 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in ... */
static void C_ccall f_7163(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_7163,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7197,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7201,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1044: make-argument-list */
t5=*((C_word*)lf[304]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
av2[3]=lf[535];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* doloop705 in k5376 in k5373 in k5402 in k5364 in k5361 in k5358 in k5355 in k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5321(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,7))){
C_save_and_reclaim_args((void *)trf_5321,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_greater_or_equalp(t2,((C_word*)t0)[2]))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5331,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:623: gen */
t5=*((C_word*)lf[1]+1);{
C_word av2[8];
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[306];
av2[4]=t2;
av2[5]=lf[307];
av2[6]=t3;
av2[7]=lf[308];
((C_proc)(void*)(*((C_word*)t5+1)))(8,av2);}}}

/* k8492 in k8470 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8494(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8494,2,av);}
/* c-backend.scm:1189: string-intersperse */
t2=*((C_word*)lf[256]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[701];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop1603 in k8470 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8496(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_8496,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8521,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[190]+1);
/* c-backend.scm:1190: g1626 */
t6=*((C_word*)lf[190]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[702];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7170 in k7167 in k7164 in k7161 in k7158 in k7128 in k7125 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in ... */
static void C_ccall f_7172(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_7172,2,av);}
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:1048: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[529];
av2[4]=C_SCHEME_TRUE;
av2[5]=lf[530];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}
else{
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:1050: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[531];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
/* c-backend.scm:1051: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[532];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}}

/* k6684 in for-each-loop1025 in k6647 in for-each-loop1012 in k6702 in k6642 in emit-debug-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6686(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6686,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6676(t3,((C_word*)t0)[4],t2);}

/* k3451 in g280 in k3446 in k3443 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3453(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3453,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3456,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:263: expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2625(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k3454 in k3451 in g280 in k3446 in k3443 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3456(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3456,2,av);}
/* c-backend.scm:264: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k9362 in k9353 in k9344 in k9149 in k9122 in foreign-argument-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9364(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_9364,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=t1;
if(C_truep(C_i_vectorp(t3))){
t4=C_i_vector_ref(t3,C_fix(0));
/* c-backend.scm:1274: foreign-argument-conversion */
t5=*((C_word*)lf[189]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
/* c-backend.scm:1274: foreign-argument-conversion */
t4=*((C_word*)lf[189]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9391,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[3]))){
t3=((C_word*)t0)[3];
t4=C_u_i_length(t3);
t5=t2;
f_9391(t5,C_fixnum_greater_or_equal_p(t4,C_fix(2)));}
else{
t3=t2;
f_9391(t3,C_SCHEME_FALSE);}}}

/* k6669 in k6647 in for-each-loop1012 in k6702 in k6642 in emit-debug-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6671,2,av);}
/* c-backend.scm:903: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[487];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* for-each-loop1025 in k6647 in for-each-loop1012 in k6702 in k6642 in emit-debug-table in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_6676(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,2))){
C_save_and_reclaim_args((void *)trf_6676,3,t0,t1,t2);}
a=C_alloc(11);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6686,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6658,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6662,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:901: ->string */
t8=*((C_word*)lf[490]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* for-each-loop305 in k3468 in k3460 in k3446 in k3443 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_3484(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,7))){
C_save_and_reclaim_args((void *)trf_3484,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3494,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* c-backend.scm:267: gen */
t9=*((C_word*)lf[1]+1);{
C_word av2[8];
av2[0]=t9;
av2[1]=t6;
av2[2]=C_SCHEME_TRUE;
av2[3]=C_make_character(116);
av2[4]=t8;
av2[5]=lf[100];
av2[6]=t7;
av2[7]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t9+1)))(8,av2);}}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k7195 in k7161 in k7158 in k7128 in k7125 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in ... */
static void C_ccall f_7197(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7197,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[1]+1);
av2[3]=t1;
C_apply(4,av2);}}

/* k4434 in k4431 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4436(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_4436,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:446: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[213];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4437 in k4434 in k4431 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4439(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4439,2,av);}
a=C_alloc(7);
t2=C_i_car(((C_word*)t0)[2]);
t3=C_u_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4450,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4450(t7,((C_word*)t0)[6],t2,t3);}

/* k4431 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4433,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:445: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k9353 in k9344 in k9149 in k9122 in foreign-argument-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_9355(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_9355,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[772];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[12]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[773];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
/* c-backend.scm:1272: ##sys#hash-table-ref */
t4=*((C_word*)lf[10]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[590]+1);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_9364(2,av2);}}}}}

/* k6253 in k6238 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in ... */
static void C_fcall f_6255(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,7))){
C_save_and_reclaim_args((void *)trf_6255,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:824: gen */
t2=*((C_word*)lf[1]+1);{
C_word av2[8];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[407];
av2[4]=((C_word*)t0)[3];
av2[5]=lf[408];
av2[6]=((C_word*)t0)[3];
av2[7]=lf[409];
((C_proc)(void*)(*((C_word*)t2+1)))(8,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_6243(2,av2);}}}

/* k3460 in k3446 in k3443 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3462(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_3462,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3470,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:268: iota */
t4=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
av2[3]=C_fix(1);
av2[4]=C_fix(1);
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4801 in k4798 in k4795 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4803(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_4803,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4806,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[246]+1))){
/* c-backend.scm:524: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[247];
av2[3]=*((C_word*)lf[246]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4867,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:526: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[249];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k4804 in k4801 in k4798 in k4795 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4806(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,8))){C_save_and_reclaim((void *)f_4806,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:528: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[242];
av2[4]=C_SCHEME_TRUE;
av2[5]=C_SCHEME_TRUE;
av2[6]=lf[243];
av2[7]=*((C_word*)lf[244]+1);
av2[8]=lf[245];
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k4807 in k4804 in k4801 in k4798 in k4795 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4809(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4809,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4812,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[238]+1))){
/* c-backend.scm:530: generate-foreign-callback-stub-prototypes */
t3=*((C_word*)lf[239]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[240]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_4812(2,av2);}}}

/* k6280 in k6277 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in ... */
static void C_ccall f_6282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_6282,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm:831: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[424];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6285(2,av2);}}}

/* k4798 in k4795 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4800,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4803,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:523: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6286 in k6283 in k6280 in k6277 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in ... */
static void C_ccall f_6288(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_6288,2,av);}
a=C_alloc(6);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:846: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_make_character(123);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6297,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(*((C_word*)lf[405]+1))){
/* c-backend.scm:840: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[416];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6297(2,av2);}}}}

/* k6283 in k6280 in k6277 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in ... */
static void C_ccall f_6285(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_6285,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6313,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=*((C_word*)lf[136]+1);
if(C_truep(*((C_word*)lf[136]+1))){
t5=t3;
f_6313(t5,C_SCHEME_FALSE);}
else{
t5=*((C_word*)lf[410]+1);
t6=t3;
f_6313(t6,(C_truep(*((C_word*)lf[410]+1))?C_SCHEME_FALSE:C_i_not(((C_word*)t0)[4])));}}
else{
t4=t3;
f_6313(t4,C_SCHEME_FALSE);}}

/* k8466 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8468(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_8468,2,av);}
/* c-backend.scm:1185: str */
t2=((C_word*)t0)[2];
f_8050(t2,((C_word*)t0)[3],t1);}

/* k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8461(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_8461,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8472,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1187: foreign-type-declaration */
t5=*((C_word*)lf[190]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[703];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8538,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[7],C_fix(2));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=t2;
f_8538(t5,C_eqp(lf[582],t4));}
else{
t4=t2;
f_8538(t4,C_SCHEME_FALSE);}}}

/* k7301 in k7298 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 in ... */
static void C_ccall f_7303(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7303,2,av);}
/* c-backend.scm:1018: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[552];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7298 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7300(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_7300,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7303,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7310,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7318,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1017: make-variable-list */
t5=*((C_word*)lf[299]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[554];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k6277 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in ... */
static void C_ccall f_6279(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_6279,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=*((C_word*)lf[136]+1);
if(C_truep(*((C_word*)lf[136]+1))){
t4=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_6282(2,av2);}}
else{
t4=*((C_word*)lf[393]+1);
if(C_truep(*((C_word*)lf[393]+1))){
t5=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_6282(2,av2);}}
else{
/* c-backend.scm:830: gen */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[425];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6282(2,av2);}}}

/* k6660 in for-each-loop1025 in k6647 in for-each-loop1012 in k6702 in k6642 in emit-debug-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6662(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6662,2,av);}
/* c-backend.scm:901: backslashify */
t2=*((C_word*)lf[154]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6656 in for-each-loop1025 in k6647 in for-each-loop1012 in k6702 in k6642 in emit-debug-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6658(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6658,2,av);}
/* c-backend.scm:901: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[488];
av2[3]=t1;
av2[4]=lf[489];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6295 in k6286 in k6283 in k6280 in k6277 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in ... */
static void C_ccall f_6297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,7))){C_save_and_reclaim((void *)f_6297,2,av);}
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:841: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[412];
av2[4]=((C_word*)t0)[4];
av2[5]=lf[413];
av2[6]=((C_word*)t0)[5];
av2[7]=lf[414];
((C_proc)(void*)(*((C_word*)t2+1)))(8,av2);}}
else{
/* c-backend.scm:841: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[412];
av2[4]=((C_word*)t0)[4];
av2[5]=lf[415];
av2[6]=((C_word*)t0)[5];
av2[7]=lf[414];
((C_proc)(void*)(*((C_word*)t2+1)))(8,av2);}}}

/* k3103 in k3097 in k3083 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3105(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_3105,2,av);}
a=C_alloc(4);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* c-backend.scm:173: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[58];
av2[3]=t2;
av2[4]=lf[59];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k7308 in k7298 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 in ... */
static void C_ccall f_7310(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7310,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[1]+1);
av2[3]=t1;
C_apply(4,av2);}}

/* k7316 in k7298 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 in ... */
static void C_ccall f_7318(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_7318,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,lf[553],t1);
/* c-backend.scm:1017: intersperse */
t3=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
av2[3]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* for-each-loop185 in k3097 in k3083 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_3114(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_3114,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3124,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* c-backend.scm:167: g186 */
t9=((C_word*)t0)[3];
f_3086(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k4953 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4955(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4955,2,av);}
/* c-backend.scm:508: ##sys#decode-seconds */
t2=*((C_word*)lf[263]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6207 in k6175 in k6172 in k6169 in k6165 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in ... */
static void C_ccall f_6209(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_6209,2,av);}
if(C_truep(*((C_word*)lf[386]+1))){
/* c-backend.scm:806: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[387];
av2[4]=*((C_word*)lf[386]+1);
av2[5]=lf[388];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
f_6180(2,av2);}}}

/* k6642 in emit-debug-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6644(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_6644,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6704,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6738,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm:904: sort */
t4=*((C_word*)lf[493]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* emit-debug-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6640(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_6640,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6644,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:895: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
av2[3]=C_SCHEME_TRUE;
av2[4]=lf[494];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k10584 in encode-literal in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(2,c,3))){C_save_and_reclaim((void *)f_10586,2,av);}
a=C_alloc(2);
t2=((C_word*)t0)[2];
t3=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1375: string-append */
t4=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k6647 in for-each-loop1012 in k6702 in k6642 in emit-debug-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6649(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_6649,2,av);}
a=C_alloc(8);
t2=C_i_cddr(((C_word*)t0)[2]);
t3=C_i_check_list_2(t2,lf[57]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6671,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6676,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_6676(t8,t4,t2);}

/* g1957 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_10059(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_10059,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* c-backend.scm:1325: foreign-result-conversion */
t4=*((C_word*)lf[184]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=t2;
/* c-backend.scm:1325: foreign-result-conversion */
t4=*((C_word*)lf[184]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k4945 in k4888 in k4884 in k4880 in k4876 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4947(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4947,2,av);}
/* c-backend.scm:519: string-split */
t2=*((C_word*)lf[260]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[261];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10055(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_10055,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10059,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1323: g1957 */
t3=t2;
f_10059(t3,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10082,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[4];
t4=C_u_i_length(t3);
t5=t2;
f_10082(t5,C_fixnum_greater_or_equal_p(t4,C_fix(2)));}
else{
t3=t2;
f_10082(t3,C_SCHEME_FALSE);}}}

/* k5463 in k5460 in k5457 in k5454 in k5448 in doloop728 in literal-frame in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5465(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5465,2,av);}
/* c-backend.scm:648: gen-lit */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5665(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k5460 in k5457 in k5454 in k5448 in doloop728 in literal-frame in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5462(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5462,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:648: get-output-string */
t3=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* literal-size in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5473(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5473,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5480,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:654: immediate? */
t4=*((C_word*)lf[329]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3862 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3864(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3864,2,av);}
t2=((C_word*)t0)[2];
f_3402(t2,C_i_zerop(t1));}

/* k3866 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3868,2,av);}
/* c-backend.scm:239: lambda-literal-closure-size */
t2=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4993 in k4990 in k4987 in k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4995(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4995,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5000,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5000(t5,((C_word*)t0)[2],C_fix(0),((C_word*)t0)[3]);}

/* k4990 in k4987 in k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_4992,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:555: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[270];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4045(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_4045,2,av);}
a=C_alloc(8);
t2=C_i_zerop(t1);
t3=t2;
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:338: lambda-literal-temporaries */
t5=*((C_word*)lf[101]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4029,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:351: gen */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[11];
av2[3]=C_make_character(40);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k3855 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_3857,2,av);}
/* c-backend.scm:249: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[155];
av2[4]=t1;
av2[5]=lf[156];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k5251 in k5248 in k5245 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5253(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5253,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5256,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:592: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[289];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
/* c-backend.scm:593: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[290];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k3848 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3850(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_3850,2,av);}
/* c-backend.scm:247: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[152];
av2[4]=t1;
av2[5]=lf[153];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k2994 in k2991 in k2988 in k2985 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2996(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2996,2,av);}
/* c-backend.scm:148: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5254 in k5251 in k5248 in k5245 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 in ... */
static void C_ccall f_5256(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5256,2,av);}
/* c-backend.scm:594: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4987 in k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4989(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,6))){C_save_and_reclaim((void *)f_4989,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t3)){
t4=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_4992(2,av2);}}
else{
/* c-backend.scm:554: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=C_SCHEME_TRUE;
av2[4]=lf[271];
av2[5]=((C_word*)t0)[4];
av2[6]=lf[272];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}}}

/* k2991 in k2988 in k2985 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2993(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_2993,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2996,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:147: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k2988 in k2985 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2990(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_2990,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[6]);
t4=C_a_i_plus(&a,2,t3,C_fix(1));
/* c-backend.scm:146: gen */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=lf[45];
av2[3]=t4;
av2[4]=lf[46];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k5248 in k5245 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5250(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5250,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm:590: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[291];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
/* c-backend.scm:590: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[292];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k2985 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2987(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_2987,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:145: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k4033 in k4030 in k4027 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4035(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4035,2,av);}
/* c-backend.scm:354: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4030 in k4027 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4032(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4032,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4035,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:353: expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4632(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k9389 in k9362 in k9353 in k9344 in k9149 in k9122 in foreign-argument-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_9391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,4))){
C_save_and_reclaim_args((void *)trf_9391,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_eqp(t2,lf[583]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[774];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(t2,lf[585]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t5;
av2[1]=lf[775];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eqp(t2,lf[587]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t6;
av2[1]=lf[776];
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(t2,lf[588]);
if(C_truep(t6)){
t7=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t7;
av2[1]=lf[777];
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_eqp(t2,lf[731]);
if(C_truep(t7)){
t8=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t8;
av2[1]=lf[778];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_eqp(t2,lf[732]);
if(C_truep(t8)){
t9=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t9;
av2[1]=lf[779];
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t9=C_eqp(t2,lf[586]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t10;
av2[1]=lf[780];
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=C_eqp(t2,lf[582]);
if(C_truep(t10)){
t11=C_i_cadr(((C_word*)t0)[2]);
/* c-backend.scm:1284: foreign-argument-conversion */
t12=*((C_word*)lf[189]+1);{
C_word av2[3];
av2[0]=t12;
av2[1]=((C_word*)t0)[3];
av2[2]=t11;
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
t11=C_eqp(t2,lf[723]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t12;
av2[1]=lf[781];
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
else{
t12=C_eqp(t2,lf[580]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9468,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t14=C_i_cadr(((C_word*)t0)[2]);
/* c-backend.scm:1287: foreign-type-declaration */
t15=*((C_word*)lf[190]+1);{
C_word av2[4];
av2[0]=t15;
av2[1]=t13;
av2[2]=t14;
av2[3]=lf[784];
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}
else{
t13=C_eqp(t2,lf[589]);
if(C_truep(t13)){
t14=C_i_cadr(((C_word*)t0)[2]);
/* c-backend.scm:1290: string-append */
t15=*((C_word*)lf[114]+1);{
C_word av2[5];
av2[0]=t15;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[785];
av2[3]=t14;
av2[4]=lf[786];
((C_proc)(void*)(*((C_word*)t15+1)))(5,av2);}}
else{
/* c-backend.scm:1291: err */
t14=((C_word*)t0)[4];
f_9096(t14,((C_word*)t0)[3]);}}}}}}}}}}}}
else{
/* c-backend.scm:1292: err */
t2=((C_word*)t0)[4];
f_9096(t2,((C_word*)t0)[3]);}}

/* k4027 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4029(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_4029,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11669,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:353: expr-args */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4632(t4,t3,((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
/* c-backend.scm:352: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[163];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k3234 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3236(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3236,2,av);}
/* c-backend.scm:194: c-ify-string */
t2=*((C_word*)lf[72]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3230 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3232(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_3232,2,av);}
/* c-backend.scm:193: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[70];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[71];
av2[5]=t1;
av2[6]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* k7469 in k7432 in k7426 in k7414 in k7402 in k7393 in compute-size in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_7471(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_7471,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1087: string-append */
t2=*((C_word*)lf[114]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[581];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[582]);
if(C_truep(t2)){
t3=C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm:1088: compute-size */
t4=((C_word*)((C_word*)t0)[6])[1];{
C_word av2[5];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
av2[3]=((C_word*)t0)[7];
av2[4]=((C_word*)t0)[3];
f_7385(5,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}}

/* k5245 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5247,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:589: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[293];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5478 in literal-size in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5480(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_5480,2,av);}
a=C_alloc(15);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_numberp(((C_word*)t0)[3]))){
t2=*((C_word*)lf[321]+1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=*((C_word*)lf[321]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(7);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
/* c-backend.scm:658: literal-size */
t5=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
f_5473(3,av2);}}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[3];
t3=C_block_size(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5536,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=((C_word*)((C_word*)t0)[4])[1];
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5543,a[2]=t5,a[3]=t8,a[4]=t10,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:659: vector->list */
t12=*((C_word*)lf[324]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t12;
av2[1]=t11;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:660: block-variable-literal? */
t3=*((C_word*)lf[328]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}}}}}}

/* k3051 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3053(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_3053,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:159: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k3054 in k3051 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3056(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3056,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:160: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[52];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3057 in k3054 in k3051 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3059(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3059,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3062,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:161: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k5413 in k5358 in k5355 in k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5415(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5415,2,av);}
t2=((C_word*)t0)[2];
f_5363(t2,C_i_zerop(t1));}

/* k4083 in k4080 in k4077 in k4074 in k4126 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4085,2,av);}
/* c-backend.scm:374: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4080 in k4077 in k4074 in k4126 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4082(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4082,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4085,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm:373: expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4632(t3,t2,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
/* c-backend.scm:374: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* literal-frame in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5417(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_5417,2,t0,t1);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5423,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5423(t5,t1,C_fix(0),((C_word*)t0)[3]);}

/* k2955 in k2952 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2957(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2957,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[6]);
/* c-backend.scm:139: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=C_make_character(44);
av2[3]=t3;
av2[4]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2952 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2954(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_2954,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:138: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k4077 in k4074 in k4126 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_4079,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_4082(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4097,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:371: expr */
t4=((C_word*)((C_word*)t0)[7])[1];
f_2625(t4,t3,((C_word*)t0)[8],((C_word*)t0)[5]);}}

/* k4074 in k4126 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,4))){C_save_and_reclaim((void *)f_4076,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[9])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4109,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:368: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[165];
av2[3]=((C_word*)t0)[10];
av2[4]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_4079(2,av2);}}}

/* k3282 in k3265 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3284(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3284,2,av);}
/* c-backend.scm:206: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[79];
av2[3]=t1;
av2[4]=lf[80];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3286 in k3265 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3288(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3288,2,av);}
/* c-backend.scm:206: uncommentify */
t2=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4149 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4151(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4151,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:382: push-args */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4661(t3,t2,((C_word*)t0)[6],((C_word*)t0)[7],lf[170]);}

/* k9828 in k9825 in k9822 in k9816 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9830(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9830,2,av);}
/* c-backend.scm:1308: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4152 in k4149 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,7))){C_save_and_reclaim((void *)f_4154,2,av);}
t2=C_i_car(((C_word*)t0)[2]);
/* c-backend.scm:383: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[167];
av2[4]=t2;
av2[5]=lf[168];
av2[6]=((C_word*)t0)[4];
av2[7]=lf[169];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k3271 in k3268 in k3265 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3273(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3273,2,av);}
/* c-backend.scm:208: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7426 in k7414 in k7402 in k7393 in compute-size in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_7428(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,5))){
C_save_and_reclaim_args((void *)trf_7428,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
/* c-backend.scm:1078: string-append */
t2=*((C_word*)lf[114]+1);{
C_word av2[6];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[578];
av2[4]=((C_word*)t0)[4];
av2[5]=lf[579];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7434,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[6]))){
/* c-backend.scm:1080: ##sys#hash-table-ref */
t3=*((C_word*)lf[10]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[590]+1);
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_7434(2,av2);}}}}

/* k3268 in k3265 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3270,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3273,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:207: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_8555,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1196: ->string */
t4=*((C_word*)lf[490]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[6],C_fix(2));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=t2;
f_8572(t5,C_eqp(lf[724],t4));}
else{
t4=t2;
f_8572(t4,C_SCHEME_FALSE);}}}

/* k9816 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_9818,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9824,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1308: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[796];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4130 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4132(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4132,2,av);}
/* c-backend.scm:364: lambda-literal-closure-size */
t2=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8519 in map-loop1603 in k8470 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8521(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8521,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8496(t6,((C_word*)t0)[5],t5);}

/* k9843 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_9845,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9851,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1312: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[798];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k6380 in for-each-loop885 in k6371 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in ... */
static void C_ccall f_6382(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_6382,2,av);}
t2=C_u_i_car(((C_word*)t0)[2]);
/* c-backend.scm:789: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_TRUE;
av2[3]=t1;
av2[4]=C_make_character(32);
av2[5]=t2;
av2[6]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k4126 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4128(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_4128,2,av);}
a=C_alloc(11);
t2=C_i_zerop(t1);
t3=t2;
t4=C_u_i_car(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:366: gen */
t6=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[10];
av2[3]=C_make_character(40);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_9842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_9842,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1312: open-output-string */
t3=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[583]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1313: open-output-string */
t4=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[4],lf[602]);
t4=(C_truep(t3)?t3:C_eqp(((C_word*)t0)[4],lf[603]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1314: open-output-string */
t6=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_eqp(((C_word*)t0)[4],lf[608]);
t6=(C_truep(t5)?t5:C_eqp(((C_word*)t0)[4],lf[607]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1315: open-output-string */
t8=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=C_eqp(((C_word*)t0)[4],lf[605]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1316: open-output-string */
t9=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t8=C_eqp(((C_word*)t0)[4],lf[599]);
t9=(C_truep(t8)?t8:C_eqp(((C_word*)t0)[4],lf[600]));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1317: open-output-string */
t11=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t11;
av2[1]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t10=C_eqp(((C_word*)t0)[4],lf[601]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1318: open-output-string */
t12=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t12;
av2[1]=t11;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
else{
t11=C_eqp(((C_word*)t0)[4],lf[604]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1319: open-output-string */
t13=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t13;
av2[1]=t12;
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t12=C_eqp(((C_word*)t0)[4],lf[12]);
if(C_truep(t12)){
t13=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t13;
av2[1]=lf[808];
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t13=C_eqp(((C_word*)t0)[4],lf[534]);
t14=(C_truep(t13)?t13:C_eqp(((C_word*)t0)[4],lf[614]));
if(C_truep(t14)){
t15=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t15;
av2[1]=lf[809];
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10055,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[5]))){
/* c-backend.scm:1323: ##sys#hash-table-ref */
t16=*((C_word*)lf[10]+1);{
C_word av2[4];
av2[0]=t16;
av2[1]=t15;
av2[2]=*((C_word*)lf[590]+1);
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t16+1)))(4,av2);}}
else{
t16=t15;{
C_word av2[2];
av2[0]=t16;
av2[1]=C_SCHEME_FALSE;
f_10055(2,av2);}}}}}}}}}}}}}

/* k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_8538,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8545,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:1194: foreign-type-declaration */
t4=*((C_word*)lf[190]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[6],C_fix(2));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[3]);
t5=t2;
f_8555(t5,C_eqp(lf[725],t4));}
else{
t4=t2;
f_8555(t4,C_SCHEME_FALSE);}}}

/* declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_4971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_4971,2,t0,t1);}
a=C_alloc(5);
t2=C_i_length(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4978,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:547: gen */
t5=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
av2[3]=C_SCHEME_TRUE;
av2[4]=lf[277];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k4976 in declarations in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4978(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_4978,2,av);}
a=C_alloc(10);
t2=*((C_word*)lf[248]+1);
t3=C_i_check_list_2(*((C_word*)lf[248]+1),lf[57]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5120,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_5120(t8,t4,*((C_word*)lf[248]+1));}

/* k2958 in k2955 in k2952 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2960(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_2960,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2963,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:140: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k2961 in k2958 in k2955 in k2952 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2963(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2963,2,av);}
/* c-backend.scm:141: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6371 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in ... */
static void C_ccall f_6373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6373,2,av);}
a=C_alloc(5);
t2=C_i_check_list_2(((C_word*)t0)[2],lf[57]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6396,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6396(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4521 in k4518 in k4515 in k4512 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4523(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_4523,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:463: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(58);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4524 in k4521 in k4518 in k4515 in k4512 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4526,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4529,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_caddr(((C_word*)t0)[3]);
/* c-backend.scm:464: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k4527 in k4524 in k4521 in k4518 in k4515 in k4512 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4529(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4529,2,av);}
/* c-backend.scm:465: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4518 in k4515 in k4512 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4520(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_4520,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:462: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k9825 in k9822 in k9816 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_9827,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1308: ##sys#write-char-0 */
t3=*((C_word*)lf[317]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(44);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4963 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6595 in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,10))){C_save_and_reclaim((void *)f_4965,2,av);}
/* c-backend.scm:538: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 11) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(11);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=C_SCHEME_TRUE;
av2[4]=lf[471];
av2[5]=C_SCHEME_TRUE;
av2[6]=t1;
av2[7]=lf[472];
av2[8]=C_SCHEME_TRUE;
av2[9]=lf[473];
av2[10]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(11,av2);}}

/* k9822 in k9816 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9824(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_9824,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1308: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4967 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6595 in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4969(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4969,2,av);}
/* c-backend.scm:539: uncommentify */
t2=*((C_word*)lf[81]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5402 in k5364 in k5361 in k5358 in k5355 in k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5404(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,10))){C_save_and_reclaim((void *)f_5404,2,av);}
a=C_alloc(5);
t2=(C_truep(t1)?C_SCHEME_FALSE:((C_word*)t0)[2]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5375,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:634: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 11) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(11);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
av2[3]=C_SCHEME_TRUE;
av2[4]=lf[311];
av2[5]=((C_word*)t0)[5];
av2[6]=lf[312];
av2[7]=C_SCHEME_TRUE;
av2[8]=lf[313];
av2[9]=((C_word*)t0)[5];
av2[10]=lf[314];
((C_proc)(void*)(*((C_word*)t4+1)))(11,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4512 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4514(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_4514,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:460: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k4095 in k4077 in k4074 in k4126 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4097(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4097,2,av);}
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
/* c-backend.scm:372: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
f_4082(2,av2);}}}

/* k4515 in k4512 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4517(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_4517,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:461: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[216];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* for-each-loop885 in k6371 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in ... */
static void C_fcall f_6396(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,6))){
C_save_and_reclaim_args((void *)trf_6396,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6406,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6382,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_i_cdr(t6);
t9=C_eqp(t8,lf[428]);
if(C_truep(t9)){
t10=C_u_i_car(t6);
/* c-backend.scm:789: gen */
t11=*((C_word*)lf[1]+1);{
C_word av2[7];
av2[0]=t11;
av2[1]=t5;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[429];
av2[4]=C_make_character(32);
av2[5]=t10;
av2[6]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t11+1)))(7,av2);}}
else{
t10=C_eqp(t8,lf[430]);
if(C_truep(t10)){
t11=C_u_i_car(t6);
/* c-backend.scm:789: gen */
t12=*((C_word*)lf[1]+1);{
C_word av2[7];
av2[0]=t12;
av2[1]=t5;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[431];
av2[4]=C_make_character(32);
av2[5]=t11;
av2[6]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t12+1)))(7,av2);}}
else{
t11=C_eqp(t8,lf[15]);
if(C_truep(t11)){
t12=C_u_i_car(t6);
/* c-backend.scm:789: gen */
t13=*((C_word*)lf[1]+1);{
C_word av2[7];
av2[0]=t13;
av2[1]=t5;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[432];
av2[4]=C_make_character(32);
av2[5]=t12;
av2[6]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t13+1)))(7,av2);}}
else{
t12=C_eqp(t8,lf[433]);
if(C_truep(t12)){
t13=C_u_i_car(t6);
/* c-backend.scm:789: gen */
t14=*((C_word*)lf[1]+1);{
C_word av2[7];
av2[0]=t14;
av2[1]=t5;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[434];
av2[4]=C_make_character(32);
av2[5]=t13;
av2[6]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t14+1)))(7,av2);}}
else{
t13=C_eqp(t8,lf[435]);
if(C_truep(t13)){
t14=C_u_i_car(t6);
/* c-backend.scm:789: gen */
t15=*((C_word*)lf[1]+1);{
C_word av2[7];
av2[0]=t15;
av2[1]=t5;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[436];
av2[4]=C_make_character(32);
av2[5]=t14;
av2[6]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t15+1)))(7,av2);}}
else{
t14=C_eqp(t8,lf[12]);
if(C_truep(t14)){
t15=C_u_i_car(t6);
/* c-backend.scm:789: gen */
t16=*((C_word*)lf[1]+1);{
C_word av2[7];
av2[0]=t16;
av2[1]=t5;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[437];
av2[4]=C_make_character(32);
av2[5]=t15;
av2[6]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t16+1)))(7,av2);}}
else{
/* c-backend.scm:724: bomb */
t15=*((C_word*)lf[8]+1);{
C_word av2[4];
av2[0]=t15;
av2[1]=t7;
av2[2]=lf[438];
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}}}}}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k10848 in k10835 in k10832 in k10829 in k10823 in k2515 in k2512 in k2509 */
static void C_ccall f_10850(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10850,2,av);}
/* c-backend.scm:57: ##sys#print */
t2=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k10852 in k10829 in k10823 in k2515 in k2512 in k2509 */
static void C_ccall f_10854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10854,2,av);}
/* c-backend.scm:57: ##sys#print */
t2=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k10856 in k10829 in k10823 in k2515 in k2512 in k2509 */
static void C_ccall f_10858(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_10858,2,av);}
/* c-backend.scm:57: number->string */
t2=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_fix(16);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k7224 in for-each-loop1181 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in ... */
static void C_fcall f_7226(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(20,0,2))){
C_save_and_reclaim_args((void *)trf_7226,2,t0,t1);}
a=C_alloc(20);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(0));
t4=C_slot(((C_word*)t0)[3],C_fix(0));
t5=C_slot(((C_word*)t0)[4],C_fix(0));
t6=t2;
t7=t3;
t8=t4;
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7088,a[2]=t6,a[3]=t8,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7100,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
/* c-backend.scm:1025: symbol->string */
t11=*((C_word*)lf[542]+1);{
C_word av2[3];
av2[0]=t11;
av2[1]=t10;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7106,a[2]=t10,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1025: open-output-string */
t12=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t12;
av2[1]=t11;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[6];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7227 in k7224 in for-each-loop1181 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in ... */
static void C_ccall f_7229(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_7229,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[5])[1];
f_7219(t5,((C_word*)t0)[6],t2,t3,t4);}

/* k9801 in k9798 in k9792 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9803(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_9803,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1307: ##sys#write-char-0 */
t3=*((C_word*)lf[317]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(44);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k9804 in k9801 in k9798 in k9792 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9806(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9806,2,av);}
/* c-backend.scm:1307: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k9798 in k9792 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_9800,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1307: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3714 in k3697 in k3657 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3716(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3716,2,av);}
/* c-backend.scm:308: c-ify-string */
t2=*((C_word*)lf[72]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3710 in k3697 in k3657 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3712(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_3712,2,av);}
/* c-backend.scm:307: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[121];
av2[3]=((C_word*)((C_word*)t0)[3])[1];
av2[4]=lf[122];
av2[5]=t1;
av2[6]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* k8543 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8545(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8545,2,av);}
/* c-backend.scm:1194: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[704];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* err in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_9727(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_9727,2,t0,t1);}
/* c-backend.scm:1298: quit */
t2=*((C_word*)lf[646]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[787];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##compiler#foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_9725,4,av);}
a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9727,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=C_eqp(t5,lf[15]);
t7=(C_truep(t6)?t6:C_eqp(t5,lf[615]));
if(C_truep(t7)){
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=lf[788];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_eqp(t5,lf[435]);
t9=(C_truep(t8)?t8:C_eqp(t5,lf[611]));
if(C_truep(t9)){
t10=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=lf[789];
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=C_eqp(t5,lf[616]);
t11=(C_truep(t10)?t10:C_eqp(t5,lf[617]));
if(C_truep(t11)){
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=lf[790];
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
else{
t12=C_eqp(t5,lf[612]);
if(C_truep(t12)){
t13=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=lf[791];
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t13=C_eqp(t5,lf[613]);
if(C_truep(t13)){
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=lf[792];
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
else{
t14=C_eqp(t5,lf[618]);
if(C_truep(t14)){
t15=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=lf[793];
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t15=C_eqp(t5,lf[619]);
if(C_truep(t15)){
t16=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t16;
av2[1]=lf[794];
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}
else{
t16=C_eqp(t5,lf[571]);
t17=(C_truep(t16)?t16:C_eqp(t5,lf[598]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9794,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1307: open-output-string */
t19=*((C_word*)lf[320]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t19;
av2[1]=t18;
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}
else{
t18=C_eqp(t5,lf[606]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9818,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1308: open-output-string */
t20=*((C_word*)lf[320]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t20;
av2[1]=t19;
((C_proc)(void*)(*((C_word*)t20+1)))(2,av2);}}
else{
t19=C_eqp(t5,lf[577]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9842,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_9842(t21,t19);}
else{
t21=C_eqp(t5,lf[573]);
if(C_truep(t21)){
t22=t20;
f_9842(t22,t21);}
else{
t22=C_eqp(t5,lf[585]);
if(C_truep(t22)){
t23=t20;
f_9842(t23,t22);}
else{
t23=C_eqp(t5,lf[595]);
if(C_truep(t23)){
t24=t20;
f_9842(t24,t23);}
else{
t24=C_eqp(t5,lf[591]);
if(C_truep(t24)){
t25=t20;
f_9842(t25,t24);}
else{
t25=C_eqp(t5,lf[596]);
if(C_truep(t25)){
t26=t20;
f_9842(t26,t25);}
else{
t26=C_eqp(t5,lf[597]);
if(C_truep(t26)){
t27=t20;
f_9842(t27,t26);}
else{
t27=C_eqp(t5,lf[592]);
if(C_truep(t27)){
t28=t20;
f_9842(t28,t27);}
else{
t28=C_eqp(t5,lf[593]);
if(C_truep(t28)){
t29=t20;
f_9842(t29,t28);}
else{
t29=C_eqp(t5,lf[594]);
if(C_truep(t29)){
t30=t20;
f_9842(t30,t29);}
else{
t30=C_eqp(t5,lf[609]);
t31=t20;
f_9842(t31,(C_truep(t30)?t30:C_eqp(t5,lf[610])));}}}}}}}}}}}}}}}}}}}}

/* k10838 in k10835 in k10832 in k10829 in k10823 in k2515 in k2512 in k2509 */
static void C_ccall f_10840(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_10840,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:57: ##sys#write-char-0 */
t3=*((C_word*)lf[317]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(95);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k10841 in k10838 in k10835 in k10832 in k10829 in k10823 in k2515 in k2512 in k2509 */
static void C_ccall f_10843(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_10843,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10846,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:57: get-output-string */
t3=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k10844 in k10841 in k10838 in k10835 in k10832 in k10829 in k10823 in k2515 in k2512 in k2509 */
static void C_ccall f_10846(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10846,2,av);}
/* c-backend.scm:56: string->c-identifier */
t2=*((C_word*)lf[511]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5373 in k5402 in k5364 in k5361 in k5358 in k5355 in k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5375(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,5))){C_save_and_reclaim((void *)f_5375,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:636: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[309];
av2[4]=((C_word*)t0)[4];
av2[5]=lf[310];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k5376 in k5373 in k5402 in k5364 in k5361 in k5358 in k5355 in k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5378(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,4))){C_save_and_reclaim((void *)f_5378,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5321,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5321(t8,t2,C_fix(0),t4);}

/* k5571 in map-loop755 in k5541 in k5478 in literal-size in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5573,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5548(t6,((C_word*)t0)[5],t5);}

/* k5385 in k5382 in k5379 in k5376 in k5373 in k5402 in k5364 in k5361 in k5358 in k5355 in k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5387(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5387,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5390,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5397,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:640: intersperse */
t4=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t1;
av2[3]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5382 in k5379 in k5376 in k5373 in k5402 in k5364 in k5361 in k5358 in k5355 in k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5384(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_5384,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5387,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:639: make-argument-list */
t3=*((C_word*)lf[304]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=lf[305];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5379 in k5376 in k5373 in k5402 in k5364 in k5361 in k5358 in k5355 in k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5381(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_5381,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:638: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[4];
av2[4]=C_make_character(40);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5354(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5354,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:629: lambda-literal-rest-argument-mode */
t3=*((C_word*)lf[297]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5355 in k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5357(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5357,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5360,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:630: lambda-literal-customizable */
t3=*((C_word*)lf[236]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5351(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_5351,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5354,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:628: lambda-literal-rest-argument */
t5=*((C_word*)lf[298]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10829 in k10823 in k2515 in k2512 in k2509 */
static void C_ccall f_10831(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_10831,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10854,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10858,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:57: random */
t5=*((C_word*)lf[842]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_fix(16777216);
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10835 in k10832 in k10829 in k10823 in k2515 in k2512 in k2509 */
static void C_ccall f_10837(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_10837,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10850,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:57: current-seconds */
t4=*((C_word*)lf[264]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k10832 in k10829 in k10823 in k2515 in k2512 in k2509 */
static void C_ccall f_10834(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_10834,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:57: ##sys#write-char-0 */
t3=*((C_word*)lf[317]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(95);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_3402(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(20,0,7))){
C_save_and_reclaim_args((void *)trf_3402,2,t0,t1);}
a=C_alloc(20);
t2=t1;
t3=C_u_i_car(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3406,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t2,a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[16])){
if(C_truep(*((C_word*)lf[145]+1))){
if(C_truep(((C_word*)t0)[17])){
if(C_truep(((C_word*)((C_word*)t0)[18])[1])){
/* c-backend.scm:244: gen */
t5=*((C_word*)lf[1]+1);{
C_word av2[8];
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[146];
av2[4]=((C_word*)t0)[17];
av2[5]=lf[147];
av2[6]=lf[148];
av2[7]=lf[149];
((C_proc)(void*)(*((C_word*)t5+1)))(8,av2);}}
else{
/* c-backend.scm:244: gen */
t5=*((C_word*)lf[1]+1);{
C_word av2[8];
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[146];
av2[4]=((C_word*)t0)[17];
av2[5]=lf[147];
av2[6]=lf[150];
av2[7]=lf[149];
((C_proc)(void*)(*((C_word*)t5+1)))(8,av2);}}}
else{
t5=t4;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_3406(2,av2);}}}
else{
if(C_truep(*((C_word*)lf[151]+1))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3850,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:247: backslashify */
t6=*((C_word*)lf[154]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[19];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3857,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:249: uncommentify */
t6=*((C_word*)lf[81]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[19];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}}
else{
t5=t4;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_3406(2,av2);}}}

/* k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,2))){C_save_and_reclaim((void *)f_3406,2,av);}
a=C_alloc(21);
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_eqp(lf[32],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3415,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:251: gen */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_make_character(123);
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
if(C_truep(((C_word*)t0)[8])){
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[5],a[15]=((C_word*)t0)[2],tmp=(C_word)a,a+=16,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3633,a[2]=((C_word*)t0)[8],a[3]=t4,a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:256: lambda-literal-id */
t6=*((C_word*)lf[108]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[12];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[16],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=C_slot(((C_word*)t0)[2],C_fix(1));
t6=C_eqp(lf[67],t5);
if(C_truep(t6)){
t7=*((C_word*)lf[136]+1);
if(C_truep(*((C_word*)lf[136]+1))){
t8=t4;
f_3639(t8,C_SCHEME_FALSE);}
else{
t8=*((C_word*)lf[141]+1);
t9=t4;
f_3639(t9,(C_truep(*((C_word*)lf[141]+1))?C_SCHEME_FALSE:C_i_not(((C_word*)t0)[16])));}}
else{
t7=t4;
f_3639(t7,C_SCHEME_FALSE);}}}}

/* k3722 in k3657 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3724(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3724,2,av);}
/* c-backend.scm:304: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[123];
av2[3]=t1;
av2[4]=lf[124];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5364 in k5361 in k5358 in k5355 in k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_5366,2,t0,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:633: lambda-literal-direct */
t3=*((C_word*)lf[235]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5361 in k5358 in k5355 in k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5363(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,2))){
C_save_and_reclaim_args((void *)trf_5363,2,t0,t1);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t3);
t5=t2;
f_5366(t5,t4);}
else{
t3=t2;
f_5366(t3,C_SCHEME_UNDEFINED);}}

/* k5358 in k5355 in k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5360(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_5360,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5363,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5415,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:631: lambda-literal-closure-size */
t5=*((C_word*)lf[157]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=t3;
f_5363(t4,C_SCHEME_FALSE);}}

/* a10800 in k10793 in encode-literal in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10801(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10801,3,av);}
t3=C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm:1414: encode-literal */
t4=*((C_word*)lf[343]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3736 in k3657 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3738(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3738,2,av);}
/* c-backend.scm:311: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[127];
av2[3]=t1;
av2[4]=lf[128];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k2512 in k2509 */
static void C_ccall f_2514(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2514,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_chicken_2dsyntax_toplevel(2,av2);}}

/* k2509 */
static void C_ccall f_2511(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2511,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k3729 in k3657 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3731(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3731,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* c-backend.scm:312: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[125];
av2[3]=((C_word*)((C_word*)t0)[2])[1];
av2[4]=lf[126];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k7908 in for-each-loop1430 in k7865 in k7862 in k7850 in k7847 in k7844 in k7841 in k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7910(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7910,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_7900(t4,((C_word*)t0)[5],t2,t3);}

/* k6311 in k6283 in k6280 in k6277 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in ... */
static void C_fcall f_6313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,7))){
C_save_and_reclaim_args((void *)trf_6313,2,t0,t1);}
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[2],lf[417]);
if(C_truep(t2)){
if(C_truep(C_i_greaterp(((C_word*)t0)[3],C_fix(2)))){
/* c-backend.scm:835: gen */
t3=*((C_word*)lf[1]+1);{
C_word av2[8];
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[418];
av2[4]=((C_word*)t0)[3];
av2[5]=lf[419];
av2[6]=((C_word*)t0)[3];
av2[7]=lf[420];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}
else{
t3=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6288(2,av2);}}}
else{
/* c-backend.scm:836: gen */
t3=*((C_word*)lf[1]+1);{
C_word av2[8];
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[421];
av2[4]=((C_word*)t0)[3];
av2[5]=lf[422];
av2[6]=((C_word*)t0)[3];
av2[7]=lf[423];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}}
else{
t2=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_6288(2,av2);}}}

/* k4694 in doloop534 in k4675 in k4672 in k4669 in push-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4696(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_4696,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:498: expr */
t4=((C_word*)((C_word*)t0)[6])[1];
f_2625(t4,t2,t3,((C_word*)t0)[7]);}

/* k4697 in k4694 in doloop534 in k4675 in k4672 in k4669 in push-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4699(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_4699,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:499: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[220];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* ##compiler#cleanup in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6809(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_6809,3,av);}
a=C_alloc(10);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_i_string_length(t2);
t6=t5;
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6818,a[2]=t6,a[3]=t4,a[4]=t2,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_6818(t10,t1,C_fix(0));}

/* k6805 in emit-procedure-table in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6807(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,8))){C_save_and_reclaim((void *)f_6807,2,av);}
a=C_alloc(4);
t2=C_a_i_plus(&a,2,t1,C_fix(1));
/* c-backend.scm:911: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=C_SCHEME_TRUE;
av2[4]=lf[512];
av2[5]=C_SCHEME_TRUE;
av2[6]=lf[513];
av2[7]=t2;
av2[8]=lf[514];
((C_proc)(void*)(*((C_word*)t3+1)))(9,av2);}}

/* k4280 in k4277 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4282,2,av);}
/* c-backend.scm:414: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[187];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* ##compiler#gen in k2515 in k2512 in k2509 */
static void C_ccall f_2520(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +5,c,3))){
C_save_and_reclaim((void*)f_2520,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+5);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2540,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2540(t6,t1,t2);}

/* for-each-loop1430 in k7865 in k7862 in k7850 in k7847 in k7844 in k7841 in k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_7900(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_7900,4,t0,t1,t2,t3);}
a=C_alloc(10);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7910,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
t9=t6;
t10=t7;
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7861,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1102: foreign-result-conversion */
t12=*((C_word*)lf[184]+1);{
C_word av2[4];
av2[0]=t12;
av2[1]=t11;
av2[2]=t8;
av2[3]=lf[626];
((C_proc)(void*)(*((C_word*)t12+1)))(4,av2);}}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* map-loop755 in k5541 in k5478 in literal-size in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5548(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_5548,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5573,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:659: g761 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5544 in k5541 in k5478 in literal-size in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5546(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5546,2,av);}
/* c-backend.scm:659: reduce */
t2=*((C_word*)lf[322]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[323]+1);
av2[3]=C_fix(0);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k2515 in k2512 in k2509 */
static void C_ccall f_2517(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_2517,2,av);}
a=C_alloc(10);
t2=C_set_block_item(lf[0] /* ##compiler#output */,0,C_SCHEME_FALSE);
t3=C_mutate2((C_word*)lf[1]+1 /* (set! ##compiler#gen ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2520,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate2((C_word*)lf[4]+1 /* (set! ##compiler#gen-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2563,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2602,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10825,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:57: open-output-string */
t7=*((C_word*)lf[320]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k5541 in k5478 in literal-size in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5543(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_5543,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5546,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5548,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5548(t6,t2,t1);}

/* k10823 in k2515 in k2512 in k2509 */
static void C_ccall f_10825(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10825,2,av);}
a=C_alloc(5);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10831,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:57: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[843];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4235 in k4223 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4237(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4237,2,av);}
/* c-backend.scm:404: expr-args */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4632(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* f11661 in k3567 in k3561 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f11661(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f11661,2,av);}
/* c-backend.scm:280: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[102];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* f11669 in k4027 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f11669(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f11669,2,av);}
/* c-backend.scm:354: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5395 in k5385 in k5382 in k5379 in k5376 in k5373 in k5402 in k5364 in k5361 in k5358 in k5355 in k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5397(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5397,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[1]+1);
av2[3]=t1;
C_apply(4,av2);}}

/* k5388 in k5385 in k5382 in k5379 in k5376 in k5373 in k5402 in k5364 in k5361 in k5358 in k5355 in k5352 in k5349 in a5346 in trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5390(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5390,2,av);}
/* c-backend.scm:641: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[303];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4259 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4261(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4261,2,av);}
t2=C_u_i_car(((C_word*)t0)[2]);
/* c-backend.scm:408: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t2;
av2[4]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4297 in k4293 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4299(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,7))){C_save_and_reclaim((void *)f_4299,2,av);}
/* c-backend.scm:412: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(40);
av2[3]=((C_word*)t0)[3];
av2[4]=lf[188];
av2[5]=((C_word*)t0)[4];
av2[6]=C_make_character(41);
av2[7]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(8,av2);}}

/* k4293 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4295(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4295,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:412: foreign-argument-conversion */
t4=*((C_word*)lf[189]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8120(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_8120,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
/* c-backend.scm:1140: str */
t2=((C_word*)t0)[2];
f_8050(t2,((C_word*)t0)[3],lf[654]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[605]);
if(C_truep(t2)){
/* c-backend.scm:1141: str */
t3=((C_word*)t0)[2];
f_8050(t3,((C_word*)t0)[3],lf[655]);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[611]);
t4=(C_truep(t3)?t3:C_eqp(((C_word*)t0)[4],lf[603]));
if(C_truep(t4)){
/* c-backend.scm:1142: str */
t5=((C_word*)t0)[2];
f_8050(t5,((C_word*)t0)[3],lf[656]);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[608]);
if(C_truep(t5)){
/* c-backend.scm:1143: str */
t6=((C_word*)t0)[2];
f_8050(t6,((C_word*)t0)[3],lf[657]);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[607]);
if(C_truep(t6)){
/* c-backend.scm:1144: str */
t7=((C_word*)t0)[2];
f_8050(t7,((C_word*)t0)[3],lf[658]);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[612]);
if(C_truep(t7)){
/* c-backend.scm:1145: str */
t8=((C_word*)t0)[2];
f_8050(t8,((C_word*)t0)[3],lf[659]);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[601]);
if(C_truep(t8)){
/* c-backend.scm:1146: str */
t9=((C_word*)t0)[2];
f_8050(t9,((C_word*)t0)[3],lf[660]);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[613]);
if(C_truep(t9)){
/* c-backend.scm:1147: str */
t10=((C_word*)t0)[2];
f_8050(t10,((C_word*)t0)[3],lf[661]);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[604]);
if(C_truep(t10)){
/* c-backend.scm:1148: str */
t11=((C_word*)t0)[2];
f_8050(t11,((C_word*)t0)[3],lf[662]);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[571]);
if(C_truep(t11)){
/* c-backend.scm:1149: str */
t12=((C_word*)t0)[2];
f_8050(t12,((C_word*)t0)[3],lf[663]);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[598]);
t13=(C_truep(t12)?t12:C_eqp(((C_word*)t0)[4],lf[606]));
if(C_truep(t13)){
/* c-backend.scm:1150: str */
t14=((C_word*)t0)[2];
f_8050(t14,((C_word*)t0)[3],lf[664]);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[583]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_8228(t16,t14);}
else{
t16=C_eqp(((C_word*)t0)[4],lf[585]);
if(C_truep(t16)){
t17=t15;
f_8228(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[4],lf[731]);
t18=t15;
f_8228(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[4],lf[732])));}}}}}}}}}}}}}}

/* trampolines in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5308(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(2,0,4))){
C_save_and_reclaim_args((void *)trf_5308,2,t0,t1);}
a=C_alloc(2);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5347,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm:625: ##sys#hash-table-for-each */
t3=*((C_word*)lf[302]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5585 in k5478 in literal-size in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5587(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5587,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_immp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
/* c-backend.scm:651: bomb */
t4=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[325];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
if(C_truep(C_lambdainfop(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5605,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:663: ##sys#bytevector? */
t3=*((C_word*)lf[327]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}}}

/* k4640 in a4637 in expr-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4642(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4642,2,av);}
t2=C_i_car(((C_word*)t0)[2]);
/* c-backend.scm:473: expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2625(t3,((C_word*)t0)[4],t2,((C_word*)t0)[5]);}

/* k4277 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4279(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4279,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4282,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:413: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k5304 in k5157 in k5154 in a5151 in k5145 in prototypes in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5306(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5306,2,av);}
t2=((C_word*)t0)[2];
f_5162(t2,C_i_zerop(t1));}

/* k10203 in k10200 in k10197 in k10191 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10205(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10205,2,av);}
/* c-backend.scm:1337: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k10200 in k10197 in k10191 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_10202,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1337: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[818];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* expr-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_4632(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_4632,4,t0,t1,t2,t3);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4638,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:470: pair-for-each */
t5=*((C_word*)lf[219]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t1;
av2[2]=t4;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* a4637 in expr-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4638(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_4638,3,av);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4642,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=C_i_car(t2);
/* c-backend.scm:473: expr */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2625(t6,t1,t5,((C_word*)t0)[3]);}
else{
/* c-backend.scm:472: gen */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k5534 in k5478 in literal-size in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5536(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5536,2,av);}
/* c-backend.scm:659: + */{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
C_plus(5,av2);}}

/* k5603 in k5585 in k5478 in literal-size in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5605(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_5605,2,av);}
a=C_alloc(12);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5612,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_block_size(((C_word*)t0)[3]);
/* c-backend.scm:663: words */
t4=*((C_word*)lf[326]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
if(C_truep(C_structurep(((C_word*)t0)[3]))){
t2=C_block_size(((C_word*)t0)[3]);
t3=t2;
t4=C_a_i_plus(&a,2,C_fix(2),t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5634,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5634(t8,((C_word*)t0)[2],C_fix(0),t4);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
/* c-backend.scm:651: bomb */
t4=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[325];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}}

/* doloop534 in k4675 in k4672 in k4669 in push-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_4686(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,5))){
C_save_and_reclaim_args((void *)trf_4686,4,t0,t1,t2,t3);}
a=C_alloc(8);
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4696,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:497: gen */
t5=*((C_word*)lf[1]+1);{
C_word av2[6];
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[221];
av2[4]=t2;
av2[5]=lf[222];
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}}

/* k2570 in gen-list in k2515 in k2512 in k2509 */
static void C_ccall f_2572(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_2572,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2577,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2577(t5,((C_word*)t0)[2],t1);}

/* k8661 in k8657 in k8638 in k8621 in k8604 in k8587 in k8570 in k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in ... */
static void C_ccall f_8663(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,8))){C_save_and_reclaim((void *)f_8663,2,av);}
/* c-backend.scm:1209: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=lf[714];
av2[5]=((C_word*)t0)[5];
av2[6]=lf[715];
av2[7]=t1;
av2[8]=lf[716];
((C_proc)(void*)(*((C_word*)t2+1)))(9,av2);}}

/* k4669 in push-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_4671(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,5))){
C_save_and_reclaim_args((void *)trf_4671,2,t0,t1);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4721,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:486: gen */
t4=*((C_word*)lf[1]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[232];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
/* c-backend.scm:492: gen */
t3=*((C_word*)lf[1]+1);{
C_word av2[6];
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[233];
av2[4]=((C_word*)t0)[7];
av2[5]=lf[234];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}}

/* k4675 in k4672 in k4669 in push-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4677(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4677,2,av);}
a=C_alloc(7);
t2=(C_truep(((C_word*)t0)[2])?C_fix(1):C_fix(0));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4686,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4686(t6,((C_word*)t0)[5],t2,((C_word*)t0)[6]);}

/* k4672 in k4669 in push-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4674(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,5))){C_save_and_reclaim((void *)f_4674,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:493: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[223];
av2[4]=((C_word*)t0)[2];
av2[5]=lf[224];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_4677(2,av2);}}}

/* for-each-loop47 in k2570 in gen-list in k2515 in k2512 in k2509 */
static void C_fcall f_2577(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_2577,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2587,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:49: display */
t5=*((C_word*)lf[3]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[0]+1);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* push-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_4661(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(16,0,2))){
C_save_and_reclaim_args((void *)trf_4661,5,t0,t1,t2,t3,t4);}
a=C_alloc(16);
t5=C_i_length(t2);
t6=(C_truep(t4)?C_a_i_plus(&a,2,t5,C_fix(1)):t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4671,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t2,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4743,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:479: lambda-literal-customizable */
t10=*((C_word*)lf[236]+1);{
C_word av2[3];
av2[0]=t10;
av2[1]=t9;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k2548 in for-each-loop27 in gen in k2515 in k2512 in k2509 */
static void C_ccall f_2550(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2550,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2540(t3,((C_word*)t0)[4],t2);}

/* k8682 in k8657 in k8638 in k8621 in k8604 in k8587 in k8570 in k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in ... */
static void C_ccall f_8684(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8684,2,av);}
/* c-backend.scm:1213: string-intersperse */
t2=*((C_word*)lf[256]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[717];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop1651 in k8657 in k8638 in k8621 in k8604 in k8587 in k8570 in k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in ... */
static void C_fcall f_8686(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_8686,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8711,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_eqp(lf[718],t4);
if(C_truep(t5)){
t6=t3;{
C_word av2[2];
av2[0]=t6;
av2[1]=lf[719];
f_8711(2,av2);}}
else{
/* c-backend.scm:1217: foreign-type-declaration */
t6=*((C_word*)lf[190]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[720];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2585 in for-each-loop47 in k2570 in gen-list in k2515 in k2512 in k2509 */
static void C_ccall f_2587(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2587,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2577(t3,((C_word*)t0)[4],t2);}

/* ##compiler#gen-list in k2515 in k2512 in k2509 */
static void C_ccall f_2563(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_2563,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2572,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:50: intersperse */
t4=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_make_character(32);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k10279 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10281(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_10281,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10287,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1342: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[824];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4722 in k4719 in k4669 in push-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4724(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_4724,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:488: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[229];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_8249,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
/* c-backend.scm:1153: str */
t2=((C_word*)t0)[2];
f_8050(t2,((C_word*)t0)[3],lf[668]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[669]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[670]));
if(C_truep(t3)){
/* c-backend.scm:1154: str */
t4=((C_word*)t0)[2];
f_8050(t4,((C_word*)t0)[3],lf[671]);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[672]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[673]));
if(C_truep(t5)){
/* c-backend.scm:1155: str */
t6=((C_word*)t0)[2];
f_8050(t6,((C_word*)t0)[3],lf[674]);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[675]);
t7=(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[676]));
if(C_truep(t7)){
/* c-backend.scm:1156: str */
t8=((C_word*)t0)[2];
f_8050(t8,((C_word*)t0)[3],lf[677]);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[678]);
t9=(C_truep(t8)?t8:C_eqp(((C_word*)t0)[4],lf[679]));
if(C_truep(t9)){
/* c-backend.scm:1157: str */
t10=((C_word*)t0)[2];
f_8050(t10,((C_word*)t0)[3],lf[680]);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[681]);
t11=(C_truep(t10)?t10:C_eqp(((C_word*)t0)[4],lf[682]));
if(C_truep(t11)){
/* c-backend.scm:1158: str */
t12=((C_word*)t0)[2];
f_8050(t12,((C_word*)t0)[3],lf[683]);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[684]);
t13=(C_truep(t12)?t12:C_eqp(((C_word*)t0)[4],lf[685]));
if(C_truep(t13)){
/* c-backend.scm:1159: str */
t14=((C_word*)t0)[2];
f_8050(t14,((C_word*)t0)[3],lf[686]);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[687]);
t15=(C_truep(t14)?t14:C_eqp(((C_word*)t0)[4],lf[688]));
if(C_truep(t15)){
/* c-backend.scm:1160: str */
t16=((C_word*)t0)[2];
f_8050(t16,((C_word*)t0)[3],lf[689]);}
else{
t16=C_eqp(((C_word*)t0)[4],lf[690]);
t17=(C_truep(t16)?t16:C_eqp(((C_word*)t0)[4],lf[691]));
if(C_truep(t17)){
/* c-backend.scm:1161: str */
t18=((C_word*)t0)[2];
f_8050(t18,((C_word*)t0)[3],lf[692]);}
else{
t18=C_eqp(((C_word*)t0)[4],lf[577]);
t19=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t18)){
t20=t19;
f_8357(t20,t18);}
else{
t20=C_eqp(((C_word*)t0)[4],lf[573]);
if(C_truep(t20)){
t21=t19;
f_8357(t21,t20);}
else{
t21=C_eqp(((C_word*)t0)[4],lf[591]);
if(C_truep(t21)){
t22=t19;
f_8357(t22,t21);}
else{
t22=C_eqp(((C_word*)t0)[4],lf[595]);
t23=t19;
f_8357(t23,(C_truep(t22)?t22:C_eqp(((C_word*)t0)[4],lf[594])));}}}}}}}}}}}}}

/* k4725 in k4722 in k4719 in k4669 in push-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4727(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_4727,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:489: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[228];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k10285 in k10279 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10287(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10287,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1342: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4719 in k4669 in push-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4721(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,5))){C_save_and_reclaim((void *)f_4721,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:487: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[230];
av2[4]=((C_word*)t0)[3];
av2[5]=lf[231];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* for-each-loop27 in gen in k2515 in k2512 in k2509 */
static void C_fcall f_2540(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_2540,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2550,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_eqp(C_SCHEME_TRUE,t4);
if(C_truep(t5)){
/* c-backend.scm:43: newline */
t6=*((C_word*)lf[2]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t3;
av2[2]=*((C_word*)lf[0]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
/* c-backend.scm:44: display */
t6=*((C_word*)lf[3]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[0]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k10288 in k10285 in k10279 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10290(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_10290,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1342: ##sys#write-char-0 */
t3=*((C_word*)lf[317]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(44);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k10291 in k10288 in k10285 in k10279 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10293,2,av);}
/* c-backend.scm:1342: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7113 in k7110 in k7104 in k7224 in for-each-loop1181 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in ... */
static void C_ccall f_7115(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7115,2,av);}
/* c-backend.scm:1025: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7110 in k7104 in k7224 in for-each-loop1181 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in ... */
static void C_ccall f_7112(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_7112,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1025: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6419 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in ... */
static void C_fcall f_6421(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_6421,2,t0,t1);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6423,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6423(t5,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* doloop877 in k6419 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in ... */
static void C_fcall f_6423(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,5))){
C_save_and_reclaim_args((void *)trf_6423,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_zerop(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6433,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:786: gen */
t5=*((C_word*)lf[1]+1);{
C_word av2[6];
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[439];
av2[4]=t2;
av2[5]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}}

/* k7104 in k7224 in for-each-loop1181 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in ... */
static void C_ccall f_7106(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_7106,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7112,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1025: ##sys#write-char-0 */
t6=*((C_word*)lf[317]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_make_character(116);
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k3683 in k3657 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3685(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3685,2,av);}
/* c-backend.scm:300: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[115];
av2[3]=t1;
av2[4]=lf[116];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7098 in k7224 in for-each-loop1181 in k7119 in k7077 in k7074 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in ... */
static void C_ccall f_7100(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7100,2,av);}
/* c-backend.scm:1023: foreign-type-declaration */
t2=*((C_word*)lf[190]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* doloop872 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in ... */
static void C_fcall f_6459(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,7))){
C_save_and_reclaim_args((void *)trf_6459,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_greater_or_equalp(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6469,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:779: gen */
t4=*((C_word*)lf[1]+1);{
C_word av2[8];
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[440];
av2[4]=t2;
av2[5]=lf[441];
av2[6]=t2;
av2[7]=lf[442];
((C_proc)(void*)(*((C_word*)t4+1)))(8,av2);}}}

/* k3673 in k3657 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3675(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3675,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
/* c-backend.scm:302: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[112];
av2[3]=((C_word*)((C_word*)t0)[2])[1];
av2[4]=lf[113];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3529 in for-each-loop279 in k3446 in k3443 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3531(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3531,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_3521(t4,((C_word*)t0)[5],t2,t3);}

/* k3663 in k3660 in k3657 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3665(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_3665,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:318: push-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4661(t3,t2,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)((C_word*)t0)[7])[1]);}

/* k3666 in k3663 in k3660 in k3657 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_3668,2,av);}
/* c-backend.scm:319: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[109];
av2[4]=((C_word*)t0)[3];
av2[5]=lf[110];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* for-each-loop279 in k3446 in k3443 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_3521(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_3521,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3531,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* c-backend.scm:258: g280 */
t9=((C_word*)t0)[3];
f_3449(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* loop in cleanup in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_6818(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(16,0,2))){
C_save_and_reclaim_args((void *)trf_6818,3,t0,t1,t2);}
a=C_alloc(16);
if(C_truep(C_i_greater_or_equalp(t2,((C_word*)t0)[2]))){
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=(C_truep(t3)?t3:((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_i_string_ref(((C_word*)t0)[4],t2);
t4=t3;
t5=C_u_i_char_lessp(t4,C_make_character(32));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6846,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_6846(t7,t5);}
else{
t7=C_u_i_char_greaterp(t4,C_make_character(126));
if(C_truep(t7)){
t8=t6;
f_6846(t8,t7);}
else{
if(C_truep(C_u_i_char_equalp(t4,C_make_character(42)))){
t8=C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
if(C_truep(C_i_lessp(t2,t8))){
t9=C_a_i_plus(&a,2,t2,C_fix(1));
t10=C_i_string_ref(((C_word*)t0)[4],t9);
t11=C_u_i_char_equalp(C_make_character(47),t10);
t12=t6;
f_6846(t12,t11);}
else{
t9=t6;
f_6846(t9,C_SCHEME_FALSE);}}
else{
t8=t6;
f_6846(t8,C_SCHEME_FALSE);}}}}}

/* k3660 in k3657 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3662(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_3662,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:317: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3657 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3659(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,2))){C_save_and_reclaim((void *)f_3659,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(*((C_word*)lf[111]+1))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3675,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[8])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3685,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:300: number->string */
t5=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3692,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:301: number->string */
t5=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}
else{
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3699,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[10],a[4]=t2,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3724,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:304: number->string */
t5=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
if(C_truep(((C_word*)t0)[10])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3731,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3738,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:311: number->string */
t5=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3742,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3749,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:315: number->string */
t5=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}}}

/* k7896 in k7868 in k7865 in k7862 in k7850 in k7847 in k7844 in k7841 in k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7898(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_7898,2,av);}
/* c-backend.scm:1107: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[622];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k2776 in k2773 in k2770 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2778(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2778,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:102: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k2770 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2772(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2772,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:100: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k2773 in k2770 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2775(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_2775,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:101: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[30];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2785 in k2782 in k2779 in k2776 in k2773 in k2770 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2787(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2787,2,av);}
/* c-backend.scm:105: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(125);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2782 in k2779 in k2776 in k2773 in k2770 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2784(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_2784,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2787,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_caddr(((C_word*)t0)[3]);
/* c-backend.scm:104: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k2779 in k2776 in k2773 in k2770 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2781(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2781,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:103: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(125);
av2[3]=C_SCHEME_TRUE;
av2[4]=lf[29];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3697 in k3657 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3699(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_3699,2,av);}
a=C_alloc(7);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm:306: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[119];
av2[3]=((C_word*)((C_word*)t0)[2])[1];
av2[4]=lf[120];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3712,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3716,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadddr(((C_word*)t0)[5]);
/* c-backend.scm:308: ##sys#symbol->qualified-string */
t6=*((C_word*)lf[73]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* k3591 in k3588 in k3585 in k3582 in k3561 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3593(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3593,2,av);}
/* c-backend.scm:286: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3690 in k3657 in k3637 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3692(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3692,2,av);}
/* c-backend.scm:301: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[117];
av2[3]=t1;
av2[4]=lf[118];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3060 in k3057 in k3054 in k3051 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3062(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3062,2,av);}
/* c-backend.scm:162: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3588 in k3585 in k3582 in k3561 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3590(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3590,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3593,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm:286: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[103];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
/* c-backend.scm:285: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k5457 in k5454 in k5448 in doloop728 in literal-frame in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5459(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5459,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:648: ##sys#write-char-0 */
t3=*((C_word*)lf[317]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(93);
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5454 in k5448 in doloop728 in literal-frame in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5456(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_5456,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:648: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5448 in doloop728 in literal-frame in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5450(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_5450,2,av);}
a=C_alloc(8);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:648: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[319];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3582 in k3561 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3584(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,4))){C_save_and_reclaim((void *)f_3584,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3603,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[9])){
/* c-backend.scm:283: push-args */
t4=((C_word*)((C_word*)t0)[6])[1];
f_4661(t4,t2,((C_word*)t0)[7],((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3614,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:283: number->string */
t5=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[10];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k3585 in k3582 in k3561 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3587(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_3587,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:284: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[5];
av2[4]=C_make_character(40);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* doloop728 in literal-frame in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5423(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,2))){
C_save_and_reclaim_args((void *)trf_5423,4,t0,t1,t2,t3);}
a=C_alloc(12);
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5433,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5450,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t6,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:648: open-output-string */
t8=*((C_word*)lf[320]+1);{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* doloop1171 in k7269 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 in ... */
static void C_fcall f_7276(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,7))){
C_save_and_reclaim_args((void *)trf_7276,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_greater_or_equalp(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7286,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_a_i_plus(&a,2,t2,C_fix(3));
/* c-backend.scm:1014: gen */
t5=*((C_word*)lf[1]+1);{
C_word av2[8];
av2[0]=t5;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[544];
av2[4]=t2;
av2[5]=lf[545];
av2[6]=t4;
av2[7]=lf[546];
((C_proc)(void*)(*((C_word*)t5+1)))(8,av2);}}}

/* k7269 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7271(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_7271,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7276,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7276(t5,((C_word*)t0)[3],C_fix(0));}

/* k5431 in doloop728 in literal-frame in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_5433,2,av);}
a=C_alloc(4);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=((C_word*)((C_word*)t0)[4])[1];
f_5423(t5,((C_word*)t0)[5],t2,t4);}

/* a6914 in make-argument-list in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6915(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6915,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6923,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:962: number->string */
t4=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3031 in k3028 in k3025 in k3022 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3033(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3033,2,av);}
/* c-backend.scm:155: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3028 in k3025 in k3022 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3030(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3030,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:154: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* ##compiler#make-argument-list in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6909(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_6909,4,av);}
a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6915,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:960: list-tabulate */
t5=*((C_word*)lf[518]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k6905 in a6898 in make-variable-list in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6907(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6907,2,av);}
/* c-backend.scm:957: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[517];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3022 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_3024,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:152: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k3025 in k3022 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3027(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3027,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:153: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[49];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4327 in k4323 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4329(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_4329,2,av);}
/* c-backend.scm:418: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[194];
av2[4]=t1;
av2[5]=lf[195];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k6989 in k6986 in for-each-loop1120 in generate-foreign-callback-stub-prototypes in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6991(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6991,2,av);}
/* c-backend.scm:985: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6967 in for-each-loop1096 in k6927 in generate-external-variables in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6969(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6969,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6959(t3,((C_word*)t0)[4],t2);}

/* k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in ... */
static void C_ccall f_6004(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,2))){C_save_and_reclaim((void *)f_6004,2,av);}
a=C_alloc(24);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=t2,a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm:745: lambda-literal-temporaries */
t4=*((C_word*)lf[101]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in ... */
static void C_ccall f_6007(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,2))){C_save_and_reclaim((void *)f_6007,2,av);}
a=C_alloc(25);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_6010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
/* c-backend.scm:746: lambda-literal-unboxed-temporaries */
t4=*((C_word*)lf[464]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4323 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4325(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_4325,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4329,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:418: foreign-type-declaration */
t4=*((C_word*)lf[190]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[196];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 in ... */
static void C_ccall f_6001(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,2))){C_save_and_reclaim((void *)f_6001,2,av);}
a=C_alloc(23);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_6004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm:744: lambda-literal-rest-argument-mode */
t4=*((C_word*)lf[297]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3097 in k3083 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_3099,2,av);}
a=C_alloc(10);
t2=C_i_check_list_2(((C_word*)t0)[2],lf[57]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3105,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3114,a[2]=t5,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3114(t7,t3,((C_word*)t0)[2],t1);}

/* k3091 in k3088 in g186 in k3083 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3093(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3093,2,av);}
/* c-backend.scm:171: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3088 in g186 in k3083 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3090(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3090,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3093,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:170: expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2625(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* ##compiler#generate-foreign-callback-stub-prototypes in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6982(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6982,3,av);}
a=C_alloc(5);
t3=C_i_check_list_2(t2,lf[57]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7002,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_7002(t7,t1,t2);}

/* k4348 in k4345 in k4342 in k4339 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4350(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4350,2,av);}
/* c-backend.scm:428: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[199];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5610 in k5603 in k5585 in k5478 in literal-size in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5612(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,1))){C_save_and_reclaim((void *)f_5612,2,av);}
a=C_alloc(4);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_plus(&a,2,C_fix(2),t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6169 in k6165 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in ... */
static void C_ccall f_6171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_6171,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(*((C_word*)lf[145]+1))){
/* c-backend.scm:798: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[395];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6174(2,av2);}}}

/* k6172 in k6169 in k6165 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in ... */
static void C_ccall f_6174(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_6174,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(*((C_word*)lf[393]+1))){
/* c-backend.scm:800: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[394];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6177(2,av2);}}}

/* k6927 in generate-external-variables in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6929(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6929,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=C_i_check_list_2(t2,lf[57]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6959,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_6959(t7,((C_word*)t0)[3],t2);}

/* k3570 in k3567 in k3561 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3572(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3572,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3575,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:279: expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4632(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* ##compiler#generate-external-variables in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6925(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6925,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6929,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:968: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3573 in k3570 in k3567 in k3561 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3575(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3575,2,av);}
/* c-backend.scm:280: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[102];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6921 in a6914 in make-argument-list in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6923(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6923,2,av);}
/* c-backend.scm:962: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3083 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_3085,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3099,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:172: iota */
t5=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=C_fix(1);
av2[4]=C_fix(1);
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* g186 in k3083 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_3086(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_3086,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3090,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:169: gen */
t5=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[55];
av2[3]=t3;
av2[4]=lf[56];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k7284 in doloop1171 in k7269 in k7071 in k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in ... */
static void C_ccall f_7286(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_7286,2,av);}
a=C_alloc(4);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7276(t3,((C_word*)t0)[4],t2);}

/* k6986 in for-each-loop1120 in generate-foreign-callback-stub-prototypes in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_6988,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6991,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:984: generate-foreign-callback-header */
t3=*((C_word*)lf[521]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[522];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in ... */
static void C_ccall f_6022(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(32,c,2))){C_save_and_reclaim((void *)f_6022,2,av);}
a=C_alloc(32);
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_6025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
t3=C_eqp(lf[282],((C_word*)t0)[9]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6542,a[2]=t2,a[3]=((C_word*)t0)[18],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:761: gen */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[450];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6520,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:754: gen */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[455];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in ... */
static void C_ccall f_6028(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,2))){C_save_and_reclaim((void *)f_6028,2,av);}
a=C_alloc(26);
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_6031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6031(2,av2);}}
else{
/* c-backend.scm:766: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[447];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in ... */
static void C_ccall f_6025(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,2))){C_save_and_reclaim((void *)f_6025,2,av);}
a=C_alloc(26);
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_6028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
/* c-backend.scm:765: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(40);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3561 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3563(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_3563,2,av);}
a=C_alloc(11);
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3569,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:277: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[9];
av2[4]=C_make_character(40);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3584,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:282: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(123);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k3567 in k3561 in k3440 in k3404 in k3400 in k3397 in k3394 in k3391 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3569(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_3569,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11661,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:279: expr-args */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4632(t4,t3,((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
/* c-backend.scm:278: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(116);
av2[3]=((C_word*)t0)[7];
av2[4]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k6175 in k6172 in k6169 in k6165 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in ... */
static void C_ccall f_6177(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,7))){C_save_and_reclaim((void *)f_6177,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(*((C_word*)lf[246]+1))){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6180(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6209,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[389]+1))){
/* c-backend.scm:803: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[390];
av2[4]=*((C_word*)lf[389]+1);
av2[5]=lf[391];
av2[6]=C_SCHEME_TRUE;
av2[7]=lf[392];
((C_proc)(void*)(*((C_word*)t4+1)))(8,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_6209(2,av2);}}}}

/* k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7837(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_7837,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:1093: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in ... */
static void C_ccall f_6013(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,4))){C_save_and_reclaim((void *)f_6013,2,av);}
a=C_alloc(27);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_6016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=t2,a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],tmp=(C_word)a,a+=27,tmp);
if(C_truep(((C_word*)t0)[19])){
/* c-backend.scm:750: debugging */
t4=*((C_word*)lf[459]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[460];
av2[3]=lf[461];
av2[4]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_6016(2,av2);}}}

/* k4700 in k4697 in k4694 in doloop534 in k4675 in k4672 in k4669 in push-args in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_4702,2,av);}
a=C_alloc(4);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=((C_word*)((C_word*)t0)[4])[1];
f_4686(t5,((C_word*)t0)[5],t2,t4);}

/* k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in generate-code in k2600 in ... */
static void C_ccall f_6010(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,3))){C_save_and_reclaim((void *)f_6010,2,av);}
a=C_alloc(26);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_6013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=t2,a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
if(C_truep(*((C_word*)lf[246]+1))){
/* c-backend.scm:748: string-append */
t4=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[246]+1);
av2[3]=lf[462];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=lf[463];
f_6013(2,av2);}}}

/* k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in ... */
static void C_ccall f_6019(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(29,c,2))){C_save_and_reclaim((void *)f_6019,2,av);}
a=C_alloc(29);
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_6022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6559,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:752: cleanup */
t4=*((C_word*)lf[458]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[26];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in k5960 in k5957 in a5954 in procedures in k2606 in ... */
static void C_ccall f_6016(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,3))){C_save_and_reclaim((void *)f_6016,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_6019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],tmp=(C_word)a,a+=27,tmp);
/* c-backend.scm:751: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6165 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in ... */
static void C_ccall f_6167(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,9))){C_save_and_reclaim((void *)f_6167,2,av);}
a=C_alloc(9);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_u_i_length(t3);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6171,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:794: gen */
t6=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 10) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(10);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[396];
av2[4]=C_SCHEME_TRUE;
av2[5]=lf[397];
av2[6]=C_SCHEME_TRUE;
av2[7]=lf[398];
av2[8]=((C_word*)t0)[7];
av2[9]=lf[399];
((C_proc)(void*)(*((C_word*)t6+1)))(10,av2);}}

/* k7847 in k7844 in k7841 in k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7849(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_7849,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:1099: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[628];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k7844 in k7841 in k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7846(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,7))){C_save_and_reclaim((void *)f_7846,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_string_equal_p(lf[629],((C_word*)t0)[8]))){
/* c-backend.scm:1097: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(123);
av2[3]=C_SCHEME_TRUE;
av2[4]=lf[630];
av2[5]=((C_word*)t0)[8];
av2[6]=lf[631];
av2[7]=lf[632];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}
else{
/* c-backend.scm:1097: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(123);
av2[3]=C_SCHEME_TRUE;
av2[4]=lf[630];
av2[5]=((C_word*)t0)[8];
av2[6]=lf[631];
av2[7]=lf[633];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}}

/* k7841 in k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7843(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_7843,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:1096: generate-foreign-callback-header */
t3=*((C_word*)lf[521]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[634];
av2[3]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in ... */
static void C_fcall f_6043(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(25,0,3))){
C_save_and_reclaim_args((void *)trf_6043,2,t0,t1);}
a=C_alloc(25);
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_6046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* c-backend.scm:775: gen */
t3=*((C_word*)lf[1]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[443];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in ... */
static void C_ccall f_6040(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,2))){C_save_and_reclaim((void *)f_6040,2,av);}
a=C_alloc(25);
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_6043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
t3=C_eqp(((C_word*)t0)[21],lf[417]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_FALSE);
t5=t2;
f_6043(t5,t4);}
else{
t4=t2;
f_6043(t4,C_SCHEME_UNDEFINED);}}

/* k6181 in k6178 in k6175 in k6172 in k6169 in k6165 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in ... */
static void C_ccall f_6183(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,5))){C_save_and_reclaim((void *)f_6183,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6186,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_eqp(((C_word*)t0)[3],C_fix(0));
if(C_truep(t3)){
/* c-backend.scm:820: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(123);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6195,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:817: gen */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[367];
av2[4]=((C_word*)t0)[3];
av2[5]=lf[368];
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}}

/* k6178 in k6175 in k6172 in k6169 in k6165 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in ... */
static void C_ccall f_6180(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,35))){C_save_and_reclaim((void *)f_6180,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:807: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 36) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(36);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[369];
av2[4]=((C_word*)t0)[5];
av2[5]=lf[370];
av2[6]=((C_word*)t0)[6];
av2[7]=lf[371];
av2[8]=C_SCHEME_TRUE;
av2[9]=lf[372];
av2[10]=((C_word*)t0)[5];
av2[11]=lf[373];
av2[12]=((C_word*)t0)[6];
av2[13]=lf[374];
av2[14]=C_SCHEME_TRUE;
av2[15]=lf[375];
av2[16]=((C_word*)t0)[7];
av2[17]=lf[376];
av2[18]=C_SCHEME_TRUE;
av2[19]=lf[377];
av2[20]=C_SCHEME_TRUE;
av2[21]=lf[378];
av2[22]=((C_word*)t0)[8];
av2[23]=lf[379];
av2[24]=C_SCHEME_TRUE;
av2[25]=lf[380];
av2[26]=C_SCHEME_TRUE;
av2[27]=lf[381];
av2[28]=((C_word*)t0)[8];
av2[29]=lf[382];
av2[30]=C_SCHEME_TRUE;
av2[31]=lf[383];
av2[32]=C_SCHEME_TRUE;
av2[33]=lf[384];
av2[34]=((C_word*)t0)[5];
av2[35]=lf[385];
((C_proc)(void*)(*((C_word*)t3+1)))(36,av2);}}

/* k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7840(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_7840,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7949,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1095: cleanup */
t4=*((C_word*)lf[458]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[10];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_7843(2,av2);}}}

/* k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in ... */
static void C_ccall f_6049(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(40,c,5))){C_save_and_reclaim((void *)f_6049,2,av);}
a=C_alloc(40);
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
/* c-backend.scm:781: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[427];
av2[4]=((C_word*)t0)[6];
av2[5]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6373,a[2]=((C_word*)t0)[24],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6421,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[23])){
t5=C_a_i_minus(&a,2,((C_word*)t0)[6],C_fix(1));
t6=t4;
f_6421(t6,C_a_i_plus(&a,2,((C_word*)t0)[11],t5));}
else{
t5=t4;
f_6421(t5,((C_word*)t0)[11]);}}}

/* k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in ... */
static void C_ccall f_6046(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(31,c,3))){C_save_and_reclaim((void *)f_6046,2,av);}
a=C_alloc(31);
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_6049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
t3=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:((C_word*)t0)[10]);
if(C_truep(t3)){
t4=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_6049(2,av2);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6459,a[2]=((C_word*)t0)[6],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6459(t7,t2,C_fix(0));}}

/* k7402 in k7393 in compute-size in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_7404(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_7404,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
/* c-backend.scm:1074: string-append */
t2=*((C_word*)lf[114]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[572];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[573]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_7416(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t4)){
t5=t3;
f_7416(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[596]);
if(C_truep(t5)){
t6=t3;
f_7416(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[596]);
t7=t3;
f_7416(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[597])));}}}}}

/* k6196 in k6193 in k6181 in k6178 in k6175 in k6172 in k6169 in k6165 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in ... */
static void C_ccall f_6198(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_6198,2,av);}
/* c-backend.scm:819: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[365];
av2[4]=((C_word*)t0)[3];
av2[5]=lf[366];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k6193 in k6181 in k6178 in k6175 in k6172 in k6169 in k6165 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in ... */
static void C_ccall f_6195(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6195,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:818: literal-frame */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5417(t3,t2);}

/* k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in k5963 in ... */
static void C_ccall f_6031(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(30,c,2))){C_save_and_reclaim((void *)f_6031,2,av);}
a=C_alloc(30);
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_6034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],tmp=(C_word)a,a+=26,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6492,a[2]=((C_word*)t0)[25],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[10])){
t4=C_i_zerop(((C_word*)t0)[12]);
t5=t3;
f_6492(t5,C_i_not(t4));}
else{
t4=t3;
f_6492(t4,C_SCHEME_FALSE);}}

/* k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in k5966 in ... */
static void C_ccall f_6034(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,3))){C_save_and_reclaim((void *)f_6034,2,av);}
a=C_alloc(25);
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_6037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(((C_word*)t0)[3])){{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t2;
av2[2]=*((C_word*)lf[1]+1);
av2[3]=((C_word*)t0)[25];
C_apply(4,av2);}}
else{
/* c-backend.scm:772: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[445];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
if(C_truep(((C_word*)t0)[10])){{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t2;
av2[2]=*((C_word*)lf[1]+1);
av2[3]=((C_word*)t0)[25];
C_apply(4,av2);}}
else{
/* c-backend.scm:772: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[445];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}}

/* k7850 in k7847 in k7844 in k7841 in k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_7852,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:1104: reverse */
t3=*((C_word*)lf[627]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in k5984 in k5981 in k5975 in k5972 in k5969 in ... */
static void C_ccall f_6037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,2))){C_save_and_reclaim((void *)f_6037,2,av);}
a=C_alloc(25);
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_6040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* c-backend.scm:773: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[444];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6184 in k6181 in k6178 in k6175 in k6172 in k6169 in k6165 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in ... */
static void C_ccall f_6186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6186,2,av);}
/* c-backend.scm:820: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(123);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7865 in k7862 in k7850 in k7847 in k7844 in k7841 in k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7867(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_7867,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7900,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7900(t6,t2,((C_word*)t0)[6],t1);}

/* k7862 in k7850 in k7847 in k7844 in k7841 in k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7864(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_7864,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:1105: reverse */
t4=*((C_word*)lf[627]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k8709 in map-loop1651 in k8657 in k8638 in k8621 in k8604 in k8587 in k8570 in k8553 in k8536 in k8459 in k8442 in k8425 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in ... */
static void C_ccall f_8711(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8711,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8686(t6,((C_word*)t0)[5],t5);}

/* k6060 in k6056 in k6053 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in ... */
static void C_ccall f_6062(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6062,2,av);}
/* c-backend.scm:873: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(125);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7859 in for-each-loop1430 in k7865 in k7862 in k7850 in k7847 in k7844 in k7841 in k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7861(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,8))){C_save_and_reclaim((void *)f_7861,2,av);}
/* c-backend.scm:1102: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[623];
av2[4]=t1;
av2[5]=((C_word*)t0)[3];
av2[6]=lf[624];
av2[7]=C_SCHEME_TRUE;
av2[8]=lf[625];
((C_proc)(void*)(*((C_word*)t2+1)))(9,av2);}}

/* k6067 in k6056 in k6053 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in ... */
static void C_ccall f_6069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_6069,2,av);}
a=C_alloc(4);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* c-backend.scm:867: expression */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2622(t3,((C_word*)t0)[5],t1,t2,((C_word*)t0)[6]);}
else{
/* c-backend.scm:867: expression */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2622(t2,((C_word*)t0)[5],t1,((C_word*)t0)[3],((C_word*)t0)[6]);}}

/* k5772 in k5762 in k5759 in k5676 in k5670 in gen-lit in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5774(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5774,2,av);}
/* c-backend.scm:695: gen-string-constant */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5807(t2,((C_word*)t0)[3],t1);}

/* k7874 in k7871 in k7868 in k7865 in k7862 in k7850 in k7847 in k7844 in k7841 in k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 in ... */
static void C_ccall f_7876(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_7876,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7879,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_eqp(lf[534],((C_word*)t0)[3]);
if(C_truep(t3)){
/* c-backend.scm:1110: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[620];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
/* c-backend.scm:1109: gen */
t4=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k7877 in k7874 in k7871 in k7868 in k7865 in k7862 in k7850 in k7847 in k7844 in k7841 in k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in ... */
static void C_ccall f_7879(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7879,2,av);}
/* c-backend.scm:1110: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[620];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6053 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in ... */
static void C_ccall f_6055(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,11))){C_save_and_reclaim((void *)f_6055,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_eqp(lf[282],((C_word*)t0)[9]);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_not(((C_word*)t0)[10]));
if(C_truep(t4)){
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6085,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:849: gen */
t6=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 12) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(12);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[354];
av2[4]=((C_word*)t0)[9];
av2[5]=lf[355];
av2[6]=C_SCHEME_TRUE;
av2[7]=lf[356];
av2[8]=((C_word*)t0)[6];
av2[9]=lf[357];
av2[10]=((C_word*)t0)[12];
av2[11]=lf[358];
((C_proc)(void*)(*((C_word*)t6+1)))(12,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6121,a[2]=((C_word*)t0)[12],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_truep(((C_word*)t0)[3])?C_i_greaterp(((C_word*)t0)[13],C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6136,a[2]=t5,a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:858: gen */
t8=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[362];
av2[4]=((C_word*)t0)[9];
av2[5]=C_make_character(44);
av2[6]=((C_word*)t0)[13];
av2[7]=C_make_character(44);
((C_proc)(void*)(*((C_word*)t8+1)))(8,av2);}}
else{
/* c-backend.scm:862: gen */
t7=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=lf[363];
av2[3]=((C_word*)t0)[9];
av2[4]=C_make_character(44);
av2[5]=((C_word*)t0)[6];
av2[6]=lf[364];
((C_proc)(void*)(*((C_word*)t7+1)))(7,av2);}}}}
else{
/* c-backend.scm:865: gen */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=C_make_character(125);
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in k5990 in k5987 in ... */
static void C_ccall f_6052(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,4))){C_save_and_reclaim((void *)f_6052,2,av);}
a=C_alloc(26);
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t3=C_eqp(lf[282],((C_word*)t0)[9]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6167,a[2]=((C_word*)t0)[15],a[3]=t2,a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[17],a[7]=((C_word*)t0)[18],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6226,a[2]=((C_word*)t0)[19],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:792: fold */
t6=*((C_word*)lf[400]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=C_fix(0);
av2[4]=((C_word*)t0)[15];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6240,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[20],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:822: gen */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[411];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6279,a[2]=((C_word*)t0)[10],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[17],a[7]=((C_word*)t0)[21],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[22],a[10]=((C_word*)t0)[23],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[10])){
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_6279(2,av2);}}
else{
/* c-backend.scm:828: gen */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[426];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}}}

/* k7871 in k7868 in k7865 in k7862 in k7850 in k7847 in k7844 in k7841 in k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7873(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,6))){C_save_and_reclaim((void *)f_7873,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1108: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[621];
av2[3]=((C_word*)t0)[4];
av2[4]=C_make_character(44);
av2[5]=((C_word*)t0)[5];
av2[6]=C_make_character(41);
((C_proc)(void*)(*((C_word*)t3+1)))(7,av2);}}

/* k7868 in k7865 in k7862 in k7850 in k7847 in k7844 in k7841 in k7838 in k7835 in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_7870,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_eqp(lf[534],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_7873(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7898,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1107: foreign-argument-conversion */
t5=*((C_word*)lf[189]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k6056 in k6053 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in ... */
static void C_ccall f_6058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_6058,2,av);}
a=C_alloc(10);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6062,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6069,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t3,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:868: lambda-literal-body */
t5=*((C_word*)lf[349]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7414 in k7402 in k7393 in compute-size in k7381 in k7375 in k7372 in k7369 in k7366 in g1256 in generate-foreign-callback-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_7416(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,7))){
C_save_and_reclaim_args((void *)trf_7416,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
/* c-backend.scm:1076: string-append */
t2=*((C_word*)lf[114]+1);{
C_word av2[8];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[574];
av2[4]=((C_word*)t0)[4];
av2[5]=lf[575];
av2[6]=((C_word*)t0)[4];
av2[7]=lf[576];
((C_proc)(void*)(*((C_word*)t2+1)))(8,av2);}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[577]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_7428(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[591]);
if(C_truep(t4)){
t5=t3;
f_7428(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[592]);
if(C_truep(t5)){
t6=t3;
f_7428(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[593]);
t7=t3;
f_7428(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[5],lf[594])));}}}}}

/* k6083 in k6053 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in ... */
static void C_ccall f_6085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,7))){C_save_and_reclaim((void *)f_6085,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:851: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[351];
av2[4]=((C_word*)t0)[2];
av2[5]=lf[352];
av2[6]=((C_word*)t0)[2];
av2[7]=lf[353];
((C_proc)(void*)(*((C_word*)t3+1)))(8,av2);}}

/* k6086 in k6083 in k6053 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in ... */
static void C_ccall f_6088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_6088,2,av);}
a=C_alloc(9);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6097,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6097(t6,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}

/* k3995 in for-each-loop394 in k3918 in k3915 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3997(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3997,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_3987(t4,((C_word*)t0)[5],t2,t3);}

/* k6119 in k6053 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in ... */
static void C_ccall f_6121(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_6121,2,av);}
if(C_truep(C_i_greaterp(((C_word*)t0)[2],C_fix(0)))){
/* c-backend.scm:864: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[359];
av2[4]=((C_word*)t0)[2];
av2[5]=lf[360];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_6058(2,av2);}}}

/* k6134 in k6053 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in k5993 in ... */
static void C_ccall f_6136(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_6136,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6139,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t2;
av2[2]=*((C_word*)lf[1]+1);
av2[3]=((C_word*)t0)[3];
C_apply(4,av2);}}

/* k6137 in k6134 in k6053 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in k5996 in ... */
static void C_ccall f_6139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6139,2,av);}
/* c-backend.scm:860: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[361];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* for-each-loop394 in k3918 in k3915 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_3987(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_3987,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3997,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* c-backend.scm:338: g395 */
t9=((C_word*)t0)[3];
f_3921(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_backend_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_backend_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(1823)){
C_save(t1);
C_rereclaim2(1823*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,844);
lf[0]=C_h_intern(&lf[0],15,"\010compileroutput");
lf[1]=C_h_intern(&lf[1],12,"\010compilergen");
lf[2]=C_h_intern(&lf[2],7,"newline");
lf[3]=C_h_intern(&lf[3],7,"display");
lf[4]=C_h_intern(&lf[4],17,"\010compilergen-list");
lf[5]=C_h_intern(&lf[5],11,"intersperse");
lf[6]=C_h_intern(&lf[6],18,"\010compilerunique-id");
lf[7]=C_h_intern(&lf[7],22,"\010compilergenerate-code");
lf[8]=C_h_intern(&lf[8],13,"\010compilerbomb");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[10]=C_h_intern(&lf[10],18,"\003syshash-table-ref");
lf[11]=C_h_intern(&lf[11],14,"\004coreimmediate");
lf[12]=C_h_intern(&lf[12],4,"bool");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[15]=C_h_intern(&lf[15],4,"char");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[17]=C_h_intern(&lf[17],3,"nil");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[19]=C_h_intern(&lf[19],3,"fix");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[21]=C_h_intern(&lf[21],3,"eof");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[24]=C_h_intern(&lf[24],12,"\004coreliteral");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[28]=C_h_intern(&lf[28],2,"if");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[32]=C_h_intern(&lf[32],9,"\004coreproc");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[34]=C_h_intern(&lf[34],9,"\004corebind");
lf[35]=C_h_intern(&lf[35],16,"\004corelet_unboxed");
lf[36]=C_h_intern(&lf[36],8,"\004coreref");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word\052)");
lf[39]=C_h_intern(&lf[39],10,"\004coreunbox");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word\052)");
lf[42]=C_h_intern(&lf[42],13,"\004coreupdate_i");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[44]=C_h_intern(&lf[44],11,"\004coreupdate");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate2(((C_word \052)");
lf[48]=C_h_intern(&lf[48],16,"\004coreupdatebox_i");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[51]=C_h_intern(&lf[51],14,"\004coreupdatebox");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate2(((C_word \052)");
lf[54]=C_h_intern(&lf[54],12,"\004coreclosure");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[57]=C_h_intern(&lf[57],8,"for-each");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[60]=C_h_intern(&lf[60],4,"iota");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\023(\052a=C_CLOSURE_TYPE|");
lf[62]=C_h_intern(&lf[62],8,"\004corebox");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\031(\052a=C_VECTOR_TYPE|1,a[1]=");
lf[65]=C_h_intern(&lf[65],10,"\004corelocal");
lf[66]=C_h_intern(&lf[66],13,"\004coresetlocal");
lf[67]=C_h_intern(&lf[67],11,"\004coreglobal");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[72]=C_h_intern(&lf[72],21,"\010compilerc-ify-string");
lf[73]=C_h_intern(&lf[73],28,"\003syssymbol->qualified-string");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\016\052((C_word\052)lf[");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fast_retrieve(lf[");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[78]=C_h_intern(&lf[78],14,"\004coresetglobal");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\012 /\052 (set! ");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\011 ...) \052/,");
lf[81]=C_h_intern(&lf[81],21,"\010compileruncommentify");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\016C_mutate2(&lf[");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mutate2((C_word\052)lf[");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\003]+1");
lf[86]=C_h_intern(&lf[86],16,"\004coresetglobal_i");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\005] /\052 ");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\005 \052/ =");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\005] /\052 ");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\006 \052/,0,");
lf[93]=C_h_intern(&lf[93],14,"\004coreundefined");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[95]=C_h_intern(&lf[95],9,"\004corecall");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\007,av2);}");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[101]=C_h_intern(&lf[101],26,"lambda-literal-temporaries");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\006av2);}");
lf[104]=C_h_intern(&lf[104],17,"\003sysstring-append");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[106]=C_h_intern(&lf[106],14,"number->string");
lf[107]=C_h_intern(&lf[107],22,"lambda-literal-looping");
lf[108]=C_h_intern(&lf[108],17,"lambda-literal-id");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\003tp(");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\007,av2);}");
lf[111]=C_h_intern(&lf[111],35,"\010compilerno-global-procedure-checks");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\024(void\052)(\052((C_word\052)(");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\005)+1))");
lf[114]=C_h_intern(&lf[114],13,"string-append");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\016\052((C_word\052)lf[");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fast_retrieve_proc(");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\030C_retrieve2_symbol_proc(");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fast_retrieve_proc(");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\016\052((C_word\052)lf[");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\037C_fast_retrieve_symbol_proc(lf[");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\016\052((C_word\052)lf[");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\023{C_proc tp=(C_proc)");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\007,av2);}");
lf[136]=C_h_intern(&lf[136],6,"unsafe");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\024(void\052)(\052((C_word\052)t");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\026C_fast_retrieve_proc(t");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[141]=C_h_intern(&lf[141],28,"\010compilerno-procedure-checks");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_proc)");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\002;{");
lf[145]=C_h_intern(&lf[145],15,"emit-debug-info");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\032C_debugger(&(C_debug_info[");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\003]),");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\0060,NULL");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\004c,av");
lf[151]=C_h_intern(&lf[151],24,"\010compileremit-trace-info");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[154]=C_h_intern(&lf[154],21,"\010compilerbackslashify");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\003/\052 ");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\003 \052/");
lf[157]=C_h_intern(&lf[157],27,"lambda-literal-closure-size");
lf[158]=C_h_intern(&lf[158],5,"fifth");
lf[159]=C_h_intern(&lf[159],28,"\010compilersource-info->string");
lf[160]=C_h_intern(&lf[160],12,"\004corerecurse");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[164]=C_h_intern(&lf[164],16,"\004coredirect_call");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[166]=C_h_intern(&lf[166],13,"\004corecallunit");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\007,av2);}");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[171]=C_h_intern(&lf[171],11,"\004corereturn");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[174]=C_h_intern(&lf[174],11,"\004coreinline");
lf[175]=C_h_intern(&lf[175],16,"\004coredebug-event");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\032C_debugger(&(C_debug_info[");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\003]),");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\0060,NULL");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\004c,av");
lf[181]=C_h_intern(&lf[181],20,"\004coreinline_allocate");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[183]=C_h_intern(&lf[183],15,"\004coreinline_ref");
lf[184]=C_h_intern(&lf[184],34,"\010compilerforeign-result-conversion");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[186]=C_h_intern(&lf[186],18,"\004coreinline_update");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[189]=C_h_intern(&lf[189],36,"\010compilerforeign-argument-conversion");
lf[190]=C_h_intern(&lf[190],33,"\010compilerforeign-type-declaration");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[192]=C_h_intern(&lf[192],19,"\004coreinline_loc_ref");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\003\052((");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\021\052)C_data_pointer(");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[198]=C_h_intern(&lf[198],22,"\004coreinline_loc_update");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\004((\052(");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\021\052)C_data_pointer(");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[204]=C_h_intern(&lf[204],16,"\004coreunboxed_ref");
lf[205]=C_h_intern(&lf[205],17,"\004coreunboxed_set!");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\002((");
lf[208]=C_h_intern(&lf[208],19,"\004coreinline_unboxed");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[210]=C_h_intern(&lf[210],11,"\004coreswitch");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[215]=C_h_intern(&lf[215],9,"\004corecond");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[219]=C_h_intern(&lf[219],13,"pair-for-each");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\004av2[");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\007av2[0]=");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\016  av2=C_alloc(");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\010} else {");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000(  av2=av; /\052 Re-use our own argvector \052/");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\010if(c >= ");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\003) {");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word \052av2;");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word av2[");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[235]=C_h_intern(&lf[235],21,"lambda-literal-direct");
lf[236]=C_h_intern(&lf[236],27,"lambda-literal-customizable");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[238]=C_h_intern(&lf[238],30,"\010compilerexternal-protos-first");
lf[239]=C_h_intern(&lf[239],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[240]=C_h_intern(&lf[240],22,"foreign-callback-stubs");
lf[241]=C_h_intern(&lf[241],29,"\010compilerforeign-declarations");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\002\052/");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[244]=C_h_intern(&lf[244],28,"\010compilertarget-include-file");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[246]=C_h_intern(&lf[246],18,"\010compilerunit-name");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[248]=C_h_intern(&lf[248],19,"\010compilerused-units");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[250]=C_h_intern(&lf[250],27,"\010compilercompiler-arguments");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\022/\052 Generated from ");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\031   http://www.call-cc.org");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[256]=C_h_intern(&lf[256],18,"string-intersperse");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[260]=C_h_intern(&lf[260],12,"string-split");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[262]=C_h_intern(&lf[262],15,"chicken-version");
lf[263]=C_h_intern(&lf[263],18,"\003sysdecode-seconds");
lf[264]=C_h_intern(&lf[264],15,"current-seconds");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[269]=C_h_intern(&lf[269],23,"\003syslambda-info->string");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\047_toplevel(C_word c,C_word \052av) C_noret;");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY \052create_ptable(void);");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word \052av");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word \052a");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[282]=C_h_intern(&lf[282],8,"toplevel");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[296]=C_h_intern(&lf[296],24,"lambda-literal-allocated");
lf[297]=C_h_intern(&lf[297],33,"lambda-literal-rest-argument-mode");
lf[298]=C_h_intern(&lf[298],28,"lambda-literal-rest-argument");
lf[299]=C_h_intern(&lf[299],27,"\010compilermake-variable-list");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[301]=C_h_intern(&lf[301],29,"lambda-literal-argument-count");
lf[302]=C_h_intern(&lf[302],23,"\003syshash-table-for-each");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[304]=C_h_intern(&lf[304],27,"\010compilermake-argument-list");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\004=av[");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_ccall tr");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\026(C_word c,C_word \052av){");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_ccall tr");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\036(C_word c,C_word \052av) C_noret;");
lf[315]=C_h_intern(&lf[315],7,"sprintf");
lf[316]=C_h_intern(&lf[316],17,"get-output-string");
lf[317]=C_h_intern(&lf[317],16,"\003syswrite-char-0");
lf[318]=C_h_intern(&lf[318],9,"\003sysprint");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[320]=C_h_intern(&lf[320],18,"open-output-string");
lf[321]=C_h_intern(&lf[321],25,"\010compilerwords-per-flonum");
lf[322]=C_h_intern(&lf[322],6,"reduce");
lf[323]=C_h_intern(&lf[323],1,"+");
lf[324]=C_h_intern(&lf[324],12,"vector->list");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[326]=C_h_intern(&lf[326],14,"\010compilerwords");
lf[327]=C_h_intern(&lf[327],15,"\003sysbytevector\077");
lf[328]=C_h_intern(&lf[328],32,"\010compilerblock-variable-literal\077");
lf[329]=C_h_intern(&lf[329],19,"\010compilerimmediate\077");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[332]=C_h_intern(&lf[332],19,"\003sysundefined-value");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[343]=C_h_intern(&lf[343],23,"\010compilerencode-literal");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[345]=C_h_intern(&lf[345],20,"\010compilerbig-fixnum\077");
lf[346]=C_h_intern(&lf[346],6,"modulo");
lf[347]=C_h_intern(&lf[347],14,"\003syscopy-bytes");
lf[348]=C_h_intern(&lf[348],11,"make-string");
lf[349]=C_h_intern(&lf[349],19,"lambda-literal-body");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\023=C_build_rest(&a,c,");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\005,av);");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\032C_save_and_reclaim((void\052)");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\010,c,av);}");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\020)\052C_SIZEOF_PAIR+");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\042C_save_and_reclaim_args((void \052)tr");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\033C_save_and_reclaim((void \052)");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\006,av);}");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000+C_check_nursery_minimum(C_calculate_demand(");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\003,c,");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\003));");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000 if(!C_demand(C_calculate_demand(");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\003,c,");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\004))){");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\034C_save_and_reclaim((void\052)C_");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\010,c,av);}");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\023\052sizeof(C_word),1);");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[386]=C_h_intern(&lf[386],26,"\010compilertarget-stack-size");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[389]=C_h_intern(&lf[389],25,"\010compilertarget-heap-size");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[393]=C_h_intern(&lf[393],40,"\010compilerdisable-stack-overflow-checking");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000$C_register_debug_info(C_debug_info);");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word \052a;");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000=if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[400]=C_h_intern(&lf[400],4,"fold");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000#if(!C_demand(C_calculate_demand((c-");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\021)\052C_SIZEOF_PAIR +");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\003,c,");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\004))){");
lf[405]=C_h_intern(&lf[405],28,"\010compilerinsert-timer-checks");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[410]=C_h_intern(&lf[410],23,"\010compilerno-argc-checks");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word \052a;");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000 if(!C_demand(C_calculate_demand(");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\004))){");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\003,c,");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[417]=C_h_intern(&lf[417],4,"none");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\027C_stack_overflow_check;");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word \052a;");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[428]=C_h_intern(&lf[428],6,"fixnum");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[430]=C_h_intern(&lf[430],6,"flonum");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[433]=C_h_intern(&lf[433],7,"pointer");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\006void \052");
lf[435]=C_h_intern(&lf[435],3,"int");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\024invalid unboxed type");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\004=av[");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word \052av");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word \052a");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\003/\052 ");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\003 \052/");
lf[458]=C_h_intern(&lf[458],16,"\010compilercleanup");
lf[459]=C_h_intern(&lf[459],18,"\010compilerdebugging");
lf[460]=C_h_intern(&lf[460],1,"o");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[464]=C_h_intern(&lf[464],34,"lambda-literal-unboxed-temporaries");
lf[465]=C_h_intern(&lf[465],23,"lambda-literal-external");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[468]=C_h_intern(&lf[468],3,"max");
lf[469]=C_h_intern(&lf[469],32,"lambda-literal-callee-signatures");
lf[470]=C_h_intern(&lf[470],18,"\010compilerreal-name");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\002/\052");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\002\052/");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\021/\052 end of file \052/");
lf[474]=C_h_intern(&lf[474],35,"\010compilercollected-debugging-output");
lf[475]=C_h_intern(&lf[475],20,"emit-procedure-table");
lf[476]=C_h_intern(&lf[476],16,"emit-debug-table");
lf[477]=C_h_intern(&lf[477],31,"generate-foreign-callback-stubs");
lf[478]=C_h_intern(&lf[478],31,"\010compilergenerate-foreign-stubs");
lf[479]=C_h_intern(&lf[479],29,"\010compilerforeign-lambda-stubs");
lf[480]=C_h_intern(&lf[480],36,"\010compilergenerate-external-variables");
lf[481]=C_h_intern(&lf[481],27,"\010compilerexternal-variables");
lf[482]=C_h_intern(&lf[482],1,"p");
lf[483]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[484]=C_h_intern(&lf[484],31,"flonum-maximum-decimal-exponent");
lf[485]=C_h_intern(&lf[485],22,"flonum-print-precision");
lf[486]=C_decode_literal(C_heaptop,"\376B\000\000\022{0,0,NULL,NULL}};\012");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[489]=C_decode_literal(C_heaptop,"\376B\000\000\002\042,");
lf[490]=C_h_intern(&lf[490],8,"->string");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[493]=C_h_intern(&lf[493],4,"sort");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000$static C_DEBUG_INFO C_debug_info[]={");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\052static C_PTABLE_ENTRY \052create_ptable(void)");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[504]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[505]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[510]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void\052)");
lf[511]=C_h_intern(&lf[511],29,"\010compilerstring->c-identifier");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[515]=C_h_intern(&lf[515],19,"\003syshash-table-size");
lf[516]=C_h_intern(&lf[516],11,"string-copy");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[518]=C_h_intern(&lf[518],13,"list-tabulate");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[521]=C_h_intern(&lf[521],41,"\010compilergenerate-foreign-callback-header");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[523]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[527]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[532]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[534]=C_h_intern(&lf[534],4,"void");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[542]=C_h_intern(&lf[542],14,"symbol->string");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,\052C_a=(C_word\052)C_buf;");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word C_a");
lf[545]=C_decode_literal(C_heaptop,"\376B\000\000\006=C_av[");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\032(C_word C_c,C_word \052C_av){");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000!C_word C_k=C_av[1],C_buf=C_av[2];");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[553]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[554]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[557]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\000\010/\052 from ");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000\003 \052/");
lf[560]=C_h_intern(&lf[560],21,"foreign-stub-callback");
lf[561]=C_h_intern(&lf[561],16,"foreign-stub-cps");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[563]=C_h_intern(&lf[563],9,"make-list");
lf[564]=C_h_intern(&lf[564],27,"foreign-stub-argument-names");
lf[565]=C_h_intern(&lf[565],17,"foreign-stub-body");
lf[566]=C_h_intern(&lf[566],17,"foreign-stub-name");
lf[567]=C_h_intern(&lf[567],24,"foreign-stub-return-type");
lf[568]=C_h_intern(&lf[568],27,"foreign-stub-argument-types");
lf[569]=C_h_intern(&lf[569],19,"\010compilerreal-name2");
lf[570]=C_h_intern(&lf[570],15,"foreign-stub-id");
lf[571]=C_h_intern(&lf[571],5,"float");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[573]=C_h_intern(&lf[573],8,"c-string");
lf[574]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[575]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[576]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[577]=C_h_intern(&lf[577],16,"nonnull-c-string");
lf[578]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[579]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[580]=C_h_intern(&lf[580],3,"ref");
lf[581]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[582]=C_h_intern(&lf[582],5,"const");
lf[583]=C_h_intern(&lf[583],9,"c-pointer");
lf[584]=C_h_intern(&lf[584],15,"nonnull-pointer");
lf[585]=C_h_intern(&lf[585],17,"nonnull-c-pointer");
lf[586]=C_h_intern(&lf[586],8,"function");
lf[587]=C_h_intern(&lf[587],8,"instance");
lf[588]=C_h_intern(&lf[588],16,"nonnull-instance");
lf[589]=C_h_intern(&lf[589],12,"instance-ref");
lf[590]=C_h_intern(&lf[590],27,"\010compilerforeign-type-table");
lf[591]=C_h_intern(&lf[591],17,"nonnull-c-string\052");
lf[592]=C_h_intern(&lf[592],25,"nonnull-unsigned-c-string");
lf[593]=C_h_intern(&lf[593],26,"nonnull-unsigned-c-string\052");
lf[594]=C_h_intern(&lf[594],6,"symbol");
lf[595]=C_h_intern(&lf[595],9,"c-string\052");
lf[596]=C_h_intern(&lf[596],17,"unsigned-c-string");
lf[597]=C_h_intern(&lf[597],18,"unsigned-c-string\052");
lf[598]=C_h_intern(&lf[598],6,"double");
lf[599]=C_h_intern(&lf[599],16,"unsigned-integer");
lf[600]=C_h_intern(&lf[600],18,"unsigned-integer32");
lf[601]=C_h_intern(&lf[601],4,"long");
lf[602]=C_h_intern(&lf[602],7,"integer");
lf[603]=C_h_intern(&lf[603],9,"integer32");
lf[604]=C_h_intern(&lf[604],13,"unsigned-long");
lf[605]=C_h_intern(&lf[605],6,"size_t");
lf[606]=C_h_intern(&lf[606],6,"number");
lf[607]=C_h_intern(&lf[607],18,"unsigned-integer64");
lf[608]=C_h_intern(&lf[608],9,"integer64");
lf[609]=C_h_intern(&lf[609],13,"c-string-list");
lf[610]=C_h_intern(&lf[610],14,"c-string-list\052");
lf[611]=C_h_intern(&lf[611],5,"int32");
lf[612]=C_h_intern(&lf[612],5,"short");
lf[613]=C_h_intern(&lf[613],14,"unsigned-short");
lf[614]=C_h_intern(&lf[614],13,"scheme-object");
lf[615]=C_h_intern(&lf[615],13,"unsigned-char");
lf[616]=C_h_intern(&lf[616],12,"unsigned-int");
lf[617]=C_h_intern(&lf[617],14,"unsigned-int32");
lf[618]=C_h_intern(&lf[618],4,"byte");
lf[619]=C_h_intern(&lf[619],13,"unsigned-byte");
lf[620]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[621]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void \052)");
lf[622]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[623]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[624]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[625]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[626]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[627]=C_h_intern(&lf[627],7,"reverse");
lf[628]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[629]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[630]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[631]=C_decode_literal(C_heaptop,"\376B\000\000\004,\052a=");
lf[632]=C_decode_literal(C_heaptop,"\376B\000\000\020C_stack_pointer;");
lf[633]=C_decode_literal(C_heaptop,"\376B\000\000\013C_alloc(s);");
lf[634]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[635]=C_decode_literal(C_heaptop,"\376B\000\000\010/\052 from ");
lf[636]=C_decode_literal(C_heaptop,"\376B\000\000\003 \052/");
lf[637]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[638]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[639]=C_h_intern(&lf[639],36,"foreign-callback-stub-argument-types");
lf[640]=C_h_intern(&lf[640],33,"foreign-callback-stub-return-type");
lf[641]=C_h_intern(&lf[641],24,"foreign-callback-stub-id");
lf[642]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[643]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[644]=C_h_intern(&lf[644],32,"foreign-callback-stub-qualifiers");
lf[645]=C_h_intern(&lf[645],26,"foreign-callback-stub-name");
lf[646]=C_h_intern(&lf[646],13,"\010compilerquit");
lf[647]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[648]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[649]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[652]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[653]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[654]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[655]=C_decode_literal(C_heaptop,"\376B\000\000\006size_t");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[657]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[658]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u64");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[660]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[661]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[662]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[663]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[664]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[665]=C_decode_literal(C_heaptop,"\376B\000\000\006void \052");
lf[666]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char \052\052");
lf[667]=C_h_intern(&lf[667],4,"blob");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char \052");
lf[669]=C_h_intern(&lf[669],9,"u16vector");
lf[670]=C_h_intern(&lf[670],17,"nonnull-u16vector");
lf[671]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short \052");
lf[672]=C_h_intern(&lf[672],8,"s8vector");
lf[673]=C_h_intern(&lf[673],16,"nonnull-s8vector");
lf[674]=C_decode_literal(C_heaptop,"\376B\000\000\015signed char \052");
lf[675]=C_h_intern(&lf[675],9,"u32vector");
lf[676]=C_h_intern(&lf[676],17,"nonnull-u32vector");
lf[677]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int \052");
lf[678]=C_h_intern(&lf[678],9,"s16vector");
lf[679]=C_h_intern(&lf[679],17,"nonnull-s16vector");
lf[680]=C_decode_literal(C_heaptop,"\376B\000\000\007short \052");
lf[681]=C_h_intern(&lf[681],9,"s32vector");
lf[682]=C_h_intern(&lf[682],17,"nonnull-s32vector");
lf[683]=C_decode_literal(C_heaptop,"\376B\000\000\005int \052");
lf[684]=C_h_intern(&lf[684],9,"f32vector");
lf[685]=C_h_intern(&lf[685],17,"nonnull-f32vector");
lf[686]=C_decode_literal(C_heaptop,"\376B\000\000\007float \052");
lf[687]=C_h_intern(&lf[687],9,"f64vector");
lf[688]=C_h_intern(&lf[688],17,"nonnull-f64vector");
lf[689]=C_decode_literal(C_heaptop,"\376B\000\000\010double \052");
lf[690]=C_h_intern(&lf[690],14,"pointer-vector");
lf[691]=C_h_intern(&lf[691],22,"nonnull-pointer-vector");
lf[692]=C_decode_literal(C_heaptop,"\376B\000\000\007void \052\052");
lf[693]=C_decode_literal(C_heaptop,"\376B\000\000\006char \052");
lf[694]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char \052");
lf[695]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[696]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[697]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[698]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[699]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[700]=C_h_intern(&lf[700],3,"map");
lf[701]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[702]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[705]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[707]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[708]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[709]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[710]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[711]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[712]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[713]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[714]=C_decode_literal(C_heaptop,"\376B\000\000\003 (\052");
lf[715]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[716]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[717]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[718]=C_h_intern(&lf[718],3,"...");
lf[719]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[720]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[722]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\020nonnull-instance\376\377\016");
lf[723]=C_h_intern(&lf[723],4,"enum");
lf[724]=C_h_intern(&lf[724],5,"union");
lf[725]=C_h_intern(&lf[725],6,"struct");
lf[726]=C_h_intern(&lf[726],8,"template");
lf[727]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\017nonnull-pointer\376\003\000\000\002\376\001\000\000\011c-pointer\376\003\000\000\002\376\001\000\000\016scheme-po"
"inter\376\003\000\000\002\376\001\000\000\026nonnull-scheme-pointer\376\003\000\000\002\376\001\000\000\021nonnull-c-pointer\376\377\016");
lf[728]=C_h_intern(&lf[728],12,"nonnull-blob");
lf[729]=C_h_intern(&lf[729],8,"u8vector");
lf[730]=C_h_intern(&lf[730],16,"nonnull-u8vector");
lf[731]=C_h_intern(&lf[731],14,"scheme-pointer");
lf[732]=C_h_intern(&lf[732],22,"nonnull-scheme-pointer");
lf[733]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[734]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[735]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[736]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[737]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[738]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[739]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[740]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\025(size_t)C_num_to_int(");
lf[744]=C_decode_literal(C_heaptop,"\376B\000\000\020C_num_to_uint64(");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[748]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[750]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[752]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[754]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[756]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\033C_c_pointer_vector_or_null(");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\023C_c_pointer_vector(");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\002\052(");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\002\052(");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\021\052)C_c_pointer_nn(");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\012C_flonum(&");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\012C_number(&");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mpointer_or_false(&");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\016C_int_to_num(&");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\023C_a_double_to_num(&");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\006,(int)");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\016C_int_to_num(&");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\027C_unsigned_int_to_num(&");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\017C_long_to_num(&");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000\030C_unsigned_long_to_num(&");
lf[808]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[810]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[811]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000\011,(void\052)&");
lf[813]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[814]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[815]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mpointer_or_false(&");
lf[816]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[817]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[818]=C_decode_literal(C_heaptop,"\376B\000\000\011,(void\052)&");
lf[819]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[820]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[821]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mpointer_or_false(&");
lf[822]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void\052)");
lf[823]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[824]=C_decode_literal(C_heaptop,"\376B\000\000\016C_int_to_num(&");
lf[825]=C_decode_literal(C_heaptop,"\376B\000\000=Encoded literal size of ~S is too large (must fit in 24 bits)");
lf[826]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[827]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[828]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[829]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[830]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[831]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[832]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[833]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[834]=C_h_intern(&lf[834],18,"\003sysfixnum->string");
lf[835]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[836]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[837]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[838]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[839]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid literal - cannot encode");
lf[840]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[841]=C_h_intern(&lf[841],5,"cons\052");
lf[842]=C_h_intern(&lf[842],6,"random");
lf[843]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
C_register_lf2(lf,844,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2511,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* k9466 in k9389 in k9362 in k9353 in k9344 in k9149 in k9122 in foreign-argument-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9468(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9468,2,av);}
/* c-backend.scm:1287: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[782];
av2[3]=t1;
av2[4]=lf[783];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* doloop947 in k6086 in k6083 in k6053 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in k5999 in ... */
static void C_fcall f_6097(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,5))){
C_save_and_reclaim_args((void *)trf_6097,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_zerop(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6107,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:855: gen */
t5=*((C_word*)lf[1]+1);{
C_word av2[6];
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[350];
av2[4]=t2;
av2[5]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}}

/* k4880 in k4876 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4882(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_4882,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:516: pad0 */
f_4761(t3,((C_word*)t0)[8]);}

/* k4884 in k4880 in k4876 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4886(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_4886,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:516: pad0 */
f_4761(t3,((C_word*)t0)[8]);}

/* k6949 in for-each-loop1096 in k6927 in generate-external-variables in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6951(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_6951,2,av);}
/* c-backend.scm:974: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
av2[5]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* g1590 in k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_8388,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* c-backend.scm:1170: foreign-type-declaration */
t4=*((C_word*)lf[190]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=t2;
/* c-backend.scm:1170: foreign-type-declaration */
t4=*((C_word*)lf[190]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k8382 in k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_8384(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_8384,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8388,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1168: g1590 */
t3=t2;
f_8388(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm:1171: str */
t2=((C_word*)t0)[5];
f_8050(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
if(C_truep(C_i_listp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8427,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=C_eqp(C_fix(2),t3);
if(C_truep(t5)){
t6=C_i_car(((C_word*)t0)[4]);
t7=t4;
f_8427(t7,C_u_i_memq(t6,lf[727]));}
else{
t6=t4;
f_8427(t6,C_SCHEME_FALSE);}}
else{
/* c-backend.scm:1222: err */
t2=((C_word*)t0)[6];
f_8045(t2,((C_word*)t0)[3]);}}}}

/* k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6595 in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6625(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_6625,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6628,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:888: emit-procedure-table */
t3=*((C_word*)lf[475]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6595 in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6622(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_6622,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:887: procedures */
t3=((C_word*)((C_word*)t0)[5])[1];
f_5949(t3,t2);}

/* k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6595 in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6628(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6628,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4965,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4969,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:540: get-output-string */
t5=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[474]+1);
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10197 in k10191 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10199,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1337: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4876 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4878(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_4878,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:516: pad0 */
f_4761(t3,((C_word*)t0)[8]);}

/* k10191 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10193(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_10193,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10199,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1337: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[819];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* for-each-loop1096 in k6927 in generate-external-variables in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_6959(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_6959,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6969,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=C_i_vector_ref(t4,C_fix(0));
t7=C_i_vector_ref(t4,C_fix(1));
t8=C_i_vector_ref(t4,C_fix(2));
t9=(C_truep(t8)?lf[519]:lf[520]);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6951,a[2]=t5,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:974: foreign-type-declaration */
t12=*((C_word*)lf[190]+1);{
C_word av2[4];
av2[0]=t12;
av2[1]=t11;
av2[2]=t7;
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t12+1)))(4,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* for-each-loop420 in k3940 in k3932 in k3918 in k3915 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_3950(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,7))){
C_save_and_reclaim_args((void *)trf_3950,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3960,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* c-backend.scm:347: gen */
t9=*((C_word*)lf[1]+1);{
C_word av2[8];
av2[0]=t9;
av2[1]=t6;
av2[2]=C_SCHEME_TRUE;
av2[3]=C_make_character(116);
av2[4]=t8;
av2[5]=lf[162];
av2[6]=t7;
av2[7]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t9+1)))(8,av2);}}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k2883 in k2880 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2885(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_2885,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:123: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2880 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2882(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2882,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* c-backend.scm:122: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k2886 in k2883 in k2880 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2888(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2888,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
/* c-backend.scm:124: expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2625(t3,((C_word*)t0)[4],t2,((C_word*)t0)[5]);}

/* loop in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_2830(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,5))){
C_save_and_reclaim_args((void *)trf_2830,5,t0,t1,t2,t3,t4);}
a=C_alloc(8);
if(C_truep(C_i_greaterp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2840,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:113: gen */
t6=*((C_word*)lf[1]+1);{
C_word av2[6];
av2[0]=t6;
av2[1]=t5;
av2[2]=C_SCHEME_TRUE;
av2[3]=C_make_character(116);
av2[4]=t3;
av2[5]=C_make_character(61);
((C_proc)(void*)(*((C_word*)t6+1)))(6,av2);}}
else{
t5=C_i_car(t2);
/* c-backend.scm:117: expr */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2625(t6,t1,t5,t3);}}

/* k6611 in k6608 in k6605 in k6602 in k6599 in k6595 in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_6613,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:883: generate-foreign-callback-stubs */
t3=*((C_word*)lf[477]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[240]+1);
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6595 in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6619,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(*((C_word*)lf[145]+1))){
/* c-backend.scm:886: emit-debug-table */
t3=*((C_word*)lf[476]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6622(2,av2);}}}

/* k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6595 in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_6616,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:884: trampolines */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5308(t3,t2);}

/* k3943 in k3940 in k3932 in k3918 in k3915 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3945(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3945,2,av);}
/* c-backend.scm:349: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[161];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6608 in k6605 in k6602 in k6599 in k6595 in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_6610(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_6610,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:882: prototypes */
t3=((C_word*)((C_word*)t0)[9])[1];
f_5143(t3,t2);}

/* k6105 in doloop947 in k6086 in k6083 in k6053 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6029 in k6026 in k6023 in k6020 in k6017 in k6014 in k6011 in k6008 in k6005 in k6002 in ... */
static void C_ccall f_6107(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_6107,2,av);}
a=C_alloc(8);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=C_a_i_minus(&a,2,((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_6097(t4,((C_word*)t0)[5],t2,t3);}

/* k3940 in k3932 in k3918 in k3915 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3942(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_3942,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3945,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3950,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3950(t6,t2,((C_word*)t0)[3],t1);}

/* k8367 in k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8369(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_8369,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
/* c-backend.scm:1165: str */
t2=((C_word*)t0)[2];
f_8050(t2,((C_word*)t0)[3],lf[694]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[534]);
if(C_truep(t2)){
/* c-backend.scm:1166: str */
t3=((C_word*)t0)[2];
f_8050(t3,((C_word*)t0)[3],lf[695]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8384,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[6]))){
/* c-backend.scm:1168: ##sys#hash-table-ref */
t4=*((C_word*)lf[10]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[590]+1);
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_8384(2,av2);}}}}}

/* k10176 in k10173 in k10167 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10178(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_10178,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1335: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[816];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10173 in k10167 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10175(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10175,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1335: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10606 in encode-literal in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10608(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_10608,2,av);}
/* c-backend.scm:1379: string-append */
t2=*((C_word*)lf[114]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[828];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3958 in for-each-loop420 in k3940 in k3932 in k3918 in k3915 in k4043 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3960(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3960,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_3950(t4,((C_word*)t0)[5],t2,t3);}

/* k10179 in k10176 in k10173 in k10167 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10181(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10181,2,av);}
/* c-backend.scm:1335: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4480 in k4477 in k4474 in k4471 in doloop490 in k4437 in k4434 in k4431 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4482(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_4482,2,av);}
a=C_alloc(4);
t2=C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
t3=C_i_cddr(((C_word*)t0)[3]);
t4=((C_word*)((C_word*)t0)[4])[1];
f_4450(t4,((C_word*)t0)[5],t2,t3);}

/* k2841 in k2838 in loop in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2843(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2843,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:115: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(59);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2838 in loop in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2840(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_2840,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* c-backend.scm:114: expr */
t4=((C_word*)((C_word*)t0)[7])[1];
f_2625(t4,t2,t3,((C_word*)t0)[3]);}

/* k2844 in k2841 in k2838 in loop in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_2846(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_2846,2,av);}
a=C_alloc(8);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t5=C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
/* c-backend.scm:116: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_2830(t6,((C_word*)t0)[6],t3,t4,t5);}

/* k8355 in k8247 in k8226 in k8118 in foreign-type-declaration in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_8357(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_8357,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
/* c-backend.scm:1163: str */
t2=((C_word*)t0)[2];
f_8050(t2,((C_word*)t0)[3],lf[693]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[592]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8369(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[593]);
if(C_truep(t4)){
t5=t3;
f_8369(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[596]);
t6=t3;
f_8369(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[4],lf[597])));}}}}

/* k5759 in k5676 in k5670 in gen-lit in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5761(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_5761,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:694: gen */
t3=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[5];
av2[4]=lf[344];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[4];
/* c-backend.scm:651: bomb */
t4=*((C_word*)lf[8]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[325];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k5765 in k5762 in k5759 in k5676 in k5670 in gen-lit in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5767,2,av);}
/* c-backend.scm:696: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[342];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5762 in k5759 in k5676 in k5670 in gen-lit in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5764(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5764,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5767,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5774,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:695: encode-literal */
t4=*((C_word*)lf[343]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4477 in k4474 in k4471 in doloop490 in k4437 in k4434 in k4431 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4479(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_4479,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* c-backend.scm:456: expr */
t4=((C_word*)((C_word*)t0)[6])[1];
f_2625(t4,t2,t3,((C_word*)t0)[7]);}

/* k4474 in k4471 in doloop490 in k4437 in k4434 in k4431 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4476(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_4476,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:455: gen */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(58);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4471 in doloop490 in k4437 in k4434 in k4431 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4473(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_4473,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:454: expr */
t4=((C_word*)((C_word*)t0)[6])[1];
f_2625(t4,t2,t3,((C_word*)t0)[7]);}

/* k3156 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_3158(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3158,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3161,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:177: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* k5732 in k5726 in k5676 in k5670 in gen-lit in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5734(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,8))){C_save_and_reclaim((void *)f_5734,2,av);}
/* c-backend.scm:688: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[338];
av2[3]=((C_word*)t0)[3];
av2[4]=C_make_character(44);
av2[5]=((C_word*)t0)[4];
av2[6]=C_make_character(44);
av2[7]=((C_word*)t0)[5];
av2[8]=lf[339];
((C_proc)(void*)(*((C_word*)t2+1)))(9,av2);}}

/* k4461 in k4458 in doloop490 in k4437 in k4434 in k4431 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4463(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4463,2,av);}
/* c-backend.scm:452: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(125);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4458 in doloop490 in k4437 in k4434 in k4431 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4460(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4460,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4463,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:451: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2625(t4,t2,t3,((C_word*)t0)[5]);}

/* doloop490 in k4437 in k4434 in k4431 in expr in expression in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_4450(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_4450,4,t0,t1,t2,t3);}
a=C_alloc(8);
if(C_truep(C_i_zerop(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4460,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:450: gen */
t5=*((C_word*)lf[1]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[211];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4473,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:453: gen */
t5=*((C_word*)lf[1]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[212];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k10231 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_10233,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10239,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1340: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[821];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10237 in k10231 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10239(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10239,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1340: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5509 in k5478 in literal-size in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5511(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5511,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5515,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* c-backend.scm:658: literal-size */
t6=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
f_5473(3,av2);}}

/* k5513 in k5509 in k5478 in literal-size in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5515(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5515,2,av);}
/* c-backend.scm:658: + */{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(3);
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
C_plus(5,av2);}}

/* k10240 in k10237 in k10231 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10242(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_10242,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1340: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[820];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10243 in k10240 in k10237 in k10231 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10245(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10245,2,av);}
/* c-backend.scm:1340: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k9906 in k9903 in k9900 in k9894 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9908,2,av);}
/* c-backend.scm:1314: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k10119 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10121(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_10121,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10127,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1331: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[813];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k9903 in k9900 in k9894 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9905(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_9905,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1314: ##sys#write-char-0 */
t3=*((C_word*)lf[317]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(44);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4865 in k4801 in k4798 in k4795 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4867(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4867,2,av);}
/* c-backend.scm:527: gen-list */
t2=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[248]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k9900 in k9894 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9902(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_9902,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1314: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10125 in k10119 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10127,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1331: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10255 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10257(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_10257,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10263,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1341: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[823];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k5815 in gen-string-constant in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_5817(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_5817,2,av);}
a=C_alloc(9);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5822(t6,((C_word*)t0)[5],((C_word*)t0)[6],C_fix(0));}

/* k10267 in k10264 in k10261 in k10255 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10269(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10269,2,av);}
/* c-backend.scm:1341: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k10261 in k10255 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10263(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10263,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1341: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10264 in k10261 in k10255 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10266(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_10266,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10269,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1341: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[822];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10101 in k10095 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10103(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10103,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1329: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k9927 in k9921 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9929(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_9929,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1315: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4845 in for-each-loop595 in k4825 in k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4847(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4847,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4837(t3,((C_word*)t0)[4],t2);}

/* doloop811 in k5815 in gen-string-constant in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_5822(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(16,0,4))){
C_save_and_reclaim_args((void *)trf_5822,4,t0,t1,t2,t3);}
a=C_alloc(16);
if(C_truep(C_i_zerop(t2))){
t4=C_eqp(((C_word*)t0)[2],C_fix(0));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5838,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=t5;
f_5838(t6,t4);}
else{
t6=C_u_i_zerop(((C_word*)t0)[5]);
t7=t5;
f_5838(t7,C_i_not(t6));}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5858,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5873,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5877,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=C_a_i_plus(&a,2,t3,C_fix(80));
/* c-backend.scm:708: string-like-substring */
f_5883(t6,((C_word*)t0)[4],t3,t7);}}

/* k10107 in k10104 in k10101 in k10095 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10109(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10109,2,av);}
/* c-backend.scm:1329: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k9921 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9923(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_9923,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9929,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1315: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[802];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10104 in k10101 in k10095 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10106(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_10106,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1329: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[810];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10149 in k10143 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10151(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10151,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1333: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k10152 in k10149 in k10143 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_10154,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1333: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[814];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* for-each-loop595 in k4825 in k4810 in k4807 in k4804 in k4801 in k4798 in k4795 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_fcall f_4837(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_4837,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4847,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:533: gen */
t5=*((C_word*)lf[1]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k10155 in k10152 in k10149 in k10143 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10157(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10157,2,av);}
/* c-backend.scm:1333: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k9945 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9947(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_9947,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9953,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1316: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[804];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k7326 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7035 in k7032 in k7029 in g1144 in generate-foreign-stubs in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_7328(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_7328,2,av);}
/* c-backend.scm:1004: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_TRUE;
av2[3]=lf[558];
av2[4]=t1;
av2[5]=lf[559];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k10167 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10169(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_10169,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[315]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10175,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1335: ##sys#print */
t6=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[817];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k9933 in k9930 in k9927 in k9921 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9935(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9935,2,av);}
/* c-backend.scm:1315: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4888 in k4884 in k4880 in k4876 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,2))){C_save_and_reclaim((void *)f_4890,2,av);}
a=C_alloc(22);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4906,a[2]=t3,a[3]=t6,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4947,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:519: chicken-version */
t10=*((C_word*)lf[262]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k10128 in k10125 in k10119 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_10130,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1331: ##sys#print */
t3=*((C_word*)lf[318]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[812];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4892 in k4888 in k4884 in k4880 in k4876 in k4777 in header in k2606 in generate-code in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_4894(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,20))){C_save_and_reclaim((void *)f_4894,2,av);}
/* c-backend.scm:514: gen */
t2=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 21) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(21);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[251];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[252];
av2[5]=C_SCHEME_TRUE;
av2[6]=lf[253];
av2[7]=C_SCHEME_TRUE;
av2[8]=lf[254];
av2[9]=((C_word*)t0)[4];
av2[10]=C_make_character(45);
av2[11]=((C_word*)t0)[5];
av2[12]=C_make_character(45);
av2[13]=((C_word*)t0)[6];
av2[14]=C_make_character(32);
av2[15]=((C_word*)t0)[7];
av2[16]=C_make_character(58);
av2[17]=((C_word*)t0)[8];
av2[18]=C_SCHEME_TRUE;
av2[19]=t1;
av2[20]=lf[255];
((C_proc)(void*)(*((C_word*)t2+1)))(21,av2);}}

/* k10131 in k10128 in k10125 in k10119 in k10080 in k10053 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_10133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10133,2,av);}
/* c-backend.scm:1331: get-output-string */
t2=*((C_word*)lf[316]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k9930 in k9927 in k9921 in k9840 in foreign-result-conversion in k2600 in k2515 in k2512 in k2509 */
static void C_ccall f_9932(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_9932,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1315: ##sys#write-char-0 */
t3=*((C_word*)lf[317]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(44);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[753] = {
{"f_10145:c_2dbackend_2escm",(void*)f_10145},
{"f_7349:c_2dbackend_2escm",(void*)f_7349},
{"f_6226:c_2dbackend_2escm",(void*)f_6226},
{"f_3315:c_2dbackend_2escm",(void*)f_3315},
{"f_3318:c_2dbackend_2escm",(void*)f_3318},
{"f_9794:c_2dbackend_2escm",(void*)f_9794},
{"f_6240:c_2dbackend_2escm",(void*)f_6240},
{"f_6243:c_2dbackend_2escm",(void*)f_6243},
{"f_6246:c_2dbackend_2escm",(void*)f_6246},
{"f_4936:c_2dbackend_2escm",(void*)f_4936},
{"f_4417:c_2dbackend_2escm",(void*)f_4417},
{"f_4414:c_2dbackend_2escm",(void*)f_4414},
{"f_6234:c_2dbackend_2escm",(void*)f_6234},
{"f_3339:c_2dbackend_2escm",(void*)f_3339},
{"f_3336:c_2dbackend_2escm",(void*)f_3336},
{"f_3333:c_2dbackend_2escm",(void*)f_3333},
{"f_4911:c_2dbackend_2escm",(void*)f_4911},
{"f_6604:c_2dbackend_2escm",(void*)f_6604},
{"f_6607:c_2dbackend_2escm",(void*)f_6607},
{"f_6601:c_2dbackend_2escm",(void*)f_6601},
{"f_2935:c_2dbackend_2escm",(void*)f_2935},
{"f_2938:c_2dbackend_2escm",(void*)f_2938},
{"f_4906:c_2dbackend_2escm",(void*)f_4906},
{"f_10097:c_2dbackend_2escm",(void*)f_10097},
{"f_2908:c_2dbackend_2escm",(void*)f_2908},
{"f_6704:c_2dbackend_2escm",(void*)f_6704},
{"f_4909:c_2dbackend_2escm",(void*)f_4909},
{"f_5634:c_2dbackend_2escm",(void*)f_5634},
{"f_4192:c_2dbackend_2escm",(void*)f_4192},
{"f_2911:c_2dbackend_2escm",(void*)f_2911},
{"f_8005:c_2dbackend_2escm",(void*)f_8005},
{"f_8002:c_2dbackend_2escm",(void*)f_8002},
{"f_4189:c_2dbackend_2escm",(void*)f_4189},
{"f_8014:c_2dbackend_2escm",(void*)f_8014},
{"f_8010:c_2dbackend_2escm",(void*)f_8010},
{"f_10082:c_2dbackend_2escm",(void*)f_10082},
{"f_4173:c_2dbackend_2escm",(void*)f_4173},
{"f_4170:c_2dbackend_2escm",(void*)f_4170},
{"f_3399:c_2dbackend_2escm",(void*)f_3399},
{"f_3393:c_2dbackend_2escm",(void*)f_3393},
{"f_3396:c_2dbackend_2escm",(void*)f_3396},
{"f_8029:c_2dbackend_2escm",(void*)f_8029},
{"f_5672:c_2dbackend_2escm",(void*)f_5672},
{"f_5678:c_2dbackend_2escm",(void*)f_5678},
{"f_6799:c_2dbackend_2escm",(void*)f_6799},
{"f_8438:c_2dbackend_2escm",(void*)f_8438},
{"f_3350:c_2dbackend_2escm",(void*)f_3350},
{"f_8041:c_2dbackend_2escm",(void*)f_8041},
{"f_8045:c_2dbackend_2escm",(void*)f_8045},
{"f_8043:c_2dbackend_2escm",(void*)f_8043},
{"f_8444:c_2dbackend_2escm",(void*)f_8444},
{"f_5805:c_2dbackend_2escm",(void*)f_5805},
{"f_5656:c_2dbackend_2escm",(void*)f_5656},
{"f_5807:c_2dbackend_2escm",(void*)f_5807},
{"f_8050:c_2dbackend_2escm",(void*)f_8050},
{"f_8455:c_2dbackend_2escm",(void*)f_8455},
{"f_3354:c_2dbackend_2escm",(void*)f_3354},
{"f_5665:c_2dbackend_2escm",(void*)f_5665},
{"f_10010:c_2dbackend_2escm",(void*)f_10010},
{"f_4109:c_2dbackend_2escm",(void*)f_4109},
{"f_8596:c_2dbackend_2escm",(void*)f_8596},
{"f_5728:c_2dbackend_2escm",(void*)f_5728},
{"f_10031:c_2dbackend_2escm",(void*)f_10031},
{"f_10034:c_2dbackend_2escm",(void*)f_10034},
{"f_3329:c_2dbackend_2escm",(void*)f_3329},
{"f_10007:c_2dbackend_2escm",(void*)f_10007},
{"f_8562:c_2dbackend_2escm",(void*)f_8562},
{"f_10004:c_2dbackend_2escm",(void*)f_10004},
{"f_8572:c_2dbackend_2escm",(void*)f_8572},
{"f_8579:c_2dbackend_2escm",(void*)f_8579},
{"f_8427:c_2dbackend_2escm",(void*)f_8427},
{"f_10028:c_2dbackend_2escm",(void*)f_10028},
{"f_10022:c_2dbackend_2escm",(void*)f_10022},
{"f_5949:c_2dbackend_2escm",(void*)f_5949},
{"f_7219:c_2dbackend_2escm",(void*)f_7219},
{"f_5955:c_2dbackend_2escm",(void*)f_5955},
{"f_5959:c_2dbackend_2escm",(void*)f_5959},
{"f_5000:c_2dbackend_2escm",(void*)f_5000},
{"f_6738:c_2dbackend_2escm",(void*)f_6738},
{"f_7201:c_2dbackend_2escm",(void*)f_7201},
{"f_6768:c_2dbackend_2escm",(void*)f_6768},
{"f_8589:c_2dbackend_2escm",(void*)f_8589},
{"f_6765:c_2dbackend_2escm",(void*)f_6765},
{"f_6762:c_2dbackend_2escm",(void*)f_6762},
{"f_6759:c_2dbackend_2escm",(void*)f_6759},
{"f_5989:c_2dbackend_2escm",(void*)f_5989},
{"f_5986:c_2dbackend_2escm",(void*)f_5986},
{"f_5983:c_2dbackend_2escm",(void*)f_5983},
{"f_2608:c_2dbackend_2escm",(void*)f_2608},
{"f_2602:c_2dbackend_2escm",(void*)f_2602},
{"f_2604:c_2dbackend_2escm",(void*)f_2604},
{"f_6756:c_2dbackend_2escm",(void*)f_6756},
{"f_6752:c_2dbackend_2escm",(void*)f_6752},
{"f_6725:c_2dbackend_2escm",(void*)f_6725},
{"f_3786:c_2dbackend_2escm",(void*)f_3786},
{"f_5992:c_2dbackend_2escm",(void*)f_5992},
{"f_5998:c_2dbackend_2escm",(void*)f_5998},
{"f_5995:c_2dbackend_2escm",(void*)f_5995},
{"f_2614:c_2dbackend_2escm",(void*)f_2614},
{"f_2610:c_2dbackend_2escm",(void*)f_2610},
{"f_6715:c_2dbackend_2escm",(void*)f_6715},
{"f_6710:c_2dbackend_2escm",(void*)f_6710},
{"f_5040:c_2dbackend_2escm",(void*)f_5040},
{"f_2625:c_2dbackend_2escm",(void*)f_2625},
{"f_2622:c_2dbackend_2escm",(void*)f_2622},
{"f_6773:c_2dbackend_2escm",(void*)f_6773},
{"f_6777:c_2dbackend_2escm",(void*)f_6777},
{"f_5019:c_2dbackend_2escm",(void*)f_5019},
{"f_5016:c_2dbackend_2escm",(void*)f_5016},
{"f_5010:c_2dbackend_2escm",(void*)f_5010},
{"f_3742:c_2dbackend_2escm",(void*)f_3742},
{"f_3755:c_2dbackend_2escm",(void*)f_3755},
{"f_5025:c_2dbackend_2escm",(void*)f_5025},
{"f_3758:c_2dbackend_2escm",(void*)f_3758},
{"f_5022:c_2dbackend_2escm",(void*)f_5022},
{"f_9346:c_2dbackend_2escm",(void*)f_9346},
{"f_3773:c_2dbackend_2escm",(void*)f_3773},
{"f_7957:c_2dbackend_2escm",(void*)f_7957},
{"f_3749:c_2dbackend_2escm",(void*)f_3749},
{"f_5077:c_2dbackend_2escm",(void*)f_5077},
{"f_3761:c_2dbackend_2escm",(void*)f_3761},
{"f_7967:c_2dbackend_2escm",(void*)f_7967},
{"f_7980:c_2dbackend_2escm",(void*)f_7980},
{"f_3791:c_2dbackend_2escm",(void*)f_3791},
{"f_5143:c_2dbackend_2escm",(void*)f_5143},
{"f_5147:c_2dbackend_2escm",(void*)f_5147},
{"f_7990:c_2dbackend_2escm",(void*)f_7990},
{"f_3767:c_2dbackend_2escm",(void*)f_3767},
{"f_3764:c_2dbackend_2escm",(void*)f_3764},
{"f_5050:c_2dbackend_2escm",(void*)f_5050},
{"f_5152:c_2dbackend_2escm",(void*)f_5152},
{"f_5156:c_2dbackend_2escm",(void*)f_5156},
{"f_7987:c_2dbackend_2escm",(void*)f_7987},
{"f_5159:c_2dbackend_2escm",(void*)f_5159},
{"f_7984:c_2dbackend_2escm",(void*)f_7984},
{"f_5067:c_2dbackend_2escm",(void*)f_5067},
{"f_3161:c_2dbackend_2escm",(void*)f_3161},
{"f_7999:c_2dbackend_2escm",(void*)f_7999},
{"f_7012:c_2dbackend_2escm",(void*)f_7012},
{"f_7993:c_2dbackend_2escm",(void*)f_7993},
{"f_5120:c_2dbackend_2escm",(void*)f_5120},
{"f_7395:c_2dbackend_2escm",(void*)f_7395},
{"f_7027:c_2dbackend_2escm",(void*)f_7027},
{"f_3190:c_2dbackend_2escm",(void*)f_3190},
{"f_7025:c_2dbackend_2escm",(void*)f_7025},
{"f_6893:c_2dbackend_2escm",(void*)f_6893},
{"f_5130:c_2dbackend_2escm",(void*)f_5130},
{"f_6899:c_2dbackend_2escm",(void*)f_6899},
{"f_5962:c_2dbackend_2escm",(void*)f_5962},
{"f_7368:c_2dbackend_2escm",(void*)f_7368},
{"f_5965:c_2dbackend_2escm",(void*)f_5965},
{"f_5968:c_2dbackend_2escm",(void*)f_5968},
{"f_7364:c_2dbackend_2escm",(void*)f_7364},
{"f_7362:c_2dbackend_2escm",(void*)f_7362},
{"f_3752:c_2dbackend_2escm",(void*)f_3752},
{"f_7037:c_2dbackend_2escm",(void*)f_7037},
{"f_7031:c_2dbackend_2escm",(void*)f_7031},
{"f_7034:c_2dbackend_2escm",(void*)f_7034},
{"f_5971:c_2dbackend_2escm",(void*)f_5971},
{"f_5974:c_2dbackend_2escm",(void*)f_5974},
{"f_5977:c_2dbackend_2escm",(void*)f_5977},
{"f_7339:c_2dbackend_2escm",(void*)f_7339},
{"f_7049:c_2dbackend_2escm",(void*)f_7049},
{"f_7046:c_2dbackend_2escm",(void*)f_7046},
{"f_7043:c_2dbackend_2escm",(void*)f_7043},
{"f_8623:c_2dbackend_2escm",(void*)f_8623},
{"f_7385:c_2dbackend_2escm",(void*)f_7385},
{"f_3124:c_2dbackend_2escm",(void*)f_3124},
{"f_7383:c_2dbackend_2escm",(void*)f_7383},
{"f_7055:c_2dbackend_2escm",(void*)f_7055},
{"f_9124:c_2dbackend_2escm",(void*)f_9124},
{"f_7052:c_2dbackend_2escm",(void*)f_7052},
{"f_7058:c_2dbackend_2escm",(void*)f_7058},
{"f_4228:c_2dbackend_2escm",(void*)f_4228},
{"f_4225:c_2dbackend_2escm",(void*)f_4225},
{"f_8630:c_2dbackend_2escm",(void*)f_8630},
{"f_7064:c_2dbackend_2escm",(void*)f_7064},
{"f_7067:c_2dbackend_2escm",(void*)f_7067},
{"f_7061:c_2dbackend_2escm",(void*)f_7061},
{"f_10799:c_2dbackend_2escm",(void*)f_10799},
{"f_9986:c_2dbackend_2escm",(void*)f_9986},
{"f_10795:c_2dbackend_2escm",(void*)f_10795},
{"f_9983:c_2dbackend_2escm",(void*)f_9983},
{"f_8640:c_2dbackend_2escm",(void*)f_8640},
{"f_9980:c_2dbackend_2escm",(void*)f_9980},
{"f_6469:c_2dbackend_2escm",(void*)f_6469},
{"f_7121:c_2dbackend_2escm",(void*)f_7121},
{"f_7073:c_2dbackend_2escm",(void*)f_7073},
{"f_6492:c_2dbackend_2escm",(void*)f_6492},
{"f_7076:c_2dbackend_2escm",(void*)f_7076},
{"f_7079:c_2dbackend_2escm",(void*)f_7079},
{"f_7070:c_2dbackend_2escm",(void*)f_7070},
{"f_9974:c_2dbackend_2escm",(void*)f_9974},
{"f_8659:c_2dbackend_2escm",(void*)f_8659},
{"f_6495:c_2dbackend_2escm",(void*)f_6495},
{"f_7130:c_2dbackend_2escm",(void*)f_7130},
{"f_7377:c_2dbackend_2escm",(void*)f_7377},
{"f_7374:c_2dbackend_2escm",(void*)f_7374},
{"f_7371:c_2dbackend_2escm",(void*)f_7371},
{"f_7088:c_2dbackend_2escm",(void*)f_7088},
{"f_7127:c_2dbackend_2escm",(void*)f_7127},
{"f_7096:c_2dbackend_2escm",(void*)f_7096},
{"f_6433:c_2dbackend_2escm",(void*)f_6433},
{"f_9998:c_2dbackend_2escm",(void*)f_9998},
{"f_7092:c_2dbackend_2escm",(void*)f_7092},
{"f_7133:c_2dbackend_2escm",(void*)f_7133},
{"f_7139:c_2dbackend_2escm",(void*)f_7139},
{"f_10787:c_2dbackend_2escm",(void*)f_10787},
{"f_9151:c_2dbackend_2escm",(void*)f_9151},
{"f_8606:c_2dbackend_2escm",(void*)f_8606},
{"f_7142:c_2dbackend_2escm",(void*)f_7142},
{"f_10757:c_2dbackend_2escm",(void*)f_10757},
{"f_5873:c_2dbackend_2escm",(void*)f_5873},
{"f_5877:c_2dbackend_2escm",(void*)f_5877},
{"f_6846:c_2dbackend_2escm",(void*)f_6846},
{"f_8613:c_2dbackend_2escm",(void*)f_8613},
{"f_10765:c_2dbackend_2escm",(void*)f_10765},
{"f_5883:c_2dbackend_2escm",(void*)f_5883},
{"f_3603:c_2dbackend_2escm",(void*)f_3603},
{"f_7949:c_2dbackend_2escm",(void*)f_7949},
{"f_5292:c_2dbackend_2escm",(void*)f_5292},
{"f_6856:c_2dbackend_2escm",(void*)f_6856},
{"f_5222:c_2dbackend_2escm",(void*)f_5222},
{"f_10718:c_2dbackend_2escm",(void*)f_10718},
{"f_3639:c_2dbackend_2escm",(void*)f_3639},
{"f_3633:c_2dbackend_2escm",(void*)f_3633},
{"f_5278:c_2dbackend_2escm",(void*)f_5278},
{"f_5275:c_2dbackend_2escm",(void*)f_5275},
{"f_5272:c_2dbackend_2escm",(void*)f_5272},
{"f_4776:c_2dbackend_2escm",(void*)f_4776},
{"f_4779:c_2dbackend_2escm",(void*)f_4779},
{"f_6523:c_2dbackend_2escm",(void*)f_6523},
{"f_6526:c_2dbackend_2escm",(void*)f_6526},
{"f_6406:c_2dbackend_2escm",(void*)f_6406},
{"f_3617:c_2dbackend_2escm",(void*)f_3617},
{"f_3614:c_2dbackend_2escm",(void*)f_3614},
{"f_10705:c_2dbackend_2escm",(void*)f_10705},
{"f_10700:c_2dbackend_2escm",(void*)f_10700},
{"f_3620:c_2dbackend_2escm",(void*)f_3620},
{"f_4369:c_2dbackend_2escm",(void*)f_4369},
{"f_4361:c_2dbackend_2escm",(void*)f_4361},
{"f_4394:c_2dbackend_2escm",(void*)f_4394},
{"f_4391:c_2dbackend_2escm",(void*)f_4391},
{"f_4347:c_2dbackend_2escm",(void*)f_4347},
{"f_4341:c_2dbackend_2escm",(void*)f_4341},
{"f_4344:c_2dbackend_2escm",(void*)f_4344},
{"f_10734:c_2dbackend_2escm",(void*)f_10734},
{"f_5858:c_2dbackend_2escm",(void*)f_5858},
{"f_9959:c_2dbackend_2escm",(void*)f_9959},
{"f_9956:c_2dbackend_2escm",(void*)f_9956},
{"f_9953:c_2dbackend_2escm",(void*)f_9953},
{"f_8228:c_2dbackend_2escm",(void*)f_8228},
{"f_3267:c_2dbackend_2escm",(void*)f_3267},
{"f_5219:c_2dbackend_2escm",(void*)f_5219},
{"f_5838:c_2dbackend_2escm",(void*)f_5838},
{"f_5849:c_2dbackend_2escm",(void*)f_5849},
{"f_5845:c_2dbackend_2escm",(void*)f_5845},
{"f_5893:c_2dbackend_2escm",(void*)f_5893},
{"f_5890:c_2dbackend_2escm",(void*)f_5890},
{"f_4761:c_2dbackend_2escm",(void*)f_4761},
{"f_5201:c_2dbackend_2escm",(void*)f_5201},
{"f_4758:c_2dbackend_2escm",(void*)f_4758},
{"f_4743:c_2dbackend_2escm",(void*)f_4743},
{"f_4746:c_2dbackend_2escm",(void*)f_4746},
{"f_4311:c_2dbackend_2escm",(void*)f_4311},
{"f_4314:c_2dbackend_2escm",(void*)f_4314},
{"f_4733:c_2dbackend_2escm",(void*)f_4733},
{"f_4730:c_2dbackend_2escm",(void*)f_4730},
{"f_9896:c_2dbackend_2escm",(void*)f_9896},
{"f_7434:c_2dbackend_2escm",(void*)f_7434},
{"f_7438:c_2dbackend_2escm",(void*)f_7438},
{"f_4797:c_2dbackend_2escm",(void*)f_4797},
{"f_10519:c_2dbackend_2escm",(void*)f_10519},
{"f_10510:c_2dbackend_2escm",(void*)f_10510},
{"f_9875:c_2dbackend_2escm",(void*)f_9875},
{"f_9878:c_2dbackend_2escm",(void*)f_9878},
{"f_6559:c_2dbackend_2escm",(void*)f_6559},
{"f_4827:c_2dbackend_2escm",(void*)f_4827},
{"f_3925:c_2dbackend_2escm",(void*)f_3925},
{"f_3928:c_2dbackend_2escm",(void*)f_3928},
{"f_3921:c_2dbackend_2escm",(void*)f_3921},
{"f_3920:c_2dbackend_2escm",(void*)f_3920},
{"f_4815:c_2dbackend_2escm",(void*)f_4815},
{"f_4812:c_2dbackend_2escm",(void*)f_4812},
{"f_3934:c_2dbackend_2escm",(void*)f_3934},
{"f_9857:c_2dbackend_2escm",(void*)f_9857},
{"f_9854:c_2dbackend_2escm",(void*)f_9854},
{"f_9851:c_2dbackend_2escm",(void*)f_9851},
{"f_3418:c_2dbackend_2escm",(void*)f_3418},
{"f_3415:c_2dbackend_2escm",(void*)f_3415},
{"f_9881:c_2dbackend_2escm",(void*)f_9881},
{"f_6590:c_2dbackend_2escm",(void*)f_6590},
{"f_6597:c_2dbackend_2escm",(void*)f_6597},
{"f_6594:c_2dbackend_2escm",(void*)f_6594},
{"f_3917:c_2dbackend_2escm",(void*)f_3917},
{"f_5186:c_2dbackend_2escm",(void*)f_5186},
{"f_3449:c_2dbackend_2escm",(void*)f_3449},
{"f_5183:c_2dbackend_2escm",(void*)f_5183},
{"f_3445:c_2dbackend_2escm",(void*)f_3445},
{"f_3448:c_2dbackend_2escm",(void*)f_3448},
{"f_5180:c_2dbackend_2escm",(void*)f_5180},
{"f_3442:c_2dbackend_2escm",(void*)f_3442},
{"f_6545:c_2dbackend_2escm",(void*)f_6545},
{"f_6542:c_2dbackend_2escm",(void*)f_6542},
{"f_5189:c_2dbackend_2escm",(void*)f_5189},
{"f_5195:c_2dbackend_2escm",(void*)f_5195},
{"f_5198:c_2dbackend_2escm",(void*)f_5198},
{"f_5192:c_2dbackend_2escm",(void*)f_5192},
{"f_9869:c_2dbackend_2escm",(void*)f_9869},
{"f_5168:c_2dbackend_2escm",(void*)f_5168},
{"f_5165:c_2dbackend_2escm",(void*)f_5165},
{"f_5162:c_2dbackend_2escm",(void*)f_5162},
{"f_5177:c_2dbackend_2escm",(void*)f_5177},
{"f_5174:c_2dbackend_2escm",(void*)f_5174},
{"f_5171:c_2dbackend_2escm",(void*)f_5171},
{"f_6520:c_2dbackend_2escm",(void*)f_6520},
{"f_9094:c_2dbackend_2escm",(void*)f_9094},
{"f_9096:c_2dbackend_2escm",(void*)f_9096},
{"f_7002:c_2dbackend_2escm",(void*)f_7002},
{"f_5331:c_2dbackend_2escm",(void*)f_5331},
{"f_3494:c_2dbackend_2escm",(void*)f_3494},
{"f_5347:c_2dbackend_2escm",(void*)f_5347},
{"f_7160:c_2dbackend_2escm",(void*)f_7160},
{"f_8472:c_2dbackend_2escm",(void*)f_8472},
{"f_8476:c_2dbackend_2escm",(void*)f_8476},
{"f_3473:c_2dbackend_2escm",(void*)f_3473},
{"f_3476:c_2dbackend_2escm",(void*)f_3476},
{"f_3470:c_2dbackend_2escm",(void*)f_3470},
{"f_7169:c_2dbackend_2escm",(void*)f_7169},
{"f_7166:c_2dbackend_2escm",(void*)f_7166},
{"f_7163:c_2dbackend_2escm",(void*)f_7163},
{"f_5321:c_2dbackend_2escm",(void*)f_5321},
{"f_8494:c_2dbackend_2escm",(void*)f_8494},
{"f_8496:c_2dbackend_2escm",(void*)f_8496},
{"f_7172:c_2dbackend_2escm",(void*)f_7172},
{"f_6686:c_2dbackend_2escm",(void*)f_6686},
{"f_3453:c_2dbackend_2escm",(void*)f_3453},
{"f_3456:c_2dbackend_2escm",(void*)f_3456},
{"f_9364:c_2dbackend_2escm",(void*)f_9364},
{"f_6671:c_2dbackend_2escm",(void*)f_6671},
{"f_6676:c_2dbackend_2escm",(void*)f_6676},
{"f_3484:c_2dbackend_2escm",(void*)f_3484},
{"f_7197:c_2dbackend_2escm",(void*)f_7197},
{"f_4436:c_2dbackend_2escm",(void*)f_4436},
{"f_4439:c_2dbackend_2escm",(void*)f_4439},
{"f_4433:c_2dbackend_2escm",(void*)f_4433},
{"f_9355:c_2dbackend_2escm",(void*)f_9355},
{"f_6255:c_2dbackend_2escm",(void*)f_6255},
{"f_3462:c_2dbackend_2escm",(void*)f_3462},
{"f_4803:c_2dbackend_2escm",(void*)f_4803},
{"f_4806:c_2dbackend_2escm",(void*)f_4806},
{"f_4809:c_2dbackend_2escm",(void*)f_4809},
{"f_6282:c_2dbackend_2escm",(void*)f_6282},
{"f_4800:c_2dbackend_2escm",(void*)f_4800},
{"f_6288:c_2dbackend_2escm",(void*)f_6288},
{"f_6285:c_2dbackend_2escm",(void*)f_6285},
{"f_8468:c_2dbackend_2escm",(void*)f_8468},
{"f_8461:c_2dbackend_2escm",(void*)f_8461},
{"f_7303:c_2dbackend_2escm",(void*)f_7303},
{"f_7300:c_2dbackend_2escm",(void*)f_7300},
{"f_6279:c_2dbackend_2escm",(void*)f_6279},
{"f_6662:c_2dbackend_2escm",(void*)f_6662},
{"f_6658:c_2dbackend_2escm",(void*)f_6658},
{"f_6297:c_2dbackend_2escm",(void*)f_6297},
{"f_3105:c_2dbackend_2escm",(void*)f_3105},
{"f_7310:c_2dbackend_2escm",(void*)f_7310},
{"f_7318:c_2dbackend_2escm",(void*)f_7318},
{"f_3114:c_2dbackend_2escm",(void*)f_3114},
{"f_4955:c_2dbackend_2escm",(void*)f_4955},
{"f_6209:c_2dbackend_2escm",(void*)f_6209},
{"f_6644:c_2dbackend_2escm",(void*)f_6644},
{"f_6640:c_2dbackend_2escm",(void*)f_6640},
{"f_10586:c_2dbackend_2escm",(void*)f_10586},
{"f_6649:c_2dbackend_2escm",(void*)f_6649},
{"f_10059:c_2dbackend_2escm",(void*)f_10059},
{"f_4947:c_2dbackend_2escm",(void*)f_4947},
{"f_10055:c_2dbackend_2escm",(void*)f_10055},
{"f_5465:c_2dbackend_2escm",(void*)f_5465},
{"f_5462:c_2dbackend_2escm",(void*)f_5462},
{"f_5473:c_2dbackend_2escm",(void*)f_5473},
{"f_3864:c_2dbackend_2escm",(void*)f_3864},
{"f_3868:c_2dbackend_2escm",(void*)f_3868},
{"f_4995:c_2dbackend_2escm",(void*)f_4995},
{"f_4992:c_2dbackend_2escm",(void*)f_4992},
{"f_4045:c_2dbackend_2escm",(void*)f_4045},
{"f_3857:c_2dbackend_2escm",(void*)f_3857},
{"f_5253:c_2dbackend_2escm",(void*)f_5253},
{"f_3850:c_2dbackend_2escm",(void*)f_3850},
{"f_2996:c_2dbackend_2escm",(void*)f_2996},
{"f_5256:c_2dbackend_2escm",(void*)f_5256},
{"f_4989:c_2dbackend_2escm",(void*)f_4989},
{"f_2993:c_2dbackend_2escm",(void*)f_2993},
{"f_2990:c_2dbackend_2escm",(void*)f_2990},
{"f_5250:c_2dbackend_2escm",(void*)f_5250},
{"f_2987:c_2dbackend_2escm",(void*)f_2987},
{"f_4035:c_2dbackend_2escm",(void*)f_4035},
{"f_4032:c_2dbackend_2escm",(void*)f_4032},
{"f_9391:c_2dbackend_2escm",(void*)f_9391},
{"f_4029:c_2dbackend_2escm",(void*)f_4029},
{"f_3236:c_2dbackend_2escm",(void*)f_3236},
{"f_3232:c_2dbackend_2escm",(void*)f_3232},
{"f_7471:c_2dbackend_2escm",(void*)f_7471},
{"f_5247:c_2dbackend_2escm",(void*)f_5247},
{"f_5480:c_2dbackend_2escm",(void*)f_5480},
{"f_3053:c_2dbackend_2escm",(void*)f_3053},
{"f_3056:c_2dbackend_2escm",(void*)f_3056},
{"f_3059:c_2dbackend_2escm",(void*)f_3059},
{"f_5415:c_2dbackend_2escm",(void*)f_5415},
{"f_4085:c_2dbackend_2escm",(void*)f_4085},
{"f_4082:c_2dbackend_2escm",(void*)f_4082},
{"f_5417:c_2dbackend_2escm",(void*)f_5417},
{"f_2957:c_2dbackend_2escm",(void*)f_2957},
{"f_2954:c_2dbackend_2escm",(void*)f_2954},
{"f_4079:c_2dbackend_2escm",(void*)f_4079},
{"f_4076:c_2dbackend_2escm",(void*)f_4076},
{"f_3284:c_2dbackend_2escm",(void*)f_3284},
{"f_3288:c_2dbackend_2escm",(void*)f_3288},
{"f_4151:c_2dbackend_2escm",(void*)f_4151},
{"f_9830:c_2dbackend_2escm",(void*)f_9830},
{"f_4154:c_2dbackend_2escm",(void*)f_4154},
{"f_3273:c_2dbackend_2escm",(void*)f_3273},
{"f_7428:c_2dbackend_2escm",(void*)f_7428},
{"f_3270:c_2dbackend_2escm",(void*)f_3270},
{"f_8555:c_2dbackend_2escm",(void*)f_8555},
{"f_9818:c_2dbackend_2escm",(void*)f_9818},
{"f_4132:c_2dbackend_2escm",(void*)f_4132},
{"f_8521:c_2dbackend_2escm",(void*)f_8521},
{"f_9845:c_2dbackend_2escm",(void*)f_9845},
{"f_6382:c_2dbackend_2escm",(void*)f_6382},
{"f_4128:c_2dbackend_2escm",(void*)f_4128},
{"f_9842:c_2dbackend_2escm",(void*)f_9842},
{"f_8538:c_2dbackend_2escm",(void*)f_8538},
{"f_4971:c_2dbackend_2escm",(void*)f_4971},
{"f_4978:c_2dbackend_2escm",(void*)f_4978},
{"f_2960:c_2dbackend_2escm",(void*)f_2960},
{"f_2963:c_2dbackend_2escm",(void*)f_2963},
{"f_6373:c_2dbackend_2escm",(void*)f_6373},
{"f_4523:c_2dbackend_2escm",(void*)f_4523},
{"f_4526:c_2dbackend_2escm",(void*)f_4526},
{"f_4529:c_2dbackend_2escm",(void*)f_4529},
{"f_4520:c_2dbackend_2escm",(void*)f_4520},
{"f_9827:c_2dbackend_2escm",(void*)f_9827},
{"f_4965:c_2dbackend_2escm",(void*)f_4965},
{"f_9824:c_2dbackend_2escm",(void*)f_9824},
{"f_4969:c_2dbackend_2escm",(void*)f_4969},
{"f_5404:c_2dbackend_2escm",(void*)f_5404},
{"f_4514:c_2dbackend_2escm",(void*)f_4514},
{"f_4097:c_2dbackend_2escm",(void*)f_4097},
{"f_4517:c_2dbackend_2escm",(void*)f_4517},
{"f_6396:c_2dbackend_2escm",(void*)f_6396},
{"f_10850:c_2dbackend_2escm",(void*)f_10850},
{"f_10854:c_2dbackend_2escm",(void*)f_10854},
{"f_10858:c_2dbackend_2escm",(void*)f_10858},
{"f_7226:c_2dbackend_2escm",(void*)f_7226},
{"f_7229:c_2dbackend_2escm",(void*)f_7229},
{"f_9803:c_2dbackend_2escm",(void*)f_9803},
{"f_9806:c_2dbackend_2escm",(void*)f_9806},
{"f_9800:c_2dbackend_2escm",(void*)f_9800},
{"f_3716:c_2dbackend_2escm",(void*)f_3716},
{"f_3712:c_2dbackend_2escm",(void*)f_3712},
{"f_8545:c_2dbackend_2escm",(void*)f_8545},
{"f_9727:c_2dbackend_2escm",(void*)f_9727},
{"f_9725:c_2dbackend_2escm",(void*)f_9725},
{"f_10840:c_2dbackend_2escm",(void*)f_10840},
{"f_10843:c_2dbackend_2escm",(void*)f_10843},
{"f_10846:c_2dbackend_2escm",(void*)f_10846},
{"f_5375:c_2dbackend_2escm",(void*)f_5375},
{"f_5378:c_2dbackend_2escm",(void*)f_5378},
{"f_5573:c_2dbackend_2escm",(void*)f_5573},
{"f_5387:c_2dbackend_2escm",(void*)f_5387},
{"f_5384:c_2dbackend_2escm",(void*)f_5384},
{"f_5381:c_2dbackend_2escm",(void*)f_5381},
{"f_5354:c_2dbackend_2escm",(void*)f_5354},
{"f_5357:c_2dbackend_2escm",(void*)f_5357},
{"f_5351:c_2dbackend_2escm",(void*)f_5351},
{"f_10831:c_2dbackend_2escm",(void*)f_10831},
{"f_10837:c_2dbackend_2escm",(void*)f_10837},
{"f_10834:c_2dbackend_2escm",(void*)f_10834},
{"f_3402:c_2dbackend_2escm",(void*)f_3402},
{"f_3406:c_2dbackend_2escm",(void*)f_3406},
{"f_3724:c_2dbackend_2escm",(void*)f_3724},
{"f_5366:c_2dbackend_2escm",(void*)f_5366},
{"f_5363:c_2dbackend_2escm",(void*)f_5363},
{"f_5360:c_2dbackend_2escm",(void*)f_5360},
{"f_10801:c_2dbackend_2escm",(void*)f_10801},
{"f_3738:c_2dbackend_2escm",(void*)f_3738},
{"f_2514:c_2dbackend_2escm",(void*)f_2514},
{"f_2511:c_2dbackend_2escm",(void*)f_2511},
{"f_3731:c_2dbackend_2escm",(void*)f_3731},
{"f_7910:c_2dbackend_2escm",(void*)f_7910},
{"f_6313:c_2dbackend_2escm",(void*)f_6313},
{"f_4696:c_2dbackend_2escm",(void*)f_4696},
{"f_4699:c_2dbackend_2escm",(void*)f_4699},
{"f_6809:c_2dbackend_2escm",(void*)f_6809},
{"f_6807:c_2dbackend_2escm",(void*)f_6807},
{"f_4282:c_2dbackend_2escm",(void*)f_4282},
{"f_2520:c_2dbackend_2escm",(void*)f_2520},
{"f_7900:c_2dbackend_2escm",(void*)f_7900},
{"f_5548:c_2dbackend_2escm",(void*)f_5548},
{"f_5546:c_2dbackend_2escm",(void*)f_5546},
{"f_2517:c_2dbackend_2escm",(void*)f_2517},
{"f_5543:c_2dbackend_2escm",(void*)f_5543},
{"f_10825:c_2dbackend_2escm",(void*)f_10825},
{"f_4237:c_2dbackend_2escm",(void*)f_4237},
{"f11661:c_2dbackend_2escm",(void*)f11661},
{"f11669:c_2dbackend_2escm",(void*)f11669},
{"f_5397:c_2dbackend_2escm",(void*)f_5397},
{"f_5390:c_2dbackend_2escm",(void*)f_5390},
{"f_4261:c_2dbackend_2escm",(void*)f_4261},
{"f_4299:c_2dbackend_2escm",(void*)f_4299},
{"f_4295:c_2dbackend_2escm",(void*)f_4295},
{"f_8120:c_2dbackend_2escm",(void*)f_8120},
{"f_5308:c_2dbackend_2escm",(void*)f_5308},
{"f_5587:c_2dbackend_2escm",(void*)f_5587},
{"f_4642:c_2dbackend_2escm",(void*)f_4642},
{"f_4279:c_2dbackend_2escm",(void*)f_4279},
{"f_5306:c_2dbackend_2escm",(void*)f_5306},
{"f_10205:c_2dbackend_2escm",(void*)f_10205},
{"f_10202:c_2dbackend_2escm",(void*)f_10202},
{"f_4632:c_2dbackend_2escm",(void*)f_4632},
{"f_4638:c_2dbackend_2escm",(void*)f_4638},
{"f_5536:c_2dbackend_2escm",(void*)f_5536},
{"f_5605:c_2dbackend_2escm",(void*)f_5605},
{"f_4686:c_2dbackend_2escm",(void*)f_4686},
{"f_2572:c_2dbackend_2escm",(void*)f_2572},
{"f_8663:c_2dbackend_2escm",(void*)f_8663},
{"f_4671:c_2dbackend_2escm",(void*)f_4671},
{"f_4677:c_2dbackend_2escm",(void*)f_4677},
{"f_4674:c_2dbackend_2escm",(void*)f_4674},
{"f_2577:c_2dbackend_2escm",(void*)f_2577},
{"f_4661:c_2dbackend_2escm",(void*)f_4661},
{"f_2550:c_2dbackend_2escm",(void*)f_2550},
{"f_8684:c_2dbackend_2escm",(void*)f_8684},
{"f_8686:c_2dbackend_2escm",(void*)f_8686},
{"f_2587:c_2dbackend_2escm",(void*)f_2587},
{"f_2563:c_2dbackend_2escm",(void*)f_2563},
{"f_10281:c_2dbackend_2escm",(void*)f_10281},
{"f_4724:c_2dbackend_2escm",(void*)f_4724},
{"f_8249:c_2dbackend_2escm",(void*)f_8249},
{"f_4727:c_2dbackend_2escm",(void*)f_4727},
{"f_10287:c_2dbackend_2escm",(void*)f_10287},
{"f_4721:c_2dbackend_2escm",(void*)f_4721},
{"f_2540:c_2dbackend_2escm",(void*)f_2540},
{"f_10290:c_2dbackend_2escm",(void*)f_10290},
{"f_10293:c_2dbackend_2escm",(void*)f_10293},
{"f_7115:c_2dbackend_2escm",(void*)f_7115},
{"f_7112:c_2dbackend_2escm",(void*)f_7112},
{"f_6421:c_2dbackend_2escm",(void*)f_6421},
{"f_6423:c_2dbackend_2escm",(void*)f_6423},
{"f_7106:c_2dbackend_2escm",(void*)f_7106},
{"f_3685:c_2dbackend_2escm",(void*)f_3685},
{"f_7100:c_2dbackend_2escm",(void*)f_7100},
{"f_6459:c_2dbackend_2escm",(void*)f_6459},
{"f_3675:c_2dbackend_2escm",(void*)f_3675},
{"f_3531:c_2dbackend_2escm",(void*)f_3531},
{"f_3665:c_2dbackend_2escm",(void*)f_3665},
{"f_3668:c_2dbackend_2escm",(void*)f_3668},
{"f_3521:c_2dbackend_2escm",(void*)f_3521},
{"f_6818:c_2dbackend_2escm",(void*)f_6818},
{"f_3662:c_2dbackend_2escm",(void*)f_3662},
{"f_3659:c_2dbackend_2escm",(void*)f_3659},
{"f_7898:c_2dbackend_2escm",(void*)f_7898},
{"f_2778:c_2dbackend_2escm",(void*)f_2778},
{"f_2772:c_2dbackend_2escm",(void*)f_2772},
{"f_2775:c_2dbackend_2escm",(void*)f_2775},
{"f_2787:c_2dbackend_2escm",(void*)f_2787},
{"f_2784:c_2dbackend_2escm",(void*)f_2784},
{"f_2781:c_2dbackend_2escm",(void*)f_2781},
{"f_3699:c_2dbackend_2escm",(void*)f_3699},
{"f_3593:c_2dbackend_2escm",(void*)f_3593},
{"f_3692:c_2dbackend_2escm",(void*)f_3692},
{"f_3062:c_2dbackend_2escm",(void*)f_3062},
{"f_3590:c_2dbackend_2escm",(void*)f_3590},
{"f_5459:c_2dbackend_2escm",(void*)f_5459},
{"f_5456:c_2dbackend_2escm",(void*)f_5456},
{"f_5450:c_2dbackend_2escm",(void*)f_5450},
{"f_3584:c_2dbackend_2escm",(void*)f_3584},
{"f_3587:c_2dbackend_2escm",(void*)f_3587},
{"f_5423:c_2dbackend_2escm",(void*)f_5423},
{"f_7276:c_2dbackend_2escm",(void*)f_7276},
{"f_7271:c_2dbackend_2escm",(void*)f_7271},
{"f_5433:c_2dbackend_2escm",(void*)f_5433},
{"f_6915:c_2dbackend_2escm",(void*)f_6915},
{"f_3033:c_2dbackend_2escm",(void*)f_3033},
{"f_3030:c_2dbackend_2escm",(void*)f_3030},
{"f_6909:c_2dbackend_2escm",(void*)f_6909},
{"f_6907:c_2dbackend_2escm",(void*)f_6907},
{"f_3024:c_2dbackend_2escm",(void*)f_3024},
{"f_3027:c_2dbackend_2escm",(void*)f_3027},
{"f_4329:c_2dbackend_2escm",(void*)f_4329},
{"f_6991:c_2dbackend_2escm",(void*)f_6991},
{"f_6969:c_2dbackend_2escm",(void*)f_6969},
{"f_6004:c_2dbackend_2escm",(void*)f_6004},
{"f_6007:c_2dbackend_2escm",(void*)f_6007},
{"f_4325:c_2dbackend_2escm",(void*)f_4325},
{"f_6001:c_2dbackend_2escm",(void*)f_6001},
{"f_3099:c_2dbackend_2escm",(void*)f_3099},
{"f_3093:c_2dbackend_2escm",(void*)f_3093},
{"f_3090:c_2dbackend_2escm",(void*)f_3090},
{"f_6982:c_2dbackend_2escm",(void*)f_6982},
{"f_4350:c_2dbackend_2escm",(void*)f_4350},
{"f_5612:c_2dbackend_2escm",(void*)f_5612},
{"f_6171:c_2dbackend_2escm",(void*)f_6171},
{"f_6174:c_2dbackend_2escm",(void*)f_6174},
{"f_6929:c_2dbackend_2escm",(void*)f_6929},
{"f_3572:c_2dbackend_2escm",(void*)f_3572},
{"f_6925:c_2dbackend_2escm",(void*)f_6925},
{"f_3575:c_2dbackend_2escm",(void*)f_3575},
{"f_6923:c_2dbackend_2escm",(void*)f_6923},
{"f_3085:c_2dbackend_2escm",(void*)f_3085},
{"f_3086:c_2dbackend_2escm",(void*)f_3086},
{"f_7286:c_2dbackend_2escm",(void*)f_7286},
{"f_6988:c_2dbackend_2escm",(void*)f_6988},
{"f_6022:c_2dbackend_2escm",(void*)f_6022},
{"f_6028:c_2dbackend_2escm",(void*)f_6028},
{"f_6025:c_2dbackend_2escm",(void*)f_6025},
{"f_3563:c_2dbackend_2escm",(void*)f_3563},
{"f_3569:c_2dbackend_2escm",(void*)f_3569},
{"f_6177:c_2dbackend_2escm",(void*)f_6177},
{"f_7837:c_2dbackend_2escm",(void*)f_7837},
{"f_6013:c_2dbackend_2escm",(void*)f_6013},
{"f_4702:c_2dbackend_2escm",(void*)f_4702},
{"f_6010:c_2dbackend_2escm",(void*)f_6010},
{"f_6019:c_2dbackend_2escm",(void*)f_6019},
{"f_6016:c_2dbackend_2escm",(void*)f_6016},
{"f_6167:c_2dbackend_2escm",(void*)f_6167},
{"f_7849:c_2dbackend_2escm",(void*)f_7849},
{"f_7846:c_2dbackend_2escm",(void*)f_7846},
{"f_7843:c_2dbackend_2escm",(void*)f_7843},
{"f_6043:c_2dbackend_2escm",(void*)f_6043},
{"f_6040:c_2dbackend_2escm",(void*)f_6040},
{"f_6183:c_2dbackend_2escm",(void*)f_6183},
{"f_6180:c_2dbackend_2escm",(void*)f_6180},
{"f_7840:c_2dbackend_2escm",(void*)f_7840},
{"f_6049:c_2dbackend_2escm",(void*)f_6049},
{"f_6046:c_2dbackend_2escm",(void*)f_6046},
{"f_7404:c_2dbackend_2escm",(void*)f_7404},
{"f_6198:c_2dbackend_2escm",(void*)f_6198},
{"f_6195:c_2dbackend_2escm",(void*)f_6195},
{"f_6031:c_2dbackend_2escm",(void*)f_6031},
{"f_6034:c_2dbackend_2escm",(void*)f_6034},
{"f_7852:c_2dbackend_2escm",(void*)f_7852},
{"f_6037:c_2dbackend_2escm",(void*)f_6037},
{"f_6186:c_2dbackend_2escm",(void*)f_6186},
{"f_7867:c_2dbackend_2escm",(void*)f_7867},
{"f_7864:c_2dbackend_2escm",(void*)f_7864},
{"f_8711:c_2dbackend_2escm",(void*)f_8711},
{"f_6062:c_2dbackend_2escm",(void*)f_6062},
{"f_7861:c_2dbackend_2escm",(void*)f_7861},
{"f_6069:c_2dbackend_2escm",(void*)f_6069},
{"f_5774:c_2dbackend_2escm",(void*)f_5774},
{"f_7876:c_2dbackend_2escm",(void*)f_7876},
{"f_7879:c_2dbackend_2escm",(void*)f_7879},
{"f_6055:c_2dbackend_2escm",(void*)f_6055},
{"f_6052:c_2dbackend_2escm",(void*)f_6052},
{"f_7873:c_2dbackend_2escm",(void*)f_7873},
{"f_7870:c_2dbackend_2escm",(void*)f_7870},
{"f_6058:c_2dbackend_2escm",(void*)f_6058},
{"f_7416:c_2dbackend_2escm",(void*)f_7416},
{"f_6085:c_2dbackend_2escm",(void*)f_6085},
{"f_6088:c_2dbackend_2escm",(void*)f_6088},
{"f_3997:c_2dbackend_2escm",(void*)f_3997},
{"f_6121:c_2dbackend_2escm",(void*)f_6121},
{"f_6136:c_2dbackend_2escm",(void*)f_6136},
{"f_6139:c_2dbackend_2escm",(void*)f_6139},
{"f_3987:c_2dbackend_2escm",(void*)f_3987},
{"toplevel:c_2dbackend_2escm",(void*)C_backend_toplevel},
{"f_9468:c_2dbackend_2escm",(void*)f_9468},
{"f_6097:c_2dbackend_2escm",(void*)f_6097},
{"f_4882:c_2dbackend_2escm",(void*)f_4882},
{"f_4886:c_2dbackend_2escm",(void*)f_4886},
{"f_6951:c_2dbackend_2escm",(void*)f_6951},
{"f_8388:c_2dbackend_2escm",(void*)f_8388},
{"f_8384:c_2dbackend_2escm",(void*)f_8384},
{"f_6625:c_2dbackend_2escm",(void*)f_6625},
{"f_6622:c_2dbackend_2escm",(void*)f_6622},
{"f_6628:c_2dbackend_2escm",(void*)f_6628},
{"f_10199:c_2dbackend_2escm",(void*)f_10199},
{"f_4878:c_2dbackend_2escm",(void*)f_4878},
{"f_10193:c_2dbackend_2escm",(void*)f_10193},
{"f_6959:c_2dbackend_2escm",(void*)f_6959},
{"f_3950:c_2dbackend_2escm",(void*)f_3950},
{"f_2885:c_2dbackend_2escm",(void*)f_2885},
{"f_2882:c_2dbackend_2escm",(void*)f_2882},
{"f_2888:c_2dbackend_2escm",(void*)f_2888},
{"f_2830:c_2dbackend_2escm",(void*)f_2830},
{"f_6613:c_2dbackend_2escm",(void*)f_6613},
{"f_6619:c_2dbackend_2escm",(void*)f_6619},
{"f_6616:c_2dbackend_2escm",(void*)f_6616},
{"f_3945:c_2dbackend_2escm",(void*)f_3945},
{"f_6610:c_2dbackend_2escm",(void*)f_6610},
{"f_6107:c_2dbackend_2escm",(void*)f_6107},
{"f_3942:c_2dbackend_2escm",(void*)f_3942},
{"f_8369:c_2dbackend_2escm",(void*)f_8369},
{"f_10178:c_2dbackend_2escm",(void*)f_10178},
{"f_10175:c_2dbackend_2escm",(void*)f_10175},
{"f_10608:c_2dbackend_2escm",(void*)f_10608},
{"f_3960:c_2dbackend_2escm",(void*)f_3960},
{"f_10181:c_2dbackend_2escm",(void*)f_10181},
{"f_4482:c_2dbackend_2escm",(void*)f_4482},
{"f_2843:c_2dbackend_2escm",(void*)f_2843},
{"f_2840:c_2dbackend_2escm",(void*)f_2840},
{"f_2846:c_2dbackend_2escm",(void*)f_2846},
{"f_8357:c_2dbackend_2escm",(void*)f_8357},
{"f_5761:c_2dbackend_2escm",(void*)f_5761},
{"f_5767:c_2dbackend_2escm",(void*)f_5767},
{"f_5764:c_2dbackend_2escm",(void*)f_5764},
{"f_4479:c_2dbackend_2escm",(void*)f_4479},
{"f_4476:c_2dbackend_2escm",(void*)f_4476},
{"f_4473:c_2dbackend_2escm",(void*)f_4473},
{"f_3158:c_2dbackend_2escm",(void*)f_3158},
{"f_5734:c_2dbackend_2escm",(void*)f_5734},
{"f_4463:c_2dbackend_2escm",(void*)f_4463},
{"f_4460:c_2dbackend_2escm",(void*)f_4460},
{"f_4450:c_2dbackend_2escm",(void*)f_4450},
{"f_10233:c_2dbackend_2escm",(void*)f_10233},
{"f_10239:c_2dbackend_2escm",(void*)f_10239},
{"f_5511:c_2dbackend_2escm",(void*)f_5511},
{"f_5515:c_2dbackend_2escm",(void*)f_5515},
{"f_10242:c_2dbackend_2escm",(void*)f_10242},
{"f_10245:c_2dbackend_2escm",(void*)f_10245},
{"f_9908:c_2dbackend_2escm",(void*)f_9908},
{"f_10121:c_2dbackend_2escm",(void*)f_10121},
{"f_9905:c_2dbackend_2escm",(void*)f_9905},
{"f_4867:c_2dbackend_2escm",(void*)f_4867},
{"f_9902:c_2dbackend_2escm",(void*)f_9902},
{"f_10127:c_2dbackend_2escm",(void*)f_10127},
{"f_10257:c_2dbackend_2escm",(void*)f_10257},
{"f_5817:c_2dbackend_2escm",(void*)f_5817},
{"f_10269:c_2dbackend_2escm",(void*)f_10269},
{"f_10263:c_2dbackend_2escm",(void*)f_10263},
{"f_10266:c_2dbackend_2escm",(void*)f_10266},
{"f_10103:c_2dbackend_2escm",(void*)f_10103},
{"f_9929:c_2dbackend_2escm",(void*)f_9929},
{"f_4847:c_2dbackend_2escm",(void*)f_4847},
{"f_5822:c_2dbackend_2escm",(void*)f_5822},
{"f_10109:c_2dbackend_2escm",(void*)f_10109},
{"f_9923:c_2dbackend_2escm",(void*)f_9923},
{"f_10106:c_2dbackend_2escm",(void*)f_10106},
{"f_10151:c_2dbackend_2escm",(void*)f_10151},
{"f_10154:c_2dbackend_2escm",(void*)f_10154},
{"f_4837:c_2dbackend_2escm",(void*)f_4837},
{"f_10157:c_2dbackend_2escm",(void*)f_10157},
{"f_9947:c_2dbackend_2escm",(void*)f_9947},
{"f_7328:c_2dbackend_2escm",(void*)f_7328},
{"f_10169:c_2dbackend_2escm",(void*)f_10169},
{"f_9935:c_2dbackend_2escm",(void*)f_9935},
{"f_4890:c_2dbackend_2escm",(void*)f_4890},
{"f_10130:c_2dbackend_2escm",(void*)f_10130},
{"f_4894:c_2dbackend_2escm",(void*)f_4894},
{"f_10133:c_2dbackend_2escm",(void*)f_10133},
{"f_9932:c_2dbackend_2escm",(void*)f_9932},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  map		4
S|  sprintf		21
S|  for-each		18
o|eliminated procedure checks: 132 
o|specializations:
o|  1 (number->string fixnum)
o|  1 (cdddr (pair * (pair * pair)))
o|  3 (>= fixnum fixnum)
o|  1 (> fixnum fixnum)
o|  2 (memq * list)
o|  8 (= fixnum fixnum)
o|  2 (char=? char char)
o|  1 (char>? char char)
o|  1 (char<? char char)
o|  4 (length list)
o|  2 (zero? number)
o|  1 (vector-length vector)
o|  2 (bitwise-and fixnum fixnum)
o|  3 (zero? fixnum)
o|  4 (string-append string string)
o|  5 (car pair)
o|  1 (cddr (pair * pair))
o|  7 (cdr pair)
o|  3 (first pair)
o|  274 (eqv? * (not float))
o|  21 (##sys#check-output-port * * *)
o|  18 (##sys#check-list (or pair list) *)
(o e)|safe calls: 973 
o|safe globals: (##compiler#gen-list ##compiler#gen ##compiler#output) 
o|Removed `not' forms: 19 
o|inlining procedure: k2542 
o|contracted procedure: "(c-backend.scm:39) g2835" 
o|inlining procedure: k2524 
o|inlining procedure: k2524 
o|inlining procedure: k2542 
o|inlining procedure: k2579 
o|contracted procedure: "(c-backend.scm:47) g4855" 
o|inlining procedure: k2579 
o|inlining procedure: k2615 
o|inlining procedure: k2615 
o|inlining procedure: k2651 
o|inlining procedure: k2670 
o|inlining procedure: k2670 
o|inlining procedure: k2676 
o|inlining procedure: k2676 
o|inlining procedure: k2702 
o|inlining procedure: k2702 
o|substituted constant variable: a2728 
o|substituted constant variable: a2730 
o|substituted constant variable: a2732 
o|substituted constant variable: a2734 
o|substituted constant variable: a2736 
o|inlining procedure: k2651 
o|inlining procedure: k2746 
o|inlining procedure: k2746 
o|inlining procedure: k2764 
o|inlining procedure: k2764 
o|inlining procedure: k2816 
o|inlining procedure: k2832 
o|inlining procedure: k2832 
o|inlining procedure: k2816 
o|inlining procedure: k2900 
o|inlining procedure: k2900 
o|inlining procedure: k2946 
o|inlining procedure: k2946 
o|inlining procedure: k3016 
o|inlining procedure: k3016 
o|inlining procedure: k3074 
o|inlining procedure: k3116 
o|inlining procedure: k3116 
o|inlining procedure: k3074 
o|inlining procedure: k3169 
o|inlining procedure: k3169 
o|inlining procedure: k3202 
o|inlining procedure: k3220 
o|inlining procedure: k3220 
o|inlining procedure: k3241 
o|inlining procedure: k3241 
o|inlining procedure: k3202 
o|inlining procedure: k3295 
o|inlining procedure: k3295 
o|inlining procedure: k3364 
o|contracted procedure: "(c-backend.scm:253) g265266" 
o|inlining procedure: k3434 
o|inlining procedure: k3474 
o|inlining procedure: k3474 
o|inlining procedure: k3486 
o|contracted procedure: "(c-backend.scm:266) g306314" 
o|inlining procedure: k3486 
o|inlining procedure: k3523 
o|inlining procedure: k3523 
o|inlining procedure: k3564 
o|inlining procedure: k3564 
o|contracted procedure: k3604 
o|inlining procedure: k3601 
o|inlining procedure: k3601 
o|substituted constant variable: a3610 
o|inlining procedure: k3434 
o|inlining procedure: k3693 
o|inlining procedure: k3693 
o|contracted procedure: "(c-backend.scm:291) g351352" 
o|inlining procedure: k3765 
o|inlining procedure: k3765 
o|propagated global variable: tmp369371 unsafe 
o|propagated global variable: tmp369371 unsafe 
o|propagated global variable: tmp372374 ##compiler#no-procedure-checks 
o|inlining procedure: k3780 
o|propagated global variable: tmp372374 ##compiler#no-procedure-checks 
o|inlining procedure: k3780 
o|substituted constant variable: a3787 
o|contracted procedure: k3798 
o|propagated global variable: r3799 unsafe 
o|inlining procedure: k3795 
o|inlining procedure: k3795 
o|contracted procedure: k3804 
o|propagated global variable: r3805 ##compiler#no-procedure-checks 
o|contracted procedure: "(c-backend.scm:287) g345346" 
o|contracted procedure: "(c-backend.scm:250) g261262" 
o|inlining procedure: k3828 
o|inlining procedure: k3838 
o|inlining procedure: k3838 
o|inlining procedure: k3828 
o|inlining procedure: k3872 
o|inlining procedure: k3872 
o|inlining procedure: k3364 
o|inlining procedure: k3912 
o|inlining procedure: k3952 
o|contracted procedure: "(c-backend.scm:346) g421429" 
o|inlining procedure: k3952 
o|inlining procedure: k3989 
o|inlining procedure: k3989 
o|inlining procedure: k3912 
o|inlining procedure: k4046 
o|inlining procedure: k4098 
o|inlining procedure: k4098 
o|inlining procedure: k4110 
o|inlining procedure: k4110 
o|inlining procedure: k4046 
o|inlining procedure: k4162 
o|inlining procedure: k4162 
o|inlining procedure: k4200 
o|inlining procedure: k4214 
o|inlining procedure: k4214 
o|inlining procedure: k4200 
o|inlining procedure: k4226 
o|inlining procedure: k4226 
o|inlining procedure: k4249 
o|inlining procedure: k4249 
o|inlining procedure: k4300 
o|inlining procedure: k4300 
o|inlining procedure: k4370 
o|inlining procedure: k4370 
o|inlining procedure: k4406 
o|inlining procedure: k4406 
o|inlining procedure: k4452 
o|inlining procedure: k4452 
o|inlining procedure: k4506 
o|inlining procedure: k4506 
o|contracted procedure: "(c-backend.scm:467) g510511" 
o|substituted constant variable: a4558 
o|substituted constant variable: a4560 
o|substituted constant variable: a4562 
o|substituted constant variable: a4564 
o|substituted constant variable: a4566 
o|substituted constant variable: a4568 
o|substituted constant variable: a4570 
o|substituted constant variable: a4572 
o|substituted constant variable: a4574 
o|substituted constant variable: a4576 
o|substituted constant variable: a4578 
o|substituted constant variable: a4580 
o|substituted constant variable: a4582 
o|substituted constant variable: a4584 
o|substituted constant variable: a4586 
o|substituted constant variable: a4588 
o|substituted constant variable: a4590 
o|substituted constant variable: a4592 
o|substituted constant variable: a4594 
o|substituted constant variable: a4596 
o|substituted constant variable: a4598 
o|substituted constant variable: a4600 
o|substituted constant variable: a4602 
o|substituted constant variable: a4604 
o|substituted constant variable: a4606 
o|substituted constant variable: a4608 
o|substituted constant variable: a4610 
o|substituted constant variable: a4612 
o|substituted constant variable: a4614 
o|substituted constant variable: a4616 
o|substituted constant variable: a4618 
o|substituted constant variable: a4620 
o|substituted constant variable: a4622 
o|substituted constant variable: a4624 
o|substituted constant variable: a4626 
o|substituted constant variable: a4628 
o|substituted constant variable: a4630 
o|contracted procedure: "(c-backend.scm:81) g130131" 
o|contracted procedure: "(c-backend.scm:80) g121122" 
o|contracted procedure: "(c-backend.scm:79) g118119" 
o|contracted procedure: k4650 
o|inlining procedure: k4688 
o|inlining procedure: k4688 
o|inlining procedure: k4744 
o|inlining procedure: k4744 
o|inlining procedure: k4751 
o|inlining procedure: k4751 
o|inlining procedure: k4763 
o|substituted constant variable: a4772 
o|inlining procedure: k4763 
o|inlining procedure: k4816 
o|inlining procedure: k4816 
o|inlining procedure: k4839 
o|contracted procedure: "(c-backend.scm:533) g596603" 
o|inlining procedure: k4839 
o|propagated global variable: g602604 ##compiler#foreign-declarations 
o|inlining procedure: k4913 
o|contracted procedure: "(c-backend.scm:518) g563572" 
o|inlining procedure: k4913 
o|inlining procedure: k5002 
o|inlining procedure: k5002 
o|inlining procedure: k5042 
o|inlining procedure: k5042 
o|inlining procedure: k5069 
o|inlining procedure: k5069 
o|substituted constant variable: a5102 
o|inlining procedure: k5122 
o|contracted procedure: "(c-backend.scm:548) g624631" 
o|inlining procedure: k5122 
o|propagated global variable: g630632 ##compiler#used-units 
o|inlining procedure: k5199 
o|inlining procedure: k5199 
o|inlining procedure: k5223 
o|inlining procedure: k5223 
o|contracted procedure: k5242 
o|inlining procedure: k5254 
o|inlining procedure: k5254 
o|inlining procedure: k5267 
o|inlining procedure: k5267 
o|inlining procedure: k5294 
o|inlining procedure: k5294 
o|inlining procedure: k5367 
o|contracted procedure: "(c-backend.scm:637) restore703" 
o|inlining procedure: k5323 
o|inlining procedure: k5323 
o|inlining procedure: k5367 
o|contracted procedure: k5398 
o|inlining procedure: k5425 
o|inlining procedure: k5425 
o|substituted constant variable: a5452 
o|substituted constant variable: a5453 
o|inlining procedure: k5475 
o|inlining procedure: k5475 
o|inlining procedure: k5487 
o|propagated global variable: r548811059 ##compiler#words-per-flonum 
o|inlining procedure: k5487 
o|inlining procedure: k5499 
o|inlining procedure: k5499 
o|inlining procedure: k5550 
o|inlining procedure: k5550 
o|inlining procedure: k5582 
o|inlining procedure: k5582 
o|inlining procedure: "(c-backend.scm:661) bad-literal97" 
o|inlining procedure: k5597 
o|inlining procedure: k5597 
o|inlining procedure: k5617 
o|inlining procedure: k5636 
o|inlining procedure: k5636 
o|inlining procedure: k5617 
o|inlining procedure: "(c-backend.scm:670) bad-literal97" 
o|inlining procedure: k5667 
o|inlining procedure: k5667 
o|inlining procedure: k5682 
o|inlining procedure: k5682 
o|inlining procedure: k5701 
o|inlining procedure: k5701 
o|inlining procedure: k5704 
o|inlining procedure: k5704 
o|inlining procedure: k5738 
o|inlining procedure: k5738 
o|inlining procedure: k5753 
o|inlining procedure: k5753 
o|inlining procedure: "(c-backend.scm:697) bad-literal97" 
o|contracted procedure: k5785 
o|inlining procedure: k5824 
o|inlining procedure: k5824 
o|inlining procedure: k6071 
o|inlining procedure: k6071 
o|inlining procedure: k6080 
o|inlining procedure: k6099 
o|inlining procedure: k6099 
o|inlining procedure: k6080 
o|contracted procedure: k6152 
o|contracted procedure: k6190 
o|inlining procedure: k6184 
o|inlining procedure: k6184 
o|inlining procedure: k6210 
o|inlining procedure: k6210 
o|inlining procedure: k6235 
o|contracted procedure: k6259 
o|propagated global variable: r6260 unsafe 
o|contracted procedure: k6265 
o|propagated global variable: r6266 ##compiler#no-argc-checks 
o|inlining procedure: k6262 
o|inlining procedure: k6262 
o|inlining procedure: k6235 
o|contracted procedure: k6292 
o|inlining procedure: k6302 
o|inlining procedure: k6302 
o|inlining procedure: k6314 
o|inlining procedure: k6314 
o|contracted procedure: k6335 
o|propagated global variable: r6336 unsafe 
o|inlining procedure: k6332 
o|inlining procedure: k6332 
o|contracted procedure: k6341 
o|propagated global variable: r6342 ##compiler#no-argc-checks 
o|contracted procedure: k6359 
o|propagated global variable: r6360 unsafe 
o|inlining procedure: k6356 
o|inlining procedure: k6356 
o|contracted procedure: "(c-backend.scm:789) utype102" 
o|inlining procedure: k5897 
o|inlining procedure: k5897 
o|inlining procedure: k5909 
o|inlining procedure: k5909 
o|inlining procedure: k5921 
o|inlining procedure: k5921 
o|substituted constant variable: a5937 
o|substituted constant variable: a5939 
o|substituted constant variable: a5941 
o|substituted constant variable: a5943 
o|substituted constant variable: a5945 
o|substituted constant variable: a5947 
o|inlining procedure: k6398 
o|inlining procedure: k6398 
o|inlining procedure: k6425 
o|inlining procedure: k6425 
o|inlining procedure: k6446 
o|inlining procedure: k6446 
o|inlining procedure: k6461 
o|inlining procedure: k6461 
o|inlining procedure: k6496 
o|inlining procedure: k6496 
o|contracted procedure: k6515 
o|inlining procedure: k6524 
o|inlining procedure: k6524 
o|inlining procedure: k6537 
o|inlining procedure: k6537 
o|inlining procedure: k6567 
o|inlining procedure: k6567 
o|inlining procedure: k6574 
o|inlining procedure: k6574 
o|inlining procedure: k6581 
o|inlining procedure: k6581 
o|contracted procedure: "(c-backend.scm:889) trailer92" 
o|inlining procedure: k6717 
o|contracted procedure: "(c-backend.scm:896) g10131020" 
o|inlining procedure: k6678 
o|contracted procedure: "(c-backend.scm:899) g10261033" 
o|inlining procedure: k6678 
o|inlining procedure: k6717 
o|inlining procedure: k6778 
o|inlining procedure: k6778 
o|inlining procedure: k6820 
o|inlining procedure: k6820 
o|substituted constant variable: a6843 
o|inlining procedure: k6857 
o|inlining procedure: k6857 
o|substituted constant variable: a6864 
o|inlining procedure: k6865 
o|inlining procedure: k6865 
o|substituted constant variable: a6872 
o|inlining procedure: k6873 
o|substituted constant variable: a6879 
o|inlining procedure: k6873 
o|inlining procedure: k6961 
o|contracted procedure: "(c-backend.scm:969) g10971104" 
o|inlining procedure: k6961 
o|inlining procedure: k7004 
o|contracted procedure: "(c-backend.scm:980) g11211128" 
o|inlining procedure: k7004 
o|inlining procedure: k7131 
o|inlining procedure: k7149 
o|inlining procedure: k7149 
o|inlining procedure: k7131 
o|inlining procedure: k7179 
o|inlining procedure: k7179 
o|contracted procedure: k7202 
o|inlining procedure: k7221 
o|contracted procedure: "(c-backend.scm:1020) g11821191" 
o|inlining procedure: k7098 
o|substituted constant variable: a7108 
o|substituted constant variable: a7109 
o|inlining procedure: k7098 
o|inlining procedure: k7221 
o|inlining procedure: k7260 
o|inlining procedure: k7260 
o|inlining procedure: k7278 
o|inlining procedure: k7278 
o|inlining procedure: k7341 
o|inlining procedure: k7341 
o|inlining procedure: k7387 
o|inlining procedure: k7387 
o|inlining procedure: k7408 
o|inlining procedure: k7408 
o|inlining procedure: k7444 
o|inlining procedure: k7444 
o|inlining procedure: k7435 
o|inlining procedure: k7435 
o|inlining procedure: k7463 
o|inlining procedure: k7463 
o|substituted constant variable: a7489 
o|inlining procedure: k7493 
o|inlining procedure: k7493 
o|inlining procedure: k7505 
o|inlining procedure: k7505 
o|inlining procedure: k7517 
o|inlining procedure: k7517 
o|inlining procedure: k7529 
o|inlining procedure: k7529 
o|substituted constant variable: a7536 
o|substituted constant variable: a7538 
o|substituted constant variable: a7540 
o|substituted constant variable: a7542 
o|substituted constant variable: a7544 
o|substituted constant variable: a7546 
o|substituted constant variable: a7548 
o|substituted constant variable: a7550 
o|substituted constant variable: a7552 
o|inlining procedure: k7562 
o|inlining procedure: k7562 
o|inlining procedure: k7574 
o|inlining procedure: k7574 
o|substituted constant variable: a7581 
o|substituted constant variable: a7583 
o|substituted constant variable: a7585 
o|substituted constant variable: a7587 
o|substituted constant variable: a7589 
o|inlining procedure: k7593 
o|inlining procedure: k7593 
o|inlining procedure: k7605 
o|inlining procedure: k7605 
o|substituted constant variable: a7612 
o|substituted constant variable: a7614 
o|substituted constant variable: a7616 
o|substituted constant variable: a7618 
o|substituted constant variable: a7620 
o|inlining procedure: k7624 
o|inlining procedure: k7624 
o|inlining procedure: k7636 
o|inlining procedure: k7636 
o|inlining procedure: k7648 
o|inlining procedure: k7648 
o|inlining procedure: k7660 
o|inlining procedure: k7660 
o|inlining procedure: k7672 
o|inlining procedure: k7672 
o|inlining procedure: k7684 
o|inlining procedure: k7684 
o|inlining procedure: k7696 
o|inlining procedure: k7696 
o|substituted constant variable: a7709 
o|substituted constant variable: a7711 
o|substituted constant variable: a7713 
o|substituted constant variable: a7715 
o|substituted constant variable: a7717 
o|substituted constant variable: a7719 
o|substituted constant variable: a7721 
o|substituted constant variable: a7723 
o|substituted constant variable: a7725 
o|substituted constant variable: a7727 
o|substituted constant variable: a7729 
o|substituted constant variable: a7731 
o|substituted constant variable: a7733 
o|substituted constant variable: a7735 
o|substituted constant variable: a7737 
o|substituted constant variable: a7739 
o|inlining procedure: k7743 
o|inlining procedure: k7743 
o|inlining procedure: k7755 
o|inlining procedure: k7755 
o|inlining procedure: k7767 
o|inlining procedure: k7767 
o|inlining procedure: k7779 
o|inlining procedure: k7779 
o|inlining procedure: k7791 
o|inlining procedure: k7791 
o|inlining procedure: k7803 
o|inlining procedure: k7803 
o|substituted constant variable: a7810 
o|substituted constant variable: a7812 
o|substituted constant variable: a7814 
o|substituted constant variable: a7816 
o|substituted constant variable: a7818 
o|substituted constant variable: a7820 
o|substituted constant variable: a7822 
o|substituted constant variable: a7824 
o|substituted constant variable: a7826 
o|substituted constant variable: a7828 
o|substituted constant variable: a7830 
o|substituted constant variable: a7832 
o|substituted constant variable: a7834 
o|inlining procedure: k7877 
o|inlining procedure: k7877 
o|inlining procedure: k7902 
o|contracted procedure: "(c-backend.scm:1100) g14311439" 
o|inlining procedure: k7902 
o|inlining procedure: k7937 
o|inlining procedure: k7937 
o|inlining procedure: k7959 
o|inlining procedure: k7959 
o|inlining procedure: k8015 
o|inlining procedure: k8015 
o|inlining procedure: k8055 
o|inlining procedure: k8055 
o|inlining procedure: k8076 
o|inlining procedure: k8076 
o|inlining procedure: k8100 
o|inlining procedure: k8100 
o|inlining procedure: k8124 
o|inlining procedure: k8124 
o|inlining procedure: k8145 
o|inlining procedure: k8145 
o|inlining procedure: k8163 
o|inlining procedure: k8163 
o|inlining procedure: k8181 
o|inlining procedure: k8181 
o|inlining procedure: k8199 
o|inlining procedure: k8199 
o|inlining procedure: k8220 
o|inlining procedure: k8220 
o|inlining procedure: k8241 
o|inlining procedure: k8241 
o|inlining procedure: k8265 
o|inlining procedure: k8265 
o|inlining procedure: k8289 
o|inlining procedure: k8289 
o|inlining procedure: k8313 
o|inlining procedure: k8313 
o|inlining procedure: k8337 
o|inlining procedure: k8337 
o|inlining procedure: k8361 
o|inlining procedure: k8361 
o|inlining procedure: k8394 
o|inlining procedure: k8394 
o|inlining procedure: k8385 
o|inlining procedure: k8385 
o|inlining procedure: k8415 
o|inlining procedure: k8439 
o|inlining procedure: k8439 
o|inlining procedure: k8498 
o|contracted procedure: "(c-backend.scm:1190) g16091618" 
o|propagated global variable: g16261627 ##compiler#foreign-type-declaration 
o|inlining procedure: k8498 
o|inlining procedure: k8533 
o|inlining procedure: k8533 
o|inlining procedure: k8567 
o|inlining procedure: k8567 
o|inlining procedure: k8601 
o|inlining procedure: k8601 
o|inlining procedure: k8635 
o|inlining procedure: k8688 
o|contracted procedure: "(c-backend.scm:1214) g16571666" 
o|inlining procedure: k8670 
o|inlining procedure: k8670 
o|inlining procedure: k8688 
o|inlining procedure: k8635 
o|substituted constant variable: a8739 
o|substituted constant variable: a8751 
o|substituted constant variable: a8759 
o|substituted constant variable: a8761 
o|substituted constant variable: a8773 
o|substituted constant variable: a8785 
o|substituted constant variable: a8797 
o|substituted constant variable: a8809 
o|substituted constant variable: a8821 
o|substituted constant variable: a8832 
o|substituted constant variable: a8841 
o|substituted constant variable: a8842 
o|inlining procedure: k8415 
o|substituted constant variable: a8854 
o|inlining procedure: k8858 
o|inlining procedure: k8858 
o|substituted constant variable: a8871 
o|substituted constant variable: a8873 
o|substituted constant variable: a8875 
o|substituted constant variable: a8877 
o|inlining procedure: k8881 
o|inlining procedure: k8881 
o|inlining procedure: k8893 
o|inlining procedure: k8893 
o|substituted constant variable: a8900 
o|substituted constant variable: a8902 
o|substituted constant variable: a8904 
o|substituted constant variable: a8906 
o|substituted constant variable: a8908 
o|substituted constant variable: a8913 
o|substituted constant variable: a8915 
o|substituted constant variable: a8920 
o|substituted constant variable: a8922 
o|substituted constant variable: a8927 
o|substituted constant variable: a8929 
o|substituted constant variable: a8934 
o|substituted constant variable: a8936 
o|substituted constant variable: a8941 
o|substituted constant variable: a8943 
o|substituted constant variable: a8948 
o|substituted constant variable: a8950 
o|substituted constant variable: a8955 
o|substituted constant variable: a8957 
o|substituted constant variable: a8962 
o|substituted constant variable: a8964 
o|inlining procedure: k8968 
o|inlining procedure: k8968 
o|substituted constant variable: a8981 
o|substituted constant variable: a8983 
o|substituted constant variable: a8985 
o|substituted constant variable: a8987 
o|substituted constant variable: a8992 
o|substituted constant variable: a8994 
o|inlining procedure: k8998 
o|inlining procedure: k8998 
o|substituted constant variable: a9011 
o|substituted constant variable: a9013 
o|substituted constant variable: a9015 
o|substituted constant variable: a9017 
o|substituted constant variable: a9022 
o|substituted constant variable: a9024 
o|substituted constant variable: a9026 
o|substituted constant variable: a9028 
o|substituted constant variable: a9030 
o|substituted constant variable: a9032 
o|substituted constant variable: a9034 
o|substituted constant variable: a9036 
o|substituted constant variable: a9038 
o|substituted constant variable: a9043 
o|substituted constant variable: a9045 
o|substituted constant variable: a9047 
o|inlining procedure: k9051 
o|inlining procedure: k9051 
o|substituted constant variable: a9058 
o|substituted constant variable: a9060 
o|substituted constant variable: a9062 
o|substituted constant variable: a9067 
o|substituted constant variable: a9069 
o|substituted constant variable: a9074 
o|substituted constant variable: a9076 
o|substituted constant variable: a9081 
o|substituted constant variable: a9083 
o|substituted constant variable: a9088 
o|substituted constant variable: a9090 
o|substituted constant variable: a9092 
o|inlining procedure: k9101 
o|inlining procedure: k9101 
o|inlining procedure: k9116 
o|inlining procedure: k9116 
o|inlining procedure: k9131 
o|inlining procedure: k9131 
o|inlining procedure: k9143 
o|inlining procedure: k9143 
o|inlining procedure: k9161 
o|inlining procedure: k9161 
o|inlining procedure: k9173 
o|inlining procedure: k9173 
o|inlining procedure: k9185 
o|inlining procedure: k9185 
o|inlining procedure: k9200 
o|inlining procedure: k9200 
o|inlining procedure: k9212 
o|inlining procedure: k9212 
o|inlining procedure: k9224 
o|inlining procedure: k9224 
o|inlining procedure: k9236 
o|inlining procedure: k9236 
o|inlining procedure: k9248 
o|inlining procedure: k9248 
o|inlining procedure: k9260 
o|inlining procedure: k9260 
o|inlining procedure: k9272 
o|inlining procedure: k9272 
o|inlining procedure: k9284 
o|inlining procedure: k9284 
o|inlining procedure: k9296 
o|inlining procedure: k9296 
o|inlining procedure: k9308 
o|inlining procedure: k9308 
o|inlining procedure: k9320 
o|inlining procedure: k9320 
o|inlining procedure: k9332 
o|inlining procedure: k9332 
o|inlining procedure: k9347 
o|inlining procedure: k9347 
o|inlining procedure: k9365 
o|contracted procedure: "(c-backend.scm:1272) g17431744" 
o|inlining procedure: k9374 
o|inlining procedure: k9374 
o|inlining procedure: k9365 
o|inlining procedure: k9395 
o|inlining procedure: k9395 
o|inlining procedure: k9407 
o|inlining procedure: k9407 
o|inlining procedure: k9419 
o|inlining procedure: k9419 
o|inlining procedure: k9431 
o|inlining procedure: k9431 
o|inlining procedure: k9450 
o|inlining procedure: k9450 
o|inlining procedure: k9473 
o|inlining procedure: k9473 
o|substituted constant variable: a9490 
o|substituted constant variable: a9492 
o|substituted constant variable: a9494 
o|substituted constant variable: a9496 
o|substituted constant variable: a9498 
o|substituted constant variable: a9500 
o|substituted constant variable: a9502 
o|substituted constant variable: a9504 
o|substituted constant variable: a9506 
o|substituted constant variable: a9508 
o|substituted constant variable: a9510 
o|substituted constant variable: a9522 
o|substituted constant variable: a9530 
o|inlining procedure: k9534 
o|inlining procedure: k9534 
o|inlining procedure: k9546 
o|inlining procedure: k9546 
o|substituted constant variable: a9553 
o|substituted constant variable: a9555 
o|substituted constant variable: a9557 
o|substituted constant variable: a9559 
o|substituted constant variable: a9561 
o|inlining procedure: k9565 
o|inlining procedure: k9565 
o|substituted constant variable: a9578 
o|substituted constant variable: a9580 
o|substituted constant variable: a9582 
o|substituted constant variable: a9584 
o|substituted constant variable: a9586 
o|substituted constant variable: a9588 
o|substituted constant variable: a9590 
o|substituted constant variable: a9592 
o|substituted constant variable: a9594 
o|substituted constant variable: a9596 
o|substituted constant variable: a9598 
o|substituted constant variable: a9600 
o|substituted constant variable: a9602 
o|substituted constant variable: a9604 
o|substituted constant variable: a9606 
o|substituted constant variable: a9608 
o|substituted constant variable: a9610 
o|substituted constant variable: a9612 
o|substituted constant variable: a9614 
o|substituted constant variable: a9616 
o|substituted constant variable: a9618 
o|substituted constant variable: a9620 
o|substituted constant variable: a9622 
o|substituted constant variable: a9624 
o|substituted constant variable: a9626 
o|substituted constant variable: a9628 
o|substituted constant variable: a9630 
o|substituted constant variable: a9632 
o|substituted constant variable: a9637 
o|substituted constant variable: a9639 
o|substituted constant variable: a9641 
o|substituted constant variable: a9643 
o|substituted constant variable: a9645 
o|substituted constant variable: a9647 
o|substituted constant variable: a9652 
o|substituted constant variable: a9654 
o|inlining procedure: k9658 
o|inlining procedure: k9658 
o|substituted constant variable: a9665 
o|substituted constant variable: a9667 
o|substituted constant variable: a9669 
o|substituted constant variable: a9671 
o|substituted constant variable: a9673 
o|substituted constant variable: a9675 
o|inlining procedure: k9679 
o|inlining procedure: k9679 
o|inlining procedure: k9691 
o|inlining procedure: k9691 
o|substituted constant variable: a9704 
o|substituted constant variable: a9706 
o|substituted constant variable: a9708 
o|substituted constant variable: a9710 
o|substituted constant variable: a9712 
o|substituted constant variable: a9714 
o|substituted constant variable: a9719 
o|substituted constant variable: a9721 
o|substituted constant variable: a9723 
o|inlining procedure: k9732 
o|inlining procedure: k9732 
o|inlining procedure: k9750 
o|inlining procedure: k9750 
o|inlining procedure: k9765 
o|inlining procedure: k9765 
o|inlining procedure: k9777 
o|inlining procedure: k9777 
o|substituted constant variable: a9796 
o|substituted constant variable: a9797 
o|substituted constant variable: a9820 
o|substituted constant variable: a9821 
o|inlining procedure: k9810 
o|inlining procedure: k9810 
o|substituted constant variable: a9847 
o|substituted constant variable: a9848 
o|substituted constant variable: a9871 
o|substituted constant variable: a9872 
o|inlining procedure: k9861 
o|inlining procedure: k9861 
o|substituted constant variable: a9898 
o|substituted constant variable: a9899 
o|substituted constant variable: a9925 
o|substituted constant variable: a9926 
o|inlining procedure: k9912 
o|inlining procedure: k9912 
o|substituted constant variable: a9949 
o|substituted constant variable: a9950 
o|substituted constant variable: a9976 
o|substituted constant variable: a9977 
o|inlining procedure: k9963 
o|inlining procedure: k9963 
o|substituted constant variable: a10000 
o|substituted constant variable: a10001 
o|substituted constant variable: a10024 
o|substituted constant variable: a10025 
o|inlining procedure: k10014 
o|inlining procedure: k10014 
o|inlining procedure: k10044 
o|inlining procedure: k10044 
o|inlining procedure: k10065 
o|inlining procedure: k10065 
o|inlining procedure: k10077 
o|substituted constant variable: a10099 
o|substituted constant variable: a10100 
o|substituted constant variable: a10123 
o|substituted constant variable: a10124 
o|inlining procedure: k10113 
o|inlining procedure: k10113 
o|substituted constant variable: a10147 
o|substituted constant variable: a10148 
o|substituted constant variable: a10171 
o|substituted constant variable: a10172 
o|inlining procedure: k10161 
o|inlining procedure: k10161 
o|substituted constant variable: a10195 
o|substituted constant variable: a10196 
o|inlining procedure: k10209 
o|inlining procedure: k10209 
o|substituted constant variable: a10235 
o|substituted constant variable: a10236 
o|substituted constant variable: a10259 
o|substituted constant variable: a10260 
o|inlining procedure: k10249 
o|inlining procedure: k10249 
o|substituted constant variable: a10283 
o|substituted constant variable: a10284 
o|substituted constant variable: a10301 
o|substituted constant variable: a10303 
o|substituted constant variable: a10308 
o|substituted constant variable: a10310 
o|substituted constant variable: a10312 
o|substituted constant variable: a10314 
o|substituted constant variable: a10316 
o|substituted constant variable: a10318 
o|substituted constant variable: a10320 
o|substituted constant variable: a10325 
o|substituted constant variable: a10327 
o|inlining procedure: k10077 
o|substituted constant variable: a10339 
o|substituted constant variable: a10350 
o|substituted constant variable: a10352 
o|substituted constant variable: a10354 
o|substituted constant variable: a10356 
o|substituted constant variable: a10358 
o|substituted constant variable: a10363 
o|substituted constant variable: a10365 
o|substituted constant variable: a10367 
o|substituted constant variable: a10372 
o|substituted constant variable: a10374 
o|substituted constant variable: a10379 
o|substituted constant variable: a10381 
o|substituted constant variable: a10383 
o|inlining procedure: k10387 
o|inlining procedure: k10387 
o|inlining procedure: k10399 
o|inlining procedure: k10399 
o|inlining procedure: k10411 
o|inlining procedure: k10411 
o|inlining procedure: k10423 
o|inlining procedure: k10423 
o|inlining procedure: k10435 
o|inlining procedure: k10435 
o|substituted constant variable: a10448 
o|substituted constant variable: a10450 
o|substituted constant variable: a10452 
o|substituted constant variable: a10454 
o|substituted constant variable: a10456 
o|substituted constant variable: a10458 
o|substituted constant variable: a10460 
o|substituted constant variable: a10462 
o|substituted constant variable: a10464 
o|substituted constant variable: a10466 
o|substituted constant variable: a10468 
o|substituted constant variable: a10470 
o|substituted constant variable: a10472 
o|substituted constant variable: a10477 
o|substituted constant variable: a10479 
o|substituted constant variable: a10481 
o|substituted constant variable: a10483 
o|substituted constant variable: a10485 
o|substituted constant variable: a10487 
o|substituted constant variable: a10492 
o|substituted constant variable: a10494 
o|substituted constant variable: a10499 
o|substituted constant variable: a10501 
o|substituted constant variable: a10506 
o|substituted constant variable: a10508 
o|contracted procedure: k10524 
o|inlining procedure: k10521 
o|inlining procedure: k10521 
o|contracted procedure: "(c-backend.scm:1376) finish2082" 
o|inlining procedure: k10590 
o|inlining procedure: k10590 
o|inlining procedure: k10613 
o|inlining procedure: k10613 
o|inlining procedure: k10625 
o|inlining procedure: k10625 
o|contracted procedure: k10640 
o|inlining procedure: k10637 
o|inlining procedure: k10637 
o|substituted constant variable: a10646 
o|substituted constant variable: a10668 
o|inlining procedure: k10706 
o|inlining procedure: k10706 
o|inlining procedure: k10739 
o|inlining procedure: k10739 
o|inlining procedure: "(c-backend.scm:1406) getsize2080" 
o|inlining procedure: "(c-backend.scm:1405) getbits2079" 
o|inlining procedure: "(c-backend.scm:1412) getbits2079" 
o|inlining procedure: "(c-backend.scm:1409) getsize2080" 
o|substituted constant variable: a10827 
o|substituted constant variable: a10828 
o|replaced variables: 2022 
o|removed binding forms: 571 
o|substituted constant variable: r267110868 
o|substituted constant variable: r267110868 
o|substituted constant variable: r267110870 
o|substituted constant variable: r267110870 
o|inlining procedure: k3591 
o|substituted constant variable: r360210923 
o|substituted constant variable: r360210923 
o|propagated global variable: r378110940 ##compiler#no-procedure-checks 
o|substituted constant variable: r379610942 
o|substituted constant variable: r383910945 
o|substituted constant variable: r383910945 
o|substituted constant variable: r383910947 
o|substituted constant variable: r383910947 
o|substituted constant variable: r387310951 
o|inlining procedure: k4083 
o|substituted constant variable: r421510968 
o|substituted constant variable: r421510968 
o|substituted constant variable: r421510970 
o|substituted constant variable: r421510970 
o|substituted constant variable: r475211001 
o|substituted constant variable: r475211001 
o|substituted constant variable: r475211003 
o|substituted constant variable: r475211003 
o|converted assignments to bindings: (pad0547) 
o|substituted constant variable: r526811043 
o|substituted constant variable: r526811043 
o|substituted constant variable: r526811045 
o|substituted constant variable: r526811045 
o|removed side-effect free assignment to unused variable: bad-literal97 
o|substituted constant variable: r547611057 
o|substituted constant variable: r558311065 
o|substituted constant variable: r559811072 
o|substituted constant variable: r570211087 
o|substituted constant variable: r570211087 
o|substituted constant variable: r570211089 
o|substituted constant variable: r570211089 
o|substituted constant variable: r626311125 
o|substituted constant variable: r630311128 
o|substituted constant variable: r630311128 
o|substituted constant variable: r630311130 
o|substituted constant variable: r630311130 
o|substituted constant variable: r633311134 
o|substituted constant variable: r635711136 
o|contracted procedure: "(c-backend.scm:787) g886893" 
o|substituted constant variable: r589811138 
o|substituted constant variable: r591011140 
o|substituted constant variable: r592211142 
o|substituted constant variable: r644711150 
o|substituted constant variable: r644711150 
o|inlining procedure: k6543 
o|substituted constant variable: r653811166 
o|substituted constant variable: r653811166 
o|substituted constant variable: r653811168 
o|substituted constant variable: r653811168 
o|substituted constant variable: r658211178 
o|substituted constant variable: r658211178 
o|substituted constant variable: r658211180 
o|substituted constant variable: r658211180 
o|inlining procedure: k6847 
o|inlining procedure: k6847 
o|substituted constant variable: r687411195 
o|substituted constant variable: r726111221 
o|substituted constant variable: r793811292 
o|substituted constant variable: r793811292 
o|substituted constant variable: r793811294 
o|substituted constant variable: r793811294 
o|substituted constant variable: r867111349 
o|substituted constant variable: r910211366 
o|substituted constant variable: r911711368 
o|substituted constant variable: r913211370 
o|substituted constant variable: r914411372 
o|substituted constant variable: r916211374 
o|substituted constant variable: r917411376 
o|substituted constant variable: r918611378 
o|substituted constant variable: r920111380 
o|substituted constant variable: r921311382 
o|substituted constant variable: r922511384 
o|substituted constant variable: r923711386 
o|substituted constant variable: r924911388 
o|substituted constant variable: r926111390 
o|substituted constant variable: r927311392 
o|substituted constant variable: r928511394 
o|substituted constant variable: r929711396 
o|substituted constant variable: r930911398 
o|substituted constant variable: r932111400 
o|substituted constant variable: r933311402 
o|substituted constant variable: r934811404 
o|substituted constant variable: r939611412 
o|substituted constant variable: r940811414 
o|substituted constant variable: r942011416 
o|substituted constant variable: r943211418 
o|substituted constant variable: r945111420 
o|substituted constant variable: r973311436 
o|substituted constant variable: r975111438 
o|substituted constant variable: r976611440 
o|substituted constant variable: r977811442 
o|substituted constant variable: r1004511454 
o|removed side-effect free assignment to unused variable: getbits2079 
o|removed side-effect free assignment to unused variable: getsize2080 
o|substituted constant variable: r1059111482 
o|substituted constant variable: r1061411484 
o|substituted constant variable: r1062611486 
o|simplifications: ((let . 1)) 
o|replaced variables: 37 
o|removed binding forms: 2023 
o|inlining procedure: k3570 
o|inlining procedure: k4030 
o|inlining procedure: k4116 
o|inlining procedure: k4640 
o|inlining procedure: k4813 
o|inlining procedure: k5208 
o|inlining procedure: k5208 
o|inlining procedure: k6244 
o|inlining procedure: k6350 
o|inlining procedure: k6350 
o|inlining procedure: k6481 
o|inlining procedure: k6481 
o|inlining procedure: k6832 
o|inlining procedure: k10767 
o|inlining procedure: k10775 
o|inlining procedure: k10815 
o|converted assignments to bindings: (encode-size2081) 
o|simplifications: ((let . 1)) 
o|replaced variables: 41 
o|removed binding forms: 150 
o|Removed `not' forms: 1 
o|substituted constant variable: r635111710 
o|contracted procedure: k6350 
o|propagated global variable: r6351 ##compiler#disable-stack-overflow-checking 
o|substituted constant variable: r635111711 
o|contracted procedure: k10778 
o|simplifications: ((let . 1)) 
o|replaced variables: 4 
o|removed binding forms: 50 
o|removed conditional forms: 2 
o|removed binding forms: 7 
o|simplifications: ((if . 58) (##core#call . 815)) 
o|  call simplifications:
o|    eof-object?
o|    integer->char	9
o|    string	5
o|    list?	3
o|    fx>
o|    fx>=	3
o|    string=?
o|    string-set!	3
o|    fx/
o|    void	2
o|    boolean?
o|    char?	2
o|    fixnum?	3
o|    string?	2
o|    number?	2
o|    symbol?	7
o|    ##sys#immediate?	4
o|    ##sys#generic-structure?
o|    ##sys#size	5
o|    apply	9
o|    string-length	3
o|    arithmetic-shift	8
o|    >=	6
o|    string-ref	3
o|    bitwise-and	8
o|    -	5
o|    cons	9
o|    ##sys#setslot	4
o|    <	3
o|    null?	6
o|    cddr	3
o|    cdr	5
o|    length	10
o|    cdddr
o|    zero?	14
o|    not	13
o|    third	7
o|    fourth	4
o|    ##sys#check-list	12
o|    +	23
o|    >	5
o|    add1	20
o|    sub1	11
o|    car	38
o|    cadr	21
o|    caddr	2
o|    vector?	6
o|    vector-ref	13
o|    first	36
o|    char->integer	4
o|    second	15
o|    pair?	42
o|    eq?	314
o|    ##sys#slot	76
o|contracted procedure: k2545 
o|contracted procedure: k2555 
o|contracted procedure: k2559 
o|contracted procedure: k2527 
o|contracted procedure: k2582 
o|contracted procedure: k2592 
o|contracted procedure: k2596 
o|contracted procedure: k2632 
o|contracted procedure: k2640 
o|contracted procedure: k2648 
o|contracted procedure: k2654 
o|contracted procedure: k2657 
o|contracted procedure: k2663 
o|contracted procedure: k2673 
o|contracted procedure: k2679 
o|contracted procedure: k2690 
o|contracted procedure: k2686 
o|contracted procedure: k2696 
o|contracted procedure: k2705 
o|contracted procedure: k2712 
o|contracted procedure: k2718 
o|contracted procedure: k2740 
o|contracted procedure: k2743 
o|contracted procedure: k2749 
o|contracted procedure: k2756 
o|contracted procedure: k2767 
o|contracted procedure: k2792 
o|contracted procedure: k2796 
o|contracted procedure: k2800 
o|contracted procedure: k2806 
o|contracted procedure: k2813 
o|contracted procedure: k2819 
o|contracted procedure: k2826 
o|contracted procedure: k2835 
o|contracted procedure: k2853 
o|contracted procedure: k2857 
o|contracted procedure: k2861 
o|contracted procedure: k2868 
o|contracted procedure: k2874 
o|contracted procedure: k2877 
o|contracted procedure: k2893 
o|contracted procedure: k2897 
o|contracted procedure: k2903 
o|contracted procedure: k2920 
o|contracted procedure: k2916 
o|contracted procedure: k2924 
o|contracted procedure: k2930 
o|contracted procedure: k2943 
o|contracted procedure: k2949 
o|contracted procedure: k2968 
o|contracted procedure: k2972 
o|contracted procedure: k2976 
o|contracted procedure: k2982 
o|contracted procedure: k3001 
o|contracted procedure: k3009 
o|contracted procedure: k3005 
o|contracted procedure: k3013 
o|contracted procedure: k3019 
o|contracted procedure: k3038 
o|contracted procedure: k3042 
o|contracted procedure: k3048 
o|contracted procedure: k3067 
o|contracted procedure: k3071 
o|contracted procedure: k3077 
o|contracted procedure: k3080 
o|contracted procedure: k3100 
o|contracted procedure: k3110 
o|contracted procedure: k3144 
o|contracted procedure: k3119 
o|contracted procedure: k3129 
o|contracted procedure: k3133 
o|contracted procedure: k3137 
o|contracted procedure: k3141 
o|contracted procedure: k3153 
o|contracted procedure: k3166 
o|contracted procedure: k3172 
o|contracted procedure: k3179 
o|contracted procedure: k3185 
o|contracted procedure: k3195 
o|contracted procedure: k3199 
o|contracted procedure: k3205 
o|contracted procedure: k3208 
o|contracted procedure: k3211 
o|contracted procedure: k3214 
o|contracted procedure: k3238 
o|contracted procedure: k3253 
o|contracted procedure: k3256 
o|contracted procedure: k3259 
o|contracted procedure: k3262 
o|contracted procedure: k3278 
o|contracted procedure: k3298 
o|contracted procedure: k3301 
o|contracted procedure: k3304 
o|contracted procedure: k3307 
o|contracted procedure: k3323 
o|contracted procedure: k3344 
o|contracted procedure: k3358 
o|contracted procedure: k3367 
o|contracted procedure: k3370 
o|contracted procedure: k3373 
o|contracted procedure: k3376 
o|contracted procedure: k3379 
o|contracted procedure: k3382 
o|contracted procedure: k3385 
o|contracted procedure: k3388 
o|contracted procedure: k3825 
o|contracted procedure: k3410 
o|contracted procedure: k3424 
o|contracted procedure: k3431 
o|contracted procedure: k3514 
o|contracted procedure: k3489 
o|contracted procedure: k3499 
o|contracted procedure: k3503 
o|contracted procedure: k3507 
o|contracted procedure: k3511 
o|contracted procedure: k3551 
o|contracted procedure: k3526 
o|contracted procedure: k3536 
o|contracted procedure: k3540 
o|contracted procedure: k3544 
o|contracted procedure: k3548 
o|contracted procedure: k3558 
o|contracted procedure: k3624 
o|contracted procedure: k3645 
o|contracted procedure: k3648 
o|contracted procedure: k3651 
o|contracted procedure: k3654 
o|contracted procedure: k3718 
o|contracted procedure: k3816 
o|contracted procedure: k3792 
o|contracted procedure: k3882 
o|contracted procedure: k3875 
o|contracted procedure: k3894 
o|contracted procedure: k3897 
o|contracted procedure: k3900 
o|contracted procedure: k3903 
o|contracted procedure: k3906 
o|contracted procedure: k3909 
o|contracted procedure: k3980 
o|contracted procedure: k3955 
o|contracted procedure: k3965 
o|contracted procedure: k3969 
o|contracted procedure: k3973 
o|contracted procedure: k3977 
o|contracted procedure: k4017 
o|contracted procedure: k3992 
o|contracted procedure: k4002 
o|contracted procedure: k4006 
o|contracted procedure: k4010 
o|contracted procedure: k4014 
o|contracted procedure: k4024 
o|contracted procedure: k4049 
o|contracted procedure: k4052 
o|contracted procedure: k4055 
o|contracted procedure: k4058 
o|contracted procedure: k4061 
o|contracted procedure: k4064 
o|contracted procedure: k4134 
o|contracted procedure: k4067 
o|contracted procedure: k4070 
o|contracted procedure: k4089 
o|contracted procedure: k4101 
o|contracted procedure: k4113 
o|contracted procedure: k4116 
o|contracted procedure: k4140 
o|contracted procedure: k4143 
o|contracted procedure: k4146 
o|contracted procedure: k4159 
o|contracted procedure: k4165 
o|contracted procedure: k4178 
o|contracted procedure: k4184 
o|contracted procedure: k4197 
o|contracted procedure: k4203 
o|contracted procedure: k4210 
o|contracted procedure: k4220 
o|contracted procedure: k4232 
o|contracted procedure: k4242 
o|contracted procedure: k4246 
o|contracted procedure: k4252 
o|contracted procedure: k4265 
o|contracted procedure: k4271 
o|contracted procedure: k4274 
o|contracted procedure: k4287 
o|contracted procedure: k4303 
o|contracted procedure: k4306 
o|contracted procedure: k4319 
o|contracted procedure: k4333 
o|contracted procedure: k4336 
o|contracted procedure: k4355 
o|contracted procedure: k4363 
o|contracted procedure: k4373 
o|contracted procedure: k4380 
o|contracted procedure: k4386 
o|contracted procedure: k4399 
o|contracted procedure: k4403 
o|contracted procedure: k4409 
o|contracted procedure: k4422 
o|contracted procedure: k4428 
o|contracted procedure: k4444 
o|contracted procedure: k4455 
o|contracted procedure: k4468 
o|contracted procedure: k4487 
o|contracted procedure: k4491 
o|contracted procedure: k4495 
o|contracted procedure: k4499 
o|contracted procedure: k4503 
o|contracted procedure: k4509 
o|contracted procedure: k4534 
o|contracted procedure: k4538 
o|contracted procedure: k4542 
o|contracted procedure: k4554 
o|contracted procedure: k4647 
o|contracted procedure: k4657 
o|contracted procedure: k464711678 
o|contracted procedure: k4663 
o|contracted procedure: k4666 
o|contracted procedure: k4682 
o|contracted procedure: k4691 
o|contracted procedure: k4707 
o|contracted procedure: k4713 
o|contracted procedure: k4766 
o|contracted procedure: k4780 
o|contracted procedure: k4783 
o|contracted procedure: k4786 
o|contracted procedure: k4789 
o|contracted procedure: k4792 
o|contracted procedure: k4822 
o|contracted procedure: k4842 
o|contracted procedure: k4852 
o|contracted procedure: k4856 
o|contracted procedure: k4872 
o|contracted procedure: k4896 
o|contracted procedure: k4916 
o|contracted procedure: k4919 
o|contracted procedure: k4922 
o|contracted procedure: k4930 
o|contracted procedure: k4938 
o|contracted procedure: k4949 
o|contracted procedure: k4973 
o|contracted procedure: k4984 
o|contracted procedure: k5005 
o|contracted procedure: k5011 
o|contracted procedure: k5030 
o|contracted procedure: k5063 
o|contracted procedure: k5059 
o|contracted procedure: k5036 
o|contracted procedure: k5045 
o|contracted procedure: k5055 
o|contracted procedure: k5072 
o|contracted procedure: k5082 
o|contracted procedure: k5090 
o|contracted procedure: k5086 
o|contracted procedure: k5094 
o|contracted procedure: k5105 
o|contracted procedure: k5098 
o|contracted procedure: k5109 
o|contracted procedure: k5112 
o|contracted procedure: k5125 
o|contracted procedure: k5135 
o|contracted procedure: k5139 
o|propagated global variable: g630632 ##compiler#used-units 
o|contracted procedure: k5226 
o|contracted procedure: k5236 
o|contracted procedure: k5286 
o|contracted procedure: k5294 
o|contracted procedure: k5370 
o|contracted procedure: k5317 
o|contracted procedure: k5326 
o|contracted procedure: k5336 
o|contracted procedure: k5340 
o|contracted procedure: k5406 
o|contracted procedure: k5428 
o|contracted procedure: k5438 
o|contracted procedure: k5444 
o|contracted procedure: k5484 
o|contracted procedure: k5490 
o|contracted procedure: k5496 
o|contracted procedure: k5502 
o|contracted procedure: k5523 
o|contracted procedure: k5530 
o|contracted procedure: k5538 
o|contracted procedure: k5553 
o|contracted procedure: k5556 
o|contracted procedure: k5559 
o|contracted procedure: k5567 
o|contracted procedure: k5575 
o|contracted procedure: k5591 
o|contracted procedure: k5614 
o|contracted procedure: k5620 
o|contracted procedure: k5623 
o|contracted procedure: k5630 
o|contracted procedure: k5639 
o|contracted procedure: k5646 
o|contracted procedure: k5650 
o|contracted procedure: k5658 
o|contracted procedure: k5793 
o|contracted procedure: k5685 
o|propagated global variable: r5794 ##sys#undefined-value 
o|contracted procedure: k5694 
o|contracted procedure: k5707 
o|contracted procedure: k5714 
o|contracted procedure: k5720 
o|contracted procedure: k5723 
o|contracted procedure: k5729 
o|contracted procedure: k5741 
o|contracted procedure: k5789 
o|contracted procedure: k5747 
o|contracted procedure: k5756 
o|contracted procedure: k5782 
o|contracted procedure: k5796 
o|contracted procedure: k5809 
o|contracted procedure: k5812 
o|contracted procedure: k5827 
o|contracted procedure: k5833 
o|contracted procedure: k5863 
o|contracted procedure: k5867 
o|contracted procedure: k5879 
o|contracted procedure: k5885 
o|contracted procedure: k5978 
o|contracted procedure: k6071 
o|contracted procedure: k6159 
o|contracted procedure: k6077 
o|contracted procedure: k6093 
o|contracted procedure: k6102 
o|contracted procedure: k6112 
o|contracted procedure: k6116 
o|contracted procedure: k6125 
o|contracted procedure: k6131 
o|contracted procedure: k6162 
o|contracted procedure: k6203 
o|contracted procedure: k6271 
o|contracted procedure: k6317 
o|contracted procedure: k6323 
o|contracted procedure: k6389 
o|contracted procedure: k6401 
o|contracted procedure: k6411 
o|contracted procedure: k6415 
o|contracted procedure: k6386 
o|contracted procedure: k5900 
o|contracted procedure: k5906 
o|contracted procedure: k5912 
o|contracted procedure: k5918 
o|contracted procedure: k5924 
o|contracted procedure: k5930 
o|contracted procedure: k6428 
o|contracted procedure: k6438 
o|contracted procedure: k6442 
o|contracted procedure: k6446 
o|contracted procedure: k6452 
o|contracted procedure: k6464 
o|contracted procedure: k6474 
o|contracted procedure: k6477 
o|contracted procedure: k6499 
o|contracted procedure: k6509 
o|contracted procedure: k6553 
o|contracted procedure: k6567 
o|contracted procedure: k6574 
o|contracted procedure: k6636 
o|contracted procedure: k6705 
o|contracted procedure: k6720 
o|contracted procedure: k6730 
o|contracted procedure: k6734 
o|contracted procedure: k6663 
o|contracted procedure: k6666 
o|contracted procedure: k6681 
o|contracted procedure: k6691 
o|contracted procedure: k6695 
o|contracted procedure: k6699 
o|contracted procedure: k6744 
o|contracted procedure: k6748 
o|contracted procedure: k6781 
o|contracted procedure: k6801 
o|contracted procedure: k6811 
o|contracted procedure: k6823 
o|contracted procedure: k6829 
o|contracted procedure: k6839 
o|contracted procedure: k683911727 
o|contracted procedure: k6889 
o|contracted procedure: k6876 
o|contracted procedure: k6885 
o|contracted procedure: k6881 
o|contracted procedure: k6952 
o|contracted procedure: k6964 
o|contracted procedure: k6974 
o|contracted procedure: k6978 
o|contracted procedure: k6932 
o|contracted procedure: k6935 
o|contracted procedure: k6938 
o|contracted procedure: k6945 
o|contracted procedure: k6995 
o|contracted procedure: k7007 
o|contracted procedure: k7017 
o|contracted procedure: k7021 
o|contracted procedure: k7038 
o|contracted procedure: k7122 
o|contracted procedure: k7188 
o|contracted procedure: k7212 
o|contracted procedure: k7234 
o|contracted procedure: k7238 
o|contracted procedure: k7242 
o|contracted procedure: k7246 
o|contracted procedure: k7250 
o|contracted procedure: k7254 
o|contracted procedure: k7257 
o|contracted procedure: k7263 
o|contracted procedure: k7281 
o|contracted procedure: k7291 
o|contracted procedure: k7295 
o|contracted procedure: k7312 
o|contracted procedure: k7332 
o|contracted procedure: k7344 
o|contracted procedure: k7354 
o|contracted procedure: k7358 
o|contracted procedure: k7378 
o|contracted procedure: k7390 
o|contracted procedure: k7399 
o|contracted procedure: k7411 
o|contracted procedure: k7423 
o|contracted procedure: k7447 
o|contracted procedure: k7444 
o|contracted procedure: k7459 
o|contracted procedure: k7466 
o|contracted procedure: k7478 
o|contracted procedure: k7485 
o|contracted procedure: k7490 
o|contracted procedure: k7496 
o|contracted procedure: k7502 
o|contracted procedure: k7508 
o|contracted procedure: k7514 
o|contracted procedure: k7520 
o|contracted procedure: k7526 
o|contracted procedure: k7553 
o|contracted procedure: k7559 
o|contracted procedure: k7565 
o|contracted procedure: k7571 
o|contracted procedure: k7590 
o|contracted procedure: k7596 
o|contracted procedure: k7602 
o|contracted procedure: k7621 
o|contracted procedure: k7627 
o|contracted procedure: k7633 
o|contracted procedure: k7639 
o|contracted procedure: k7645 
o|contracted procedure: k7651 
o|contracted procedure: k7657 
o|contracted procedure: k7663 
o|contracted procedure: k7669 
o|contracted procedure: k7675 
o|contracted procedure: k7681 
o|contracted procedure: k7687 
o|contracted procedure: k7693 
o|contracted procedure: k7699 
o|contracted procedure: k7740 
o|contracted procedure: k7746 
o|contracted procedure: k7752 
o|contracted procedure: k7758 
o|contracted procedure: k7764 
o|contracted procedure: k7770 
o|contracted procedure: k7776 
o|contracted procedure: k7782 
o|contracted procedure: k7788 
o|contracted procedure: k7794 
o|contracted procedure: k7800 
o|contracted procedure: k7883 
o|contracted procedure: k7889 
o|contracted procedure: k7930 
o|contracted procedure: k7905 
o|contracted procedure: k7915 
o|contracted procedure: k7919 
o|contracted procedure: k7923 
o|contracted procedure: k7927 
o|contracted procedure: k7940 
o|contracted procedure: k7950 
o|contracted procedure: k7962 
o|contracted procedure: k7972 
o|contracted procedure: k7976 
o|contracted procedure: k7994 
o|contracted procedure: k8018 
o|contracted procedure: k8031 
o|contracted procedure: k8035 
o|contracted procedure: k8058 
o|contracted procedure: k8067 
o|contracted procedure: k8070 
o|contracted procedure: k8079 
o|contracted procedure: k8082 
o|contracted procedure: k8091 
o|contracted procedure: k8094 
o|contracted procedure: k8103 
o|contracted procedure: k8106 
o|contracted procedure: k8115 
o|contracted procedure: k8127 
o|contracted procedure: k8136 
o|contracted procedure: k8139 
o|contracted procedure: k8148 
o|contracted procedure: k8157 
o|contracted procedure: k8166 
o|contracted procedure: k8175 
o|contracted procedure: k8184 
o|contracted procedure: k8193 
o|contracted procedure: k8202 
o|contracted procedure: k8211 
o|contracted procedure: k8214 
o|contracted procedure: k8223 
o|contracted procedure: k8235 
o|contracted procedure: k8238 
o|contracted procedure: k8244 
o|contracted procedure: k8256 
o|contracted procedure: k8259 
o|contracted procedure: k8268 
o|contracted procedure: k8271 
o|contracted procedure: k8280 
o|contracted procedure: k8283 
o|contracted procedure: k8292 
o|contracted procedure: k8295 
o|contracted procedure: k8304 
o|contracted procedure: k8307 
o|contracted procedure: k8316 
o|contracted procedure: k8319 
o|contracted procedure: k8328 
o|contracted procedure: k8331 
o|contracted procedure: k8340 
o|contracted procedure: k8343 
o|contracted procedure: k8352 
o|contracted procedure: k8364 
o|contracted procedure: k8376 
o|contracted procedure: k8397 
o|contracted procedure: k8394 
o|contracted procedure: k8409 
o|contracted procedure: k8418 
o|contracted procedure: k8432 
o|contracted procedure: k8449 
o|contracted procedure: k8478 
o|contracted procedure: k8486 
o|contracted procedure: k8489 
o|contracted procedure: k8501 
o|contracted procedure: k8504 
o|contracted procedure: k8507 
o|contracted procedure: k8515 
o|contracted procedure: k8523 
o|contracted procedure: k8530 
o|contracted procedure: k8547 
o|contracted procedure: k8564 
o|contracted procedure: k8581 
o|contracted procedure: k8598 
o|contracted procedure: k8615 
o|contracted procedure: k8632 
o|contracted procedure: k8641 
o|contracted procedure: k8644 
o|contracted procedure: k8719 
o|contracted procedure: k8650 
o|contracted procedure: k8665 
o|contracted procedure: k8679 
o|contracted procedure: k8691 
o|contracted procedure: k8694 
o|contracted procedure: k8697 
o|contracted procedure: k8705 
o|contracted procedure: k8713 
o|contracted procedure: k8673 
o|contracted procedure: k8728 
o|contracted procedure: k8735 
o|contracted procedure: k8740 
o|contracted procedure: k8747 
o|contracted procedure: k8752 
o|contracted procedure: k8756 
o|contracted procedure: k8762 
o|contracted procedure: k8769 
o|contracted procedure: k8774 
o|contracted procedure: k8781 
o|contracted procedure: k8786 
o|contracted procedure: k8793 
o|contracted procedure: k8798 
o|contracted procedure: k8805 
o|contracted procedure: k8810 
o|contracted procedure: k8817 
o|contracted procedure: k8822 
o|contracted procedure: k8829 
o|contracted procedure: k8834 
o|contracted procedure: k8838 
o|contracted procedure: k8847 
o|contracted procedure: k8855 
o|contracted procedure: k8861 
o|contracted procedure: k8878 
o|contracted procedure: k8884 
o|contracted procedure: k8890 
o|contracted procedure: k8965 
o|contracted procedure: k8971 
o|contracted procedure: k8995 
o|contracted procedure: k9001 
o|contracted procedure: k9048 
o|contracted procedure: k9104 
o|contracted procedure: k9110 
o|contracted procedure: k9113 
o|contracted procedure: k9119 
o|contracted procedure: k9128 
o|contracted procedure: k9134 
o|contracted procedure: k9140 
o|contracted procedure: k9146 
o|contracted procedure: k9155 
o|contracted procedure: k9158 
o|contracted procedure: k9164 
o|contracted procedure: k9170 
o|contracted procedure: k9176 
o|contracted procedure: k9182 
o|contracted procedure: k9188 
o|contracted procedure: k9191 
o|contracted procedure: k9197 
o|contracted procedure: k9203 
o|contracted procedure: k9209 
o|contracted procedure: k9215 
o|contracted procedure: k9221 
o|contracted procedure: k9227 
o|contracted procedure: k9233 
o|contracted procedure: k9239 
o|contracted procedure: k9245 
o|contracted procedure: k9251 
o|contracted procedure: k9257 
o|contracted procedure: k9263 
o|contracted procedure: k9269 
o|contracted procedure: k9275 
o|contracted procedure: k9281 
o|contracted procedure: k9287 
o|contracted procedure: k9293 
o|contracted procedure: k9299 
o|contracted procedure: k9305 
o|contracted procedure: k9311 
o|contracted procedure: k9317 
o|contracted procedure: k9323 
o|contracted procedure: k9329 
o|contracted procedure: k9335 
o|contracted procedure: k9341 
o|contracted procedure: k9350 
o|contracted procedure: k9359 
o|contracted procedure: k9377 
o|contracted procedure: k9374 
o|contracted procedure: k9392 
o|contracted procedure: k9398 
o|contracted procedure: k9404 
o|contracted procedure: k9410 
o|contracted procedure: k9416 
o|contracted procedure: k9422 
o|contracted procedure: k9428 
o|contracted procedure: k9434 
o|contracted procedure: k9440 
o|contracted procedure: k9447 
o|contracted procedure: k9453 
o|contracted procedure: k9459 
o|contracted procedure: k9470 
o|contracted procedure: k9476 
o|contracted procedure: k9483 
o|contracted procedure: k9514 
o|contracted procedure: k9523 
o|contracted procedure: k9531 
o|contracted procedure: k9537 
o|contracted procedure: k9543 
o|contracted procedure: k9562 
o|contracted procedure: k9568 
o|contracted procedure: k9655 
o|contracted procedure: k9676 
o|contracted procedure: k9682 
o|contracted procedure: k9688 
o|contracted procedure: k9694 
o|contracted procedure: k9735 
o|contracted procedure: k9738 
o|contracted procedure: k9744 
o|contracted procedure: k9747 
o|contracted procedure: k9753 
o|contracted procedure: k9756 
o|contracted procedure: k9762 
o|contracted procedure: k9768 
o|contracted procedure: k9774 
o|contracted procedure: k9780 
o|contracted procedure: k9786 
o|contracted procedure: k9789 
o|contracted procedure: k9813 
o|contracted procedure: k9837 
o|contracted procedure: k9864 
o|contracted procedure: k9888 
o|contracted procedure: k9891 
o|contracted procedure: k9915 
o|contracted procedure: k9918 
o|contracted procedure: k9942 
o|contracted procedure: k9966 
o|contracted procedure: k9969 
o|contracted procedure: k9993 
o|contracted procedure: k10017 
o|contracted procedure: k10041 
o|contracted procedure: k10047 
o|contracted procedure: k10050 
o|contracted procedure: k10068 
o|contracted procedure: k10065 
o|contracted procedure: k10083 
o|contracted procedure: k10089 
o|contracted procedure: k10092 
o|contracted procedure: k10116 
o|contracted procedure: k10140 
o|contracted procedure: k10164 
o|contracted procedure: k10188 
o|contracted procedure: k10212 
o|contracted procedure: k10219 
o|contracted procedure: k10225 
o|contracted procedure: k10228 
o|contracted procedure: k10252 
o|contracted procedure: k10276 
o|contracted procedure: k10331 
o|contracted procedure: k10340 
o|contracted procedure: k10384 
o|contracted procedure: k10390 
o|contracted procedure: k10396 
o|contracted procedure: k10402 
o|contracted procedure: k10408 
o|contracted procedure: k10414 
o|contracted procedure: k10420 
o|contracted procedure: k10426 
o|contracted procedure: k10432 
o|contracted procedure: k10438 
o|contracted procedure: k10567 
o|contracted procedure: k10562 
o|contracted procedure: k10558 
o|contracted procedure: k10534 
o|contracted procedure: k10554 
o|contracted procedure: k10550 
o|contracted procedure: k10538 
o|contracted procedure: k10546 
o|contracted procedure: k10542 
o|contracted procedure: k10577 
o|contracted procedure: k10587 
o|contracted procedure: k10593 
o|contracted procedure: k10599 
o|contracted procedure: k10610 
o|contracted procedure: k10616 
o|contracted procedure: k10622 
o|contracted procedure: k10819 
o|contracted procedure: k10628 
o|propagated global variable: r10820 ##sys#undefined-value 
o|contracted procedure: k10634 
o|contracted procedure: k10691 
o|contracted procedure: k10687 
o|contracted procedure: k10652 
o|contracted procedure: k10683 
o|contracted procedure: k10679 
o|contracted procedure: k10656 
o|contracted procedure: k10675 
o|contracted procedure: k10671 
o|contracted procedure: k10660 
o|contracted procedure: k10664 
o|contracted procedure: k10648 
o|contracted procedure: k10709 
o|contracted procedure: k10722 
o|contracted procedure: k10725 
o|contracted procedure: k10736 
o|contracted procedure: k10742 
o|contracted procedure: k10771 
o|contracted procedure: k10759 
o|contracted procedure: k10811 
o|contracted procedure: k10789 
o|contracted procedure: k10807 
o|simplifications: ((let . 81)) 
o|removed binding forms: 753 
o|inlining procedure: k6832 
o|inlining procedure: k6832 
o|inlining procedure: k6832 
o|inlining procedure: k10584 
o|inlining procedure: k10584 
o|inlining procedure: k10584 
o|inlining procedure: k10584 
o|inlining procedure: k10584 
o|replaced variables: 209 
o|inlining procedure: k6380 
o|inlining procedure: k6380 
o|inlining procedure: k6380 
o|inlining procedure: k6380 
o|inlining procedure: k6380 
o|inlining procedure: k6380 
o|substituted constant variable: r1058512216 
o|substituted constant variable: r1058512216 
o|substituted constant variable: r1058512220 
o|substituted constant variable: r1058512220 
o|substituted constant variable: r1058512224 
o|substituted constant variable: r1058512224 
o|substituted constant variable: r1058512228 
o|substituted constant variable: r1058512228 
o|substituted constant variable: r1058512232 
o|substituted constant variable: r1058512232 
o|simplifications: ((if . 8)) 
o|removed binding forms: 111 
o|substituted constant variable: r638112280 
o|substituted constant variable: r638112282 
o|substituted constant variable: r638112284 
o|substituted constant variable: r638112286 
o|substituted constant variable: r638112288 
o|substituted constant variable: r638112290 
o|removed binding forms: 10 
o|removed binding forms: 6 
o|customizable procedures: (encode-size2081 k9840 k10080 err1756 g19571958 k9122 k9149 k9344 k9353 k9389 err1678 k8118 k8226 k8247 k8355 k8367 k8425 k8442 k8459 k8536 k8553 k8570 k8587 k8604 k8621 k8638 err1484 map-loop16511669 map-loop16031628 g15901591 str1485 g12561263 for-each-loop12551462 for-each-loop14301444 k7393 k7402 k7414 k7426 k7469 g13941395 g11441151 for-each-loop11431245 doloop11711172 k7224 for-each-loop11811210 for-each-loop11201133 for-each-loop10961110 k6844 loop1067 for-each-loop10251036 for-each-loop10121045 header91 declarations93 prototypes94 trampolines95 procedures103 k5975 k6490 k6041 doloop872873 k6419 doloop877878 for-each-loop885896 k6311 k6253 literal-frame96 doloop947948 expression90 doloop811812 k5836 string-like-substring101 k5670 k5759 gen-string-constant100 loop780 map-loop755772 gen-lit99 doloop728729 k5361 k5364 doloop705706 k5160 k5217 for-each-loop623634 doloop645646 doloop650651 doloop639640 pad0547 map-loop557582 for-each-loop595606 k4669 doloop534535 doloop490491 g395403 for-each-loop394410 for-each-loop420434 k3394 find-lambda89 k3400 k3637 k3771 expr-args112 g280288 for-each-loop279295 for-each-loop305319 push-args113 g186194 for-each-loop185201 loop146 expr111 for-each-loop4758 for-each-loop2738) 
o|calls to known targets: 415 
o|fast box initializations: 53 
o|dropping unused closure argument: f_5883 
o|dropping unused closure argument: f_4761 
o|dropping unused closure argument: f_10519 
*/
/* end of file */
