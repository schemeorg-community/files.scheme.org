/* Generated from compiler-syntax.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:51
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: compiler-syntax.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -extend private-namespace.scm -no-trace -output-file compiler-syntax.c
   unit: compiler_2dsyntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[87];
static double C_possibly_force_alignment;


C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word *av) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word *av) C_noret;
C_noret_decl(f_1344)
static void C_ccall f_1344(C_word c,C_word *av) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word *av) C_noret;
C_noret_decl(f_2530)
static void C_fcall f_2530(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1361)
static void C_ccall f_1361(C_word c,C_word *av) C_noret;
C_noret_decl(f_2572)
static C_word C_fcall f_2572(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_1338)
static void C_ccall f_1338(C_word c,C_word *av) C_noret;
C_noret_decl(f_2794)
static void C_fcall f_2794(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word *av) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word *av) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word *av) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word *av) C_noret;
C_noret_decl(f_1353)
static void C_ccall f_1353(C_word c,C_word *av) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word *av) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word *av) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word *av) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word *av) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word *av) C_noret;
C_noret_decl(f_2714)
static void C_fcall f_2714(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word *av) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word *av) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word *av) C_noret;
C_noret_decl(f_2518)
static void C_ccall f_2518(C_word c,C_word *av) C_noret;
C_noret_decl(f_2512)
static void C_ccall f_2512(C_word c,C_word *av) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word *av) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word *av) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word *av) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word *av) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word *av) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word *av) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word *av) C_noret;
C_noret_decl(f_2760)
static void C_fcall f_2760(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word *av) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word *av) C_noret;
C_noret_decl(f_2503)
static void C_ccall f_2503(C_word c,C_word *av) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word *av) C_noret;
C_noret_decl(f_3008)
static void C_ccall f_3008(C_word c,C_word *av) C_noret;
C_noret_decl(f_2652)
static void C_fcall f_2652(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2758)
static void C_ccall f_2758(C_word c,C_word *av) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word *av) C_noret;
C_noret_decl(f_2751)
static C_word C_fcall f_2751(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word *av) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word *av) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word *av) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word *av) C_noret;
C_noret_decl(f_2898)
static void C_fcall f_2898(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1389)
static void C_fcall f_1389(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1383)
static void C_fcall f_1383(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word *av) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word *av) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word *av) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word *av) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word *av) C_noret;
C_noret_decl(f_3101)
static C_word C_fcall f_3101(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word *av) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word *av) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word *av) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word *av) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word *av) C_noret;
C_noret_decl(f_1412)
static void C_ccall f_1412(C_word c,C_word *av) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word *av) C_noret;
C_noret_decl(f_1424)
static void C_ccall f_1424(C_word c,C_word *av) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word *av) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word *av) C_noret;
C_noret_decl(f_1549)
static void C_fcall f_1549(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3215)
static void C_fcall f_3215(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word *av) C_noret;
C_noret_decl(f_2364)
static void C_ccall f_2364(C_word c,C_word *av) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word *av) C_noret;
C_noret_decl(f_2842)
static void C_fcall f_2842(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word *av) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word *av) C_noret;
C_noret_decl(f_1562)
static void C_ccall f_1562(C_word c,C_word *av) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word *av) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word *av) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word *av) C_noret;
C_noret_decl(f_3043)
static void C_ccall f_3043(C_word c,C_word *av) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word *av) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word *av) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word *av) C_noret;
C_noret_decl(f_1467)
static void C_ccall f_1467(C_word c,C_word *av) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word *av) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word *av) C_noret;
C_noret_decl(f_1671)
static void C_ccall f_1671(C_word c,C_word *av) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word *av) C_noret;
C_noret_decl(f_1461)
static void C_ccall f_1461(C_word c,C_word *av) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word *av) C_noret;
C_noret_decl(f_1464)
static void C_ccall f_1464(C_word c,C_word *av) C_noret;
C_noret_decl(f_1501)
static void C_fcall f_1501(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word *av) C_noret;
C_noret_decl(f_2330)
static void C_ccall f_2330(C_word c,C_word *av) C_noret;
C_noret_decl(f_1430)
static void C_ccall f_1430(C_word c,C_word *av) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word *av) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word *av) C_noret;
C_noret_decl(f_1449)
static void C_ccall f_1449(C_word c,C_word *av) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word *av) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word *av) C_noret;
C_noret_decl(f_1532)
static void C_ccall f_1532(C_word c,C_word *av) C_noret;
C_noret_decl(f_1539)
static C_word C_fcall f_1539(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word *av) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word *av) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word *av) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word *av) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word *av) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word *av) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word *av) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word *av) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word *av) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word *av) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word *av) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word *av) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word *av) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word *av) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word *av) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word *av) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word *av) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word *av) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word *av) C_noret;
C_noret_decl(f_3067)
static void C_fcall f_3067(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word *av) C_noret;
C_noret_decl(f_2327)
static void C_ccall f_2327(C_word c,C_word *av) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word *av) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word *av) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word *av) C_noret;
C_noret_decl(f_3081)
static void C_ccall f_3081(C_word c,C_word *av) C_noret;
C_noret_decl(f_3443)
static void C_fcall f_3443(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734(C_word c,C_word *av) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word *av) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word *av) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word *av) C_noret;
C_noret_decl(f_2431)
static void C_ccall f_2431(C_word c,C_word *av) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word *av) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word *av) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word *av) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word *av) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word *av) C_noret;
C_noret_decl(f_1913)
static void C_ccall f_1913(C_word c,C_word *av) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word *av) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word *av) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word *av) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word *av) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word *av) C_noret;
C_noret_decl(f_1252)
static void C_ccall f_1252(C_word c,C_word *av) C_noret;
C_noret_decl(f_1255)
static void C_ccall f_1255(C_word c,C_word *av) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word *av) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word *av) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word *av) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word *av) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word *av) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word *av) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word *av) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word *av) C_noret;
C_noret_decl(f_2966)
static void C_fcall f_2966(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word *av) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word *av) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word *av) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word *av) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word *av) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word *av) C_noret;
C_noret_decl(f_3343)
static void C_fcall f_3343(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(C_compiler_2dsyntax_toplevel)
C_externexport void C_ccall C_compiler_2dsyntax_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_3169)
static void C_fcall f_3169(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word *av) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word *av) C_noret;
C_noret_decl(f_2065)
static void C_ccall f_2065(C_word c,C_word *av) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word *av) C_noret;
C_noret_decl(f_3252)
static C_word C_fcall f_3252(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word *av) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word *av) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word *av) C_noret;
C_noret_decl(f_3261)
static void C_fcall f_3261(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word *av) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word *av) C_noret;
C_noret_decl(f_1269)
static void C_ccall f_1269(C_word c,C_word *av) C_noret;
C_noret_decl(f_1265)
static void C_ccall f_1265(C_word c,C_word *av) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word *av) C_noret;
C_noret_decl(f_3497)
static void C_ccall f_3497(C_word c,C_word *av) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word *av) C_noret;
C_noret_decl(f_1810)
static void C_fcall f_1810(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1470)
static void C_ccall f_1470(C_word c,C_word *av) C_noret;
C_noret_decl(f_1472)
static C_word C_fcall f_1472(C_word t0);
C_noret_decl(f_3295)
static void C_fcall f_3295(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1482)
static void C_fcall f_1482(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word *av) C_noret;
C_noret_decl(f_1283)
static void C_fcall f_1283(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1292)
static void C_fcall f_1292(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1261)
static void C_ccall f_1261(C_word c,C_word *av) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word *av) C_noret;
C_noret_decl(f_3391)
static void C_fcall f_3391(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;

C_noret_decl(trf_2530)
static void C_ccall trf_2530(C_word c,C_word *av) C_noret;
static void C_ccall trf_2530(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2530(t0,t1);}

C_noret_decl(trf_2794)
static void C_ccall trf_2794(C_word c,C_word *av) C_noret;
static void C_ccall trf_2794(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2794(t0,t1,t2,t3);}

C_noret_decl(trf_2714)
static void C_ccall trf_2714(C_word c,C_word *av) C_noret;
static void C_ccall trf_2714(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2714(t0,t1,t2);}

C_noret_decl(trf_2760)
static void C_ccall trf_2760(C_word c,C_word *av) C_noret;
static void C_ccall trf_2760(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2760(t0,t1,t2);}

C_noret_decl(trf_2652)
static void C_ccall trf_2652(C_word c,C_word *av) C_noret;
static void C_ccall trf_2652(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2652(t0,t1,t2);}

C_noret_decl(trf_2898)
static void C_ccall trf_2898(C_word c,C_word *av) C_noret;
static void C_ccall trf_2898(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_2898(t0,t1,t2,t3);}

C_noret_decl(trf_1389)
static void C_ccall trf_1389(C_word c,C_word *av) C_noret;
static void C_ccall trf_1389(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_1389(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1383)
static void C_ccall trf_1383(C_word c,C_word *av) C_noret;
static void C_ccall trf_1383(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1383(t0,t1);}

C_noret_decl(trf_1549)
static void C_ccall trf_1549(C_word c,C_word *av) C_noret;
static void C_ccall trf_1549(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1549(t0,t1,t2);}

C_noret_decl(trf_3215)
static void C_ccall trf_3215(C_word c,C_word *av) C_noret;
static void C_ccall trf_3215(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3215(t0,t1,t2);}

C_noret_decl(trf_2842)
static void C_ccall trf_2842(C_word c,C_word *av) C_noret;
static void C_ccall trf_2842(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2842(t0,t1,t2);}

C_noret_decl(trf_1501)
static void C_ccall trf_1501(C_word c,C_word *av) C_noret;
static void C_ccall trf_1501(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1501(t0,t1,t2);}

C_noret_decl(trf_3067)
static void C_ccall trf_3067(C_word c,C_word *av) C_noret;
static void C_ccall trf_3067(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3067(t0,t1);}

C_noret_decl(trf_3443)
static void C_ccall trf_3443(C_word c,C_word *av) C_noret;
static void C_ccall trf_3443(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3443(t0,t1,t2);}

C_noret_decl(trf_2966)
static void C_ccall trf_2966(C_word c,C_word *av) C_noret;
static void C_ccall trf_2966(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2966(t0,t1,t2);}

C_noret_decl(trf_3343)
static void C_ccall trf_3343(C_word c,C_word *av) C_noret;
static void C_ccall trf_3343(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3343(t0,t1,t2);}

C_noret_decl(trf_3169)
static void C_ccall trf_3169(C_word c,C_word *av) C_noret;
static void C_ccall trf_3169(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3169(t0,t1,t2);}

C_noret_decl(trf_3261)
static void C_ccall trf_3261(C_word c,C_word *av) C_noret;
static void C_ccall trf_3261(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3261(t0,t1,t2);}

C_noret_decl(trf_1810)
static void C_ccall trf_1810(C_word c,C_word *av) C_noret;
static void C_ccall trf_1810(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1810(t0,t1,t2);}

C_noret_decl(trf_3295)
static void C_ccall trf_3295(C_word c,C_word *av) C_noret;
static void C_ccall trf_3295(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3295(t0,t1,t2,t3);}

C_noret_decl(trf_1482)
static void C_ccall trf_1482(C_word c,C_word *av) C_noret;
static void C_ccall trf_1482(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1482(t0,t1);}

C_noret_decl(trf_1283)
static void C_ccall trf_1283(C_word c,C_word *av) C_noret;
static void C_ccall trf_1283(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1283(t0,t1,t2);}

C_noret_decl(trf_1292)
static void C_ccall trf_1292(C_word c,C_word *av) C_noret;
static void C_ccall trf_1292(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1292(t0,t1,t2);}

C_noret_decl(trf_3391)
static void C_ccall trf_3391(C_word c,C_word *av) C_noret;
static void C_ccall trf_3391(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3391(t0,t1,t2,t3);}

/* k2565 in k2894 in k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in ... */
static void C_ccall f_2567(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,1))){C_save_and_reclaim((void *)f_2567,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[5],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1341(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,5))){C_save_and_reclaim((void *)f_1341,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1344,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2437,tmp=(C_word)a,a+=2,tmp);
/* compiler-syntax.scm:134: r-c-s */
t4=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[71];
av2[3]=t3;
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1344(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_1344,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2323,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2435,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler-syntax.scm:141: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[58];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1347(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_1347,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1350,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2236,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2321,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler-syntax.scm:158: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[58];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_fcall f_2530(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(29,0,3))){
C_save_and_reclaim_args((void *)trf_2530,2,t0,t1);}
a=C_alloc(29);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=C_i_check_list_2(((C_word*)t0)[2],lf[72]);
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2544,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[2],tmp=(C_word)a,a+=17,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2966,a[2]=t4,a[3]=t9,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2966(t11,t7,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[10];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1361(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,2))){C_save_and_reclaim((void *)f_1361,3,av);}
a=C_alloc(18);
t3=C_i_length(((C_word*)t0)[2]);
if(C_truep(C_fixnum_greater_or_equal_p(t3,C_fix(1)))){
if(C_truep(C_i_memq(((C_word*)t0)[3],*((C_word*)lf[13]+1)))){
t4=C_i_car(((C_word*)t0)[2]);
t5=C_i_stringp(t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1383,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_1383(t7,t5);}
else{
t7=((C_word*)t0)[2];
t8=C_u_i_car(t7);
if(C_truep(C_i_listp(t8))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1884,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:183: r */
t11=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[28];
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t9=t6;
f_1383(t9,C_SCHEME_FALSE);}}}
else{
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* g435 in k2894 in k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in ... */
static C_word C_fcall f_2572(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_overflow_check;{}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],lf[72]);
t3=C_a_i_list(&a,3,lf[42],t1,t2);
return(C_a_i_list(&a,2,lf[43],t3));}

/* k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1338(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_1338,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1341,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2478,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3028,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler-syntax.scm:92: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[48];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* map-loop459 in k2585 in k2894 in k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in ... */
static void C_fcall f_2794(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_2794,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list2(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k1300 in for-each-loop43 in k1319 in k1315 in r-c-s in k1256 in k1253 in k1250 */
static void C_ccall f_1302(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1302,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1292(t3,((C_word*)t0)[4],t2);}

/* k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2521(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,2))){C_save_and_reclaim((void *)f_2521,2,av);}
a=C_alloc(20);
t2=t1;
t3=C_i_cddr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2530,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t2,a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_i_memq(lf[72],*((C_word*)lf[76]+1)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3008,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* compiler-syntax.scm:110: length+ */
t7=*((C_word*)lf[77]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t6=t5;
f_2530(t6,C_SCHEME_FALSE);}}

/* k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1350(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_1350,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2163,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2234,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler-syntax.scm:168: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[58];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* ##compiler#compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1355(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_1355,8,av);}
a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1361,a[2]=t5,a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t6,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:177: call/cc */
t9=*((C_word*)lf[39]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t1;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}

/* k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1353(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,8))){C_save_and_reclaim((void *)f_1353,2,av);}
a=C_alloc(11);
t2=C_mutate2((C_word*)lf[12]+1 /* (set! ##compiler#compile-format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1355,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1913,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2046,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2161,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* compiler-syntax.scm:266: ##sys#primitive-alias */
t6=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[48];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k2295 in k2299 in k2303 in k2307 in k2311 in k2315 in k2319 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,4))){C_save_and_reclaim((void *)f_2297,2,av);}
a=C_alloc(24);
t2=C_a_i_cons(&a,2,lf[16],t1);
t3=C_a_i_list(&a,7,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],t2);
/* compiler-syntax.scm:158: r-c-s */
t4=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[8];
av2[2]=lf[62];
av2[3]=((C_word*)t0)[9];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2544(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
if(!C_demand(C_calculate_demand(70,c,4))){C_save_and_reclaim((void *)f_2544,2,av);}
a=C_alloc(70);
t2=t1;
t3=C_a_i_list(&a,1,lf[73]);
t4=C_a_i_list(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t5=C_a_i_list(&a,3,((C_word*)t0)[3],t3,t4);
t6=C_a_i_list(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_list(&a,1,t6);
t8=t7;
t9=C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t10=t9;
t11=C_i_cadr(((C_word*)t0)[6]);
t12=C_a_i_list(&a,2,((C_word*)t0)[7],t11);
t13=t12;
t14=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t15=t14;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=((C_word*)t16)[1];
t18=C_i_check_list_2(t2,lf[72]);
t19=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2896,a[2]=t13,a[3]=t10,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t8,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[3],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[4],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[5],a[17]=((C_word*)t0)[15],a[18]=t2,tmp=(C_word)a,a+=19,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2898,a[2]=t16,a[3]=t21,a[4]=t17,tmp=(C_word)a,a+=5,tmp));
t23=((C_word*)t21)[1];
f_2898(t23,t19,t2,((C_word*)t0)[16]);}

/* k1319 in k1315 in r-c-s in k1256 in k1253 in k1250 */
static void C_ccall f_1321(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_1321,2,av);}
a=C_alloc(12);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1283,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[3];
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1292,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1292(t9,((C_word*)t0)[4],t5);}

/* k1323 in r-c-s in k1256 in k1253 in k1250 */
static void C_ccall f_1325(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1325,2,av);}
t2=C_i_car(((C_word*)t0)[2]);
/* compiler-syntax.scm:46: ##sys#ensure-transformer */
t3=*((C_word*)lf[10]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2710 in k2756 in k2600 in k2585 in k2894 in k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in ... */
static void C_ccall f_2712(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(!C_demand(C_calculate_demand(73,c,3))){C_save_and_reclaim((void *)f_2712,2,av);}
a=C_alloc(73);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=C_a_i_list(&a,3,((C_word*)t0)[4],t2,t3);
t5=C_a_i_list(&a,2,((C_word*)t0)[5],t4);
t6=C_a_i_list(&a,1,t5);
t7=t6;
t8=C_a_i_list(&a,4,lf[74],((C_word*)t0)[6],C_fix(1),((C_word*)t0)[5]);
t9=t8;
t10=C_a_i_list(&a,3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);
t11=t10;
t12=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t13=t12;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=((C_word*)t14)[1];
t16=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t7,a[5]=t9,a[6]=t11,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2652,a[2]=t14,a[3]=t18,a[4]=t15,tmp=(C_word)a,a+=5,tmp));
t20=((C_word*)t18)[1];
f_2652(t20,t16,((C_word*)t0)[16]);}

/* map-loop520 in k2756 in k2600 in k2585 in k2894 in k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in ... */
static void C_fcall f_2714(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(12,0,2))){
C_save_and_reclaim_args((void *)trf_2714,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,3,lf[44],t3,C_fix(0));
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2220 in k2224 in k2228 in k2232 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_2222,2,av);}
a=C_alloc(11);
t2=C_a_i_cons(&a,2,lf[35],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2218,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:168: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[60];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2224 in k2228 in k2232 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2226(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_2226,2,av);}
a=C_alloc(10);
t2=C_a_i_cons(&a,2,lf[17],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:168: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[35];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2515(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_2515,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* compiler-syntax.scm:106: r */
t3=((C_word*)t0)[14];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[78];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2518(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_2518,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* compiler-syntax.scm:107: r */
t4=((C_word*)t0)[14];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[48];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2512(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_2512,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* compiler-syntax.scm:105: r */
t3=((C_word*)t0)[14];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[69];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2232 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2234(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_2234,2,av);}
a=C_alloc(8);
t2=C_a_i_cons(&a,2,lf[58],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2230,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:168: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[59];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* a2235 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2236(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,7))){C_save_and_reclaim((void *)f_2236,5,av);}
a=C_alloc(4);
t5=C_i_length(t2);
if(C_truep(C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2246,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cadr(t2);
t8=t2;
t9=C_u_i_cdr(t8);
t10=C_u_i_cdr(t9);
/* compiler-syntax.scm:161: compile-format-string */
t11=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t11;
av2[1]=t6;
av2[2]=lf[17];
av2[3]=t7;
av2[4]=t2;
av2[5]=t10;
av2[6]=t3;
av2[7]=t4;
((C_proc)(void*)(*((C_word*)t11+1)))(8,av2);}}
else{
t6=t2;
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k2228 in k2232 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2230(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_2230,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,lf[59],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2226,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:168: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[17];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2585 in k2894 in k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in ... */
static void C_ccall f_2587(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(29,c,4))){C_save_and_reclaim((void *)f_2587,2,av);}
a=C_alloc(29);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t2,a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2794,a[2]=t5,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2794(t11,t7,((C_word*)t0)[15],((C_word*)t0)[15]);}

/* k2244 in a2235 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2246(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2246,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=(C_truep(t1)?t1:((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1315 in r-c-s in k1256 in k1253 in k1250 */
static void C_ccall f_1317(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_1317,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1321,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:49: append */
t4=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k1652 in k1612 in loop in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1654(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_1654,2,av);}
a=C_alloc(15);
t2=C_a_i_list(&a,4,lf[18],t1,C_SCHEME_FALSE,((C_word*)t0)[2]);
t3=f_1539(C_a_i(&a,3),((C_word*)((C_word*)t0)[3])[1],t2);
/* compiler-syntax.scm:263: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1549(t4,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* map-loop490 in k2600 in k2585 in k2894 in k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in ... */
static void C_fcall f_2760(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_2760,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_2751(C_a_i(&a,6),((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2509(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_2509,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2512,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* compiler-syntax.scm:104: r */
t4=((C_word*)t0)[13];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[79];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2506(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_2506,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler-syntax.scm:103: r */
t4=((C_word*)t0)[12];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[28];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2503(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_2503,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler-syntax.scm:102: gensym */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2500(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_2500,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler-syntax.scm:101: gensym */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3006 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_3008(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3008,2,av);}
t2=((C_word*)t0)[2];
f_2530(t2,C_i_greaterp(t1,C_fix(2)));}

/* map-loop550 in k2710 in k2756 in k2600 in k2585 in k2894 in k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in ... */
static void C_fcall f_2652(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(12,0,2))){
C_save_and_reclaim_args((void *)trf_2652,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,3,lf[44],t3,C_fix(1));
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2756 in k2600 in k2585 in k2894 in k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in ... */
static void C_ccall f_2758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(32,c,3))){C_save_and_reclaim((void *)f_2758,2,av);}
a=C_alloc(32);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2712,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t3,a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2714,a[2]=t6,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_2714(t12,t8,((C_word*)t0)[16]);}

/* k2648 in k2710 in k2756 in k2600 in k2585 in k2894 in k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in ... */
static void C_ccall f_2650(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(57,c,3))){C_save_and_reclaim((void *)f_2650,2,av);}
a=C_alloc(57);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[45],t2);
t4=C_a_i_list(&a,5,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t3);
t5=C_a_i_list(&a,3,lf[44],((C_word*)t0)[7],C_fix(1));
t6=C_a_i_list(&a,4,((C_word*)t0)[8],((C_word*)t0)[9],t4,t5);
t7=C_a_i_list(&a,4,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[10],t6);
t8=C_a_i_list(&a,1,t7);
/* compiler-syntax.scm:111: ##sys#append */
t9=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=((C_word*)t0)[11];
av2[2]=((C_word*)t0)[12];
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}

/* g496 in k2600 in k2585 in k2894 in k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in ... */
static C_word C_fcall f_2751(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2165 in a2162 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2167(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2167,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a2162 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2163(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,7))){C_save_and_reclaim((void *)f_2163,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2167,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(t2);
/* compiler-syntax.scm:170: compile-format-string */
t7=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=lf[56];
av2[3]=lf[57];
av2[4]=t2;
av2[5]=t6;
av2[6]=t3;
av2[7]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(8,av2);}}

/* k2894 in k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 in ... */
static void C_ccall f_2896(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(44,c,3))){C_save_and_reclaim((void *)f_2896,2,av);}
a=C_alloc(44);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2567,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2572,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[4],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=t5,a[15]=((C_word*)t0)[18],tmp=(C_word)a,a+=16,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2842,a[2]=t10,a[3]=t8,a[4]=t13,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_2842(t15,t11,((C_word*)t0)[18]);}

/* k2159 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2161(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2161,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,lf[48],t1);
t3=C_a_i_list(&a,1,t2);
/* compiler-syntax.scm:266: r-c-s */
t4=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[55];
av2[3]=((C_word*)t0)[3];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* map-loop398 in k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 in ... */
static void C_fcall f_2898(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_2898,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list2(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_fcall f_1389(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_1389,5,t0,t1,t2,t3,t4);}
a=C_alloc(9);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1393,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm:188: get-line */
t6=*((C_word*)lf[25]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_fcall f_1383(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_1383,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
if(C_truep(C_i_stringp(t4))){
t5=((C_word*)t0)[2];
t6=t2;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_u_i_car(t5);
f_1386(2,av2);}}
else{
/* compiler-syntax.scm:185: cadar */
t5=*((C_word*)lf[38]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}
else{
t2=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1386(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,5))){C_save_and_reclaim((void *)f_1386,2,av);}
a=C_alloc(24);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1389,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_i_string_length(t2);
t12=t11;
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1461,a[2]=t2,a[3]=t10,a[4]=t5,a[5]=t6,a[6]=t8,a[7]=t12,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* compiler-syntax.scm:198: r */
t14=((C_word*)t0)[8];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t14;
av2[1]=t13;
av2[2]=lf[37];
((C_proc)(void*)(*((C_word*)t14+1)))(3,av2);}}

/* k1635 in k1612 in loop in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1637(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_1637,2,av);}
a=C_alloc(15);
t2=C_a_i_list(&a,4,lf[18],t1,C_SCHEME_TRUE,((C_word*)t0)[2]);
t3=f_1539(C_a_i(&a,3),((C_word*)((C_word*)t0)[3])[1],t2);
/* compiler-syntax.scm:263: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1549(t4,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k1612 in loop in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1614(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,4))){C_save_and_reclaim((void *)f_1614,2,av);}
a=C_alloc(16);
t2=C_u_i_char_upcase(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1620,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
switch(t2){
case C_make_character(83):
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:234: next */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1482(t5,t4);
case C_make_character(65):
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:235: next */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1482(t5,t4);
case C_make_character(67):
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1671,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:236: next */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1482(t5,t4);
case C_make_character(66):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1692,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:239: next */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1482(t5,t4);
case C_make_character(79):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1713,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:243: next */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1482(t5,t4);
case C_make_character(88):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1734,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:247: next */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1482(t5,t4);
case C_make_character(33):
t4=C_a_i_list(&a,2,lf[32],((C_word*)t0)[5]);
t5=f_1539(C_a_i(&a,3),((C_word*)((C_word*)t0)[6])[1],t4);
/* compiler-syntax.scm:263: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1549(t6,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
case C_make_character(63):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:251: next */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1482(t5,t4);
case C_make_character(126):
t4=C_a_i_list(&a,3,lf[21],C_make_character(126),((C_word*)t0)[5]);
t5=f_1539(C_a_i(&a,3),((C_word*)((C_word*)t0)[6])[1],t4);
/* compiler-syntax.scm:263: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1549(t6,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
default:
t4=C_eqp(t2,C_make_character(37));
t5=(C_truep(t4)?t4:C_eqp(t2,C_make_character(78)));
if(C_truep(t5)){
t6=C_a_i_list(&a,3,lf[21],C_make_character(10),((C_word*)t0)[5]);
t7=f_1539(C_a_i(&a,3),((C_word*)((C_word*)t0)[6])[1],t6);
/* compiler-syntax.scm:263: loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_1549(t8,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_u_i_char_whitespacep(((C_word*)t0)[2]))){
t6=f_1472(((C_word*)((C_word*)t0)[10])[1]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1810,a[2]=((C_word*)t0)[10],a[3]=t8,a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_1810(t10,t3,t6);}
else{
/* compiler-syntax.scm:262: fail */
t6=((C_word*)t0)[12];
f_1389(t6,t3,C_SCHEME_TRUE,lf[34],C_a_i_list(&a,1,((C_word*)t0)[2]));}}}}

/* k2600 in k2585 in k2894 in k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in ... */
static void C_ccall f_2602(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,3))){C_save_and_reclaim((void *)f_2602,2,av);}
a=C_alloc(33);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2751,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2758,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t2,a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2760,a[2]=t7,a[3]=t5,a[4]=t10,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_2760(t12,t8,((C_word*)t0)[16]);}

/* k1618 in k1612 in loop in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1620(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1620,2,av);}
/* compiler-syntax.scm:263: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1549(t2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}

/* g195 in k3387 in k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static C_word C_fcall f_3101(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_overflow_check;{}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],lf[84]);
t3=C_a_i_list(&a,3,lf[42],t1,t2);
return(C_a_i_list(&a,2,lf[43],t3));}

/* k3114 in k3387 in k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3116(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,4))){C_save_and_reclaim((void *)f_3116,2,av);}
a=C_alloc(24);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3295,a[2]=t5,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_3295(t11,t7,((C_word*)t0)[10],((C_word*)t0)[10]);}

/* k1394 in k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1396(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1396,2,av);}
if(C_truep(((C_word*)t0)[2])){
/* compiler-syntax.scm:194: return */
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1393(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_1393,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1406,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:190: open-output-string */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k1416 in k1413 in k1410 in k1404 in k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_1418,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:190: ##sys#print */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[20];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1413 in k1410 in k1404 in k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1415(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_1415,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:190: ##sys#print */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1410 in k1404 in k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1412(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_1412,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1415,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm:190: ##sys#write-char-0 */
t3=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(96);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1404 in k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 in ... */
static void C_ccall f_1427(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,5))){C_save_and_reclaim((void *)f_1427,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=0;
av2[1]=t2;
av2[2]=*((C_word*)lf[17]+1);
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=((C_word*)t0)[6];
C_apply(6,av2);}}

/* k1422 in k1419 in k1416 in k1413 in k1410 in k1404 in k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_1424,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:190: ##sys#print */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[19];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1419 in k1416 in k1413 in k1410 in k1404 in k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1421(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_1421,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:190: ##sys#print */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2350 in k2362 in k2338 in k2328 in k2325 in a2322 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2352(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,1))){C_save_and_reclaim((void *)f_2352,2,av);}
a=C_alloc(18);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,4,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* loop in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_fcall f_1549(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(13,0,4))){
C_save_and_reclaim_args((void *)trf_1549,3,t0,t1,t2);}
a=C_alloc(13);
if(C_truep(C_i_greater_or_equalp(((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1559,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[10])[1]))){
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_1559(2,av2);}}
else{
/* compiler-syntax.scm:223: fail */
t4=((C_word*)t0)[11];
f_1389(t4,t3,C_SCHEME_FALSE,lf[31],C_SCHEME_END_OF_LIST);}}
else{
t3=f_1472(((C_word*)((C_word*)t0)[12])[1]);
t4=C_eqp(t3,C_make_character(126));
if(C_truep(t4)){
t5=f_1472(((C_word*)((C_word*)t0)[12])[1]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1614,a[2]=t6,a[3]=((C_word*)t0)[13],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[17],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[2],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler-syntax.scm:232: endchunk */
t8=((C_word*)((C_word*)t0)[9])[1];
f_1501(t8,t7,t2);}
else{
t5=C_a_i_cons(&a,2,t3,t2);
/* compiler-syntax.scm:264: loop */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}}}

/* map-loop280 in k3257 in k3129 in k3114 in k3387 in k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_fcall f_3215(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(12,0,2))){
C_save_and_reclaim_args((void *)trf_3215,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,3,lf[44],t3,C_fix(0));
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3211 in k3257 in k3129 in k3114 in k3387 in k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3213(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,3))){C_save_and_reclaim((void *)f_3213,2,av);}
a=C_alloc(26);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3167,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3169,a[2]=t6,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_3169(t12,t8,((C_word*)t0)[11]);}

/* k2362 in k2338 in k2328 in k2325 in a2322 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2364(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,2))){C_save_and_reclaim((void *)f_2364,2,av);}
a=C_alloc(19);
t2=C_a_i_list(&a,1,t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:155: r */
t7=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[16];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k1404 in k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,4))){C_save_and_reclaim((void *)f_1406,2,av);}
a=C_alloc(17);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1412,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1437,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[7])){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1440,a[2]=t6,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* compiler-syntax.scm:191: open-output-string */
t8=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
/* compiler-syntax.scm:190: ##sys#print */
t7=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=lf[24];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}}

/* map-loop429 in k2894 in k2542 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in ... */
static void C_fcall f_2842(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(24,0,2))){
C_save_and_reclaim_args((void *)trf_2842,3,t0,t1,t2);}
a=C_alloc(24);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_2572(C_a_i(&a,21),((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1557 in loop in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1559(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_1559,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:224: endchunk */
t3=((C_word*)((C_word*)t0)[8])[1];
f_1501(t3,t2,((C_word*)t0)[9]);}

/* k1690 in k1612 in loop in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1692(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,2))){C_save_and_reclaim((void *)f_1692,2,av);}
a=C_alloc(24);
t2=C_a_i_list(&a,3,((C_word*)t0)[2],t1,C_fix(2));
t3=C_a_i_list(&a,4,lf[18],t2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t4=f_1539(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t3);
/* compiler-syntax.scm:263: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1549(t5,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k1560 in k1557 in loop in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,2))){C_save_and_reclaim((void *)f_1562,2,av);}
a=C_alloc(33);
t2=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=C_a_i_list(&a,2,lf[28],((C_word*)t0)[4]);
t6=C_a_i_list(&a,4,lf[29],((C_word*)t0)[2],C_SCHEME_TRUE,t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1585,a[2]=t7,a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:227: reverse */
t9=*((C_word*)lf[30]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=((C_word*)((C_word*)t0)[7])[1];
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}

/* k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3046(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_3046,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler-syntax.scm:69: r */
t4=((C_word*)t0)[8];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[28];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3049(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_3049,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm:70: r */
t4=((C_word*)t0)[9];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[78];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3040(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_3040,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:67: gensym */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3043(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_3043,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm:68: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[79];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1450 in k1447 in k1444 in k1438 in k1404 in k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1452(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1452,2,av);}
/* compiler-syntax.scm:191: get-output-string */
t2=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2307 in k2311 in k2315 in k2319 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2309(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_2309,2,av);}
a=C_alloc(11);
t2=C_a_i_cons(&a,2,lf[35],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:158: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[60];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2303 in k2307 in k2311 in k2315 in k2319 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2305(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_2305,2,av);}
a=C_alloc(12);
t2=C_a_i_cons(&a,2,lf[60],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm:158: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[23];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1467(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_1467,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler-syntax.scm:201: r */
t4=((C_word*)t0)[13];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[35];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2299 in k2303 in k2307 in k2311 in k2315 in k2319 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2301(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_2301,2,av);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,lf[23],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler-syntax.scm:158: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[16];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_3058,2,av);}
a=C_alloc(16);
t2=C_i_cddr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3067,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_memq(lf[84],*((C_word*)lf[76]+1)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3485,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* compiler-syntax.scm:75: length+ */
t6=*((C_word*)lf[77]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=t4;
f_3067(t5,C_SCHEME_FALSE);}}

/* k1669 in k1612 in loop in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_1671,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,3,lf[21],t1,((C_word*)t0)[2]);
t3=f_1539(C_a_i(&a,3),((C_word*)((C_word*)t0)[3])[1],t2);
/* compiler-syntax.scm:263: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1549(t4,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3052(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_3052,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler-syntax.scm:71: r */
t4=((C_word*)t0)[10];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[48];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1461(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_1461,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* compiler-syntax.scm:199: r */
t4=((C_word*)t0)[11];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[17];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3055(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_3055,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler-syntax.scm:72: r */
t4=((C_word*)t0)[11];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[69];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1464(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_1464,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* compiler-syntax.scm:200: r */
t4=((C_word*)t0)[12];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[36];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* endchunk in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_fcall f_1501(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,2))){
C_save_and_reclaim_args((void *)trf_1501,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t3=C_i_length(t2);
t4=C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=C_i_car(t2);
t6=C_a_i_list(&a,3,lf[21],t5,((C_word*)t0)[2]);
/* compiler-syntax.scm:214: push */
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=f_1539(C_a_i(&a,3),((C_word*)((C_word*)t0)[3])[1],t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1532,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:217: reverse-list->string */
t6=*((C_word*)lf[27]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k1435 in k1404 in k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1437(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1437,2,av);}
/* compiler-syntax.scm:190: ##sys#print */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k2328 in k2325 in a2322 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2330(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_2330,2,av);}
a=C_alloc(6);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:153: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[36];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1404 in k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in ... */
static void C_ccall f_1430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1430,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1433,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler-syntax.scm:190: get-output-string */
t3=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k1431 in k1428 in k1425 in k1422 in k1419 in k1416 in k1413 in k1410 in k1404 in k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in ... */
static void C_ccall f_1433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1433,2,av);}
/* compiler-syntax.scm:189: warning */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1444 in k1438 in k1404 in k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1446(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_1446,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:191: ##sys#print */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1447 in k1444 in k1438 in k1404 in k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1449(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1449,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* compiler-syntax.scm:191: ##sys#print */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[22];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2338 in k2328 in k2325 in a2322 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2340(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2340,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:153: r */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[23];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1438 in k1404 in k1391 in fail in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1440(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1440,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[14]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1446,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:191: ##sys#write-char-0 */
t6=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_make_character(40);
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k1530 in endchunk in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1532(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,1))){C_save_and_reclaim((void *)f_1532,2,av);}
a=C_alloc(15);
t2=C_a_i_list(&a,4,lf[18],t1,C_SCHEME_FALSE,((C_word*)t0)[2]);
/* compiler-syntax.scm:214: push */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=f_1539(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* push in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static C_word C_fcall f_1539(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_overflow_check;{}
t2=C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}

/* k3466 in map-loop128 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3468(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3468,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3443(t6,((C_word*)t0)[5],t5);}

/* a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2478(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2478,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2482,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:94: r */
t6=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[36];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k1757 in k1754 in k1612 in loop in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1759(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,2))){C_save_and_reclaim((void *)f_1759,2,av);}
a=C_alloc(18);
t2=C_a_i_list(&a,5,lf[33],((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);
t3=f_1539(C_a_i(&a,3),((C_word*)((C_word*)t0)[5])[1],t2);
/* compiler-syntax.scm:263: loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_1549(t4,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);}

/* k2452 in k2445 in a2436 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2454(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_2454,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_a_i_list(&a,1,((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2462,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_i_cdr(((C_word*)t0)[4]);
/* compiler-syntax.scm:138: fold-right */
t7=*((C_word*)lf[67]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=*((C_word*)lf[68]+1);
av2[3]=((C_word*)t0)[2];
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k1754 in k1612 in loop in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1756(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_1756,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:252: next */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1482(t4,t3);}

/* k3129 in k3114 in k3387 in k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3131(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(28,c,3))){C_save_and_reclaim((void *)f_3131,2,av);}
a=C_alloc(28);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3252,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3259,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3261,a[2]=t7,a[3]=t5,a[4]=t10,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_3261(t12,t8,((C_word*)t0)[11]);}

/* k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2485(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2485,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:96: r */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[82];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2482(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_2482,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2485,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:95: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[49];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2488(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_2488,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:97: gensym */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2460 in k2452 in k2445 in a2436 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2462(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_2462,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1882 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1884(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1884,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* compiler-syntax.scm:184: cadar */
t3=*((C_word*)lf[38]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];
f_1383(t2,C_SCHEME_FALSE);}}

/* k1941 in k1938 in k1935 in a1917 in k1911 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1943(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_1943,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm:298: r */
t4=((C_word*)t0)[8];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[48];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1938 in k1935 in a1917 in k1911 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1940(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_1940,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm:297: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[49];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1947 in k1944 in k1941 in k1938 in k1935 in a1917 in k1911 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_1949,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1952,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm:300: gensym */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[47];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1944 in k1941 in k1938 in k1935 in a1917 in k1911 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1946(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_1946,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler-syntax.scm:299: gensym */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1583 in k1560 in k1557 in loop in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1585(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_1585,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2315 in k2319 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2317(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_2317,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,lf[59],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2313,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:158: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[17];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2311 in k2315 in k2319 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2313(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_2313,2,av);}
a=C_alloc(10);
t2=C_a_i_cons(&a,2,lf[17],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:158: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[35];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in a1917 in k1911 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1952(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_1952,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* compiler-syntax.scm:301: gensym */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_fcall f_3067(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(25,0,3))){
C_save_and_reclaim_args((void *)trf_3067,2,t0,t1);}
a=C_alloc(25);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=C_i_check_list_2(((C_word*)t0)[2],lf[72]);
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3081,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[2],tmp=(C_word)a,a+=13,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3443,a[2]=t4,a[3]=t9,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_3443(t11,t7,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in a1917 in k1911 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1955(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_demand(C_calculate_demand(138,c,1))){C_save_and_reclaim((void *)f_1955,2,av);}
a=C_alloc(138);
t2=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t4=C_a_i_list(&a,2,t2,t3);
t5=C_a_i_list(&a,2,lf[41],lf[40]);
t6=C_a_i_list(&a,3,lf[42],t1,t5);
t7=C_a_i_list(&a,2,lf[43],t6);
t8=C_a_i_list(&a,2,t1,t1);
t9=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[2]);
t10=C_a_i_list(&a,2,t8,t9);
t11=C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t12=C_a_i_list(&a,3,lf[44],t1,C_fix(1));
t13=C_a_i_list(&a,3,lf[44],t1,C_fix(0));
t14=C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[2],t13);
t15=C_a_i_list(&a,4,lf[45],((C_word*)t0)[7],t12,t14);
t16=C_a_i_list(&a,4,((C_word*)t0)[8],t11,t15,((C_word*)t0)[2]);
t17=C_a_i_list(&a,4,((C_word*)t0)[9],((C_word*)t0)[7],t10,t16);
t18=((C_word*)t0)[10];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t18;
av2[1]=C_a_i_list(&a,4,((C_word*)t0)[11],t4,t7,t17);
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}

/* k2325 in a2322 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2327(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,7))){C_save_and_reclaim((void *)f_2327,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2330,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(((C_word*)t0)[4]);
t5=(C_truep((C_truep(C_eqp(t4,lf[14]))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,lf[63]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))?lf[14]:lf[64]);
t6=((C_word*)t0)[4];
t7=C_u_i_cdr(t6);
/* compiler-syntax.scm:144: compile-format-string */
t8=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t8;
av2[1]=t3;
av2[2]=t5;
av2[3]=t2;
av2[4]=((C_word*)t0)[4];
av2[5]=t7;
av2[6]=((C_word*)t0)[3];
av2[7]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t8+1)))(8,av2);}}

/* a2322 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2323(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_2323,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2327,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:143: gensym */
t6=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[37];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k2319 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2321(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_2321,2,av);}
a=C_alloc(8);
t2=C_a_i_cons(&a,2,lf[58],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2317,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:158: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[59];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1711 in k1612 in loop in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1713(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,2))){C_save_and_reclaim((void *)f_1713,2,av);}
a=C_alloc(24);
t2=C_a_i_list(&a,3,((C_word*)t0)[2],t1,C_fix(8));
t3=C_a_i_list(&a,4,lf[18],t2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t4=f_1539(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t3);
/* compiler-syntax.scm:263: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1549(t5,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3081(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(31,c,4))){C_save_and_reclaim((void *)f_3081,2,av);}
a=C_alloc(31);
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=t4;
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=C_i_check_list_2(t2,lf[72]);
t11=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3389,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3391,a[2]=t8,a[3]=t13,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t15=((C_word*)t13)[1];
f_3391(t15,t11,t2,((C_word*)t0)[12]);}

/* map-loop128 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_fcall f_3443(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_3443,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3468,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_list(&a,1,t4);
/* compiler-syntax.scm:76: gensym */
t6=*((C_word*)lf[46]+1);{
C_word av2[2];
av2[0]=t6;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1732 in k1612 in loop in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1734(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,2))){C_save_and_reclaim((void *)f_1734,2,av);}
a=C_alloc(24);
t2=C_a_i_list(&a,3,((C_word*)t0)[2],t1,C_fix(16));
t3=C_a_i_list(&a,4,lf[18],t2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t4=f_1539(C_a_i(&a,3),((C_word*)((C_word*)t0)[4])[1],t3);
/* compiler-syntax.scm:263: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1549(t5,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}

/* k2433 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2435(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_2435,2,av);}
a=C_alloc(8);
t2=C_a_i_cons(&a,2,lf[58],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2431,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:141: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[59];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3094 in k3387 in k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3096(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_3096,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a2436 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2437(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2437,5,av);}
a=C_alloc(5);
t5=C_i_length(t2);
t6=C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?C_i_memq(lf[66],*((C_word*)lf[13]+1)):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2447,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:137: r */
t9=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[70];
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t8=t2;
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}

/* k2429 in k2433 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2431(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_2431,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,lf[59],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2427,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:141: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[17];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1893 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1895(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1895,2,av);}
t2=C_i_caar(((C_word*)t0)[2]);
/* compiler-syntax.scm:183: c */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=t1;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2212 in k2216 in k2220 in k2224 in k2228 in k2232 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2214(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_2214,2,av);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,lf[23],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler-syntax.scm:168: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[16];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2208 in k2212 in k2216 in k2220 in k2224 in k2228 in k2232 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2210(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,4))){C_save_and_reclaim((void *)f_2210,2,av);}
a=C_alloc(24);
t2=C_a_i_cons(&a,2,lf[16],t1);
t3=C_a_i_list(&a,7,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],t2);
/* compiler-syntax.scm:168: r-c-s */
t4=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[8];
av2[2]=lf[61];
av2[3]=((C_word*)t0)[9];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k1889 in k1882 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1891(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1891,2,av);}
t2=((C_word*)t0)[2];
f_1383(t2,C_i_stringp(t1));}

/* k2216 in k2220 in k2224 in k2228 in k2232 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_2218,2,av);}
a=C_alloc(12);
t2=C_a_i_cons(&a,2,lf[60],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm:168: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[23];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1911 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1913(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_1913,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1916,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1918,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2044,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* compiler-syntax.scm:288: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[48];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3026 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_3028(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_3028,2,av);}
a=C_alloc(8);
t2=C_a_i_cons(&a,2,lf[48],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3024,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:92: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[81];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2445 in a2436 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2447(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2447,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2454,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:138: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[69];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3022 in k3026 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_3024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_3024,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,lf[81],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
/* compiler-syntax.scm:92: r-c-s */
t4=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[83];
av2[3]=((C_word*)t0)[4];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* a1917 in k1911 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1918(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_1918,5,av);}
a=C_alloc(7);
t5=C_i_length(t2);
t6=C_eqp(t5,C_fix(4));
t7=(C_truep(t6)?C_i_memq(lf[40],*((C_word*)lf[13]+1)):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=C_i_cadr(t2);
t9=t8;
t10=C_i_caddr(t2);
t11=t10;
t12=C_i_cadddr(t2);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1937,a[2]=t11,a[3]=t13,a[4]=t9,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:295: r */
t15=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t15;
av2[1]=t14;
av2[2]=lf[50];
((C_proc)(void*)(*((C_word*)t15+1)))(3,av2);}}
else{
t8=t2;
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}

/* k1914 in k1911 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1916(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1916,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1250 */
static void C_ccall f_1252(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1252,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1255,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k1253 in k1250 */
static void C_ccall f_1255(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1255,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1258,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_chicken_2dsyntax_toplevel(2,av2);}}

/* k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3037,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:66: r */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[85];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3030(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3030,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3034,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* compiler-syntax.scm:64: r */
t6=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[36];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3034(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3034,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* compiler-syntax.scm:65: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[49];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2075 in k2072 in k2069 in k2066 in k2063 in a2045 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_2077,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2080,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm:278: gensym */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1256 in k1253 in k1250 */
static void C_ccall f_1258(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,5))){C_save_and_reclaim((void *)f_1258,2,av);}
a=C_alloc(13);
t2=C_set_block_item(lf[0] /* ##compiler#compiler-syntax-statistics */,0,C_SCHEME_END_OF_LIST);
t3=C_mutate2((C_word*)lf[1]+1 /* (set! ##sys#compiler-syntax-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1261,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate2((C_word*)lf[5]+1 /* (set! ##compiler#r-c-s ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1275,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1338,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3030,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3497,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* compiler-syntax.scm:62: ##sys#primitive-alias */
t8=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[48];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k2069 in k2066 in k2063 in a2045 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2071(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_2071,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2074,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm:276: r */
t4=((C_word*)t0)[8];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[49];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2072 in k2069 in k2066 in k2063 in a2045 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2074(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_2074,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler-syntax.scm:277: gensym */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[54];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1935 in a1917 in k1911 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1937(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_1937,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:296: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[36];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* map-loop368 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_fcall f_2966(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_2966,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_list(&a,1,t4);
/* compiler-syntax.scm:111: gensym */
t6=*((C_word*)lf[46]+1);{
C_word av2[2];
av2[0]=t6;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2042 in k1911 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2044,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,lf[48],t1);
t3=C_a_i_list(&a,1,t2);
/* compiler-syntax.scm:288: r-c-s */
t4=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[51];
av2[3]=((C_word*)t0)[3];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* a2045 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2046(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2046,5,av);}
a=C_alloc(7);
t5=C_i_length(t2);
t6=C_eqp(t5,C_fix(4));
t7=(C_truep(t6)?C_i_memq(lf[53],*((C_word*)lf[13]+1)):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=C_i_cadr(t2);
t9=t8;
t10=C_i_caddr(t2);
t11=t10;
t12=C_i_cadddr(t2);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2065,a[2]=t13,a[3]=t9,a[4]=t11,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:273: r */
t15=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t15;
av2[1]=t14;
av2[2]=lf[50];
((C_proc)(void*)(*((C_word*)t15+1)))(3,av2);}}
else{
t8=t2;
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}

/* k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2494(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_2494,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2497,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler-syntax.scm:99: r */
t4=((C_word*)t0)[8];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[80];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2491(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_2491,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2494,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm:98: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[81];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2497(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_2497,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* compiler-syntax.scm:100: gensym */
t4=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2989 in map-loop368 in k2528 in k2519 in k2516 in k2513 in k2510 in k2507 in k2504 in k2501 in k2498 in k2495 in k2492 in k2489 in k2486 in k2483 in k2480 in a2477 in k1336 in k1256 in k1253 in k1250 in ... */
static void C_ccall f_2991(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2991,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2966(t6,((C_word*)t0)[5],t5);}

/* map-loop189 in k3387 in k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_fcall f_3343(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(24,0,2))){
C_save_and_reclaim_args((void *)trf_3343,3,t0,t1,t2);}
a=C_alloc(24);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_3101(C_a_i(&a,21),((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_compiler_2dsyntax_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("compiler_2dsyntax_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_compiler_2dsyntax_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(690)){
C_save(t1);
C_rereclaim2(690*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,87);
lf[0]=C_h_intern(&lf[0],35,"\010compilercompiler-syntax-statistics");
lf[1]=C_h_intern(&lf[1],24,"\003syscompiler-syntax-hook");
lf[2]=C_h_intern(&lf[2],13,"alist-update!");
lf[3]=C_h_intern(&lf[3],9,"alist-ref");
lf[4]=C_h_intern(&lf[4],3,"eq\077");
lf[5]=C_h_intern(&lf[5],14,"\010compilerr-c-s");
lf[6]=C_h_intern(&lf[6],8,"\003sysput!");
lf[7]=C_h_intern(&lf[7],24,"\010compilercompiler-syntax");
lf[8]=C_h_intern(&lf[8],6,"append");
lf[9]=C_h_intern(&lf[9],29,"\003sysdefault-macro-environment");
lf[10]=C_h_intern(&lf[10],22,"\003sysensure-transformer");
lf[11]=C_h_intern(&lf[11],18,"\003syser-transformer");
lf[12]=C_h_intern(&lf[12],30,"\010compilercompile-format-string");
lf[13]=C_h_intern(&lf[13],17,"extended-bindings");
lf[14]=C_h_intern(&lf[14],7,"sprintf");
lf[15]=C_h_intern(&lf[15],7,"warning");
lf[16]=C_h_intern(&lf[16],17,"get-output-string");
lf[17]=C_h_intern(&lf[17],7,"fprintf");
lf[18]=C_h_intern(&lf[18],9,"\003sysprint");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\024\047, in format string ");
lf[21]=C_h_intern(&lf[21],16,"\003syswrite-char-0");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[23]=C_h_intern(&lf[23],18,"open-output-string");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[25]=C_h_intern(&lf[25],17,"\010compilerget-line");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000/too few arguments to formatted output procedure");
lf[27]=C_h_intern(&lf[27],20,"reverse-list->string");
lf[28]=C_h_intern(&lf[28],5,"quote");
lf[29]=C_h_intern(&lf[29],21,"\003syscheck-output-port");
lf[30]=C_h_intern(&lf[30],7,"reverse");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\0000too many arguments to formatted output procedure");
lf[32]=C_h_intern(&lf[32],16,"\003sysflush-output");
lf[33]=C_h_intern(&lf[33],9,"\003sysapply");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000$illegal format-string character `~c\047");
lf[35]=C_h_intern(&lf[35],14,"number->string");
lf[36]=C_h_intern(&lf[36],3,"let");
lf[37]=C_h_intern(&lf[37],3,"out");
lf[38]=C_h_intern(&lf[38],5,"cadar");
lf[39]=C_h_intern(&lf[39],7,"call/cc");
lf[40]=C_h_intern(&lf[40],5,"foldl");
lf[41]=C_h_intern(&lf[41],10,"\004corequote");
lf[42]=C_h_intern(&lf[42],14,"\003syscheck-list");
lf[43]=C_h_intern(&lf[43],10,"\004corecheck");
lf[44]=C_h_intern(&lf[44],8,"\003sysslot");
lf[45]=C_h_intern(&lf[45],8,"\004coreapp");
lf[46]=C_h_intern(&lf[46],6,"gensym");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\005foldl");
lf[48]=C_h_intern(&lf[48],5,"pair\077");
lf[49]=C_h_intern(&lf[49],2,"if");
lf[50]=C_h_intern(&lf[50],4,"let\052");
lf[51]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005foldl\376\003\000\000\002\376\001\000\000\007#%foldl\376\377\016");
lf[52]=C_h_intern(&lf[52],19,"\003sysprimitive-alias");
lf[53]=C_h_intern(&lf[53],5,"foldr");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\005foldr");
lf[55]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005foldr\376\003\000\000\002\376\001\000\000\007#%foldr\376\377\016");
lf[56]=C_h_intern(&lf[56],6,"printf");
lf[57]=C_h_intern(&lf[57],19,"\003sysstandard-output");
lf[58]=C_h_intern(&lf[58],7,"display");
lf[59]=C_h_intern(&lf[59],5,"write");
lf[60]=C_h_intern(&lf[60],10,"write-char");
lf[61]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006printf\376\003\000\000\002\376\001\000\000\010#%printf\376\377\016");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007fprintf\376\003\000\000\002\376\001\000\000\011#%fprintf\376\377\016");
lf[63]=C_h_intern(&lf[63],9,"#%sprintf");
lf[64]=C_h_intern(&lf[64],6,"format");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007sprintf\376\003\000\000\002\376\001\000\000\011#%sprintf\376\003\000\000\002\376\001\000\000\006format\376\003\000\000\002\376\001\000\000\010#%format\376\377\016");
lf[66]=C_h_intern(&lf[66],1,"o");
lf[67]=C_h_intern(&lf[67],10,"fold-right");
lf[68]=C_h_intern(&lf[68],4,"list");
lf[69]=C_h_intern(&lf[69],6,"lambda");
lf[70]=C_h_intern(&lf[70],3,"tmp");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001o\376\003\000\000\002\376\001\000\000\003#%o\376\377\016");
lf[72]=C_h_intern(&lf[72],3,"map");
lf[73]=C_h_intern(&lf[73],14,"\004coreundefined");
lf[74]=C_h_intern(&lf[74],11,"\003syssetslot");
lf[75]=C_h_intern(&lf[75],10,"\003sysappend");
lf[76]=C_h_intern(&lf[76],17,"standard-bindings");
lf[77]=C_h_intern(&lf[77],7,"length+");
lf[78]=C_h_intern(&lf[78],3,"and");
lf[79]=C_h_intern(&lf[79],5,"begin");
lf[80]=C_h_intern(&lf[80],4,"set!");
lf[81]=C_h_intern(&lf[81],4,"cons");
lf[82]=C_h_intern(&lf[82],8,"map-loop");
lf[83]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000\007\003sysmap\376\003\000\000\002\376\001\000\000\005#%map\376\377\016");
lf[84]=C_h_intern(&lf[84],8,"for-each");
lf[85]=C_h_intern(&lf[85],13,"for-each-loop");
lf[86]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\014\003sysfor-each\376\003\000\000\002\376\001\000\000\012#%for-each\376\377\016");
C_register_lf2(lf,87,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1252,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* map-loop310 in k3211 in k3257 in k3129 in k3114 in k3387 in k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_fcall f_3169(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(12,0,2))){
C_save_and_reclaim_args((void *)trf_3169,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,3,lf[44],t3,C_fix(1));
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3165 in k3211 in k3257 in k3129 in k3114 in k3387 in k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3167(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(39,c,3))){C_save_and_reclaim((void *)f_3167,2,av);}
a=C_alloc(39);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[45],t2);
t4=C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t3);
t5=C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[6],t4);
t6=C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[2],((C_word*)t0)[8],t5);
t7=C_a_i_list(&a,1,t6);
/* compiler-syntax.scm:76: ##sys#append */
t8=*((C_word*)lf[75]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=((C_word*)t0)[9];
av2[2]=((C_word*)t0)[10];
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k3257 in k3129 in k3114 in k3387 in k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,3))){C_save_and_reclaim((void *)f_3259,2,av);}
a=C_alloc(27);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3213,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3215,a[2]=t6,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_3215(t12,t8,((C_word*)t0)[11]);}

/* k2063 in a2045 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2065(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_2065,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:274: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[36];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2066 in k2063 in a2045 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2068(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_2068,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm:275: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[48];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* g256 in k3129 in k3114 in k3387 in k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static C_word C_fcall f_3252(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2417 in k2421 in k2425 in k2429 in k2433 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2419(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_2419,2,av);}
a=C_alloc(12);
t2=C_a_i_cons(&a,2,lf[60],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2415,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* compiler-syntax.scm:141: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[23];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2413 in k2417 in k2421 in k2425 in k2429 in k2433 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2415(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_2415,2,av);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,lf[23],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* compiler-syntax.scm:141: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[16];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2409 in k2413 in k2417 in k2421 in k2425 in k2429 in k2433 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2411(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,4))){C_save_and_reclaim((void *)f_2411,2,av);}
a=C_alloc(24);
t2=C_a_i_cons(&a,2,lf[16],t1);
t3=C_a_i_list(&a,7,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],t2);
/* compiler-syntax.scm:141: r-c-s */
t4=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[8];
av2[2]=lf[65];
av2[3]=((C_word*)t0)[9];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* map-loop250 in k3129 in k3114 in k3387 in k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_fcall f_3261(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_3261,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_3252(C_a_i(&a,6),((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2425 in k2429 in k2433 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2427(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_2427,2,av);}
a=C_alloc(10);
t2=C_a_i_cons(&a,2,lf[17],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* compiler-syntax.scm:141: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[35];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2421 in k2425 in k2429 in k2433 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2423(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_2423,2,av);}
a=C_alloc(11);
t2=C_a_i_cons(&a,2,lf[35],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* compiler-syntax.scm:141: ##sys#primitive-alias */
t5=*((C_word*)lf[52]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[60];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1267 in k1263 in compiler-syntax-hook in k1256 in k1253 in k1250 */
static void C_ccall f_1269(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1269,2,av);}
t2=C_mutate2((C_word*)lf[0]+1 /* (set! ##compiler#compiler-syntax-statistics ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1263 in compiler-syntax-hook in k1256 in k1253 in k1250 */
static void C_ccall f_1265(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_1265,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1269,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_plus(&a,2,t1,C_fix(1));
/* compiler-syntax.scm:43: alist-update! */
t4=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=t3;
av2[4]=*((C_word*)lf[0]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2078 in k2075 in k2072 in k2069 in k2066 in k2063 in a2045 in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_2080(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(117,c,1))){C_save_and_reclaim((void *)f_2080,2,av);}
a=C_alloc(117);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[41],lf[53]);
t5=C_a_i_list(&a,3,lf[42],t1,t4);
t6=C_a_i_list(&a,2,lf[43],t5);
t7=C_a_i_list(&a,2,t1,t1);
t8=C_a_i_list(&a,1,t7);
t9=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t10=C_a_i_list(&a,3,lf[44],t1,C_fix(0));
t11=C_a_i_list(&a,3,lf[44],t1,C_fix(1));
t12=C_a_i_list(&a,3,lf[45],((C_word*)t0)[4],t11);
t13=C_a_i_list(&a,3,((C_word*)t0)[5],t10,t12);
t14=C_a_i_list(&a,4,((C_word*)t0)[6],t9,t13,((C_word*)t0)[7]);
t15=C_a_i_list(&a,4,((C_word*)t0)[8],((C_word*)t0)[4],t8,t14);
t16=((C_word*)t0)[9];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t16;
av2[1]=C_a_i_list(&a,4,((C_word*)t0)[10],t3,t6,t15);
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}

/* k3495 in k1256 in k1253 in k1250 */
static void C_ccall f_3497(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_3497,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,lf[48],t1);
t3=C_a_i_list(&a,1,t2);
/* compiler-syntax.scm:62: r-c-s */
t4=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[86];
av2[3]=((C_word*)t0)[3];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* ##compiler#r-c-s in k1256 in k1253 in k1250 */
static void C_ccall f_1275(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +9,c,2))){
C_save_and_reclaim((void*)f_1275,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+9);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_i_car(t4));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1317,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1325,a[2]=t2,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* compiler-syntax.scm:47: ##sys#er-transformer */
t10=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* skip in k1612 in loop in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_fcall f_1810(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_1810,3,t0,t1,t2);}
a=C_alloc(4);
if(C_truep(C_u_i_char_whitespacep(t2))){
t3=f_1472(((C_word*)((C_word*)t0)[2])[1]);
/* compiler-syntax.scm:260: skip */
t6=t1;
t7=t3;
t1=t6;
t2=t7;
goto loop;}
else{
t3=C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t3);
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_ccall f_1470(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_demand(C_calculate_demand(43,c,3))){C_save_and_reclaim((void *)f_1470,2,av);}
a=C_alloc(43);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t12=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1482,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp));
t13=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1501,a[2]=((C_word*)t0)[6],a[3]=t10,tmp=(C_word)a,a+=4,tmp));
t14=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1539,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp));
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=t8,a[10]=((C_word*)t0)[4],a[11]=((C_word*)t0)[5],a[12]=t4,a[13]=t16,a[14]=t10,a[15]=t6,a[16]=t2,a[17]=((C_word*)t0)[12],tmp=(C_word)a,a+=18,tmp));
t18=((C_word*)t16)[1];
f_1549(t18,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);}

/* fetch in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static C_word C_fcall f_1472(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_overflow_check;{}
t1=C_i_string_ref(((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t2=C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
return(t1);}

/* map-loop219 in k3114 in k3387 in k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_fcall f_3295(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_3295,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list2(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* next in k1468 in k1465 in k1462 in k1459 in k1384 in k1381 in a1360 in compile-format-string in k1351 in k1348 in k1345 in k1342 in k1339 in k1336 in k1256 in k1253 in k1250 */
static void C_fcall f_1482(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_1482,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
/* compiler-syntax.scm:208: fail */
t2=((C_word*)t0)[3];
f_1389(t2,t1,C_SCHEME_TRUE,lf[26],C_SCHEME_END_OF_LIST);}
else{
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k3483 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3485(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3485,2,av);}
t2=((C_word*)t0)[2];
f_3067(t2,C_i_greaterp(t1,C_fix(2)));}

/* g44 in k1319 in k1315 in r-c-s in k1256 in k1253 in k1250 */
static void C_fcall f_1283(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_1283,3,t0,t1,t2);}
/* compiler-syntax.scm:52: ##sys#put! */
t3=*((C_word*)lf[6]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[7];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* for-each-loop43 in k1319 in k1315 in r-c-s in k1256 in k1253 in k1250 */
static void C_fcall f_1292(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1292,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1302,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* compiler-syntax.scm:45: g44 */
t5=((C_word*)t0)[3];
f_1283(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* ##sys#compiler-syntax-hook in k1256 in k1253 in k1250 */
static void C_ccall f_1261(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,5))){C_save_and_reclaim((void *)f_1261,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1265,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* compiler-syntax.scm:41: alist-ref */
t5=*((C_word*)lf[3]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
av2[3]=*((C_word*)lf[0]+1);
av2[4]=*((C_word*)lf[4]+1);
av2[5]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}

/* k3387 in k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_ccall f_3389(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(35,c,3))){C_save_and_reclaim((void *)f_3389,2,av);}
a=C_alloc(35);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3096,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3101,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3116,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[4],a[9]=t4,a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3343,a[2]=t9,a[3]=t7,a[4]=t12,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_3343(t14,t10,((C_word*)t0)[12]);}

/* map-loop158 in k3079 in k3065 in k3056 in k3053 in k3050 in k3047 in k3044 in k3041 in k3038 in k3035 in k3032 in a3029 in k1256 in k1253 in k1250 */
static void C_fcall f_3391(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_3391,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list2(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[191] = {
{"f_2567:compiler_2dsyntax_2escm",(void*)f_2567},
{"f_1341:compiler_2dsyntax_2escm",(void*)f_1341},
{"f_1344:compiler_2dsyntax_2escm",(void*)f_1344},
{"f_1347:compiler_2dsyntax_2escm",(void*)f_1347},
{"f_2530:compiler_2dsyntax_2escm",(void*)f_2530},
{"f_1361:compiler_2dsyntax_2escm",(void*)f_1361},
{"f_2572:compiler_2dsyntax_2escm",(void*)f_2572},
{"f_1338:compiler_2dsyntax_2escm",(void*)f_1338},
{"f_2794:compiler_2dsyntax_2escm",(void*)f_2794},
{"f_1302:compiler_2dsyntax_2escm",(void*)f_1302},
{"f_2521:compiler_2dsyntax_2escm",(void*)f_2521},
{"f_1350:compiler_2dsyntax_2escm",(void*)f_1350},
{"f_1355:compiler_2dsyntax_2escm",(void*)f_1355},
{"f_1353:compiler_2dsyntax_2escm",(void*)f_1353},
{"f_2297:compiler_2dsyntax_2escm",(void*)f_2297},
{"f_2544:compiler_2dsyntax_2escm",(void*)f_2544},
{"f_1321:compiler_2dsyntax_2escm",(void*)f_1321},
{"f_1325:compiler_2dsyntax_2escm",(void*)f_1325},
{"f_2712:compiler_2dsyntax_2escm",(void*)f_2712},
{"f_2714:compiler_2dsyntax_2escm",(void*)f_2714},
{"f_2222:compiler_2dsyntax_2escm",(void*)f_2222},
{"f_2226:compiler_2dsyntax_2escm",(void*)f_2226},
{"f_2515:compiler_2dsyntax_2escm",(void*)f_2515},
{"f_2518:compiler_2dsyntax_2escm",(void*)f_2518},
{"f_2512:compiler_2dsyntax_2escm",(void*)f_2512},
{"f_2234:compiler_2dsyntax_2escm",(void*)f_2234},
{"f_2236:compiler_2dsyntax_2escm",(void*)f_2236},
{"f_2230:compiler_2dsyntax_2escm",(void*)f_2230},
{"f_2587:compiler_2dsyntax_2escm",(void*)f_2587},
{"f_2246:compiler_2dsyntax_2escm",(void*)f_2246},
{"f_1317:compiler_2dsyntax_2escm",(void*)f_1317},
{"f_1654:compiler_2dsyntax_2escm",(void*)f_1654},
{"f_2760:compiler_2dsyntax_2escm",(void*)f_2760},
{"f_2509:compiler_2dsyntax_2escm",(void*)f_2509},
{"f_2506:compiler_2dsyntax_2escm",(void*)f_2506},
{"f_2503:compiler_2dsyntax_2escm",(void*)f_2503},
{"f_2500:compiler_2dsyntax_2escm",(void*)f_2500},
{"f_3008:compiler_2dsyntax_2escm",(void*)f_3008},
{"f_2652:compiler_2dsyntax_2escm",(void*)f_2652},
{"f_2758:compiler_2dsyntax_2escm",(void*)f_2758},
{"f_2650:compiler_2dsyntax_2escm",(void*)f_2650},
{"f_2751:compiler_2dsyntax_2escm",(void*)f_2751},
{"f_2167:compiler_2dsyntax_2escm",(void*)f_2167},
{"f_2163:compiler_2dsyntax_2escm",(void*)f_2163},
{"f_2896:compiler_2dsyntax_2escm",(void*)f_2896},
{"f_2161:compiler_2dsyntax_2escm",(void*)f_2161},
{"f_2898:compiler_2dsyntax_2escm",(void*)f_2898},
{"f_1389:compiler_2dsyntax_2escm",(void*)f_1389},
{"f_1383:compiler_2dsyntax_2escm",(void*)f_1383},
{"f_1386:compiler_2dsyntax_2escm",(void*)f_1386},
{"f_1637:compiler_2dsyntax_2escm",(void*)f_1637},
{"f_1614:compiler_2dsyntax_2escm",(void*)f_1614},
{"f_2602:compiler_2dsyntax_2escm",(void*)f_2602},
{"f_1620:compiler_2dsyntax_2escm",(void*)f_1620},
{"f_3101:compiler_2dsyntax_2escm",(void*)f_3101},
{"f_3116:compiler_2dsyntax_2escm",(void*)f_3116},
{"f_1396:compiler_2dsyntax_2escm",(void*)f_1396},
{"f_1393:compiler_2dsyntax_2escm",(void*)f_1393},
{"f_1418:compiler_2dsyntax_2escm",(void*)f_1418},
{"f_1415:compiler_2dsyntax_2escm",(void*)f_1415},
{"f_1412:compiler_2dsyntax_2escm",(void*)f_1412},
{"f_1427:compiler_2dsyntax_2escm",(void*)f_1427},
{"f_1424:compiler_2dsyntax_2escm",(void*)f_1424},
{"f_1421:compiler_2dsyntax_2escm",(void*)f_1421},
{"f_2352:compiler_2dsyntax_2escm",(void*)f_2352},
{"f_1549:compiler_2dsyntax_2escm",(void*)f_1549},
{"f_3215:compiler_2dsyntax_2escm",(void*)f_3215},
{"f_3213:compiler_2dsyntax_2escm",(void*)f_3213},
{"f_2364:compiler_2dsyntax_2escm",(void*)f_2364},
{"f_1406:compiler_2dsyntax_2escm",(void*)f_1406},
{"f_2842:compiler_2dsyntax_2escm",(void*)f_2842},
{"f_1559:compiler_2dsyntax_2escm",(void*)f_1559},
{"f_1692:compiler_2dsyntax_2escm",(void*)f_1692},
{"f_1562:compiler_2dsyntax_2escm",(void*)f_1562},
{"f_3046:compiler_2dsyntax_2escm",(void*)f_3046},
{"f_3049:compiler_2dsyntax_2escm",(void*)f_3049},
{"f_3040:compiler_2dsyntax_2escm",(void*)f_3040},
{"f_3043:compiler_2dsyntax_2escm",(void*)f_3043},
{"f_1452:compiler_2dsyntax_2escm",(void*)f_1452},
{"f_2309:compiler_2dsyntax_2escm",(void*)f_2309},
{"f_2305:compiler_2dsyntax_2escm",(void*)f_2305},
{"f_1467:compiler_2dsyntax_2escm",(void*)f_1467},
{"f_2301:compiler_2dsyntax_2escm",(void*)f_2301},
{"f_3058:compiler_2dsyntax_2escm",(void*)f_3058},
{"f_1671:compiler_2dsyntax_2escm",(void*)f_1671},
{"f_3052:compiler_2dsyntax_2escm",(void*)f_3052},
{"f_1461:compiler_2dsyntax_2escm",(void*)f_1461},
{"f_3055:compiler_2dsyntax_2escm",(void*)f_3055},
{"f_1464:compiler_2dsyntax_2escm",(void*)f_1464},
{"f_1501:compiler_2dsyntax_2escm",(void*)f_1501},
{"f_1437:compiler_2dsyntax_2escm",(void*)f_1437},
{"f_2330:compiler_2dsyntax_2escm",(void*)f_2330},
{"f_1430:compiler_2dsyntax_2escm",(void*)f_1430},
{"f_1433:compiler_2dsyntax_2escm",(void*)f_1433},
{"f_1446:compiler_2dsyntax_2escm",(void*)f_1446},
{"f_1449:compiler_2dsyntax_2escm",(void*)f_1449},
{"f_2340:compiler_2dsyntax_2escm",(void*)f_2340},
{"f_1440:compiler_2dsyntax_2escm",(void*)f_1440},
{"f_1532:compiler_2dsyntax_2escm",(void*)f_1532},
{"f_1539:compiler_2dsyntax_2escm",(void*)f_1539},
{"f_3468:compiler_2dsyntax_2escm",(void*)f_3468},
{"f_2478:compiler_2dsyntax_2escm",(void*)f_2478},
{"f_1759:compiler_2dsyntax_2escm",(void*)f_1759},
{"f_2454:compiler_2dsyntax_2escm",(void*)f_2454},
{"f_1756:compiler_2dsyntax_2escm",(void*)f_1756},
{"f_3131:compiler_2dsyntax_2escm",(void*)f_3131},
{"f_2485:compiler_2dsyntax_2escm",(void*)f_2485},
{"f_2482:compiler_2dsyntax_2escm",(void*)f_2482},
{"f_2488:compiler_2dsyntax_2escm",(void*)f_2488},
{"f_2462:compiler_2dsyntax_2escm",(void*)f_2462},
{"f_1884:compiler_2dsyntax_2escm",(void*)f_1884},
{"f_1943:compiler_2dsyntax_2escm",(void*)f_1943},
{"f_1940:compiler_2dsyntax_2escm",(void*)f_1940},
{"f_1949:compiler_2dsyntax_2escm",(void*)f_1949},
{"f_1946:compiler_2dsyntax_2escm",(void*)f_1946},
{"f_1585:compiler_2dsyntax_2escm",(void*)f_1585},
{"f_2317:compiler_2dsyntax_2escm",(void*)f_2317},
{"f_2313:compiler_2dsyntax_2escm",(void*)f_2313},
{"f_1952:compiler_2dsyntax_2escm",(void*)f_1952},
{"f_3067:compiler_2dsyntax_2escm",(void*)f_3067},
{"f_1955:compiler_2dsyntax_2escm",(void*)f_1955},
{"f_2327:compiler_2dsyntax_2escm",(void*)f_2327},
{"f_2323:compiler_2dsyntax_2escm",(void*)f_2323},
{"f_2321:compiler_2dsyntax_2escm",(void*)f_2321},
{"f_1713:compiler_2dsyntax_2escm",(void*)f_1713},
{"f_3081:compiler_2dsyntax_2escm",(void*)f_3081},
{"f_3443:compiler_2dsyntax_2escm",(void*)f_3443},
{"f_1734:compiler_2dsyntax_2escm",(void*)f_1734},
{"f_2435:compiler_2dsyntax_2escm",(void*)f_2435},
{"f_3096:compiler_2dsyntax_2escm",(void*)f_3096},
{"f_2437:compiler_2dsyntax_2escm",(void*)f_2437},
{"f_2431:compiler_2dsyntax_2escm",(void*)f_2431},
{"f_1895:compiler_2dsyntax_2escm",(void*)f_1895},
{"f_2214:compiler_2dsyntax_2escm",(void*)f_2214},
{"f_2210:compiler_2dsyntax_2escm",(void*)f_2210},
{"f_1891:compiler_2dsyntax_2escm",(void*)f_1891},
{"f_2218:compiler_2dsyntax_2escm",(void*)f_2218},
{"f_1913:compiler_2dsyntax_2escm",(void*)f_1913},
{"f_3028:compiler_2dsyntax_2escm",(void*)f_3028},
{"f_2447:compiler_2dsyntax_2escm",(void*)f_2447},
{"f_3024:compiler_2dsyntax_2escm",(void*)f_3024},
{"f_1918:compiler_2dsyntax_2escm",(void*)f_1918},
{"f_1916:compiler_2dsyntax_2escm",(void*)f_1916},
{"f_1252:compiler_2dsyntax_2escm",(void*)f_1252},
{"f_1255:compiler_2dsyntax_2escm",(void*)f_1255},
{"f_3037:compiler_2dsyntax_2escm",(void*)f_3037},
{"f_3030:compiler_2dsyntax_2escm",(void*)f_3030},
{"f_3034:compiler_2dsyntax_2escm",(void*)f_3034},
{"f_2077:compiler_2dsyntax_2escm",(void*)f_2077},
{"f_1258:compiler_2dsyntax_2escm",(void*)f_1258},
{"f_2071:compiler_2dsyntax_2escm",(void*)f_2071},
{"f_2074:compiler_2dsyntax_2escm",(void*)f_2074},
{"f_1937:compiler_2dsyntax_2escm",(void*)f_1937},
{"f_2966:compiler_2dsyntax_2escm",(void*)f_2966},
{"f_2044:compiler_2dsyntax_2escm",(void*)f_2044},
{"f_2046:compiler_2dsyntax_2escm",(void*)f_2046},
{"f_2494:compiler_2dsyntax_2escm",(void*)f_2494},
{"f_2491:compiler_2dsyntax_2escm",(void*)f_2491},
{"f_2497:compiler_2dsyntax_2escm",(void*)f_2497},
{"f_2991:compiler_2dsyntax_2escm",(void*)f_2991},
{"f_3343:compiler_2dsyntax_2escm",(void*)f_3343},
{"toplevel:compiler_2dsyntax_2escm",(void*)C_compiler_2dsyntax_toplevel},
{"f_3169:compiler_2dsyntax_2escm",(void*)f_3169},
{"f_3167:compiler_2dsyntax_2escm",(void*)f_3167},
{"f_3259:compiler_2dsyntax_2escm",(void*)f_3259},
{"f_2065:compiler_2dsyntax_2escm",(void*)f_2065},
{"f_2068:compiler_2dsyntax_2escm",(void*)f_2068},
{"f_3252:compiler_2dsyntax_2escm",(void*)f_3252},
{"f_2419:compiler_2dsyntax_2escm",(void*)f_2419},
{"f_2415:compiler_2dsyntax_2escm",(void*)f_2415},
{"f_2411:compiler_2dsyntax_2escm",(void*)f_2411},
{"f_3261:compiler_2dsyntax_2escm",(void*)f_3261},
{"f_2427:compiler_2dsyntax_2escm",(void*)f_2427},
{"f_2423:compiler_2dsyntax_2escm",(void*)f_2423},
{"f_1269:compiler_2dsyntax_2escm",(void*)f_1269},
{"f_1265:compiler_2dsyntax_2escm",(void*)f_1265},
{"f_2080:compiler_2dsyntax_2escm",(void*)f_2080},
{"f_3497:compiler_2dsyntax_2escm",(void*)f_3497},
{"f_1275:compiler_2dsyntax_2escm",(void*)f_1275},
{"f_1810:compiler_2dsyntax_2escm",(void*)f_1810},
{"f_1470:compiler_2dsyntax_2escm",(void*)f_1470},
{"f_1472:compiler_2dsyntax_2escm",(void*)f_1472},
{"f_3295:compiler_2dsyntax_2escm",(void*)f_3295},
{"f_1482:compiler_2dsyntax_2escm",(void*)f_1482},
{"f_3485:compiler_2dsyntax_2escm",(void*)f_3485},
{"f_1283:compiler_2dsyntax_2escm",(void*)f_1283},
{"f_1292:compiler_2dsyntax_2escm",(void*)f_1292},
{"f_1261:compiler_2dsyntax_2escm",(void*)f_1261},
{"f_3389:compiler_2dsyntax_2escm",(void*)f_3389},
{"f_3391:compiler_2dsyntax_2escm",(void*)f_3391},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  sprintf		2
S|  map		14
S|  for-each		1
o|eliminated procedure checks: 220 
o|specializations:
o|  11 (eqv? (not float) *)
o|  1 (= fixnum fixnum)
o|  2 (##sys#check-output-port * * *)
o|  3 (car pair)
o|  1 (cddr (pair * pair))
o|  2 (>= fixnum fixnum)
o|  2 (cdr pair)
o|  1 (memq * list)
o|  15 (##sys#check-list (or pair list) *)
(o e)|safe calls: 330 
o|safe globals: (##compiler#r-c-s ##sys#compiler-syntax-hook ##compiler#compiler-syntax-statistics) 
o|inlining procedure: k1294 
o|inlining procedure: k1294 
o|inlining procedure: k1363 
o|merged explicitly consed rest parameter: args663 
o|inlining procedure: k1397 
o|inlining procedure: k1397 
o|substituted constant variable: a1408 
o|substituted constant variable: a1409 
o|substituted constant variable: a1442 
o|substituted constant variable: a1443 
o|inlining procedure: k1435 
o|inlining procedure: k1435 
o|inlining procedure: k1484 
o|consed rest parameter at call site: "(compiler-syntax.scm:208) fail660" 3 
o|inlining procedure: k1484 
o|inlining procedure: k1503 
o|inlining procedure: k1513 
o|inlining procedure: k1513 
o|substituted constant variable: a1533 
o|inlining procedure: k1503 
o|inlining procedure: k1375 
o|inlining procedure: k1551 
o|consed rest parameter at call site: "(compiler-syntax.scm:223) fail660" 3 
o|inlining procedure: k1551 
o|inlining procedure: k1618 
o|inlining procedure: k1618 
o|inlining procedure: k1655 
o|inlining procedure: k1655 
o|inlining procedure: k1693 
o|inlining procedure: k1693 
o|inlining procedure: k1735 
o|inlining procedure: k1735 
o|inlining procedure: k1767 
o|inlining procedure: k1767 
o|inlining procedure: k1796 
o|inlining procedure: k1812 
o|inlining procedure: k1812 
o|inlining procedure: k1796 
o|consed rest parameter at call site: "(compiler-syntax.scm:262) fail660" 3 
o|substituted constant variable: a1836 
o|substituted constant variable: a1838 
o|substituted constant variable: a1840 
o|substituted constant variable: a1842 
o|substituted constant variable: a1844 
o|substituted constant variable: a1846 
o|substituted constant variable: a1848 
o|substituted constant variable: a1850 
o|substituted constant variable: a1852 
o|substituted constant variable: a1854 
o|substituted constant variable: a1856 
o|inlining procedure: k1375 
o|inlining procedure: k1873 
o|inlining procedure: k1873 
o|inlining procedure: k1363 
o|substituted constant variable: a1910 
o|inlining procedure: k1920 
o|inlining procedure: k1920 
o|inlining procedure: k2048 
o|inlining procedure: k2048 
o|inlining procedure: k2168 
o|inlining procedure: k2168 
o|inlining procedure: k2238 
o|inlining procedure: k2238 
o|substituted constant variable: a2261 
o|inlining procedure: k2331 
o|inlining procedure: k2331 
o|substituted constant variable: a2375 
o|inlining procedure: k2439 
o|inlining procedure: k2439 
o|inlining procedure: k2525 
o|inlining procedure: k2654 
o|contracted procedure: "(compiler-syntax.scm:130) g556565" 
o|inlining procedure: k2654 
o|inlining procedure: k2716 
o|contracted procedure: "(compiler-syntax.scm:124) g526535" 
o|inlining procedure: k2716 
o|inlining procedure: k2762 
o|inlining procedure: k2762 
o|inlining procedure: k2796 
o|inlining procedure: k2796 
o|inlining procedure: k2844 
o|inlining procedure: k2844 
o|inlining procedure: k2900 
o|inlining procedure: k2900 
o|inlining procedure: k2968 
o|contracted procedure: "(compiler-syntax.scm:111) g374383" 
o|inlining procedure: k2968 
o|inlining procedure: k2525 
o|inlining procedure: k3062 
o|inlining procedure: k3171 
o|contracted procedure: "(compiler-syntax.scm:89) g316325" 
o|inlining procedure: k3171 
o|inlining procedure: k3217 
o|contracted procedure: "(compiler-syntax.scm:86) g286295" 
o|inlining procedure: k3217 
o|inlining procedure: k3263 
o|inlining procedure: k3263 
o|inlining procedure: k3297 
o|inlining procedure: k3297 
o|inlining procedure: k3345 
o|inlining procedure: k3345 
o|inlining procedure: k3393 
o|inlining procedure: k3393 
o|inlining procedure: k3445 
o|contracted procedure: "(compiler-syntax.scm:76) g134143" 
o|inlining procedure: k3445 
o|inlining procedure: k3062 
o|simplifications: ((if . 1)) 
o|replaced variables: 353 
o|removed binding forms: 126 
o|substituted constant variable: r14363505 
o|substituted constant variable: r14363505 
o|converted assignments to bindings: (fail660) 
o|substituted constant variable: r13763540 
o|substituted constant variable: r18743542 
o|substituted constant variable: r13643543 
o|simplifications: ((let . 1)) 
o|replaced variables: 2 
o|removed binding forms: 383 
o|replaced variables: 12 
o|removed binding forms: 7 
o|removed binding forms: 11 
o|simplifications: ((if . 11) (##core#call . 340)) 
o|  call simplifications:
o|    cddr	2
o|    >	2
o|    ##sys#check-list	4
o|    list	4
o|    ##sys#setslot	14
o|    fx>
o|    fx=	2
o|    cadr	5
o|    caddr	2
o|    cadddr	2
o|    fx>=	2
o|    memq	6
o|    list?
o|    caar
o|    string?	3
o|    string-length
o|    >=
o|    char-upcase
o|    char-whitespace?	2
o|    sub1
o|    ##sys#cons	44
o|    length	6
o|    eq?	13
o|    ##sys#list	101
o|    cdr	3
o|    string-ref
o|    fx+
o|    ##sys#apply
o|    null?	3
o|    car	6
o|    cons	31
o|    pair?	20
o|    ##sys#slot	52
o|    add1
o|contracted procedure: k1271 
o|contracted procedure: k1330 
o|contracted procedure: k1277 
o|contracted procedure: k1280 
o|contracted procedure: k1297 
o|contracted procedure: k1307 
o|contracted procedure: k1311 
o|contracted procedure: k1327 
o|contracted procedure: k1907 
o|contracted procedure: k1366 
o|contracted procedure: k1372 
o|contracted procedure: k1903 
o|contracted procedure: k1378 
o|contracted procedure: k1456 
o|contracted procedure: k1474 
o|contracted procedure: k1478 
o|contracted procedure: k1487 
o|contracted procedure: k1493 
o|contracted procedure: k1497 
o|contracted procedure: k1506 
o|contracted procedure: k1535 
o|contracted procedure: k1516 
o|contracted procedure: k1523 
o|inlining procedure: k1513 
o|inlining procedure: k1513 
o|contracted procedure: k1542 
o|contracted procedure: k1554 
o|contracted procedure: k1591 
o|contracted procedure: k1571 
o|contracted procedure: k1587 
o|contracted procedure: k1579 
o|contracted procedure: k1575 
o|contracted procedure: k1567 
o|contracted procedure: k1594 
o|contracted procedure: k1606 
o|contracted procedure: k1615 
o|contracted procedure: k1624 
o|contracted procedure: k1631 
o|contracted procedure: k1641 
o|contracted procedure: k1648 
o|contracted procedure: k1658 
o|contracted procedure: k1665 
o|contracted procedure: k1675 
o|contracted procedure: k1686 
o|contracted procedure: k1682 
o|contracted procedure: k1696 
o|contracted procedure: k1707 
o|contracted procedure: k1703 
o|contracted procedure: k1717 
o|contracted procedure: k1728 
o|contracted procedure: k1724 
o|contracted procedure: k1738 
o|contracted procedure: k1745 
o|contracted procedure: k1751 
o|contracted procedure: k1764 
o|contracted procedure: k1770 
o|contracted procedure: k1777 
o|contracted procedure: k1783 
o|contracted procedure: k1786 
o|contracted procedure: k1793 
o|contracted procedure: k1799 
o|contracted procedure: k1815 
o|contracted procedure: k1826 
o|contracted procedure: k1861 
o|contracted procedure: k1864 
o|contracted procedure: k1876 
o|contracted procedure: k1897 
o|contracted procedure: k2030 
o|contracted procedure: k2023 
o|contracted procedure: k1923 
o|contracted procedure: k1926 
o|contracted procedure: k1929 
o|contracted procedure: k1932 
o|contracted procedure: k2016 
o|contracted procedure: k2020 
o|contracted procedure: k1960 
o|contracted procedure: k2012 
o|contracted procedure: k2008 
o|contracted procedure: k1964 
o|contracted procedure: k2000 
o|contracted procedure: k2004 
o|contracted procedure: k1972 
o|contracted procedure: k1980 
o|contracted procedure: k1988 
o|contracted procedure: k1996 
o|contracted procedure: k1992 
o|contracted procedure: k1984 
o|contracted procedure: k1976 
o|contracted procedure: k1968 
o|contracted procedure: k2038 
o|contracted procedure: k2034 
o|contracted procedure: k2147 
o|contracted procedure: k2140 
o|contracted procedure: k2051 
o|contracted procedure: k2054 
o|contracted procedure: k2057 
o|contracted procedure: k2060 
o|contracted procedure: k2137 
o|contracted procedure: k2085 
o|contracted procedure: k2133 
o|contracted procedure: k2129 
o|contracted procedure: k2089 
o|contracted procedure: k2125 
o|contracted procedure: k2097 
o|contracted procedure: k2105 
o|contracted procedure: k2113 
o|contracted procedure: k2121 
o|contracted procedure: k2117 
o|contracted procedure: k2109 
o|contracted procedure: k2101 
o|contracted procedure: k2093 
o|contracted procedure: k2155 
o|contracted procedure: k2151 
o|contracted procedure: k2172 
o|contracted procedure: k2180 
o|contracted procedure: k2184 
o|contracted procedure: k2188 
o|contracted procedure: k2192 
o|contracted procedure: k2196 
o|contracted procedure: k2200 
o|contracted procedure: k2204 
o|contracted procedure: k2176 
o|contracted procedure: k2258 
o|contracted procedure: k2241 
o|contracted procedure: k2251 
o|contracted procedure: k2267 
o|contracted procedure: k2271 
o|contracted procedure: k2275 
o|contracted procedure: k2279 
o|contracted procedure: k2283 
o|contracted procedure: k2287 
o|contracted procedure: k2291 
o|contracted procedure: k2263 
o|contracted procedure: k2358 
o|contracted procedure: k2354 
o|contracted procedure: k2342 
o|contracted procedure: k2346 
o|contracted procedure: k2372 
o|contracted procedure: k2366 
o|contracted procedure: k2381 
o|contracted procedure: k2385 
o|contracted procedure: k2389 
o|contracted procedure: k2393 
o|contracted procedure: k2397 
o|contracted procedure: k2401 
o|contracted procedure: k2405 
o|contracted procedure: k2377 
o|contracted procedure: k2474 
o|contracted procedure: k2467 
o|contracted procedure: k2442 
o|contracted procedure: k2456 
o|contracted procedure: k2464 
o|contracted procedure: k2522 
o|contracted procedure: k2531 
o|contracted procedure: k2539 
o|contracted procedure: k2958 
o|contracted procedure: k2962 
o|contracted procedure: k2954 
o|contracted procedure: k2950 
o|contracted procedure: k2549 
o|contracted procedure: k2876 
o|contracted procedure: k2946 
o|contracted procedure: k2884 
o|contracted procedure: k2888 
o|contracted procedure: k2891 
o|contracted procedure: k2880 
o|contracted procedure: k2561 
o|contracted procedure: k2557 
o|contracted procedure: k2553 
o|contracted procedure: k2569 
o|contracted procedure: k2582 
o|contracted procedure: k2578 
o|contracted procedure: k2597 
o|contracted procedure: k2748 
o|contracted procedure: k2608 
o|contracted procedure: k2702 
o|contracted procedure: k2694 
o|contracted procedure: k2698 
o|contracted procedure: k2690 
o|contracted procedure: k2686 
o|contracted procedure: k2620 
o|contracted procedure: k2624 
o|contracted procedure: k2628 
o|contracted procedure: k2640 
o|contracted procedure: k2636 
o|contracted procedure: k2632 
o|contracted procedure: k2612 
o|contracted procedure: k2616 
o|contracted procedure: k2604 
o|contracted procedure: k2593 
o|contracted procedure: k2589 
o|contracted procedure: k2657 
o|contracted procedure: k2679 
o|contracted procedure: k2675 
o|contracted procedure: k2660 
o|contracted procedure: k2663 
o|contracted procedure: k2671 
o|contracted procedure: k2719 
o|contracted procedure: k2741 
o|contracted procedure: k2737 
o|contracted procedure: k2722 
o|contracted procedure: k2725 
o|contracted procedure: k2733 
o|contracted procedure: k2765 
o|contracted procedure: k2768 
o|contracted procedure: k2771 
o|contracted procedure: k2779 
o|contracted procedure: k2787 
o|contracted procedure: k2835 
o|contracted procedure: k2799 
o|contracted procedure: k2825 
o|contracted procedure: k2829 
o|contracted procedure: k2821 
o|contracted procedure: k2802 
o|contracted procedure: k2805 
o|contracted procedure: k2813 
o|contracted procedure: k2817 
o|contracted procedure: k2847 
o|contracted procedure: k2850 
o|contracted procedure: k2853 
o|contracted procedure: k2861 
o|contracted procedure: k2869 
o|contracted procedure: k2939 
o|contracted procedure: k2903 
o|contracted procedure: k2929 
o|contracted procedure: k2933 
o|contracted procedure: k2925 
o|contracted procedure: k2906 
o|contracted procedure: k2909 
o|contracted procedure: k2917 
o|contracted procedure: k2921 
o|contracted procedure: k2971 
o|contracted procedure: k2974 
o|contracted procedure: k2977 
o|contracted procedure: k2985 
o|contracted procedure: k2993 
o|contracted procedure: k2999 
o|contracted procedure: k3014 
o|contracted procedure: k3018 
o|contracted procedure: k3010 
o|contracted procedure: k3059 
o|contracted procedure: k3068 
o|contracted procedure: k3076 
o|contracted procedure: k3439 
o|contracted procedure: k3377 
o|contracted procedure: k3381 
o|contracted procedure: k3384 
o|contracted procedure: k3090 
o|contracted procedure: k3086 
o|contracted procedure: k3098 
o|contracted procedure: k3111 
o|contracted procedure: k3107 
o|contracted procedure: k3126 
o|contracted procedure: k3249 
o|contracted procedure: k3137 
o|contracted procedure: k3203 
o|contracted procedure: k3145 
o|contracted procedure: k3157 
o|contracted procedure: k3153 
o|contracted procedure: k3149 
o|contracted procedure: k3141 
o|contracted procedure: k3133 
o|contracted procedure: k3122 
o|contracted procedure: k3118 
o|contracted procedure: k3174 
o|contracted procedure: k3196 
o|contracted procedure: k3192 
o|contracted procedure: k3177 
o|contracted procedure: k3180 
o|contracted procedure: k3188 
o|contracted procedure: k3220 
o|contracted procedure: k3242 
o|contracted procedure: k3238 
o|contracted procedure: k3223 
o|contracted procedure: k3226 
o|contracted procedure: k3234 
o|contracted procedure: k3266 
o|contracted procedure: k3269 
o|contracted procedure: k3272 
o|contracted procedure: k3280 
o|contracted procedure: k3288 
o|contracted procedure: k3336 
o|contracted procedure: k3300 
o|contracted procedure: k3326 
o|contracted procedure: k3330 
o|contracted procedure: k3322 
o|contracted procedure: k3303 
o|contracted procedure: k3306 
o|contracted procedure: k3314 
o|contracted procedure: k3318 
o|contracted procedure: k3348 
o|contracted procedure: k3351 
o|contracted procedure: k3354 
o|contracted procedure: k3362 
o|contracted procedure: k3370 
o|contracted procedure: k3432 
o|contracted procedure: k3396 
o|contracted procedure: k3422 
o|contracted procedure: k3426 
o|contracted procedure: k3418 
o|contracted procedure: k3399 
o|contracted procedure: k3402 
o|contracted procedure: k3410 
o|contracted procedure: k3414 
o|contracted procedure: k3448 
o|contracted procedure: k3451 
o|contracted procedure: k3454 
o|contracted procedure: k3462 
o|contracted procedure: k3470 
o|contracted procedure: k3476 
o|contracted procedure: k3491 
o|contracted procedure: k3487 
o|simplifications: ((let . 32)) 
o|removed binding forms: 310 
o|replaced variables: 86 
o|removed binding forms: 1 
o|removed binding forms: 52 
o|direct leaf routine/allocation: fetch703 0 
o|direct leaf routine/allocation: push706 3 
o|direct leaf routine/allocation: g435444 21 
o|direct leaf routine/allocation: g496505 6 
o|direct leaf routine/allocation: g195204 21 
o|direct leaf routine/allocation: g256265 6 
o|contracted procedure: "(compiler-syntax.scm:229) k1600" 
o|contracted procedure: "(compiler-syntax.scm:231) k1609" 
o|inlining procedure: "(compiler-syntax.scm:234) k1618" 
o|inlining procedure: "(compiler-syntax.scm:235) k1618" 
o|inlining procedure: "(compiler-syntax.scm:236) k1618" 
o|inlining procedure: "(compiler-syntax.scm:238) k1618" 
o|inlining procedure: "(compiler-syntax.scm:242) k1618" 
o|inlining procedure: "(compiler-syntax.scm:246) k1618" 
o|inlining procedure: "(compiler-syntax.scm:249) k1618" 
o|inlining procedure: "(compiler-syntax.scm:253) k1618" 
o|inlining procedure: "(compiler-syntax.scm:254) k1618" 
o|inlining procedure: "(compiler-syntax.scm:255) k1618" 
o|contracted procedure: "(compiler-syntax.scm:258) k1806" 
o|contracted procedure: "(compiler-syntax.scm:260) k1822" 
o|contracted procedure: "(compiler-syntax.scm:120) k2783" 
o|contracted procedure: "(compiler-syntax.scm:116) k2865" 
o|contracted procedure: "(compiler-syntax.scm:83) k3284" 
o|contracted procedure: "(compiler-syntax.scm:79) k3366" 
o|removed binding forms: 8 
o|customizable procedures: (k3065 map-loop128146 map-loop158177 map-loop189210 map-loop219238 map-loop250271 map-loop280301 map-loop310331 k2528 map-loop368386 map-loop398417 map-loop429450 map-loop459478 map-loop490511 map-loop520541 map-loop550571 k1381 skip773 next704 loop719 endchunk705 fail660 g4451 for-each-loop4354) 
o|calls to known targets: 69 
o|identified direct recursive calls: f_1810 1 
o|identified direct recursive calls: f_1549 1 
o|identified direct recursive calls: f_2652 1 
o|identified direct recursive calls: f_2714 1 
o|identified direct recursive calls: f_2760 1 
o|identified direct recursive calls: f_2794 1 
o|identified direct recursive calls: f_2842 1 
o|identified direct recursive calls: f_2898 1 
o|identified direct recursive calls: f_3169 1 
o|identified direct recursive calls: f_3215 1 
o|identified direct recursive calls: f_3261 1 
o|identified direct recursive calls: f_3295 1 
o|identified direct recursive calls: f_3343 1 
o|identified direct recursive calls: f_3391 1 
o|fast box initializations: 21 
*/
/* end of file */
