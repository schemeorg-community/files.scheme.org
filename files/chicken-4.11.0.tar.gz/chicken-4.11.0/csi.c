/* Generated from csi.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:51
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: csi.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -local -no-trace -output-file csi.c
   used units: library eval chicken_2dsyntax ports extras
*/

#include "chicken.h"

#include <signal.h>

#if defined(HAVE_DIRECT_H)
# include <direct.h>
#else
# define _getcwd(buf, len)       NULL
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[405];
static double C_possibly_force_alignment;


/* from k2057 */
C_regparm static C_word C_fcall stub63(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mpointer(&C_a,(void*)_getcwd(t0,t1));
return C_r;}

C_noret_decl(f_5773)
static void C_ccall f_5773(C_word c,C_word *av) C_noret;
C_noret_decl(f_5779)
static void C_fcall f_5779(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5034)
static void C_fcall f_5034(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5703)
static void C_fcall f_5703(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6600)
static void C_ccall f_6600(C_word c,C_word *av) C_noret;
C_noret_decl(f_5795)
static void C_fcall f_5795(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5793)
static void C_ccall f_5793(C_word c,C_word *av) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word *av) C_noret;
C_noret_decl(f_3349)
static void C_fcall f_3349(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6678)
static void C_ccall f_6678(C_word c,C_word *av) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word *av) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word *av) C_noret;
C_noret_decl(f_2394)
static C_word C_fcall f_2394(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word *av) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word *av) C_noret;
C_noret_decl(f_3987)
static void C_ccall f_3987(C_word c,C_word *av) C_noret;
C_noret_decl(f_5748)
static void C_ccall f_5748(C_word c,C_word *av) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word *av) C_noret;
C_noret_decl(f_6836)
static void C_ccall f_6836(C_word c,C_word *av) C_noret;
C_noret_decl(f_6698)
static void C_ccall f_6698(C_word c,C_word *av) C_noret;
C_noret_decl(f_6692)
static void C_ccall f_6692(C_word c,C_word *av) C_noret;
C_noret_decl(f_6695)
static void C_ccall f_6695(C_word c,C_word *av) C_noret;
C_noret_decl(f_5310)
static void C_ccall f_5310(C_word c,C_word *av) C_noret;
C_noret_decl(f_5313)
static void C_ccall f_5313(C_word c,C_word *av) C_noret;
C_noret_decl(f_6686)
static void C_ccall f_6686(C_word c,C_word *av) C_noret;
C_noret_decl(f_5316)
static void C_ccall f_5316(C_word c,C_word *av) C_noret;
C_noret_decl(f_5319)
static void C_ccall f_5319(C_word c,C_word *av) C_noret;
C_noret_decl(f_6682)
static void C_ccall f_6682(C_word c,C_word *av) C_noret;
C_noret_decl(f_3142)
static void C_fcall f_3142(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word *av) C_noret;
C_noret_decl(f_5322)
static void C_ccall f_5322(C_word c,C_word *av) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word *av) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word *av) C_noret;
C_noret_decl(f_3138)
static void C_ccall f_3138(C_word c,C_word *av) C_noret;
C_noret_decl(f_6824)
static void C_ccall f_6824(C_word c,C_word *av) C_noret;
C_noret_decl(f_6820)
static void C_ccall f_6820(C_word c,C_word *av) C_noret;
C_noret_decl(f_6827)
static void C_fcall f_6827(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3124)
static void C_ccall f_3124(C_word c,C_word *av) C_noret;
C_noret_decl(f_3509)
static void C_fcall f_3509(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3504)
static void C_ccall f_3504(C_word c,C_word *av) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word *av) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word *av) C_noret;
C_noret_decl(f_6855)
static void C_fcall f_6855(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6072)
static void C_ccall f_6072(C_word c,C_word *av) C_noret;
C_noret_decl(f_5358)
static void C_ccall f_5358(C_word c,C_word *av) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word *av) C_noret;
C_noret_decl(f_6885)
static void C_ccall f_6885(C_word c,C_word *av) C_noret;
C_noret_decl(f_4141)
static void C_ccall f_4141(C_word c,C_word *av) C_noret;
C_noret_decl(f_6883)
static void C_ccall f_6883(C_word c,C_word *av) C_noret;
C_noret_decl(f_5365)
static void C_ccall f_5365(C_word c,C_word *av) C_noret;
C_noret_decl(f_5367)
static void C_fcall f_5367(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6200)
static void C_ccall f_6200(C_word c,C_word *av) C_noret;
C_noret_decl(f_6203)
static void C_ccall f_6203(C_word c,C_word *av) C_noret;
C_noret_decl(f_6218)
static void C_ccall f_6218(C_word c,C_word *av) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word *av) C_noret;
C_noret_decl(f_5377)
static void C_ccall f_5377(C_word c,C_word *av) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206(C_word c,C_word *av) C_noret;
C_noret_decl(f_6209)
static void C_ccall f_6209(C_word c,C_word *av) C_noret;
C_noret_decl(f_6080)
static void C_ccall f_6080(C_word c,C_word *av) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word *av) C_noret;
C_noret_decl(f_6082)
static void C_ccall f_6082(C_word c,C_word *av) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word *av) C_noret;
C_noret_decl(f_3704)
static void C_ccall f_3704(C_word c,C_word *av) C_noret;
C_noret_decl(f_6896)
static void C_ccall f_6896(C_word c,C_word *av) C_noret;
C_noret_decl(f_6893)
static void C_ccall f_6893(C_word c,C_word *av) C_noret;
C_noret_decl(f_5554)
static void C_fcall f_5554(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word *av) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word *av) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word *av) C_noret;
C_noret_decl(f_6061)
static void C_ccall f_6061(C_word c,C_word *av) C_noret;
C_noret_decl(f_6757)
static void C_ccall f_6757(C_word c,C_word *av) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word *av) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word *av) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word *av) C_noret;
C_noret_decl(f_6777)
static void C_ccall f_6777(C_word c,C_word *av) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word *av) C_noret;
C_noret_decl(f_6416)
static void C_fcall f_6416(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021(C_word c,C_word *av) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word *av) C_noret;
C_noret_decl(f_3262)
static void C_ccall f_3262(C_word c,C_word *av) C_noret;
C_noret_decl(f_6765)
static void C_ccall f_6765(C_word c,C_word *av) C_noret;
C_noret_decl(f_6403)
static void C_ccall f_6403(C_word c,C_word *av) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word *av) C_noret;
C_noret_decl(f_6712)
static void C_ccall f_6712(C_word c,C_word *av) C_noret;
C_noret_decl(f_2232)
static void C_fcall f_2232(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6700)
static void C_ccall f_6700(C_word c,C_word *av) C_noret;
C_noret_decl(f_3554)
static void C_ccall f_3554(C_word c,C_word *av) C_noret;
C_noret_decl(f_6708)
static void C_ccall f_6708(C_word c,C_word *av) C_noret;
C_noret_decl(f_3551)
static void C_ccall f_3551(C_word c,C_word *av) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word *av) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word *av) C_noret;
C_noret_decl(f_3541)
static void C_fcall f_3541(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word *av) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word *av) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word *av) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word *av) C_noret;
C_noret_decl(f_6724)
static void C_fcall f_6724(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word *av) C_noret;
C_noret_decl(f_2222)
static void C_fcall f_2222(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6449)
static void C_ccall f_6449(C_word c,C_word *av) C_noret;
C_noret_decl(f_4608)
static void C_fcall f_4608(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6439)
static void C_fcall f_6439(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word *av) C_noret;
C_noret_decl(f_6497)
static void C_ccall f_6497(C_word c,C_word *av) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word *av) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word *av) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word *av) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word *av) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word *av) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word *av) C_noret;
C_noret_decl(f_6484)
static void C_ccall f_6484(C_word c,C_word *av) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word *av) C_noret;
C_noret_decl(f_3101)
static void C_fcall f_3101(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word *av) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word *av) C_noret;
C_noret_decl(f_6478)
static void C_ccall f_6478(C_word c,C_word *av) C_noret;
C_noret_decl(f_4715)
static void C_fcall f_4715(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4613)
static void C_fcall f_4613(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word *av) C_noret;
C_noret_decl(f_6469)
static void C_ccall f_6469(C_word c,C_word *av) C_noret;
C_noret_decl(f_6149)
static void C_ccall f_6149(C_word c,C_word *av) C_noret;
C_noret_decl(f_6466)
static void C_ccall f_6466(C_word c,C_word *av) C_noret;
C_noret_decl(f_6463)
static void C_ccall f_6463(C_word c,C_word *av) C_noret;
C_noret_decl(f_4766)
static void C_fcall f_4766(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word *av) C_noret;
C_noret_decl(f_4408)
static void C_ccall f_4408(C_word c,C_word *av) C_noret;
C_noret_decl(f_4681)
static void C_fcall f_4681(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word *av) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word *av) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word *av) C_noret;
C_noret_decl(f_3286)
static void C_ccall f_3286(C_word c,C_word *av) C_noret;
C_noret_decl(f_6112)
static void C_ccall f_6112(C_word c,C_word *av) C_noret;
C_noret_decl(f_3282)
static void C_ccall f_3282(C_word c,C_word *av) C_noret;
C_noret_decl(f_6230)
static void C_ccall f_6230(C_word c,C_word *av) C_noret;
C_noret_decl(f_2748)
static void C_ccall f_2748(C_word c,C_word *av) C_noret;
C_noret_decl(f_5900)
static void C_ccall f_5900(C_word c,C_word *av) C_noret;
C_noret_decl(f_5908)
static void C_fcall f_5908(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5903)
static void C_fcall f_5903(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2921)
static void C_ccall f_2921(C_word c,C_word *av) C_noret;
C_noret_decl(f_3278)
static void C_ccall f_3278(C_word c,C_word *av) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274(C_word c,C_word *av) C_noret;
C_noret_decl(f_6221)
static void C_ccall f_6221(C_word c,C_word *av) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word *av) C_noret;
C_noret_decl(f_4263)
static void C_ccall f_4263(C_word c,C_word *av) C_noret;
C_noret_decl(f_4264)
static void C_fcall f_4264(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6233)
static void C_ccall f_6233(C_word c,C_word *av) C_noret;
C_noret_decl(f_4277)
static void C_fcall f_4277(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5921)
static void C_ccall f_5921(C_word c,C_word *av) C_noret;
C_noret_decl(f_5929)
static void C_ccall f_5929(C_word c,C_word *av) C_noret;
C_noret_decl(f_5926)
static void C_ccall f_5926(C_word c,C_word *av) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word *av) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word *av) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word *av) C_noret;
C_noret_decl(f_5974)
static void C_ccall f_5974(C_word c,C_word *av) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word *av) C_noret;
C_noret_decl(f_4648)
static void C_fcall f_4648(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4414)
static void C_fcall f_4414(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4691)
static void C_ccall f_4691(C_word c,C_word *av) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word *av) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word *av) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word *av) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word *av) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word *av) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word *av) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word *av) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word *av) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word *av) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word *av) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word *av) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word *av) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word *av) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word *av) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word *av) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word *av) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word *av) C_noret;
C_noret_decl(f_4886)
static void C_fcall f_4886(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2777)
static void C_ccall f_2777(C_word c,C_word *av) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word *av) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word *av) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word *av) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word *av) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word *av) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423(C_word c,C_word *av) C_noret;
C_noret_decl(f_5988)
static void C_ccall f_5988(C_word c,C_word *av) C_noret;
C_noret_decl(f_5428)
static void C_fcall f_5428(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word *av) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word *av) C_noret;
C_noret_decl(f_5601)
static void C_ccall f_5601(C_word c,C_word *av) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word *av) C_noret;
C_noret_decl(f_5483)
static void C_fcall f_5483(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5489)
static void C_fcall f_5489(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4491)
static void C_ccall f_4491(C_word c,C_word *av) C_noret;
C_noret_decl(f_2064)
static void C_fcall f_2064(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word *av) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word *av) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word *av) C_noret;
C_noret_decl(f_5434)
static void C_fcall f_5434(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5273)
static void C_ccall f_5273(C_word c,C_word *av) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word *av) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word *av) C_noret;
C_noret_decl(f_4651)
static void C_fcall f_4651(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word *av) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word *av) C_noret;
C_noret_decl(f_6136)
static void C_fcall f_6136(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5683)
static void C_ccall f_5683(C_word c,C_word *av) C_noret;
C_noret_decl(f_5686)
static void C_fcall f_5686(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5680)
static void C_fcall f_5680(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6131)
static void C_ccall f_6131(C_word c,C_word *av) C_noret;
C_noret_decl(f_6128)
static void C_ccall f_6128(C_word c,C_word *av) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word *av) C_noret;
C_noret_decl(f_5695)
static void C_ccall f_5695(C_word c,C_word *av) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692(C_word c,C_word *av) C_noret;
C_noret_decl(f_2093)
static void C_fcall f_2093(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word *av) C_noret;
C_noret_decl(f_5697)
static void C_fcall f_5697(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word *av) C_noret;
C_noret_decl(f_3803)
static void C_fcall f_3803(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6152)
static void C_ccall f_6152(C_word c,C_word *av) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word *av) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word *av) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word *av) C_noret;
C_noret_decl(f_5674)
static void C_fcall f_5674(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677(C_word c,C_word *av) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word *av) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word *av) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word *av) C_noret;
C_noret_decl(f_5446)
static void C_fcall f_5446(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word *av) C_noret;
C_noret_decl(f_3819)
static void C_ccall f_3819(C_word c,C_word *av) C_noret;
C_noret_decl(f_3813)
static void C_ccall f_3813(C_word c,C_word *av) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word *av) C_noret;
C_noret_decl(f_3200)
static void C_fcall f_3200(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word *av) C_noret;
C_noret_decl(f_3876)
static void C_fcall f_3876(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word *av) C_noret;
C_noret_decl(f_5632)
static C_word C_fcall f_5632(C_word t0);
C_noret_decl(f_3632)
static void C_ccall f_3632(C_word c,C_word *av) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word *av) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word *av) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word *av) C_noret;
C_noret_decl(f_6903)
static void C_ccall f_6903(C_word c,C_word *av) C_noret;
C_noret_decl(f_6907)
static void C_ccall f_6907(C_word c,C_word *av) C_noret;
C_noret_decl(f_3611)
static void C_ccall f_3611(C_word c,C_word *av) C_noret;
C_noret_decl(f_3888)
static void C_fcall f_3888(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word *av) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665(C_word c,C_word *av) C_noret;
C_noret_decl(f_5662)
static void C_ccall f_5662(C_word c,C_word *av) C_noret;
C_noret_decl(f_5282)
static void C_fcall f_5282(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word *av) C_noret;
C_noret_decl(f_5288)
static void C_fcall f_5288(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word *av) C_noret;
C_noret_decl(f_5298)
static void C_ccall f_5298(C_word c,C_word *av) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word *av) C_noret;
C_noret_decl(f_3033)
static void C_fcall f_3033(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3861)
static void C_ccall f_3861(C_word c,C_word *av) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word *av) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word *av) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word *av) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word *av) C_noret;
C_noret_decl(f_5248)
static void C_fcall f_5248(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word *av) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word *av) C_noret;
C_noret_decl(f_2277)
static void C_fcall f_2277(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6185)
static void C_ccall f_6185(C_word c,C_word *av) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word *av) C_noret;
C_noret_decl(f_5229)
static void C_fcall f_5229(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6916)
static void C_ccall f_6916(C_word c,C_word *av) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166(C_word c,C_word *av) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word *av) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word *av) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word *av) C_noret;
C_noret_decl(f_5233)
static void C_ccall f_5233(C_word c,C_word *av) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word *av) C_noret;
C_noret_decl(f_5206)
static void C_ccall f_5206(C_word c,C_word *av) C_noret;
C_noret_decl(f_5081)
static void C_ccall f_5081(C_word c,C_word *av) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word *av) C_noret;
C_noret_decl(f_4960)
static void C_fcall f_4960(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2131)
static void C_ccall f_2131(C_word c,C_word *av) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word *av) C_noret;
C_noret_decl(f_4975)
static void C_fcall f_4975(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6166)
static void C_ccall f_6166(C_word c,C_word *av) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947(C_word c,C_word *av) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word *av) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word *av) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word *av) C_noret;
C_noret_decl(f_4941)
static void C_ccall f_4941(C_word c,C_word *av) C_noret;
C_noret_decl(f_4944)
static void C_ccall f_4944(C_word c,C_word *av) C_noret;
C_noret_decl(f_6197)
static void C_ccall f_6197(C_word c,C_word *av) C_noret;
C_noret_decl(f_5095)
static void C_fcall f_5095(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2115)
static void C_fcall f_2115(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3497)
static void C_ccall f_3497(C_word c,C_word *av) C_noret;
C_noret_decl(f_3491)
static void C_fcall f_3491(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word *av) C_noret;
C_noret_decl(f_4218)
static void C_fcall f_4218(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6504)
static void C_ccall f_6504(C_word c,C_word *av) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word *av) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489(C_word c,C_word *av) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word *av) C_noret;
C_noret_decl(f_4923)
static void C_ccall f_4923(C_word c,C_word *av) C_noret;
C_noret_decl(f_4920)
static void C_ccall f_4920(C_word c,C_word *av) C_noret;
C_noret_decl(f_5078)
static void C_ccall f_5078(C_word c,C_word *av) C_noret;
C_noret_decl(f_4938)
static void C_ccall f_4938(C_word c,C_word *av) C_noret;
C_noret_decl(f_6520)
static void C_ccall f_6520(C_word c,C_word *av) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523(C_word c,C_word *av) C_noret;
C_noret_decl(f_6528)
static void C_fcall f_6528(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4935)
static void C_ccall f_4935(C_word c,C_word *av) C_noret;
C_noret_decl(f_4932)
static void C_ccall f_4932(C_word c,C_word *av) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word *av) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word *av) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word *av) C_noret;
C_noret_decl(f_3459)
static C_word C_fcall f_3459(C_word t0);
C_noret_decl(f_3698)
static void C_ccall f_3698(C_word c,C_word *av) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word *av) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word *av) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word *av) C_noret;
C_noret_decl(f_1914)
static void C_fcall f_1914(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_fcall f_2321(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6564)
static void C_ccall f_6564(C_word c,C_word *av) C_noret;
C_noret_decl(f_3424)
static C_word C_fcall f_3424(C_word t0,C_word t1);
C_noret_decl(f_4180)
static void C_fcall f_4180(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6553)
static void C_ccall f_6553(C_word c,C_word *av) C_noret;
C_noret_decl(f_4188)
static void C_fcall f_4188(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2501)
static void C_ccall f_2501(C_word c,C_word *av) C_noret;
C_noret_decl(f_2302)
static void C_ccall f_2302(C_word c,C_word *av) C_noret;
C_noret_decl(f7575)
static void C_ccall f7575(C_word c,C_word *av) C_noret;
C_noret_decl(f_6588)
static void C_ccall f_6588(C_word c,C_word *av) C_noret;
C_noret_decl(f_6585)
static void C_ccall f_6585(C_word c,C_word *av) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word *av) C_noret;
C_noret_decl(f_6582)
static void C_ccall f_6582(C_word c,C_word *av) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word *av) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word *av) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word *av) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word *av) C_noret;
C_noret_decl(f_6579)
static void C_ccall f_6579(C_word c,C_word *av) C_noret;
C_noret_decl(f_6573)
static void C_ccall f_6573(C_word c,C_word *av) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word *av) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word *av) C_noret;
C_noret_decl(f_4823)
static void C_ccall f_4823(C_word c,C_word *av) C_noret;
C_noret_decl(f_6591)
static void C_ccall f_6591(C_word c,C_word *av) C_noret;
C_noret_decl(f_4820)
static void C_ccall f_4820(C_word c,C_word *av) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word *av) C_noret;
C_noret_decl(f_4877)
static void C_fcall f_4877(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4500)
static void C_fcall f_4500(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4502)
static void C_fcall f_4502(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4505)
static void C_fcall f_4505(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5826)
static void C_ccall f_5826(C_word c,C_word *av) C_noret;
C_noret_decl(f_4800)
static void C_fcall f_4800(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word *av) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word *av) C_noret;
C_noret_decl(f_4851)
static void C_fcall f_4851(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4854)
static void C_fcall f_4854(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word *av) C_noret;
C_noret_decl(f_5836)
static void C_ccall f_5836(C_word c,C_word *av) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word *av) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word *av) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word *av) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word *av) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word *av) C_noret;
C_noret_decl(f_5195)
static void C_fcall f_5195(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5193)
static void C_fcall f_5193(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word *av) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word *av) C_noret;
C_noret_decl(f_5812)
static void C_ccall f_5812(C_word c,C_word *av) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word *av) C_noret;
C_noret_decl(f_5816)
static void C_ccall f_5816(C_word c,C_word *av) C_noret;
C_noret_decl(f_2590)
static void C_fcall f_2590(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word *av) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word *av) C_noret;
C_noret_decl(f_2498)
static void C_ccall f_2498(C_word c,C_word *av) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word *av) C_noret;
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word *av) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word *av) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word *av) C_noret;
C_noret_decl(f_2625)
static void C_fcall f_2625(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word *av) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word *av) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word *av) C_noret;
C_noret_decl(f_5872)
static void C_ccall f_5872(C_word c,C_word *av) C_noret;
C_noret_decl(f_5875)
static void C_ccall f_5875(C_word c,C_word *av) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word *av) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631(C_word c,C_word *av) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word *av) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word *av) C_noret;
C_noret_decl(f_3183)
static void C_fcall f_3183(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word *av) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word *av) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word *av) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word *av) C_noret;
C_noret_decl(f_5845)
static void C_ccall f_5845(C_word c,C_word *av) C_noret;
C_noret_decl(f_2472)
static void C_ccall f_2472(C_word c,C_word *av) C_noret;
C_noret_decl(f_5842)
static void C_fcall f_5842(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5848)
static void C_fcall f_5848(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word *av) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word *av) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word *av) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word *av) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word *av) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word *av) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word *av) C_noret;
C_noret_decl(f_4997)
static void C_ccall f_4997(C_word c,C_word *av) C_noret;
C_noret_decl(f_2440)
static void C_fcall f_2440(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5854)
static void C_ccall f_5854(C_word c,C_word *av) C_noret;
C_noret_decl(f_5857)
static void C_ccall f_5857(C_word c,C_word *av) C_noret;
C_noret_decl(f_5851)
static void C_ccall f_5851(C_word c,C_word *av) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word *av) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word *av) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word *av) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word *av) C_noret;
C_noret_decl(f_6003)
static void C_ccall f_6003(C_word c,C_word *av) C_noret;
C_noret_decl(f_3164)
static void C_fcall f_3164(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_ccall f_4300(C_word c,C_word *av) C_noret;
C_noret_decl(f_4305)
static void C_ccall f_4305(C_word c,C_word *av) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word *av) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word *av) C_noret;
C_noret_decl(f_4580)
static void C_ccall f_4580(C_word c,C_word *av) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word *av) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word *av) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word *av) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word *av) C_noret;
C_noret_decl(f_1944)
static void C_fcall f_1944(C_word t0) C_noret;
C_noret_decl(f_3379)
static void C_fcall f_3379(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5888)
static void C_ccall f_5888(C_word c,C_word *av) C_noret;
C_noret_decl(f_5885)
static void C_ccall f_5885(C_word c,C_word *av) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word *av) C_noret;
C_noret_decl(f_5881)
static void C_ccall f_5881(C_word c,C_word *av) C_noret;
C_noret_decl(f_6310)
static void C_ccall f_6310(C_word c,C_word *av) C_noret;
C_noret_decl(f_6317)
static void C_ccall f_6317(C_word c,C_word *av) C_noret;
C_noret_decl(f_5897)
static void C_ccall f_5897(C_word c,C_word *av) C_noret;
C_noret_decl(f_4570)
static void C_fcall f_4570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5894)
static void C_ccall f_5894(C_word c,C_word *av) C_noret;
C_noret_decl(f_5891)
static void C_ccall f_5891(C_word c,C_word *av) C_noret;
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word *av) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304(C_word c,C_word *av) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word *av) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word *av) C_noret;
C_noret_decl(f_5511)
static void C_fcall f_5511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word *av) C_noret;
C_noret_decl(f_6323)
static void C_ccall f_6323(C_word c,C_word *av) C_noret;
C_noret_decl(f_2172)
static void C_fcall f_2172(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word *av) C_noret;
C_noret_decl(f_6325)
static void C_fcall f_6325(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word *av) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word *av) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word *av) C_noret;
C_noret_decl(f_2685)
static void C_ccall f_2685(C_word c,C_word *av) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word *av) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word *av) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word *av) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word *av) C_noret;
C_noret_decl(f_2157)
static void C_ccall f_2157(C_word c,C_word *av) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word *av) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word *av) C_noret;
C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word *av) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word *av) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word *av) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word *av) C_noret;
C_noret_decl(f_3150)
static void C_fcall f_3150(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word *av) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word *av) C_noret;
C_noret_decl(f_4387)
static void C_fcall f_4387(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word *av) C_noret;
C_noret_decl(f_2646)
static void C_fcall f_2646(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word *av) C_noret;
C_noret_decl(f_4332)
static void C_fcall f_4332(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6393)
static void C_fcall f_6393(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word *av) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342(C_word c,C_word *av) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word *av) C_noret;
C_noret_decl(f_2897)
static void C_fcall f_2897(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word *av) C_noret;
C_noret_decl(f_2361)
static void C_ccall f_2361(C_word c,C_word *av) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word *av) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word *av) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word *av) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word *av) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word *av) C_noret;
C_noret_decl(f_6359)
static void C_fcall f_6359(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word *av) C_noret;
C_noret_decl(f_4373)
static void C_fcall f_4373(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word *av) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word *av) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word *av) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word *av) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word *av) C_noret;
C_noret_decl(f_5786)
static void C_ccall f_5786(C_word c,C_word *av) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word *av) C_noret;
C_noret_decl(f_5711)
static void C_fcall f_5711(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word *av) C_noret;
C_noret_decl(f_5732)
static void C_ccall f_5732(C_word c,C_word *av) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word *av) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word *av) C_noret;
C_noret_decl(f_6043)
static void C_ccall f_6043(C_word c,C_word *av) C_noret;
C_noret_decl(f_5136)
static void C_fcall f_5136(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word *av) C_noret;
C_noret_decl(f_6020)
static void C_ccall f_6020(C_word c,C_word *av) C_noret;
C_noret_decl(f_5766)
static void C_ccall f_5766(C_word c,C_word *av) C_noret;
C_noret_decl(f_5760)
static void C_ccall f_5760(C_word c,C_word *av) C_noret;
C_noret_decl(f_6051)
static void C_ccall f_6051(C_word c,C_word *av) C_noret;

C_noret_decl(trf_5779)
static void C_ccall trf_5779(C_word c,C_word *av) C_noret;
static void C_ccall trf_5779(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5779(t0,t1,t2);}

C_noret_decl(trf_5034)
static void C_ccall trf_5034(C_word c,C_word *av) C_noret;
static void C_ccall trf_5034(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5034(t0,t1,t2,t3);}

C_noret_decl(trf_5703)
static void C_ccall trf_5703(C_word c,C_word *av) C_noret;
static void C_ccall trf_5703(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5703(t0,t1,t2);}

C_noret_decl(trf_5795)
static void C_ccall trf_5795(C_word c,C_word *av) C_noret;
static void C_ccall trf_5795(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5795(t0,t1,t2);}

C_noret_decl(trf_3349)
static void C_ccall trf_3349(C_word c,C_word *av) C_noret;
static void C_ccall trf_3349(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3349(t0,t1,t2);}

C_noret_decl(trf_3142)
static void C_ccall trf_3142(C_word c,C_word *av) C_noret;
static void C_ccall trf_3142(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3142(t0,t1,t2);}

C_noret_decl(trf_6827)
static void C_ccall trf_6827(C_word c,C_word *av) C_noret;
static void C_ccall trf_6827(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6827(t0,t1);}

C_noret_decl(trf_3509)
static void C_ccall trf_3509(C_word c,C_word *av) C_noret;
static void C_ccall trf_3509(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3509(t0,t1,t2);}

C_noret_decl(trf_6855)
static void C_ccall trf_6855(C_word c,C_word *av) C_noret;
static void C_ccall trf_6855(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6855(t0,t1,t2);}

C_noret_decl(trf_5367)
static void C_ccall trf_5367(C_word c,C_word *av) C_noret;
static void C_ccall trf_5367(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5367(t0,t1,t2,t3);}

C_noret_decl(trf_5554)
static void C_ccall trf_5554(C_word c,C_word *av) C_noret;
static void C_ccall trf_5554(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5554(t0,t1,t2);}

C_noret_decl(trf_6416)
static void C_ccall trf_6416(C_word c,C_word *av) C_noret;
static void C_ccall trf_6416(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6416(t0,t1,t2);}

C_noret_decl(trf_2232)
static void C_ccall trf_2232(C_word c,C_word *av) C_noret;
static void C_ccall trf_2232(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2232(t0,t1);}

C_noret_decl(trf_3541)
static void C_ccall trf_3541(C_word c,C_word *av) C_noret;
static void C_ccall trf_3541(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3541(t0,t1,t2,t3);}

C_noret_decl(trf_6724)
static void C_ccall trf_6724(C_word c,C_word *av) C_noret;
static void C_ccall trf_6724(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6724(t0,t1);}

C_noret_decl(trf_2222)
static void C_ccall trf_2222(C_word c,C_word *av) C_noret;
static void C_ccall trf_2222(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2222(t0,t1,t2);}

C_noret_decl(trf_4608)
static void C_ccall trf_4608(C_word c,C_word *av) C_noret;
static void C_ccall trf_4608(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4608(t0,t1,t2);}

C_noret_decl(trf_6439)
static void C_ccall trf_6439(C_word c,C_word *av) C_noret;
static void C_ccall trf_6439(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6439(t0,t1,t2);}

C_noret_decl(trf_3101)
static void C_ccall trf_3101(C_word c,C_word *av) C_noret;
static void C_ccall trf_3101(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3101(t0,t1,t2,t3);}

C_noret_decl(trf_4715)
static void C_ccall trf_4715(C_word c,C_word *av) C_noret;
static void C_ccall trf_4715(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4715(t0,t1,t2,t3);}

C_noret_decl(trf_4613)
static void C_ccall trf_4613(C_word c,C_word *av) C_noret;
static void C_ccall trf_4613(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4613(t0,t1);}

C_noret_decl(trf_4766)
static void C_ccall trf_4766(C_word c,C_word *av) C_noret;
static void C_ccall trf_4766(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4766(t0,t1,t2,t3);}

C_noret_decl(trf_4681)
static void C_ccall trf_4681(C_word c,C_word *av) C_noret;
static void C_ccall trf_4681(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4681(t0,t1,t2);}

C_noret_decl(trf_5908)
static void C_ccall trf_5908(C_word c,C_word *av) C_noret;
static void C_ccall trf_5908(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5908(t0,t1,t2);}

C_noret_decl(trf_5903)
static void C_ccall trf_5903(C_word c,C_word *av) C_noret;
static void C_ccall trf_5903(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5903(t0,t1);}

C_noret_decl(trf_4264)
static void C_ccall trf_4264(C_word c,C_word *av) C_noret;
static void C_ccall trf_4264(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4264(t0,t1,t2);}

C_noret_decl(trf_4277)
static void C_ccall trf_4277(C_word c,C_word *av) C_noret;
static void C_ccall trf_4277(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4277(t0,t1,t2);}

C_noret_decl(trf_4648)
static void C_ccall trf_4648(C_word c,C_word *av) C_noret;
static void C_ccall trf_4648(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_4648(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4414)
static void C_ccall trf_4414(C_word c,C_word *av) C_noret;
static void C_ccall trf_4414(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4414(t0,t1,t2);}

C_noret_decl(trf_4886)
static void C_ccall trf_4886(C_word c,C_word *av) C_noret;
static void C_ccall trf_4886(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4886(t0,t1,t2,t3);}

C_noret_decl(trf_5428)
static void C_ccall trf_5428(C_word c,C_word *av) C_noret;
static void C_ccall trf_5428(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5428(t0,t1,t2);}

C_noret_decl(trf_5483)
static void C_ccall trf_5483(C_word c,C_word *av) C_noret;
static void C_ccall trf_5483(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5483(t0,t1);}

C_noret_decl(trf_5489)
static void C_ccall trf_5489(C_word c,C_word *av) C_noret;
static void C_ccall trf_5489(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5489(t0,t1,t2);}

C_noret_decl(trf_2064)
static void C_ccall trf_2064(C_word c,C_word *av) C_noret;
static void C_ccall trf_2064(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2064(t0,t1);}

C_noret_decl(trf_5434)
static void C_ccall trf_5434(C_word c,C_word *av) C_noret;
static void C_ccall trf_5434(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5434(t0,t1,t2);}

C_noret_decl(trf_4651)
static void C_ccall trf_4651(C_word c,C_word *av) C_noret;
static void C_ccall trf_4651(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_4651(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6136)
static void C_ccall trf_6136(C_word c,C_word *av) C_noret;
static void C_ccall trf_6136(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6136(t0,t1,t2);}

C_noret_decl(trf_5686)
static void C_ccall trf_5686(C_word c,C_word *av) C_noret;
static void C_ccall trf_5686(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5686(t0,t1);}

C_noret_decl(trf_5680)
static void C_ccall trf_5680(C_word c,C_word *av) C_noret;
static void C_ccall trf_5680(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5680(t0,t1);}

C_noret_decl(trf_2093)
static void C_ccall trf_2093(C_word c,C_word *av) C_noret;
static void C_ccall trf_2093(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2093(t0,t1,t2);}

C_noret_decl(trf_5697)
static void C_ccall trf_5697(C_word c,C_word *av) C_noret;
static void C_ccall trf_5697(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5697(t0,t1,t2);}

C_noret_decl(trf_3803)
static void C_ccall trf_3803(C_word c,C_word *av) C_noret;
static void C_ccall trf_3803(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3803(t0,t1,t2);}

C_noret_decl(trf_5674)
static void C_ccall trf_5674(C_word c,C_word *av) C_noret;
static void C_ccall trf_5674(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5674(t0,t1);}

C_noret_decl(trf_5446)
static void C_ccall trf_5446(C_word c,C_word *av) C_noret;
static void C_ccall trf_5446(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5446(t0,t1,t2);}

C_noret_decl(trf_3200)
static void C_ccall trf_3200(C_word c,C_word *av) C_noret;
static void C_ccall trf_3200(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3200(t0,t1);}

C_noret_decl(trf_3876)
static void C_ccall trf_3876(C_word c,C_word *av) C_noret;
static void C_ccall trf_3876(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3876(t0,t1);}

C_noret_decl(trf_3888)
static void C_ccall trf_3888(C_word c,C_word *av) C_noret;
static void C_ccall trf_3888(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3888(t0,t1,t2,t3);}

C_noret_decl(trf_5282)
static void C_ccall trf_5282(C_word c,C_word *av) C_noret;
static void C_ccall trf_5282(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5282(t0,t1,t2,t3);}

C_noret_decl(trf_5288)
static void C_ccall trf_5288(C_word c,C_word *av) C_noret;
static void C_ccall trf_5288(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5288(t0,t1,t2,t3);}

C_noret_decl(trf_3033)
static void C_ccall trf_3033(C_word c,C_word *av) C_noret;
static void C_ccall trf_3033(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3033(t0,t1,t2);}

C_noret_decl(trf_5248)
static void C_ccall trf_5248(C_word c,C_word *av) C_noret;
static void C_ccall trf_5248(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5248(t0,t1,t2);}

C_noret_decl(trf_2277)
static void C_ccall trf_2277(C_word c,C_word *av) C_noret;
static void C_ccall trf_2277(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2277(t0,t1,t2);}

C_noret_decl(trf_5229)
static void C_ccall trf_5229(C_word c,C_word *av) C_noret;
static void C_ccall trf_5229(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5229(t0,t1,t2);}

C_noret_decl(trf_4960)
static void C_ccall trf_4960(C_word c,C_word *av) C_noret;
static void C_ccall trf_4960(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4960(t0,t1,t2,t3);}

C_noret_decl(trf_4975)
static void C_ccall trf_4975(C_word c,C_word *av) C_noret;
static void C_ccall trf_4975(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4975(t0,t1,t2,t3);}

C_noret_decl(trf_5095)
static void C_ccall trf_5095(C_word c,C_word *av) C_noret;
static void C_ccall trf_5095(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5095(t0,t1);}

C_noret_decl(trf_2115)
static void C_ccall trf_2115(C_word c,C_word *av) C_noret;
static void C_ccall trf_2115(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2115(t0,t1,t2);}

C_noret_decl(trf_3491)
static void C_ccall trf_3491(C_word c,C_word *av) C_noret;
static void C_ccall trf_3491(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3491(t0,t1,t2,t3);}

C_noret_decl(trf_4218)
static void C_ccall trf_4218(C_word c,C_word *av) C_noret;
static void C_ccall trf_4218(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4218(t0,t1,t2);}

C_noret_decl(trf_6528)
static void C_ccall trf_6528(C_word c,C_word *av) C_noret;
static void C_ccall trf_6528(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6528(t0,t1,t2);}

C_noret_decl(trf_1914)
static void C_ccall trf_1914(C_word c,C_word *av) C_noret;
static void C_ccall trf_1914(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1914(t0,t1);}

C_noret_decl(trf_2321)
static void C_ccall trf_2321(C_word c,C_word *av) C_noret;
static void C_ccall trf_2321(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2321(t0,t1);}

C_noret_decl(trf_4180)
static void C_ccall trf_4180(C_word c,C_word *av) C_noret;
static void C_ccall trf_4180(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4180(t0,t1,t2);}

C_noret_decl(trf_4188)
static void C_ccall trf_4188(C_word c,C_word *av) C_noret;
static void C_ccall trf_4188(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4188(t0,t1,t2);}

C_noret_decl(trf_4877)
static void C_ccall trf_4877(C_word c,C_word *av) C_noret;
static void C_ccall trf_4877(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4877(t0,t1);}

C_noret_decl(trf_4500)
static void C_ccall trf_4500(C_word c,C_word *av) C_noret;
static void C_ccall trf_4500(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4500(t0,t1,t2);}

C_noret_decl(trf_4502)
static void C_ccall trf_4502(C_word c,C_word *av) C_noret;
static void C_ccall trf_4502(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4502(t0,t1,t2,t3);}

C_noret_decl(trf_4505)
static void C_ccall trf_4505(C_word c,C_word *av) C_noret;
static void C_ccall trf_4505(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4505(t0,t1,t2);}

C_noret_decl(trf_4800)
static void C_ccall trf_4800(C_word c,C_word *av) C_noret;
static void C_ccall trf_4800(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4800(t0,t1,t2);}

C_noret_decl(trf_4851)
static void C_ccall trf_4851(C_word c,C_word *av) C_noret;
static void C_ccall trf_4851(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4851(t0,t1);}

C_noret_decl(trf_4854)
static void C_ccall trf_4854(C_word c,C_word *av) C_noret;
static void C_ccall trf_4854(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4854(t0,t1);}

C_noret_decl(trf_5195)
static void C_ccall trf_5195(C_word c,C_word *av) C_noret;
static void C_ccall trf_5195(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5195(t0,t1,t2);}

C_noret_decl(trf_5193)
static void C_ccall trf_5193(C_word c,C_word *av) C_noret;
static void C_ccall trf_5193(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5193(t0,t1);}

C_noret_decl(trf_2590)
static void C_ccall trf_2590(C_word c,C_word *av) C_noret;
static void C_ccall trf_2590(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2590(t0,t1,t2);}

C_noret_decl(trf_2625)
static void C_ccall trf_2625(C_word c,C_word *av) C_noret;
static void C_ccall trf_2625(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2625(t0,t1,t2);}

C_noret_decl(trf_3183)
static void C_ccall trf_3183(C_word c,C_word *av) C_noret;
static void C_ccall trf_3183(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3183(t0,t1,t2);}

C_noret_decl(trf_5842)
static void C_ccall trf_5842(C_word c,C_word *av) C_noret;
static void C_ccall trf_5842(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5842(t0,t1);}

C_noret_decl(trf_5848)
static void C_ccall trf_5848(C_word c,C_word *av) C_noret;
static void C_ccall trf_5848(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5848(t0,t1);}

C_noret_decl(trf_2440)
static void C_ccall trf_2440(C_word c,C_word *av) C_noret;
static void C_ccall trf_2440(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2440(t0,t1);}

C_noret_decl(trf_3164)
static void C_ccall trf_3164(C_word c,C_word *av) C_noret;
static void C_ccall trf_3164(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3164(t0,t1);}

C_noret_decl(trf_1944)
static void C_ccall trf_1944(C_word c,C_word *av) C_noret;
static void C_ccall trf_1944(C_word c,C_word *av){
C_word t0=av[0];
f_1944(t0);}

C_noret_decl(trf_3379)
static void C_ccall trf_3379(C_word c,C_word *av) C_noret;
static void C_ccall trf_3379(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3379(t0,t1,t2);}

C_noret_decl(trf_4570)
static void C_ccall trf_4570(C_word c,C_word *av) C_noret;
static void C_ccall trf_4570(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4570(t0,t1);}

C_noret_decl(trf_5511)
static void C_ccall trf_5511(C_word c,C_word *av) C_noret;
static void C_ccall trf_5511(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5511(t0,t1);}

C_noret_decl(trf_2172)
static void C_ccall trf_2172(C_word c,C_word *av) C_noret;
static void C_ccall trf_2172(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2172(t0,t1,t2);}

C_noret_decl(trf_6325)
static void C_ccall trf_6325(C_word c,C_word *av) C_noret;
static void C_ccall trf_6325(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6325(t0,t1,t2);}

C_noret_decl(trf_3150)
static void C_ccall trf_3150(C_word c,C_word *av) C_noret;
static void C_ccall trf_3150(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3150(t0,t1);}

C_noret_decl(trf_4387)
static void C_ccall trf_4387(C_word c,C_word *av) C_noret;
static void C_ccall trf_4387(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4387(t0,t1,t2);}

C_noret_decl(trf_2646)
static void C_ccall trf_2646(C_word c,C_word *av) C_noret;
static void C_ccall trf_2646(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2646(t0,t1,t2);}

C_noret_decl(trf_4332)
static void C_ccall trf_4332(C_word c,C_word *av) C_noret;
static void C_ccall trf_4332(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4332(t0,t1,t2);}

C_noret_decl(trf_6393)
static void C_ccall trf_6393(C_word c,C_word *av) C_noret;
static void C_ccall trf_6393(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6393(t0,t1,t2);}

C_noret_decl(trf_2897)
static void C_ccall trf_2897(C_word c,C_word *av) C_noret;
static void C_ccall trf_2897(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2897(t0,t1,t2);}

C_noret_decl(trf_6359)
static void C_ccall trf_6359(C_word c,C_word *av) C_noret;
static void C_ccall trf_6359(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6359(t0,t1,t2);}

C_noret_decl(trf_4373)
static void C_ccall trf_4373(C_word c,C_word *av) C_noret;
static void C_ccall trf_4373(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4373(t0,t1,t2);}

C_noret_decl(trf_5711)
static void C_ccall trf_5711(C_word c,C_word *av) C_noret;
static void C_ccall trf_5711(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5711(t0,t1,t2);}

C_noret_decl(trf_5136)
static void C_ccall trf_5136(C_word c,C_word *av) C_noret;
static void C_ccall trf_5136(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5136(t0,t1);}

/* k5771 in k5746 in k6183 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in ... */
static void C_ccall f_5773(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5773,2,av);}
/* csi.scm:1019: string-append */
t2=*((C_word*)lf[30]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[306];
av2[4]=lf[0];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* evalstring in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in ... */
static void C_fcall f_5779(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_5779,3,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5826,tmp=(C_word)a,a+=2,tmp):C_i_car(t3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5786,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1023: open-input-string */
t8=C_fast_retrieve(lf[273]);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* for-each-loop819 in k4942 in k4939 in k4936 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in ... */
static void C_fcall f_5034(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_5034,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5044,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* csi.scm:831: g820 */
t9=((C_word*)t0)[3];
f_4960(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* loop in collect-options in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in ... */
static void C_fcall f_5703(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_5703,3,t0,t1,t2);}
a=C_alloc(4);
t3=C_i_member(((C_word*)t0)[2],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1000: g1205 */
t5=t4;
f_5711(t5,t1,t3);}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6598 in k6589 in k6586 in k6583 in k6580 in k6577 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in ... */
static void C_ccall f_6600(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6600,2,av);}
if(C_truep(t1)){
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_5674(t3,C_i_set_car(t2,t1));}
else{
t2=((C_word*)t0)[3];
f_5674(t2,C_SCHEME_FALSE);}}

/* doloop1225 in k5791 in k5784 in evalstring in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in ... */
static void C_fcall f_5795(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_5795,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_eofp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5805,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5816,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5818,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1026: ##sys#call-with-values */{
C_word av2[4];
av2[0]=0;
av2[1]=t4;
av2[2]=t5;
av2[3]=*((C_word*)lf[272]+1);
C_call_with_values(4,av2);}}}

/* k5791 in k5784 in evalstring in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in ... */
static void C_ccall f_5793(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_5793,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5795,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5795(t5,((C_word*)t0)[4],t1);}

/* k3342 in k3280 in k3276 in k3272 in k3268 in k3260 in k3232 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in ... */
static void C_ccall f_3344(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3344,2,av);}
/* csi.scm:520: symbol->string */
t2=*((C_word*)lf[134]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* for-each-loop422 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_fcall f_3349(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_3349,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3359,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:480: g423 */
t5=((C_word*)t0)[3];
f_3183(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6676 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6678(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6678,2,av);}
/* csi.scm:997: append */
t2=*((C_word*)lf[231]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3993(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_3993,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=(C_truep(t2)?lf[200]:lf[201]);
t4=t3;
t5=C_slot(((C_word*)t0)[2],C_fix(7));
t6=t5;
t7=C_slot(((C_word*)t0)[2],C_fix(3));
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t6,a[6]=t8,tmp=(C_word)a,a+=7,tmp);
/* csi.scm:667: ##sys#peek-unsigned-integer */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[199]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[199]+1);
av2[1]=t9;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(0);
tp(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:668: ##sys#locative? */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[236]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[236]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
tp(3,av2);}}}

/* k6663 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6665(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6665,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_i_member(lf[359],((C_word*)((C_word*)t0)[2])[1]);
t4=((C_word*)t0)[3];
f_5674(t4,(C_truep(t3)?C_i_set_cdr(t3,C_SCHEME_END_OF_LIST):C_SCHEME_FALSE));}

/* g167 in toplevel-command in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static C_word C_fcall f_2394(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
return(C_i_set_cdr(t1,t2));}

/* k3320 in k3292 in k3288 in k3284 in k3280 in k3276 in k3272 in k3268 in k3260 in k3232 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in ... */
static void C_ccall f_3322(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,20))){C_save_and_reclaim((void *)f_3322,2,av);}
/* csi.scm:497: printf */
t2=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 21) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(21);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[132];
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
av2[5]=((C_word*)t0)[5];
av2[6]=((C_word*)t0)[6];
av2[7]=((C_word*)t0)[7];
av2[8]=((C_word*)t0)[8];
av2[9]=((C_word*)t0)[9];
av2[10]=C_fast_retrieve(lf[133]);
av2[11]=((C_word*)t0)[10];
av2[12]=((C_word*)t0)[11];
av2[13]=((C_word*)t0)[12];
av2[14]=((C_word*)t0)[13];
av2[15]=((C_word*)t0)[14];
av2[16]=((C_word*)t0)[15];
av2[17]=((C_word*)t0)[16];
av2[18]=((C_word*)t0)[17];
av2[19]=((C_word*)t0)[18];
av2[20]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(21,av2);}}

/* k3981 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_3983,2,av);}
/* csi.scm:658: descseq */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=*((C_word*)lf[173]+1);
av2[4]=*((C_word*)lf[175]+1);
av2[5]=C_fix(1);
f_3497(6,av2);}}

/* k3985 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3987(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3987,2,av);}
/* csi.scm:659: sprintf */
t2=*((C_word*)lf[197]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[198];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5746 in k6183 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in ... */
static void C_ccall f_5748(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5748,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
if(C_truep(C_i_string_equal_p(t1,lf[305]))){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5760,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5773,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1019: chop-separator */
t4=C_retrieve2(lf[23],"chop-separator");{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t1;
f_2014(3,av2);}}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k3116 in doloop362 in k3097 in a3090 in a3084 in a3066 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_ccall f_3118(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3118,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_3101(t3,((C_word*)t0)[5],t1,t2);}

/* k6834 in k6825 in k6822 in a6819 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6836,2,av);}
/* csi.scm:432: printf */
t2=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[388];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6696 in k6690 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6698(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6698,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* k6690 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6692(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6692,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6695,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6698,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[270]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[270]+1);
av2[1]=t3;
tp(2,av2);}}

/* k6693 in k6690 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6695(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6695,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5308 in doloop931 in g918 in doloop903 in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5310(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_5310,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:898: display */
t3=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[105];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t3=((C_word*)t0)[6];
t4=C_u_i_cdr(t3);
t5=((C_word*)((C_word*)t0)[7])[1];
f_5288(t5,((C_word*)t0)[8],t2,t4);}}

/* k5311 in k5308 in doloop931 in g918 in doloop903 in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5313(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5313,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[6];
t4=C_u_i_car(t3);
/* csi.scm:899: display */
t5=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6686(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6686,2,av);}
a=C_alloc(4);
t2=(C_truep(t1)?t1:lf[362]);
t3=((C_word*)t0)[2];
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2999,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:447: open-input-string */
t6=C_fast_retrieve(lf[273]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k5314 in k5311 in k5308 in doloop931 in g918 in doloop903 in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5316(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5316,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:900: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5317 in k5314 in k5311 in k5308 in doloop931 in g918 in doloop903 in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_5319(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_5319,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_a_i_list1(&a,1,t3);
/* csi.scm:901: history-add */
t5=C_retrieve2(lf[40],"history-add");
f_2222(t5,t2,t4);}

/* k6680 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6682(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6682,2,av);}
/* csi.scm:978: canonicalize-args */
f_5483(((C_word*)t0)[2],t1);}

/* report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_3142(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_3142,3,t0,t1,t2);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=t3;
f_3150(t5,C_u_i_car(t4));}
else{
t4=t3;
f_3150(t4,*((C_word*)lf[91]+1));}}

/* k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3141(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_3141,2,av);}
a=C_alloc(9);
t2=t1;
t3=C_mutate2(&lf[68] /* (set! report ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3142,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t4=C_mutate2(&lf[147] /* (set! bytevector-data ...) */,lf[148]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3489,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:565: make-vector */
t6=*((C_word*)lf[379]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_fix(37);
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k5320 in k5317 in k5314 in k5311 in k5308 in doloop931 in g918 in doloop903 in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_ccall f_5322(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5322,2,av);}
t2=C_slot(((C_word*)t0)[2],((C_word*)t0)[3]);
/* csi.scm:902: return */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[5];
av2[2]=t2;
((C_proc)C_fast_retrieve_proc(t3))(3,av2);}}

/* a3129 in a3123 in a3084 in a3066 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3130,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k6870 in k6825 in k6822 in a6819 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6872(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6872,2,av);}
/* csi.scm:435: ##sys#find-module */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[385]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[385]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
tp(4,av2);}}

/* k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3138(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_3138,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3141,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t1;
f_3141(2,av2);}}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[380]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_PREFIX);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k6822 in a6819 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6824(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_6824,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6827,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_stringp(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6883,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:429: ##sys#string->symbol */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[389]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[389]+1);
av2[1]=t5;
av2[2]=((C_word*)t3)[1];
tp(3,av2);}}
else{
t5=t4;
f_6827(t5,C_SCHEME_UNDEFINED);}}

/* a6819 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6820(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6820,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6824,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:427: read */
t3=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6825 in k6822 in a6819 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_6827(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_6827,2,t0,t1);}
a=C_alloc(7);
t2=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t2)){
if(C_truep(C_i_symbolp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6872,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:435: ##sys#resolve-module-name */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[386]);
C_word av2[4];
av2[0]=*((C_word*)lf[386]+1);
av2[1]=t4;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=C_SCHEME_FALSE;
tp(4,av2);}}
else{
/* csi.scm:434: printf */
t3=*((C_word*)lf[84]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[387];
av2[3]=((C_word*)((C_word*)t0)[2])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6836,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:431: ##sys#switch-module */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[383]);
C_word av2[3];
av2[0]=*((C_word*)lf[383]+1);
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
tp(3,av2);}}}

/* a3123 in a3084 in a3066 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3124(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,2))){
C_save_and_reclaim((void*)f_3124,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3130,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:454: k354 */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* loop1 in k3502 in k3624 in descseq in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_3509(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,4))){
C_save_and_reclaim_args((void *)trf_3509,3,t0,t1,t2);}
a=C_alloc(10);
t3=C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_fixnum_greater_or_equal_p(t2,C_fix(40)))){
t4=C_fixnum_difference(((C_word*)t0)[2],t2);
/* csi.scm:581: fprintf */
t5=*((C_word*)lf[153]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[154];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3532,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t5=C_fixnum_plus(((C_word*)t0)[4],t2);
/* csi.scm:583: pref */
t6=((C_word*)t0)[6];{
C_word av2[4];
av2[0]=t6;
av2[1]=t4;
av2[2]=((C_word*)t0)[7];
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t6))(4,av2);}}}}

/* k3502 in k3624 in descseq in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3504(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_3504,2,av);}
a=C_alloc(10);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3509(t5,((C_word*)t0)[7],C_fix(0));}

/* k6857 in g324 in k6849 in k6825 in k6822 in a6819 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6859,2,av);}
/* csi.scm:438: printf */
t2=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[382];
av2[3]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6849 in k6825 in k6822 in a6819 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_6851,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6855,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:430: g324 */
t3=t2;
f_6855(t3,((C_word*)t0)[3],t1);}
else{
/* csi.scm:440: printf */
t2=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[384];
av2[3]=((C_word*)((C_word*)t0)[2])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* g324 in k6849 in k6825 in k6822 in a6819 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_6855(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_6855,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6859,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:437: ##sys#switch-module */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[383]);
C_word av2[3];
av2[0]=*((C_word*)lf[383]+1);
av2[1]=t3;
av2[2]=t2;
tp(3,av2);}}

/* a6071 in k6059 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in ... */
static void C_ccall f_6072(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6072,2,av);}
a=C_alloc(4);
t2=C_fast_retrieve(lf[296]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6080,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1126: command-line-arguments */
t4=C_fast_retrieve(lf[297]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5356 in doloop903 in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5358(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_5358,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:905: ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[27]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=t2;
av2[2]=lf[107];
av2[3]=((C_word*)t0)[4];
tp(4,av2);}}

/* chop-separator in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2014(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_2014,3,av);}
a=C_alloc(9);
t3=C_block_size(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=t4;
t6=C_i_string_ref(t2,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2027,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_fixnum_greaterp(t5,C_fix(0)))){
/* csi.scm:178: dirseparator? */
t8=C_retrieve2(lf[21],"dirseparator\077");{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t6;
f_1999(3,av2);}}
else{
t8=t7;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
f_2027(2,av2);}}}

/* a6884 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6885(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6885,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6893,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:259: ##sys#current-module */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[396]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[396]+1);
av2[1]=t2;
tp(2,av2);}}

/* k4139 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_4141(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_4141,2,av);}
/* csi.scm:687: hexdump */
f_4648(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],*((C_word*)lf[216]+1),((C_word*)t0)[5]);}

/* k6881 in k6822 in a6819 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6883(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6883,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_6827(t3,t2);}

/* k5363 in k5356 in doloop903 in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5365(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5365,2,av);}
/* csi.scm:905: fail */
t2=((C_word*)t0)[2];
f_5229(t2,((C_word*)t0)[3],t1);}

/* for-each-loop917 in doloop903 in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5367(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_5367,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5377,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* csi.scm:892: g918 */
t9=((C_word*)t0)[3];
f_5282(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k6198 in k6195 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in ... */
static void C_ccall f_6200(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6200,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6203,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1075: case-sensitive */
t3=C_fast_retrieve(lf[312]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6201 in k6198 in k6195 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in ... */
static void C_ccall f_6203(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6203,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6206,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1076: keyword-style */
t3=C_fast_retrieve(lf[135]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[311];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6216 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in ... */
static void C_ccall f_6218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6218,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6221,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
/* csi.scm:1072: symbol-escape */
t3=C_fast_retrieve(lf[309]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
/* csi.scm:1071: display */
t3=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[315];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_5894(2,av2);}}}

/* k4152 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_4154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4154,2,av);}
/* csi.scm:689: fprintf */
t2=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[218];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5375 in for-each-loop917 in doloop903 in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5377(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5377,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_5367(t4,((C_word*)t0)[5],t2,t3);}

/* k6204 in k6201 in k6198 in k6195 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in ... */
static void C_ccall f_6206(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6206,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6209,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1077: parentheses-synonyms */
t3=C_fast_retrieve(lf[310]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6207 in k6204 in k6201 in k6198 in k6195 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in ... */
static void C_ccall f_6209(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6209,2,av);}
/* csi.scm:1078: symbol-escape */
t2=C_fast_retrieve(lf[309]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6078 in a6071 in k6059 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in ... */
static void C_ccall f_6080(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6080,2,av);}
/* csi.scm:1126: g1427 */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* k4127 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4129(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4129,2,av);}
/* csi.scm:683: fprintf */
t2=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[214];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a6081 in k6059 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in ... */
static void C_ccall f_6082(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +0,c,2))){
C_save_and_reclaim((void*)f_6082,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+0);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
if(C_truep(C_fixnump(t4))){
t5=C_i_car(t2);
/* csi.scm:1128: exit */
t6=C_fast_retrieve(lf[57]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
/* csi.scm:1128: exit */
t5=C_fast_retrieve(lf[57]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}
else{
/* csi.scm:1128: exit */
t3=C_fast_retrieve(lf[57]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2045(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(49,c,3))){C_save_and_reclaim((void *)f_2045,2,av);}
a=C_alloc(49);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2064,tmp=(C_word)a,a+=2,tmp);
t4=C_mutate2(&lf[29] /* (set! lookup-script-file ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2115,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t5=C_SCHEME_UNDEFINED;
t6=C_a_i_vector(&a,32,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5,t5);
t7=C_mutate2(&lf[38] /* (set! history-list ...) */,t6);
t8=lf[18] /* history-count */ =C_fix(1);;
t9=C_fast_retrieve(lf[39]);
t10=C_mutate2(&lf[40] /* (set! history-add ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2222,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2(&lf[19] /* (set! history-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2321,tmp=(C_word)a,a+=2,tmp));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6885,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:255: repl-prompt */
t14=C_fast_retrieve(lf[397]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
((C_proc)(void*)(*((C_word*)t14+1)))(3,av2);}}

/* k3702 in k3696 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3704(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3704,2,av);}
/* csi.scm:612: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[95]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[95]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=*((C_word*)lf[91]+1);
tp(4,av2);}}

/* k6894 in k6891 in a6884 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6896(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6896,2,av);}
/* csi.scm:258: sprintf */
t2=*((C_word*)lf[197]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[392];
av2[3]=t1;
av2[4]=C_retrieve2(lf[18],"history-count");
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6891 in a6884 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_6893,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6896,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6903,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:261: ##sys#module-name */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[394]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[394]+1);
av2[1]=t3;
av2[2]=t1;
tp(3,av2);}}
else{
/* csi.scm:258: sprintf */
t3=*((C_word*)lf[197]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[392];
av2[3]=lf[395];
av2[4]=C_retrieve2(lf[18],"history-count");
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* map-loop1061 in k5523 in k5509 in loop in canonicalize-args in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5554(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_5554,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_string(&a,2,C_make_character(45),t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5548 in k5544 in k5523 in k5509 in loop in canonicalize-args in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5550(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5550,2,av);}
/* csi.scm:956: append */
t2=*((C_word*)lf[231]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4135(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,6))){C_save_and_reclaim((void *)f_4135,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=C_block_size(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4141,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:686: fprintf */
t5=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[217];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
if(C_truep(C_lambdainfop(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4154,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:689: ##sys#lambda-info->string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[219]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[219]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
tp(3,av2);}}
else{
if(C_truep(C_i_structurep(((C_word*)t0)[2],lf[220]))){
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_eqp(t2,C_fix(1));
t5=(C_truep(t4)?lf[223]:lf[224]);
t6=C_slot(((C_word*)t0)[2],C_fix(3));
/* csi.scm:692: fprintf */
t7=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[225];
av2[4]=t2;
av2[5]=t5;
av2[6]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(7,av2);}}
else{
if(C_truep(C_i_structurep(((C_word*)t0)[2],lf[226]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(1));
/* csi.scm:706: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[229];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
if(C_truep(C_structurep(((C_word*)t0)[2]))){
t2=C_slot(((C_word*)t0)[2],C_fix(0));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:722: ##sys#hash-table-ref */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[233]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[233]+1);
av2[1]=t4;
av2[2]=C_retrieve2(lf[149],"describer-table");
av2[3]=t3;
tp(4,av2);}}
else{
/* csi.scm:729: fprintf */
t2=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[234];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}}}}}

/* k3769 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3771(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3771,2,av);}
/* csi.scm:620: fprintf */
t2=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[176];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6059 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in ... */
static void C_ccall f_6061(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_6061,2,av);}
a=C_alloc(4);
if(C_truep(C_i_equalp(lf[295],((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6072,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6082,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1126: call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}
else{
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[5])[1];
f_5908(t3,((C_word*)t0)[6],t2);}}

/* k6755 in k6775 in k6735 in k6722 in a6713 in k6706 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6757(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_6757,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:914: rename999 */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[259];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k2025 in chop-separator in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2027(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_2027,2,av);}
if(C_truep(t1)){
/* csi.scm:179: substring */
t2=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_fix(0);
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3764(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_3764,2,av);}
a=C_alloc(12);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3771,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:621: ##sys#symbol->string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[177]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[177]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3780,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3864,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:623: ##sys#symbol-has-toplevel-binding? */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[190]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[190]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}
else{
t2=((C_word*)t0)[4];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3424,tmp=(C_word)a,a+=2,tmp);
t4=f_3424(t2,t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3876,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_3876(t6,t4);}
else{
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3459,tmp=(C_word)a,a+=2,tmp);
t8=t5;
f_3876(t8,f_3459(t6));}}}}

/* k6424 in for-each-loop1256 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in ... */
static void C_ccall f_6426(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6426,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6416(t3,((C_word*)t0)[4],t2);}

/* k6775 in k6735 in k6722 in a6713 in k6706 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6777(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,2))){C_save_and_reclaim((void *)f_6777,2,av);}
a=C_alloc(20);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],t2);
t4=C_a_i_cons(&a,2,lf[372],t3);
t5=C_a_i_cons(&a,2,t1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6757,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:914: rename999 */
t8=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[373];
((C_proc)C_fast_retrieve_proc(t8))(3,av2);}}

/* a3582 in loop2 in k3530 in loop1 in k3502 in k3624 in descseq in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_3583(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_3583,2,av);}
/* csi.scm:589: fprintf */
t2=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[158];
av2[4]=((C_word*)t0)[3];
av2[5]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* for-each-loop1256 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in ... */
static void C_fcall f_6416(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_6416,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6426,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1049: g1257 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4021(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_4021,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:670: ##sys#peek-unsigned-integer */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[199]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[199]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(0);
tp(4,av2);}}
else{
if(C_truep(C_anypointerp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4129,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:683: ##sys#peek-unsigned-integer */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[199]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[199]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(0);
tp(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4135,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:684: ##sys#bytevector? */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[235]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[235]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
tp(3,av2);}}}}

/* k4026 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4028(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_4028,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[2],C_fix(2));
switch(t3){
case C_fix(0):
/* csi.scm:669: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[203];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[204];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(1):
/* csi.scm:669: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[203];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[205];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(2):
/* csi.scm:669: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[203];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[206];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(3):
/* csi.scm:669: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[203];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[207];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(4):
/* csi.scm:669: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[203];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[208];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(5):
/* csi.scm:669: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[203];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[209];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(6):
/* csi.scm:669: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[203];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[210];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(7):
/* csi.scm:669: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[203];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[211];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(8):
/* csi.scm:669: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[203];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[212];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
case C_fix(9):
/* csi.scm:669: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[203];
av2[4]=t1;
av2[5]=t2;
av2[6]=lf[213];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}
default:
t4=C_SCHEME_UNDEFINED;
/* csi.scm:669: fprintf */
t5=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[203];
av2[4]=t1;
av2[5]=t2;
av2[6]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(7,av2);}}}

/* k3260 in k3232 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_ccall f_3262(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_3262,2,av);}
a=C_alloc(10);
t2=t1;
t3=C_fudge(C_fix(3));
t4=(C_truep(t3)?lf[126]:lf[127]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t5,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* csi.scm:514: software-type */
t7=C_fast_retrieve(lf[139]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k6763 in k6755 in k6775 in k6735 in k6722 in a6713 in k6706 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,1))){C_save_and_reclaim((void *)f_6765,2,av);}
a=C_alloc(21);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* k6401 in for-each-loop1273 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in ... */
static void C_ccall f_6403(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6403,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6393(t3,((C_word*)t0)[4],t2);}

/* a6713 in k6706 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6714(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6714,5,av);}
a=C_alloc(6);
t5=C_i_cdr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6724,a[2]=t6,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t6))){
t8=C_i_cdr(t6);
if(C_truep(C_i_pairp(t8))){
t9=C_i_cdr(t8);
t10=t7;
f_6724(t10,C_eqp(t9,C_SCHEME_END_OF_LIST));}
else{
t9=t7;
f_6724(t9,C_SCHEME_FALSE);}}
else{
t8=t7;
f_6724(t8,C_SCHEME_FALSE);}}

/* k6710 in k6706 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6712(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6712,2,av);}
/* csi.scm:913: ##sys#extend-macro-environment */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[370]);
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[370]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=lf[371];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
tp(5,av2);}}

/* k2230 in history-add in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_2232(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,1))){
C_save_and_reclaim_args((void *)trf_2232,2,t0,t1);}
t2=C_i_vector_set(C_retrieve2(lf[38],"history-list"),C_retrieve2(lf[18],"history-count"),((C_word*)t0)[2]);
t3=C_fixnum_plus(C_retrieve2(lf[18],"history-count"),C_fix(1));
t4=C_mutate2(&lf[18] /* (set! history-count ...) */,t3);
t5=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t5;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* a6699 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6700,3,av);}
/* csi.scm:920: ##sys#user-interrupt-hook */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[258]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[258]+1);
av2[1]=t1;
tp(2,av2);}}

/* k3552 in k3549 in loop2 in k3530 in loop1 in k3502 in k3624 in descseq in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_ccall f_3554(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3554,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],((C_word*)t0)[3]);
/* csi.scm:595: loop1 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3509(t3,((C_word*)t0)[5],t2);}

/* k6706 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6708(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_6708,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6712,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6714,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:914: ##sys#er-transformer */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[377]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[377]+1);
av2[1]=t3;
av2[2]=t4;
tp(3,av2);}}

/* k3549 in loop2 in k3530 in loop1 in k3502 in k3624 in descseq in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_3551(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_3551,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[3],C_fix(1)))){
t3=C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t4=C_eqp(((C_word*)t0)[3],C_fix(2));
if(C_truep(t4)){
/* csi.scm:591: fprintf */
t5=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=lf[155];
av2[4]=t3;
av2[5]=lf[156];
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}
else{
/* csi.scm:591: fprintf */
t5=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=lf[155];
av2[4]=t3;
av2[5]=lf[157];
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}}
else{
/* csi.scm:594: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k3796 in k3784 in k3781 in k3778 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3798(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_3798,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3803,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3803(t5,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k6735 in k6722 in a6713 in k6706 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6737(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_6737,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:914: rename999 */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[374];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* loop2 in k3530 in loop1 in k3502 in k3624 in descseq in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_3541(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_3541,4,t0,t1,t2,t3);}
a=C_alloc(12);
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3551,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3583,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:586: ##sys#with-print-length-limit */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[93]);
C_word av2[4];
av2[0]=*((C_word*)lf[93]+1);
av2[1]=t4;
av2[2]=C_fix(1000);
av2[3]=t5;
tp(4,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3611,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:596: pref */
t5=((C_word*)t0)[8];{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[9];
av2[3]=t3;
((C_proc)C_fast_retrieve_proc(t5))(4,av2);}}}

/* k3784 in k3781 in k3778 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3786(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_3786,2,av);}
a=C_alloc(5);
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=t2;
if(C_truep(C_i_nullp(t3))){
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3798,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:634: display */
t5=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[180];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k3781 in k3778 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3783(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_3783,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3861,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:627: ##sys#interned-symbol? */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[187]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[187]+1);
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
tp(3,av2);}}

/* k3778 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3780(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3780,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:625: ##sys#qualified-symbol? */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[188]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[188]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
tp(3,av2);}}

/* k2244 in history-add in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2246(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2246,2,av);}
t2=C_mutate2(&lf[38] /* (set! history-list ...) */,t1);
t3=((C_word*)t0)[2];
f_2232(t3,t2);}

/* k6722 in a6713 in k6706 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_6724(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_6724,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_i_cdr(((C_word*)t0)[2]);
t5=C_i_car(t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6737,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:914: rename999 */
t8=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[375];
((C_proc)C_fast_retrieve_proc(t8))(3,av2);}}
else{
/* csi.scm:914: ##sys#syntax-rules-mismatch */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[376]);
C_word av2[3];
av2[0]=*((C_word*)lf[376]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[5];
tp(3,av2);}}}

/* k3530 in loop1 in k3502 in k3624 in descseq in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3532(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_3532,2,av);}
a=C_alloc(12);
t2=t1;
t3=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[3],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3541,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t6,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_3541(t8,((C_word*)t0)[9],C_fix(1),t4);}

/* history-add in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_2222(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_2222,3,t0,t1,t2);}
a=C_alloc(7);
t3=C_i_nullp(t2);
t4=(C_truep(t3)?*((C_word*)lf[41]+1):C_slot(t2,C_fix(0)));
t5=t4;
t6=C_block_size(C_retrieve2(lf[38],"history-list"));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2232,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(C_retrieve2(lf[18],"history-count"),t6))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2246,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=C_fixnum_times(C_fix(2),t6);
/* csi.scm:229: vector-resize */
t10=((C_word*)t0)[2];{
C_word av2[4];
av2[0]=t10;
av2[1]=t8;
av2[2]=C_retrieve2(lf[38],"history-list");
av2[3]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}
else{
t8=t7;
f_2232(t8,C_SCHEME_UNDEFINED);}}

/* k6447 in for-each-loop1239 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in ... */
static void C_ccall f_6449(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6449,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6439(t3,((C_word*)t0)[4],t2);}

/* def-out689 in dump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4608(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_4608,3,t0,t1,t2);}
/* csi.scm:740: body686 */
t3=((C_word*)t0)[2];
f_4502(t3,t1,t2,*((C_word*)lf[91]+1));}

/* for-each-loop1239 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in ... */
static void C_fcall f_6439(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_6439,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6449,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1048: g1240 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a3072 in a3066 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3073,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3079,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:454: k354 */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k6495 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in ... */
static void C_ccall f_6497(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6497,2,av);}
/* csi.scm:1037: exit */
t2=C_fast_retrieve(lf[57]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4729 in k4726 in doloop749 in k4698 in k4695 in k4692 in k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_ccall f_4731(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4731,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_4715(t4,((C_word*)t0)[5],t2,t3);}

/* k4726 in doloop749 in k4698 in k4695 in k4692 in k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_4728(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_4728,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_fixnum_greater_or_equal_p(t1,C_fix(32));
t4=(C_truep(t3)?C_fixnum_lessp(t1,C_fix(128)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_make_character(C_unfix(t1));
/* write-char/port */
t6=C_fast_retrieve(lf[249]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=t5;
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
/* write-char/port */
t5=C_fast_retrieve(lf[249]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=C_make_character(46);
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* a3078 in a3072 in a3066 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3079,2,av);}
/* csi.scm:454: ##sys#error */
t2=*((C_word*)lf[42]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[365];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6485 in k6482 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in ... */
static void C_ccall f_6487(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6487,2,av);}
t2=C_set_block_item(lf[336] /* ##sys#warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_5848(t3,t2);}

/* k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_4706(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4706,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(16));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4681(t3,((C_word*)t0)[4],t2);}

/* k4701 in k4698 in k4695 in k4692 in k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4703(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4703,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_fast_retrieve(lf[249]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6482 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in ... */
static void C_ccall f_6484(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6484,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6487,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=C_set_block_item(lf[336] /* ##sys#warnings-enabled */,0,C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
f_5848(t4,t3);}
else{
/* csi.scm:1039: display */
t3=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[337];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
t2=((C_word*)t0)[2];
f_5848(t2,C_SCHEME_UNDEFINED);}}

/* k4698 in k4695 in k4692 in k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,4))){C_save_and_reclaim((void *)f_4700,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_4715(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* doloop362 in k3097 in a3090 in a3084 in a3066 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_fcall f_3101(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3101,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_eofp(t2))){
/* csi.scm:457: reverse */
t4=*((C_word*)lf[366]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3118,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:455: read */
t5=*((C_word*)lf[60]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k2730 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2732(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2732,2,av);}
/* csi.scm:354: describe */
t2=C_retrieve2(lf[63],"describe");
f_3491(t2,((C_word*)t0)[2],C_fast_retrieve(lf[82]),C_SCHEME_END_OF_LIST);}

/* k3056 in map-loop334 in k3023 in k3020 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3058,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3033(t6,((C_word*)t0)[5],t5);}

/* k6476 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in ... */
static void C_ccall f_6478(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6478,2,av);}
/* csi.scm:1043: print-banner */
f_1944(((C_word*)t0)[2]);}

/* doloop749 in k4698 in k4695 in k4692 in k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4715(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_4715,4,t0,t1,t2,t3);}
a=C_alloc(7);
t4=C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[2]));
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4728,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:788: ref */
t7=((C_word*)t0)[5];{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[6];
av2[3]=t3;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}}

/* def-len688 in dump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4613(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_4613,2,t0,t1);}
/* csi.scm:740: def-out689 */
t2=((C_word*)t0)[2];
f_4608(t2,t1,C_SCHEME_FALSE);}

/* a3084 in a3066 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_3085,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3091,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3124,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:454: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* k6467 in k6464 in k6461 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in ... */
static void C_ccall f_6469(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6469,2,av);}
/* csi.scm:1047: case-sensitive */
t2=C_fast_retrieve(lf[312]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6147 in doloop1413 in k6123 in k6120 in k6114 */
static void C_ccall f_6149(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6149,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_u_i_char_equalp(C_make_character(10),((C_word*)t0)[5]))){
/* csi.scm:1121: display */
t3=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[300];
av2[3]=*((C_word*)lf[299]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6136(t4,((C_word*)t0)[4],t3);}}

/* k6464 in k6461 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in ... */
static void C_ccall f_6466(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6466,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6469,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1046: register-feature! */
t3=C_fast_retrieve(lf[274]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[332];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6461 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in ... */
static void C_ccall f_6463(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6463,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6466,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f7575,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1046: register-feature! */
t4=C_fast_retrieve(lf[274]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[332];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
/* csi.scm:1045: display */
t3=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[333];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_5854(2,av2);}}}

/* doloop733 in k4692 in k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4766(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_4766,4,t0,t1,t2,t3);}
a=C_alloc(10);
t4=C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[2]));
if(C_truep(t5)){
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[2]))){
t6=C_fixnum_modulo(((C_word*)t0)[2],C_fix(16));
t7=C_eqp(t6,C_fix(0));
if(C_truep(t7)){
t8=C_SCHEME_UNDEFINED;
t9=t1;{
C_word av2[2];
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t8=C_fixnum_difference(C_fix(16),t6);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4800,a[2]=t10,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_4800(t12,t1,t8);}}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4820,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* write-char/port */
t7=C_fast_retrieve(lf[249]);{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}

/* k4669 in k4653 in justify in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4671,2,av);}
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[27]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* k4406 in g644 in k4367 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in ... */
static void C_ccall f_4408(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4408,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,C_fix(0));
/* csi.scm:725: append */
t3=*((C_word*)lf[231]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4681(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,5))){
C_save_and_reclaim_args((void *)trf_4681,3,t0,t1,t2);}
a=C_alloc(14);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4691,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4849,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:771: justify */
f_4651(t4,t2,C_fix(4),C_fix(10),C_make_character(32));}}

/* k3292 in k3288 in k3284 in k3280 in k3276 in k3272 in k3268 in k3260 in k3232 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in ... */
static void C_ccall f_3294(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,2))){C_save_and_reclaim((void *)f_3294,2,av);}
a=C_alloc(19);
t2=t1;
t3=C_i_vector_ref(((C_word*)t0)[2],C_fix(2));
t4=t3;
t5=C_i_vector_ref(((C_word*)t0)[3],C_fix(0));
t6=t5;
t7=C_fudge(C_fix(17));
t8=(C_truep(t7)?lf[128]:lf[129]);
t9=t8;
t10=C_i_vector_ref(((C_word*)t0)[3],C_fix(1));
t11=t10;
t12=C_i_vector_ref(((C_word*)t0)[3],C_fix(2));
t13=t12;
t14=C_fudge(C_fix(18));
t15=C_i_nequalp(C_fix(1),t14);
t16=(C_truep(t15)?lf[130]:lf[131]);
t17=t16;
t18=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_3322,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t2,a[13]=t4,a[14]=t6,a[15]=t9,a[16]=t11,a[17]=t13,a[18]=t17,tmp=(C_word)a,a+=19,tmp);
/* csi.scm:529: argv */
t19=((C_word*)t0)[14];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t19;
av2[1]=t18;
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}

/* k3288 in k3284 in k3280 in k3276 in k3272 in k3268 in k3260 in k3232 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in ... */
static void C_ccall f_3290(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_3290,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t4=C_i_vector_ref(((C_word*)t0)[2],C_fix(1));
/* csi.scm:522: shorten */
f_3164(t3,t4);}

/* k6114 */
static void C_ccall f_6116(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6116,2,av);}
a=C_alloc(6);
t2=t1;
t3=C_i_string_length(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:1114: flush-output */
t6=*((C_word*)lf[302]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=*((C_word*)lf[91]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k3284 in k3280 in k3276 in k3272 in k3268 in k3260 in k3232 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in ... */
static void C_ccall f_3286(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_3286,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t4=C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* csi.scm:521: shorten */
f_3164(t3,t4);}

/* f_6112 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in ... */
static void C_ccall f_6112(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_6112,3,av);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6116,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6166,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1112: with-output-to-string */
t5=C_fast_retrieve(lf[303]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3280 in k3276 in k3272 in k3268 in k3260 in k3232 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in ... */
static void C_ccall f_3282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,2))){C_save_and_reclaim((void *)f_3282,2,av);}
a=C_alloc(17);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3344,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:520: keyword-style */
t5=C_fast_retrieve(lf[135]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k6228 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in ... */
static void C_ccall f_6230(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6230,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6233,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
/* csi.scm:1069: parentheses-synonyms */
t3=C_fast_retrieve(lf[310]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
/* csi.scm:1068: display */
t3=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[317];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_5891(2,av2);}}}

/* k2746 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2748(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2748,2,av);}
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* csi.scm:361: printf */
t3=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[85];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in ... */
static void C_ccall f_5900(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5900,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_set_block_item(lf[5] /* ##sys#notices-enabled */,0,C_SCHEME_FALSE);
t4=t2;
f_5903(t4,t3);}
else{
t3=t2;
f_5903(t3,C_SCHEME_UNDEFINED);}}

/* doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in ... */
static void C_fcall f_5908(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(17,0,4))){
C_save_and_reclaim_args((void *)trf_5908,3,t0,t1,t2);}
a=C_alloc(17);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_nullp(((C_word*)t3)[1]))){
if(C_truep(((C_word*)t0)[2])){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5921,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5926,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1085: call/cc */
t6=*((C_word*)lf[108]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}
else{
t4=C_i_car(((C_word*)t3)[1]);
t5=C_i_member(t4,lf[277]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5945,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=C_i_cdr(((C_word*)t3)[1]);
t20=t1;
t21=t7;
t1=t20;
t2=t21;
goto loop;}
else{
if(C_truep((C_truep(C_i_equalp(t4,lf[278]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[279]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[280]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[281]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[282]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[283]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[284]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))))){
t7=C_i_cdr(((C_word*)t3)[1]);
t8=C_set_block_item(t3,0,t7);
t9=C_i_cdr(((C_word*)t3)[1]);
t20=t1;
t21=t9;
t1=t20;
t2=t21;
goto loop;}
else{
t7=C_i_string_equal_p(lf[285],t4);
t8=(C_truep(t7)?t7:C_u_i_string_equal_p(lf[286],t4));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5974,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5988,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=C_i_cadr(((C_word*)t3)[1]);
/* csi.scm:1095: string->symbol */
t12=*((C_word*)lf[288]+1);{
C_word av2[3];
av2[0]=t12;
av2[1]=t10;
av2[2]=t11;
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
t9=C_u_i_string_equal_p(lf[289],t4);
t10=(C_truep(t9)?t9:C_u_i_string_equal_p(lf[290],t4));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6003,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t12=C_i_cadr(((C_word*)t3)[1]);
/* csi.scm:1098: evalstring */
f_5779(t11,t12,C_SCHEME_END_OF_LIST);}
else{
t11=C_u_i_string_equal_p(lf[291],t4);
t12=(C_truep(t11)?t11:C_u_i_string_equal_p(lf[292],t4));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6020,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t14=C_i_cadr(((C_word*)t3)[1]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6028,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1101: evalstring */
f_5779(t13,t14,C_a_i_list(&a,1,t15));}
else{
t13=C_u_i_string_equal_p(lf[293],t4);
t14=(C_truep(t13)?t13:C_u_i_string_equal_p(lf[294],t4));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6043,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t16=C_i_cadr(((C_word*)t3)[1]);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6051,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1104: evalstring */
f_5779(t15,t16,C_a_i_list(&a,1,t17));}
else{
t15=(C_truep(((C_word*)t0)[5])?C_i_car(((C_word*)t0)[5]):C_SCHEME_FALSE);
t16=t15;
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6061,a[2]=t16,a[3]=t6,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_equalp(lf[298],t16))){
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6112,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1108: ##sys#load */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[304]);
C_word av2[5];
av2[0]=*((C_word*)lf[304]+1);
av2[1]=t17;
av2[2]=t4;
av2[3]=t18;
av2[4]=C_SCHEME_FALSE;
tp(5,av2);}}
else{
/* csi.scm:1108: ##sys#load */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[304]);
C_word av2[5];
av2[0]=*((C_word*)lf[304]+1);
av2[1]=t17;
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
av2[4]=C_SCHEME_FALSE;
tp(5,av2);}}}}}}}}}}

/* k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in ... */
static void C_fcall f_5903(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_5903,2,t0,t1);}
a=C_alloc(8);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5908,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5908(t5,((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1]);}

/* k2919 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2921(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2921,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3276 in k3272 in k3268 in k3260 in k3232 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in ... */
static void C_ccall f_3278(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_3278,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* csi.scm:518: repository-path */
t4=C_fast_retrieve(lf[136]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3272 in k3268 in k3260 in k3232 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in ... */
static void C_ccall f_3274(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_3274,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* csi.scm:516: build-platform */
t4=C_fast_retrieve(lf[137]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6219 in k6216 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in ... */
static void C_ccall f_6221(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6221,2,av);}
/* csi.scm:1072: symbol-escape */
t2=C_fast_retrieve(lf[309]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3268 in k3260 in k3232 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in ... */
static void C_ccall f_3270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_3270,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* csi.scm:515: software-version */
t4=C_fast_retrieve(lf[138]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4261 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_4263(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_4263,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_i_check_list_2(t3,lf[106]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4332,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4332(t8,((C_word*)t0)[4],t3);}

/* g604 in k4261 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_fcall f_4264(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_4264,3,t0,t1,t2);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:709: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[228];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k6231 in k6228 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in ... */
static void C_ccall f_6233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6233,2,av);}
/* csi.scm:1069: parentheses-synonyms */
t2=C_fast_retrieve(lf[310]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* loop in k4266 in g604 in k4261 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in ... */
static void C_fcall f_4277(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(13,0,3))){
C_save_and_reclaim_args((void *)trf_4277,3,t0,t1,t2);}
a=C_alloc(13);
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4287,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_caar(t2);
t5=C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4300,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4305,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:713: ##sys#with-print-length-limit */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[93]);
C_word av2[4];
av2[0]=*((C_word*)lf[93]+1);
av2[1]=t6;
av2[2]=C_fix(100);
av2[3]=t7;
tp(4,av2);}}
else{
t6=C_i_cddr(t2);
/* csi.scm:718: loop */
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}}

/* k5919 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in ... */
static void C_ccall f_5921(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5921,2,av);}
/* csi.scm:1089: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[95]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[95]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=*((C_word*)lf[91]+1);
tp(4,av2);}}

/* ##sys#quit-hook in a5925 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in ... */
static void C_ccall f_5929(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5929,2,av);}
/* csi.scm:1087: k */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* a5925 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in ... */
static void C_ccall f_5926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5926,3,av);}
a=C_alloc(3);
t3=C_mutate2((C_word*)lf[70]+1 /* (set! ##sys#quit-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5929,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
/* csi.scm:1088: repl */
t4=C_fast_retrieve(lf[276]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=C_retrieve2(lf[56],"csi-eval");
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2905 in for-each-loop293 in k2868 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2907(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2907,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2897(t3,((C_word*)t0)[4],t2);}

/* k4266 in g604 in k4261 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in ... */
static void C_ccall f_4268(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4268,2,av);}
a=C_alloc(7);
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4277,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4277(t6,((C_word*)t0)[5],t2);}

/* k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_1893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_1893,2,av);}
a=C_alloc(6);
t2=C_mutate2(&lf[0] /* (set! constant8 ...) */,lf[1]);
t3=C_set_block_item(lf[2] /* ##sys#repl-print-length-limit */,0,C_fix(2048));
t4=C_a_i_cons(&a,2,lf[3],C_fast_retrieve(lf[4]));
t5=C_mutate2((C_word*)lf[4]+1 /* (set! ##sys#features ...) */,t4);
t6=C_set_block_item(lf[5] /* ##sys#notices-enabled */,0,C_SCHEME_TRUE);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:66: make-parameter */
t8=C_fast_retrieve(lf[404]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k5972 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in ... */
static void C_ccall f_5974(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5974,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_u_i_cdr(t2));
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_5908(t5,((C_word*)t0)[4],t4);}

/* k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_1890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1890,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_extras_toplevel(2,av2);}}

/* hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4648(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,6))){
C_save_and_reclaim_args((void *)trf_4648,5,t1,t2,t3,t4,t5);}
a=C_alloc(12);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4651,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4681,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t4,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_4681(t10,t1,C_fix(0));}

/* map-loop649 in g644 in k4367 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in ... */
static void C_fcall f_4414(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4414,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4439,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:725: g655 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4691(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_4691,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* write-char/port */
t3=C_fast_retrieve(lf[249]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(58);
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4692 in k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,4))){C_save_and_reclaim((void *)f_4694,2,av);}
a=C_alloc(19);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4766(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* k1882 in k1879 */
static void C_ccall f_1884(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1884,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1887,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_chicken_2dsyntax_toplevel(2,av2);}}

/* k2702 in a2699 in k2687 in a2684 in k2678 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2704(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2704,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
C_apply_values(3,av2);}}

/* a2699 in k2687 in a2684 in k2678 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +7,c,2))){
C_save_and_reclaim((void*)f_2700,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+7);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2704,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2711,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:347: ##sys#stop-timer */
t5=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k1885 in k1882 in k1879 */
static void C_ccall f_1887(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1887,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1890,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_ports_toplevel(2,av2);}}

/* k2784 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2786(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2786,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1879 */
static void C_ccall f_1881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1881,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k4695 in k4692 in k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4697(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_4697,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* write-char/port */
t3=C_fast_retrieve(lf[249]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5943 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in ... */
static void C_ccall f_5945(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5945,2,av);}
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_5908(t3,((C_word*)t0)[4],t2);}

/* k4285 in loop in k4266 in g604 in k4261 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in ... */
static void C_ccall f_4287(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4287,2,av);}
t2=C_i_cddr(((C_word*)t0)[2]);
/* csi.scm:718: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4277(t3,((C_word*)t0)[4],t2);}

/* a2712 in k2678 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2713(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +5,c,2))){
C_save_and_reclaim((void*)f_2713,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+5);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2717,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:349: history-add */
t4=C_retrieve2(lf[40],"history-add");
f_2222(t4,t3,t2);}

/* k2709 in a2699 in k2687 in a2684 in k2678 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2711(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2711,2,av);}
/* csi.scm:347: ##sys#display-times */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[78]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[78]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* k2796 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2798(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2798,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2715 in a2712 in k2678 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2717(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2717,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
C_apply(4,av2);}}

/* k2764 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2766(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2766,2,av);}
/* csi.scm:356: system */
t2=C_fast_retrieve(lf[86]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a3066 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3067(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_3067,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3073,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3085,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:454: with-exception-handler */
t5=C_fast_retrieve(lf[367]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k4481 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4483(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4483,2,av);}
/* csi.scm:599: fprintf */
t2=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[239];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4886(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,4))){
C_save_and_reclaim_args((void *)trf_4886,4,t0,t1,t2,t3);}
a=C_alloc(14);
if(C_truep(C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_i_car(t2);
t5=t4;
t6=C_eqp(C_retrieve2(lf[7],"selected-frame"),t5);
t7=t6;
t8=C_slot(t5,C_fix(1));
t9=t8;
t10=C_slot(t5,C_fix(2));
t11=t10;
t12=C_i_structurep(t11,lf[104]);
t13=t12;
t14=(C_truep(t13)?C_slot(t11,C_fix(1)):t11);
t15=t14;
t16=*((C_word*)lf[91]+1);
t17=*((C_word*)lf[91]+1);
t18=C_i_check_port_2(*((C_word*)lf[91]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[84]);
t19=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4917,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t7,a[7]=t13,a[8]=((C_word*)t0)[3],a[9]=t11,a[10]=t9,a[11]=t15,a[12]=t16,a[13]=t5,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t7)){
/* csi.scm:813: ##sys#print */
t20=*((C_word*)lf[92]+1);{
C_word av2[5];
av2[0]=t20;
av2[1]=t19;
av2[2]=C_make_character(42);
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[91]+1);
((C_proc)(void*)(*((C_word*)t20+1)))(5,av2);}}
else{
/* csi.scm:813: ##sys#print */
t20=*((C_word*)lf[92]+1);{
C_word av2[5];
av2[0]=t20;
av2[1]=t19;
av2[2]=C_make_character(32);
av2[3]=C_SCHEME_FALSE;
av2[4]=t16;
((C_proc)(void*)(*((C_word*)t20+1)))(5,av2);}}}}

/* k2775 in k2768 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2777(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_2777,2,av);}
/* csi.scm:357: string-append */
t2=*((C_word*)lf[30]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[87];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k2768 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2770(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2770,2,av);}
a=C_alloc(4);
t2=(C_truep(t1)?t1:C_retrieve2(lf[8],"default-editor"));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2777,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:359: read-line */
t5=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k4450 in k4367 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_ccall f_4452(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_4452,2,av);}
/* csi.scm:728: descseq */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_FALSE;
av2[3]=*((C_word*)lf[173]+1);
av2[4]=*((C_word*)lf[175]+1);
av2[5]=C_fix(1);
f_3497(6,av2);}}

/* k3097 in a3090 in a3084 in a3066 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_3099,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3101,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3101(t5,((C_word*)t0)[3],t1,C_SCHEME_END_OF_LIST);}

/* a3090 in a3084 in a3066 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3091(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3091,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3099,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:455: read */
t3=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5418 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5420(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5420,2,av);}
t2=((C_word*)t0)[2];
f_5193(t2,C_SCHEME_FALSE);}

/* k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5423(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,4))){C_save_and_reclaim((void *)f_5423,2,av);}
a=C_alloc(15);
t2=C_establish_signal_handler(C_fix((C_word)SIGINT),C_fix((C_word)SIGINT));
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6700,tmp=(C_word)a,a+=2,tmp);
t4=C_i_setslot(C_fast_retrieve(lf[259]),C_fix((C_word)SIGINT),t3);
t5=C_mutate2(&lf[260] /* (set! member* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5428,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2(&lf[261] /* (set! canonicalize-args ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5483,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6692,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5662,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6686,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:977: get-environment-variable */
t11=C_fast_retrieve(lf[36]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[369];
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}

/* k5986 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in ... */
static void C_ccall f_5988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_5988,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,1,t1);
t3=C_a_i_list(&a,3,lf[287],t2,C_SCHEME_TRUE);
/* csi.scm:1095: eval */
t4=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* member* in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5428(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_5428,3,t1,t2,t3);}
a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5434,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5434(t7,t1,t3);}

/* k2975 in a2972 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2977(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2977,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
C_apply(4,av2);}}

/* k2078 in k2072 in k2069 in addext in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2080(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2080,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=(C_truep(t1)?((C_word*)t0)[3]:C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5599 in k5509 in loop in canonicalize-args in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5601(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_5601,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a2972 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2973(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +5,c,2))){
C_save_and_reclaim((void*)f_2973,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+5);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2977,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:417: history-add */
t4=C_retrieve2(lf[40],"history-add");
f_2222(t4,t3,t2);}

/* canonicalize-args in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5483(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_5483,2,t1,t2);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5489,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5489(t6,t1,t2);}

/* loop in canonicalize-args in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5489(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_5489,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=t3;
if(C_truep((C_truep(C_i_equalp(t4,lf[262]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[263]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[264]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[265]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[266]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5511,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=C_block_size(t4);
if(C_truep(C_fixnum_greaterp(t6,C_fix(2)))){
t7=C_subchar(t4,C_fix(0));
if(C_truep(C_i_char_equalp(C_make_character(45),t7))){
t8=C_i_member(t4,lf[269]);
t9=t5;
f_5511(t9,C_i_not(t8));}
else{
t8=t5;
f_5511(t8,C_SCHEME_FALSE);}}
else{
t7=t5;
f_5511(t7,C_SCHEME_FALSE);}}}}

/* set-describer! in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4491(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4491,4,av);}
t4=C_i_check_symbol_2(t2,lf[241]);
/* csi.scm:734: ##sys#hash-table-set! */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[242]);
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[242]+1);
av2[1]=t1;
av2[2]=C_retrieve2(lf[149],"describer-table");
av2[3]=t2;
av2[4]=t3;
tp(5,av2);}}

/* addext in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_2064(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_2064,2,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2071,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:191: file-exists? */
t4=C_fast_retrieve(lf[26]);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a2966 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2967(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2967,2,av);}
/* csi.scm:416: eval */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2072 in k2069 in addext in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2074(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2074,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2080,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:194: file-exists? */
t4=C_fast_retrieve(lf[26]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2069 in addext in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2071(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_2071,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2074,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[27]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=t2;
av2[2]=t3;
av2[3]=lf[28];
tp(4,av2);}}}

/* loop in member* in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5434(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_5434,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_i_pairp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5446,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5446(t6,t1,((C_word*)t0)[3]);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5271 in doloop903 in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5273(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5273,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)((C_word*)t0)[3])[1];
f_5248(t4,((C_word*)t0)[4],t3);}

/* k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_2999,2,av);}
a=C_alloc(14);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3022,a[2]=t5,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3067,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:454: call-with-current-continuation */
t9=*((C_word*)lf[368]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}

/* k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2993(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_2993,2,av);}
a=C_alloc(6);
t2=C_fast_retrieve(lf[116]);
t3=C_fast_retrieve(lf[117]);
t4=C_fast_retrieve(lf[118]);
t5=C_fast_retrieve(lf[119]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3138,a[2]=t5,a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:470: get-environment-variable */
t7=C_fast_retrieve(lf[36]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[381];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* justify in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4651(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_4651,5,t1,t2,t3,t4,t5);}
a=C_alloc(5);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4655,a[2]=t3,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:763: number->string */
t7=*((C_word*)lf[248]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k4653 in justify in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4655(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_4655,2,av);}
a=C_alloc(4);
t2=t1;
t3=C_block_size(t2);
if(C_truep(C_fixnum_lessp(t3,((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4671,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_fixnum_difference(((C_word*)t0)[2],t3);
/* csi.scm:766: make-string */
t6=*((C_word*)lf[122]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a3827 in k3811 in doloop538 in k3796 in k3784 in k3781 in k3778 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in ... */
static void C_ccall f_3828(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3828,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
/* csi.scm:641: write */
t3=*((C_word*)lf[178]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* doloop1413 in k6123 in k6120 in k6114 */
static void C_fcall f_6136(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_6136,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_i_string_ref(((C_word*)t0)[3],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6149,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t6=C_fast_retrieve(lf[249]);{
C_word av2[4];
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
av2[3]=*((C_word*)lf[299]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}

/* k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_ccall f_5683(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_5683,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_5686(t3,((C_word*)t0)[4]);}
else{
if(C_truep(t1)){
t3=t1;
t4=t2;
f_5686(t4,t3);}
else{
t3=t2;
f_5686(t3,((C_word*)t0)[6]);}}}

/* k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in ... */
static void C_fcall f_5686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(20,0,2))){
C_save_and_reclaim_args((void *)trf_5686,2,t0,t1);}
a=C_alloc(20);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_retrieve2(lf[23],"chop-separator");
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5692,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=t7,a[11]=t6,tmp=(C_word)a,a+=12,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6564,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1006: get-environment-variable */
t10=C_fast_retrieve(lf[36]);{
C_word av2[3];
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[351];
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_fcall f_5680(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_5680,2,t0,t1);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5683,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:1002: member* */
f_5428(t3,lf[352],((C_word*)((C_word*)t0)[2])[1]);}

/* k6129 in k6126 in k6123 in k6120 in k6114 */
static void C_ccall f_6131(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6131,2,av);}
/* csi.scm:1123: eval */
t2=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6126 in k6123 in k6120 in k6114 */
static void C_ccall f_6128(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6128,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1122: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[299]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6123 in k6120 in k6114 */
static void C_ccall f_6125(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_6125,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6136,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6136(t6,t2,C_fix(0));}

/* k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in ... */
static void C_ccall f_5695(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,4))){C_save_and_reclaim((void *)f_5695,2,av);}
a=C_alloc(24);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5779,tmp=(C_word)a,a+=2,tmp));
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5836,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6520,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1027: member* */
f_5428(t10,lf[348],((C_word*)((C_word*)t0)[2])[1]);}

/* k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in ... */
static void C_ccall f_5692(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_5692,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5695,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6528,a[2]=((C_word*)t0)[9],a[3]=t4,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_6528(t6,t2,t1);}

/* loop in k2129 in k2117 in lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_2093(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_2093,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2106,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_subchar(((C_word*)t0)[4],t2);
/* csi.scm:199: proc */
t5=((C_word*)t0)[5];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}}

/* k6295 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in ... */
static void C_ccall f_6297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6297,2,av);}
/* csi.scm:1052: ##sys#nodups */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[325]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[325]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=*((C_word*)lf[326]+1);
tp(4,av2);}}

/* collect-options in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in ... */
static void C_fcall f_5697(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_5697,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5703,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5703(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k6120 in k6114 */
static void C_ccall f_6122(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_6122,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:1115: display */
t3=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[301];
av2[3]=*((C_word*)lf[299]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* doloop538 in k3796 in k3784 in k3781 in k3778 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_fcall f_3803(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_3803,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3813,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(t2);
/* csi.scm:637: fprintf */
t5=*((C_word*)lf[153]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[179];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* k6150 in k6147 in doloop1413 in k6123 in k6120 in k6114 */
static void C_ccall f_6152(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6152,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6136(t3,((C_word*)t0)[4],t2);}

/* k3238 in k3235 in k3232 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in ... */
static void C_ccall f_3240(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3240,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fudge(C_fix(14)))){
/* csi.scm:531: display */
t3=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[125];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_3243(2,av2);}}}

/* k3241 in k3238 in k3235 in k3232 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in ... */
static void C_ccall f_3243(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3243,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3246,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fudge(C_fix(15)))){
/* csi.scm:532: display */
t3=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[124];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3244 in k3241 in k3238 in k3235 in k3232 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in ... */
static void C_ccall f_3246(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3246,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5674(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_5674,2,t0,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:1000: member* */
f_5428(t2,lf[354],((C_word*)((C_word*)t0)[2])[1]);}

/* k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5677(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_5677,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_5680(t4,((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6573,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1001: member* */
f_5428(t4,lf[353],((C_word*)((C_word*)t0)[2])[1]);}}

/* k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_5671,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5674,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6579,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cdr(t2);
t6=C_i_pairp(t5);
t7=C_i_not(t6);
if(C_truep(t7)){
if(C_truep(t7)){
/* csi.scm:986: ##sys#error */
t8=*((C_word*)lf[42]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t4;
av2[2]=lf[358];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t8=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_UNDEFINED;
f_6579(2,av2);}}}
else{
t8=C_i_cadr(t2);
t9=C_i_string_length(t8);
t10=C_eqp(t9,C_fix(0));
if(C_truep(t10)){
if(C_truep(t10)){
/* csi.scm:986: ##sys#error */
t11=*((C_word*)lf[42]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t4;
av2[2]=lf[358];
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t11=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=C_SCHEME_UNDEFINED;
f_6579(2,av2);}}}
else{
t11=C_u_i_cdr(t2);
t12=C_u_i_car(t11);
t13=C_i_string_ref(t12,C_fix(0));
if(C_truep(C_u_i_char_equalp(C_make_character(45),t13))){
/* csi.scm:986: ##sys#error */
t14=*((C_word*)lf[42]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t14;
av2[1]=t4;
av2[2]=lf[358];
((C_proc)(void*)(*((C_word*)t14+1)))(3,av2);}}
else{
t14=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_SCHEME_UNDEFINED;
f_6579(2,av2);}}}}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6665,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6678,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:997: canonicalize-args */
f_5483(t5,((C_word*)t0)[5]);}}

/* k3232 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_3234(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_3234,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3262,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:512: machine-type */
t4=C_fast_retrieve(lf[140]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3235 in k3232 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_ccall f_3237(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3237,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3240,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:530: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[95]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[95]+1);
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=*((C_word*)lf[91]+1);
tp(4,av2);}}

/* find in loop in member* in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5446(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_5446,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_i_cdr(((C_word*)t0)[2]);
/* csi.scm:929: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5434(t4,t1,t3);}
else{
t3=C_i_car(t2);
t4=C_i_car(((C_word*)t0)[2]);
if(C_truep(C_i_equalp(t3,t4))){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=t2;
t6=C_u_i_cdr(t5);
/* csi.scm:931: find */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* k3814 in k3811 in doloop538 in k3796 in k3784 in k3781 in k3778 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in ... */
static void C_ccall f_3816(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3816,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:642: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3817 in k3814 in k3811 in doloop538 in k3796 in k3784 in k3781 in k3778 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in ... */
static void C_ccall f_3819(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3819,2,av);}
t2=C_i_cddr(((C_word*)t0)[2]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3803(t3,((C_word*)t0)[4],t2);}

/* k3811 in doloop538 in k3796 in k3784 in k3781 in k3778 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_ccall f_3813(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_3813,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:638: ##sys#with-print-length-limit */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[93]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[93]+1);
av2[1]=t2;
av2[2]=C_fix(1000);
av2[3]=t3;
tp(4,av2);}}

/* k3215 in k3198 in k3185 in g423 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in ... */
static void C_ccall f_3217(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3217,2,av);}
/* csi.scm:495: display */
t2=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3198 in k3185 in g423 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in ... */
static void C_fcall f_3200(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_3200,2,t0,t1);}
a=C_alloc(4);
if(C_truep(C_i_greater_or_equalp(((C_word*)((C_word*)t0)[2])[1],C_fix(3)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:492: display */
t3=*((C_word*)lf[99]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[121];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3217,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:495: make-string */
t3=*((C_word*)lf[122]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
av2[3]=C_make_character(32);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k3207 in k3198 in k3185 in g423 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in ... */
static void C_ccall f_3209(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3209,2,av);}
t2=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_3876(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,5))){
C_save_and_reclaim_args((void *)trf_3876,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:644: fprintf */
t3=*((C_word*)lf[153]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[194];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
/* csi.scm:654: descseq */
t2=((C_word*)t0)[5];{
C_word av2[6];
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[195];
av2[3]=((C_word*)t0)[6];
av2[4]=((C_word*)t0)[7];
av2[5]=C_fix(0);
f_3497(6,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
/* csi.scm:655: fprintf */
t6=*((C_word*)lf[153]+1);{
C_word av2[6];
av2[0]=t6;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[196];
av2[4]=t3;
av2[5]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(6,av2);}}
else{
if(C_truep(C_i_closurep(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3983,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3987,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:659: ##sys#peek-unsigned-integer */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[199]);
C_word av2[4];
av2[0]=*((C_word*)lf[199]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(0);
tp(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:661: port? */
t3=C_fast_retrieve(lf[237]);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}}}}

/* k3877 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3879(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_3879,2,av);}
a=C_alloc(9);
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3888,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3888(t6,((C_word*)t0)[4],((C_word*)t0)[2],t2);}

/* loop in k5523 in k5509 in loop in canonicalize-args in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static C_word C_fcall f_5632(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;
loop:{}
t2=C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=C_i_car(t1);
if(C_truep((C_truep(C_eqp(t3,C_make_character(107)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(115)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(118)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(104)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(68)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(101)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(105)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(82)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(98)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(110)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(113)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(119)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(45)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(73)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(112)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(80)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))))){
t4=t1;
t5=C_u_i_cdr(t4);
t7=t5;
t1=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* k3630 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3632(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3632,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4437 in map-loop649 in g644 in k4367 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in ... */
static void C_ccall f_4439(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4439,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4414(t6,((C_word*)t0)[5],t5);}

/* k3020 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3022(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3022,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:454: g358 */
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)C_fast_retrieve_proc(t3))(2,av2);}}

/* k3023 in k3020 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3025(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_3025,2,av);}
a=C_alloc(7);
t2=C_i_check_list_2(t1,lf[230]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_3033(t6,((C_word*)t0)[4],t1);}

/* k6901 in k6891 in a6884 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6903(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6903,2,av);}
/* csi.scm:261: sprintf */
t2=*((C_word*)lf[197]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[393];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6905 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6907(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6907,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_1914(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6916,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:72: get-environment-variable */
t3=C_fast_retrieve(lf[36]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[401];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k3609 in loop2 in k3530 in loop1 in k3502 in k3624 in descseq in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_3611(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3611,2,av);}
t2=C_eqp(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* csi.scm:596: loop2 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3541(t5,((C_word*)t0)[6],t3,t4);}
else{
/* csi.scm:597: loop2 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3541(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[7]);}}

/* loop-print in k3877 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_3888(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_3888,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_not_pair_p(t2);
t5=(C_truep(t4)?t4:C_i_nullp(t2));
if(C_truep(t5)){
/* csi.scm:648: printf */
t6=*((C_word*)lf[84]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t1;
av2[2]=lf[191];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=C_i_car(t2);
if(C_truep(C_i_memq(t6,t3))){
/* csi.scm:650: fprintf */
t7=*((C_word*)lf[153]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[192];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t7=t2;
t8=C_u_i_car(t7);
if(C_truep(C_i_memq(t8,t3))){
t9=C_SCHEME_UNDEFINED;
t10=t1;{
C_word av2[2];
av2[0]=t10;
av2[1]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3919,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t10=t2;
t11=C_u_i_car(t10);
/* csi.scm:652: fprintf */
t12=*((C_word*)lf[153]+1);{
C_word av2[5];
av2[0]=t12;
av2[1]=t9;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[193];
av2[4]=t11;
((C_proc)(void*)(*((C_word*)t12+1)))(5,av2);}}}}}

/* k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5668,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:981: member* */
f_5428(t3,lf[360],((C_word*)((C_word*)t0)[2])[1]);}

/* k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5665(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_5665,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5668,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:980: member* */
f_5428(t4,lf[361],((C_word*)t3)[1]);}

/* k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5662(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5662,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5665,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6682,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:978: command-line-arguments */
t5=C_fast_retrieve(lf[297]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* g918 in doloop903 in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5282(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_5282,4,t0,t1,t2,t3);}
a=C_alloc(8);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5288,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5288(t7,t1,C_fix(0),t2);}

/* k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3629(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,7))){C_save_and_reclaim((void *)f_3629,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3632,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_charp(((C_word*)t0)[3]))){
t3=C_fix(C_character_code(((C_word*)t0)[3]));
/* csi.scm:602: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[160];
av2[4]=((C_word*)t0)[3];
av2[5]=t3;
av2[6]=t3;
av2[7]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(8,av2);}}
else{
switch(((C_word*)t0)[3]){
case C_SCHEME_TRUE:
/* csi.scm:603: fprintf */
t3=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[161];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}
case C_SCHEME_FALSE:
/* csi.scm:604: fprintf */
t3=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[162];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}
default:
if(C_truep(C_i_nullp(((C_word*)t0)[3]))){
/* csi.scm:605: fprintf */
t3=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[163];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
if(C_truep(C_eofp(((C_word*)t0)[3]))){
/* csi.scm:606: fprintf */
t3=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[164];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=*((C_word*)lf[41]+1);
t4=C_eqp(*((C_word*)lf[41]+1),((C_word*)t0)[3]);
if(C_truep(t4)){
/* csi.scm:607: fprintf */
t5=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[165];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
if(C_truep(C_fixnump(((C_word*)t0)[3]))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3698,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:609: fprintf */
t6=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[167];
av2[4]=((C_word*)t0)[3];
av2[5]=((C_word*)t0)[3];
av2[6]=((C_word*)t0)[3];
av2[7]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(8,av2);}}
else{
t5=C_slot(lf[168],C_fix(0));
t6=C_eqp(((C_word*)t0)[3],t5);
if(C_truep(t6)){
/* csi.scm:614: fprintf */
t7=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[169];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
if(C_truep(C_i_flonump(((C_word*)t0)[3]))){
/* csi.scm:615: fprintf */
t7=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[170];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
if(C_truep(C_i_numberp(((C_word*)t0)[3]))){
/* csi.scm:616: fprintf */
t7=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[171];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
/* csi.scm:617: descseq */
t7=((C_word*)t0)[5];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=lf[172];
av2[3]=*((C_word*)lf[173]+1);
av2[4]=((C_word*)t0)[6];
av2[5]=C_fix(0);
f_3497(6,av2);}}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[3]))){
/* csi.scm:618: descseq */
t7=((C_word*)t0)[5];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=lf[174];
av2[3]=*((C_word*)lf[173]+1);
av2[4]=*((C_word*)lf[175]+1);
av2[5]=C_fix(0);
f_3497(6,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3764,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* csi.scm:619: keyword? */
t8=C_fast_retrieve(lf[238]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}}}}}}}}}}}}

/* doloop931 in g918 in doloop903 in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5288(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,2))){
C_save_and_reclaim_args((void *)trf_5288,4,t0,t1,t2,t3);}
a=C_alloc(15);
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5298,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5310,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t6=C_i_car(t3);
/* csi.scm:897: compare */
t7=((C_word*)t0)[5];
f_5195(t7,t5,t6);}}

/* k3624 in descseq in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3626(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,5))){C_save_and_reclaim((void *)f_3626,2,av);}
a=C_alloc(8);
t2=C_fixnum_difference(t1,((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3504,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
/* csi.scm:577: fprintf */
t5=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[159];
av2[4]=((C_word*)t0)[7];
av2[5]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_3504(2,av2);}}}

/* k5296 in doloop931 in g918 in doloop903 in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5298(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5298,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=((C_word*)((C_word*)t0)[4])[1];
f_5288(t5,((C_word*)t0)[5],t2,t4);}

/* k3862 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3864(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3864,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_3780(2,av2);}}
else{
/* csi.scm:624: display */
t2=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[189];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* map-loop334 in k3023 in k3020 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_3033(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,2))){
C_save_and_reclaim_args((void *)trf_3033,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3058,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
if(C_truep(C_i_stringp(t6))){
t7=t5;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3013,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:451: open-output-string */
t8=C_fast_retrieve(lf[364]);{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3859 in k3781 in k3778 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3861(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3861,2,av);}
a=C_alloc(6);
t2=(C_truep(t1)?lf[181]:lf[182]);
t3=t2;
t4=(C_truep(((C_word*)t0)[2])?lf[183]:lf[184]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm:630: ##sys#symbol->qualified-string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[186]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[186]+1);
av2[1]=t6;
av2[2]=((C_word*)t0)[5];
tp(3,av2);}}
else{
/* csi.scm:631: ##sys#symbol->string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[177]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[177]+1);
av2[1]=t6;
av2[2]=((C_word*)t0)[5];
tp(3,av2);}}}

/* k2297 in k2294 in k2291 in k2288 in doloop120 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2299(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2299,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2302,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:247: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2294 in k2291 in k2288 in doloop120 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2296(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_2296,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2311,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:243: ##sys#with-print-length-limit */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[93]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[93]+1);
av2[1]=t2;
av2[2]=C_fix(80);
av2[3]=t3;
tp(4,av2);}}

/* k2288 in doloop120 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2290(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2290,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:238: ##sys#print */
t3=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2291 in k2288 in doloop120 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2293,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2296,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:238: ##sys#print */
t3=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[94];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* doloop903 in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5248(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(20,0,4))){
C_save_and_reclaim_args((void *)trf_5248,3,t0,t1,t2);}
a=C_alloc(20);
if(C_truep(C_i_nullp(t2))){
/* csi.scm:885: fail */
t3=((C_word*)t0)[2];
f_5229(t3,t1,lf[103]);}
else{
t3=C_i_car(t2);
t4=C_eqp(C_retrieve2(lf[7],"selected-frame"),t3);
t5=C_slot(t3,C_fix(2));
t6=C_i_structurep(t5,lf[104]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5273,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(C_truep(t4)?t6:C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5282,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t10=C_slot(t5,C_fix(2));
t11=C_slot(t5,C_fix(3));
t12=C_i_check_list_2(t10,lf[106]);
t13=C_i_check_list_2(t11,lf[106]);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5358,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5367,a[2]=t16,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t18=((C_word*)t16)[1];
f_5367(t18,t14,t10,t11);}
else{
t9=t2;
t10=C_u_i_cdr(t9);
t19=t1;
t20=t10;
t1=t19;
t2=t20;
goto loop;}}}

/* k3011 in map-loop334 in k3023 in k3020 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3013(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_3013,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3016,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:452: write */
t4=*((C_word*)lf[178]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3014 in k3011 in map-loop334 in k3023 in k3020 in k2997 in k6684 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_3016(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3016,2,av);}
/* csi.scm:453: get-output-string */
t2=C_fast_retrieve(lf[363]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* doloop120 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_2277(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_2277,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_greater_or_equalp(t2,C_retrieve2(lf[18],"history-count")))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=*((C_word*)lf[91]+1);
t4=*((C_word*)lf[91]+1);
t5=C_i_check_port_2(*((C_word*)lf[91]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[84]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2290,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:238: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[95]);
C_word av2[4];
av2[0]=*((C_word*)lf[95]+1);
av2[1]=t6;
av2[2]=C_make_character(35);
av2[3]=*((C_word*)lf[91]+1);
tp(4,av2);}}}

/* k6183 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in ... */
static void C_ccall f_6185(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6185,2,av);}
a=C_alloc(3);
t2=(C_truep(t1)?t1:(C_truep(((C_word*)t0)[2])?((C_word*)t0)[2]:((C_word*)t0)[3]));
if(C_truep(t2)){
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5900(2,av2);}}
else{
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5748,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1017: get-environment-variable */
t5=C_fast_retrieve(lf[36]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[307];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k3402 in map-loop396 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_3404(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3404,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3379(t6,((C_word*)t0)[5],t5);}

/* fail in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5229(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_5229,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5233,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:881: display */
t4=*((C_word*)lf[99]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6914 in k6905 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6916(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6916,2,av);}
t2=((C_word*)t0)[2];
f_1914(t2,(C_truep(t1)?lf[399]:lf[400]));}

/* k4164 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_4166(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4166,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(4));
/* csi.scm:694: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[222];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4167 in k4164 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_ccall f_4169(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_4169,2,av);}
a=C_alloc(8);
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=t2;
t4=C_block_size(t3);
t5=t4;
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4180,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4180(t9,((C_word*)t0)[4],C_fix(0));}

/* a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5226(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_5226,3,av);}
a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5229,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5248,a[2]=t3,a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_5248(t7,t1,((C_word*)t0)[4]);}

/* k3850 in k3859 in k3781 in k3778 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_3852,2,av);}
/* csi.scm:626: fprintf */
t2=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[185];
av2[4]=((C_word*)t0)[4];
av2[5]=((C_word*)t0)[5];
av2[6]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* k5231 in fail in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5233,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:882: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5234 in k5231 in fail in a5225 in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5236(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5236,2,av);}
t2=*((C_word*)lf[41]+1);
/* csi.scm:883: return */
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=*((C_word*)lf[41]+1);
((C_proc)C_fast_retrieve_proc(t3))(3,av2);}}

/* k5204 in compare in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5206(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5206,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_string_equal_p(((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5079 in k5076 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in ... */
static void C_ccall f_5081(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5081,2,av);}
/* csi.scm:827: ##sys#print */
t2=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[254];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4226 in for-each-loop581 in doloop576 in k4167 in k4164 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in ... */
static void C_ccall f_4228(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4228,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4218(t3,((C_word*)t0)[4],t2);}

/* g820 in k4942 in k4939 in k4936 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in ... */
static void C_fcall f_4960(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4960,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4970,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:834: display */
t5=*((C_word*)lf[99]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[253];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k2129 in k2117 in lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2131(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_2131,2,av);}
a=C_alloc(15);
if(C_truep(t1)){
/* csi.scm:204: addext */
f_2064(((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_retrieve2(lf[21],"dirseparator\077");
t4=((C_word*)t0)[4];
t5=C_block_size(t4);
t6=t5;
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2093,a[2]=t6,a[3]=t8,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_2093(t10,t2,C_fix(0));}}

/* k4968 in g820 in k4942 in k4939 in k4936 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in ... */
static void C_ccall f_4970(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4970,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4975,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4975(t5,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[5]);}

/* doloop833 in k4968 in g820 in k4942 in k4939 in k4936 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in ... */
static void C_fcall f_4975(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,4))){
C_save_and_reclaim_args((void *)trf_4975,4,t0,t1,t2,t3);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=*((C_word*)lf[91]+1);
t5=*((C_word*)lf[91]+1);
t6=C_i_check_port_2(*((C_word*)lf[91]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[84]);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4988,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
/* csi.scm:835: ##sys#print */
t8=*((C_word*)lf[92]+1);{
C_word av2[5];
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[252];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[91]+1);
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}}

/* a6165 */
static void C_ccall f_6166(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6166,2,av);}
t2=C_fast_retrieve(lf[54]);
/* csi.scm:1112: g1410 */
t3=C_fast_retrieve(lf[54]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4945 in k4942 in k4939 in k4936 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in ... */
static void C_ccall f_4947(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4947,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t5=((C_word*)((C_word*)t0)[4])[1];
f_4886(t5,((C_word*)t0)[5],t3,t4);}

/* k4207 in doloop576 in k4167 in k4164 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in ... */
static void C_ccall f_4209(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4209,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4180(t3,((C_word*)t0)[4],t2);}

/* k2141 in k2138 in k2129 in k2117 in lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2143(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_2143,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2154,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:207: chop-separator */
t4=C_retrieve2(lf[23],"chop-separator");{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t1;
f_2014(3,av2);}}

/* k2138 in k2129 in k2117 in lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2140(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_2140,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_truep(((C_word*)t0)[5])?C_i_foreign_block_argumentp(((C_word*)t0)[5]):C_SCHEME_FALSE);
t5=C_i_foreign_fixnum_argumentp(C_fix(256));
t6=stub63(t3,t4,t5);
/* csi.scm:189: ##sys#peek-nonnull-c-string */
t7=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=t6;
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2157,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:208: addext */
f_2064(t2,((C_word*)t0)[4]);}}

/* k4939 in k4936 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in ... */
static void C_ccall f_4941(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_4941,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* csi.scm:829: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4942 in k4939 in k4936 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in ... */
static void C_ccall f_4944(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,4))){C_save_and_reclaim((void *)f_4944,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep(((C_word*)t0)[6])?((C_word*)t0)[7]:C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4960,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t5=C_slot(((C_word*)t0)[9],C_fix(2));
t6=C_slot(((C_word*)t0)[9],C_fix(3));
t7=C_i_check_list_2(t5,lf[106]);
t8=C_i_check_list_2(t6,lf[106]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5034,a[2]=t10,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_5034(t12,t2,t5,t6);}
else{
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t7=((C_word*)((C_word*)t0)[4])[1];
f_4886(t7,((C_word*)t0)[5],t5,t6);}}

/* k6195 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in ... */
static void C_ccall f_6197(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6197,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6200,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6200(2,av2);}}
else{
/* csi.scm:1074: display */
t3=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[313];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_5897(2,av2);}}}

/* k5093 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5095(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_5095,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm:813: ##sys#print */
t2=*((C_word*)lf[92]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[256];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
/* csi.scm:813: ##sys#print */
t2=*((C_word*)lf[92]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[257];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}}

/* lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_2115(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_2115,3,t0,t1,t2);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2119,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:202: get-environment-variable */
t4=C_fast_retrieve(lf[36]);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[37];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* descseq in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3497(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_3497,6,av);}
a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3626,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm:576: plen */
t7=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t7))(3,av2);}}

/* describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_3491(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(17,0,6))){
C_save_and_reclaim_args((void *)trf_3491,4,t0,t1,t2,t3);}
a=C_alloc(17);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[91]+1):C_i_car(t3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3497,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3629,a[2]=t1,a[3]=t2,a[4]=t6,a[5]=t7,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_permanentp(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4483,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:599: ##sys#block-address */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[240]);
C_word av2[3];
av2[0]=*((C_word*)lf[240]+1);
av2[1]=t9;
av2[2]=t2;
tp(3,av2);}}
else{
t9=t8;{
C_word av2[2];
av2[0]=t9;
av2[1]=C_SCHEME_UNDEFINED;
f_3629(2,av2);}}}

/* k2117 in lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2119(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2119,2,av);}
a=C_alloc(7);
t2=t1;
t3=C_block_size(((C_word*)t0)[2]);
if(C_truep(C_fixnum_greaterp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2131,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=C_i_string_ref(((C_word*)t0)[2],C_fix(0));
/* csi.scm:204: dirseparator? */
t6=C_retrieve2(lf[21],"dirseparator\077");{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
f_1999(3,av2);}}
else{
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* for-each-loop581 in doloop576 in k4167 in k4164 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in ... */
static void C_fcall f_4218(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_4218,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4228,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:696: g582 */
t5=((C_word*)t0)[3];
f_4188(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6502 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in ... */
static void C_ccall f_6504(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6504,2,av);}
/* csi.scm:1036: print */
t2=*((C_word*)lf[10]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_4929(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,4))){C_save_and_reclaim((void *)f_4929,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=C_slot(((C_word*)t0)[13],C_fix(0));
/* csi.scm:813: ##sys#print */
t4=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[12];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3489(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,6))){C_save_and_reclaim((void *)f_3489,2,av);}
a=C_alloc(19);
t2=C_mutate2(&lf[149] /* (set! describer-table ...) */,t1);
t3=*((C_word*)lf[150]+1);
t4=*((C_word*)lf[151]+1);
t5=*((C_word*)lf[152]+1);
t6=C_mutate2(&lf[63] /* (set! describe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3491,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t7=C_mutate2((C_word*)lf[241]+1 /* (set! set-describer! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4491,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate2(&lf[65] /* (set! dump ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4500,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate2(&lf[215] /* (set! hexdump ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4648,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate2(&lf[97] /* (set! show-frameinfo ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4851,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5423,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6708,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:913: ##sys#current-environment */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[378]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[378]+1);
av2[1]=t12;
tp(2,av2);}}

/* k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_4926,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* csi.scm:813: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[95]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[95]+1);
av2[1]=t2;
av2[2]=C_make_character(9);
av2[3]=((C_word*)t0)[12];
tp(4,av2);}}

/* k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4923(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,2))){C_save_and_reclaim((void *)f_4923,2,av);}
a=C_alloc(18);
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5095,a[2]=t2,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[7])){
t4=C_slot(((C_word*)t0)[9],C_fix(2));
t5=t3;
f_5095(t5,C_i_pairp(t4));}
else{
t4=t3;
f_5095(t4,C_SCHEME_FALSE);}}

/* k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4920(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_4920,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* csi.scm:813: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[95]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[95]+1);
av2[1]=t2;
av2[2]=C_make_character(58);
av2[3]=((C_word*)t0)[12];
tp(4,av2);}}

/* k5076 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in ... */
static void C_ccall f_5078(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_5078,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:827: ##sys#print */
t3=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4936 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in ... */
static void C_ccall f_4938(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_4938,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[10])){
/* csi.scm:828: prin1 */
f_4854(t2,((C_word*)t0)[10]);}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_4941(2,av2);}}}

/* k6518 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in ... */
static void C_ccall f_6520(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6520,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6523,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1920,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:80: display */
t5=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[347];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_5836(2,av2);}}}

/* k6521 in k6518 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in ... */
static void C_ccall f_6523(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6523,2,av);}
/* csi.scm:1029: exit */
t2=C_fast_retrieve(lf[57]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop1166 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in ... */
static void C_fcall f_6528(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_6528,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6553,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1004: g1172 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in ... */
static void C_ccall f_4935(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_4935,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[11])){
t3=*((C_word*)lf[91]+1);
t4=*((C_word*)lf[91]+1);
t5=C_i_check_port_2(*((C_word*)lf[91]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[84]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5078,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:827: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[95]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[95]+1);
av2[1]=t6;
av2[2]=C_make_character(91);
av2[3]=*((C_word*)lf[91]+1);
tp(4,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_4938(2,av2);}}}

/* k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_ccall f_4932(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_4932,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm:813: ##sys#print */
t3=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[255];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[12];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2346(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,4))){C_save_and_reclaim((void *)f_2346,2,av);}
a=C_alloc(19);
t2=C_set_block_item(lf[44] /* ##sys#break-on-error */,0,C_SCHEME_FALSE);
t3=C_fast_retrieve(lf[45]);
t4=C_mutate2((C_word*)lf[45]+1 /* (set! ##sys#read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2361,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=lf[48] /* command-table */ =C_SCHEME_END_OF_LIST;;
t6=C_mutate2((C_word*)lf[49]+1 /* (set! toplevel-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2374,tmp=(C_word)a,a+=2,tmp));
t7=C_fast_retrieve(lf[50]);
t8=C_fast_retrieve(lf[51]);
t9=C_fast_retrieve(lf[52]);
t10=C_fast_retrieve(lf[33]);
t11=C_fast_retrieve(lf[53]);
t12=C_fast_retrieve(lf[54]);
t13=*((C_word*)lf[55]+1);
t14=C_mutate2(&lf[56] /* (set! csi-eval ...) */,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2424,a[2]=t12,a[3]=t11,a[4]=t7,a[5]=t10,a[6]=t9,a[7]=t8,a[8]=t13,tmp=(C_word)a,a+=9,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2993,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6820,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:423: toplevel-command */
t17=C_fast_retrieve(lf[49]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t17;
av2[1]=t15;
av2[2]=lf[390];
av2[3]=t16;
av2[4]=lf[391];
f_2374(5,av2);}}

/* k6512 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in ... */
static void C_ccall f_6514(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6514,2,av);}
/* csi.scm:1032: exit */
t2=C_fast_retrieve(lf[57]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4917(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,4))){C_save_and_reclaim((void *)f_4917,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* csi.scm:813: ##sys#print */
t3=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[12];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* lp in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static C_word C_fcall f_3459(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;
loop:{}
if(C_truep(C_i_pairp(t1))){
t2=C_i_car(t1);
t3=C_eqp(t1,t2);
if(C_truep(t3)){
return(t3);}
else{
t4=t1;
t5=C_u_i_cdr(t4);
t7=t5;
t1=t7;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* k3696 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3698(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_3698,2,av);}
a=C_alloc(3);
t2=C_make_character(C_unfix(((C_word*)t0)[2]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3704,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[2],C_fix(65536)))){
/* csi.scm:611: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[166];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
/* csi.scm:612: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[95]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[95]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=C_make_character(10);
av2[3]=*((C_word*)lf[91]+1);
tp(4,av2);}}}

/* k1918 in k6518 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in ... */
static void C_ccall f_1920(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_1920,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1930,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,lf[344],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[0],t4);
t6=C_a_i_cons(&a,2,lf[345],t5);
/* csi.scm:79: ##sys#print-to-string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[346]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[346]+1);
av2[1]=t3;
av2[2]=t6;
tp(3,av2);}}

/* k1921 in k1918 in k6518 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in ... */
static void C_ccall f_1923(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1923,2,av);}
/* csi.scm:106: display */
t2=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[343];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_1911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_1911,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1914(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6907,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:71: get-environment-variable */
t4=C_fast_retrieve(lf[36]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[402];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_1914(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,4))){
C_save_and_reclaim_args((void *)trf_1914,2,t0,t1);}
a=C_alloc(14);
t2=C_mutate2(&lf[8] /* (set! default-editor ...) */,t1);
t3=C_mutate2(&lf[9] /* (set! print-banner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1944,tmp=(C_word)a,a+=2,tmp));
t4=C_fast_retrieve(lf[16]);
t5=C_mutate2((C_word*)lf[16]+1 /* (set! ##sys#user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1960,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[20]+1 /* (set! ##sys#sharp-number-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1989,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate2(&lf[21] /* (set! dirseparator? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1999,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate2(&lf[23] /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2014,tmp=(C_word)a,a+=2,tmp));
t9=C_set_block_item(lf[25] /* @ */,0,C_SCHEME_FALSE);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2045,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[398]);
C_word av2[4];
av2[0]=*((C_word*)lf[398]+1);
av2[1]=t10;
av2[2]=C_fix(256);
av2[3]=C_make_character(32);
tp(4,av2);}}

/* history-ref in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_2321(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_2321,2,t1,t2);}
t3=C_i_inexact_to_exact(t2);
t4=C_fixnum_greaterp(t3,C_fix(0));
t5=(C_truep(t4)?C_fixnum_less_or_equal_p(t3,C_retrieve2(lf[18],"history-count")):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_i_vector_ref(C_retrieve2(lf[38],"history-list"),t3);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
/* csi.scm:253: ##sys#error */
t6=*((C_word*)lf[42]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t1;
av2[2]=lf[43];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}

/* k6562 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in ... */
static void C_ccall f_6564(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6564,2,av);}
if(C_truep(t1)){
t2=t1;
/* csi.scm:1005: string-split */
t3=C_fast_retrieve(lf[33]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
av2[3]=lf[349];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
/* csi.scm:1005: string-split */
t2=C_fast_retrieve(lf[33]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[350];
av2[3]=lf[349];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* lp in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static C_word C_fcall f_3424(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_overflow_check;
loop:{}
if(C_truep(C_i_pairp(t1))){
t3=t1;
t4=C_u_i_cdr(t3);
if(C_truep(C_i_pairp(t4))){
t5=C_u_i_cdr(t4);
t6=C_i_cdr(t2);
t7=C_eqp(t5,t6);
if(C_truep(t7)){
return(t7);}
else{
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}

/* doloop576 in k4167 in k4164 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in ... */
static void C_fcall f_4180(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,3))){
C_save_and_reclaim_args((void *)trf_4180,3,t0,t1,t2);}
a=C_alloc(14);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4188,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(((C_word*)t0)[4],t2);
t5=C_i_check_list_2(t4,lf[106]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4209,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4218,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_4218(t10,t6,t4);}}

/* k6551 in map-loop1166 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in ... */
static void C_ccall f_6553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6553,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6528(t6,((C_word*)t0)[5],t5);}

/* g582 in doloop576 in k4167 in k4164 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in ... */
static void C_fcall f_4188(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,5))){
C_save_and_reclaim_args((void *)trf_4188,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(0));
t4=C_slot(t2,C_fix(1));
/* csi.scm:702: fprintf */
t5=*((C_word*)lf[153]+1);{
C_word av2[6];
av2[0]=t5;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[221];
av2[4]=t3;
av2[5]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}

/* k2499 in k2496 in k2493 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2501(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2501,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2300 in k2297 in k2294 in k2291 in k2288 in doloop120 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2302(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2302,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2277(t3,((C_word*)t0)[4],t2);}

/* f7575 in k6461 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in ... */
static void C_ccall f7575(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f7575,2,av);}
/* csi.scm:1047: case-sensitive */
t2=C_fast_retrieve(lf[312]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6586 in k6583 in k6580 in k6577 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_ccall f_6588(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6588,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:991: register-feature! */
t3=C_fast_retrieve(lf[274]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[355];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6583 in k6580 in k6577 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_6585(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6585,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:990: register-feature! */
t3=C_fast_retrieve(lf[274]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[356];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2511 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2513(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2513,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2516,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:324: eval */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6580 in k6577 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6582(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6582,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=C_u_i_cdr(t3);
/* csi.scm:988: command-line-arguments */
t5=C_fast_retrieve(lf[297]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2514 in k2511 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2516(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2516,2,av);}
/* csi.scm:325: describe */
t2=C_retrieve2(lf[63],"describe");
f_3491(t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k4836 in k4818 in doloop733 in k4692 in k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4838(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4838,2,av);}
/* csi.scm:783: display */
t2=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a2310 in k2294 in k2291 in k2288 in doloop120 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2311(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_2311,2,av);}
t2=C_i_vector_ref(C_retrieve2(lf[38],"history-list"),((C_word*)t0)[2]);
/* csi.scm:246: ##sys#print */
t3=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=*((C_word*)lf[91]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3357 in for-each-loop422 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_ccall f_3359(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3359,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3349(t3,((C_word*)t0)[4],t2);}

/* k6577 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_6579(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6579,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* csi.scm:987: program-name */
t4=C_fast_retrieve(lf[357]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6571 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_6573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6573,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_5680(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_5680(t2,((C_word*)t0)[3]);}}

/* k4808 in doloop741 in doloop733 in k4692 in k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4810(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4810,2,av);}
t2=C_fixnum_difference(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4800(t3,((C_word*)t0)[4],t2);}

/* k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_1906(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1906,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[6]+1 /* (set! editor-command ...) */,t1);
t3=lf[7] /* selected-frame */ =C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:70: get-environment-variable */
t5=C_fast_retrieve(lf[36]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[403];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k4821 in k4818 in doloop733 in k4692 in k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4823(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4823,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_4766(t4,((C_word*)t0)[5],t2,t3);}

/* k6589 in k6586 in k6583 in k6580 in k6577 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in ... */
static void C_ccall f_6591(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6591,2,av);}
a=C_alloc(4);
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_i_set_i_slot(t2,C_fix(1),C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[22]+1))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* csi.scm:994: lookup-script-file */
t6=C_retrieve2(lf[29],"lookup-script-file");
f_2115(t6,t4,t5);}
else{
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[3];
f_5674(t5,t4);}}

/* k4818 in doloop733 in k4692 in k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4820(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_4820,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4838,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4842,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:783: ref */
t5=((C_word*)t0)[8];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[9];
av2[3]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t5))(4,av2);}}

/* k1975 in user-read-hook in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_1977(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_1977,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[17],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4877(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_4877,2,t0,t1);}
a=C_alloc(6);
t2=C_mutate2(&lf[7] /* (set! selected-frame ...) */,t1);
t3=C_fixnum_difference(((C_word*)t0)[2],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4886,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4886(t7,((C_word*)t0)[4],((C_word*)t0)[5],t3);}

/* dump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4500(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,4))){
C_save_and_reclaim_args((void *)trf_4500,3,t1,t2,t3);}
a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4502,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4608,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4613,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t3))){
/* csi.scm:740: def-len688 */
t7=t6;
f_4613(t7,t1);}
else{
t7=C_i_car(t3);
t8=C_u_i_cdr(t3);
if(C_truep(C_i_nullp(t8))){
/* csi.scm:740: def-out689 */
t9=t5;
f_4608(t9,t1,t7);}
else{
t9=C_i_car(t8);
t10=C_u_i_cdr(t8);
/* csi.scm:740: body686 */
t11=t4;
f_4502(t11,t1,t7,t9);}}}

/* body686 in dump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4502(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,4))){
C_save_and_reclaim_args((void *)trf_4502,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4505,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_immp(((C_word*)t0)[2]))){
/* csi.scm:745: ##sys#error */
t5=*((C_word*)lf[42]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t1;
av2[2]=lf[244];
av2[3]=lf[245];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4527,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:746: ##sys#bytevector? */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[235]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[235]+1);
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
tp(3,av2);}}}

/* bestlen in body686 in dump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4505(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_4505,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* csi.scm:744: min */
t3=*((C_word*)lf[243]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* f_5826 in evalstring in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in ... */
static void C_ccall f_5826(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5826,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* doloop741 in doloop733 in k4692 in k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4800(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_4800,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4810,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:781: display */
t5=*((C_word*)lf[99]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[250];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k1995 in sharp-number-hook in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_1997(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_1997,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[17],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* dirseparator? in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_1999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1999,3,av);}
if(C_truep(*((C_word*)lf[22]+1))){
t3=C_i_char_equalp(t2,C_make_character(92));
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=(C_truep(t3)?t3:C_i_char_equalp(t2,C_make_character(47)));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_char_equalp(t2,C_make_character(47));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4851(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_4851,2,t1,t2);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4854,tmp=(C_word)a,a+=2,tmp);
t4=C_fast_retrieve(lf[101]);
t5=(C_truep(C_fast_retrieve(lf[101]))?C_fast_retrieve(lf[101]):C_SCHEME_END_OF_LIST);
t6=t5;
t7=C_i_length(t6);
t8=t7;
t9=t2;
t10=(C_truep(C_u_i_memq(t9,t6))?t2:C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4877,a[2]=t8,a[3]=t3,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t10)){
t12=t11;
f_4877(t12,t10);}
else{
if(C_truep(C_fixnum_greaterp(t8,C_fix(0)))){
t12=C_fixnum_difference(t8,C_fix(1));
t13=t11;
f_4877(t13,C_i_list_ref(t6,t12));}
else{
t12=t11;
f_4877(t12,C_SCHEME_FALSE);}}}

/* prin1 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4854(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,3))){
C_save_and_reclaim_args((void *)trf_4854,2,t1,t2);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4860,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:803: ##sys#with-print-length-limit */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[93]);
C_word av2[4];
av2[0]=*((C_word*)lf[93]+1);
av2[1]=t1;
av2[2]=C_fix(100);
av2[3]=t3;
tp(4,av2);}}

/* k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in ... */
static void C_ccall f_5839(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_5839,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_member(lf[340],((C_word*)((C_word*)t0)[6])[1]))){
t3=C_set_block_item(lf[341] /* ##sys#setup-mode */,0,C_SCHEME_TRUE);
t4=t2;
f_5842(t4,t3);}
else{
t3=t2;
f_5842(t3,C_SCHEME_UNDEFINED);}}

/* k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in ... */
static void C_ccall f_5836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_5836,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_member(lf[342],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6514,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1031: print-banner */
f_1944(t3);}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5839(2,av2);}}}

/* a4859 in prin1 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4860,2,av);}
/* csi.scm:806: ##sys#print */
t2=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=C_SCHEME_TRUE;
av2[4]=*((C_word*)lf[91]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5803 in doloop1225 in k5791 in k5784 in evalstring in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in ... */
static void C_ccall f_5805(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5805,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1024: read */
t3=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2583 in k2580 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2585(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2585,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2580 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2582(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_2582,2,av);}
a=C_alloc(9);
t2=C_fast_retrieve(lf[72]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2585,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2590,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_2590(t7,t3,t1);}

/* k1928 in k1918 in k6518 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in ... */
static void C_ccall f_1930(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1930,2,av);}
/* csi.scm:101: display */
t2=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* compare in k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5195(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,4))){
C_save_and_reclaim_args((void *)trf_5195,3,t0,t1,t2);}
a=C_alloc(4);
t3=C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5206,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=C_i_string_length(((C_word*)t0)[2]);
t6=C_i_string_length(t3);
t7=C_i_fixnum_min(t5,t6);
/* csi.scm:876: substring */
t8=*((C_word*)lf[24]+1);{
C_word av2[5];
av2[0]=t8;
av2[1]=t4;
av2[2]=t3;
av2[3]=C_fix(0);
av2[4]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}

/* k5191 in k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5193(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_5193,2,t0,t1);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5195,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5226,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:878: call/cc */
t5=*((C_word*)lf[108]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k2484 in k2470 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2486(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2486,2,av);}
/* csi.scm:315: ##sys#strip-syntax */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[59]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[59]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* k2480 in k2470 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2482(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2482,2,av);}
/* csi.scm:315: pretty-print */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5810 in k5803 in doloop1225 in k5791 in k5784 in evalstring in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in ... */
static void C_ccall f_5812(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5812,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
f_5795(t2,((C_word*)t0)[3],t1);}

/* a5817 in doloop1225 in k5791 in k5784 in evalstring in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in ... */
static void C_ccall f_5818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5818,2,av);}
/* csi.scm:1026: eval */
t2=C_fast_retrieve(lf[50]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5814 in doloop1225 in k5791 in k5784 in evalstring in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in ... */
static void C_ccall f_5816(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5816,2,av);}
/* csi.scm:1026: rec */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* for-each-loop227 in k2580 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_2590(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_2590,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2600,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:339: g228 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* ##sys#user-read-hook in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_1960(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_1960,4,av);}
a=C_alloc(3);
t4=C_i_char_equalp(C_make_character(41),t2);
t5=(C_truep(t4)?t4:C_u_i_char_whitespacep(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1977,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_fixnum_difference(C_retrieve2(lf[18],"history-count"),C_fix(1));
/* csi.scm:159: history-ref */
f_2321(t6,t7);}
else{
/* csi.scm:160: old-hook */
t6=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)C_fast_retrieve_proc(t6))(4,av2);}}}

/* k2493 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2495(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2495,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:319: eval */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2496 in k2493 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2498(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2498,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2501,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:320: pretty-print */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in ... */
static void C_ccall f_5863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_5863,2,av);}
a=C_alloc(13);
t2=C_fast_retrieve(lf[274]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* csi.scm:1049: collect-options */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5697(t4,t3,lf[330]);}

/* k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in ... */
static void C_ccall f_5866(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_5866,2,av);}
a=C_alloc(18);
t2=C_i_check_list_2(t1,lf[106]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6416,a[2]=t5,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6416(t7,t3,t1);}

/* k4840 in k4818 in doloop733 in k4692 in k4689 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4842(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_4842,2,av);}
/* csi.scm:783: justify */
f_4651(((C_word*)t0)[3],t1,C_fix(2),C_fix(16),C_make_character(48));}

/* k2622 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2624(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_2624,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2646,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_2646(t7,t3,t1);}

/* g247 in k2622 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_2625(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,4))){
C_save_and_reclaim_args((void *)trf_2625,3,t0,t1,t2);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2631,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:344: g262 */
t4=((C_word*)t0)[3];{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[76];
av2[4]=t3;
((C_proc)C_fast_retrieve_proc(t4))(5,av2);}}

/* k1956 in k1949 in k1946 in print-banner in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_1958(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1958,2,av);}
/* csi.scm:148: print */
t2=*((C_word*)lf[10]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[11];
av2[3]=t1;
av2[4]=lf[12];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1949 in k1946 in print-banner in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_1951(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1951,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:148: chicken-version */
t3=C_fast_retrieve(lf[13]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4847 in doloop723 in hexdump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4849(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4849,2,av);}
/* csi.scm:771: display */
t2=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in ... */
static void C_ccall f_5872(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_5872,2,av);}
a=C_alloc(13);
t2=C_fast_retrieve(lf[275]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* csi.scm:1050: collect-options */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5697(t4,t3,lf[329]);}

/* k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in ... */
static void C_ccall f_5875(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_5875,2,av);}
a=C_alloc(18);
t2=C_i_check_list_2(t1,lf[106]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6393,a[2]=t5,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6393(t7,t3,t1);}

/* k2633 in a2630 in g247 in k2622 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2635(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2635,2,av);}
/* csi.scm:344: print* */
t2=*((C_word*)lf[74]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[75];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a2630 in g247 in k2622 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2631(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2631,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2635,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:344: pretty-print */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* ##sys#sharp-number-hook in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_1989(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1989,4,av);}
a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1997,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:164: history-ref */
f_2321(t4,t3);}

/* k3185 in g423 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_ccall f_3187(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,2))){C_save_and_reclaim((void *)f_3187,2,av);}
a=C_alloc(23);
t2=C_i_string_length(((C_word*)t0)[2]);
t3=C_a_i_minus(&a,2,C_fix(16),t2);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3200,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_less_or_equalp(((C_word*)t5)[1],C_fix(0)))){
t9=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t10=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t9);
t11=C_a_i_plus(&a,2,((C_word*)t5)[1],C_fix(18));
t12=C_set_block_item(t5,0,t11);
t13=t8;
f_3200(t13,t12);}
else{
t9=t8;
f_3200(t9,C_SCHEME_UNDEFINED);}}

/* g423 in k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_fcall f_3183(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_3183,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3187,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:484: printf */
t4=*((C_word*)lf[84]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[123];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3180 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3182(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,3))){C_save_and_reclaim((void *)f_3182,2,av);}
a=C_alloc(19);
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3183,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_check_list_2(t1,lf[106]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3234,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3349,a[2]=t8,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_3349(t10,t6,t1);}

/* k2104 in loop in k2129 in k2117 in lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2106(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2106,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* csi.scm:200: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2093(t3,((C_word*)t0)[2],t2);}}

/* k4986 in doloop833 in k4968 in g820 in k4942 in k4939 in k4936 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in ... */
static void C_ccall f_4988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_4988,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* csi.scm:835: ##sys#print */
t4=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2473 in k2470 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2475(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2475,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in ... */
static void C_ccall f_5845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_5845,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6484,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1038: member* */
f_5428(t3,lf[338],((C_word*)((C_word*)t0)[6])[1]);}

/* k2470 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2472(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_2472,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2475,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2482,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2486,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:315: expand */
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in ... */
static void C_fcall f_5842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(18,0,2))){
C_save_and_reclaim_args((void *)trf_5842,2,t0,t1);}
a=C_alloc(18);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_member(lf[339],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6497,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6504,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1036: chicken-version */
t5=C_fast_retrieve(lf[13]);{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5845(2,av2);}}}

/* k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in ... */
static void C_fcall f_5848(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,2))){
C_save_and_reclaim_args((void *)trf_5848,2,t0,t1);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5851(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6478,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1042: load-verbose */
t4=C_fast_retrieve(lf[335]);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k4525 in body686 in dump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_4527,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[3]);
/* csi.scm:746: bestlen */
t4=((C_word*)t0)[5];
f_4505(t4,t2,t3);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[3]);
/* csi.scm:747: bestlen */
t4=((C_word*)t0)[5];
f_4505(t4,t2,t3);}
else{
t2=C_immp(((C_word*)t0)[3]);
t3=(C_truep(t2)?C_SCHEME_FALSE:C_anypointerp(((C_word*)t0)[3]));
if(C_truep(t3)){
/* csi.scm:749: hexdump */
f_4648(((C_word*)t0)[2],((C_word*)t0)[3],C_fix(32),*((C_word*)lf[246]+1),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_structurep(((C_word*)t0)[3]))){
t5=C_slot(((C_word*)t0)[3],C_fix(0));
t6=t4;
f_4570(t6,C_i_assq(t5,C_retrieve2(lf[147],"bytevector-data")));}
else{
t5=t4;
f_4570(t5,C_SCHEME_FALSE);}}}}}

/* k2598 in for-each-loop227 in k2580 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2600(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2600,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2590(t3,((C_word*)t0)[4],t2);}

/* k2544 in k2541 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2546(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2546,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:333: eval */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2547 in k2544 in k2541 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2549(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2549,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2552,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:334: eval */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3179(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,3))){C_save_and_reclaim((void *)f_3179,2,av);}
a=C_alloc(25);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_fast_retrieve(lf[141]);
t8=C_fast_retrieve(lf[4]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3377,a[2]=((C_word*)t0)[8],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3379,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_3379(t13,t9,C_fast_retrieve(lf[4]));}

/* k2541 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2543(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2543,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:332: read */
t4=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3170 in shorten in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3172(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,1))){C_save_and_reclaim((void *)f_3172,2,av);}
a=C_alloc(4);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_divide(&a,2,t1,C_fix(100));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4995 in k4992 in k4989 in k4986 in doloop833 in k4968 in g820 in k4942 in k4939 in k4936 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in ... */
static void C_ccall f_4997(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_4997,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:840: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_2440(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_2440,2,t0,t1);}
a=C_alloc(10);
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_assq(t2,C_retrieve2(lf[48],"command-table"));
if(C_truep(t3)){
t4=((C_word*)t0)[3];
t5=C_i_cadr(t3);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2457,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:307: g202 */
t7=t5;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)C_fast_retrieve_proc(t7))(2,av2);}}
else{
t4=C_eqp(t2,lf[58]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2472,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:314: read */
t6=*((C_word*)lf[60]+1);{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_eqp(t2,lf[61]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2495,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:318: read */
t7=*((C_word*)lf[60]+1);{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=C_eqp(t2,lf[62]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:323: read */
t8=*((C_word*)lf[60]+1);{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=C_eqp(t2,lf[64]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2528,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:327: read */
t9=*((C_word*)lf[60]+1);{
C_word av2[2];
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t8=C_eqp(t2,lf[66]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2543,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:331: read */
t10=*((C_word*)lf[60]+1);{
C_word av2[2];
av2[0]=t10;
av2[1]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t9=C_eqp(t2,lf[67]);
if(C_truep(t9)){
/* csi.scm:336: report */
t10=C_retrieve2(lf[68],"report");
f_3142(t10,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t10=C_eqp(t2,lf[69]);
if(C_truep(t10)){
/* csi.scm:337: ##sys#quit-hook */
t11=C_fast_retrieve(lf[70]);{
C_word av2[3];
av2[0]=t11;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_FALSE;
f_5929(3,av2);}}
else{
t11=C_eqp(t2,lf[71]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2615,a[2]=((C_word*)t0)[7],a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:339: read-line */
t14=((C_word*)t0)[8];{
C_word av2[2];
av2[0]=t14;
av2[1]=t13;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
else{
t12=C_eqp(t2,lf[73]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2624,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[7],a[3]=t13,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:343: read-line */
t15=((C_word*)t0)[8];{
C_word av2[2];
av2[0]=t15;
av2[1]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t13=C_eqp(t2,lf[77]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2680,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:347: read */
t15=*((C_word*)lf[60]+1);{
C_word av2[2];
av2[0]=t15;
av2[1]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t14=C_eqp(t2,lf[81]);
if(C_truep(t14)){
if(C_truep(C_fast_retrieve(lf[82]))){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2732,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t16=C_a_i_list1(&a,1,C_fast_retrieve(lf[82]));
/* csi.scm:353: history-add */
t17=C_retrieve2(lf[40],"history-add");
f_2222(t17,t15,t16);}
else{
t15=C_SCHEME_UNDEFINED;
t16=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t16;
av2[1]=t15;
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}}
else{
t15=C_eqp(t2,lf[83]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2748,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2766,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2770,a[2]=t17,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:358: editor-command */
t19=C_fast_retrieve(lf[6]);{
C_word av2[2];
av2[0]=t19;
av2[1]=t18;
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}
else{
t16=C_eqp(t2,lf[88]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t18=*((C_word*)lf[41]+1);
/* csi.scm:235: vector-fill! */
t19=*((C_word*)lf[89]+1);{
C_word av2[4];
av2[0]=t19;
av2[1]=t17;
av2[2]=C_retrieve2(lf[38],"history-list");
av2[3]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t19+1)))(4,av2);}}
else{
t17=C_eqp(t2,lf[90]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2798,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2277,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t22=((C_word*)t20)[1];
f_2277(t22,t18,C_fix(1));}
else{
t18=C_eqp(t2,lf[96]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2810,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:369: show-frameinfo */
f_4851(t19,C_retrieve2(lf[7],"selected-frame"));}
else{
t19=C_eqp(t2,lf[98]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2822,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2829,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:372: read */
t22=*((C_word*)lf[60]+1);{
C_word av2[2];
av2[0]=t22;
av2[1]=t21;
((C_proc)(void*)(*((C_word*)t22+1)))(2,av2);}}
else{
t20=C_eqp(t2,lf[102]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2842,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:375: read */
t22=*((C_word*)lf[60]+1);{
C_word av2[2];
av2[0]=t22;
av2[1]=t21;
((C_proc)(void*)(*((C_word*)t22+1)))(2,av2);}}
else{
t21=C_eqp(t2,lf[110]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:377: read-line */
t23=((C_word*)t0)[8];{
C_word av2[2];
av2[0]=t23;
av2[1]=t22;
((C_proc)(void*)(*((C_word*)t23+1)))(2,av2);}}
else{
t22=C_eqp(t2,lf[111]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2870,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:382: display */
t24=*((C_word*)lf[99]+1);{
C_word av2[3];
av2[0]=t24;
av2[1]=t23;
av2[2]=lf[113];
((C_proc)(void*)(*((C_word*)t24+1)))(3,av2);}}
else{
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2921,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:413: printf */
t24=*((C_word*)lf[84]+1);{
C_word av2[4];
av2[0]=t24;
av2[1]=t23;
av2[2]=lf[114];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t24+1)))(4,av2);}}}}}}}}}}}}}}}}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2973,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:416: ##sys#call-with-values */{
C_word av2[4];
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}}

/* k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in ... */
static void C_ccall f_5854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_5854,2,av);}
a=C_alloc(13);
t2=C_fast_retrieve(lf[274]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* csi.scm:1048: collect-options */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5697(t4,t3,lf[331]);}

/* k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in ... */
static void C_ccall f_5857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_5857,2,av);}
a=C_alloc(18);
t2=C_i_check_list_2(t1,lf[106]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6439,a[2]=t5,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6439(t7,t3,t1);}

/* k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in ... */
static void C_ccall f_5851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_5851,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6463,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1044: member* */
f_5428(t3,lf[334],((C_word*)((C_word*)t0)[6])[1]);}

/* k4989 in k4986 in doloop833 in k4968 in g820 in k4942 in k4939 in k4936 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in ... */
static void C_ccall f_4991(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_4991,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:835: ##sys#print */
t3=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[251];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4992 in k4989 in k4986 in doloop833 in k4968 in g820 in k4942 in k4939 in k4936 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in ... */
static void C_ccall f_4994(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_4994,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[6],((C_word*)t0)[2]);
/* csi.scm:839: prin1 */
f_4854(t2,t3);}

/* k2550 in k2547 in k2544 in k2541 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2552(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_2552,2,av);}
a=C_alloc(3);
/* csi.scm:335: dump */
f_4500(((C_word*)t0)[2],((C_word*)t0)[3],C_a_i_list(&a,1,t1));}

/* k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3162(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_3162,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3164,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm:479: printf */
t5=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[143];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6001 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in ... */
static void C_ccall f_6003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6003,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_u_i_cdr(t2));
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_5908(t5,((C_word*)t0)[4],t4);}

/* shorten in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_3164(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_3164,2,t1,t2);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3172,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_times(&a,2,t2,C_fix(100));
/* csi.scm:478: truncate */
t5=*((C_word*)lf[120]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k4298 in loop in k4266 in g604 in k4261 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in ... */
static void C_ccall f_4300(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4300,2,av);}
/* csi.scm:717: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a4304 in loop in k4266 in g604 in k4261 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in ... */
static void C_ccall f_4305(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_4305,2,av);}
t2=C_i_cdar(((C_word*)t0)[2]);
t3=C_i_cadr(((C_word*)t0)[2]);
/* csi.scm:716: fprintf */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[227];
av2[4]=t2;
av2[5]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}

/* k2455 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2457(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2457,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4998 in k4995 in k4992 in k4989 in k4986 in doloop833 in k4968 in g820 in k4942 in k4939 in k4936 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in ... */
static void C_ccall f_5000(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5000,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=((C_word*)((C_word*)t0)[4])[1];
f_4975(t5,((C_word*)t0)[5],t2,t4);}

/* k4578 in k4568 in k4525 in body686 in dump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4580(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_4580,2,av);}
/* csi.scm:752: hexdump */
f_4648(((C_word*)t0)[2],((C_word*)t0)[3],t1,*((C_word*)lf[216]+1),((C_word*)t0)[4]);}

/* k2526 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2528(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2528,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2531,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:328: eval */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_2424,3,av);}
a=C_alloc(11);
if(C_truep(C_eofp(t2))){
/* csi.scm:302: exit */
t3=C_fast_retrieve(lf[57]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2440,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_pairp(t2))){
t4=C_slot(t2,C_fix(0));
t5=t3;
f_2440(t5,C_eqp(lf[115],t4));}
else{
t4=t3;
f_2440(t4,C_SCHEME_FALSE);}}}

/* k2529 in k2526 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2531(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2531,2,av);}
/* csi.scm:329: dump */
f_4500(((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1946 in print-banner in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_1948(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1948,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:147: print */
t3=*((C_word*)lf[10]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[14];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* print-banner in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_1944(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_1944,1,t1);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1948,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:129: newline */
t3=*((C_word*)lf[15]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop396 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_3379(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3379,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3404,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:480: g402 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in ... */
static void C_ccall f_5888(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_5888,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6230,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1067: member* */
f_5428(t3,lf[318],((C_word*)((C_word*)t0)[6])[1]);}

/* k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in ... */
static void C_ccall f_5885(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_5885,2,av);}
a=C_alloc(9);
t2=C_mutate2((C_word*)lf[133]+1 /* (set! ##sys#include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=C_i_cdr(((C_word*)t0)[9]);
if(C_truep(C_i_pairp(t4))){
t5=C_i_cadr(((C_word*)t0)[9]);
if(C_truep(C_i_string_equal_p(lf[319],t5))){
/* csi.scm:1062: keyword-style */
t6=C_fast_retrieve(lf[135]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=lf[320];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=C_u_i_cdr(((C_word*)t0)[9]);
t7=C_u_i_car(t6);
if(C_truep(C_i_string_equal_p(lf[321],t7))){
/* csi.scm:1064: keyword-style */
t8=C_fast_retrieve(lf[135]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t3;
av2[2]=lf[311];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t8=C_u_i_cdr(((C_word*)t0)[9]);
t9=C_u_i_car(t8);
if(C_truep(C_i_string_equal_p(lf[322],t9))){
/* csi.scm:1066: keyword-style */
t10=C_fast_retrieve(lf[135]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t3;
av2[2]=lf[323];
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}
else{
t10=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=C_SCHEME_UNDEFINED;
f_5888(2,av2);}}}}}
else{
/* csi.scm:1060: ##sys#error */
t5=*((C_word*)lf[42]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[324];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_5888(2,av2);}}}

/* k3375 in k3177 in k3160 in k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3377(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3377,2,av);}
/* csi.scm:480: sort */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=*((C_word*)lf[142]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in ... */
static void C_ccall f_5881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,2))){C_save_and_reclaim((void *)f_5881,2,av);}
a=C_alloc(26);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6297,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_retrieve2(lf[23],"chop-separator");
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6304,a[2]=t3,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=t6,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* csi.scm:1053: collect-options */
t10=((C_word*)((C_word*)t0)[11])[1];
f_5697(t10,t9,lf[328]);}

/* k6308 in k6302 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in ... */
static void C_ccall f_6310(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_6310,2,av);}
a=C_alloc(13);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_retrieve2(lf[23],"chop-separator");
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6317,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t7,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* csi.scm:1054: collect-options */
t9=((C_word*)((C_word*)t0)[4])[1];
f_5697(t9,t8,lf[327]);}

/* k6315 in k6308 in k6302 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in ... */
static void C_ccall f_6317(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_6317,2,av);}
a=C_alloc(13);
t2=C_i_check_list_2(t1,lf[230]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6325,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6325(t7,t3,t1);}

/* k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in ... */
static void C_ccall f_5897(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_5897,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6185,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:1079: member* */
f_5428(t3,lf[308],((C_word*)((C_word*)t0)[6])[1]);}

/* k4568 in k4525 in body686 in dump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_4570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_4570,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4580,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=C_block_size(t3);
/* csi.scm:752: bestlen */
t6=((C_word*)t0)[5];
f_4505(t6,t4,t5);}
else{
/* csi.scm:753: ##sys#error */
t2=*((C_word*)lf[42]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[244];
av2[3]=lf[247];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}}

/* k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in ... */
static void C_ccall f_5894(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_5894,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6197,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1073: member* */
f_5428(t3,lf[314],((C_word*)((C_word*)t0)[6])[1]);}

/* k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in ... */
static void C_ccall f_5891(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_5891,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6218,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1070: member* */
f_5428(t3,lf[316],((C_word*)((C_word*)t0)[6])[1]);}

/* k2654 in for-each-loop246 in k2622 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2656(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2656,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2646(t3,((C_word*)t0)[4],t2);}

/* k6302 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in ... */
static void C_ccall f_6304(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_6304,2,av);}
a=C_alloc(13);
t2=C_i_check_list_2(t1,lf[230]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6359,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6359(t7,t3,t1);}

/* k2808 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2810(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2810,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5042 in for-each-loop819 in k4942 in k4939 in k4936 in k4933 in k4930 in k4927 in k4924 in k4921 in k4918 in k4915 in doloop785 in k4875 in show-frameinfo in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in ... */
static void C_ccall f_5044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5044,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_5034(t4,((C_word*)t0)[5],t2,t3);}

/* k5509 in loop in canonicalize-args in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_5511,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=C_subchar(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_i_char_equalp(C_make_character(58),t2))){
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* csi.scm:953: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5489(t5,((C_word*)t0)[5],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5525,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5593,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:954: substring */
t5=*((C_word*)lf[24]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(1);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5601,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* csi.scm:958: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5489(t5,t2,t4);}}

/* k4549 in k4525 in body686 in dump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4551(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_4551,2,av);}
/* csi.scm:747: hexdump */
f_4648(((C_word*)t0)[2],((C_word*)t0)[3],t1,*((C_word*)lf[216]+1),((C_word*)t0)[4]);}

/* k6321 in k6315 in k6308 in k6302 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in ... */
static void C_ccall f_6323(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_6323,2,av);}
/* csi.scm:1053: append */
t2=*((C_word*)lf[231]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
av2[4]=C_fast_retrieve(lf[133]);
av2[5]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* loop in k2168 in k2161 in k2155 in k2138 in k2129 in k2117 in lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_2172(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,2))){
C_save_and_reclaim_args((void *)trf_2172,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2182,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2199,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_slot(t2,C_fix(0));
/* csi.scm:213: chop-separator */
t6=C_retrieve2(lf[23],"chop-separator");{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
f_2014(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2168 in k2161 in k2155 in k2138 in k2129 in k2117 in lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2170(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_2170,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2172,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2172(t5,((C_word*)t0)[4],t1);}

/* map-loop1316 in k6315 in k6308 in k6302 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in ... */
static void C_fcall f_6325(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_6325,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6350,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1054: g1322 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5523 in k5509 in loop in canonicalize-args in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5525(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,3))){C_save_and_reclaim((void *)f_5525,2,av);}
a=C_alloc(19);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5632,tmp=(C_word)a,a+=2,tmp);
t3=f_5632(t1);
if(C_truep(t3)){
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5554,a[2]=t6,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_5554(t12,t8,t1);}
else{
/* csi.scm:957: ##sys#error */
t4=*((C_word*)lf[42]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[267];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k2687 in a2684 in k2678 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2689(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2689,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2700,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:347: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[4];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* k2183 in k2180 in loop in k2168 in k2161 in k2155 in k2138 in k2129 in k2117 in lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2185(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2185,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* csi.scm:215: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2172(t3,((C_word*)t0)[2],t2);}}

/* a2684 in k2678 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2685(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2685,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:347: ##sys#start-timer */
t3=*((C_word*)lf[80]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2180 in loop in k2168 in k2161 in k2155 in k2138 in k2129 in k2117 in lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2182(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2182,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:214: addext */
f_2064(t2,t1);}

/* k2678 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2680(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_2680,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2685,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2713,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:347: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[4];
av2[2]=t3;
av2[3]=t4;
C_call_with_values(4,av2);}}

/* k4532 in k4525 in body686 in dump in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4534(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_4534,2,av);}
/* csi.scm:746: hexdump */
f_4648(((C_word*)t0)[2],((C_word*)t0)[3],t1,*((C_word*)lf[216]+1),((C_word*)t0)[4]);}

/* k2613 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2615(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2615,2,av);}
/* csi.scm:339: string-split */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2155 in k2138 in k2129 in k2117 in lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2157(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_2157,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2163,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[5];
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[27]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=t2;
av2[2]=lf[35];
av2[3]=t3;
tp(4,av2);}}}

/* k2152 in k2141 in k2138 in k2129 in k2117 in lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_2154,2,av);}
/* csi.scm:207: string-append */
t2=*((C_word*)lf[30]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[31];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k2148 in k2141 in k2138 in k2129 in k2117 in lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2150(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2150,2,av);}
/* csi.scm:207: addext */
f_2064(((C_word*)t0)[3],t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point

void C_ccall C_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(1820)){
C_save(t1);
C_rereclaim2(1820*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,405);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\006.csirc");
lf[2]=C_h_intern(&lf[2],27,"\003sysrepl-print-length-limit");
lf[3]=C_h_intern(&lf[3],4,"\000csi");
lf[4]=C_h_intern(&lf[4],12,"\003sysfeatures");
lf[5]=C_h_intern(&lf[5],19,"\003sysnotices-enabled");
lf[6]=C_h_intern(&lf[6],14,"editor-command");
lf[10]=C_h_intern(&lf[10],5,"print");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000C(c) 2008-2016, The CHICKEN Team\012(c) 2000-2007, Felix L. Winkelmann\012");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[13]=C_h_intern(&lf[13],15,"chicken-version");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\007CHICKEN");
lf[15]=C_h_intern(&lf[15],7,"newline");
lf[16]=C_h_intern(&lf[16],18,"\003sysuser-read-hook");
lf[17]=C_h_intern(&lf[17],5,"quote");
lf[20]=C_h_intern(&lf[20],21,"\003syssharp-number-hook");
lf[22]=C_h_intern(&lf[22],20,"\003syswindows-platform");
lf[24]=C_h_intern(&lf[24],9,"substring");
lf[25]=C_h_intern(&lf[25],1,"@");
lf[26]=C_h_intern(&lf[26],12,"file-exists\077");
lf[27]=C_h_intern(&lf[27],17,"\003sysstring-append");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\004.bat");
lf[30]=C_h_intern(&lf[30],13,"string-append");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[32]=C_h_intern(&lf[32],25,"\003syspeek-nonnull-c-string");
lf[33]=C_h_intern(&lf[33],12,"string-split");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[36]=C_h_intern(&lf[36],24,"get-environment-variable");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\004PATH");
lf[39]=C_h_intern(&lf[39],13,"vector-resize");
lf[41]=C_h_intern(&lf[41],19,"\003sysundefined-value");
lf[42]=C_h_intern(&lf[42],9,"\003syserror");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000 history entry index out of range");
lf[44]=C_h_intern(&lf[44],18,"\003sysbreak-on-error");
lf[45]=C_h_intern(&lf[45],20,"\003sysread-prompt-hook");
lf[46]=C_h_intern(&lf[46],13,"\003systty-port\077");
lf[47]=C_h_intern(&lf[47],18,"\003sysstandard-input");
lf[49]=C_h_intern(&lf[49],16,"toplevel-command");
lf[50]=C_h_intern(&lf[50],4,"eval");
lf[51]=C_h_intern(&lf[51],12,"load-noisily");
lf[52]=C_h_intern(&lf[52],9,"read-line");
lf[53]=C_h_intern(&lf[53],6,"expand");
lf[54]=C_h_intern(&lf[54],12,"pretty-print");
lf[55]=C_h_intern(&lf[55],6,"values");
lf[57]=C_h_intern(&lf[57],4,"exit");
lf[58]=C_h_intern(&lf[58],1,"x");
lf[59]=C_h_intern(&lf[59],16,"\003sysstrip-syntax");
lf[60]=C_h_intern(&lf[60],4,"read");
lf[61]=C_h_intern(&lf[61],1,"p");
lf[62]=C_h_intern(&lf[62],1,"d");
lf[64]=C_h_intern(&lf[64],2,"du");
lf[66]=C_h_intern(&lf[66],3,"dur");
lf[67]=C_h_intern(&lf[67],1,"r");
lf[69]=C_h_intern(&lf[69],1,"q");
lf[70]=C_h_intern(&lf[70],13,"\003sysquit-hook");
lf[71]=C_h_intern(&lf[71],1,"l");
lf[72]=C_h_intern(&lf[72],4,"load");
lf[73]=C_h_intern(&lf[73],2,"ln");
lf[74]=C_h_intern(&lf[74],6,"print\052");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\004==> ");
lf[76]=C_h_intern(&lf[76],8,"\000printer");
lf[77]=C_h_intern(&lf[77],1,"t");
lf[78]=C_h_intern(&lf[78],17,"\003sysdisplay-times");
lf[79]=C_h_intern(&lf[79],14,"\003sysstop-timer");
lf[80]=C_h_intern(&lf[80],15,"\003sysstart-timer");
lf[81]=C_h_intern(&lf[81],3,"exn");
lf[82]=C_h_intern(&lf[82],18,"\003syslast-exception");
lf[83]=C_h_intern(&lf[83],1,"e");
lf[84]=C_h_intern(&lf[84],6,"printf");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000,editor returned with non-zero exit status ~a");
lf[86]=C_h_intern(&lf[86],6,"system");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[88]=C_h_intern(&lf[88],2,"ch");
lf[89]=C_h_intern(&lf[89],12,"vector-fill!");
lf[90]=C_h_intern(&lf[90],1,"h");
lf[91]=C_h_intern(&lf[91],19,"\003sysstandard-output");
lf[92]=C_h_intern(&lf[92],9,"\003sysprint");
lf[93]=C_h_intern(&lf[93],27,"\003syswith-print-length-limit");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[95]=C_h_intern(&lf[95],16,"\003syswrite-char-0");
lf[96]=C_h_intern(&lf[96],1,"c");
lf[98]=C_h_intern(&lf[98],1,"f");
lf[99]=C_h_intern(&lf[99],7,"display");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\016no such frame\012");
lf[101]=C_h_intern(&lf[101],26,"\003sysrepl-recent-call-chain");
lf[102]=C_h_intern(&lf[102],1,"g");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\027no environment in frame");
lf[104]=C_h_intern(&lf[104],9,"frameinfo");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\012; getting ");
lf[106]=C_h_intern(&lf[106],8,"for-each");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\022no such variable: ");
lf[108]=C_h_intern(&lf[108],7,"call/cc");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000#string or symbol required for `,g\047\012");
lf[110]=C_h_intern(&lf[110],1,"s");
lf[111]=C_h_intern(&lf[111],1,"\077");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\002 ,");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\003\266Toplevel commands:\012\012 ,\077                Show this text\012 ,p EXP            Pr"
"etty print evaluated expression EXP\012 ,d EXP            Describe result of evalua"
"ted expression EXP\012 ,du EXP           Dump data of expression EXP\012 ,dur EXP N   "
"     Dump range\012 ,q                Quit interpreter\012 ,l FILENAME ...   Load one "
"or more files\012 ,ln FILENAME ...  Load one or more files and print result of each"
" top-level expression\012 ,r                Show system information\012 ,h            "
"    Show history of expression results\012 ,ch               Clear history of expre"
"ssion results\012 ,e FILENAME       Run external editor\012 ,s TEXT ...       Execute "
"shell-command\012 ,exn              Describe last exception\012 ,c                Show"
" call-chain of most recent error\012 ,f N              Select frame N\012 ,g NAME     "
"      Get variable NAME from current frame\012 ,t EXP            Evaluate form and "
"print elapsed time\012 ,x EXP            Pretty print expanded expression EXP\012");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\0005undefined toplevel command ~s - enter `,\077\047 for help~%");
lf[115]=C_h_intern(&lf[115],7,"unquote");
lf[116]=C_h_intern(&lf[116],4,"chop");
lf[117]=C_h_intern(&lf[117],4,"sort");
lf[118]=C_h_intern(&lf[118],19,"with-output-to-port");
lf[119]=C_h_intern(&lf[119],4,"argv");
lf[120]=C_h_intern(&lf[120],8,"truncate");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[122]=C_h_intern(&lf[122],11,"make-string");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\004  ~a");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol gc is enabled\012");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\027interrupts are enabled\012");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\010(64-bit)");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\010 (fixed)");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\010downward");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\006upward");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\002\262~%~%~\012                   Machine type:    \011~A ~A~%~\012                   Soft"
"ware type:   \011~A~%~\012                   Software version:\011~A~%~\012                 "
"  Build platform:  \011~A~%~\012                   Installation prefix:\011~A~%~\012        "
"           Extension path:  \011~A~%~\012                   Include path:    \011~A~%~\012  "
"                 Keyword style:   \011~A~%~\012                   Symbol-table load:\011~"
"S~%  ~\012                     Avg bucket length:\011~S~%  ~\012                     Tota"
"l symbol count:\011~S~%~\012                   Memory:\011heap size is ~S bytes~A with ~S"
" bytes currently in use~%~  \012                     nursery size is ~S bytes, stac"
"k grows ~A~%~\012                   Command line:    \011~S~%");
lf[133]=C_h_intern(&lf[133],21,"\003sysinclude-pathnames");
lf[134]=C_h_intern(&lf[134],14,"symbol->string");
lf[135]=C_h_intern(&lf[135],13,"keyword-style");
lf[136]=C_h_intern(&lf[136],15,"repository-path");
lf[137]=C_h_intern(&lf[137],14,"build-platform");
lf[138]=C_h_intern(&lf[138],16,"software-version");
lf[139]=C_h_intern(&lf[139],13,"software-type");
lf[140]=C_h_intern(&lf[140],12,"machine-type");
lf[141]=C_h_intern(&lf[141],15,"keyword->string");
lf[142]=C_h_intern(&lf[142],8,"string<\077");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\015Features:~%~%");
lf[144]=C_h_intern(&lf[144],17,"memory-statistics");
lf[145]=C_h_intern(&lf[145],21,"\003syssymbol-table-info");
lf[146]=C_h_intern(&lf[146],2,"gc");
lf[148]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376B\000\000\030vector of unsigned bytes\376\003\000\000\002\376\001\000\000\017u8vector-leng"
"th\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376B\000\000\026vector of signed byt"
"es\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000"
"\002\376B\000\000\037vector of unsigned 16-bit words\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\015u16vect"
"or-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376B\000\000\035vector of signed 16-bit words\376\003\000\000\002\376\001\000"
"\000\020s16vector-length\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376B\000\000\037ve"
"ctor of unsigned 32-bit words\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\015u32vector-ref\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376B\000\000\035vector of signed 32-bit words\376\003\000\000\002\376\001\000\000\020s32vec"
"tor-length\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376B\000\000\027vector of "
"32-bit floats\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"f64vector\376\003\000\000\002\376B\000\000\027vector of 64-bit floats\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\015f6"
"4vector-ref\376\377\016\376\377\016");
lf[150]=C_h_intern(&lf[150],6,"length");
lf[151]=C_h_intern(&lf[151],8,"list-ref");
lf[152]=C_h_intern(&lf[152],10,"string-ref");
lf[153]=C_h_intern(&lf[153],7,"fprintf");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000 ~% (~A elements not displayed)~%");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000.\011(followed by ~A identical instance~a)~% ...~%");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\007 ~S: ~S");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\021~A of length ~S~%");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000$character ~S, code: ~S, #x~X, #o~O~%");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\016boolean true~%");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\017boolean false~%");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\014empty list~%");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\024end-of-file object~%");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\024unspecified object~%");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\016, character ~S");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000(exact integer ~S~%  #x~X~%  #o~O~%  #b~B");
lf[168]=C_h_intern(&lf[168],28,"\003sysarbitrary-unbound-symbol");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\017unbound value~%");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\023inexact number ~S~%");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\013number ~S~%");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\006string");
lf[173]=C_h_intern(&lf[173],8,"\003syssize");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\006vector");
lf[175]=C_h_intern(&lf[175],8,"\003sysslot");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\035keyword symbol with name ~s~%");
lf[177]=C_h_intern(&lf[177],18,"\003syssymbol->string");
lf[178]=C_h_intern(&lf[178],5,"write");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\005  ~s\011");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\020  \012properties:\012\012");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\013uninterned ");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\012qualified ");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\031~a~asymbol with name ~S~%");
lf[186]=C_h_intern(&lf[186],28,"\003syssymbol->qualified-string");
lf[187]=C_h_intern(&lf[187],20,"\003sysinterned-symbol\077");
lf[188]=C_h_intern(&lf[188],21,"\003sysqualified-symbol\077");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\010unbound ");
lf[190]=C_h_intern(&lf[190],32,"\003syssymbol-has-toplevel-binding\077");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\005eol~%");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\012(circle)~%");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\006~S -> ");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\024circular structure: ");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\004list");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\036pair with car ~S~%and cdr ~S~%");
lf[197]=C_h_intern(&lf[197],7,"sprintf");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000 procedure with code pointer 0x~X");
lf[199]=C_h_intern(&lf[199],25,"\003syspeek-unsigned-integer");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\005input");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\006output");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\0005~A port of type ~A with name ~S and file pointer ~X~%");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000/locative~%  pointer ~X~%  index ~A~%  type ~A~%");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\004slot");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\010u8vector");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\010s8vector");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\011u16vector");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\011s16vector");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\011u32vector");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\011s32vector");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\011f32vector");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\011f64vector");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\024machine pointer ~X~%");
lf[216]=C_h_intern(&lf[216],8,"\003sysbyte");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\022blob of size ~S:~%");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\030lambda information: ~s~%");
lf[219]=C_h_intern(&lf[219],23,"\003syslambda-info->string");
lf[220]=C_h_intern(&lf[220],10,"hash-table");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\013 ~S\011-> ~S~%");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\025  hash function: ~a~%");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000:hash-table with ~S element~a~%  comparison procedure: ~A~%");
lf[226]=C_h_intern(&lf[226],9,"condition");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\007\011~s: ~s");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\005 ~s~%");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\017condition: ~s~%");
lf[230]=C_h_intern(&lf[230],3,"map");
lf[231]=C_h_intern(&lf[231],6,"append");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\031structure of type `~S\047:~%");
lf[233]=C_h_intern(&lf[233],18,"\003syshash-table-ref");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\020unknown object~%");
lf[235]=C_h_intern(&lf[235],15,"\003sysbytevector\077");
lf[236]=C_h_intern(&lf[236],13,"\003syslocative\077");
lf[237]=C_h_intern(&lf[237],5,"port\077");
lf[238]=C_h_intern(&lf[238],8,"keyword\077");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\034statically allocated (0x~X) ");
lf[240]=C_h_intern(&lf[240],17,"\003sysblock-address");
lf[241]=C_h_intern(&lf[241],14,"set-describer!");
lf[242]=C_h_intern(&lf[242],19,"\003syshash-table-set!");
lf[243]=C_h_intern(&lf[243],3,"min");
lf[244]=C_h_intern(&lf[244],4,"dump");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot dump immediate object");
lf[246]=C_h_intern(&lf[246],13,"\003syspeek-byte");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot dump object");
lf[248]=C_h_intern(&lf[248],14,"number->string");
lf[249]=C_h_intern(&lf[249],19,"\003syswrite-char/port");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\004:\011  ");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\006  ---\012");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\002] ");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\003\011  ");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\002[]");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[258]=C_h_intern(&lf[258],23,"\003sysuser-interrupt-hook");
lf[259]=C_h_intern(&lf[259],17,"\003syssignal-vector");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\007-script");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[268]=C_h_intern(&lf[268],16,"\003sysstring->list");
lf[269]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\010-version\376\003\000\000\002\376B\000\000\005-help\376\003\000\000"
"\002\376B\000\000\006--help\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\013-no-feature\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\021-cas"
"e-insensitive\376\003\000\000\002\376B\000\000\016-keyword-style\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000"
"\021-no-symbol-escape\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\022-require-"
"extension\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\010-no-ini"
"t\376\003\000\000\002\376B\000\000\015-include-path\376\003\000\000\002\376B\000\000\010-release\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pretty-prin"
"t\376\003\000\000\002\376B\000\000\002--\376\377\016");
lf[270]=C_h_intern(&lf[270],25,"\003sysimplicit-exit-handler");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\047missing argument to command-line option");
lf[272]=C_h_intern(&lf[272],8,"\003syslist");
lf[273]=C_h_intern(&lf[273],17,"open-input-string");
lf[274]=C_h_intern(&lf[274],17,"register-feature!");
lf[275]=C_h_intern(&lf[275],19,"unregister-feature!");
lf[276]=C_h_intern(&lf[276],4,"repl");
lf[277]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\002-n"
"\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-"
"insensitive\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000\000\002\376B\000"
"\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B"
"\000\000\007-script\376\377\016");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\002-K");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\016-keyword-style");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-feature");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\002-R");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[287]=C_h_intern(&lf[287],22,"\004corerequire-extension");
lf[288]=C_h_intern(&lf[288],14,"string->symbol");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\002-e");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\005-eval");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\006-print");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\002-P");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\015-pretty-print");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[296]=C_h_intern(&lf[296],4,"main");
lf[297]=C_h_intern(&lf[297],22,"command-line-arguments");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[299]=C_h_intern(&lf[299],18,"\003sysstandard-error");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\002; ");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\003\012; ");
lf[302]=C_h_intern(&lf[302],12,"flush-output");
lf[303]=C_h_intern(&lf[303],21,"with-output-to-string");
lf[304]=C_h_intern(&lf[304],8,"\003sysload");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[308]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\010-no-init\376\377\016");
lf[309]=C_h_intern(&lf[309],13,"symbol-escape");
lf[310]=C_h_intern(&lf[310],20,"parentheses-synonyms");
lf[311]=C_h_intern(&lf[311],5,"\000none");
lf[312]=C_h_intern(&lf[312],14,"case-sensitive");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000/Disabled the CHICKEN extensions to R5RS syntax\012");
lf[314]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000%Disabled support for escaped symbols\012");
lf[316]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\377\016");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\052Disabled support for parentheses synonyms\012");
lf[318]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\377\016");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[320]=C_h_intern(&lf[320],7,"\000prefix");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[323]=C_h_intern(&lf[323],7,"\000suffix");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000+missing argument to `-keyword-style\047 option");
lf[325]=C_h_intern(&lf[325],10,"\003sysnodups");
lf[326]=C_h_intern(&lf[326],8,"string=\077");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-feature");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[332]=C_h_intern(&lf[332],16,"case-insensitive");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000-Identifiers and symbols are case insensitive\012");
lf[334]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016");
lf[335]=C_h_intern(&lf[335],12,"load-verbose");
lf[336]=C_h_intern(&lf[336],20,"\003syswarnings-enabled");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\026Warnings are disabled\012");
lf[338]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\377\016");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\013-setup-mode");
lf[341]=C_h_intern(&lf[341],14,"\003syssetup-mode");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\004V    -b  -batch                    terminate after command-line processing\012 "
"   -w  -no-warnings              disable all warnings\012    -K  -keyword-style STY"
"LE      enable alternative keyword-syntax\012                                   (pr"
"efix, suffix or none)\012        -no-parentheses-synonyms  disables list delimiter "
"synonyms\012        -no-symbol-escape         disables support for escaped symbols\012"
"        -r5rs-syntax              disables the CHICKEN extensions to\012           "
"                        R5RS syntax\012    -s  -script PATHNAME          use interp"
"reter for shell scripts\012        -ss PATHNAME              shell script with `mai"
"n\047 procedure\012        -sx PATHNAME              same as `-s\047, but print each expr"
"ession\012                                   as it is evaluated\012        -setup-mode"
"               prefer the current directory when locating extensions\012    -R  -re"
"quire-extension NAME   require extension and import before\012                     "
"              executing code\012    -I  -include-path PATHNAME    add PATHNAME to i"
"nclude path\012    --                            ignore all following options\012");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\003 \047\012");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000D    -n  -no-init                  do not load initialization file ` ");
lf[346]=C_h_intern(&lf[346],19,"\003sysprint-to-string");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\003\052usage: csi [FILENAME | OPTION ...]\012\012  `csi\047 is the CHICKEN interpreter.\012  \012"
"  FILENAME is a Scheme source file name with optional extension. OPTION may be\012 "
" one of the following:\012\012    -h  -help  --help             display this text and "
"exit\012        -version                  display version and exit\012        -release"
"                  print release number and exit\012    -i  -case-insensitive       "
"  enable case-insensitive reading\012    -e  -eval EXPRESSION          evaluate giv"
"en expression\012    -p  -print EXPRESSION         evaluate and print result(s)\012   "
" -P  -pretty-print EXPRESSION  evaluate and print result(s) prettily\012    -D  -fe"
"ature SYMBOL           register feature identifier\012        -no-feature SYMBOL   "
"     disable built-in feature identifier\012    -q  -quiet                    do no"
"t print banner\012");
lf[348]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376B\000\000\006--help\376\377\016");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[352]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[353]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\377\016");
lf[354]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-e\376\003\000\000\002\376B\000\000\002-p\376\003\000\000\002\376B\000\000\002-P\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pr"
"etty-print\376\377\016");
lf[355]=C_h_intern(&lf[355],14,"chicken-script");
lf[356]=C_h_intern(&lf[356],6,"script");
lf[357]=C_h_intern(&lf[357],12,"program-name");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\042missing or invalid script argument");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[360]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[361]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-K\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[363]=C_h_intern(&lf[363],17,"get-output-string");
lf[364]=C_h_intern(&lf[364],18,"open-output-string");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid option syntax");
lf[366]=C_h_intern(&lf[366],7,"reverse");
lf[367]=C_h_intern(&lf[367],22,"with-exception-handler");
lf[368]=C_h_intern(&lf[368],30,"call-with-current-continuation");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\013CSI_OPTIONS");
lf[370]=C_h_intern(&lf[370],28,"\003sysextend-macro-environment");
lf[371]=C_h_intern(&lf[371],10,"defhandler");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\032C_establish_signal_handler");
lf[373]=C_h_intern(&lf[373],11,"\003syssetslot");
lf[374]=C_h_intern(&lf[374],11,"\004coreinline");
lf[375]=C_h_intern(&lf[375],5,"begin");
lf[376]=C_h_intern(&lf[376],25,"\003syssyntax-rules-mismatch");
lf[377]=C_h_intern(&lf[377],18,"\003syser-transformer");
lf[378]=C_h_intern(&lf[378],23,"\003syscurrent-environment");
lf[379]=C_h_intern(&lf[379],11,"make-vector");
lf[380]=C_h_intern(&lf[380],17,"\003syspeek-c-string");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000$; switching current module to `~a\047~%");
lf[383]=C_h_intern(&lf[383],17,"\003sysswitch-module");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\027undefined module `~a\047~%");
lf[385]=C_h_intern(&lf[385],15,"\003sysfind-module");
lf[386]=C_h_intern(&lf[386],23,"\003sysresolve-module-name");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid module name `~a\047~%");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000(; resetting current module to toplevel~%");
lf[389]=C_h_intern(&lf[389],18,"\003sysstring->symbol");
lf[390]=C_h_intern(&lf[390],1,"m");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\0005,m MODULE         switch to module with name `MODULE\047");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\010#;~A~A> ");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\003~a:");
lf[394]=C_h_intern(&lf[394],15,"\003sysmodule-name");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[396]=C_h_intern(&lf[396],18,"\003syscurrent-module");
lf[397]=C_h_intern(&lf[397],11,"repl-prompt");
lf[398]=C_h_intern(&lf[398],15,"\003sysmake-string");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\013emacsclient");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\002vi");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\005EMACS");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\006VISUAL");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\006EDITOR");
lf[404]=C_h_intern(&lf[404],14,"make-parameter");
C_register_lf2(lf,405,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1881,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* a2693 in k2687 in a2684 in k2678 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2694,2,av);}
/* csi.scm:348: eval */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3157 in k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3159(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3159,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3162,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:477: memory-statistics */
t4=C_fast_retrieve(lf[144]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3154 in a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3156,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:476: ##sys#symbol-table-info */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[145]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[145]+1);
av2[1]=t2;
tp(2,av2);}}

/* a3151 in k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3152(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3152,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3156,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:475: gc */
t3=C_fast_retrieve(lf[146]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3148 in report in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_3150(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_3150,2,t0,t1);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:473: with-output-to-port */
t3=((C_word*)t0)[5];{
C_word av2[4];
av2[0]=t3;
av2[1]=((C_word*)t0)[6];
av2[2]=t1;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2820 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2822(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2822,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2827 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2829(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2829,2,av);}
a=C_alloc(4);
t2=((C_word*)t0)[2];
t3=t1;
t4=C_i_numberp(t3);
t5=C_i_not(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5136,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;
f_5136(t7,t5);}
else{
t7=C_i_not(C_fast_retrieve(lf[101]));
if(C_truep(t7)){
t8=t6;
f_5136(t8,t7);}
else{
t8=C_fixnum_lessp(t3,C_fix(0));
if(C_truep(t8)){
t9=t6;
f_5136(t9,t8);}
else{
t9=C_i_length(C_fast_retrieve(lf[101]));
t10=t6;
f_5136(t10,C_fixnum_greater_or_equal_p(t3,t9));}}}}

/* g644 in k4367 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_fcall f_4387(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(20,0,3))){
C_save_and_reclaim_args((void *)trf_4387,3,t0,t1,t2);}
a=C_alloc(20);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4395,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_fast_retrieve(lf[50]);
t9=C_i_cdr(t2);
t10=C_i_check_list_2(t9,lf[230]);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4408,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4414,a[2]=t6,a[3]=t13,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_4414(t15,t11,t9);}

/* k2669 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2671,2,av);}
/* csi.scm:343: string-split */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* for-each-loop246 in k2622 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_2646(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_2646,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2656,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:343: g247 */
t5=((C_word*)t0)[3];
f_2625(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k2639 in k2622 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2641(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2641,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* for-each-loop603 in k4261 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_fcall f_4332(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_4332,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4342,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:707: g604 */
t5=((C_word*)t0)[3];
f_4264(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* for-each-loop1273 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in ... */
static void C_fcall f_6393(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_6393,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6403,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1050: g1274 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4367 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 in ... */
static void C_ccall f_4369(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_4369,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:721: g633 */
t3=t2;
f_4373(t3,((C_word*)t0)[4],t1);}
else{
t2=C_i_assq(((C_word*)t0)[5],C_retrieve2(lf[147],"bytevector-data"));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4387,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:721: g644 */
t4=t3;
f_4387(t4,((C_word*)t0)[4],t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4452,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_slot(((C_word*)t0)[2],C_fix(0));
/* csi.scm:727: fprintf */
t5=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[232];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}}

/* k4340 in for-each-loop603 in k4261 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in ... */
static void C_ccall f_4342(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4342,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4332(t3,((C_word*)t0)[4],t2);}

/* k6382 in map-loop1290 in k6302 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in ... */
static void C_ccall f_6384(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6384,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6359(t6,((C_word*)t0)[5],t5);}

/* for-each-loop293 in k2868 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_2897(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_2897,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2907,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_caddr(t4);
if(C_truep(t5)){
/* csi.scm:408: print */
t6=*((C_word*)lf[10]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=C_make_character(32);
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t6=C_u_i_car(t4);
/* csi.scm:409: print */
t7=*((C_word*)lf[10]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t3;
av2[2]=lf[112];
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k2366 in read-prompt-hook in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2368(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2368,2,av);}
if(C_truep(t1)){
/* csi.scm:273: old */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* ##sys#read-prompt-hook in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2361(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2361,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_fudge(C_fix(12));
if(C_truep(t3)){
if(C_truep(t3)){
/* csi.scm:273: old */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t1;
((C_proc)C_fast_retrieve_proc(t4))(2,av2);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
/* csi.scm:266: ##sys#tty-port? */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[46]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[46]+1);
av2[1]=t2;
av2[2]=*((C_word*)lf[47]+1);
tp(3,av2);}}}

/* k2890 in k2868 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2892,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5591 in k5509 in loop in canonicalize-args in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5593(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5593,2,av);}
/* string->list */
t2=C_fast_retrieve(lf[268]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4393 in g644 in k4367 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in ... */
static void C_ccall f_4395(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4395,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
C_apply(4,av2);}}

/* toplevel-command in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2374(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +12,c,2))){
C_save_and_reclaim((void*)f_2374,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+12);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_check_symbol_2(t2,lf[49]);
t9=(C_truep(t7)?C_i_check_string_2(t7,lf[49]):C_SCHEME_UNDEFINED);
t10=C_i_assq(t2,C_retrieve2(lf[48],"command-table"));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2394,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t12=f_2394(C_a_i(&a,6),t11,t10);
t13=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t11=C_a_i_list3(&a,3,t2,t3,t7);
t12=C_a_i_cons(&a,2,t11,C_retrieve2(lf[48],"command-table"));
t13=C_mutate2(&lf[48] /* (set! command-table ...) */,t12);
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=*((C_word*)lf[41]+1);
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}

/* k2868 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_2870,2,av);}
a=C_alloc(8);
t2=C_retrieve2(lf[48],"command-table");
t3=C_i_check_list_2(C_retrieve2(lf[48],"command-table"),lf[106]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2897,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_2897(t8,t4,C_retrieve2(lf[48],"command-table"));}

/* map-loop1290 in k6302 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in ... */
static void C_fcall f_6359(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_6359,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6384,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* csi.scm:1053: g1296 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6348 in map-loop1316 in k6315 in k6308 in k6302 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in k5690 in k5684 in k5681 in ... */
static void C_ccall f_6350(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6350,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6325(t6,((C_word*)t0)[5],t5);}

/* g633 in k4367 in k4133 in k4019 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in ... */
static void C_fcall f_4373(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_4373,3,t0,t1,t2);}
/* csi.scm:722: g641 */
t3=t2;{
C_word av2[4];
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}

/* k2840 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2842(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2842,2,av);}
a=C_alloc(7);
t2=((C_word*)t0)[2];
t3=C_fast_retrieve(lf[101]);
t4=(C_truep(C_fast_retrieve(lf[101]))?C_fast_retrieve(lf[101]):C_SCHEME_END_OF_LIST);
t5=t4;
t6=C_i_length(t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5193,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_symbolp(t1))){
t8=t7;
f_5193(t8,C_slot(t1,C_fix(1)));}
else{
if(C_truep(C_i_stringp(t1))){
t8=t7;
f_5193(t8,t1);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5420,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:870: display */
t9=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[109];
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}}

/* k5544 in k5523 in k5509 in loop in canonicalize-args in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_5546(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5546,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5550,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* csi.scm:956: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5489(t6,t3,t5);}

/* k2855 in k2852 in k2849 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2857,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2852 in k2849 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2854,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2857,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list1(&a,1,t2);
/* csi.scm:379: history-add */
t5=C_retrieve2(lf[40],"history-add");
f_2222(t5,t3,t4);}

/* k2849 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2851,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:378: system */
t3=C_fast_retrieve(lf[86]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5784 in evalstring in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in ... */
static void C_ccall f_5786(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5786,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5793,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:1024: read */
t4=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2161 in k2155 in k2138 in k2129 in k2117 in lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2163(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_2163,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2170,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:211: string-split */
t4=C_fast_retrieve(lf[33]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[34];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* g1205 in loop in collect-options in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in ... */
static void C_fcall f_5711(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_5711,3,t0,t1,t2);}
a=C_alloc(4);
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
/* csi.scm:1013: ##sys#error */
t4=*((C_word*)lf[42]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[271];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=C_i_cadr(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5732,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
/* csi.scm:1014: loop */
t10=((C_word*)((C_word*)t0)[3])[1];
f_5703(t10,t6,t9);}}

/* k3917 in loop-print in k3877 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_3919(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3919,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
/* csi.scm:653: loop-print */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3888(t7,((C_word*)t0)[5],t3,t6);}

/* k5730 in g1205 in loop in collect-options in k5693 in k5690 in k5684 in k5681 in k5678 in k5675 in k5672 in k5669 in k5666 in k5663 in k5660 in k5421 in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in ... */
static void C_ccall f_5732(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_5732,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4010 in k3991 in k3874 in k3762 in k3627 in describe in k3487 in k3139 in k3136 in k2991 in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_4012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,7))){C_save_and_reclaim((void *)f_4012,2,av);}
/* csi.scm:662: fprintf */
t2=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[202];
av2[4]=((C_word*)t0)[4];
av2[5]=((C_word*)t0)[5];
av2[6]=((C_word*)t0)[6];
av2[7]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(8,av2);}}

/* k2197 in loop in k2168 in k2161 in k2155 in k2138 in k2129 in k2117 in lookup-script-file in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_ccall f_2199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2199,2,av);}
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[27]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* k6041 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in ... */
static void C_ccall f_6043(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6043,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_u_i_cdr(t2));
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_5908(t5,((C_word*)t0)[4],t4);}

/* k5134 in k2827 in k2438 in csi-eval in k2344 in k2043 in k1912 in k1909 in k1904 in k1891 in k1888 in k1885 in k1882 in k1879 */
static void C_fcall f_5136(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_5136,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm:851: display */
t2=*((C_word*)lf[99]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[100];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_i_length(C_fast_retrieve(lf[101]));
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_fixnum_difference(t2,t3);
t5=C_i_list_ref(C_fast_retrieve(lf[101]),t4);
t6=C_mutate2(&lf[7] /* (set! selected-frame ...) */,t5);
/* csi.scm:857: show-frameinfo */
f_4851(((C_word*)t0)[2],C_retrieve2(lf[7],"selected-frame"));}}

/* a6027 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in ... */
static void C_ccall f_6028(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +0,c,4))){
C_save_and_reclaim((void*)f_6028,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+0);
t2=C_build_rest(&a,c,2,av);
C_word t3;{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t1;
av2[2]=*((C_word*)lf[106]+1);
av2[3]=*((C_word*)lf[10]+1);
av2[4]=t2;
C_apply(5,av2);}}

/* k6018 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in ... */
static void C_ccall f_6020(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6020,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_u_i_cdr(t2));
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_5908(t5,((C_word*)t0)[4],t4);}

/* k5764 in k5758 in k5746 in k6183 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in ... */
static void C_ccall f_5766(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5766,2,av);}
if(C_truep(t1)){
/* csi.scm:1021: load */
t2=C_fast_retrieve(lf[72]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5758 in k5746 in k6183 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in k5693 in ... */
static void C_ccall f_5760(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5760,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5766,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1020: file-exists? */
t4=C_fast_retrieve(lf[26]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a6050 in doloop1356 in k5901 in k5898 in k5895 in k5892 in k5889 in k5886 in k5883 in k5879 in k5873 in k5870 in k5864 in k5861 in k5855 in k5852 in k5849 in k5846 in k5843 in k5840 in k5837 in k5834 in ... */
static void C_ccall f_6051(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +0,c,4))){
C_save_and_reclaim((void*)f_6051,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+0);
t2=C_build_rest(&a,c,2,av);
C_word t3;{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t1;
av2[2]=*((C_word*)lf[106]+1);
av2[3]=C_fast_retrieve(lf[54]);
av2[4]=t2;
C_apply(5,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[500] = {
{"f_5773:csi_2escm",(void*)f_5773},
{"f_5779:csi_2escm",(void*)f_5779},
{"f_5034:csi_2escm",(void*)f_5034},
{"f_5703:csi_2escm",(void*)f_5703},
{"f_6600:csi_2escm",(void*)f_6600},
{"f_5795:csi_2escm",(void*)f_5795},
{"f_5793:csi_2escm",(void*)f_5793},
{"f_3344:csi_2escm",(void*)f_3344},
{"f_3349:csi_2escm",(void*)f_3349},
{"f_6678:csi_2escm",(void*)f_6678},
{"f_3993:csi_2escm",(void*)f_3993},
{"f_6665:csi_2escm",(void*)f_6665},
{"f_2394:csi_2escm",(void*)f_2394},
{"f_3322:csi_2escm",(void*)f_3322},
{"f_3983:csi_2escm",(void*)f_3983},
{"f_3987:csi_2escm",(void*)f_3987},
{"f_5748:csi_2escm",(void*)f_5748},
{"f_3118:csi_2escm",(void*)f_3118},
{"f_6836:csi_2escm",(void*)f_6836},
{"f_6698:csi_2escm",(void*)f_6698},
{"f_6692:csi_2escm",(void*)f_6692},
{"f_6695:csi_2escm",(void*)f_6695},
{"f_5310:csi_2escm",(void*)f_5310},
{"f_5313:csi_2escm",(void*)f_5313},
{"f_6686:csi_2escm",(void*)f_6686},
{"f_5316:csi_2escm",(void*)f_5316},
{"f_5319:csi_2escm",(void*)f_5319},
{"f_6682:csi_2escm",(void*)f_6682},
{"f_3142:csi_2escm",(void*)f_3142},
{"f_3141:csi_2escm",(void*)f_3141},
{"f_5322:csi_2escm",(void*)f_5322},
{"f_3130:csi_2escm",(void*)f_3130},
{"f_6872:csi_2escm",(void*)f_6872},
{"f_3138:csi_2escm",(void*)f_3138},
{"f_6824:csi_2escm",(void*)f_6824},
{"f_6820:csi_2escm",(void*)f_6820},
{"f_6827:csi_2escm",(void*)f_6827},
{"f_3124:csi_2escm",(void*)f_3124},
{"f_3509:csi_2escm",(void*)f_3509},
{"f_3504:csi_2escm",(void*)f_3504},
{"f_6859:csi_2escm",(void*)f_6859},
{"f_6851:csi_2escm",(void*)f_6851},
{"f_6855:csi_2escm",(void*)f_6855},
{"f_6072:csi_2escm",(void*)f_6072},
{"f_5358:csi_2escm",(void*)f_5358},
{"f_2014:csi_2escm",(void*)f_2014},
{"f_6885:csi_2escm",(void*)f_6885},
{"f_4141:csi_2escm",(void*)f_4141},
{"f_6883:csi_2escm",(void*)f_6883},
{"f_5365:csi_2escm",(void*)f_5365},
{"f_5367:csi_2escm",(void*)f_5367},
{"f_6200:csi_2escm",(void*)f_6200},
{"f_6203:csi_2escm",(void*)f_6203},
{"f_6218:csi_2escm",(void*)f_6218},
{"f_4154:csi_2escm",(void*)f_4154},
{"f_5377:csi_2escm",(void*)f_5377},
{"f_6206:csi_2escm",(void*)f_6206},
{"f_6209:csi_2escm",(void*)f_6209},
{"f_6080:csi_2escm",(void*)f_6080},
{"f_4129:csi_2escm",(void*)f_4129},
{"f_6082:csi_2escm",(void*)f_6082},
{"f_2045:csi_2escm",(void*)f_2045},
{"f_3704:csi_2escm",(void*)f_3704},
{"f_6896:csi_2escm",(void*)f_6896},
{"f_6893:csi_2escm",(void*)f_6893},
{"f_5554:csi_2escm",(void*)f_5554},
{"f_5550:csi_2escm",(void*)f_5550},
{"f_4135:csi_2escm",(void*)f_4135},
{"f_3771:csi_2escm",(void*)f_3771},
{"f_6061:csi_2escm",(void*)f_6061},
{"f_6757:csi_2escm",(void*)f_6757},
{"f_2027:csi_2escm",(void*)f_2027},
{"f_3764:csi_2escm",(void*)f_3764},
{"f_6426:csi_2escm",(void*)f_6426},
{"f_6777:csi_2escm",(void*)f_6777},
{"f_3583:csi_2escm",(void*)f_3583},
{"f_6416:csi_2escm",(void*)f_6416},
{"f_4021:csi_2escm",(void*)f_4021},
{"f_4028:csi_2escm",(void*)f_4028},
{"f_3262:csi_2escm",(void*)f_3262},
{"f_6765:csi_2escm",(void*)f_6765},
{"f_6403:csi_2escm",(void*)f_6403},
{"f_6714:csi_2escm",(void*)f_6714},
{"f_6712:csi_2escm",(void*)f_6712},
{"f_2232:csi_2escm",(void*)f_2232},
{"f_6700:csi_2escm",(void*)f_6700},
{"f_3554:csi_2escm",(void*)f_3554},
{"f_6708:csi_2escm",(void*)f_6708},
{"f_3551:csi_2escm",(void*)f_3551},
{"f_3798:csi_2escm",(void*)f_3798},
{"f_6737:csi_2escm",(void*)f_6737},
{"f_3541:csi_2escm",(void*)f_3541},
{"f_3786:csi_2escm",(void*)f_3786},
{"f_3783:csi_2escm",(void*)f_3783},
{"f_3780:csi_2escm",(void*)f_3780},
{"f_2246:csi_2escm",(void*)f_2246},
{"f_6724:csi_2escm",(void*)f_6724},
{"f_3532:csi_2escm",(void*)f_3532},
{"f_2222:csi_2escm",(void*)f_2222},
{"f_6449:csi_2escm",(void*)f_6449},
{"f_4608:csi_2escm",(void*)f_4608},
{"f_6439:csi_2escm",(void*)f_6439},
{"f_3073:csi_2escm",(void*)f_3073},
{"f_6497:csi_2escm",(void*)f_6497},
{"f_4731:csi_2escm",(void*)f_4731},
{"f_4728:csi_2escm",(void*)f_4728},
{"f_3079:csi_2escm",(void*)f_3079},
{"f_6487:csi_2escm",(void*)f_6487},
{"f_4706:csi_2escm",(void*)f_4706},
{"f_4703:csi_2escm",(void*)f_4703},
{"f_6484:csi_2escm",(void*)f_6484},
{"f_4700:csi_2escm",(void*)f_4700},
{"f_3101:csi_2escm",(void*)f_3101},
{"f_2732:csi_2escm",(void*)f_2732},
{"f_3058:csi_2escm",(void*)f_3058},
{"f_6478:csi_2escm",(void*)f_6478},
{"f_4715:csi_2escm",(void*)f_4715},
{"f_4613:csi_2escm",(void*)f_4613},
{"f_3085:csi_2escm",(void*)f_3085},
{"f_6469:csi_2escm",(void*)f_6469},
{"f_6149:csi_2escm",(void*)f_6149},
{"f_6466:csi_2escm",(void*)f_6466},
{"f_6463:csi_2escm",(void*)f_6463},
{"f_4766:csi_2escm",(void*)f_4766},
{"f_4671:csi_2escm",(void*)f_4671},
{"f_4408:csi_2escm",(void*)f_4408},
{"f_4681:csi_2escm",(void*)f_4681},
{"f_3294:csi_2escm",(void*)f_3294},
{"f_3290:csi_2escm",(void*)f_3290},
{"f_6116:csi_2escm",(void*)f_6116},
{"f_3286:csi_2escm",(void*)f_3286},
{"f_6112:csi_2escm",(void*)f_6112},
{"f_3282:csi_2escm",(void*)f_3282},
{"f_6230:csi_2escm",(void*)f_6230},
{"f_2748:csi_2escm",(void*)f_2748},
{"f_5900:csi_2escm",(void*)f_5900},
{"f_5908:csi_2escm",(void*)f_5908},
{"f_5903:csi_2escm",(void*)f_5903},
{"f_2921:csi_2escm",(void*)f_2921},
{"f_3278:csi_2escm",(void*)f_3278},
{"f_3274:csi_2escm",(void*)f_3274},
{"f_6221:csi_2escm",(void*)f_6221},
{"f_3270:csi_2escm",(void*)f_3270},
{"f_4263:csi_2escm",(void*)f_4263},
{"f_4264:csi_2escm",(void*)f_4264},
{"f_6233:csi_2escm",(void*)f_6233},
{"f_4277:csi_2escm",(void*)f_4277},
{"f_5921:csi_2escm",(void*)f_5921},
{"f_5929:csi_2escm",(void*)f_5929},
{"f_5926:csi_2escm",(void*)f_5926},
{"f_2907:csi_2escm",(void*)f_2907},
{"f_4268:csi_2escm",(void*)f_4268},
{"f_1893:csi_2escm",(void*)f_1893},
{"f_5974:csi_2escm",(void*)f_5974},
{"f_1890:csi_2escm",(void*)f_1890},
{"f_4648:csi_2escm",(void*)f_4648},
{"f_4414:csi_2escm",(void*)f_4414},
{"f_4691:csi_2escm",(void*)f_4691},
{"f_4694:csi_2escm",(void*)f_4694},
{"f_1884:csi_2escm",(void*)f_1884},
{"f_2704:csi_2escm",(void*)f_2704},
{"f_2700:csi_2escm",(void*)f_2700},
{"f_1887:csi_2escm",(void*)f_1887},
{"f_2786:csi_2escm",(void*)f_2786},
{"f_1881:csi_2escm",(void*)f_1881},
{"f_4697:csi_2escm",(void*)f_4697},
{"f_5945:csi_2escm",(void*)f_5945},
{"f_4287:csi_2escm",(void*)f_4287},
{"f_2713:csi_2escm",(void*)f_2713},
{"f_2711:csi_2escm",(void*)f_2711},
{"f_2798:csi_2escm",(void*)f_2798},
{"f_2717:csi_2escm",(void*)f_2717},
{"f_2766:csi_2escm",(void*)f_2766},
{"f_3067:csi_2escm",(void*)f_3067},
{"f_4483:csi_2escm",(void*)f_4483},
{"f_4886:csi_2escm",(void*)f_4886},
{"f_2777:csi_2escm",(void*)f_2777},
{"f_2770:csi_2escm",(void*)f_2770},
{"f_4452:csi_2escm",(void*)f_4452},
{"f_3099:csi_2escm",(void*)f_3099},
{"f_3091:csi_2escm",(void*)f_3091},
{"f_5420:csi_2escm",(void*)f_5420},
{"f_5423:csi_2escm",(void*)f_5423},
{"f_5988:csi_2escm",(void*)f_5988},
{"f_5428:csi_2escm",(void*)f_5428},
{"f_2977:csi_2escm",(void*)f_2977},
{"f_2080:csi_2escm",(void*)f_2080},
{"f_5601:csi_2escm",(void*)f_5601},
{"f_2973:csi_2escm",(void*)f_2973},
{"f_5483:csi_2escm",(void*)f_5483},
{"f_5489:csi_2escm",(void*)f_5489},
{"f_4491:csi_2escm",(void*)f_4491},
{"f_2064:csi_2escm",(void*)f_2064},
{"f_2967:csi_2escm",(void*)f_2967},
{"f_2074:csi_2escm",(void*)f_2074},
{"f_2071:csi_2escm",(void*)f_2071},
{"f_5434:csi_2escm",(void*)f_5434},
{"f_5273:csi_2escm",(void*)f_5273},
{"f_2999:csi_2escm",(void*)f_2999},
{"f_2993:csi_2escm",(void*)f_2993},
{"f_4651:csi_2escm",(void*)f_4651},
{"f_4655:csi_2escm",(void*)f_4655},
{"f_3828:csi_2escm",(void*)f_3828},
{"f_6136:csi_2escm",(void*)f_6136},
{"f_5683:csi_2escm",(void*)f_5683},
{"f_5686:csi_2escm",(void*)f_5686},
{"f_5680:csi_2escm",(void*)f_5680},
{"f_6131:csi_2escm",(void*)f_6131},
{"f_6128:csi_2escm",(void*)f_6128},
{"f_6125:csi_2escm",(void*)f_6125},
{"f_5695:csi_2escm",(void*)f_5695},
{"f_5692:csi_2escm",(void*)f_5692},
{"f_2093:csi_2escm",(void*)f_2093},
{"f_6297:csi_2escm",(void*)f_6297},
{"f_5697:csi_2escm",(void*)f_5697},
{"f_6122:csi_2escm",(void*)f_6122},
{"f_3803:csi_2escm",(void*)f_3803},
{"f_6152:csi_2escm",(void*)f_6152},
{"f_3240:csi_2escm",(void*)f_3240},
{"f_3243:csi_2escm",(void*)f_3243},
{"f_3246:csi_2escm",(void*)f_3246},
{"f_5674:csi_2escm",(void*)f_5674},
{"f_5677:csi_2escm",(void*)f_5677},
{"f_5671:csi_2escm",(void*)f_5671},
{"f_3234:csi_2escm",(void*)f_3234},
{"f_3237:csi_2escm",(void*)f_3237},
{"f_5446:csi_2escm",(void*)f_5446},
{"f_3816:csi_2escm",(void*)f_3816},
{"f_3819:csi_2escm",(void*)f_3819},
{"f_3813:csi_2escm",(void*)f_3813},
{"f_3217:csi_2escm",(void*)f_3217},
{"f_3200:csi_2escm",(void*)f_3200},
{"f_3209:csi_2escm",(void*)f_3209},
{"f_3876:csi_2escm",(void*)f_3876},
{"f_3879:csi_2escm",(void*)f_3879},
{"f_5632:csi_2escm",(void*)f_5632},
{"f_3632:csi_2escm",(void*)f_3632},
{"f_4439:csi_2escm",(void*)f_4439},
{"f_3022:csi_2escm",(void*)f_3022},
{"f_3025:csi_2escm",(void*)f_3025},
{"f_6903:csi_2escm",(void*)f_6903},
{"f_6907:csi_2escm",(void*)f_6907},
{"f_3611:csi_2escm",(void*)f_3611},
{"f_3888:csi_2escm",(void*)f_3888},
{"f_5668:csi_2escm",(void*)f_5668},
{"f_5665:csi_2escm",(void*)f_5665},
{"f_5662:csi_2escm",(void*)f_5662},
{"f_5282:csi_2escm",(void*)f_5282},
{"f_3629:csi_2escm",(void*)f_3629},
{"f_5288:csi_2escm",(void*)f_5288},
{"f_3626:csi_2escm",(void*)f_3626},
{"f_5298:csi_2escm",(void*)f_5298},
{"f_3864:csi_2escm",(void*)f_3864},
{"f_3033:csi_2escm",(void*)f_3033},
{"f_3861:csi_2escm",(void*)f_3861},
{"f_2299:csi_2escm",(void*)f_2299},
{"f_2296:csi_2escm",(void*)f_2296},
{"f_2290:csi_2escm",(void*)f_2290},
{"f_2293:csi_2escm",(void*)f_2293},
{"f_5248:csi_2escm",(void*)f_5248},
{"f_3013:csi_2escm",(void*)f_3013},
{"f_3016:csi_2escm",(void*)f_3016},
{"f_2277:csi_2escm",(void*)f_2277},
{"f_6185:csi_2escm",(void*)f_6185},
{"f_3404:csi_2escm",(void*)f_3404},
{"f_5229:csi_2escm",(void*)f_5229},
{"f_6916:csi_2escm",(void*)f_6916},
{"f_4166:csi_2escm",(void*)f_4166},
{"f_4169:csi_2escm",(void*)f_4169},
{"f_5226:csi_2escm",(void*)f_5226},
{"f_3852:csi_2escm",(void*)f_3852},
{"f_5233:csi_2escm",(void*)f_5233},
{"f_5236:csi_2escm",(void*)f_5236},
{"f_5206:csi_2escm",(void*)f_5206},
{"f_5081:csi_2escm",(void*)f_5081},
{"f_4228:csi_2escm",(void*)f_4228},
{"f_4960:csi_2escm",(void*)f_4960},
{"f_2131:csi_2escm",(void*)f_2131},
{"f_4970:csi_2escm",(void*)f_4970},
{"f_4975:csi_2escm",(void*)f_4975},
{"f_6166:csi_2escm",(void*)f_6166},
{"f_4947:csi_2escm",(void*)f_4947},
{"f_4209:csi_2escm",(void*)f_4209},
{"f_2143:csi_2escm",(void*)f_2143},
{"f_2140:csi_2escm",(void*)f_2140},
{"f_4941:csi_2escm",(void*)f_4941},
{"f_4944:csi_2escm",(void*)f_4944},
{"f_6197:csi_2escm",(void*)f_6197},
{"f_5095:csi_2escm",(void*)f_5095},
{"f_2115:csi_2escm",(void*)f_2115},
{"f_3497:csi_2escm",(void*)f_3497},
{"f_3491:csi_2escm",(void*)f_3491},
{"f_2119:csi_2escm",(void*)f_2119},
{"f_4218:csi_2escm",(void*)f_4218},
{"f_6504:csi_2escm",(void*)f_6504},
{"f_4929:csi_2escm",(void*)f_4929},
{"f_3489:csi_2escm",(void*)f_3489},
{"f_4926:csi_2escm",(void*)f_4926},
{"f_4923:csi_2escm",(void*)f_4923},
{"f_4920:csi_2escm",(void*)f_4920},
{"f_5078:csi_2escm",(void*)f_5078},
{"f_4938:csi_2escm",(void*)f_4938},
{"f_6520:csi_2escm",(void*)f_6520},
{"f_6523:csi_2escm",(void*)f_6523},
{"f_6528:csi_2escm",(void*)f_6528},
{"f_4935:csi_2escm",(void*)f_4935},
{"f_4932:csi_2escm",(void*)f_4932},
{"f_2346:csi_2escm",(void*)f_2346},
{"f_6514:csi_2escm",(void*)f_6514},
{"f_4917:csi_2escm",(void*)f_4917},
{"f_3459:csi_2escm",(void*)f_3459},
{"f_3698:csi_2escm",(void*)f_3698},
{"f_1920:csi_2escm",(void*)f_1920},
{"f_1923:csi_2escm",(void*)f_1923},
{"f_1911:csi_2escm",(void*)f_1911},
{"f_1914:csi_2escm",(void*)f_1914},
{"f_2321:csi_2escm",(void*)f_2321},
{"f_6564:csi_2escm",(void*)f_6564},
{"f_3424:csi_2escm",(void*)f_3424},
{"f_4180:csi_2escm",(void*)f_4180},
{"f_6553:csi_2escm",(void*)f_6553},
{"f_4188:csi_2escm",(void*)f_4188},
{"f_2501:csi_2escm",(void*)f_2501},
{"f_2302:csi_2escm",(void*)f_2302},
{"f7575:csi_2escm",(void*)f7575},
{"f_6588:csi_2escm",(void*)f_6588},
{"f_6585:csi_2escm",(void*)f_6585},
{"f_2513:csi_2escm",(void*)f_2513},
{"f_6582:csi_2escm",(void*)f_6582},
{"f_2516:csi_2escm",(void*)f_2516},
{"f_4838:csi_2escm",(void*)f_4838},
{"f_2311:csi_2escm",(void*)f_2311},
{"f_3359:csi_2escm",(void*)f_3359},
{"f_6579:csi_2escm",(void*)f_6579},
{"f_6573:csi_2escm",(void*)f_6573},
{"f_4810:csi_2escm",(void*)f_4810},
{"f_1906:csi_2escm",(void*)f_1906},
{"f_4823:csi_2escm",(void*)f_4823},
{"f_6591:csi_2escm",(void*)f_6591},
{"f_4820:csi_2escm",(void*)f_4820},
{"f_1977:csi_2escm",(void*)f_1977},
{"f_4877:csi_2escm",(void*)f_4877},
{"f_4500:csi_2escm",(void*)f_4500},
{"f_4502:csi_2escm",(void*)f_4502},
{"f_4505:csi_2escm",(void*)f_4505},
{"f_5826:csi_2escm",(void*)f_5826},
{"f_4800:csi_2escm",(void*)f_4800},
{"f_1997:csi_2escm",(void*)f_1997},
{"f_1999:csi_2escm",(void*)f_1999},
{"f_4851:csi_2escm",(void*)f_4851},
{"f_4854:csi_2escm",(void*)f_4854},
{"f_5839:csi_2escm",(void*)f_5839},
{"f_5836:csi_2escm",(void*)f_5836},
{"f_4860:csi_2escm",(void*)f_4860},
{"f_5805:csi_2escm",(void*)f_5805},
{"f_2585:csi_2escm",(void*)f_2585},
{"f_2582:csi_2escm",(void*)f_2582},
{"f_1930:csi_2escm",(void*)f_1930},
{"f_5195:csi_2escm",(void*)f_5195},
{"f_5193:csi_2escm",(void*)f_5193},
{"f_2486:csi_2escm",(void*)f_2486},
{"f_2482:csi_2escm",(void*)f_2482},
{"f_5812:csi_2escm",(void*)f_5812},
{"f_5818:csi_2escm",(void*)f_5818},
{"f_5816:csi_2escm",(void*)f_5816},
{"f_2590:csi_2escm",(void*)f_2590},
{"f_1960:csi_2escm",(void*)f_1960},
{"f_2495:csi_2escm",(void*)f_2495},
{"f_2498:csi_2escm",(void*)f_2498},
{"f_5863:csi_2escm",(void*)f_5863},
{"f_5866:csi_2escm",(void*)f_5866},
{"f_4842:csi_2escm",(void*)f_4842},
{"f_2624:csi_2escm",(void*)f_2624},
{"f_2625:csi_2escm",(void*)f_2625},
{"f_1958:csi_2escm",(void*)f_1958},
{"f_1951:csi_2escm",(void*)f_1951},
{"f_4849:csi_2escm",(void*)f_4849},
{"f_5872:csi_2escm",(void*)f_5872},
{"f_5875:csi_2escm",(void*)f_5875},
{"f_2635:csi_2escm",(void*)f_2635},
{"f_2631:csi_2escm",(void*)f_2631},
{"f_1989:csi_2escm",(void*)f_1989},
{"f_3187:csi_2escm",(void*)f_3187},
{"f_3183:csi_2escm",(void*)f_3183},
{"f_3182:csi_2escm",(void*)f_3182},
{"f_2106:csi_2escm",(void*)f_2106},
{"f_4988:csi_2escm",(void*)f_4988},
{"f_2475:csi_2escm",(void*)f_2475},
{"f_5845:csi_2escm",(void*)f_5845},
{"f_2472:csi_2escm",(void*)f_2472},
{"f_5842:csi_2escm",(void*)f_5842},
{"f_5848:csi_2escm",(void*)f_5848},
{"f_4527:csi_2escm",(void*)f_4527},
{"f_2600:csi_2escm",(void*)f_2600},
{"f_2546:csi_2escm",(void*)f_2546},
{"f_2549:csi_2escm",(void*)f_2549},
{"f_3179:csi_2escm",(void*)f_3179},
{"f_2543:csi_2escm",(void*)f_2543},
{"f_3172:csi_2escm",(void*)f_3172},
{"f_4997:csi_2escm",(void*)f_4997},
{"f_2440:csi_2escm",(void*)f_2440},
{"f_5854:csi_2escm",(void*)f_5854},
{"f_5857:csi_2escm",(void*)f_5857},
{"f_5851:csi_2escm",(void*)f_5851},
{"f_4991:csi_2escm",(void*)f_4991},
{"f_4994:csi_2escm",(void*)f_4994},
{"f_2552:csi_2escm",(void*)f_2552},
{"f_3162:csi_2escm",(void*)f_3162},
{"f_6003:csi_2escm",(void*)f_6003},
{"f_3164:csi_2escm",(void*)f_3164},
{"f_4300:csi_2escm",(void*)f_4300},
{"f_4305:csi_2escm",(void*)f_4305},
{"f_2457:csi_2escm",(void*)f_2457},
{"f_5000:csi_2escm",(void*)f_5000},
{"f_4580:csi_2escm",(void*)f_4580},
{"f_2528:csi_2escm",(void*)f_2528},
{"f_2424:csi_2escm",(void*)f_2424},
{"f_2531:csi_2escm",(void*)f_2531},
{"f_1948:csi_2escm",(void*)f_1948},
{"f_1944:csi_2escm",(void*)f_1944},
{"f_3379:csi_2escm",(void*)f_3379},
{"f_5888:csi_2escm",(void*)f_5888},
{"f_5885:csi_2escm",(void*)f_5885},
{"f_3377:csi_2escm",(void*)f_3377},
{"f_5881:csi_2escm",(void*)f_5881},
{"f_6310:csi_2escm",(void*)f_6310},
{"f_6317:csi_2escm",(void*)f_6317},
{"f_5897:csi_2escm",(void*)f_5897},
{"f_4570:csi_2escm",(void*)f_4570},
{"f_5894:csi_2escm",(void*)f_5894},
{"f_5891:csi_2escm",(void*)f_5891},
{"f_2656:csi_2escm",(void*)f_2656},
{"f_6304:csi_2escm",(void*)f_6304},
{"f_2810:csi_2escm",(void*)f_2810},
{"f_5044:csi_2escm",(void*)f_5044},
{"f_5511:csi_2escm",(void*)f_5511},
{"f_4551:csi_2escm",(void*)f_4551},
{"f_6323:csi_2escm",(void*)f_6323},
{"f_2172:csi_2escm",(void*)f_2172},
{"f_2170:csi_2escm",(void*)f_2170},
{"f_6325:csi_2escm",(void*)f_6325},
{"f_5525:csi_2escm",(void*)f_5525},
{"f_2689:csi_2escm",(void*)f_2689},
{"f_2185:csi_2escm",(void*)f_2185},
{"f_2685:csi_2escm",(void*)f_2685},
{"f_2182:csi_2escm",(void*)f_2182},
{"f_2680:csi_2escm",(void*)f_2680},
{"f_4534:csi_2escm",(void*)f_4534},
{"f_2615:csi_2escm",(void*)f_2615},
{"f_2157:csi_2escm",(void*)f_2157},
{"f_2154:csi_2escm",(void*)f_2154},
{"f_2150:csi_2escm",(void*)f_2150},
{"toplevel:csi_2escm",(void*)C_toplevel},
{"f_2694:csi_2escm",(void*)f_2694},
{"f_3159:csi_2escm",(void*)f_3159},
{"f_3156:csi_2escm",(void*)f_3156},
{"f_3152:csi_2escm",(void*)f_3152},
{"f_3150:csi_2escm",(void*)f_3150},
{"f_2822:csi_2escm",(void*)f_2822},
{"f_2829:csi_2escm",(void*)f_2829},
{"f_4387:csi_2escm",(void*)f_4387},
{"f_2671:csi_2escm",(void*)f_2671},
{"f_2646:csi_2escm",(void*)f_2646},
{"f_2641:csi_2escm",(void*)f_2641},
{"f_4332:csi_2escm",(void*)f_4332},
{"f_6393:csi_2escm",(void*)f_6393},
{"f_4369:csi_2escm",(void*)f_4369},
{"f_4342:csi_2escm",(void*)f_4342},
{"f_6384:csi_2escm",(void*)f_6384},
{"f_2897:csi_2escm",(void*)f_2897},
{"f_2368:csi_2escm",(void*)f_2368},
{"f_2361:csi_2escm",(void*)f_2361},
{"f_2892:csi_2escm",(void*)f_2892},
{"f_5593:csi_2escm",(void*)f_5593},
{"f_4395:csi_2escm",(void*)f_4395},
{"f_2374:csi_2escm",(void*)f_2374},
{"f_2870:csi_2escm",(void*)f_2870},
{"f_6359:csi_2escm",(void*)f_6359},
{"f_6350:csi_2escm",(void*)f_6350},
{"f_4373:csi_2escm",(void*)f_4373},
{"f_2842:csi_2escm",(void*)f_2842},
{"f_5546:csi_2escm",(void*)f_5546},
{"f_2857:csi_2escm",(void*)f_2857},
{"f_2854:csi_2escm",(void*)f_2854},
{"f_2851:csi_2escm",(void*)f_2851},
{"f_5786:csi_2escm",(void*)f_5786},
{"f_2163:csi_2escm",(void*)f_2163},
{"f_5711:csi_2escm",(void*)f_5711},
{"f_3919:csi_2escm",(void*)f_3919},
{"f_5732:csi_2escm",(void*)f_5732},
{"f_4012:csi_2escm",(void*)f_4012},
{"f_2199:csi_2escm",(void*)f_2199},
{"f_6043:csi_2escm",(void*)f_6043},
{"f_5136:csi_2escm",(void*)f_5136},
{"f_6028:csi_2escm",(void*)f_6028},
{"f_6020:csi_2escm",(void*)f_6020},
{"f_5766:csi_2escm",(void*)f_5766},
{"f_5760:csi_2escm",(void*)f_5760},
{"f_6051:csi_2escm",(void*)f_6051},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  map		7
S|  for-each		11
S|  printf		4
o|eliminated procedure checks: 147 
o|eliminated procedure checks: 1 
o|specializations:
o|  7 (string=? string string)
o|  1 (set-cdr! pair *)
o|  2 (cddr (pair * pair))
o|  2 (char=? char char)
o|  3 (cadr (pair * pair))
o|  1 (min fixnum fixnum)
o|  1 (memq * list)
o|  22 (cdr pair)
o|  1 (current-output-port)
o|  8 (car pair)
o|  2 (zero? fixnum)
o|  5 (##sys#check-list (or pair list) *)
o|  29 (eqv? * (not float))
o|  4 (##sys#check-output-port * * *)
o|  1 (> fixnum fixnum)
o|  4 (string-append string string)
o|  1 (make-string fixnum)
(o e)|safe calls: 740 
o|safe globals: (##sys#repl-print-length-limit constant8 constant3 constant0) 
o|Removed `not' forms: 8 
o|substituted constant variable: constant3 
o|substituted constant variable: constant0 
o|inlining procedure: k1962 
o|inlining procedure: k1962 
o|inlining procedure: k2004 
o|inlining procedure: k2004 
o|inlining procedure: k2022 
o|inlining procedure: k2022 
o|inlining procedure: k2066 
o|inlining procedure: k2066 
o|substituted constant variable: a2082 
o|inlining procedure: k2120 
o|inlining procedure: k2135 
o|contracted procedure: "(csi.scm:206) _getcwd60" 
o|inlining procedure: k2135 
o|inlining procedure: k2174 
o|inlining procedure: k2174 
o|substituted constant variable: a2205 
o|contracted procedure: "(csi.scm:205) string-index71" 
o|inlining procedure: k2095 
o|inlining procedure: k2095 
o|inlining procedure: k2120 
o|substituted constant variable: a2215 
o|inlining procedure: k2279 
o|propagated global variable: out123127 ##sys#standard-output 
o|substituted constant variable: a2286 
o|substituted constant variable: a2287 
o|inlining procedure: k2279 
o|propagated global variable: out123127 ##sys#standard-output 
o|inlining procedure: k2326 
o|inlining procedure: k2326 
o|inlining procedure: k2363 
o|inlining procedure: k2363 
o|contracted procedure: "(csi.scm:273) tty-input?" 
o|inlining procedure: k2353 
o|inlining procedure: k2353 
o|inlining procedure: k2388 
o|inlining procedure: k2388 
o|inlining procedure: k2426 
o|inlining procedure: k2426 
o|inlining procedure: k2447 
o|contracted procedure: "(csi.scm:305) g199200" 
o|inlining procedure: k2447 
o|inlining procedure: k2487 
o|inlining procedure: k2487 
o|consed rest parameter at call site: "(csi.scm:325) describe" 2 
o|inlining procedure: k2520 
o|consed rest parameter at call site: "(csi.scm:329) dump" 2 
o|inlining procedure: k2520 
o|consed rest parameter at call site: "(csi.scm:335) dump" 2 
o|inlining procedure: k2556 
o|consed rest parameter at call site: "(csi.scm:336) report" 1 
o|inlining procedure: k2556 
o|inlining procedure: k2574 
o|inlining procedure: k2592 
o|inlining procedure: k2592 
o|inlining procedure: k2574 
o|inlining procedure: k2648 
o|inlining procedure: k2648 
o|inlining procedure: k2672 
o|inlining procedure: k2672 
o|inlining procedure: k2727 
o|consed rest parameter at call site: "(csi.scm:354) describe" 2 
o|inlining procedure: k2727 
o|inlining procedure: k2740 
o|contracted procedure: k2752 
o|inlining procedure: k2740 
o|contracted procedure: "(csi.scm:363) history-clear" 
o|inlining procedure: k2790 
o|inlining procedure: k2790 
o|inlining procedure: k2814 
o|inlining procedure: k2814 
o|inlining procedure: k2843 
o|inlining procedure: k2843 
o|inlining procedure: k2899 
o|contracted procedure: "(csi.scm:404) g294301" 
o|inlining procedure: k2876 
o|inlining procedure: k2876 
o|inlining procedure: k2899 
o|propagated global variable: g300302 command-table 
o|substituted constant variable: a2926 
o|substituted constant variable: a2928 
o|substituted constant variable: a2930 
o|substituted constant variable: a2932 
o|substituted constant variable: a2934 
o|substituted constant variable: a2936 
o|substituted constant variable: a2938 
o|substituted constant variable: a2940 
o|substituted constant variable: a2942 
o|substituted constant variable: a2944 
o|substituted constant variable: a2946 
o|substituted constant variable: a2948 
o|substituted constant variable: a2950 
o|substituted constant variable: a2952 
o|substituted constant variable: a2954 
o|substituted constant variable: a2956 
o|substituted constant variable: a2958 
o|substituted constant variable: a2960 
o|substituted constant variable: a2962 
o|merged explicitly consed rest parameter: port387 
o|inlining procedure: k3201 
o|inlining procedure: k3201 
o|inlining procedure: k3244 
o|inlining procedure: k3244 
o|inlining procedure: k3351 
o|inlining procedure: k3351 
o|inlining procedure: k3381 
o|inlining procedure: k3381 
o|propagated global variable: g408412 ##sys#features 
o|merged explicitly consed rest parameter: tmp492494 
o|inlining procedure: k3514 
o|inlining procedure: k3514 
o|inlining procedure: k3543 
o|inlining procedure: k3573 
o|inlining procedure: k3573 
o|inlining procedure: k3543 
o|inlining procedure: k3630 
o|inlining procedure: k3630 
o|inlining procedure: k3654 
o|inlining procedure: k3654 
o|inlining procedure: k3672 
o|inlining procedure: k3672 
o|inlining procedure: k3690 
o|inlining procedure: k3690 
o|inlining procedure: k3723 
o|inlining procedure: k3723 
o|inlining procedure: k3741 
o|inlining procedure: k3741 
o|inlining procedure: k3759 
o|inlining procedure: k3759 
o|inlining procedure: k3790 
o|inlining procedure: k3790 
o|inlining procedure: k3805 
o|inlining procedure: k3805 
o|inlining procedure: k3850 
o|inlining procedure: k3850 
o|inlining procedure: k3868 
o|inlining procedure: k3890 
o|inlining procedure: k3890 
o|contracted procedure: k3914 
o|inlining procedure: k3911 
o|inlining procedure: k3911 
o|inlining procedure: k3868 
o|inlining procedure: k3955 
o|inlining procedure: k3955 
o|inlining procedure: k3988 
o|inlining procedure: k3988 
o|inlining procedure: k4037 
o|inlining procedure: k4037 
o|inlining procedure: k4049 
o|inlining procedure: k4049 
o|inlining procedure: k4061 
o|inlining procedure: k4061 
o|inlining procedure: k4073 
o|inlining procedure: k4073 
o|inlining procedure: k4085 
o|inlining procedure: k4085 
o|substituted constant variable: a4098 
o|substituted constant variable: a4100 
o|substituted constant variable: a4102 
o|substituted constant variable: a4104 
o|substituted constant variable: a4106 
o|substituted constant variable: a4108 
o|substituted constant variable: a4110 
o|substituted constant variable: a4112 
o|substituted constant variable: a4114 
o|substituted constant variable: a4116 
o|inlining procedure: k4117 
o|inlining procedure: k4117 
o|inlining procedure: k4145 
o|inlining procedure: k4145 
o|inlining procedure: k4182 
o|inlining procedure: k4182 
o|inlining procedure: k4220 
o|inlining procedure: k4220 
o|inlining procedure: k4279 
o|inlining procedure: k4279 
o|inlining procedure: k4255 
o|inlining procedure: k4334 
o|inlining procedure: k4334 
o|inlining procedure: k4255 
o|inlining procedure: k4370 
o|inlining procedure: k4370 
o|inlining procedure: k4416 
o|inlining procedure: k4416 
o|contracted procedure: "(csi.scm:643) improper-pairs?" 
o|contracted procedure: k3464 
o|inlining procedure: k3461 
o|inlining procedure: k3461 
o|contracted procedure: "(csi.scm:643) circular-list?" 
o|inlining procedure: k3426 
o|inlining procedure: k3446 
o|inlining procedure: k3446 
o|inlining procedure: k3426 
o|merged explicitly consed rest parameter: len-out683 
o|inlining procedure: k4507 
o|inlining procedure: k4507 
o|inlining procedure: k4513 
o|inlining procedure: k4513 
o|inlining procedure: k4539 
o|inlining procedure: k4539 
o|inlining procedure: k4565 
o|inlining procedure: k4565 
o|contracted procedure: k4598 
o|inlining procedure: k4618 
o|inlining procedure: k4618 
o|inlining procedure: k4659 
o|inlining procedure: k4659 
o|inlining procedure: k4683 
o|inlining procedure: k4683 
o|inlining procedure: k4717 
o|inlining procedure: k4717 
o|inlining procedure: k4768 
o|inlining procedure: k4786 
o|inlining procedure: k4786 
o|inlining procedure: k4802 
o|inlining procedure: k4802 
o|inlining procedure: k4768 
o|inlining procedure: k4888 
o|propagated global variable: out795799 ##sys#standard-output 
o|substituted constant variable: a4913 
o|substituted constant variable: a4914 
o|inlining procedure: k4888 
o|inlining procedure: k4962 
o|inlining procedure: k4962 
o|inlining procedure: k4977 
o|propagated global variable: out837841 ##sys#standard-output 
o|substituted constant variable: a4984 
o|substituted constant variable: a4985 
o|inlining procedure: k4977 
o|propagated global variable: out837841 ##sys#standard-output 
o|inlining procedure: k5036 
o|inlining procedure: k5036 
o|propagated global variable: out808812 ##sys#standard-output 
o|substituted constant variable: a5074 
o|substituted constant variable: a5075 
o|propagated global variable: out808812 ##sys#standard-output 
o|inlining procedure: k5090 
o|inlining procedure: k5090 
o|inlining procedure: k5104 
o|propagated global variable: out795799 ##sys#standard-output 
o|inlining procedure: k5104 
o|inlining procedure: k5110 
o|inlining procedure: k5110 
o|propagated global variable: tmp776778 ##sys#repl-recent-call-chain 
o|propagated global variable: tmp776778 ##sys#repl-recent-call-chain 
o|inlining procedure: k5128 
o|inlining procedure: k5128 
o|inlining procedure: k5162 
o|inlining procedure: k5162 
o|inlining procedure: k5219 
o|inlining procedure: k5250 
o|inlining procedure: k5250 
o|inlining procedure: k5290 
o|inlining procedure: k5290 
o|inlining procedure: k5369 
o|inlining procedure: k5369 
o|inlining procedure: k5219 
o|inlining procedure: k5412 
o|inlining procedure: k5412 
o|propagated global variable: tmp889891 ##sys#repl-recent-call-chain 
o|propagated global variable: tmp889891 ##sys#repl-recent-call-chain 
o|inlining procedure: k5436 
o|inlining procedure: k5448 
o|inlining procedure: k5448 
o|inlining procedure: k5436 
o|inlining procedure: k5491 
o|inlining procedure: k5491 
o|inlining procedure: k5506 
o|inlining procedure: k5526 
o|inlining procedure: k5556 
o|contracted procedure: "(csi.scm:956) g10671076" 
o|inlining procedure: k5556 
o|inlining procedure: k5526 
o|contracted procedure: "(csi.scm:955) findall" 
o|substituted constant variable: constant1038 
o|inlining procedure: k5637 
o|inlining procedure: k5637 
o|inlining procedure: k5506 
o|inlining procedure: k5607 
o|substituted constant variable: constant1045 
o|inlining procedure: k5607 
o|contracted procedure: "(csi.scm:1133) run" 
o|inlining procedure: k5713 
o|inlining procedure: k5713 
o|inlining procedure: k5708 
o|inlining procedure: k5708 
o|merged explicitly consed rest parameter: tmp12151217 
o|inlining procedure: k5797 
o|inlining procedure: k5797 
o|inlining procedure: k5910 
o|inlining procedure: k5910 
o|inlining procedure: k5953 
o|inlining procedure: k5953 
o|substituted constant variable: a5996 
o|inlining procedure: k5993 
o|consed rest parameter at call site: "(csi.scm:1098) evalstring1195" 2 
o|inlining procedure: k5993 
o|substituted constant variable: a6013 
o|consed rest parameter at call site: "(csi.scm:1101) evalstring1195" 2 
o|substituted constant variable: a6036 
o|inlining procedure: k6033 
o|consed rest parameter at call site: "(csi.scm:1104) evalstring1195" 2 
o|inlining procedure: k6033 
o|inlining procedure: k6088 
o|inlining procedure: k6088 
o|inlining procedure: k6106 
o|inlining procedure: k6138 
o|inlining procedure: k6138 
o|substituted constant variable: a6160 
o|propagated global variable: g14101411 pretty-print 
o|inlining procedure: k6106 
o|substituted constant variable: a6174 
o|substituted constant variable: a6176 
o|substituted constant variable: a6178 
o|substituted constant variable: a6180 
o|substituted constant variable: constant1119 
o|substituted constant variable: constant1110 
o|contracted procedure: "(csi.scm:1079) loadinit1194" 
o|inlining procedure: k5749 
o|contracted procedure: k5755 
o|inlining procedure: k5761 
o|inlining procedure: k5761 
o|inlining procedure: k5749 
o|inlining procedure: k6192 
o|inlining procedure: k6192 
o|inlining procedure: k6219 
o|inlining procedure: k6219 
o|inlining procedure: k6231 
o|inlining procedure: k6231 
o|contracted procedure: k6243 
o|inlining procedure: k6240 
o|inlining procedure: k6258 
o|inlining procedure: k6258 
o|inlining procedure: k6240 
o|inlining procedure: k6327 
o|inlining procedure: k6327 
o|inlining procedure: k6361 
o|inlining procedure: k6361 
o|inlining procedure: k6395 
o|inlining procedure: k6395 
o|inlining procedure: k6418 
o|inlining procedure: k6418 
o|inlining procedure: k6441 
o|inlining procedure: k6441 
o|inlining procedure: k6485 
o|inlining procedure: k6485 
o|contracted procedure: "(csi.scm:1028) print-usage" 
o|inlining procedure: k6530 
o|inlining procedure: k6530 
o|inlining procedure: k6565 
o|inlining procedure: k6565 
o|inlining procedure: k6568 
o|inlining procedure: k6568 
o|inlining procedure: k6574 
o|inlining procedure: k6574 
o|inlining procedure: k6595 
o|inlining procedure: k6595 
o|substituted constant variable: a6615 
o|inlining procedure: k6635 
o|inlining procedure: k6635 
o|substituted constant variable: a6638 
o|inlining procedure: k6669 
o|inlining procedure: k6669 
o|contracted procedure: "(csi.scm:977) parse-option-string" 
o|inlining procedure: k3035 
o|contracted procedure: "(csi.scm:446) g340349" 
o|inlining procedure: k3005 
o|inlining procedure: k3005 
o|inlining procedure: k3035 
o|inlining procedure: k3103 
o|inlining procedure: k3103 
o|inlining procedure: k6719 
o|inlining procedure: k6719 
o|inlining procedure: k6803 
o|inlining procedure: k6803 
o|contracted procedure: k6831 
o|inlining procedure: k6828 
o|contracted procedure: k6843 
o|inlining procedure: k6852 
o|inlining procedure: k6852 
o|inlining procedure: k6828 
o|inlining procedure: k6894 
o|inlining procedure: k6894 
o|substituted constant variable: a6904 
o|inlining procedure: k6908 
o|inlining procedure: k6908 
o|replaced variables: 923 
o|removed binding forms: 363 
o|removed side-effect free assignment to unused variable: constant0 
o|removed side-effect free assignment to unused variable: constant3 
o|substituted constant variable: int6267 
o|substituted constant variable: r21756929 
o|substituted constant variable: r20966930 
o|substituted constant variable: r21216932 
o|contracted procedure: "(csi.scm:366) history-show" 
o|propagated global variable: out123127 ##sys#standard-output 
o|contracted procedure: "(csi.scm:372) select-frame" 
o|contracted procedure: "(csi.scm:375) copy-from-frame" 
o|converted assignments to bindings: (fail904) 
o|converted assignments to bindings: (compare899) 
o|substituted constant variable: r54137130 
o|converted assignments to bindings: (shorten390) 
o|substituted constant variable: r35746996 
o|substituted constant variable: r35746996 
o|substituted constant variable: r35746998 
o|substituted constant variable: r35746998 
o|inlining procedure: k3702 
o|inlining procedure: k3630 
o|inlining procedure: k3630 
o|removed call to pure procedure with unused result: "(csi.scm:657) size" 
o|substituted constant variable: r40387041 
o|substituted constant variable: r40387041 
o|inlining procedure: k4037 
o|inlining procedure: k4037 
o|substituted constant variable: r40507045 
o|inlining procedure: k4037 
o|inlining procedure: k4037 
o|substituted constant variable: r40627047 
o|inlining procedure: k4037 
o|inlining procedure: k4037 
o|substituted constant variable: r40747049 
o|inlining procedure: k4037 
o|inlining procedure: k4037 
o|substituted constant variable: r40867051 
o|inlining procedure: k4037 
o|inlining procedure: k4037 
o|substituted constant variable: r34627072 
o|substituted constant variable: r34277076 
o|converted assignments to bindings: (descseq500) 
o|converted assignments to bindings: (bestlen701) 
o|converted assignments to bindings: (justify724) 
o|propagated global variable: out795799 ##sys#standard-output 
o|propagated global variable: out837841 ##sys#standard-output 
o|propagated global variable: out808812 ##sys#standard-output 
o|substituted constant variable: r50917107 
o|substituted constant variable: r50917107 
o|substituted constant variable: r50917109 
o|substituted constant variable: r50917109 
o|substituted constant variable: r51057111 
o|substituted constant variable: r51057111 
o|substituted constant variable: r51057113 
o|substituted constant variable: r51057113 
o|substituted constant variable: r51117116 
o|converted assignments to bindings: (prin1773) 
o|substituted constant variable: r54377134 
o|removed side-effect free assignment to unused variable: constant1038 
o|removed side-effect free assignment to unused variable: constant1045 
o|substituted constant variable: r54927135 
o|substituted constant variable: clist1096 
o|substituted constant variable: r56087146 
o|removed side-effect free assignment to unused variable: constant1110 
o|removed side-effect free assignment to unused variable: constant1119 
o|substituted constant variable: r57097150 
o|substituted constant variable: r60897163 
o|substituted constant variable: r60897163 
o|substituted constant variable: r61077169 
o|substituted constant variable: r61077169 
o|substituted constant variable: r57507174 
o|substituted constant variable: r65667221 
o|substituted constant variable: r65667221 
o|substituted constant variable: r66707232 
o|substituted constant variable: r68047242 
o|substituted constant variable: r68957249 
o|substituted constant variable: r68957249 
o|converted assignments to bindings: (addext70) 
o|simplifications: ((let . 8)) 
o|replaced variables: 20 
o|removed binding forms: 933 
o|inlining procedure: k2001 
o|inlining procedure: k5271 
o|contracted procedure: k3974 
o|inlining procedure: k4285 
o|inlining procedure: k5943 
o|inlining procedure: k5943 
o|inlining procedure: k5943 
o|inlining procedure: k5943 
o|inlining procedure: k5943 
o|inlining procedure: k5943 
o|inlining procedure: k5943 
o|inlining procedure: k6150 
o|inlining procedure: k6464 
o|inlining procedure: k6626 
o|inlining procedure: k6626 
o|inlining procedure: k6626 
o|replaced variables: 14 
o|removed binding forms: 91 
o|substituted constant variable: r20027442 
o|substituted constant variable: r20027442 
o|substituted constant variable: r20027442 
o|substituted constant variable: r40387317 
o|substituted constant variable: r40387319 
o|substituted constant variable: r40387321 
o|substituted constant variable: r40387323 
o|substituted constant variable: r40387325 
o|substituted constant variable: r40387327 
o|substituted constant variable: r40387329 
o|substituted constant variable: r40387331 
o|substituted constant variable: r40387333 
o|inlining procedure: k6091 
o|replaced variables: 2 
o|removed binding forms: 28 
o|removed conditional forms: 1 
o|substituted constant variable: r60927662 
o|removed binding forms: 12 
o|removed conditional forms: 1 
o|simplifications: ((let . 1)) 
o|removed binding forms: 1 
o|simplifications: ((if . 40) (##core#call . 554)) 
o|  call simplifications:
o|    make-vector
o|    ##sys#pair?	2
o|    ##sys#eq?
o|    ##sys#cdr	4
o|    ##sys#car	2
o|    ##sys#cons	11
o|    set-car!
o|    call-with-values
o|    void
o|    member	9
o|    string->list
o|    string
o|    equal?	3
o|    fxmod
o|    write-char	7
o|    ##sys#immediate?	2
o|    ##sys#permanent?
o|    char?
o|    fixnum?	2
o|    flonum?
o|    vector?
o|    list?
o|    procedure?
o|    ##sys#pointer?	2
o|    ##sys#generic-structure?	2
o|    cdr	15
o|    caar
o|    cdar
o|    fx=	3
o|    atom?
o|    memq	3
o|    cddr	3
o|    integer->char	2
o|    char->integer
o|    ##sys#setslot	9
o|    =
o|    -
o|    <=
o|    add1	2
o|    +
o|    *
o|    /
o|    eof-object?	4
o|    caddr
o|    symbol?	3
o|    string?	5
o|    ##sys#structure?	4
o|    ##sys#check-list	15
o|    string-length	5
o|    fxmin
o|    string=?	6
o|    number?	2
o|    not	4
o|    fx<	4
o|    length	4
o|    list-ref	2
o|    >=	2
o|    eq?	43
o|    apply	5
o|    ##sys#call-with-values	5
o|    ##sys#apply	2
o|    cadr	13
o|    car	19
o|    ##sys#check-symbol	2
o|    ##sys#check-string
o|    assq	4
o|    cons	23
o|    list	7
o|    set-cdr!	2
o|    ##sys#fudge	6
o|    inexact->exact
o|    fx<=
o|    vector-ref	8
o|    null?	21
o|    ##sys#void	20
o|    fx*
o|    vector-set!
o|    fx>=	15
o|    fx+	20
o|    pair?	32
o|    ##sys#slot	87
o|    ##sys#foreign-block-argument
o|    ##sys#foreign-fixnum-argument
o|    ##sys#size	11
o|    sub1
o|    string-ref	4
o|    fx>	6
o|    char=?	6
o|    char-whitespace?
o|    fx-	11
o|    ##sys#list	4
o|contracted procedure: k1899 
o|contracted procedure: k1965 
o|contracted procedure: k1968 
o|contracted procedure: k1979 
o|contracted procedure: k2001 
o|contracted procedure: k2038 
o|contracted procedure: k2016 
o|contracted procedure: k2019 
o|contracted procedure: k2031 
o|contracted procedure: k2212 
o|contracted procedure: k2123 
o|contracted procedure: k2053 
o|contracted procedure: k2057 
o|contracted procedure: k2177 
o|contracted procedure: k2193 
o|contracted procedure: k2202 
o|contracted procedure: k2086 
o|contracted procedure: k2098 
o|contracted procedure: k2111 
o|contracted procedure: k2208 
o|contracted procedure: k2217 
o|contracted procedure: k2251 
o|contracted procedure: k2224 
o|contracted procedure: k2227 
o|contracted procedure: k2233 
o|contracted procedure: k2237 
o|contracted procedure: k2240 
o|contracted procedure: k2248 
o|contracted procedure: k2323 
o|contracted procedure: k2338 
o|contracted procedure: k2329 
o|contracted procedure: k2350 
o|contracted procedure: k2417 
o|contracted procedure: k2376 
o|contracted procedure: k2379 
o|contracted procedure: k2382 
o|contracted procedure: k2385 
o|contracted procedure: k2400 
o|contracted procedure: k2411 
o|contracted procedure: k2407 
o|contracted procedure: k2429 
o|contracted procedure: k2441 
o|contracted procedure: k2444 
o|contracted procedure: k2452 
o|contracted procedure: k2467 
o|contracted procedure: k2490 
o|contracted procedure: k2508 
o|contracted procedure: k2523 
o|contracted procedure: k2538 
o|contracted procedure: k2559 
o|contracted procedure: k2568 
o|contracted procedure: k2577 
o|contracted procedure: k2595 
o|contracted procedure: k2605 
o|contracted procedure: k2609 
o|contracted procedure: k2619 
o|contracted procedure: k2651 
o|contracted procedure: k2661 
o|contracted procedure: k2665 
o|contracted procedure: k2675 
o|contracted procedure: k2724 
o|contracted procedure: k2737 
o|contracted procedure: k2743 
o|contracted procedure: k2759 
o|contracted procedure: k2771 
o|contracted procedure: k2781 
o|contracted procedure: k2267 
o|propagated global variable: r2268 ##sys#undefined-value 
o|contracted procedure: k2793 
o|contracted procedure: k2282 
o|contracted procedure: k2307 
o|contracted procedure: k2317 
o|contracted procedure: k2805 
o|contracted procedure: k2817 
o|contracted procedure: k5179 
o|contracted procedure: k5131 
o|contracted procedure: k5152 
o|contracted procedure: k5156 
o|contracted procedure: k5148 
o|contracted procedure: k5141 
o|contracted procedure: k5159 
o|contracted procedure: k5165 
o|contracted procedure: k5175 
o|contracted procedure: k2833 
o|contracted procedure: k5185 
o|contracted procedure: k5188 
o|contracted procedure: k5197 
o|contracted procedure: k5212 
o|contracted procedure: k5216 
o|contracted procedure: k5208 
o|contracted procedure: k5241 
o|propagated global variable: r5242 ##sys#undefined-value 
o|contracted procedure: k5253 
o|contracted procedure: k5259 
o|contracted procedure: k5262 
o|contracted procedure: k5265 
o|contracted procedure: k5268 
o|contracted procedure: k5279 
o|contracted procedure: k5293 
o|contracted procedure: k5303 
o|contracted procedure: k5327 
o|contracted procedure: k5335 
o|contracted procedure: k5331 
o|contracted procedure: k5341 
o|contracted procedure: k5344 
o|contracted procedure: k5347 
o|contracted procedure: k5350 
o|contracted procedure: k5353 
o|contracted procedure: k5397 
o|contracted procedure: k5372 
o|contracted procedure: k5382 
o|contracted procedure: k5386 
o|contracted procedure: k5390 
o|contracted procedure: k5394 
o|contracted procedure: k5406 
o|contracted procedure: k5415 
o|contracted procedure: k2846 
o|contracted procedure: k2859 
o|contracted procedure: k2865 
o|contracted procedure: k2887 
o|contracted procedure: k2902 
o|contracted procedure: k2912 
o|contracted procedure: k2916 
o|contracted procedure: k2873 
o|propagated global variable: g300302 command-table 
o|contracted procedure: k2981 
o|contracted procedure: k2988 
o|contracted procedure: k3174 
o|contracted procedure: k3188 
o|contracted procedure: k3191 
o|contracted procedure: k3195 
o|contracted procedure: k3204 
o|contracted procedure: k3218 
o|contracted procedure: k3222 
o|contracted procedure: k3226 
o|contracted procedure: k3229 
o|contracted procedure: k3247 
o|contracted procedure: k3253 
o|contracted procedure: k3345 
o|contracted procedure: k3264 
o|contracted procedure: k3296 
o|contracted procedure: k3300 
o|contracted procedure: k3330 
o|contracted procedure: k3304 
o|contracted procedure: k3308 
o|contracted procedure: k3312 
o|contracted procedure: k3327 
o|contracted procedure: k3323 
o|contracted procedure: k3316 
o|contracted procedure: k3334 
o|contracted procedure: k3338 
o|contracted procedure: k3354 
o|contracted procedure: k3364 
o|contracted procedure: k3368 
o|contracted procedure: k3372 
o|contracted procedure: k3384 
o|contracted procedure: k3387 
o|contracted procedure: k3390 
o|contracted procedure: k3398 
o|contracted procedure: k3406 
o|contracted procedure: k3412 
o|contracted procedure: k4484 
o|contracted procedure: k3493 
o|contracted procedure: k3499 
o|contracted procedure: k3511 
o|contracted procedure: k3520 
o|contracted procedure: k3527 
o|contracted procedure: k3613 
o|contracted procedure: k3537 
o|contracted procedure: k3546 
o|contracted procedure: k3559 
o|contracted procedure: k3562 
o|contracted procedure: k3569 
o|contracted procedure: k3576 
o|contracted procedure: k3591 
o|contracted procedure: k3598 
o|contracted procedure: k3602 
o|contracted procedure: k3617 
o|contracted procedure: k3636 
o|contracted procedure: k3639 
o|contracted procedure: k3648 
o|contracted procedure: k3657 
o|contracted procedure: k3666 
o|contracted procedure: k3675 
o|contracted procedure: k4471 
o|contracted procedure: k3684 
o|propagated global variable: r4472 ##sys#undefined-value 
o|contracted procedure: k3693 
o|contracted procedure: k3699 
o|contracted procedure: k3708 
o|contracted procedure: k4467 
o|contracted procedure: k3717 
o|contracted procedure: k3726 
o|contracted procedure: k3735 
o|contracted procedure: k3744 
o|contracted procedure: k3753 
o|contracted procedure: k3775 
o|contracted procedure: k3787 
o|contracted procedure: k3793 
o|contracted procedure: k3808 
o|contracted procedure: k3824 
o|contracted procedure: k3834 
o|contracted procedure: k3838 
o|contracted procedure: k3842 
o|contracted procedure: k3846 
o|contracted procedure: k3884 
o|contracted procedure: k3893 
o|contracted procedure: k3896 
o|contracted procedure: k3940 
o|contracted procedure: k3905 
o|contracted procedure: k3934 
o|contracted procedure: k3926 
o|contracted procedure: k3949 
o|contracted procedure: k3958 
o|contracted procedure: k3971 
o|contracted procedure: k4013 
o|contracted procedure: k3998 
o|contracted procedure: k4002 
o|contracted procedure: k4006 
o|contracted procedure: k4030 
o|contracted procedure: k4034 
o|contracted procedure: k4040 
o|contracted procedure: k4046 
o|contracted procedure: k4052 
o|contracted procedure: k4058 
o|contracted procedure: k4064 
o|contracted procedure: k4070 
o|contracted procedure: k4076 
o|contracted procedure: k4082 
o|contracted procedure: k4088 
o|contracted procedure: k4094 
o|contracted procedure: k4120 
o|contracted procedure: k4136 
o|contracted procedure: k4158 
o|contracted procedure: k4161 
o|contracted procedure: k4170 
o|contracted procedure: k4173 
o|contracted procedure: k4185 
o|contracted procedure: k4194 
o|contracted procedure: k4198 
o|contracted procedure: k4201 
o|contracted procedure: k4204 
o|contracted procedure: k4214 
o|contracted procedure: k4223 
o|contracted procedure: k4233 
o|contracted procedure: k4237 
o|contracted procedure: k4241 
o|contracted procedure: k4252 
o|contracted procedure: k4245 
o|contracted procedure: k4249 
o|contracted procedure: k4258 
o|contracted procedure: k4273 
o|contracted procedure: k4282 
o|contracted procedure: k4292 
o|contracted procedure: k4319 
o|contracted procedure: k4295 
o|contracted procedure: k4311 
o|contracted procedure: k4315 
o|contracted procedure: k42927484 
o|contracted procedure: k4322 
o|contracted procedure: k4325 
o|contracted procedure: k4337 
o|contracted procedure: k4347 
o|contracted procedure: k4351 
o|contracted procedure: k4355 
o|contracted procedure: k4361 
o|contracted procedure: k4364 
o|contracted procedure: k4381 
o|contracted procedure: k4397 
o|contracted procedure: k4400 
o|contracted procedure: k4403 
o|contracted procedure: k4410 
o|contracted procedure: k4419 
o|contracted procedure: k4422 
o|contracted procedure: k4425 
o|contracted procedure: k4433 
o|contracted procedure: k4441 
o|contracted procedure: k4457 
o|contracted procedure: k3483 
o|contracted procedure: k3479 
o|contracted procedure: k3467 
o|contracted procedure: k3429 
o|contracted procedure: k3436 
o|contracted procedure: k3440 
o|contracted procedure: k3443 
o|contracted procedure: k4474 
o|contracted procedure: k4493 
o|contracted procedure: k4516 
o|contracted procedure: k4536 
o|contracted procedure: k4542 
o|contracted procedure: k4553 
o|contracted procedure: k4605 
o|contracted procedure: k4559 
o|contracted procedure: k4571 
o|contracted procedure: k4582 
o|contracted procedure: k4588 
o|contracted procedure: k4595 
o|contracted procedure: k4621 
o|contracted procedure: k4627 
o|contracted procedure: k4634 
o|contracted procedure: k4640 
o|contracted procedure: k4656 
o|contracted procedure: k4662 
o|contracted procedure: k4674 
o|contracted procedure: k4686 
o|contracted procedure: k4711 
o|contracted procedure: k4720 
o|contracted procedure: k4723 
o|contracted procedure: k4736 
o|contracted procedure: k4740 
o|contracted procedure: k4756 
o|contracted procedure: k4743 
o|contracted procedure: k4750 
o|contracted procedure: k4771 
o|contracted procedure: k4774 
o|contracted procedure: k4780 
o|contracted procedure: k4783 
o|contracted procedure: k4789 
o|contracted procedure: k4796 
o|contracted procedure: k4805 
o|contracted procedure: k4815 
o|contracted procedure: k4828 
o|contracted procedure: k4832 
o|contracted procedure: k4865 
o|contracted procedure: k4868 
o|contracted procedure: k4872 
o|contracted procedure: k4882 
o|contracted procedure: k4891 
o|contracted procedure: k4894 
o|contracted procedure: k4897 
o|contracted procedure: k4900 
o|contracted procedure: k4903 
o|contracted procedure: k4906 
o|contracted procedure: k4909 
o|contracted procedure: k4954 
o|contracted procedure: k4957 
o|contracted procedure: k4965 
o|contracted procedure: k4980 
o|contracted procedure: k5005 
o|contracted procedure: k5011 
o|contracted procedure: k5015 
o|contracted procedure: k5018 
o|contracted procedure: k5021 
o|contracted procedure: k5024 
o|contracted procedure: k5027 
o|contracted procedure: k5064 
o|contracted procedure: k5039 
o|contracted procedure: k5049 
o|contracted procedure: k5053 
o|contracted procedure: k5057 
o|contracted procedure: k5061 
o|contracted procedure: k5086 
o|contracted procedure: k5100 
o|contracted procedure: k5113 
o|contracted procedure: k5120 
o|contracted procedure: k5424 
o|contracted procedure: k5439 
o|contracted procedure: k5451 
o|contracted procedure: k5458 
o|contracted procedure: k5473 
o|contracted procedure: k5477 
o|contracted procedure: k5464 
o|contracted procedure: k5494 
o|contracted procedure: k5497 
o|contracted procedure: k5503 
o|contracted procedure: k5515 
o|contracted procedure: k5536 
o|contracted procedure: k5559 
o|contracted procedure: k5581 
o|contracted procedure: k5577 
o|contracted procedure: k5562 
o|contracted procedure: k5565 
o|contracted procedure: k5573 
o|contracted procedure: k5634 
o|contracted procedure: k5652 
o|contracted procedure: k5643 
o|contracted procedure: k5622 
o|contracted procedure: k5604 
o|contracted procedure: k5610 
o|contracted procedure: k5617 
o|contracted procedure: k5687 
o|contracted procedure: k5705 
o|contracted procedure: k5737 
o|contracted procedure: k5716 
o|contracted procedure: k5726 
o|contracted procedure: k5823 
o|contracted procedure: k5781 
o|contracted procedure: k5800 
o|contracted procedure: k5858 
o|contracted procedure: k5867 
o|contracted procedure: k5876 
o|contracted procedure: k5913 
o|contracted procedure: k5937 
o|contracted procedure: k5940 
o|contracted procedure: k5950 
o|contracted procedure: k59507530 
o|contracted procedure: k5956 
o|contracted procedure: k5960 
o|contracted procedure: k59507534 
o|contracted procedure: k5966 
o|contracted procedure: k5969 
o|contracted procedure: k59507538 
o|contracted procedure: k5982 
o|contracted procedure: k5978 
o|contracted procedure: k5990 
o|contracted procedure: k5998 
o|contracted procedure: k59507542 
o|contracted procedure: k6007 
o|contracted procedure: k6015 
o|contracted procedure: k59507546 
o|contracted procedure: k6024 
o|contracted procedure: k6038 
o|contracted procedure: k59507550 
o|contracted procedure: k6047 
o|contracted procedure: k6056 
o|contracted procedure: k6065 
o|contracted procedure: k6097 
o|contracted procedure: k6091 
o|contracted procedure: k6088 
o|contracted procedure: k59507554 
o|contracted procedure: k6109 
o|contracted procedure: k6117 
o|contracted procedure: k6141 
o|contracted procedure: k6144 
o|contracted procedure: k6157 
o|contracted procedure: k61577558 
o|contracted procedure: k6186 
o|contracted procedure: k5775 
o|contracted procedure: k6291 
o|contracted procedure: k6287 
o|contracted procedure: k6283 
o|contracted procedure: k6252 
o|contracted procedure: k6261 
o|contracted procedure: k6270 
o|contracted procedure: k6299 
o|contracted procedure: k6305 
o|contracted procedure: k6312 
o|contracted procedure: k6318 
o|contracted procedure: k6330 
o|contracted procedure: k6333 
o|contracted procedure: k6336 
o|contracted procedure: k6344 
o|contracted procedure: k6352 
o|contracted procedure: k6364 
o|contracted procedure: k6367 
o|contracted procedure: k6370 
o|contracted procedure: k6378 
o|contracted procedure: k6386 
o|contracted procedure: k6398 
o|contracted procedure: k6408 
o|contracted procedure: k6412 
o|contracted procedure: k6421 
o|contracted procedure: k6431 
o|contracted procedure: k6435 
o|contracted procedure: k6444 
o|contracted procedure: k6454 
o|contracted procedure: k6458 
o|contracted procedure: k6492 
o|contracted procedure: k6505 
o|contracted procedure: k6509 
o|contracted procedure: k1940 
o|contracted procedure: k1936 
o|contracted procedure: k1932 
o|contracted procedure: k6533 
o|contracted procedure: k6536 
o|contracted procedure: k6539 
o|contracted procedure: k6547 
o|contracted procedure: k6555 
o|contracted procedure: k6592 
o|contracted procedure: k6610 
o|contracted procedure: k6620 
o|contracted procedure: k6659 
o|contracted procedure: k6655 
o|contracted procedure: k6623 
o|contracted procedure: k6651 
o|contracted procedure: k6647 
o|contracted procedure: k6632 
o|contracted procedure: k6640 
o|contracted procedure: k6666 
o|contracted procedure: k6687 
o|contracted procedure: k3000 
o|contracted procedure: k3026 
o|contracted procedure: k3038 
o|contracted procedure: k3041 
o|contracted procedure: k3044 
o|contracted procedure: k3052 
o|contracted procedure: k3060 
o|contracted procedure: k3008 
o|contracted procedure: k3106 
o|contracted procedure: k3120 
o|contracted procedure: k6716 
o|contracted procedure: k6725 
o|contracted procedure: k6791 
o|contracted procedure: k6728 
o|contracted procedure: k6787 
o|contracted procedure: k6783 
o|contracted procedure: k6779 
o|contracted procedure: k6743 
o|contracted procedure: k6771 
o|contracted procedure: k6767 
o|contracted procedure: k6759 
o|contracted procedure: k6751 
o|contracted procedure: k6747 
o|contracted procedure: k6739 
o|contracted procedure: k6797 
o|contracted procedure: k6800 
o|contracted procedure: k6806 
o|contracted procedure: k6813 
o|contracted procedure: k6874 
o|contracted procedure: k6877 
o|simplifications: ((if . 3) (let . 117)) 
o|removed binding forms: 506 
o|inlining procedure: k5296 
o|inlining procedure: k4945 
o|replaced variables: 214 
o|inlining procedure: k2366 
o|simplifications: ((if . 1)) 
o|removed binding forms: 89 
o|replaced variables: 1 
o|removed binding forms: 1 
o|direct leaf routine/allocation: g167168 6 
o|direct leaf routine/allocation: lp474 0 
o|direct leaf routine/allocation: lp460 0 
o|direct leaf routine/allocation: loop1097 0 
o|contracted procedure: "(csi.scm:280) k2388" 
o|contracted procedure: k3871 
o|converted assignments to bindings: (lp474) 
o|converted assignments to bindings: (lp460) 
o|contracted procedure: k5529 
o|converted assignments to bindings: (loop1097) 
o|simplifications: ((let . 3)) 
o|removed binding forms: 3 
o|replaced variables: 2 
o|removed binding forms: 1 
o|customizable procedures: (k1912 k6825 g324325 k6722 doloop362363 map-loop334368 canonicalize-args lookup-script-file k5672 k5678 k5684 map-loop11661186 k5840 k5846 print-banner for-each-loop12391249 for-each-loop12561266 for-each-loop12731283 map-loop12901307 collect-options1193 map-loop13161333 member* k5901 doloop14131414 evalstring1195 doloop13561357 doloop12251226 g12051206 loop1197 k5509 map-loop10611086 loop1049 find1026 loop1023 k4875 k5093 g820828 for-each-loop819850 prin1773 doloop833834 doloop785786 justify724 doloop733734 doloop741742 doloop749750 doloop723731 def-len688709 def-out689707 body686694 k4568 bestlen701 k3874 g644645 map-loop649666 g633634 g604611 for-each-loop603620 loop614 g582589 for-each-loop581592 doloop576577 hexdump loop-print551 doloop538539 loop2516 loop1506 k3148 map-loop396413 g423430 for-each-loop422444 shorten390 k3198 k2438 for-each-loop293305 k5191 g918926 for-each-loop917941 compare899 doloop931932 doloop903908 fail904 k5134 show-frameinfo doloop120121 history-add g247254 for-each-loop246266 for-each-loop227237 report dump describe k2230 loop78 loop97 addext70 history-ref) 
o|calls to known targets: 263 
o|identified direct recursive calls: f_5248 1 
o|identified direct recursive calls: f_3424 1 
o|identified direct recursive calls: f_4277 1 
o|identified direct recursive calls: f_3459 1 
o|identified direct recursive calls: f_5446 1 
o|identified direct recursive calls: f_5632 1 
o|identified direct recursive calls: f_5554 1 
o|unused rest argument: _1223 f_5826 
o|unused rest argument: _1360 f_5929 
o|identified direct recursive calls: f_5908 2 
o|fast box initializations: 47 
o|fast global references: 77 
o|fast global assignments: 27 
o|dropping unused closure argument: f_5779 
o|dropping unused closure argument: f_4648 
o|dropping unused closure argument: f_5428 
o|dropping unused closure argument: f_5483 
o|dropping unused closure argument: f_2064 
o|dropping unused closure argument: f_4651 
o|dropping unused closure argument: f_5632 
o|dropping unused closure argument: f_3459 
o|dropping unused closure argument: f_2321 
o|dropping unused closure argument: f_3424 
o|dropping unused closure argument: f_4500 
o|dropping unused closure argument: f_4851 
o|dropping unused closure argument: f_4854 
o|dropping unused closure argument: f_3164 
o|dropping unused closure argument: f_1944 
*/
/* end of file */
