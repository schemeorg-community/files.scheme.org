/* Generated from lolevel.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:48
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: lolevel.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file lolevel.c
   unit: lolevel
*/

#include "chicken.h"

#ifndef C_NONUNIX
# include <sys/mman.h>
#endif

#define C_memmove_o(to, from, n, toff, foff) C_memmove((char *)(to) + (toff), (char *)(from) + (foff), (n))

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_srfi_2d69_toplevel)
C_externimport void C_ccall C_srfi_2d69_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[141];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,99,104,101,99,107,45,98,108,111,99,107,32,120,54,52,32,108,111,99,54,53,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,99,104,101,99,107,45,103,101,110,101,114,105,99,45,115,116,114,117,99,116,117,114,101,32,120,56,55,32,108,111,99,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,99,104,101,99,107,45,112,111,105,110,116,101,114,32,120,49,48,54,32,46,32,108,111,99,49,48,55,41,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,10),40,110,111,115,105,122,101,114,114,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,16),40,115,105,122,101,114,114,32,97,114,103,115,50,49,48,41};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,29),40,99,104,101,99,107,110,49,32,110,50,49,49,32,110,109,97,120,50,49,50,32,111,102,102,50,49,51,41,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,47),40,99,104,101,99,107,110,50,32,110,50,49,52,32,110,109,97,120,50,49,53,32,110,109,97,120,50,50,49,54,32,111,102,102,49,50,49,55,32,111,102,102,50,50,49,56,41,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,20),40,109,111,118,101,32,102,114,111,109,50,50,49,32,116,111,50,50,50,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,40),40,109,111,118,101,45,109,101,109,111,114,121,33,32,102,114,111,109,49,57,49,32,116,111,49,57,50,32,46,32,116,109,112,49,57,48,49,57,51,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,51,48,55,32,105,51,48,57,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,50,57,54,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,99,111,112,121,32,120,50,57,52,41,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,20),40,97,108,108,111,99,97,116,101,32,105,110,116,51,49,53,51,49,56,41,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,22),40,102,114,101,101,32,99,45,112,111,105,110,116,101,114,51,50,49,51,50,53,41,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,15),40,112,111,105,110,116,101,114,63,32,120,51,50,56,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,20),40,112,111,105,110,116,101,114,45,108,105,107,101,63,32,120,51,51,51,41,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,26),40,97,100,100,114,101,115,115,45,62,112,111,105,110,116,101,114,32,97,100,100,114,51,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,25),40,112,111,105,110,116,101,114,45,62,97,100,100,114,101,115,115,32,112,116,114,51,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,62,112,111,105,110,116,101,114,32,120,51,52,53,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,24),40,112,111,105,110,116,101,114,45,62,111,98,106,101,99,116,32,112,116,114,51,53,53,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,23),40,112,111,105,110,116,101,114,61,63,32,112,49,51,53,56,32,112,50,51,53,57,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,30),40,112,111,105,110,116,101,114,43,32,112,116,114,51,54,51,51,54,56,32,111,102,102,51,54,52,51,54,57,41,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,20),40,97,108,105,103,110,45,116,111,45,119,111,114,100,32,120,51,55,57,41,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,27),40,116,97,103,45,112,111,105,110,116,101,114,32,112,116,114,51,56,57,32,116,97,103,51,57,48,41,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,34),40,116,97,103,103,101,100,45,112,111,105,110,116,101,114,63,32,120,52,48,52,32,46,32,116,109,112,52,48,51,52,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,18),40,112,111,105,110,116,101,114,45,116,97,103,32,120,52,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,108,111,99,97,116,105,118,101,32,111,98,106,52,50,53,32,46,32,105,110,100,101,120,52,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,38),40,109,97,107,101,45,119,101,97,107,45,108,111,99,97,116,105,118,101,32,111,98,106,52,51,50,32,46,32,105,110,100,101,120,52,51,51,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,25),40,108,111,99,97,116,105,118,101,45,115,101,116,33,32,120,52,51,57,32,121,52,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,23),40,108,111,99,97,116,105,118,101,45,62,111,98,106,101,99,116,32,120,52,52,51,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,16),40,108,111,99,97,116,105,118,101,63,32,120,52,52,53,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,27),40,112,111,105,110,116,101,114,45,117,56,45,115,101,116,33,32,112,52,52,56,32,110,52,52,57,41,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,27),40,112,111,105,110,116,101,114,45,115,56,45,115,101,116,33,32,112,52,53,49,32,110,52,53,50,41,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,117,49,54,45,115,101,116,33,32,112,52,53,52,32,110,52,53,53,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,115,49,54,45,115,101,116,33,32,112,52,53,55,32,110,52,53,56,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,117,51,50,45,115,101,116,33,32,112,52,54,48,32,110,52,54,49,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,115,51,50,45,115,101,116,33,32,112,52,54,51,32,110,52,54,52,41,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,102,51,50,45,115,101,116,33,32,112,52,54,54,32,110,52,54,55,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,102,54,52,45,115,101,116,33,32,112,52,54,57,32,110,52,55,48,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,12),40,97,50,49,55,52,32,120,52,57,49,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,17),40,97,50,49,57,48,32,120,52,57,51,32,105,52,57,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,34),40,101,120,116,101,110,100,45,112,114,111,99,101,100,117,114,101,32,112,114,111,99,52,56,57,32,100,97,116,97,52,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,12),40,97,50,50,49,55,32,120,53,48,53,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,26),40,101,120,116,101,110,100,101,100,45,112,114,111,99,101,100,117,114,101,63,32,120,52,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,12),40,97,50,50,53,48,32,120,53,49,53,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,21),40,112,114,111,99,101,100,117,114,101,45,100,97,116,97,32,120,53,48,56,41,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,34),40,115,101,116,45,112,114,111,99,101,100,117,114,101,45,100,97,116,97,33,32,112,114,111,99,53,49,56,32,120,53,49,57,41,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,19),40,118,101,99,116,111,114,45,108,105,107,101,63,32,120,53,50,50,41,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,115,108,111,116,115,32,120,53,51,51,41,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,98,121,116,101,115,32,120,53,51,54,41,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,40),40,109,97,107,101,45,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,32,116,121,112,101,53,52,50,32,46,32,97,114,103,115,53,52,51,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,35),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,63,32,120,53,53,49,32,46,32,116,109,112,53,53,48,53,53,50,41,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,27),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,116,121,112,101,32,120,53,54,55,41,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,29),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,108,101,110,103,116,104,32,120,53,55,48,41,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,42),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,115,108,111,116,45,115,101,116,33,32,120,53,55,51,32,105,53,55,52,32,121,53,55,53,41,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,53,56,55,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,21),40,114,101,99,111,114,100,45,62,118,101,99,116,111,114,32,120,53,56,52,41,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,101,118,105,99,116,101,100,63,32,120,53,57,52,41,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,54,49,55,32,105,54,49,57,41};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,54,48,54,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,18),40,102,95,50,53,57,51,32,105,110,116,54,48,48,54,48,51,41,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,34),40,111,98,106,101,99,116,45,101,118,105,99,116,32,120,53,57,54,32,46,32,97,108,108,111,99,97,116,111,114,53,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,54,53,52,32,105,54,53,54,41};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,54,52,50,41,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,49),40,111,98,106,101,99,116,45,101,118,105,99,116,45,116,111,45,108,111,99,97,116,105,111,110,32,120,54,51,49,32,112,116,114,54,51,50,32,46,32,108,105,109,105,116,54,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,54,56,55,32,105,54,56,57,41};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,14),40,114,101,108,101,97,115,101,32,120,54,56,49,41,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,24),40,102,95,50,56,52,54,32,99,45,112,111,105,110,116,101,114,54,55,52,54,55,56,41};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,35),40,111,98,106,101,99,116,45,114,101,108,101,97,115,101,32,120,54,55,48,32,46,32,114,101,108,101,97,115,101,114,54,55,49,41,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,48,54,32,105,55,48,56,41};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,54,57,57,41,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,115,105,122,101,32,120,54,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,52,54,32,105,55,52,56,41};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,55,51,50,41,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,33),40,111,98,106,101,99,116,45,117,110,101,118,105,99,116,32,120,55,50,51,32,46,32,116,109,112,55,50,50,55,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,108,115,116,55,50,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,24),40,111,98,106,101,99,116,45,98,101,99,111,109,101,33,32,97,108,115,116,55,53,53,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,34),40,109,117,116,97,116,101,45,112,114,111,99,101,100,117,114,101,33,32,111,108,100,55,53,56,32,112,114,111,99,55,53,57,41,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,55,56,51,41,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,38),40,109,97,107,101,45,112,111,105,110,116,101,114,45,118,101,99,116,111,114,32,110,55,55,51,32,46,32,116,109,112,55,55,50,55,55,52,41,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,22),40,112,111,105,110,116,101,114,45,118,101,99,116,111,114,63,32,120,55,57,50,41,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,55,57,56,32,112,116,114,115,56,48,48,32,105,56,48,49,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,26),40,112,111,105,110,116,101,114,45,118,101,99,116,111,114,32,46,32,112,116,114,115,55,57,52,41,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,56,49,49,41,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,35),40,112,111,105,110,116,101,114,45,118,101,99,116,111,114,45,102,105,108,108,33,32,112,118,56,48,55,32,112,116,114,56,48,56,41,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,31),40,112,118,45,98,117,102,45,115,101,116,33,32,105,56,50,56,56,51,52,32,112,116,114,56,50,57,56,51,53,41,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,39),40,112,111,105,110,116,101,114,45,118,101,99,116,111,114,45,115,101,116,33,32,112,118,56,51,56,32,105,56,51,57,32,112,116,114,56,52,48,41,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,29),40,112,111,105,110,116,101,114,45,118,101,99,116,111,114,45,108,101,110,103,116,104,32,112,118,56,53,50,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,18),40,97,51,51,49,50,32,112,118,56,52,54,32,105,56,52,55,41,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,17),40,97,51,51,51,53,32,120,53,55,57,32,105,53,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,12),40,97,51,51,53,57,32,112,52,56,54,41,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,12),40,97,51,51,54,50,32,112,52,56,52,41,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,12),40,97,51,51,54,53,32,112,52,56,50,41,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,12),40,97,51,51,54,56,32,112,52,56,48,41,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,12),40,97,51,51,55,49,32,112,52,55,56,41,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,12),40,97,51,51,55,52,32,112,52,55,54,41,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,12),40,97,51,51,55,55,32,112,52,55,52,41,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,12),40,97,51,51,56,48,32,112,52,55,50,41,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,14),67,95,108,111,99,97,116,105,118,101,95,114,101,102,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
C_regparm static C_word C_fcall stub830(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word buf=(C_word )(C_a0);
unsigned int i=(unsigned int )C_unfix(C_a1);
void * ptr=(void * )C_c_pointer_or_null(C_a2);
*((void **)C_data_pointer(buf) + i) = ptr;
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
C_regparm static C_word C_fcall stub821(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word buf=(C_word )(C_a0);
unsigned int i=(unsigned int )C_unfix(C_a1);
C_return(*((void **)C_data_pointer(buf) + i));
C_ret:
#undef return

return C_r;}

/* from k2849 */
C_regparm static C_word C_fcall stub675(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k2596 */
C_regparm static C_word C_fcall stub601(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k1942 */
C_regparm static C_word C_fcall stub375(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
C_regparm static C_word C_fcall stub365(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
C_return((unsigned char *)ptr + off);
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
C_regparm static C_word C_fcall stub350(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
C_return((void *)x);
C_ret:
#undef return

return C_r;}

/* from k1855 */
C_regparm static C_word C_fcall stub322(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k1848 */
C_regparm static C_word C_fcall stub316(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k1405 */
C_regparm static C_word C_fcall stub173(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1377 */
C_regparm static C_word C_fcall stub157(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1349 */
C_regparm static C_word C_fcall stub141(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1321 */
C_regparm static C_word C_fcall stub125(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word *av) C_noret;
C_noret_decl(f_2703)
static void C_ccall f_2703(C_word c,C_word *av) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word *av) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word *av) C_noret;
C_noret_decl(f_2621)
static void C_fcall f_2621(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word *av) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word *av) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word *av) C_noret;
C_noret_decl(f_2773)
static void C_fcall f_2773(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1205)
static void C_ccall f_1205(C_word c,C_word *av) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word *av) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word *av) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word *av) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word *av) C_noret;
C_noret_decl(f_2818)
static void C_fcall f_2818(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2768)
static void C_fcall f_2768(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word *av) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word *av) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word *av) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word *av) C_noret;
C_noret_decl(f_3002)
static void C_ccall f_3002(C_word c,C_word *av) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word *av) C_noret;
C_noret_decl(f_1469)
static void C_fcall f_1469(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word *av) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word *av) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word *av) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word *av) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word *av) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word *av) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word *av) C_noret;
C_noret_decl(f_3183)
static void C_fcall f_3183(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1476)
static void C_fcall f_1476(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word *av) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word *av) C_noret;
C_noret_decl(f_1453)
static void C_fcall f_1453(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word *av) C_noret;
C_noret_decl(f3721)
static void C_ccall f3721(C_word c,C_word *av) C_noret;
C_noret_decl(f_2865)
static void C_fcall f_2865(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word *av) C_noret;
C_noret_decl(f_1420)
static void C_ccall f_1420(C_word c,C_word *av) C_noret;
C_noret_decl(f_2897)
static void C_fcall f_2897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2899)
static void C_fcall f_2899(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word *av) C_noret;
C_noret_decl(f_2884)
static void C_fcall f_2884(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word *av) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word *av) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word *av) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word *av) C_noret;
C_noret_decl(f_2456)
static C_word C_fcall f_2456(C_word t0,C_word t1);
C_noret_decl(f_1579)
static void C_fcall f_1579(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word *av) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word *av) C_noret;
C_noret_decl(f_2370)
static void C_fcall f_2370(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_fcall f_2486(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word *av) C_noret;
C_noret_decl(f_1510)
static void C_fcall f_1510(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1447)
static void C_fcall f_1447(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word *av) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word *av) C_noret;
C_noret_decl(f_1441)
static void C_fcall f_1441(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word *av) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word *av) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word *av) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word *av) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word *av) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word *av) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word *av) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word *av) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word *av) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word *av) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word *av) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word *av) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word *av) C_noret;
C_noret_decl(C_lolevel_toplevel)
C_externexport void C_ccall C_lolevel_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word *av) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word *av) C_noret;
C_noret_decl(f_2046)
static void C_fcall f_2046(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1185)
static void C_fcall f_1185(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word *av) C_noret;
C_noret_decl(f_2538)
static void C_fcall f_2538(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2536)
static void C_fcall f_2536(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word *av) C_noret;
C_noret_decl(f_2112)
static void C_ccall f_2112(C_word c,C_word *av) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word *av) C_noret;
C_noret_decl(f_2523)
static void C_fcall f_2523(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word *av) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529(C_word c,C_word *av) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word *av) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word *av) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word *av) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word *av) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word *av) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word *av) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word *av) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word *av) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word *av) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word *av) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word *av) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word *av) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word *av) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word *av) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word *av) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word *av) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word *av) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word *av) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word *av) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word *av) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word *av) C_noret;
C_noret_decl(f_1814)
static void C_fcall f_1814(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word *av) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word *av) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word *av) C_noret;
C_noret_decl(f_1496)
static void C_ccall f_1496(C_word c,C_word *av) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word *av) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word *av) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word *av) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word *av) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word *av) C_noret;
C_noret_decl(f_1763)
static void C_ccall f_1763(C_word c,C_word *av) C_noret;
C_noret_decl(f_1769)
static void C_fcall f_1769(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1595)
static void C_fcall f_1595(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word *av) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word *av) C_noret;
C_noret_decl(f_1666)
static void C_fcall f_1666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3378)
static void C_ccall f_3378(C_word c,C_word *av) C_noret;
C_noret_decl(f_3372)
static void C_ccall f_3372(C_word c,C_word *av) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word *av) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word *av) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word *av) C_noret;
C_noret_decl(f_2497)
static void C_fcall f_2497(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word *av) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word *av) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word *av) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word *av) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word *av) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word *av) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word *av) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word *av) C_noret;
C_noret_decl(f_2954)
static void C_fcall f_2954(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2942)
static void C_ccall f_2942(C_word c,C_word *av) C_noret;
C_noret_decl(f_2949)
static void C_ccall f_2949(C_word c,C_word *av) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word *av) C_noret;
C_noret_decl(f_1153)
static void C_ccall f_1153(C_word c,C_word *av) C_noret;
C_noret_decl(f_1966)
static void C_fcall f_1966(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word *av) C_noret;
C_noret_decl(f_1625)
static void C_ccall f_1625(C_word c,C_word *av) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word *av) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word *av) C_noret;
C_noret_decl(f_1158)
static void C_fcall f_1158(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word *av) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word *av) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word *av) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word *av) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word *av) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word *av) C_noret;
C_noret_decl(f_3064)
static void C_ccall f_3064(C_word c,C_word *av) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word *av) C_noret;
C_noret_decl(f_2921)
static void C_ccall f_2921(C_word c,C_word *av) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word *av) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word *av) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word *av) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word *av) C_noret;
C_noret_decl(f_1602)
static void C_ccall f_1602(C_word c,C_word *av) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word *av) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word *av) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word *av) C_noret;
C_noret_decl(f_3086)
static void C_ccall f_3086(C_word c,C_word *av) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word *av) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word *av) C_noret;
C_noret_decl(f_1997)
static void C_fcall f_1997(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word *av) C_noret;
C_noret_decl(f_3369)
static void C_ccall f_3369(C_word c,C_word *av) C_noret;
C_noret_decl(f_3366)
static void C_ccall f_3366(C_word c,C_word *av) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word *av) C_noret;
C_noret_decl(f_3360)
static void C_ccall f_3360(C_word c,C_word *av) C_noret;
C_noret_decl(f_2640)
static void C_fcall f_2640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word *av) C_noret;
C_noret_decl(f_2646)
static void C_fcall f_2646(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word *av) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word *av) C_noret;
C_noret_decl(f_2662)
static void C_fcall f_2662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_fcall f_2664(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word *av) C_noret;
C_noret_decl(f_2152)
static void C_ccall f_2152(C_word c,C_word *av) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word *av) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word *av) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word *av) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word *av) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word *av) C_noret;
C_noret_decl(f_2685)
static void C_ccall f_2685(C_word c,C_word *av) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word *av) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word *av) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word *av) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word *av) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word *av) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word *av) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word *av) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word *av) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word *av) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word *av) C_noret;
C_noret_decl(f_3257)
static C_word C_fcall f_3257(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word *av) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word *av) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word *av) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word *av) C_noret;
C_noret_decl(f_1266)
static void C_fcall f_1266(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word *av) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word *av) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word *av) C_noret;
C_noret_decl(f_1234)
static void C_fcall f_1234(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631(C_word c,C_word *av) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word *av) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word *av) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word *av) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word *av) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word *av) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word *av) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word *av) C_noret;
C_noret_decl(f_3228)
static C_word C_fcall f_3228(C_word t0,C_word t1);
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word *av) C_noret;
C_noret_decl(f_1222)
static void C_fcall f_1222(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3025)
static void C_fcall f_3025(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word *av) C_noret;
C_noret_decl(f_2607)
static void C_fcall f_2607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word *av) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word *av) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word *av) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word *av) C_noret;
C_noret_decl(f_3136)
static C_word C_fcall f_3136(C_word t0,C_word t1);

C_noret_decl(trf_2621)
static void C_ccall trf_2621(C_word c,C_word *av) C_noret;
static void C_ccall trf_2621(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2621(t0,t1,t2);}

C_noret_decl(trf_2773)
static void C_ccall trf_2773(C_word c,C_word *av) C_noret;
static void C_ccall trf_2773(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2773(t0,t1,t2);}

C_noret_decl(trf_2818)
static void C_ccall trf_2818(C_word c,C_word *av) C_noret;
static void C_ccall trf_2818(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2818(t0,t1,t2);}

C_noret_decl(trf_2768)
static void C_ccall trf_2768(C_word c,C_word *av) C_noret;
static void C_ccall trf_2768(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2768(t0,t1);}

C_noret_decl(trf_1469)
static void C_ccall trf_1469(C_word c,C_word *av) C_noret;
static void C_ccall trf_1469(C_word c,C_word *av){
C_word t0=av[6];
C_word t1=av[5];
C_word t2=av[4];
C_word t3=av[3];
C_word t4=av[2];
C_word t5=av[1];
C_word t6=av[0];
f_1469(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3183)
static void C_ccall trf_3183(C_word c,C_word *av) C_noret;
static void C_ccall trf_3183(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3183(t0,t1,t2,t3);}

C_noret_decl(trf_1476)
static void C_ccall trf_1476(C_word c,C_word *av) C_noret;
static void C_ccall trf_1476(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1476(t0,t1);}

C_noret_decl(trf_1453)
static void C_ccall trf_1453(C_word c,C_word *av) C_noret;
static void C_ccall trf_1453(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_1453(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2865)
static void C_ccall trf_2865(C_word c,C_word *av) C_noret;
static void C_ccall trf_2865(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2865(t0,t1,t2);}

C_noret_decl(trf_2897)
static void C_ccall trf_2897(C_word c,C_word *av) C_noret;
static void C_ccall trf_2897(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2897(t0,t1);}

C_noret_decl(trf_2899)
static void C_ccall trf_2899(C_word c,C_word *av) C_noret;
static void C_ccall trf_2899(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2899(t0,t1,t2);}

C_noret_decl(trf_2884)
static void C_ccall trf_2884(C_word c,C_word *av) C_noret;
static void C_ccall trf_2884(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2884(t0,t1);}

C_noret_decl(trf_1579)
static void C_ccall trf_1579(C_word c,C_word *av) C_noret;
static void C_ccall trf_1579(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1579(t0,t1);}

C_noret_decl(trf_2370)
static void C_ccall trf_2370(C_word c,C_word *av) C_noret;
static void C_ccall trf_2370(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2370(t0,t1);}

C_noret_decl(trf_2486)
static void C_ccall trf_2486(C_word c,C_word *av) C_noret;
static void C_ccall trf_2486(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2486(t0,t1);}

C_noret_decl(trf_1510)
static void C_ccall trf_1510(C_word c,C_word *av) C_noret;
static void C_ccall trf_1510(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_1510(t0,t1,t2,t3);}

C_noret_decl(trf_1447)
static void C_ccall trf_1447(C_word c,C_word *av) C_noret;
static void C_ccall trf_1447(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1447(t0,t1,t2);}

C_noret_decl(trf_1441)
static void C_ccall trf_1441(C_word c,C_word *av) C_noret;
static void C_ccall trf_1441(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1441(t0,t1);}

C_noret_decl(trf_2046)
static void C_ccall trf_2046(C_word c,C_word *av) C_noret;
static void C_ccall trf_2046(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2046(t0,t1);}

C_noret_decl(trf_1185)
static void C_ccall trf_1185(C_word c,C_word *av) C_noret;
static void C_ccall trf_1185(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1185(t0,t1,t2);}

C_noret_decl(trf_2538)
static void C_ccall trf_2538(C_word c,C_word *av) C_noret;
static void C_ccall trf_2538(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2538(t0,t1,t2);}

C_noret_decl(trf_2536)
static void C_ccall trf_2536(C_word c,C_word *av) C_noret;
static void C_ccall trf_2536(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2536(t0,t1);}

C_noret_decl(trf_2523)
static void C_ccall trf_2523(C_word c,C_word *av) C_noret;
static void C_ccall trf_2523(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2523(t0,t1);}

C_noret_decl(trf_1814)
static void C_ccall trf_1814(C_word c,C_word *av) C_noret;
static void C_ccall trf_1814(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1814(t0,t1,t2);}

C_noret_decl(trf_1769)
static void C_ccall trf_1769(C_word c,C_word *av) C_noret;
static void C_ccall trf_1769(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1769(t0,t1,t2);}

C_noret_decl(trf_1595)
static void C_ccall trf_1595(C_word c,C_word *av) C_noret;
static void C_ccall trf_1595(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1595(t0,t1);}

C_noret_decl(trf_1666)
static void C_ccall trf_1666(C_word c,C_word *av) C_noret;
static void C_ccall trf_1666(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1666(t0,t1);}

C_noret_decl(trf_2497)
static void C_ccall trf_2497(C_word c,C_word *av) C_noret;
static void C_ccall trf_2497(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2497(t0,t1,t2);}

C_noret_decl(trf_2954)
static void C_ccall trf_2954(C_word c,C_word *av) C_noret;
static void C_ccall trf_2954(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2954(t0,t1,t2);}

C_noret_decl(trf_1966)
static void C_ccall trf_1966(C_word c,C_word *av) C_noret;
static void C_ccall trf_1966(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1966(t0,t1);}

C_noret_decl(trf_1158)
static void C_ccall trf_1158(C_word c,C_word *av) C_noret;
static void C_ccall trf_1158(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1158(t0,t1,t2);}

C_noret_decl(trf_1997)
static void C_ccall trf_1997(C_word c,C_word *av) C_noret;
static void C_ccall trf_1997(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1997(t0,t1);}

C_noret_decl(trf_2640)
static void C_ccall trf_2640(C_word c,C_word *av) C_noret;
static void C_ccall trf_2640(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2640(t0,t1);}

C_noret_decl(trf_2646)
static void C_ccall trf_2646(C_word c,C_word *av) C_noret;
static void C_ccall trf_2646(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2646(t0,t1);}

C_noret_decl(trf_2662)
static void C_ccall trf_2662(C_word c,C_word *av) C_noret;
static void C_ccall trf_2662(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2662(t0,t1);}

C_noret_decl(trf_2664)
static void C_ccall trf_2664(C_word c,C_word *av) C_noret;
static void C_ccall trf_2664(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2664(t0,t1,t2);}

C_noret_decl(trf_1266)
static void C_ccall trf_1266(C_word c,C_word *av) C_noret;
static void C_ccall trf_1266(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1266(t0,t1);}

C_noret_decl(trf_1234)
static void C_ccall trf_1234(C_word c,C_word *av) C_noret;
static void C_ccall trf_1234(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1234(t0,t1);}

C_noret_decl(trf_1222)
static void C_ccall trf_1222(C_word c,C_word *av) C_noret;
static void C_ccall trf_1222(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1222(t0,t1,t2);}

C_noret_decl(trf_3025)
static void C_ccall trf_3025(C_word c,C_word *av) C_noret;
static void C_ccall trf_3025(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3025(t0,t1,t2);}

C_noret_decl(trf_2607)
static void C_ccall trf_2607(C_word c,C_word *av) C_noret;
static void C_ccall trf_2607(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2607(t0,t1);}

/* k2876 in evict in k2858 in object-size in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2878(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_2878,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_block_size(((C_word*)t0)[3]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2935,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[3]))){
/* lolevel.scm:568: align-to-word */
t6=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=C_bytes(t3);
t7=C_bytes(C_fix(1));
t8=t4;
f_2884(t8,C_fixnum_plus(t6,t7));}}}

/* k2701 in k2644 in k2641 in k2638 in k2629 in evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in ... */
static void C_ccall f_2703(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_2703,2,av);}
a=C_alloc(4);
t2=C_a_i_plus(&a,2,t1,((C_word*)t0)[2]);
/* lolevel.scm:531: ##sys#set-pointer-address! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[96]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[96]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
tp(4,av2);}}

/* k3129 in k3117 in make-pointer-vector in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3131(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_3131,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li78),tmp=(C_word)a,a+=6,tmp);
t3=f_3136(t2,C_fix(0));
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record3(&a,3,lf[117],((C_word*)t0)[2],((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3044 in doloop746 in k3014 in k3011 in k2968 in copy in k2947 in object-unevict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3046(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3046,2,av);}
t2=C_i_setslot(((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_3025(t4,((C_word*)t0)[5],t3);}

/* evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_2621(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_2621,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2631,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm:513: hash-table-ref/default */
t4=*((C_word*)lf[92]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
av2[4]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* locative-set! in k1154 in k1151 */
static void C_ccall f_2090(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2090,4,av);}
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_i_locative_set(t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* locative->object in k2093 in k1154 in k1151 */
static void C_ccall f_2097(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2097,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_locative_to_object(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2093 in k1154 in k1151 */
static void C_ccall f_2095(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(36,c,4))){C_save_and_reclaim((void *)f_2095,2,av);}
a=C_alloc(36);
t2=C_mutate2((C_word*)lf[42]+1 /* (set! locative-ref ...) */,t1);
t3=C_mutate2((C_word*)lf[43]+1 /* (set! locative->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2097,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[44]+1 /* (set! locative? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2100,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[45]+1 /* (set! pointer-u8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2106,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[46]+1 /* (set! pointer-s8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2109,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[47]+1 /* (set! pointer-u16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2112,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[48]+1 /* (set! pointer-s16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2115,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[49]+1 /* (set! pointer-u32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2118,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[50]+1 /* (set! pointer-s32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2121,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[51]+1 /* (set! pointer-f32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2124,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate2((C_word*)lf[52]+1 /* (set! pointer-f64-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2127,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2132,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3381,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:321: getter-with-setter */
t15=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t15;
av2[1]=t13;
av2[2]=t14;
av2[3]=*((C_word*)lf[45]+1);
av2[4]=lf[137];
((C_proc)(void*)(*((C_word*)t15+1)))(5,av2);}}

/* release in k2766 in object-release in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_2773(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(17,0,3))){
C_save_and_reclaim_args((void *)trf_2773,3,t0,t1,t2);}
a=C_alloc(17);
if(C_truep(C_blockp(t2))){
if(C_truep(C_permanentp(t2))){
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_block_size(t2);
t4=t3;
t5=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2802,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_byteblockp(t2))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f3721,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:557: ##sys#address->pointer */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[23]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[23]+1);
av2[1]=t8;
av2[2]=C_block_address(&a,1,t2);
tp(3,av2);}}
else{
t8=(C_truep(C_specialp(t2))?C_fix(1):C_fix(0));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2818,a[2]=t4,a[3]=t10,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word)li65),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_2818(t12,t7,t8);}}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k1203 in loop in object-become! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_1205(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_1205,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_u_i_cdr(((C_word*)t0)[5]);
/* lolevel.scm:91: ##sys#check-block */
f_1158(t2,t3,C_a_i_list(&a,1,lf[111]));}

/* k1206 in k1203 in loop in object-become! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_1208(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1208,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* lolevel.scm:92: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1185(t4,((C_word*)t0)[4],t3);}

/* k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_2613,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word)li63),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2621(t7,t3,((C_word*)t0)[5]);}

/* k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2610(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_2610,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2613,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm:509: make-hash-table */
t4=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[94]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2614 in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2616,2,av);}
/* lolevel.scm:538: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
C_values(4,av2);}}

/* doloop687 in release in k2766 in object-release in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_2818(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_2818,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2828,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm:555: release */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2773(t5,t3,t4);}}

/* k2766 in object-release in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_2768(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_2768,2,t0,t1);}
a=C_alloc(10);
t2=t1;
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2773,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li66),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2773(t8,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* object-release in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2764(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +7,c,3))){
C_save_and_reclaim((void*)f_2764,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+7);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2768,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t3))){
t5=t3;
t6=t4;
f_2768(t6,C_u_i_car(t5));}
else{
t5=t4;
f_2768(t5,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2846,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));}}

/* k2800 in release in k2766 in object-release in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2802(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_2802,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:557: ##sys#address->pointer */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[23]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[23]+1);
av2[1]=t2;
av2[2]=C_block_address(&a,1,((C_word*)t0)[4]);
tp(3,av2);}}

/* k2807 in k2800 in release in k2766 in object-release in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2809(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2809,2,av);}
/* lolevel.scm:556: free */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* extended-procedure? in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2201(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2201,3,av);}
a=C_alloc(6);
if(C_truep(C_blockp(t2))){
if(C_truep(C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2235,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2218,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:382: ##sys#lambda-decoration */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[67]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[67]+1);
av2[1]=t3;
av2[2]=t4;
av2[3]=t5;
tp(4,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3000 in k2997 in k2968 in copy in k2947 in object-unevict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3002(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3002,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2728 in k2638 in k2629 in evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 in ... */
static void C_ccall f_2730(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2730,2,av);}
/* lolevel.scm:522: signal */
t2=*((C_word*)lf[97]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* checkn2 in move-memory! in k1154 in k1151 */
static void C_fcall f_1469(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_1469,7,t0,t1,t2,t3,t4,t5,t6);}
a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1476,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t8=C_fixnum_difference(t3,t5);
if(C_truep(C_fixnum_less_or_equal_p(t2,t8))){
t9=C_fixnum_difference(t4,t6);
t10=t7;
f_1476(t10,C_fixnum_less_or_equal_p(t2,t9));}
else{
t9=t7;
f_1476(t9,C_SCHEME_FALSE);}}

/* k3215 in pointer-vector-fill! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3217(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3217,2,av);}
a=C_alloc(6);
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=t2;
t4=C_slot(((C_word*)t0)[2],C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3228,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word)li83),tmp=(C_word)a,a+=6,tmp);
t7=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=f_3228(t6,C_fix(0));
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k2732 in k2638 in k2629 in evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 in ... */
static void C_ccall f_2734(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2734,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2738,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:528: make-property-condition */
t4=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[100];
av2[3]=lf[101];
av2[4]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2736 in k2732 in k2638 in k2629 in evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in ... */
static void C_ccall f_2738(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2738,2,av);}
/* lolevel.scm:523: make-composite-condition */
t2=*((C_word*)lf[98]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3014 in k3011 in k2968 in copy in k2947 in object-unevict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3016(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_3016,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3025,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word)li72),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3025(t7,t2,t3);}

/* k3017 in k3014 in k3011 in k2968 in copy in k2947 in object-unevict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3019(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3019,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* pointer-vector-fill! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3210(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_3210,4,av);}
a=C_alloc(5);
t4=C_i_check_structure_2(t2,lf[117],lf[121]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3217,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* lolevel.scm:652: ##sys#check-pointer */
t6=*((C_word*)lf[6]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
av2[3]=lf[121];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_3217(2,av2);}}}

/* k3011 in k2968 in copy in k2947 in object-unevict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3013(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_3013,2,av);}
a=C_alloc(7);
t2=C_copy_block(((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3016,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm:596: hash-table-set! */
t4=*((C_word*)lf[90]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[2];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* doloop798 in k3173 in pointer-vector in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_3183(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_3183,4,t0,t1,t2,t3);}
a=C_alloc(8);
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_car(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3196,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm:647: ##sys#check-pointer */
t7=*((C_word*)lf[6]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=t5;
av2[3]=lf[117];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}

/* k1474 in checkn2 in move-memory! in k1154 in k1151 */
static void C_fcall f_1476(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_1476,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* lolevel.scm:150: sizerr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1447(t2,((C_word*)t0)[3],C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]));}}

/* make-weak-locative in k1154 in k1151 */
static void C_ccall f_2074(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +0,c,5))){
C_save_and_reclaim((void*)f_2074,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+0);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
if(C_truep(C_i_nullp(t3))){
/* lolevel.scm:295: ##sys#make-locative */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[39]+1));
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=*((C_word*)lf[39]+1);
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(0);
av2[4]=C_SCHEME_TRUE;
av2[5]=lf[40];
tp(6,av2);}}
else{
t4=C_i_car(t3);
/* lolevel.scm:295: ##sys#make-locative */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[39]+1));
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=*((C_word*)lf[39]+1);
av2[1]=t1;
av2[2]=t2;
av2[3]=t4;
av2[4]=C_SCHEME_TRUE;
av2[5]=lf[40];
tp(6,av2);}}}

/* a2217 in extended-procedure? in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2218,3,av);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_eqp(lf[62],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* checkn1 in move-memory! in k1154 in k1151 */
static void C_fcall f_1453(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_1453,5,t0,t1,t2,t3,t4);}
a=C_alloc(6);
t5=C_fixnum_difference(t3,t4);
if(C_truep(C_fixnum_less_or_equal_p(t2,t5))){
t6=t2;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
/* lolevel.scm:145: sizerr */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1447(t6,t1,C_a_i_list(&a,2,t2,t3));}}

/* k2858 in object-size in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_2860,2,av);}
a=C_alloc(7);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2865,a[2]=t4,a[3]=t2,a[4]=((C_word)li70),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2865(t6,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* f3721 in release in k2766 in object-release in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f3721(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f3721,2,av);}
/* lolevel.scm:556: free */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* evict in k2858 in object-size in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_2865(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_2865,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2878,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm:564: hash-table-ref/default */
t4=*((C_word*)lf[92]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
av2[4]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* make-pointer-vector in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3103(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +6,c,2))){
C_save_and_reclaim((void*)f_3103,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+6);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?((C_word*)t0)[2]:C_i_car(t3));
t6=t5;
t7=C_i_check_exact_2(t2,lf[116]);
t8=C_fudge(C_fix(7));
t9=C_fixnum_times(t2,t8);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3119,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm:627: ##sys#make-blob */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[119]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[119]+1);
av2[1]=t10;
av2[2]=t9;
tp(3,av2);}}

/* move-memory! in k1154 in k1151 */
static void C_ccall f_1420(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +41,c,7))){
C_save_and_reclaim((void*)f_1420,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+41);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_fix(0):C_i_car(t9));
t12=t11;
t13=C_i_nullp(t9);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t15=C_i_nullp(t14);
t16=(C_truep(t15)?C_fix(0):C_i_car(t14));
t17=t16;
t18=C_i_nullp(t14);
t19=(C_truep(t18)?C_SCHEME_END_OF_LIST:C_i_cdr(t14));
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1441,a[2]=t2,a[3]=t3,a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp));
t29=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1447,a[2]=t2,a[3]=t3,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp));
t30=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1453,a[2]=t23,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp));
t31=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1469,a[2]=t23,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t32=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1496,a[2]=((C_word*)t0)[2],a[3]=t17,a[4]=t12,a[5]=t7,a[6]=t21,a[7]=t25,a[8]=t27,a[9]=t1,a[10]=t2,a[11]=t3,tmp=(C_word)a,a+=12,tmp);
/* lolevel.scm:152: ##sys#check-block */
f_1158(t32,t2,C_a_i_list(&a,1,lf[9]));}

/* k2895 in k2885 in k2882 in k2876 in evict in k2858 in object-size in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_2897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_2897,2,t0,t1);}
a=C_alloc(10);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li69),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2899(t5,((C_word*)t0)[6],t1);}

/* doloop706 in k2895 in k2885 in k2882 in k2876 in evict in k2858 in object-size in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_2899(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_2899,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2921,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[5],t2);
/* lolevel.scm:574: evict */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2865(t5,t3,t4);}}

/* k2888 in k2885 in k2882 in k2876 in evict in k2858 in object-size in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2890,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2882 in k2876 in evict in k2858 in object-size in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_2884(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,4))){
C_save_and_reclaim_args((void *)trf_2884,2,t0,t1);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2887,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm:570: hash-table-set! */
t5=*((C_word*)lf[90]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[3];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k2885 in k2882 in k2876 in evict in k2858 in object-size in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2887(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_2887,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2897,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=C_specialp(((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t3;
f_2897(t5,(C_truep(t4)?C_fix(1):C_fix(0)));}
else{
t5=C_i_symbolp(((C_word*)t0)[4]);
t6=t3;
f_2897(t6,(C_truep(t5)?C_fix(1):C_fix(0)));}}}

/* k2753 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2755,2,av);}
/* lolevel.scm:508: ##sys#address->pointer */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[23]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[23]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* k2744 in k2629 in evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2746(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2746,2,av);}
t2=C_bytes(C_fix(1));
t3=((C_word*)t0)[2];
f_2640(t3,C_fixnum_plus(t1,t2));}

/* k2449 in k2443 in record->vector in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2451(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_2451,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2456,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=f_2456(t3,C_fix(0));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* doloop587 in k2449 in k2443 in record->vector in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static C_word C_fcall f_2456(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
loop:{}
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
return(((C_word*)t0)[3]);}
else{
t2=C_slot(((C_word*)t0)[4],t1);
t3=C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=C_fixnum_plus(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* k1577 in move in k1503 in k1500 in k1497 in k1494 in move-memory! in k1154 in k1151 */
static void C_fcall f_1579(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,2))){
C_save_and_reclaim_args((void *)trf_1579,2,t0,t1);}
a=C_alloc(10);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[3];
t4=C_i_safe_pointerp(t3);
if(C_truep(t4)){
t5=t2;
f_1595(t5,t4);}
else{
t5=C_locativep(t3);
t6=t2;
f_1595(t6,t5);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1644,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm:174: ##sys#bytevector? */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[13]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[13]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}}

/* object-evict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2482(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +7,c,3))){
C_save_and_reclaim((void*)f_2482,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+7);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2486,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t3))){
t5=t3;
t6=t4;
f_2486(t6,C_u_i_car(t5));}
else{
t5=t4;
f_2486(t5,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2593,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));}}

/* k2487 in k2484 in object-evict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2489(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2489,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2492,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm:485: ##sys#check-closure */
t4=*((C_word*)lf[65]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[89];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2368 in record-instance? in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_2370(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,1))){
C_save_and_reclaim_args((void *)trf_2370,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_not(((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_slot(((C_word*)t0)[4],C_fix(0));
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_eqp(((C_word*)t0)[2],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k2484 in object-evict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_2486(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_2486,2,t0,t1);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2489,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:484: make-hash-table */
t4=*((C_word*)lf[93]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[94]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* object-evicted? in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2479(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2479,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_permanentp(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* move in k1503 in k1500 in k1497 in k1494 in move-memory! in k1154 in k1151 */
static void C_fcall f_1510(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,0,4))){
C_save_and_reclaim_args((void *)trf_1510,4,t0,t1,t2,t3);}
a=C_alloc(11);
if(C_truep(C_structurep(t2))){
t4=C_slot(t2,C_fix(0));
if(C_truep(C_i_memq(t4,((C_word*)t0)[2]))){
t5=C_slot(t2,C_fix(1));
/* lolevel.scm:161: move */
t9=t1;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t5=t1;
t6=t2;
t7=C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR);
/* lolevel.scm:128: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[1]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[1]+1);
av2[1]=t5;
av2[2]=t7;
av2[3]=lf[9];
av2[4]=t6;
tp(5,av2);}}}
else{
if(C_truep(C_structurep(t3))){
t4=C_slot(t3,C_fix(0));
if(C_truep(C_i_memq(t4,((C_word*)t0)[2]))){
t5=C_slot(t3,C_fix(1));
/* lolevel.scm:165: move */
t9=t1;
t10=t2;
t11=t5;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t5=t1;
t6=t3;
t7=C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR);
/* lolevel.scm:128: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[1]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[1]+1);
av2[1]=t5;
av2[2]=t7;
av2[3]=lf[9];
av2[4]=t6;
tp(5,av2);}}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1579,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=t2;
t6=C_i_safe_pointerp(t5);
if(C_truep(t6)){
t7=t4;
f_1579(t7,t6);}
else{
t7=C_locativep(t5);
t8=t4;
f_1579(t8,t7);}}}}

/* sizerr in move-memory! in k1154 in k1151 */
static void C_fcall f_1447(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,7))){
C_save_and_reclaim_args((void *)trf_1447,3,t0,t1,t2);}{
C_word av2[8];
av2[0]=0;
av2[1]=t1;
av2[2]=*((C_word*)lf[10]+1);
av2[3]=lf[9];
av2[4]=lf[12];
av2[5]=((C_word*)t0)[2];
av2[6]=((C_word*)t0)[3];
av2[7]=t2;
C_apply(8,av2);}}

/* k2418 in k2415 in record-instance-slot-set! in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2420(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2420,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_setslot(((C_word*)t0)[4],t2,((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* record-instance? in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2355(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +5,c,2))){
C_save_and_reclaim((void*)f_2355,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+5);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2370,a[2]=t6,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=t2;
if(C_truep(C_blockp(t8))){
t9=C_structurep(t8);
t10=t7;
f_2370(t10,t9);}
else{
t9=t7;
f_2370(t9,C_SCHEME_FALSE);}}

/* nosizerr in move-memory! in k1154 in k1151 */
static void C_fcall f_1441(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,5))){
C_save_and_reclaim_args((void *)trf_1441,2,t0,t1);}
/* lolevel.scm:137: ##sys#error */
t2=*((C_word*)lf[10]+1);{
C_word av2[6];
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[9];
av2[3]=lf[11];
av2[4]=((C_word*)t0)[2];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* record-instance-slot-set! in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2413(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_2413,5,av);}
a=C_alloc(9);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2417,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm:454: ##sys#check-generic-structure */
f_1222(t5,t2,C_a_i_list(&a,1,lf[84]));}

/* k2415 in record-instance-slot-set! in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2417(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_2417,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2420,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_block_size(((C_word*)t0)[4]);
t4=C_fixnum_difference(t3,C_fix(1));
/* lolevel.scm:455: ##sys#check-range */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[85]+1));
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=*((C_word*)lf[85]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(0);
av2[4]=t4;
av2[5]=lf[84];
tp(6,av2);}}

/* k2443 in record->vector in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2445(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2445,2,av);}
a=C_alloc(5);
t2=C_block_size(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2451,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:470: ##sys#make-vector */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[17]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[17]+1);
av2[1]=t4;
av2[2]=t3;
tp(3,av2);}}

/* record->vector in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2441(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_2441,3,av);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2445,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:468: ##sys#check-generic-structure */
f_1222(t3,t2,C_a_i_list(&a,1,lf[87]));}

/* k1500 in k1497 in k1494 in move-memory! in k1154 in k1151 */
static void C_ccall f_1502(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_1502,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[3],C_fix(0)))){
/* lolevel.scm:157: ##sys#error */
t3=*((C_word*)lf[10]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[9];
av2[3]=lf[14];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_1505(2,av2);}}}

/* k1503 in k1500 in k1497 in k1494 in move-memory! in k1154 in k1151 */
static void C_ccall f_1505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,4))){C_save_and_reclaim((void *)f_1505,2,av);}
a=C_alloc(13);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1510,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word)li7),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_1510(t5,((C_word*)t0)[9],((C_word*)t0)[10],((C_word*)t0)[11]);}

/* k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2439(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(55,c,5))){C_save_and_reclaim((void *)f_2439,2,av);}
a=C_alloc(55);
t2=C_mutate2((C_word*)lf[86]+1 /* (set! record-instance-slot ...) */,t1);
t3=C_mutate2((C_word*)lf[87]+1 /* (set! record->vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2441,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[88]+1 /* (set! object-evicted? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2479,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[89]+1 /* (set! object-evict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2482,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[95]+1 /* (set! object-evict-to-location ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2600,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[107]+1 /* (set! object-release ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2764,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[108]+1 /* (set! object-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2856,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[109]+1 /* (set! object-unevict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2942,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[111]+1 /* (set! object-become! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3060,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[114]+1 /* (set! mutate-procedure! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3069,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t12=C_a_i_list1(&a,1,lf[115]);
t13=t12;
t14=C_mutate2((C_word*)lf[116]+1 /* (set! make-pointer-vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3103,a[2]=t13,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp));
t15=C_mutate2((C_word*)lf[120]+1 /* (set! pointer-vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3164,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate2((C_word*)lf[117]+1 /* (set! pointer-vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3170,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[121]+1 /* (set! pointer-vector-fill! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3210,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2(&lf[118] /* (set! pv-buf-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3257,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate2((C_word*)lf[122]+1 /* (set! pointer-vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3271,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3302,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3313,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:675: getter-with-setter */
t22=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t22;
av2[1]=t20;
av2[2]=t21;
av2[3]=*((C_word*)lf[122]+1);
av2[4]=lf[126];
((C_proc)(void*)(*((C_word*)t22+1)))(5,av2);}}

/* number-of-slots in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2314(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_2314,3,av);}
a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2318,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=t3;
t5=t2;
t6=C_a_i_list(&a,1,lf[75]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1266,a[2]=t4,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_blockp(t5))){
t8=C_specialp(t5);
if(C_truep(t8)){
t9=t7;
f_1266(t9,C_i_not(t8));}
else{
t9=C_byteblockp(t5);
t10=t7;
f_1266(t10,C_i_not(t9));}}
else{
t8=t7;
f_1266(t8,C_SCHEME_FALSE);}}

/* k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2312(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(27,c,5))){C_save_and_reclaim((void *)f_2312,2,av);}
a=C_alloc(27);
t2=C_mutate2((C_word*)lf[74]+1 /* (set! block-ref ...) */,t1);
t3=C_mutate2((C_word*)lf[75]+1 /* (set! number-of-slots ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2314,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[77]+1 /* (set! number-of-bytes ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2323,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[79]+1 /* (set! make-record-instance ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2346,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[81]+1 /* (set! record-instance? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2355,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[82]+1 /* (set! record-instance-type ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2391,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[83]+1 /* (set! record-instance-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[84]+1 /* (set! record-instance-slot-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2413,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3336,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:459: getter-with-setter */
t12=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t12;
av2[1]=t10;
av2[2]=t11;
av2[3]=*((C_word*)lf[84]+1);
av2[4]=lf[127];
((C_proc)(void*)(*((C_word*)t12+1)))(5,av2);}}

/* k2316 in number-of-slots in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2318(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2318,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_block_size(((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* make-record-instance in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2346(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +0,c,4))){
C_save_and_reclaim((void*)f_2346,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+0);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
t4=C_i_check_symbol_2(t2,lf[79]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t1;
av2[2]=*((C_word*)lf[80]+1);
av2[3]=t2;
av2[4]=t3;
C_apply(5,av2);}}

/* k2557 in doloop617 in k2534 in k2524 in k2521 in k2518 in k2514 in k2505 in evict in k2490 in k2487 in k2484 in object-evict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in ... */
static void C_ccall f_2559(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2559,2,av);}
t2=C_i_set_i_slot(((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2538(t4,((C_word*)t0)[5],t3);}

/* make-locative in k1154 in k1151 */
static void C_ccall f_2058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +0,c,5))){
C_save_and_reclaim((void*)f_2058,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+0);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
if(C_truep(C_i_nullp(t3))){
/* lolevel.scm:292: ##sys#make-locative */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[39]+1));
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=*((C_word*)lf[39]+1);
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(0);
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[38];
tp(6,av2);}}
else{
t4=C_i_car(t3);
/* lolevel.scm:292: ##sys#make-locative */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[39]+1));
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=*((C_word*)lf[39]+1);
av2[1]=t1;
av2[2]=t2;
av2[3]=t4;
av2[4]=C_SCHEME_FALSE;
av2[5]=lf[38];
tp(6,av2);}}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_lolevel_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_lolevel_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(874)){
C_save(t1);
C_rereclaim2(874*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,141);
lf[1]=C_h_intern(&lf[1],14,"\003syserror-hook");
lf[3]=C_h_intern(&lf[3],15,"\003syssignal-hook");
lf[4]=C_h_intern(&lf[4],11,"\000type-error");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a structure");
lf[6]=C_h_intern(&lf[6],17,"\003syscheck-pointer");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[8]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004mmap\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\010"
"s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64ve"
"ctor\376\377\016");
lf[9]=C_h_intern(&lf[9],12,"move-memory!");
lf[10]=C_h_intern(&lf[10],9,"\003syserror");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\034need number of bytes to move");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[13]=C_h_intern(&lf[13],15,"\003sysbytevector\077");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\033negative destination offset");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\026negative source offset");
lf[16]=C_h_intern(&lf[16],11,"object-copy");
lf[17]=C_h_intern(&lf[17],15,"\003sysmake-vector");
lf[18]=C_h_intern(&lf[18],8,"allocate");
lf[19]=C_h_intern(&lf[19],4,"free");
lf[20]=C_h_intern(&lf[20],8,"pointer\077");
lf[21]=C_h_intern(&lf[21],13,"pointer-like\077");
lf[22]=C_h_intern(&lf[22],16,"address->pointer");
lf[23]=C_h_intern(&lf[23],20,"\003sysaddress->pointer");
lf[24]=C_h_intern(&lf[24],17,"\003syscheck-integer");
lf[25]=C_h_intern(&lf[25],16,"pointer->address");
lf[26]=C_h_intern(&lf[26],20,"\003syspointer->address");
lf[27]=C_h_intern(&lf[27],17,"\003syscheck-special");
lf[28]=C_h_intern(&lf[28],15,"object->pointer");
lf[29]=C_h_intern(&lf[29],15,"pointer->object");
lf[30]=C_h_intern(&lf[30],9,"pointer=\077");
lf[31]=C_h_intern(&lf[31],8,"pointer+");
lf[32]=C_h_intern(&lf[32],13,"align-to-word");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a pointer or integer");
lf[34]=C_h_intern(&lf[34],11,"tag-pointer");
lf[35]=C_h_intern(&lf[35],23,"\003sysmake-tagged-pointer");
lf[36]=C_h_intern(&lf[36],15,"tagged-pointer\077");
lf[37]=C_h_intern(&lf[37],11,"pointer-tag");
lf[38]=C_h_intern(&lf[38],13,"make-locative");
lf[39]=C_h_intern(&lf[39],17,"\003sysmake-locative");
lf[40]=C_h_intern(&lf[40],18,"make-weak-locative");
lf[41]=C_h_intern(&lf[41],13,"locative-set!");
lf[42]=C_h_intern(&lf[42],12,"locative-ref");
lf[43]=C_h_intern(&lf[43],16,"locative->object");
lf[44]=C_h_intern(&lf[44],9,"locative\077");
lf[45]=C_h_intern(&lf[45],15,"pointer-u8-set!");
lf[46]=C_h_intern(&lf[46],15,"pointer-s8-set!");
lf[47]=C_h_intern(&lf[47],16,"pointer-u16-set!");
lf[48]=C_h_intern(&lf[48],16,"pointer-s16-set!");
lf[49]=C_h_intern(&lf[49],16,"pointer-u32-set!");
lf[50]=C_h_intern(&lf[50],16,"pointer-s32-set!");
lf[51]=C_h_intern(&lf[51],16,"pointer-f32-set!");
lf[52]=C_h_intern(&lf[52],16,"pointer-f64-set!");
lf[53]=C_h_intern(&lf[53],14,"pointer-u8-ref");
lf[54]=C_h_intern(&lf[54],14,"pointer-s8-ref");
lf[55]=C_h_intern(&lf[55],15,"pointer-u16-ref");
lf[56]=C_h_intern(&lf[56],15,"pointer-s16-ref");
lf[57]=C_h_intern(&lf[57],15,"pointer-u32-ref");
lf[58]=C_h_intern(&lf[58],15,"pointer-s32-ref");
lf[59]=C_h_intern(&lf[59],15,"pointer-f32-ref");
lf[60]=C_h_intern(&lf[60],15,"pointer-f64-ref");
lf[61]=C_h_intern(&lf[61],8,"extended");
lf[63]=C_h_intern(&lf[63],16,"extend-procedure");
lf[64]=C_h_intern(&lf[64],19,"\003sysdecorate-lambda");
lf[65]=C_h_intern(&lf[65],17,"\003syscheck-closure");
lf[66]=C_h_intern(&lf[66],19,"extended-procedure\077");
lf[67]=C_h_intern(&lf[67],21,"\003syslambda-decoration");
lf[68]=C_h_intern(&lf[68],14,"procedure-data");
lf[69]=C_h_intern(&lf[69],19,"set-procedure-data!");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000-bad argument type - not an extended procedure");
lf[71]=C_h_intern(&lf[71],12,"vector-like\077");
lf[72]=C_h_intern(&lf[72],10,"block-set!");
lf[73]=C_h_intern(&lf[73],14,"\003sysblock-set!");
lf[74]=C_h_intern(&lf[74],9,"block-ref");
lf[75]=C_h_intern(&lf[75],15,"number-of-slots");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a vector-like object");
lf[77]=C_h_intern(&lf[77],15,"number-of-bytes");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\0002cannot compute number of bytes of immediate object");
lf[79]=C_h_intern(&lf[79],20,"make-record-instance");
lf[80]=C_h_intern(&lf[80],18,"\003sysmake-structure");
lf[81]=C_h_intern(&lf[81],16,"record-instance\077");
lf[82]=C_h_intern(&lf[82],20,"record-instance-type");
lf[83]=C_h_intern(&lf[83],22,"record-instance-length");
lf[84]=C_h_intern(&lf[84],25,"record-instance-slot-set!");
lf[85]=C_h_intern(&lf[85],15,"\003syscheck-range");
lf[86]=C_h_intern(&lf[86],20,"record-instance-slot");
lf[87]=C_h_intern(&lf[87],14,"record->vector");
lf[88]=C_h_intern(&lf[88],15,"object-evicted\077");
lf[89]=C_h_intern(&lf[89],12,"object-evict");
lf[90]=C_h_intern(&lf[90],15,"hash-table-set!");
lf[91]=C_h_intern(&lf[91],19,"\003sysundefined-value");
lf[92]=C_h_intern(&lf[92],22,"hash-table-ref/default");
lf[93]=C_h_intern(&lf[93],15,"make-hash-table");
lf[94]=C_h_intern(&lf[94],3,"eq\077");
lf[95]=C_h_intern(&lf[95],24,"object-evict-to-location");
lf[96]=C_h_intern(&lf[96],24,"\003sysset-pointer-address!");
lf[97]=C_h_intern(&lf[97],6,"signal");
lf[98]=C_h_intern(&lf[98],24,"make-composite-condition");
lf[99]=C_h_intern(&lf[99],23,"make-property-condition");
lf[100]=C_h_intern(&lf[100],5,"evict");
lf[101]=C_h_intern(&lf[101],5,"limit");
lf[102]=C_h_intern(&lf[102],3,"exn");
lf[103]=C_h_intern(&lf[103],8,"location");
lf[104]=C_h_intern(&lf[104],7,"message");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000$cannot evict object - limit exceeded");
lf[106]=C_h_intern(&lf[106],9,"arguments");
lf[107]=C_h_intern(&lf[107],14,"object-release");
lf[108]=C_h_intern(&lf[108],11,"object-size");
lf[109]=C_h_intern(&lf[109],14,"object-unevict");
lf[110]=C_h_intern(&lf[110],15,"\003sysmake-string");
lf[111]=C_h_intern(&lf[111],14,"object-become!");
lf[112]=C_h_intern(&lf[112],11,"\003sysbecome!");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000:bad argument type - not an a-list of non-immediate objects");
lf[114]=C_h_intern(&lf[114],17,"mutate-procedure!");
lf[115]=C_h_intern(&lf[115],5,"unset");
lf[116]=C_h_intern(&lf[116],19,"make-pointer-vector");
lf[117]=C_h_intern(&lf[117],14,"pointer-vector");
lf[119]=C_h_intern(&lf[119],13,"\003sysmake-blob");
lf[120]=C_h_intern(&lf[120],15,"pointer-vector\077");
lf[121]=C_h_intern(&lf[121],20,"pointer-vector-fill!");
lf[122]=C_h_intern(&lf[122],19,"pointer-vector-set!");
lf[123]=C_h_intern(&lf[123],18,"pointer-vector-ref");
lf[124]=C_h_intern(&lf[124],21,"pointer-vector-length");
lf[125]=C_h_intern(&lf[125],18,"getter-with-setter");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\031(pointer-vector-ref pv i)");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\032(record-instance-slot x i)");
lf[128]=C_h_intern(&lf[128],13,"\003sysblock-ref");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\017(block-ref x i)");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\023(pointer-f64-ref p)");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\023(pointer-f32-ref p)");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\023(pointer-s32-ref p)");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\023(pointer-u32-ref p)");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\023(pointer-s16-ref p)");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\023(pointer-u16-ref p)");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\022(pointer-s8-ref p)");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\022(pointer-u8-ref p)");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\022(locative-ref loc)");
lf[139]=C_h_intern(&lf[139],17,"register-feature!");
lf[140]=C_h_intern(&lf[140],7,"lolevel");
C_register_lf2(lf,141,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1153,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_srfi_2d69_toplevel(2,av2);}}

/* k2402 in record-instance-length in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2404(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2404,2,av);}
t2=C_block_size(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_fixnum_difference(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* record-instance-length in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2400(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_2400,3,av);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2404,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:450: ##sys#check-generic-structure */
f_1222(t3,t2,C_a_i_list(&a,1,lf[83]));}

/* k2044 in pointer-tag in k1154 in k1151 */
static void C_fcall f_2046(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_2046,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=(C_truep(C_taggedpointerp(((C_word*)t0)[3]))?C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR);
/* lolevel.scm:269: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[1]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[1]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
av2[3]=lf[37];
av2[4]=((C_word*)t0)[3];
tp(5,av2);}}}

/* loop in object-become! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_1185(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,5))){
C_save_and_reclaim_args((void *)trf_1185,3,t0,t1,t2);}
a=C_alloc(9);
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=C_u_i_car(t4);
t6=C_i_check_pair_2(t5,lf[111]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1205,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t8=C_u_i_car(t5);
/* lolevel.scm:90: ##sys#check-block */
f_1158(t7,t8,C_a_i_list(&a,1,lf[111]));}
else{
/* lolevel.scm:94: ##sys#signal-hook */
t4=*((C_word*)lf[3]+1);{
C_word av2[6];
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[4];
av2[3]=lf[111];
av2[4]=lf[113];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}}}

/* number-of-bytes in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2323(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_2323,3,av);}
if(C_truep(C_blockp(t2))){
if(C_truep(C_byteblockp(t2))){
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_block_size(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_block_size(t2);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_bytes(t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
/* lolevel.scm:420: ##sys#signal-hook */
t3=*((C_word*)lf[3]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[4];
av2[3]=lf[77];
av2[4]=lf[78];
av2[5]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}}

/* doloop617 in k2534 in k2524 in k2521 in k2518 in k2514 in k2505 in evict in k2490 in k2487 in k2484 in object-evict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in ... */
static void C_fcall f_2538(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_2538,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[5],t2);
/* lolevel.scm:499: evict */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2497(t5,t3,t4);}}

/* k2534 in k2524 in k2521 in k2518 in k2514 in k2505 in evict in k2490 in k2487 in k2484 in object-evict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in ... */
static void C_fcall f_2536(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_2536,2,t0,t1);}
a=C_alloc(10);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li58),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2538(t5,((C_word*)t0)[6],t1);}

/* pointer-s16-set! in k2093 in k1154 in k1151 */
static void C_ccall f_2115(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2115,4,av);}
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_u_i_pointer_s16_set(t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* pointer-u16-set! in k2093 in k1154 in k1151 */
static void C_ccall f_2112(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2112,4,av);}
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_u_i_pointer_u16_set(t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* pointer-u32-set! in k2093 in k1154 in k1151 */
static void C_ccall f_2118(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2118,4,av);}
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_u_i_pointer_u32_set(t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2521 in k2518 in k2514 in k2505 in evict in k2490 in k2487 in k2484 in object-evict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 in ... */
static void C_fcall f_2523(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,4))){
C_save_and_reclaim_args((void *)trf_2523,2,t0,t1);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm:494: hash-table-set! */
t3=*((C_word*)lf[90]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2524 in k2521 in k2518 in k2514 in k2505 in evict in k2490 in k2487 in k2484 in object-evict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in ... */
static void C_ccall f_2526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_2526,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2529,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2536,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=C_specialp(((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t3;
f_2536(t5,(C_truep(t4)?C_fix(1):C_fix(0)));}
else{
t5=C_i_symbolp(((C_word*)t0)[4]);
t6=t3;
f_2536(t6,(C_truep(t5)?C_fix(1):C_fix(0)));}}}

/* k2527 in k2524 in k2521 in k2518 in k2514 in k2505 in evict in k2490 in k2487 in k2484 in object-evict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in ... */
static void C_ccall f_2529(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2529,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2518 in k2514 in k2505 in evict in k2490 in k2487 in k2484 in object-evict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2520(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_2520,2,av);}
a=C_alloc(8);
t2=C_evict_block(((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2523,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[2]))){
t4=*((C_word*)lf[91]+1);
t5=t3;
f_2523(t5,C_i_set_i_slot(t2,C_fix(0),*((C_word*)lf[91]+1)));}
else{
t4=t3;
f_2523(t4,C_SCHEME_UNDEFINED);}}

/* pointer-s8-set! in k2093 in k1154 in k1151 */
static void C_ccall f_2109(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2109,4,av);}
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_u_i_pointer_s8_set(t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* pointer-u8-set! in k2093 in k1154 in k1151 */
static void C_ccall f_2106(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2106,4,av);}
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_u_i_pointer_u8_set(t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* locative? in k2093 in k1154 in k1151 */
static void C_ccall f_2100(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2100,3,av);}
if(C_truep(C_blockp(t2))){
t3=C_locativep(t2);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2514 in k2505 in evict in k2490 in k2487 in k2484 in object-evict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2516(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2516,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_bytes(C_fix(1));
t4=C_fixnum_plus(t1,t3);
/* lolevel.scm:492: allocator */
t5=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}

/* allocate in k1154 in k1151 */
static void C_ccall f_1845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_1845,3,av);}
a=C_alloc(5);
t3=C_a_i_bytevector(&a,1,C_fix(3));
t4=C_i_foreign_fixnum_argumentp(t2);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=stub316(t3,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* free in k1154 in k1151 */
static void C_ccall f_1852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1852,3,av);}
if(C_truep(t2)){
t3=C_i_foreign_pointer_argumentp(t2);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=stub322(C_SCHEME_UNDEFINED,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=stub322(C_SCHEME_UNDEFINED,C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a2190 in k2168 in extend-procedure in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2191(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_2191,4,av);}
a=C_alloc(3);
t4=C_a_i_cons(&a,2,lf[62],((C_word*)t0)[2]);
t5=C_i_setslot(t2,t3,t4);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k1921 in k1918 in pointer=? in k1154 in k1151 */
static void C_ccall f_1923(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1923,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_pointer_eqp(((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1918 in pointer=? in k1154 in k1151 */
static void C_ccall f_1920(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_1920,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:231: ##sys#check-special */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[27]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[30];
tp(4,av2);}}

/* pointer+ in k1154 in k1151 */
static void C_ccall f_1925(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_1925,4,av);}
a=C_alloc(5);
t4=C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_truep(t2)?C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=C_i_foreign_integer_argumentp(t3);
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=stub365(t4,t5,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k1833 in doloop307 in k1797 in copy in object-copy in k1154 in k1151 */
static void C_ccall f_1835(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1835,2,av);}
t2=C_i_setslot(((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_1814(t4,((C_word*)t0)[5],t3);}

/* k2168 in extend-procedure in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2170(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_2170,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2175,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2191,a[2]=((C_word*)t0)[2],a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:376: ##sys#decorate-lambda */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[64]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[64]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
av2[4]=t3;
tp(5,av2);}}

/* k1800 in k1797 in copy in object-copy in k1154 in k1151 */
static void C_ccall f_1802(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1802,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a2174 in k2168 in extend-procedure in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2175(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2175,3,av);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_eqp(lf[62],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3300 in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3302(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3302,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[123]+1 /* (set! pointer-vector-ref ...) */,t1);
t3=C_mutate2((C_word*)lf[124]+1 /* (set! pointer-vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3304,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* pointer-vector-length in k3300 in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3304(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3304,3,av);}
t3=C_i_check_structure_2(t2,lf[117],lf[124]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_slot(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* align-to-word in k1154 in k1151 */
static void C_ccall f_1945(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_1945,3,av);}
a=C_alloc(6);
if(C_truep(C_i_integerp(t2))){
t3=t1;
t4=t2;
t5=C_a_i_bytevector(&a,1,C_fix(4));
t6=C_i_foreign_integer_argumentp(t4);
t7=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=stub375(t5,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1966,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=t2;
if(C_truep(C_blockp(t4))){
t5=C_specialp(t4);
t6=t3;
f_1966(t6,t5);}
else{
t5=t3;
f_1966(t5,C_SCHEME_FALSE);}}}

/* k2505 in evict in k2490 in k2487 in k2484 in object-evict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2507(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_2507,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_block_size(((C_word*)t0)[3]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2516,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[3]))){
/* lolevel.scm:491: align-to-word */
t5=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_bytes(t3);
f_2516(2,av2);}}}}

/* k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2160(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(20,c,4))){C_save_and_reclaim((void *)f_2160,2,av);}
a=C_alloc(20);
t2=C_mutate2((C_word*)lf[60]+1 /* (set! pointer-f64-ref ...) */,t1);
t3=C_a_i_vector1(&a,1,lf[61]);
t4=C_mutate2(&lf[62] /* (set! xproc-tag ...) */,t3);
t5=C_mutate2((C_word*)lf[63]+1 /* (set! extend-procedure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2166,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[66]+1 /* (set! extended-procedure? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2201,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[68]+1 /* (set! procedure-data ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2237,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[69]+1 /* (set! set-procedure-data! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2276,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[71]+1 /* (set! vector-like? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2291,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[72]+1 /* (set! block-set! ...) */,*((C_word*)lf[73]+1));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:411: getter-with-setter */
t12=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t12;
av2[1]=t11;
av2[2]=*((C_word*)lf[128]+1);
av2[3]=*((C_word*)lf[73]+1);
av2[4]=lf[129];
((C_proc)(void*)(*((C_word*)t12+1)))(5,av2);}}

/* a3312 in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3313(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_3313,4,av);}
a=C_alloc(5);
t4=C_i_check_structure_2(t2,lf[117],lf[123]);
t5=C_i_check_exact_2(t3,lf[123]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3323,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(1));
/* lolevel.scm:679: ##sys#check-range */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[85]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[85]+1);
av2[1]=t6;
av2[2]=t3;
av2[3]=C_fix(0);
av2[4]=t7;
tp(5,av2);}}

/* doloop307 in k1797 in copy in object-copy in k1154 in k1151 */
static void C_fcall f_1814(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_1814,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1835,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm:200: copy */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1769(t5,t3,t4);}}

/* extend-procedure in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2166(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_2166,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2170,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:375: ##sys#check-closure */
t5=*((C_word*)lf[65]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
av2[3]=lf[63];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k3321 in a3312 in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3323(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_3323,2,av);}
a=C_alloc(5);
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
t5=C_a_i_bytevector(&a,1,C_fix(3));
t6=C_i_foreign_fixnum_argumentp(t4);
t7=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=stub821(t5,t2,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k1497 in k1494 in move-memory! in k1154 in k1151 */
static void C_ccall f_1499(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_1499,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[4],C_fix(0)))){
/* lolevel.scm:155: ##sys#error */
t3=*((C_word*)lf[10]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[9];
av2[3]=lf[15];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_1502(2,av2);}}}

/* k1494 in move-memory! in k1154 in k1151 */
static void C_ccall f_1496(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_1496,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* lolevel.scm:153: ##sys#check-block */
f_1158(t2,((C_word*)t0)[11],C_a_i_list(&a,1,lf[9]));}

/* pointer-vector-set! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3271(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_3271,5,av);}
a=C_alloc(6);
t5=C_i_check_structure_2(t2,lf[117],lf[123]);
t6=C_i_check_exact_2(t3,lf[123]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3281,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t8=C_slot(t2,C_fix(1));
/* lolevel.scm:670: ##sys#check-range */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[85]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[85]+1);
av2[1]=t7;
av2[2]=t3;
av2[3]=C_fix(0);
av2[4]=t8;
tp(5,av2);}}

/* pointer->object in k1154 in k1151 */
static void C_ccall f_1910(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1910,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1914,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:226: ##sys#check-pointer */
t4=*((C_word*)lf[6]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=lf[29];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k1912 in pointer->object in k1154 in k1151 */
static void C_ccall f_1914(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1914,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_pointer_to_object(((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* pointer=? in k1154 in k1151 */
static void C_ccall f_1916(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_1916,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1920,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:230: ##sys#check-special */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[27]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=t4;
av2[2]=t2;
av2[3]=lf[30];
tp(4,av2);}}

/* k1609 in k1593 in k1577 in move in k1503 in k1500 in k1497 in k1494 in move-memory! in k1154 in k1151 */
static void C_ccall f_1611(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,4))){C_save_and_reclaim((void *)f_1611,2,av);}
a=C_alloc(13);
t2=(C_truep(t1)?t1:C_i_stringp(((C_word*)t0)[2]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1621,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[8])){
t5=C_block_size(((C_word*)t0)[2]);
/* lolevel.scm:171: checkn1 */
t6=((C_word*)((C_word*)t0)[7])[1];
f_1453(t6,t3,((C_word*)t0)[8],t5,((C_word*)t0)[5]);}
else{
/* lolevel.scm:171: nosizerr */
t5=((C_word*)((C_word*)t0)[9])[1];
f_1441(t5,t4);}}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR);
/* lolevel.scm:128: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[1]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[1]+1);
av2[1]=t3;
av2[2]=t5;
av2[3]=lf[9];
av2[4]=t4;
tp(5,av2);}}}

/* object-copy in k1154 in k1151 */
static void C_ccall f_1763(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1763,3,av);}
a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1769,a[2]=t4,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1769(t6,t1,t2);}

/* copy in object-copy in k1154 in k1151 */
static void C_fcall f_1769(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_1769,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_blockp(t2))){
if(C_truep(C_i_symbolp(t2))){
t3=C_slot(t2,C_fix(1));
/* lolevel.scm:192: ##sys#intern-symbol */{
C_word av2[3];
av2[0]=0;
av2[1]=t1;
av2[2]=t3;
C_string_to_symbol(3,av2);}}
else{
t3=C_block_size(t2);
t4=t3;
t5=(C_truep(C_byteblockp(t2))?C_words(t4):t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1799,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm:196: ##sys#make-vector */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[17]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[17]+1);
av2[1]=t6;
av2[2]=t5;
tp(3,av2);}}}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k1593 in k1577 in move in k1503 in k1500 in k1497 in k1494 in move-memory! in k1154 in k1151 */
static void C_fcall f_1595(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,2))){
C_save_and_reclaim_args((void *)trf_1595,2,t0,t1);}
a=C_alloc(10);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[7])){
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=((C_word*)t0)[7];
f_1602(2,av2);}}
else{
/* lolevel.scm:169: nosizerr */
t3=((C_word*)((C_word*)t0)[8])[1];
f_1441(t3,t2);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm:170: ##sys#bytevector? */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[13]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[13]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}}

/* k3279 in pointer-vector-set! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3281(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_3281,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
/* lolevel.scm:671: ##sys#check-pointer */
t3=*((C_word*)lf[6]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=lf[122];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=C_slot(((C_word*)t0)[2],C_fix(2));
/* lolevel.scm:672: pv-buf-set! */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=f_3257(t3,((C_word*)t0)[4],((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k3282 in k3279 in pointer-vector-set! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3284(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3284,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(2));
/* lolevel.scm:672: pv-buf-set! */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=f_3257(t2,((C_word*)t0)[4],((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1664 in k1642 in k1577 in move in k1503 in k1500 in k1497 in k1494 in move-memory! in k1154 in k1151 */
static void C_fcall f_1666(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,4))){
C_save_and_reclaim_args((void *)trf_1666,2,t0,t1);}
a=C_alloc(10);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[7])){
/* lolevel.scm:177: checkn1 */
t3=((C_word*)((C_word*)t0)[8])[1];
f_1453(t3,t2,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[6]);}
else{
/* lolevel.scm:177: checkn1 */
t3=((C_word*)((C_word*)t0)[8])[1];
f_1453(t3,t2,((C_word*)t0)[9],((C_word*)t0)[9],((C_word*)t0)[6]);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm:178: ##sys#bytevector? */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[13]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[13]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}}

/* a3377 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3378(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3378,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_u_i_pointer_s8_ref(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a3371 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3372(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3372,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_u_i_pointer_s16_ref(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1671 in k1664 in k1642 in k1577 in move in k1503 in k1500 in k1497 in k1494 in move-memory! in k1154 in k1151 */
static void C_ccall f_1673(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1673,2,av);}
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
t5=(C_truep(t3)?C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t6=(C_truep(t4)?C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t7=C_i_foreign_fixnum_argumentp(t1);
t8=C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t9=C_i_foreign_fixnum_argumentp(((C_word*)t0)[6]);
t10=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=stub141(C_SCHEME_UNDEFINED,t5,t6,t7,t8,t9);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}

/* a3374 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3375(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3375,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_u_i_pointer_u16_ref(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2490 in k2487 in k2484 in object-evict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2492(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_2492,2,av);}
a=C_alloc(8);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2497,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li59),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2497(t5,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* evict in k2490 in k2487 in k2484 in object-evict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_2497(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,4))){
C_save_and_reclaim_args((void *)trf_2497,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2507,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm:488: hash-table-ref/default */
t4=*((C_word*)lf[92]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
av2[4]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* address->pointer in k1154 in k1151 */
static void C_ccall f_1881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1881,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1885,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:214: ##sys#check-integer */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[24]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[24]+1);
av2[1]=t3;
av2[2]=t2;
av2[3]=lf[22];
tp(4,av2);}}

/* k1883 in address->pointer in k1154 in k1151 */
static void C_ccall f_1885(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1885,2,av);}
/* lolevel.scm:215: ##sys#address->pointer */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[23]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[23]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}

/* a3380 in k2093 in k1154 in k1151 */
static void C_ccall f_3381(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3381,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_u_i_pointer_u8_ref(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* object->pointer in k1154 in k1151 */
static void C_ccall f_1899(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_1899,3,av);}
a=C_alloc(5);
if(C_truep(C_blockp(t2))){
t3=t1;
t4=t2;
t5=C_a_i_bytevector(&a,1,C_fix(3));
t6=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=stub350(t5,t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1642 in k1577 in move in k1503 in k1500 in k1497 in k1494 in move-memory! in k1154 in k1151 */
static void C_ccall f_1644(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_1644,2,av);}
a=C_alloc(11);
t2=(C_truep(t1)?t1:C_i_stringp(((C_word*)t0)[2]));
if(C_truep(t2)){
t3=C_block_size(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1666,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t4,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=((C_word*)t0)[4];
t7=C_i_safe_pointerp(t6);
if(C_truep(t7)){
t8=t5;
f_1666(t8,t7);}
else{
t8=C_locativep(t6);
t9=t5;
f_1666(t9,t8);}}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR);
/* lolevel.scm:128: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[1]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[1]+1);
av2[1]=t3;
av2[2]=t5;
av2[3]=lf[9];
av2[4]=t4;
tp(5,av2);}}}

/* k1797 in copy in object-copy in k1154 in k1151 */
static void C_ccall f_1799(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_1799,2,av);}
a=C_alloc(13);
t2=C_copy_block(((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1802,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_byteblockp(((C_word*)t0)[2]);
t5=(C_truep(t4)?t4:C_i_symbolp(((C_word*)t0)[2]));
if(C_truep(t5)){
t6=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=(C_truep(C_specialp(((C_word*)t0)[2]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t8,a[5]=((C_word*)t0)[5],a[6]=((C_word)li9),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_1814(t10,t3,t6);}}

/* pointer->address in k1154 in k1151 */
static void C_ccall f_1890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1890,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1894,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:218: ##sys#check-special */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[27]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=t3;
av2[2]=t2;
av2[3]=lf[25];
tp(4,av2);}}

/* k1892 in pointer->address in k1154 in k1151 */
static void C_ccall f_1894(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1894,2,av);}
/* lolevel.scm:219: ##sys#pointer->address */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[26]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[26]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}

/* copy in k2947 in object-unevict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_2954(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,4))){
C_save_and_reclaim_args((void *)trf_2954,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_blockp(t2))){
if(C_truep(C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2970,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm:582: hash-table-ref/default */
t4=*((C_word*)lf[92]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
av2[4]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* object-unevict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2942(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +5,c,2))){
C_save_and_reclaim((void*)f_2942,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+5);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2949,a[2]=t6,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:578: make-hash-table */
t8=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=*((C_word*)lf[94]+1);
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k2947 in object-unevict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_2949,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2954,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=((C_word)li73),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2954(t6,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* pointer? in k1154 in k1151 */
static void C_ccall f_1862(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1862,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_safe_pointerp(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1151 */
static void C_ccall f_1153(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1153,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1156,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:49: register-feature! */
t3=*((C_word*)lf[139]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[140];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k1964 in align-to-word in k1154 in k1151 */
static void C_fcall f_1966(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,5))){
C_save_and_reclaim_args((void *)trf_1966,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:244: ##sys#pointer->address */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[26]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[26]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}
else{
/* lolevel.scm:246: ##sys#signal-hook */
t2=*((C_word*)lf[3]+1);{
C_word av2[6];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[4];
av2[3]=lf[32];
av2[4]=lf[33];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}}

/* k1619 in k1609 in k1593 in k1577 in move in k1503 in k1500 in k1497 in k1494 in move-memory! in k1154 in k1151 */
static void C_ccall f_1621(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1621,2,av);}
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
t5=(C_truep(t3)?C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t6=(C_truep(t4)?C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t7=C_i_foreign_fixnum_argumentp(t1);
t8=C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t9=C_i_foreign_fixnum_argumentp(((C_word*)t0)[6]);
t10=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=stub157(C_SCHEME_UNDEFINED,t5,t6,t7,t8,t9);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}

/* k1623 in k1609 in k1593 in k1577 in move in k1503 in k1500 in k1497 in k1494 in move-memory! in k1154 in k1151 */
static void C_ccall f_1625(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1625,2,av);}
t2=C_block_size(((C_word*)t0)[2]);
/* lolevel.scm:171: checkn1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1453(t3,((C_word*)t0)[4],t1,t2,((C_word*)t0)[5]);}

/* record-instance-type in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2391(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_2391,3,av);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2395,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:446: ##sys#check-generic-structure */
f_1222(t3,t2,C_a_i_list(&a,1,lf[82]));}

/* k2393 in record-instance-type in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2395(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2395,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_slot(((C_word*)t0)[3],C_fix(0));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* ##sys#check-block in k1154 in k1151 */
static void C_fcall f_1158(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_1158,3,t1,t2,t3);}
if(C_truep(C_blockp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_BLOCK_ERROR);
if(C_truep(C_i_pairp(t3))){
t5=t3;
t6=C_u_i_car(t5);
/* lolevel.scm:79: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[1]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[1]+1);
av2[1]=t1;
av2[2]=t4;
av2[3]=t6;
av2[4]=t2;
tp(5,av2);}}
else{
/* lolevel.scm:79: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[1]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[1]+1);
av2[1]=t1;
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
av2[4]=t2;
tp(5,av2);}}}}

/* k1154 in k1151 */
static void C_ccall f_1156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(73,c,4))){C_save_and_reclaim((void *)f_1156,2,av);}
a=C_alloc(73);
t2=C_mutate2(&lf[0] /* (set! ##sys#check-block ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1158,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate2(&lf[2] /* (set! ##sys#check-generic-structure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1222,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[6]+1 /* (set! ##sys#check-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1279,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=lf[8];
t6=C_mutate2((C_word*)lf[9]+1 /* (set! move-memory! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1420,a[2]=t5,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate2((C_word*)lf[16]+1 /* (set! object-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1763,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[18]+1 /* (set! allocate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1845,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[19]+1 /* (set! free ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1852,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[20]+1 /* (set! pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1862,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[21]+1 /* (set! pointer-like? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1870,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate2((C_word*)lf[22]+1 /* (set! address->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1881,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate2((C_word*)lf[25]+1 /* (set! pointer->address ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1890,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate2((C_word*)lf[28]+1 /* (set! object->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1899,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate2((C_word*)lf[29]+1 /* (set! pointer->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1910,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate2((C_word*)lf[30]+1 /* (set! pointer=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1916,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[31]+1 /* (set! pointer+ ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1925,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2((C_word*)lf[32]+1 /* (set! align-to-word ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1945,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate2((C_word*)lf[34]+1 /* (set! tag-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1982,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate2((C_word*)lf[36]+1 /* (set! tagged-pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2003,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate2((C_word*)lf[37]+1 /* (set! pointer-tag ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2034,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate2((C_word*)lf[38]+1 /* (set! make-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2058,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate2((C_word*)lf[40]+1 /* (set! make-weak-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2074,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate2((C_word*)lf[41]+1 /* (set! locative-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2090,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2095,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)C_locative_ref,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:300: getter-with-setter */
t27=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t27;
av2[1]=t25;
av2[2]=t26;
av2[3]=*((C_word*)lf[41]+1);
av2[4]=lf[138];
((C_proc)(void*)(*((C_word*)t27+1)))(5,av2);}}

/* k2933 in k2876 in evict in k2858 in object-size in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2935(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2935,2,av);}
t2=C_bytes(C_fix(1));
t3=((C_word*)t0)[2];
f_2884(t3,C_fixnum_plus(t1,t2));}

/* mutate-procedure! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_3069,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3073,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:610: ##sys#check-closure */
t5=*((C_word*)lf[65]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
av2[3]=lf[114];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* pointer-like? in k1154 in k1151 */
static void C_ccall f_1870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1870,3,av);}
if(C_truep(C_blockp(t2))){
t3=C_specialp(t2);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a3335 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3336(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_3336,4,av);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3340,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:461: ##sys#check-generic-structure */
f_1222(t4,t2,C_a_i_list(&a,1,lf[86]));}

/* object-become! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3060(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_3060,3,av);}
a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3064,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_i_check_list_2(t4,lf[111]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1185,a[2]=t7,a[3]=t4,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1185(t9,t3,t4);}

/* k3062 in object-become! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3064(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3064,2,av);}
/* lolevel.scm:607: ##sys#become! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[112]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[112]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}

/* k1975 in k1964 in align-to-word in k1154 in k1151 */
static void C_ccall f_1977(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_1977,2,av);}
a=C_alloc(6);
t2=C_a_i_bytevector(&a,1,C_fix(4));
t3=C_i_foreign_integer_argumentp(t1);
t4=stub375(t2,t3);
/* lolevel.scm:244: ##sys#address->pointer */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[23]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[23]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t4;
tp(3,av2);}}

/* k2919 in doloop706 in k2895 in k2885 in k2882 in k2876 in evict in k2858 in object-size in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 in ... */
static void C_ccall f_2921(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2921,2,av);}
t2=C_fixnum_plus(t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t5=((C_word*)((C_word*)t0)[4])[1];
f_2899(t5,((C_word*)t0)[5],t4);}

/* k3074 in k3071 in mutate-procedure! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3076,2,av);}
a=C_alloc(5);
t2=C_block_size(((C_word*)t0)[2]);
t3=C_words(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3083,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:614: ##sys#make-vector */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[17]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[17]+1);
av2[1]=t4;
av2[2]=t3;
tp(3,av2);}}

/* tag-pointer in k1154 in k1151 */
static void C_ccall f_1982(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1982,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1986,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:254: ##sys#make-tagged-pointer */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[35]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[35]+1);
av2[1]=t4;
av2[2]=t3;
tp(3,av2);}}

/* k3341 in k3338 in a3335 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3343,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3071 in mutate-procedure! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_3073,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:611: ##sys#check-closure */
t3=*((C_word*)lf[65]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[114];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k1600 in k1593 in k1577 in move in k1503 in k1500 in k1497 in k1494 in move-memory! in k1154 in k1151 */
static void C_ccall f_1602(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1602,2,av);}
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
t5=(C_truep(t3)?C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t6=(C_truep(t4)?C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t7=C_i_foreign_fixnum_argumentp(t1);
t8=C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t9=C_i_foreign_fixnum_argumentp(((C_word*)t0)[6]);
t10=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=stub125(C_SCHEME_UNDEFINED,t5,t6,t7,t8,t9);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}

/* k3338 in a3335 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3340(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,5))){C_save_and_reclaim((void *)f_3340,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[4]);
t4=C_fixnum_difference(t3,C_fix(1));
/* lolevel.scm:462: ##sys#check-range */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[85]+1));
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=*((C_word*)lf[85]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(0);
av2[4]=t4;
av2[5]=lf[86];
tp(6,av2);}}

/* k1984 in tag-pointer in k1154 in k1151 */
static void C_ccall f_1986(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_1986,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1989,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1997,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[3];
if(C_truep(C_blockp(t5))){
t6=C_specialp(t5);
t7=t4;
f_1997(t7,t6);}
else{
t6=t4;
f_1997(t6,C_SCHEME_FALSE);}}

/* k1987 in k1984 in tag-pointer in k1154 in k1151 */
static void C_ccall f_1989(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1989,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3084 in k3081 in k3074 in k3071 in mutate-procedure! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3086(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3086,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1691 in k1681 in k1664 in k1642 in k1577 in move in k1503 in k1500 in k1497 in k1494 in move-memory! in k1154 in k1151 */
static void C_ccall f_1693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1693,2,av);}
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
t5=(C_truep(t3)?C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t6=(C_truep(t4)?C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t7=C_i_foreign_fixnum_argumentp(t1);
t8=C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t9=C_i_foreign_fixnum_argumentp(((C_word*)t0)[6]);
t10=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=stub173(C_SCHEME_UNDEFINED,t5,t6,t7,t8,t9);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}

/* k3081 in k3074 in k3071 in mutate-procedure! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3083(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_3083,2,av);}
a=C_alloc(8);
t2=C_copy_block(((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3086,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3098,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:615: proc */
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1995 in k1984 in tag-pointer in k1154 in k1151 */
static void C_fcall f_1997(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_1997,2,t0,t1);}
if(C_truep(t1)){
t2=C_copy_pointer(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR);
/* lolevel.scm:257: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[1]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[1]+1);
av2[1]=((C_word*)t0)[5];
av2[2]=t2;
av2[3]=lf[34];
av2[4]=((C_word*)t0)[2];
tp(5,av2);}}}

/* k3096 in k3081 in k3074 in k3071 in mutate-procedure! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3098(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3098,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list1(&a,1,t2);
/* lolevel.scm:615: ##sys#become! */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[112]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[112]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=t3;
tp(3,av2);}}

/* a3368 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3369(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,1))){C_save_and_reclaim((void *)f_3369,3,av);}
a=C_alloc(4);
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_u_i_pointer_u32_ref(&a,1,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a3365 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3366(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,1))){C_save_and_reclaim((void *)f_3366,3,av);}
a=C_alloc(4);
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_u_i_pointer_s32_ref(&a,1,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a3362 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3363(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,1))){C_save_and_reclaim((void *)f_3363,3,av);}
a=C_alloc(4);
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_u_i_pointer_f32_ref(&a,1,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a3359 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3360(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,1))){C_save_and_reclaim((void *)f_3360,3,av);}
a=C_alloc(4);
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_u_i_pointer_f64_ref(&a,1,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2638 in k2629 in evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_2640(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(22,0,8))){
C_save_and_reclaim_args((void *)trf_2640,2,t0,t1);}
a=C_alloc(22);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t4=C_fixnum_difference(((C_word*)((C_word*)t0)[8])[1],t2);
t5=C_mutate2(((C_word *)((C_word*)t0)[8])+1,t4);
if(C_truep(C_fixnum_lessp(((C_word*)((C_word*)t0)[8])[1],C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2730,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2734,a[2]=t6,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t8=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[8])[1]);
/* lolevel.scm:524: make-property-condition */
t9=*((C_word*)lf[99]+1);{
C_word av2[9];
av2[0]=t9;
av2[1]=t7;
av2[2]=lf[102];
av2[3]=lf[103];
av2[4]=lf[95];
av2[5]=lf[104];
av2[6]=lf[105];
av2[7]=lf[106];
av2[8]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(9,av2);}}
else{
t6=C_SCHEME_UNDEFINED;
t7=t3;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
f_2643(2,av2);}}}
else{
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2643(2,av2);}}}

/* k2647 in k2644 in k2641 in k2638 in k2629 in evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in ... */
static void C_ccall f_2649(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_2649,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm:532: hash-table-set! */
t3=*((C_word*)lf[90]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2644 in k2641 in k2638 in k2629 in evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in ... */
static void C_fcall f_2646(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,0,2))){
C_save_and_reclaim_args((void *)trf_2646,2,t0,t1);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2703,a[2]=((C_word*)t0)[8],a[3]=t2,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:531: ##sys#pointer->address */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[26]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[26]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[9];
tp(3,av2);}}

/* k2641 in k2638 in k2629 in evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 in ... */
static void C_ccall f_2643(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_2643,2,av);}
a=C_alloc(10);
t2=C_evict_block(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[2]))){
t4=*((C_word*)lf[91]+1);
t5=t3;
f_2646(t5,C_i_set_i_slot(t2,C_fix(0),*((C_word*)lf[91]+1)));}
else{
t4=t3;
f_2646(t4,C_SCHEME_UNDEFINED);}}

/* f_2593 in object-evict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2593(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_2593,3,av);}
a=C_alloc(5);
t3=C_a_i_bytevector(&a,1,C_fix(3));
t4=C_i_foreign_fixnum_argumentp(t2);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=stub601(t3,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k2660 in k2650 in k2647 in k2644 in k2641 in k2638 in k2629 in evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in ... */
static void C_fcall f_2662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_2662,2,t0,t1);}
a=C_alloc(10);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li62),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2664(t5,((C_word*)t0)[6],t1);}

/* doloop654 in k2660 in k2650 in k2647 in k2644 in k2641 in k2638 in k2629 in evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in ... */
static void C_fcall f_2664(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_2664,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2685,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[5],t2);
/* lolevel.scm:536: evict */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2621(t5,t3,t4);}}

/* k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2156,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[59]+1 /* (set! pointer-f32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2160,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3360,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:363: getter-with-setter */
t5=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[52]+1);
av2[4]=lf[130];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2152(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2152,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[58]+1 /* (set! pointer-s32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2156,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3363,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:357: getter-with-setter */
t5=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[51]+1);
av2[4]=lf[131];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k2650 in k2647 in k2644 in k2641 in k2638 in k2629 in evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in ... */
static void C_ccall f_2652(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_2652,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=C_specialp(((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t3;
f_2662(t5,(C_truep(t4)?C_fix(1):C_fix(0)));}
else{
t5=C_i_symbolp(((C_word*)t0)[4]);
t6=t3;
f_2662(t6,(C_truep(t5)?C_fix(1):C_fix(0)));}}}

/* k2653 in k2650 in k2647 in k2644 in k2641 in k2638 in k2629 in evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in ... */
static void C_ccall f_2655(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2655,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2148(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2148,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[57]+1 /* (set! pointer-u32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2152,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3366,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:351: getter-with-setter */
t5=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[50]+1);
av2[4]=lf[132];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2144(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2144,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[56]+1 /* (set! pointer-s16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2148,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3369,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:345: getter-with-setter */
t5=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[49]+1);
av2[4]=lf[133];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2140(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2140,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[55]+1 /* (set! pointer-u16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2144,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3372,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:339: getter-with-setter */
t5=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[48]+1);
av2[4]=lf[134];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k2683 in doloop654 in k2660 in k2650 in k2647 in k2644 in k2641 in k2638 in k2629 in evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in ... */
static void C_ccall f_2685(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2685,2,av);}
t2=C_i_set_i_slot(((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_2664(t4,((C_word*)t0)[5],t3);}

/* k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2136(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2136,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[54]+1 /* (set! pointer-s8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2140,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3375,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:333: getter-with-setter */
t5=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[47]+1);
av2[4]=lf[135];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2132(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2132,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[53]+1 /* (set! pointer-u8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2136,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3378,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:327: getter-with-setter */
t5=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=*((C_word*)lf[46]+1);
av2[4]=lf[136];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k1681 in k1664 in k1642 in k1577 in move in k1503 in k1500 in k1497 in k1494 in move-memory! in k1154 in k1151 */
static void C_ccall f_1683(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,6))){C_save_and_reclaim((void *)f_1683,2,av);}
a=C_alloc(7);
t2=(C_truep(t1)?t1:C_i_stringp(((C_word*)t0)[2]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1693,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_truep(((C_word*)t0)[7])?((C_word*)t0)[7]:((C_word*)t0)[8]);
t5=C_block_size(((C_word*)t0)[2]);
/* lolevel.scm:179: checkn2 */
t6=((C_word*)((C_word*)t0)[9])[1];
f_1469(t6,t3,t4,((C_word*)t0)[8],t5,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR);
/* lolevel.scm:128: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[1]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[1]+1);
av2[1]=t3;
av2[2]=t5;
av2[3]=lf[9];
av2[4]=t4;
tp(5,av2);}}}

/* ##sys#check-pointer in k1154 in k1151 */
static void C_ccall f_1279(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +0,c,5))){
C_save_and_reclaim((void*)f_1279,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+0);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=t2;
if(C_truep(C_i_safe_pointerp(t4))){
t5=C_SCHEME_UNDEFINED;
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR);
if(C_truep(C_i_pairp(t3))){
t6=t3;
t7=C_u_i_car(t6);
/* lolevel.scm:114: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[1]+1));
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=*((C_word*)lf[1]+1);
av2[1]=t1;
av2[2]=t5;
av2[3]=t7;
av2[4]=lf[7];
av2[5]=t2;
tp(6,av2);}}
else{
/* lolevel.scm:114: ##sys#error-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[1]+1));
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=*((C_word*)lf[1]+1);
av2[1]=t1;
av2[2]=t5;
av2[3]=C_SCHEME_FALSE;
av2[4]=lf[7];
av2[5]=t2;
tp(6,av2);}}}}

/* k2997 in k2968 in copy in k2947 in object-unevict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2999,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3002,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:591: hash-table-set! */
t4=*((C_word*)lf[90]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* pointer-f64-set! in k2093 in k1154 in k1151 */
static void C_ccall f_2127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2127,4,av);}
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_u_i_pointer_f64_set(t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* pointer-s32-set! in k2093 in k1154 in k1151 */
static void C_ccall f_2121(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2121,4,av);}
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_u_i_pointer_s32_set(t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* pointer-f32-set! in k2093 in k1154 in k1151 */
static void C_ccall f_2124(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2124,4,av);}
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_u_i_pointer_f32_set(t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2233 in extended-procedure? in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2235(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2235,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* procedure-data in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2237(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2237,3,av);}
a=C_alloc(6);
if(C_truep(C_blockp(t2))){
if(C_truep(C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2268,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2251,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:382: ##sys#lambda-decoration */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[67]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[67]+1);
av2[1]=t3;
av2[2]=t4;
av2[3]=t5;
tp(4,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* pv-buf-set! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static C_word C_fcall f_3257(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;{}
t4=C_i_foreign_fixnum_argumentp(t2);
if(C_truep(t3)){
t5=C_i_foreign_pointer_argumentp(t3);
return(stub830(C_SCHEME_UNDEFINED,t1,t4,t5));}
else{
return(stub830(C_SCHEME_UNDEFINED,t1,t4,C_SCHEME_FALSE));}}

/* k2981 in k2968 in copy in k2947 in object-unevict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2983,2,av);}
a=C_alloc(4);
t2=C_copy_block(((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:586: hash-table-set! */
t4=*((C_word*)lf[90]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[2];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2984 in k2981 in k2968 in copy in k2947 in object-unevict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2986(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2986,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* tagged-pointer? in k1154 in k1151 */
static void C_ccall f_2003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +0,c,1))){
C_save_and_reclaim((void*)f_2003,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+0);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
if(C_truep(C_blockp(t2))){
if(C_truep(C_taggedpointerp(t2))){
t6=C_i_not(t5);
if(C_truep(t6)){
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_slot(t2,C_fix(1));
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_i_equalp(t5,t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}
else{
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k2266 in procedure-data in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2268(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2268,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=(C_truep(t1)?C_slot(t1,C_fix(1)):C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1264 in number-of-slots in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_1266(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,5))){
C_save_and_reclaim_args((void *)trf_1266,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=C_u_i_car(((C_word*)t0)[3]);
/* lolevel.scm:108: ##sys#signal-hook */
t3=*((C_word*)lf[3]+1);{
C_word av2[6];
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[4];
av2[3]=t2;
av2[4]=lf[76];
av2[5]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}
else{
/* lolevel.scm:108: ##sys#signal-hook */
t2=*((C_word*)lf[3]+1);{
C_word av2[6];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=lf[76];
av2[5]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}}}

/* k2968 in copy in k2947 in object-unevict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2970(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2970,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_byteblockp(((C_word*)t0)[3]))){
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2983,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[3]);
/* lolevel.scm:585: ##sys#make-string */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[110]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[110]+1);
av2[1]=t2;
av2[2]=t3;
tp(3,av2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(1));
/* lolevel.scm:590: ##sys#intern-symbol */{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t2;
av2[2]=t3;
C_string_to_symbol(3,av2);}}
else{
t2=C_block_size(((C_word*)t0)[3]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm:595: ##sys#make-vector */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[17]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[17]+1);
av2[1]=t4;
av2[2]=t3;
tp(3,av2);}}}}}

/* pointer-tag in k1154 in k1151 */
static void C_ccall f_2034(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2034,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2046,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=t2;
if(C_truep(C_blockp(t4))){
t5=C_specialp(t4);
t6=t3;
f_2046(t6,t5);}
else{
t5=t3;
f_2046(t5,C_SCHEME_FALSE);}}

/* a2250 in procedure-data in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2251(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2251,3,av);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_eqp(lf[62],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1232 in check-generic-structure in k1154 in k1151 */
static void C_fcall f_1234(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,5))){
C_save_and_reclaim_args((void *)trf_1234,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
/* lolevel.scm:100: ##sys#signal-hook */
t4=*((C_word*)lf[3]+1);{
C_word av2[6];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[4];
av2[3]=t3;
av2[4]=lf[5];
av2[5]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}
else{
/* lolevel.scm:100: ##sys#signal-hook */
t2=*((C_word*)lf[3]+1);{
C_word av2[6];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=lf[5];
av2[5]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}}}

/* k2629 in evict in k2611 in k2608 in k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2631(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_2631,2,av);}
a=C_alloc(12);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_block_size(((C_word*)t0)[3]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2746,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[3]))){
/* lolevel.scm:517: align-to-word */
t6=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=C_bytes(t3);
t7=C_bytes(C_fix(1));
t8=t4;
f_2640(t8,C_fixnum_plus(t6,t7));}}}

/* k2278 in set-procedure-data! in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2280(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_2280,2,av);}
t2=C_eqp(t1,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* lolevel.scm:399: ##sys#signal-hook */
t3=*((C_word*)lf[3]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[4];
av2[3]=lf[69];
av2[4]=lf[70];
av2[5]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}}

/* pointer-vector in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3170(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_3170,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=t2;
t4=C_u_i_length(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3175,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:641: make-pointer-vector */
t6=*((C_word*)lf[116]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k3173 in pointer-vector in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3175(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_3175,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_slot(t2,C_fix(2));
t4=t3;
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3183,a[2]=t2,a[3]=t4,a[4]=t6,a[5]=((C_word)li81),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3183(t8,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* k2826 in doloop687 in release in k2766 in object-release in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2828(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2828,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2818(t3,((C_word*)t0)[4],t2);}

/* set-procedure-data! in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2276(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_2276,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2280,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:396: extend-procedure */
t5=*((C_word*)lf[63]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k3117 in make-pointer-vector in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3119(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_3119,2,av);}
a=C_alloc(6);
t2=t1;
t3=C_eqp(((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record3(&a,3,lf[117],((C_word*)t0)[5],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3131,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* lolevel.scm:630: ##sys#check-pointer */
t5=*((C_word*)lf[6]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[116];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_3131(2,av2);}}}}

/* k3194 in doloop798 in k3173 in pointer-vector in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3196(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3196,2,av);}
t2=f_3257(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);
t3=((C_word*)t0)[5];
t4=C_u_i_cdr(t3);
t5=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[6])[1];
f_3183(t6,((C_word*)t0)[7],t4,t5);}

/* doloop811 in k3215 in pointer-vector-fill! in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static C_word C_fcall f_3228(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:{}
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
t2=C_SCHEME_UNDEFINED;
return(t2);}
else{
t2=f_3257(((C_word*)t0)[3],t1,((C_word*)t0)[4]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* object-size in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2856(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2856,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2860,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:561: make-hash-table */
t4=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[94]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* ##sys#check-generic-structure in k1154 in k1151 */
static void C_fcall f_1222(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1222,3,t1,t2,t3);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1234,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
if(C_truep(C_blockp(t5))){
t6=C_structurep(t5);
t7=t4;
f_1234(t7,t6);}
else{
t6=t4;
f_1234(t6,C_SCHEME_FALSE);}}

/* doloop746 in k3014 in k3011 in k2968 in copy in k2947 in object-unevict in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_3025(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3025,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm:599: copy */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2954(t5,t3,t4);}}

/* object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2600(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +6,c,3))){
C_save_and_reclaim((void*)f_2600,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+6);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2604,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm:503: ##sys#check-special */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[27]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[27]+1);
av2[1]=t5;
av2[2]=t3;
av2[3]=lf[95];
tp(4,av2);}}

/* k2605 in k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_fcall f_2607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,2))){
C_save_and_reclaim_args((void *)trf_2607,2,t0,t1);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2755,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:508: ##sys#pointer->address */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[26]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[26]+1);
av2[1]=t5;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}

/* k2602 in object-evict-to-location in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2604,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t3=((C_word*)t0)[5];
t4=C_u_i_car(t3);
t5=C_i_check_exact_2(t4,lf[95]);
t6=t2;
f_2607(t6,t4);}
else{
t3=t2;
f_2607(t3,C_SCHEME_FALSE);}}

/* pointer-vector? in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_3164(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3164,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[117]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* vector-like? in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2291(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2291,3,av);}
if(C_truep(C_blockp(t2))){
t3=C_specialp(t2);
if(C_truep(t3)){
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_i_not(t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_byteblockp(t2);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_i_not(t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* f_2846 in object-release in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static void C_ccall f_2846(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2846,3,av);}
if(C_truep(t2)){
t3=C_i_foreign_pointer_argumentp(t2);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=stub675(C_SCHEME_UNDEFINED,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=stub675(C_SCHEME_UNDEFINED,C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* doloop783 in k3129 in k3117 in make-pointer-vector in k2437 in k2310 in k2158 in k2154 in k2150 in k2146 in k2142 in k2138 in k2134 in k2130 in k2093 in k1154 in k1151 */
static C_word C_fcall f_3136(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;
loop:{}
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[2]))){
t2=C_SCHEME_UNDEFINED;
return(t2);}
else{
t2=f_3257(((C_word*)t0)[3],t1,((C_word*)t0)[4]);
t3=C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[230] = {
{"f_2878:lolevel_2escm",(void*)f_2878},
{"f_2703:lolevel_2escm",(void*)f_2703},
{"f_3131:lolevel_2escm",(void*)f_3131},
{"f_3046:lolevel_2escm",(void*)f_3046},
{"f_2621:lolevel_2escm",(void*)f_2621},
{"f_2090:lolevel_2escm",(void*)f_2090},
{"f_2097:lolevel_2escm",(void*)f_2097},
{"f_2095:lolevel_2escm",(void*)f_2095},
{"f_2773:lolevel_2escm",(void*)f_2773},
{"f_1205:lolevel_2escm",(void*)f_1205},
{"f_1208:lolevel_2escm",(void*)f_1208},
{"f_2613:lolevel_2escm",(void*)f_2613},
{"f_2610:lolevel_2escm",(void*)f_2610},
{"f_2616:lolevel_2escm",(void*)f_2616},
{"f_2818:lolevel_2escm",(void*)f_2818},
{"f_2768:lolevel_2escm",(void*)f_2768},
{"f_2764:lolevel_2escm",(void*)f_2764},
{"f_2802:lolevel_2escm",(void*)f_2802},
{"f_2809:lolevel_2escm",(void*)f_2809},
{"f_2201:lolevel_2escm",(void*)f_2201},
{"f_3002:lolevel_2escm",(void*)f_3002},
{"f_2730:lolevel_2escm",(void*)f_2730},
{"f_1469:lolevel_2escm",(void*)f_1469},
{"f_3217:lolevel_2escm",(void*)f_3217},
{"f_2734:lolevel_2escm",(void*)f_2734},
{"f_2738:lolevel_2escm",(void*)f_2738},
{"f_3016:lolevel_2escm",(void*)f_3016},
{"f_3019:lolevel_2escm",(void*)f_3019},
{"f_3210:lolevel_2escm",(void*)f_3210},
{"f_3013:lolevel_2escm",(void*)f_3013},
{"f_3183:lolevel_2escm",(void*)f_3183},
{"f_1476:lolevel_2escm",(void*)f_1476},
{"f_2074:lolevel_2escm",(void*)f_2074},
{"f_2218:lolevel_2escm",(void*)f_2218},
{"f_1453:lolevel_2escm",(void*)f_1453},
{"f_2860:lolevel_2escm",(void*)f_2860},
{"f3721:lolevel_2escm",(void*)f3721},
{"f_2865:lolevel_2escm",(void*)f_2865},
{"f_3103:lolevel_2escm",(void*)f_3103},
{"f_1420:lolevel_2escm",(void*)f_1420},
{"f_2897:lolevel_2escm",(void*)f_2897},
{"f_2899:lolevel_2escm",(void*)f_2899},
{"f_2890:lolevel_2escm",(void*)f_2890},
{"f_2884:lolevel_2escm",(void*)f_2884},
{"f_2887:lolevel_2escm",(void*)f_2887},
{"f_2755:lolevel_2escm",(void*)f_2755},
{"f_2746:lolevel_2escm",(void*)f_2746},
{"f_2451:lolevel_2escm",(void*)f_2451},
{"f_2456:lolevel_2escm",(void*)f_2456},
{"f_1579:lolevel_2escm",(void*)f_1579},
{"f_2482:lolevel_2escm",(void*)f_2482},
{"f_2489:lolevel_2escm",(void*)f_2489},
{"f_2370:lolevel_2escm",(void*)f_2370},
{"f_2486:lolevel_2escm",(void*)f_2486},
{"f_2479:lolevel_2escm",(void*)f_2479},
{"f_1510:lolevel_2escm",(void*)f_1510},
{"f_1447:lolevel_2escm",(void*)f_1447},
{"f_2420:lolevel_2escm",(void*)f_2420},
{"f_2355:lolevel_2escm",(void*)f_2355},
{"f_1441:lolevel_2escm",(void*)f_1441},
{"f_2413:lolevel_2escm",(void*)f_2413},
{"f_2417:lolevel_2escm",(void*)f_2417},
{"f_2445:lolevel_2escm",(void*)f_2445},
{"f_2441:lolevel_2escm",(void*)f_2441},
{"f_1502:lolevel_2escm",(void*)f_1502},
{"f_1505:lolevel_2escm",(void*)f_1505},
{"f_2439:lolevel_2escm",(void*)f_2439},
{"f_2314:lolevel_2escm",(void*)f_2314},
{"f_2312:lolevel_2escm",(void*)f_2312},
{"f_2318:lolevel_2escm",(void*)f_2318},
{"f_2346:lolevel_2escm",(void*)f_2346},
{"f_2559:lolevel_2escm",(void*)f_2559},
{"f_2058:lolevel_2escm",(void*)f_2058},
{"toplevel:lolevel_2escm",(void*)C_lolevel_toplevel},
{"f_2404:lolevel_2escm",(void*)f_2404},
{"f_2400:lolevel_2escm",(void*)f_2400},
{"f_2046:lolevel_2escm",(void*)f_2046},
{"f_1185:lolevel_2escm",(void*)f_1185},
{"f_2323:lolevel_2escm",(void*)f_2323},
{"f_2538:lolevel_2escm",(void*)f_2538},
{"f_2536:lolevel_2escm",(void*)f_2536},
{"f_2115:lolevel_2escm",(void*)f_2115},
{"f_2112:lolevel_2escm",(void*)f_2112},
{"f_2118:lolevel_2escm",(void*)f_2118},
{"f_2523:lolevel_2escm",(void*)f_2523},
{"f_2526:lolevel_2escm",(void*)f_2526},
{"f_2529:lolevel_2escm",(void*)f_2529},
{"f_2520:lolevel_2escm",(void*)f_2520},
{"f_2109:lolevel_2escm",(void*)f_2109},
{"f_2106:lolevel_2escm",(void*)f_2106},
{"f_2100:lolevel_2escm",(void*)f_2100},
{"f_2516:lolevel_2escm",(void*)f_2516},
{"f_1845:lolevel_2escm",(void*)f_1845},
{"f_1852:lolevel_2escm",(void*)f_1852},
{"f_2191:lolevel_2escm",(void*)f_2191},
{"f_1923:lolevel_2escm",(void*)f_1923},
{"f_1920:lolevel_2escm",(void*)f_1920},
{"f_1925:lolevel_2escm",(void*)f_1925},
{"f_1835:lolevel_2escm",(void*)f_1835},
{"f_2170:lolevel_2escm",(void*)f_2170},
{"f_1802:lolevel_2escm",(void*)f_1802},
{"f_2175:lolevel_2escm",(void*)f_2175},
{"f_3302:lolevel_2escm",(void*)f_3302},
{"f_3304:lolevel_2escm",(void*)f_3304},
{"f_1945:lolevel_2escm",(void*)f_1945},
{"f_2507:lolevel_2escm",(void*)f_2507},
{"f_2160:lolevel_2escm",(void*)f_2160},
{"f_3313:lolevel_2escm",(void*)f_3313},
{"f_1814:lolevel_2escm",(void*)f_1814},
{"f_2166:lolevel_2escm",(void*)f_2166},
{"f_3323:lolevel_2escm",(void*)f_3323},
{"f_1499:lolevel_2escm",(void*)f_1499},
{"f_1496:lolevel_2escm",(void*)f_1496},
{"f_3271:lolevel_2escm",(void*)f_3271},
{"f_1910:lolevel_2escm",(void*)f_1910},
{"f_1914:lolevel_2escm",(void*)f_1914},
{"f_1916:lolevel_2escm",(void*)f_1916},
{"f_1611:lolevel_2escm",(void*)f_1611},
{"f_1763:lolevel_2escm",(void*)f_1763},
{"f_1769:lolevel_2escm",(void*)f_1769},
{"f_1595:lolevel_2escm",(void*)f_1595},
{"f_3281:lolevel_2escm",(void*)f_3281},
{"f_3284:lolevel_2escm",(void*)f_3284},
{"f_1666:lolevel_2escm",(void*)f_1666},
{"f_3378:lolevel_2escm",(void*)f_3378},
{"f_3372:lolevel_2escm",(void*)f_3372},
{"f_1673:lolevel_2escm",(void*)f_1673},
{"f_3375:lolevel_2escm",(void*)f_3375},
{"f_2492:lolevel_2escm",(void*)f_2492},
{"f_2497:lolevel_2escm",(void*)f_2497},
{"f_1881:lolevel_2escm",(void*)f_1881},
{"f_1885:lolevel_2escm",(void*)f_1885},
{"f_3381:lolevel_2escm",(void*)f_3381},
{"f_1899:lolevel_2escm",(void*)f_1899},
{"f_1644:lolevel_2escm",(void*)f_1644},
{"f_1799:lolevel_2escm",(void*)f_1799},
{"f_1890:lolevel_2escm",(void*)f_1890},
{"f_1894:lolevel_2escm",(void*)f_1894},
{"f_2954:lolevel_2escm",(void*)f_2954},
{"f_2942:lolevel_2escm",(void*)f_2942},
{"f_2949:lolevel_2escm",(void*)f_2949},
{"f_1862:lolevel_2escm",(void*)f_1862},
{"f_1153:lolevel_2escm",(void*)f_1153},
{"f_1966:lolevel_2escm",(void*)f_1966},
{"f_1621:lolevel_2escm",(void*)f_1621},
{"f_1625:lolevel_2escm",(void*)f_1625},
{"f_2391:lolevel_2escm",(void*)f_2391},
{"f_2395:lolevel_2escm",(void*)f_2395},
{"f_1158:lolevel_2escm",(void*)f_1158},
{"f_1156:lolevel_2escm",(void*)f_1156},
{"f_2935:lolevel_2escm",(void*)f_2935},
{"f_3069:lolevel_2escm",(void*)f_3069},
{"f_1870:lolevel_2escm",(void*)f_1870},
{"f_3336:lolevel_2escm",(void*)f_3336},
{"f_3060:lolevel_2escm",(void*)f_3060},
{"f_3064:lolevel_2escm",(void*)f_3064},
{"f_1977:lolevel_2escm",(void*)f_1977},
{"f_2921:lolevel_2escm",(void*)f_2921},
{"f_3076:lolevel_2escm",(void*)f_3076},
{"f_1982:lolevel_2escm",(void*)f_1982},
{"f_3343:lolevel_2escm",(void*)f_3343},
{"f_3073:lolevel_2escm",(void*)f_3073},
{"f_1602:lolevel_2escm",(void*)f_1602},
{"f_3340:lolevel_2escm",(void*)f_3340},
{"f_1986:lolevel_2escm",(void*)f_1986},
{"f_1989:lolevel_2escm",(void*)f_1989},
{"f_3086:lolevel_2escm",(void*)f_3086},
{"f_1693:lolevel_2escm",(void*)f_1693},
{"f_3083:lolevel_2escm",(void*)f_3083},
{"f_1997:lolevel_2escm",(void*)f_1997},
{"f_3098:lolevel_2escm",(void*)f_3098},
{"f_3369:lolevel_2escm",(void*)f_3369},
{"f_3366:lolevel_2escm",(void*)f_3366},
{"f_3363:lolevel_2escm",(void*)f_3363},
{"f_3360:lolevel_2escm",(void*)f_3360},
{"f_2640:lolevel_2escm",(void*)f_2640},
{"f_2649:lolevel_2escm",(void*)f_2649},
{"f_2646:lolevel_2escm",(void*)f_2646},
{"f_2643:lolevel_2escm",(void*)f_2643},
{"f_2593:lolevel_2escm",(void*)f_2593},
{"f_2662:lolevel_2escm",(void*)f_2662},
{"f_2664:lolevel_2escm",(void*)f_2664},
{"f_2156:lolevel_2escm",(void*)f_2156},
{"f_2152:lolevel_2escm",(void*)f_2152},
{"f_2652:lolevel_2escm",(void*)f_2652},
{"f_2655:lolevel_2escm",(void*)f_2655},
{"f_2148:lolevel_2escm",(void*)f_2148},
{"f_2144:lolevel_2escm",(void*)f_2144},
{"f_2140:lolevel_2escm",(void*)f_2140},
{"f_2685:lolevel_2escm",(void*)f_2685},
{"f_2136:lolevel_2escm",(void*)f_2136},
{"f_2132:lolevel_2escm",(void*)f_2132},
{"f_1683:lolevel_2escm",(void*)f_1683},
{"f_1279:lolevel_2escm",(void*)f_1279},
{"f_2999:lolevel_2escm",(void*)f_2999},
{"f_2127:lolevel_2escm",(void*)f_2127},
{"f_2121:lolevel_2escm",(void*)f_2121},
{"f_2124:lolevel_2escm",(void*)f_2124},
{"f_2235:lolevel_2escm",(void*)f_2235},
{"f_2237:lolevel_2escm",(void*)f_2237},
{"f_3257:lolevel_2escm",(void*)f_3257},
{"f_2983:lolevel_2escm",(void*)f_2983},
{"f_2986:lolevel_2escm",(void*)f_2986},
{"f_2003:lolevel_2escm",(void*)f_2003},
{"f_2268:lolevel_2escm",(void*)f_2268},
{"f_1266:lolevel_2escm",(void*)f_1266},
{"f_2970:lolevel_2escm",(void*)f_2970},
{"f_2034:lolevel_2escm",(void*)f_2034},
{"f_2251:lolevel_2escm",(void*)f_2251},
{"f_1234:lolevel_2escm",(void*)f_1234},
{"f_2631:lolevel_2escm",(void*)f_2631},
{"f_2280:lolevel_2escm",(void*)f_2280},
{"f_3170:lolevel_2escm",(void*)f_3170},
{"f_3175:lolevel_2escm",(void*)f_3175},
{"f_2828:lolevel_2escm",(void*)f_2828},
{"f_2276:lolevel_2escm",(void*)f_2276},
{"f_3119:lolevel_2escm",(void*)f_3119},
{"f_3196:lolevel_2escm",(void*)f_3196},
{"f_3228:lolevel_2escm",(void*)f_3228},
{"f_2856:lolevel_2escm",(void*)f_2856},
{"f_1222:lolevel_2escm",(void*)f_1222},
{"f_3025:lolevel_2escm",(void*)f_3025},
{"f_2600:lolevel_2escm",(void*)f_2600},
{"f_2607:lolevel_2escm",(void*)f_2607},
{"f_2604:lolevel_2escm",(void*)f_2604},
{"f_3164:lolevel_2escm",(void*)f_3164},
{"f_2291:lolevel_2escm",(void*)f_2291},
{"f_2846:lolevel_2escm",(void*)f_2846},
{"f_3136:lolevel_2escm",(void*)f_3136},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|eliminated procedure checks: 95 
o|specializations:
o|  1 (length list)
o|  3 (cdr pair)
o|  9 (car pair)
(o e)|safe calls: 272 
o|Removed `not' forms: 9 
o|merged explicitly consed rest parameter: loc65 
o|inlining procedure: k1160 
o|inlining procedure: k1160 
o|inlining procedure: k1168 
o|inlining procedure: k1168 
o|merged explicitly consed rest parameter: loc88 
o|inlining procedure: k1224 
o|inlining procedure: k1224 
o|inlining procedure: k1239 
o|inlining procedure: k1239 
o|contracted procedure: "(lolevel.scm:99) g8990" 
o|inlining procedure: k1229 
o|inlining procedure: k1229 
o|inlining procedure: k1281 
o|inlining procedure: k1281 
o|inlining procedure: k1294 
o|inlining procedure: k1294 
o|contracted procedure: "(lolevel.scm:113) g108109" 
o|merged explicitly consed rest parameter: args210 
o|inlining procedure: k1455 
o|inlining procedure: k1455 
o|consed rest parameter at call site: "(lolevel.scm:145) sizerr207" 1 
o|inlining procedure: k1471 
o|inlining procedure: k1471 
o|consed rest parameter at call site: "(lolevel.scm:150) sizerr207" 1 
o|inlining procedure: k1512 
o|inlining procedure: "(lolevel.scm:162) typerr118" 
o|inlining procedure: k1512 
o|inlining procedure: k1544 
o|inlining procedure: k1544 
o|inlining procedure: "(lolevel.scm:166) typerr118" 
o|inlining procedure: k1564 
o|contracted procedure: "(lolevel.scm:169) memmove1114" 
o|inlining procedure: k1606 
o|contracted procedure: "(lolevel.scm:171) memmove3116" 
o|inlining procedure: k1606 
o|inlining procedure: "(lolevel.scm:173) typerr118" 
o|contracted procedure: "(lolevel.scm:168) g240241" 
o|inlining procedure: k1590 
o|inlining procedure: k1590 
o|contracted procedure: "(lolevel.scm:58) g246247" 
o|inlining procedure: k1564 
o|inlining procedure: k1651 
o|contracted procedure: "(lolevel.scm:177) memmove2115" 
o|inlining procedure: k1675 
o|inlining procedure: k1675 
o|inlining procedure: k1651 
o|contracted procedure: "(lolevel.scm:179) memmove4117" 
o|inlining procedure: "(lolevel.scm:182) typerr118" 
o|contracted procedure: "(lolevel.scm:176) g266267" 
o|inlining procedure: k1661 
o|inlining procedure: k1661 
o|contracted procedure: "(lolevel.scm:58) g272273" 
o|inlining procedure: "(lolevel.scm:184) typerr118" 
o|contracted procedure: "(lolevel.scm:167) g227228" 
o|inlining procedure: k1574 
o|inlining procedure: k1574 
o|contracted procedure: "(lolevel.scm:58) g233234" 
o|consed rest parameter at call site: "(lolevel.scm:153) check-block" 2 
o|consed rest parameter at call site: "(lolevel.scm:152) check-block" 2 
o|contracted procedure: k1774 
o|inlining procedure: k1771 
o|inlining procedure: k1800 
o|inlining procedure: k1800 
o|inlining procedure: k1816 
o|inlining procedure: k1816 
o|inlining procedure: k1771 
o|inlining procedure: k1855 
o|inlining procedure: k1855 
o|contracted procedure: "(lolevel.scm:209) g329330" 
o|contracted procedure: "(lolevel.scm:211) g334335" 
o|inlining procedure: k1874 
o|inlining procedure: k1874 
o|inlining procedure: k1901 
o|contracted procedure: "(lolevel.scm:221) g347348" 
o|inlining procedure: k1901 
o|inlining procedure: k1947 
o|inlining procedure: k1947 
o|contracted procedure: "(lolevel.scm:243) g384385" 
o|inlining procedure: k1961 
o|inlining procedure: k1961 
o|inlining procedure: k1987 
o|inlining procedure: k1987 
o|contracted procedure: "(lolevel.scm:255) g392393" 
o|inlining procedure: k1992 
o|inlining procedure: k1992 
o|inlining procedure: k2008 
o|inlining procedure: k2017 
o|inlining procedure: k2017 
o|inlining procedure: k2008 
o|inlining procedure: k2036 
o|inlining procedure: k2036 
o|contracted procedure: "(lolevel.scm:266) g418419" 
o|inlining procedure: k2041 
o|inlining procedure: k2041 
o|inlining procedure: k2064 
o|inlining procedure: k2064 
o|inlining procedure: k2080 
o|inlining procedure: k2080 
o|inlining procedure: k2102 
o|inlining procedure: k2102 
o|inlining procedure: k2177 
o|inlining procedure: k2177 
o|inlining procedure: k2203 
o|inlining procedure: k2209 
o|inlining procedure: k2209 
o|contracted procedure: "(lolevel.scm:386) g502503" 
o|inlining procedure: k2220 
o|inlining procedure: k2220 
o|inlining procedure: k2203 
o|inlining procedure: k2239 
o|inlining procedure: k2269 
o|inlining procedure: k2269 
o|contracted procedure: "(lolevel.scm:391) g512513" 
o|inlining procedure: k2253 
o|inlining procedure: k2253 
o|inlining procedure: k2239 
o|inlining procedure: k2281 
o|inlining procedure: k2281 
o|contracted procedure: "(lolevel.scm:406) g523524" 
o|inlining procedure: k2295 
o|inlining procedure: k2302 
o|inlining procedure: k2302 
o|inlining procedure: k2295 
o|contracted procedure: "(lolevel.scm:415) check-generic-vector" 
o|inlining procedure: k1249 
o|inlining procedure: k1249 
o|inlining procedure: k1271 
o|inlining procedure: k1271 
o|contracted procedure: "(lolevel.scm:107) g9798" 
o|inlining procedure: k1254 
o|inlining procedure: k1261 
o|inlining procedure: k1261 
o|inlining procedure: k1254 
o|contracted procedure: k2328 
o|inlining procedure: k2325 
o|inlining procedure: k2325 
o|inlining procedure: k2360 
o|inlining procedure: k2360 
o|contracted procedure: "(lolevel.scm:441) g559560" 
o|inlining procedure: k2365 
o|inlining procedure: k2365 
o|consed rest parameter at call site: "(lolevel.scm:446) check-generic-structure" 2 
o|consed rest parameter at call site: "(lolevel.scm:450) check-generic-structure" 2 
o|consed rest parameter at call site: "(lolevel.scm:454) check-generic-structure" 2 
o|inlining procedure: k2458 
o|inlining procedure: k2458 
o|consed rest parameter at call site: "(lolevel.scm:468) check-generic-structure" 2 
o|contracted procedure: k2502 
o|inlining procedure: k2499 
o|inlining procedure: k2527 
o|inlining procedure: k2527 
o|inlining procedure: k2540 
o|inlining procedure: k2540 
o|inlining procedure: k2564 
o|inlining procedure: k2564 
o|inlining procedure: k2499 
o|contracted procedure: k2626 
o|inlining procedure: k2623 
o|inlining procedure: k2653 
o|inlining procedure: k2653 
o|inlining procedure: k2666 
o|inlining procedure: k2666 
o|inlining procedure: k2690 
o|inlining procedure: k2690 
o|inlining procedure: k2718 
o|inlining procedure: k2718 
o|inlining procedure: k2744 
o|inlining procedure: k2744 
o|inlining procedure: k2623 
o|contracted procedure: k2778 
o|inlining procedure: k2775 
o|contracted procedure: k2784 
o|inlining procedure: k2787 
o|inlining procedure: k2787 
o|inlining procedure: k2820 
o|inlining procedure: k2820 
o|inlining procedure: k2775 
o|inlining procedure: k2849 
o|inlining procedure: k2849 
o|contracted procedure: k2870 
o|inlining procedure: k2867 
o|inlining procedure: k2888 
o|inlining procedure: k2888 
o|inlining procedure: k2901 
o|inlining procedure: k2901 
o|inlining procedure: k2926 
o|inlining procedure: k2926 
o|inlining procedure: k2933 
o|inlining procedure: k2933 
o|inlining procedure: k2867 
o|contracted procedure: k2959 
o|inlining procedure: k2956 
o|contracted procedure: k2965 
o|inlining procedure: k2971 
o|inlining procedure: k2971 
o|inlining procedure: k2977 
o|inlining procedure: k2977 
o|inlining procedure: k2991 
o|inlining procedure: k2991 
o|inlining procedure: k3027 
o|inlining procedure: k3027 
o|inlining procedure: k2956 
o|contracted procedure: "(lolevel.scm:606) check-become-alist" 
o|inlining procedure: k1190 
o|inlining procedure: k1190 
o|consed rest parameter at call site: "(lolevel.scm:91) check-block" 2 
o|consed rest parameter at call site: "(lolevel.scm:90) check-block" 2 
o|inlining procedure: k3138 
o|inlining procedure: k3138 
o|inlining procedure: k3185 
o|inlining procedure: k3185 
o|inlining procedure: k3230 
o|inlining procedure: k3230 
o|inlining procedure: k3264 
o|inlining procedure: k3264 
o|contracted procedure: "(lolevel.scm:680) pv-buf-ref" 
o|consed rest parameter at call site: "(lolevel.scm:461) check-generic-structure" 2 
o|replaced variables: 384 
o|removed binding forms: 208 
o|substituted constant variable: r11693388 
o|substituted constant variable: r11693388 
o|substituted constant variable: r12403394 
o|substituted constant variable: r12403394 
o|substituted constant variable: r12303397 
o|substituted constant variable: r12953402 
o|substituted constant variable: r12953402 
o|substituted constant variable: r18563468 
o|substituted constant variable: r18563468 
o|substituted constant variable: r18753471 
o|substituted constant variable: r19023473 
o|substituted constant variable: r19623477 
o|substituted constant variable: r19933483 
o|substituted constant variable: r20093487 
o|substituted constant variable: r20423491 
o|substituted constant variable: r20653492 
o|substituted constant variable: r20653492 
o|substituted constant variable: r20813496 
o|substituted constant variable: r20813496 
o|substituted constant variable: r21033501 
o|substituted constant variable: r21783503 
o|substituted constant variable: r22103505 
o|substituted constant variable: r22103506 
o|substituted constant variable: r22213508 
o|substituted constant variable: r22043509 
o|substituted constant variable: r22703512 
o|substituted constant variable: r22543514 
o|substituted constant variable: r22403515 
o|substituted constant variable: r22963523 
o|substituted constant variable: r12723528 
o|substituted constant variable: r12723528 
o|substituted constant variable: r12553535 
o|substituted constant variable: r23613539 
o|substituted constant variable: r23663541 
o|substituted constant variable: r28503580 
o|substituted constant variable: r28503580 
o|substituted constant variable: r28683597 
o|substituted constant variable: loc70 
o|substituted constant variable: loc70 
o|substituted constant variable: loc70 
o|substituted constant variable: loc70 
o|substituted constant variable: loc70 
o|inlining procedure: k3120 
o|substituted constant variable: r32653618 
o|substituted constant variable: r32653618 
o|replaced variables: 63 
o|removed binding forms: 362 
o|inlining procedure: k1587 
o|inlining procedure: k1658 
o|inlining procedure: k1571 
o|inlining procedure: k2800 
o|replaced variables: 21 
o|removed binding forms: 100 
o|contracted procedure: k1286 
o|simplifications: ((let . 10)) 
o|replaced variables: 3 
o|removed binding forms: 16 
o|replaced variables: 6 
o|removed binding forms: 3 
o|removed binding forms: 3 
o|simplifications: ((if . 37) (##core#call . 226)) 
o|  call simplifications:
o|    vector
o|    ##sys#check-structure	4
o|    ##sys#structure?
o|    ##sys#fudge
o|    fx*
o|    ##sys#make-structure	2
o|    ##sys#check-list
o|    ##sys#check-pair
o|    ##sys#check-exact	4
o|    list	3
o|    +
o|    values
o|    void	2
o|    ##sys#setislot	4
o|    ##sys#check-symbol
o|    cons	3
o|    eq?	6
o|    not	6
o|    equal?
o|    integer?
o|    ##sys#foreign-integer-argument	2
o|    symbol?	8
o|    fx>=	9
o|    ##sys#setslot	5
o|    fx+	18
o|    ##sys#intern-symbol	2
o|    car	10
o|    null?	14
o|    cdr	3
o|    fx<	3
o|    ##sys#generic-structure?	2
o|    string?	3
o|    ##sys#size	18
o|    ##sys#foreign-block-argument	4
o|    ##sys#foreign-pointer-argument	8
o|    ##sys#foreign-fixnum-argument	16
o|    memq	3
o|    ##sys#slot	30
o|    fx-	7
o|    fx<=	3
o|    apply	2
o|    pair?	11
o|contracted procedure: k1171 
o|contracted procedure: k1242 
o|contracted procedure: k1297 
o|contracted procedure: k1756 
o|contracted procedure: k1422 
o|contracted procedure: k1750 
o|contracted procedure: k1425 
o|contracted procedure: k1744 
o|contracted procedure: k1428 
o|contracted procedure: k1738 
o|contracted procedure: k1431 
o|contracted procedure: k1732 
o|contracted procedure: k1434 
o|contracted procedure: k1726 
o|contracted procedure: k1437 
o|contracted procedure: k1465 
o|contracted procedure: k1458 
o|contracted procedure: k1491 
o|contracted procedure: k1480 
o|contracted procedure: k1487 
o|contracted procedure: k1515 
o|contracted procedure: k1535 
o|contracted procedure: k1521 
o|contracted procedure: k1528 
o|contracted procedure: k1541 
o|contracted procedure: k1561 
o|contracted procedure: k1547 
o|contracted procedure: k1554 
o|contracted procedure: k1305 
o|contracted procedure: k1309 
o|contracted procedure: k1313 
o|contracted procedure: k1317 
o|contracted procedure: k1321 
o|contracted procedure: k1612 
o|contracted procedure: k1361 
o|contracted procedure: k1365 
o|contracted procedure: k1369 
o|contracted procedure: k1373 
o|contracted procedure: k1377 
o|contracted procedure: k1627 
o|contracted procedure: k1645 
o|contracted procedure: k1648 
o|contracted procedure: k1333 
o|contracted procedure: k1337 
o|contracted procedure: k1341 
o|contracted procedure: k1345 
o|contracted procedure: k1349 
o|contracted procedure: k1684 
o|contracted procedure: k1389 
o|contracted procedure: k1393 
o|contracted procedure: k1397 
o|contracted procedure: k1401 
o|contracted procedure: k1405 
o|contracted procedure: k1695 
o|contracted procedure: k1699 
o|contracted procedure: k1714 
o|contracted procedure: k1720 
o|contracted procedure: k1780 
o|contracted procedure: k1787 
o|contracted procedure: k1790 
o|contracted procedure: k1793 
o|contracted procedure: k1803 
o|contracted procedure: k1810 
o|contracted procedure: k1819 
o|contracted procedure: k1822 
o|contracted procedure: k1829 
o|contracted procedure: k1837 
o|contracted procedure: k1848 
o|contracted procedure: k1855 
o|contracted procedure: k1928 
o|contracted procedure: k1932 
o|contracted procedure: k1942 
o|contracted procedure: k1950 
o|contracted procedure: k2027 
o|contracted procedure: k2005 
o|contracted procedure: k2014 
o|contracted procedure: k2024 
o|contracted procedure: k2067 
o|contracted procedure: k2064 
o|contracted procedure: k2083 
o|contracted procedure: k2080 
o|contracted procedure: k2162 
o|contracted procedure: k2180 
o|contracted procedure: k2187 
o|contracted procedure: k2197 
o|contracted procedure: k2193 
o|contracted procedure: k2223 
o|contracted procedure: k2230 
o|contracted procedure: k2256 
o|contracted procedure: k2263 
o|contracted procedure: k2284 
o|contracted procedure: k1274 
o|contracted procedure: k2341 
o|contracted procedure: k2348 
o|contracted procedure: k2384 
o|contracted procedure: k2357 
o|contracted procedure: k2371 
o|contracted procedure: k2381 
o|contracted procedure: k2409 
o|contracted procedure: k2425 
o|contracted procedure: k2433 
o|contracted procedure: k2429 
o|contracted procedure: k2446 
o|contracted procedure: k2461 
o|contracted procedure: k2475 
o|contracted procedure: k2464 
o|contracted procedure: k2471 
o|contracted procedure: k2511 
o|contracted procedure: k2543 
o|contracted procedure: k2546 
o|contracted procedure: k2553 
o|contracted procedure: k2561 
o|contracted procedure: k2564 
o|contracted procedure: k2570 
o|contracted procedure: k2577 
o|propagated global variable: r2578 ##sys#undefined-value 
o|contracted procedure: k2581 
o|contracted procedure: k2589 
o|contracted procedure: k2596 
o|contracted procedure: k2635 
o|contracted procedure: k2669 
o|contracted procedure: k2672 
o|contracted procedure: k2679 
o|contracted procedure: k2687 
o|contracted procedure: k2690 
o|contracted procedure: k2697 
o|contracted procedure: k2704 
o|contracted procedure: k2711 
o|propagated global variable: r2712 ##sys#undefined-value 
o|contracted procedure: k2715 
o|contracted procedure: k2721 
o|contracted procedure: k2740 
o|contracted procedure: k2756 
o|contracted procedure: k2760 
o|contracted procedure: k2790 
o|contracted procedure: k2793 
o|contracted procedure: k2797 
o|contracted procedure: k2814 
o|contracted procedure: k2823 
o|contracted procedure: k2833 
o|contracted procedure: k2837 
o|contracted procedure: k2842 
o|contracted procedure: k2849 
o|contracted procedure: k2879 
o|contracted procedure: k2904 
o|contracted procedure: k2908 
o|contracted procedure: k2915 
o|contracted procedure: k2923 
o|contracted procedure: k2926 
o|contracted procedure: k3053 
o|contracted procedure: k2944 
o|contracted procedure: k2988 
o|contracted procedure: k2994 
o|contracted procedure: k3004 
o|contracted procedure: k3007 
o|contracted procedure: k3021 
o|contracted procedure: k3030 
o|contracted procedure: k3033 
o|contracted procedure: k3040 
o|contracted procedure: k3048 
o|contracted procedure: k1178 
o|contracted procedure: k1187 
o|contracted procedure: k1196 
o|contracted procedure: k1200 
o|contracted procedure: k3077 
o|contracted procedure: k3092 
o|contracted procedure: k3088 
o|contracted procedure: k3100 
o|contracted procedure: k3157 
o|contracted procedure: k3105 
o|contracted procedure: k3108 
o|contracted procedure: k3111 
o|contracted procedure: k3114 
o|contracted procedure: k3126 
o|contracted procedure: k3141 
o|contracted procedure: k3151 
o|contracted procedure: k3176 
o|contracted procedure: k3188 
o|contracted procedure: k3191 
o|contracted procedure: k3206 
o|contracted procedure: k3212 
o|contracted procedure: k3218 
o|contracted procedure: k3221 
o|contracted procedure: k3233 
o|contracted procedure: k3243 
o|contracted procedure: k3260 
o|contracted procedure: k3264 
o|contracted procedure: k3273 
o|contracted procedure: k3276 
o|contracted procedure: k3289 
o|contracted procedure: k3296 
o|contracted procedure: k3306 
o|contracted procedure: k3315 
o|contracted procedure: k3318 
o|contracted procedure: k3328 
o|contracted procedure: k3253 
o|contracted procedure: k3332 
o|contracted procedure: k3348 
o|contracted procedure: k3356 
o|contracted procedure: k3352 
o|simplifications: ((let . 38)) 
o|removed binding forms: 198 
o|inlining procedure: k1623 
o|inlining procedure: "(lolevel.scm:242) align373" 
o|inlining procedure: "(lolevel.scm:244) align373" 
o|inlining procedure: k3282 
o|replaced variables: 65 
o|replaced variables: 4 
o|removed binding forms: 49 
o|inlining procedure: k1971 
o|removed binding forms: 4 
o|removed binding forms: 1 
o|direct leaf routine/allocation: doloop587588 0 
o|direct leaf routine/allocation: pv-buf-set! 0 
o|converted assignments to bindings: (doloop587588) 
o|contracted procedure: "(lolevel.scm:633) k3144" 
o|contracted procedure: "(lolevel.scm:648) k3197" 
o|contracted procedure: "(lolevel.scm:657) k3236" 
o|simplifications: ((let . 1)) 
o|removed binding forms: 3 
o|direct leaf routine/allocation: doloop783784 0 
o|direct leaf routine/allocation: doloop811812 0 
o|contracted procedure: k3120 
o|converted assignments to bindings: (doloop783784) 
o|converted assignments to bindings: (doloop811812) 
o|simplifications: ((let . 2)) 
o|removed binding forms: 1 
o|customizable procedures: (doloop798799 loop71 copy731 doloop746747 k2882 k2895 evict698 doloop706707 k2766 release680 doloop687688 k2605 k2638 k2644 k2660 evict641 doloop654655 k2484 k2521 k2534 evict605 doloop617618 ##sys#check-generic-structure k2368 k1264 k2044 k1995 k1964 copy295 doloop307308 ##sys#check-block k1577 k1664 checkn2209 k1593 checkn1208 nosizerr206 move220 k1474 sizerr207 k1232) 
o|calls to known targets: 98 
o|identified direct recursive calls: f_1510 2 
o|identified direct recursive calls: f_2456 1 
o|identified direct recursive calls: f_3136 1 
o|identified direct recursive calls: f_3228 1 
o|fast box initializations: 19 
o|fast global references: 18 
o|fast global assignments: 4 
o|dropping unused closure argument: f_1158 
o|dropping unused closure argument: f_3257 
o|dropping unused closure argument: f_1222 
*/
/* end of file */
