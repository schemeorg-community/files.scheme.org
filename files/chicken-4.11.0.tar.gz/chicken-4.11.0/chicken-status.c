/* Generated from chicken-status.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:51
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: chicken-status.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -local -no-trace -output-file chicken-status.c
   used units: library eval chicken_2dsyntax srfi_2d1 posix data_2dstructures utils ports irregex files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_srfi_2d1_toplevel)
C_externimport void C_ccall C_srfi_2d1_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_irregex_toplevel)
C_externimport void C_ccall C_irregex_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[103];
static double C_possibly_force_alignment;


C_noret_decl(f_1194)
static void C_fcall f_1194(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word *av) C_noret;
C_noret_decl(f2303)
static void C_ccall f2303(C_word c,C_word *av) C_noret;
C_noret_decl(f_952)
static void C_ccall f_952(C_word c,C_word *av) C_noret;
C_noret_decl(f2310)
static void C_ccall f2310(C_word c,C_word *av) C_noret;
C_noret_decl(f2315)
static void C_ccall f2315(C_word c,C_word *av) C_noret;
C_noret_decl(f_964)
static void C_ccall f_964(C_word c,C_word *av) C_noret;
C_noret_decl(f_1267)
static void C_ccall f_1267(C_word c,C_word *av) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897(C_word c,C_word *av) C_noret;
C_noret_decl(f_894)
static void C_ccall f_894(C_word c,C_word *av) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word *av) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word *av) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word *av) C_noret;
C_noret_decl(f_891)
static void C_ccall f_891(C_word c,C_word *av) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word *av) C_noret;
C_noret_decl(f_1063)
static void C_ccall f_1063(C_word c,C_word *av) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word *av) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word *av) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word *av) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word *av) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word *av) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word *av) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word *av) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word *av) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word *av) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word *av) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word *av) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word *av) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word *av) C_noret;
C_noret_decl(f_980)
static void C_ccall f_980(C_word c,C_word *av) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word *av) C_noret;
C_noret_decl(f_1026)
static void C_fcall f_1026(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1021)
static void C_ccall f_1021(C_word c,C_word *av) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036(C_word c,C_word *av) C_noret;
C_noret_decl(f_1038)
static void C_fcall f_1038(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_986)
static void C_ccall f_986(C_word c,C_word *av) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word *av) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word *av) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word *av) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word *av) C_noret;
C_noret_decl(f_1355)
static void C_fcall f_1355(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1643)
static void C_fcall f_1643(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word *av) C_noret;
C_noret_decl(f_1808)
static void C_ccall f_1808(C_word c,C_word *av) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word *av) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word *av) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word *av) C_noret;
C_noret_decl(f_1668)
static void C_ccall f_1668(C_word c,C_word *av) C_noret;
C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word *av) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word *av) C_noret;
C_noret_decl(f_1560)
static void C_fcall f_1560(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word *av) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word *av) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word *av) C_noret;
C_noret_decl(f_1427)
static void C_fcall f_1427(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word *av) C_noret;
C_noret_decl(f_1998)
static void C_fcall f_1998(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1701)
static void C_fcall f_1701(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1422)
static void C_ccall f_1422(C_word c,C_word *av) C_noret;
C_noret_decl(f_1531)
static void C_ccall f_1531(C_word c,C_word *av) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word *av) C_noret;
C_noret_decl(f_1604)
static void C_fcall f_1604(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word *av) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word *av) C_noret;
C_noret_decl(f_1845)
static void C_fcall f_1845(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word *av) C_noret;
C_noret_decl(f_1333)
static void C_ccall f_1333(C_word c,C_word *av) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word *av) C_noret;
C_noret_decl(f_1491)
static void C_ccall f_1491(C_word c,C_word *av) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word *av) C_noret;
C_noret_decl(f_1124)
static void C_fcall f_1124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word *av) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word *av) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word *av) C_noret;
C_noret_decl(f_1344)
static void C_ccall f_1344(C_word c,C_word *av) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word *av) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word *av) C_noret;
C_noret_decl(f_1521)
static void C_fcall f_1521(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f2298)
static void C_ccall f2298(C_word c,C_word *av) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word *av) C_noret;
C_noret_decl(f_1365)
static void C_ccall f_1365(C_word c,C_word *av) C_noret;
C_noret_decl(f_1744)
static void C_fcall f_1744(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1140)
static void C_fcall f_1140(C_word t0) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072(C_word c,C_word *av) C_noret;
C_noret_decl(f_1213)
static void C_ccall f_1213(C_word c,C_word *av) C_noret;
C_noret_decl(f_1152)
static void C_fcall f_1152(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word *av) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word *av) C_noret;
C_noret_decl(f_1384)
static void C_ccall f_1384(C_word c,C_word *av) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word *av) C_noret;
C_noret_decl(f_1769)
static void C_ccall f_1769(C_word c,C_word *av) C_noret;
C_noret_decl(f_1513)
static void C_ccall f_1513(C_word c,C_word *av) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word *av) C_noret;
C_noret_decl(f_1093)
static void C_ccall f_1093(C_word c,C_word *av) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word *av) C_noret;
C_noret_decl(f_1581)
static void C_ccall f_1581(C_word c,C_word *av) C_noret;
C_noret_decl(f_918)
static void C_ccall f_918(C_word c,C_word *av) C_noret;
C_noret_decl(f_1316)
static void C_ccall f_1316(C_word c,C_word *av) C_noret;
C_noret_decl(f_915)
static void C_ccall f_915(C_word c,C_word *av) C_noret;
C_noret_decl(f_912)
static void C_ccall f_912(C_word c,C_word *av) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word *av) C_noret;
C_noret_decl(f_1102)
static void C_fcall f_1102(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1100)
static void C_ccall f_1100(C_word c,C_word *av) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921(C_word c,C_word *av) C_noret;
C_noret_decl(f_925)
static void C_ccall f_925(C_word c,C_word *av) C_noret;
C_noret_decl(f_1112)
static void C_ccall f_1112(C_word c,C_word *av) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270(C_word c,C_word *av) C_noret;
C_noret_decl(f_1573)
static void C_fcall f_1573(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word *av) C_noret;
C_noret_decl(f_906)
static void C_ccall f_906(C_word c,C_word *av) C_noret;
C_noret_decl(f_909)
static void C_ccall f_909(C_word c,C_word *av) C_noret;
C_noret_decl(f_900)
static void C_ccall f_900(C_word c,C_word *av) C_noret;
C_noret_decl(f_903)
static void C_ccall f_903(C_word c,C_word *av) C_noret;
C_noret_decl(f_1287)
static void C_ccall f_1287(C_word c,C_word *av) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word *av) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word *av) C_noret;
C_noret_decl(f_2036)
static void C_fcall f_2036(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_974)
static void C_ccall f_974(C_word c,C_word *av) C_noret;
C_noret_decl(f_1298)
static void C_fcall f_1298(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word *av) C_noret;
C_noret_decl(f_1293)
static void C_ccall f_1293(C_word c,C_word *av) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word *av) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word *av) C_noret;
C_noret_decl(f_1177)
static void C_ccall f_1177(C_word c,C_word *av) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word *av) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word *av) C_noret;
C_noret_decl(f_1188)
static void C_ccall f_1188(C_word c,C_word *av) C_noret;
C_noret_decl(f_931)
static void C_fcall f_931(C_word t0) C_noret;
C_noret_decl(f_948)
static void C_ccall f_948(C_word c,C_word *av) C_noret;
C_noret_decl(f_1395)
static void C_fcall f_1395(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_961)
static void C_ccall f_961(C_word c,C_word *av) C_noret;

C_noret_decl(trf_1194)
static void C_ccall trf_1194(C_word c,C_word *av) C_noret;
static void C_ccall trf_1194(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_1194(t0,t1,t2,t3);}

C_noret_decl(trf_1026)
static void C_ccall trf_1026(C_word c,C_word *av) C_noret;
static void C_ccall trf_1026(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1026(t0,t1,t2);}

C_noret_decl(trf_1038)
static void C_ccall trf_1038(C_word c,C_word *av) C_noret;
static void C_ccall trf_1038(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1038(t0,t1,t2);}

C_noret_decl(trf_1355)
static void C_ccall trf_1355(C_word c,C_word *av) C_noret;
static void C_ccall trf_1355(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1355(t0,t1,t2);}

C_noret_decl(trf_1643)
static void C_ccall trf_1643(C_word c,C_word *av) C_noret;
static void C_ccall trf_1643(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1643(t0,t1,t2);}

C_noret_decl(trf_1560)
static void C_ccall trf_1560(C_word c,C_word *av) C_noret;
static void C_ccall trf_1560(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_1560(t0,t1,t2,t3);}

C_noret_decl(trf_1427)
static void C_ccall trf_1427(C_word c,C_word *av) C_noret;
static void C_ccall trf_1427(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1427(t0,t1,t2);}

C_noret_decl(trf_1998)
static void C_ccall trf_1998(C_word c,C_word *av) C_noret;
static void C_ccall trf_1998(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1998(t0,t1);}

C_noret_decl(trf_1701)
static void C_ccall trf_1701(C_word c,C_word *av) C_noret;
static void C_ccall trf_1701(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1701(t0,t1,t2);}

C_noret_decl(trf_1604)
static void C_ccall trf_1604(C_word c,C_word *av) C_noret;
static void C_ccall trf_1604(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1604(t0,t1);}

C_noret_decl(trf_1845)
static void C_ccall trf_1845(C_word c,C_word *av) C_noret;
static void C_ccall trf_1845(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1845(t0,t1);}

C_noret_decl(trf_1124)
static void C_ccall trf_1124(C_word c,C_word *av) C_noret;
static void C_ccall trf_1124(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1124(t0,t1);}

C_noret_decl(trf_1521)
static void C_ccall trf_1521(C_word c,C_word *av) C_noret;
static void C_ccall trf_1521(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1521(t0,t1,t2);}

C_noret_decl(trf_1744)
static void C_ccall trf_1744(C_word c,C_word *av) C_noret;
static void C_ccall trf_1744(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1744(t0,t1,t2);}

C_noret_decl(trf_1140)
static void C_ccall trf_1140(C_word c,C_word *av) C_noret;
static void C_ccall trf_1140(C_word c,C_word *av){
C_word t0=av[0];
f_1140(t0);}

C_noret_decl(trf_1152)
static void C_ccall trf_1152(C_word c,C_word *av) C_noret;
static void C_ccall trf_1152(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1152(t0,t1,t2);}

C_noret_decl(trf_1102)
static void C_ccall trf_1102(C_word c,C_word *av) C_noret;
static void C_ccall trf_1102(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_1102(t0,t1,t2,t3);}

C_noret_decl(trf_1573)
static void C_ccall trf_1573(C_word c,C_word *av) C_noret;
static void C_ccall trf_1573(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1573(t0,t1);}

C_noret_decl(trf_2036)
static void C_ccall trf_2036(C_word c,C_word *av) C_noret;
static void C_ccall trf_2036(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2036(t0,t1,t2);}

C_noret_decl(trf_1298)
static void C_ccall trf_1298(C_word c,C_word *av) C_noret;
static void C_ccall trf_1298(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1298(t0,t1,t2);}

C_noret_decl(trf_931)
static void C_ccall trf_931(C_word c,C_word *av) C_noret;
static void C_ccall trf_931(C_word c,C_word *av){
C_word t0=av[0];
f_931(t0);}

C_noret_decl(trf_1395)
static void C_ccall trf_1395(C_word c,C_word *av) C_noret;
static void C_ccall trf_1395(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1395(t0,t1,t2);}

/* main#format-string in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1194(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_1194,4,t1,t2,t3,t4);}
a=C_alloc(5);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_make_character(32):C_i_car(t9));
t12=C_i_nullp(t9);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t14=C_i_string_length(t2);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1213,a[2]=t7,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t16=C_fixnum_difference(t3,t14);
t17=C_i_fixnum_max(C_fix(0),t16);
/* chicken-status.scm:85: make-string */
t18=*((C_word*)lf[33]+1);{
C_word av2[4];
av2[0]=t18;
av2[1]=t15;
av2[2]=t17;
av2[3]=t11;
((C_proc)(void*)(*((C_word*)t18+1)))(4,av2);}}

/* k1190 in main#gather-all-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1192(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1192,2,av);}
/* chicken-status.scm:81: make-pathname */
t2=C_fast_retrieve(lf[7]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[29];
av2[4]=lf[30];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* f2303 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f2303(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f2303,2,av);}
/* chicken-status.scm:154: exit */
t2=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k950 in k946 in main#repo-path in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_952(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_952,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-status.scm:50: ##sys#print */
t6=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[10];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* f2310 in k2011 in k2005 in k1996 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f2310(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f2310,2,av);}
/* chicken-status.scm:154: exit */
t2=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* f2315 in k1996 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f2315(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f2315,2,av);}
/* chicken-status.scm:154: exit */
t2=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k962 in k959 in k956 in k950 in k946 in main#repo-path in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_964(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_964,2,av);}
/* chicken-status.scm:50: make-pathname */
t2=C_fast_retrieve(lf[7]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1265 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1267(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_1267,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1270,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1281,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1287,tmp=(C_word)a,a+=2,tmp);
/* chicken-status.scm:95: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t2;
av2[2]=t3;
av2[3]=t4;
C_call_with_values(4,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(80);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k895 in k892 in k889 */
static void C_ccall f_897(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_897,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_900,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_srfi_2d1_toplevel(2,av2);}}

/* k892 in k889 */
static void C_ccall f_894(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_894,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_897,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_chicken_2dsyntax_toplevel(2,av2);}}

/* k2005 in k1996 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_2007(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_2007,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2073,tmp=(C_word)a,a+=2,tmp);
/* chicken-status.scm:242: every */
t5=C_fast_retrieve(lf[93]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k956 in k950 in k946 in main#repo-path in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_958(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_958,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-status.scm:50: ##sys#print */
t3=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fix((C_word)C_BINARY_VERSION);
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2122 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_2124(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_2124,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2127,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2130,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[52]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[52]+1);
av2[1]=t3;
tp(2,av2);}}

/* k889 */
static void C_ccall f_891(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_891,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_894,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k2125 in k2122 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_2127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2127,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1061 in map-loop193 in k1012 in main#gather-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1063(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1063,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1038(t6,((C_word*)t0)[5],t5);}

/* a2072 in k2005 in k1996 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_2073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2073,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_memq(t2,lf[92]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_2134(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(17,c,4))){C_save_and_reclaim((void *)f_2134,2,av);}
a=C_alloc(17);
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1560,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t7,a[6]=t11,tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_1560(t13,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2128 in k2122 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_2130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2130,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* k1890 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_1892,2,av);}
a=C_alloc(10);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1908,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm:218: absolute-pathname? */
t6=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k1897 in k1890 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1899(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1899,2,av);}
t2=C_mutate2(&lf[3] /* (set! main#*prefix* ...) */,t1);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
/* chicken-status.scm:222: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1560(t6,((C_word*)t0)[4],t5,((C_word*)t0)[5]);}

/* k2079 in k1996 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_2081(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2081,2,av);}
/* string->list */
t2=C_fast_retrieve(lf[94]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a1003 in main#grep in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1004(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1004,3,av);}
t3=C_fast_retrieve(lf[16]);
/* chicken-status.scm:58: g186 */
t4=C_fast_retrieve(lf[16]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k1792 in k1789 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1794(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,c,4))){C_save_and_reclaim((void *)f_1794,2,av);}
a=C_alloc(15);
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1799,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1804,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1817,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm:196: ##sys#dynamic-wind */
t9=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t9;
av2[1]=((C_word*)t0)[3];
av2[2]=t6;
av2[3]=t7;
av2[4]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}

/* k1789 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1791(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1791,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm:195: status */
t3=((C_word*)t0)[2];
f_1604(t3,t2);}

/* k2018 in k2011 in k2005 in k1996 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_2020(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2020,2,av);}
/* chicken-status.scm:243: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1560(t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* a1798 in k1792 in k1789 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1799(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1799,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[1],"main#\052host-extensions\052"));
t3=C_mutate2(&lf[1] /* (set! main#*host-extensions* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1012 in main#gather-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1014(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(22,c,3))){C_save_and_reclaim((void *)f_1014,2,av);}
a=C_alloc(22);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1021,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1026,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t9=((C_word*)t0)[3];
t10=C_i_check_list_2(t9,lf[21]);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1036,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1038,a[2]=t6,a[3]=t13,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_1038(t15,t11,t9);}

/* main#gather-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1010(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1010,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1014,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm:61: gather-all-extensions */
f_1140(t3);}

/* k978 in k972 in main#repo-path in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_980(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_980,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_fudge(C_fix(42));
/* chicken-status.scm:54: ##sys#print */
t4=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k981 in k978 in k972 in main#repo-path in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_983,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_986,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:54: get-output-string */
t3=C_fast_retrieve(lf[8]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* g199 in k1012 in main#gather-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1026(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_1026,3,t0,t1,t2);}
t3=C_retrieve2(lf[15],"main#grep");
/* chicken-status.scm:63: g216 */
t4=C_retrieve2(lf[15],"main#grep");{
C_word av2[4];
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=((C_word*)t0)[2];
f_998(4,av2);}}

/* k1019 in k1012 in main#gather-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1021(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1021,2,av);}
/* chicken-status.scm:62: delete-duplicates */
t2=C_fast_retrieve(lf[19]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=*((C_word*)lf[20]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1034 in k1012 in main#gather-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1036(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1036,2,av);}
/* chicken-status.scm:63: concatenate */
t2=C_fast_retrieve(lf[22]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop193 in k1012 in main#gather-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1038(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_1038,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1063,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-status.scm:63: g199 */
t5=((C_word*)t0)[4];
f_1026(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k984 in k981 in k978 in k972 in main#repo-path in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_986(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_986,2,av);}
/* chicken-status.scm:52: make-pathname */
t2=C_fast_retrieve(lf[7]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[3],"main#\052prefix\052");
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1906 in k1890 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_1908,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
f_1899(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1915,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1919,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm:221: current-directory */
t4=C_fast_retrieve(lf[81]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* main#list-installed-files in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_1418,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1422,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1452,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1454,tmp=(C_word)a,a+=2,tmp);
/* chicken-status.scm:122: append-map */
t6=C_fast_retrieve(lf[51]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k1913 in k1906 in k1890 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1915(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1915,2,av);}
/* chicken-status.scm:220: normalize-pathname */
t2=C_fast_retrieve(lf[80]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1917 in k1906 in k1890 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1919(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1919,2,av);}
/* chicken-status.scm:221: make-pathname */
t2=C_fast_retrieve(lf[7]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* for-each-loop297 in k1345 in k1295 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1355(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1355,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1365,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-status.scm:101: g298 */
t5=((C_word*)t0)[3];
f_1298(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* map-loop413 in k1609 in status in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1643(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_1643,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1668,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-status.scm:178: g419 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1435 in for-each-loop337 in k1420 in main#list-installed-files in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1437(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1437,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1427(t3,((C_word*)t0)[4],t2);}

/* k1806 in a1803 in k1792 in k1789 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1808(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1808,2,av);}
/* chicken-status.scm:198: status */
t2=((C_word*)t0)[2];
f_1604(t2,((C_word*)t0)[3]);}

/* a1803 in k1792 in k1789 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1804(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_1804,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1815,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:197: repo-path */
f_931(t3);}

/* k1813 in a1803 in k1792 in k1789 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1815(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1815,2,av);}
/* chicken-status.scm:197: print */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[68];
av2[3]=t1;
av2[4]=lf[69];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a1816 in k1792 in k1789 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1817(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1817,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[1],"main#\052host-extensions\052"));
t3=C_mutate2(&lf[1] /* (set! main#*host-extensions* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1666 in map-loop413 in k1609 in status in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1668,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1643(t6,((C_word*)t0)[5],t5);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point

void C_ccall C_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(404)){
C_save(t1);
C_rereclaim2(404*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,103);
lf[6]=C_h_intern(&lf[6],7,"sprintf");
lf[7]=C_h_intern(&lf[7],13,"make-pathname");
lf[8]=C_h_intern(&lf[8],17,"get-output-string");
lf[9]=C_h_intern(&lf[9],9,"\003sysprint");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\010chicken/");
lf[11]=C_h_intern(&lf[11],18,"open-output-string");
lf[12]=C_h_intern(&lf[12],17,"\003syspeek-c-string");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[14]=C_h_intern(&lf[14],15,"repository-path");
lf[16]=C_h_intern(&lf[16],14,"irregex-search");
lf[17]=C_h_intern(&lf[17],6,"filter");
lf[19]=C_h_intern(&lf[19],17,"delete-duplicates");
lf[20]=C_h_intern(&lf[20],8,"string=\077");
lf[21]=C_h_intern(&lf[21],3,"map");
lf[22]=C_h_intern(&lf[22],11,"concatenate");
lf[25]=C_h_intern(&lf[25],8,"egg-name");
lf[26]=C_h_intern(&lf[26],19,"setup-api#read-info");
lf[27]=C_h_intern(&lf[27],13,"pathname-file");
lf[28]=C_h_intern(&lf[28],4,"glob");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[32]=C_h_intern(&lf[32],17,"\003sysstring-append");
lf[33]=C_h_intern(&lf[33],11,"make-string");
lf[35]=C_h_intern(&lf[35],7,"version");
lf[36]=C_h_intern(&lf[36],5,"print");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\012 version: ");
lf[38]=C_h_intern(&lf[38],8,"->string");
lf[39]=C_h_intern(&lf[39],13,"string-append");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[41]=C_h_intern(&lf[41],8,"for-each");
lf[42]=C_h_intern(&lf[42],4,"sort");
lf[43]=C_h_intern(&lf[43],8,"string<\077");
lf[44]=C_h_intern(&lf[44],19,"\003sysstandard-output");
lf[45]=C_h_intern(&lf[45],3,"min");
lf[46]=C_h_intern(&lf[46],13,"terminal-size");
lf[47]=C_h_intern(&lf[47],14,"terminal-port\077");
lf[50]=C_h_intern(&lf[50],5,"files");
lf[51]=C_h_intern(&lf[51],10,"append-map");
lf[52]=C_h_intern(&lf[52],25,"\003sysimplicit-exit-handler");
lf[53]=C_h_intern(&lf[53],4,"exit");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000 -eggs cannot be used with -list.");
lf[55]=C_h_intern(&lf[55],19,"with-output-to-port");
lf[56]=C_h_intern(&lf[56],18,"\003sysstandard-error");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000B`-deploy\047 only makes sense in combination with `-prefix DIRECTORY`");
lf[58]=C_h_intern(&lf[58],7,"irregex");
lf[59]=C_h_intern(&lf[59],7,"display");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\007(none)\012");
lf[61]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002.\052\376\377\016");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\001^");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\001$");
lf[64]=C_h_intern(&lf[64],13,"irregex-quote");
lf[65]=C_h_intern(&lf[65],16,"\003sysglob->regexp");
lf[66]=C_h_intern(&lf[66],2,"pp");
lf[67]=C_h_intern(&lf[67],14,"string->symbol");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\013\012target at ");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\002:\012");
lf[70]=C_h_intern(&lf[70],16,"\003sysdynamic-wind");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\010host at ");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\002:\012");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\002\351usage: chicken-status [OPTION | PATTERN] ...\012\012  -h   -help                 "
"   show this message\012       -version                 show version and exit\012  -f "
"  -files                   list installed files\012       -exact                   "
"treat PATTERN as exact match (not a pattern)\012       -host                    whe"
"n cross-compiling, show status of host extensions only\012       -target           "
"       when cross-compiling, show status of target extensions only\012  -p   -prefi"
"x PREFIX           change installation prefix to PREFIX\012       -deploy          "
"        prefix is a deployment directory\012       -list                    dump in"
"stalled extensions and their versions in \042override\042 format\012  -e   -eggs         "
"           list installed eggs");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\007-target");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\007-deploy");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\007-prefix");
lf[80]=C_h_intern(&lf[80],18,"normalize-pathname");
lf[81]=C_h_intern(&lf[81],17,"current-directory");
lf[82]=C_h_intern(&lf[82],18,"absolute-pathname\077");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\006-exact");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\005-list");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\002-f");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\006-files");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\002-e");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\005-eggs");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[90]=C_h_intern(&lf[90],15,"chicken-version");
lf[91]=C_h_intern(&lf[91],6,"append");
lf[92]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000f\376\003\000\000\002\376\377\012\000\000p\376\377\016");
lf[93]=C_h_intern(&lf[93],5,"every");
lf[94]=C_h_intern(&lf[94],16,"\003sysstring->list");
lf[95]=C_h_intern(&lf[95],9,"substring");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[98]=C_h_intern(&lf[98],22,"command-line-arguments");
lf[99]=C_h_intern(&lf[99],8,"feature\077");
lf[100]=C_h_intern(&lf[100],14,"\000cross-chicken");
lf[101]=C_h_intern(&lf[101],11,"\003sysrequire");
lf[102]=C_h_intern(&lf[102],9,"setup-api");
C_register_lf2(lf,103,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_891,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* a1453 in main#list-installed-files in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1454(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_1454,3,av);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1468,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1472,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm:124: repo-path */
f_931(t4);}

/* k1983 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1985(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1985,2,av);}
/* chicken-status.scm:237: exit */
t2=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1560(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,0,2))){
C_save_and_reclaim_args((void *)trf_1560,4,t0,t1,t2,t3);}
a=C_alloc(11);
if(C_truep(C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1573,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t5=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t5)){
t6=t4;
f_1573(t6,t5);}
else{
t6=((C_word*)((C_word*)t0)[3])[1];
t7=t4;
f_1573(t7,t6);}}
else{
t5=t4;
f_1573(t5,C_SCHEME_FALSE);}}
else{
t4=C_i_car(t2);
t5=t4;
t6=C_i_string_equal_p(t5,lf[73]);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1845,a[2]=t1,a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[2],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t6)){
t8=t7;
f_1845(t8,t6);}
else{
t8=C_u_i_string_equal_p(t5,lf[96]);
if(C_truep(t8)){
t9=t7;
f_1845(t9,t8);}
else{
t9=C_u_i_string_equal_p(t5,lf[97]);
t10=t7;
f_1845(t10,t9);}}}}

/* k1450 in main#list-installed-files in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1452(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1452,2,av);}
/* chicken-status.scm:121: sort */
t2=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=*((C_word*)lf[43]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1822 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1824(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1824,2,av);}
/* chicken-status.scm:194: print */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[71];
av2[3]=t1;
av2[4]=lf[72];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1470 in a1453 in main#list-installed-files in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1472(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1472,2,av);}
/* chicken-status.scm:124: setup-api#read-info */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[26]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[26]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
tp(4,av2);}}

/* for-each-loop337 in k1420 in main#list-installed-files in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1427(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1427,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1437,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-status.scm:118: g338 */
t5=*((C_word*)lf[36]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k1990 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1992,2,av);}
/* chicken-status.scm:236: print */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1996 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1998(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_1998,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=C_block_size(((C_word*)t0)[2]);
if(C_truep(C_fixnum_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2007,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2081,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:241: substring */
t5=*((C_word*)lf[95]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(1);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f2315,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:139: print */
t5=*((C_word*)lf[36]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[74];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}
else{
t2=((C_word*)t0)[6];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[5]);
/* chicken-status.scm:246: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1560(t5,((C_word*)t0)[4],t3,t4);}}

/* map-loop436 in status in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1701(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_1701,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1726,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1693,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:182: irregex-quote */
t7=C_fast_retrieve(lf[64]);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1420 in main#list-installed-files in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1422(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_1422,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1427,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1427(t5,((C_word*)t0)[2],t1);}

/* k1529 in for-each-loop357 in k1511 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1531(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1531,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1521(t3,((C_word*)t0)[4],t2);}

/* k1323 in k1310 in k1338 in g298 in k1295 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1325(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1325,2,av);}
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[32]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[32]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=lf[37];
av2[3]=t1;
tp(4,av2);}}

/* status in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1604(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(26,0,3))){
C_save_and_reclaim_args((void *)trf_1604,2,t0,t1);}
a=C_alloc(26);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=C_fast_retrieve(lf[58]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t6,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
t8=t7;{
C_word av2[2];
av2[0]=t8;
av2[1]=lf[61];
f_1611(2,av2);}}
else{
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t8=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t9=t8;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=((C_word*)t10)[1];
t12=((C_word*)t0)[4];
t13=C_i_check_list_2(t12,lf[21]);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1701,a[2]=t10,a[3]=t15,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_1701(t17,t7,t12);}
else{
t8=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t9=t8;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=((C_word*)t10)[1];
t12=C_fast_retrieve(lf[65]);
t13=((C_word*)t0)[4];
t14=C_i_check_list_2(t13,lf[21]);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1744,a[2]=t10,a[3]=t16,a[4]=t12,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t18=((C_word*)t16)[1];
f_1744(t18,t7,t13);}}}

/* k1318 in k1310 in k1338 in g298 in k1295 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1320(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_1320,2,av);}
a=C_alloc(6);
/* chicken-status.scm:109: format-string */
f_1194(((C_word*)t0)[2],t1,((C_word*)t0)[3],C_a_i_list(&a,2,C_SCHEME_TRUE,C_make_character(46)));}

/* k1504 in for-each-loop357 in k1511 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1506(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1506,2,av);}
a=C_alloc(4);
t2=C_i_assq(lf[35],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1491,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm:135: string->symbol */
t5=*((C_word*)lf[67]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1845(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_1845,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f2298,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:139: print */
t4=*((C_word*)lf[36]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[74];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
if(C_truep(C_u_i_string_equal_p(((C_word*)t0)[3],lf[75]))){
t2=lf[2] /* main#*target-extensions* */ =C_SCHEME_FALSE;;
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
/* chicken-status.scm:207: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1560(t5,((C_word*)t0)[2],t4,((C_word*)t0)[6]);}
else{
if(C_truep(C_u_i_string_equal_p(((C_word*)t0)[3],lf[76]))){
t2=lf[1] /* main#*host-extensions* */ =C_SCHEME_FALSE;;
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
/* chicken-status.scm:210: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1560(t5,((C_word*)t0)[2],t4,((C_word*)t0)[6]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[77],((C_word*)t0)[3]))){
t2=lf[4] /* main#*deploy* */ =C_SCHEME_TRUE;;
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
/* chicken-status.scm:213: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1560(t5,((C_word*)t0)[2],t4,((C_word*)t0)[6]);}
else{
t2=C_u_i_string_equal_p(((C_word*)t0)[3],lf[78]);
t3=(C_truep(t2)?t2:C_u_i_string_equal_p(((C_word*)t0)[3],lf[79]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
if(C_truep(C_i_pairp(t6))){
t7=t4;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_SCHEME_UNDEFINED;
f_1892(2,av2);}}
else{
t7=t4;
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f2303,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:139: print */
t9=*((C_word*)lf[36]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[74];
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}
else{
if(C_truep(C_u_i_string_equal_p(((C_word*)t0)[3],lf[83]))){
t4=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
/* chicken-status.scm:225: loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_1560(t7,((C_word*)t0)[2],t6,((C_word*)t0)[6]);}
else{
if(C_truep(C_u_i_string_equal_p(((C_word*)t0)[3],lf[84]))){
t4=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
/* chicken-status.scm:228: loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_1560(t7,((C_word*)t0)[2],t6,((C_word*)t0)[6]);}
else{
t4=C_u_i_string_equal_p(((C_word*)t0)[3],lf[85]);
t5=(C_truep(t4)?t4:C_u_i_string_equal_p(((C_word*)t0)[3],lf[86]));
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[9],0,C_SCHEME_TRUE);
t7=((C_word*)t0)[4];
t8=C_u_i_cdr(t7);
/* chicken-status.scm:231: loop */
t9=((C_word*)((C_word*)t0)[5])[1];
f_1560(t9,((C_word*)t0)[2],t8,((C_word*)t0)[6]);}
else{
t6=C_u_i_string_equal_p(((C_word*)t0)[3],lf[87]);
t7=(C_truep(t6)?t6:C_u_i_string_equal_p(((C_word*)t0)[3],lf[88]));
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t9=((C_word*)t0)[4];
t10=C_u_i_cdr(t9);
/* chicken-status.scm:234: loop */
t11=((C_word*)((C_word*)t0)[5])[1];
f_1560(t11,((C_word*)t0)[2],t10,((C_word*)t0)[6]);}
else{
if(C_truep(C_u_i_string_equal_p(((C_word*)t0)[3],lf[89]))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1992,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:236: chicken-version */
t10=C_fast_retrieve(lf[90]);{
C_word av2[2];
av2[0]=t10;
av2[1]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1998,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t9=C_block_size(((C_word*)t0)[3]);
if(C_truep(C_fixnum_greaterp(t9,C_fix(0)))){
t10=C_i_string_ref(((C_word*)t0)[3],C_fix(0));
t11=t8;
f_1998(t11,C_u_i_char_equalp(C_make_character(45),t10));}
else{
t10=t8;
f_1998(t10,C_SCHEME_FALSE);}}}}}}}}}}}}

/* k1615 in k1609 in status in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1617(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_1617,2,av);}
a=C_alloc(5);
t2=(C_truep(((C_word*)((C_word*)t0)[2])[1])?C_retrieve2(lf[24],"main#gather-eggs"):C_retrieve2(lf[18],"main#gather-extensions"));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1623,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-status.scm:176: g495 */
t4=t2;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1331 in k1338 in g298 in k1295 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1333(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_1333,2,av);}
a=C_alloc(6);
/* chicken-status.scm:108: format-string */
f_1194(((C_word*)t0)[2],t1,((C_word*)t0)[3],C_a_i_list(&a,2,C_SCHEME_FALSE,C_make_character(46)));}

/* k1609 in status in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1611(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_1611,2,av);}
a=C_alloc(13);
t2=C_i_check_list_2(t1,lf[21]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1643,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1643(t7,t3,t1);}

/* k1489 in k1504 in for-each-loop357 in k1511 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1491(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1491,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1495,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=C_i_cadr(((C_word*)t0)[3]);
/* chicken-status.scm:135: ->string */
t5=C_fast_retrieve(lf[38]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
/* chicken-status.scm:135: ->string */
t4=C_fast_retrieve(lf[38]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k1493 in k1489 in k1504 in for-each-loop357 in k1511 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1495(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_1495,2,av);}
a=C_alloc(6);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* chicken-status.scm:135: pp */
t3=C_fast_retrieve(lf[66]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k1122 in k1110 in loop in k1098 in main#gather-eggs in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,3))){
C_save_and_reclaim_args((void *)trf_1124,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
/* chicken-status.scm:75: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1102(t5,((C_word*)t0)[6],t2,t4);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
/* chicken-status.scm:75: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_1102(t5,((C_word*)t0)[6],t2,t4);}}

/* k1724 in map-loop436 in status in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1726(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1726,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1701(t6,((C_word*)t0)[5],t5);}

/* k1466 in a1453 in main#list-installed-files in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1468(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1468,2,av);}
t2=C_i_assq(lf[50],t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=(C_truep(t2)?C_i_cdr(t2):C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1345 in k1295 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1347(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1347,2,av);}
a=C_alloc(6);
t2=C_i_check_list_2(t1,lf[41]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1355,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1355(t6,((C_word*)t0)[3],t1);}

/* k1342 in g298 in k1295 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1344(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1344,2,av);}
/* chicken-status.scm:105: setup-api#read-info */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[26]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[26]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
tp(4,av2);}}

/* k1621 in k1615 in k1609 in status in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1623(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1623,2,av);}
if(C_truep(C_i_nullp(t1))){
/* chicken-status.scm:187: display */
t2=*((C_word*)lf[59]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[60];
av2[3]=*((C_word*)lf[56]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t2=C_retrieve2(lf[48],"main#list-installed-eggs");
t3=C_retrieve2(lf[48],"main#list-installed-eggs");
/* chicken-status.scm:176: g497 */
t4=C_retrieve2(lf[48],"main#list-installed-eggs");{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
f_1386(3,av2);}}
else{
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=C_retrieve2(lf[49],"main#list-installed-files");
t3=C_retrieve2(lf[49],"main#list-installed-files");
t4=C_retrieve2(lf[49],"main#list-installed-files");
/* chicken-status.scm:176: g497 */
t5=C_retrieve2(lf[49],"main#list-installed-files");{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
f_1418(3,av2);}}
else{
t2=C_retrieve2(lf[34],"main#list-installed-extensions");
t3=C_retrieve2(lf[34],"main#list-installed-extensions");
t4=C_retrieve2(lf[34],"main#list-installed-extensions");
/* chicken-status.scm:176: g497 */
t5=C_retrieve2(lf[34],"main#list-installed-extensions");{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
f_1293(3,av2);}}}}}

/* k1338 in g298 in k1295 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1340(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_1340,2,av);}
a=C_alloc(9);
t2=C_i_assq(lf[35],t1);
t3=t2;
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1333,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm:108: string-append */
t6=*((C_word*)lf[39]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[40];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
/* chicken-status.scm:112: print */
t4=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* for-each-loop357 in k1511 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1521(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,0,2))){
C_save_and_reclaim_args((void *)trf_1521,3,t0,t1,t2);}
a=C_alloc(13);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1531,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1506,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1510,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm:134: repo-path */
f_931(t8);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* f2298 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f2298(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f2298,2,av);}
/* chicken-status.scm:154: exit */
t2=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1145 in main#gather-all-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1147(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_1147,2,av);}
a=C_alloc(8);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1152,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1152(t5,((C_word*)t0)[5],t1);}

/* k1363 in for-each-loop297 in k1345 in k1295 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1365(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1365,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1355(t3,((C_word*)t0)[4],t2);}

/* map-loop463 in status in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1744(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_1744,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1769,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-status.scm:184: g469 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* main#gather-all-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1140(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(17,0,2))){
C_save_and_reclaim_args((void *)trf_1140,1,t1);}
a=C_alloc(17);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=C_fast_retrieve(lf[27]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1147,a[2]=t4,a[3]=t6,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1188,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1192,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:81: repo-path */
f_931(t9);}

/* main#gather-eggs in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1072(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1072,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1100,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:71: gather-extensions */
t4=C_retrieve2(lf[18],"main#gather-extensions");{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
f_1010(3,av2);}}

/* k1211 in main#format-string in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1213(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1213,2,av);}
if(C_truep(((C_word*)t0)[2])){
t2=((C_word*)t0)[3];
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[32]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[32]+1);
av2[1]=((C_word*)t0)[4];
av2[2]=t1;
av2[3]=t2;
tp(4,av2);}}
else{
t2=((C_word*)t0)[3];
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[32]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[32]+1);
av2[1]=((C_word*)t0)[4];
av2[2]=t2;
av2[3]=t1;
tp(4,av2);}}}

/* map-loop240 in k1145 in main#gather-all-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1152(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_1152,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1177,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-status.scm:80: g246 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1087 in loop in k1098 in main#gather-eggs in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1089(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1089,2,av);}
t2=C_i_assq(lf[25],t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=(C_truep(t2)?C_i_cadr(t2):C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* main#list-installed-eggs in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1386(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_1386,3,av);}
a=C_alloc(5);
t3=C_i_check_list_2(t2,lf[41]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1395,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_1395(t7,t1,t2);}

/* k1382 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1384(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1384,2,av);}
a=C_alloc(4);
t2=C_a_i_minus(&a,2,t1,C_fix(2));{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
av2[3]=C_fix(2);
C_quotient(4,av2);}}

/* k1403 in for-each-loop318 in main#list-installed-eggs in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1405(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1405,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1395(t3,((C_word*)t0)[4],t2);}

/* k1767 in map-loop463 in status in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1769(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1769,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1744(t6,((C_word*)t0)[5],t5);}

/* k1511 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1513(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_1513,2,av);}
a=C_alloc(5);
t2=C_i_check_list_2(t1,lf[41]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1521,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1521(t6,((C_word*)t0)[2],t1);}

/* k1508 in for-each-loop357 in k1511 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1510(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1510,2,av);}
/* chicken-status.scm:134: setup-api#read-info */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[26]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[26]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
tp(4,av2);}}

/* k1091 in loop in k1098 in main#gather-eggs in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1093(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1093,2,av);}
/* chicken-status.scm:68: setup-api#read-info */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[26]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[26]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
tp(4,av2);}}

/* k1691 in map-loop436 in status in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1693,2,av);}
/* chicken-status.scm:182: string-append */
t2=*((C_word*)lf[39]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[62];
av2[3]=t1;
av2[4]=lf[63];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a1580 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1581(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1581,2,av);}
/* chicken-status.scm:168: g399 */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[54];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_918(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_918,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_921,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:27: ##sys#require */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[101]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[101]+1);
av2[1]=t2;
av2[2]=lf[102];
tp(3,av2);}}

/* k1314 in k1310 in k1338 in g298 in k1295 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1316(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1316,2,av);}
/* chicken-status.scm:107: print */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_915(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_915,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_918,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_files_toplevel(2,av2);}}

/* k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_912(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_912,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_915,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_irregex_toplevel(2,av2);}}

/* k1310 in k1338 in g298 in k1295 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1312(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_1312,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1316,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1320,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1325,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_i_cadr(((C_word*)t0)[4]);
/* chicken-status.scm:110: ->string */
t7=C_fast_retrieve(lf[38]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* loop in k1098 in main#gather-eggs in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1102(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,0,2))){
C_save_and_reclaim_args((void *)trf_1102,4,t0,t1,t2,t3);}
a=C_alloc(13);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1112,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
t6=t4;
t7=t5;
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1089,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1093,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm:68: repo-path */
f_931(t9);}}

/* k1098 in main#gather-eggs in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1100(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_1100,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1102,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1102(t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_921(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_921,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_925,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:40: feature? */
t3=C_fast_retrieve(lf[99]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[100];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_925(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(24,c,5))){C_save_and_reclaim((void *)f_925,2,av);}
a=C_alloc(24);
t2=C_mutate2(&lf[0] /* (set! main#*cross-chicken* ...) */,t1);
t3=C_mutate2(&lf[1] /* (set! main#*host-extensions* ...) */,C_retrieve2(lf[0],"main#\052cross-chicken\052"));
t4=C_mutate2(&lf[2] /* (set! main#*target-extensions* ...) */,C_retrieve2(lf[0],"main#\052cross-chicken\052"));
t5=lf[3] /* main#*prefix* */ =C_SCHEME_FALSE;;
t6=lf[4] /* main#*deploy* */ =C_SCHEME_FALSE;;
t7=C_mutate2(&lf[5] /* (set! main#repo-path ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_931,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate2(&lf[15] /* (set! main#grep ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_998,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate2(&lf[18] /* (set! main#gather-extensions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1010,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate2(&lf[24] /* (set! main#gather-eggs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1072,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate2(&lf[23] /* (set! main#gather-all-extensions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1140,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate2(&lf[31] /* (set! main#format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1194,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2(&lf[34] /* (set! main#list-installed-extensions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1293,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate2(&lf[48] /* (set! main#list-installed-eggs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1386,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2(&lf[49] /* (set! main#list-installed-files ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1418,tmp=(C_word)a,a+=2,tmp));
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2124,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2134,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:248: command-line-arguments */
t18=C_fast_retrieve(lf[98]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t18;
av2[1]=t17;
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}

/* k1110 in loop in k1098 in main#gather-eggs in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1112(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_1112,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1124,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=C_i_member(t2,((C_word*)t0)[2]);
t5=t3;
f_1124(t5,C_i_not(t4));}
else{
t4=t3;
f_1124(t4,C_SCHEME_FALSE);}}

/* k1268 in k1265 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1270,2,av);}
if(C_truep(C_i_zerop(t1))){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(80);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
/* chicken-status.scm:98: min */
t2=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(80);
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1573(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,0,3))){
C_save_and_reclaim_args((void *)trf_1573,2,t0,t1);}
a=C_alloc(13);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1581,tmp=(C_word)a,a+=2,tmp);
/* chicken-status.scm:167: with-output-to-port */
t4=C_fast_retrieve(lf[55]);{
C_word av2[4];
av2[0]=t4;
av2[1]=t2;
av2[2]=*((C_word*)lf[56]+1);
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t2=(C_truep(C_retrieve2(lf[4],"main#\052deploy\052"))?C_i_not(C_retrieve2(lf[3],"main#\052prefix\052")):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1599,tmp=(C_word)a,a+=2,tmp);
/* chicken-status.scm:171: with-output-to-port */
t5=C_fast_retrieve(lf[55]);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=*((C_word*)lf[56]+1);
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1604,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=((C_word*)t0)[2];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1513,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:136: gather-all-extensions */
f_1140(t5);}
else{
t4=(C_truep(C_retrieve2(lf[1],"main#\052host-extensions\052"))?C_retrieve2(lf[2],"main#\052target-extensions\052"):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1791,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1824,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:194: repo-path */
f_931(t6);}
else{
/* chicken-status.scm:199: status */
t5=t3;
f_1604(t5,((C_word*)t0)[2]);}}}}}

/* k1574 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1576(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1576,2,av);}
/* chicken-status.scm:169: exit */
t2=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_906(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_906,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_909,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_utils_toplevel(2,av2);}}

/* k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_909(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_909,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_912,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_ports_toplevel(2,av2);}}

/* k898 in k895 in k892 in k889 */
static void C_ccall f_900(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_900,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_903,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_posix_toplevel(2,av2);}}

/* k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_903(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_903,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_906,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_data_2dstructures_toplevel(2,av2);}}

/* a1286 in k1265 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1287(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +0,c,1))){
C_save_and_reclaim((void*)f_1287,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+0);
t2=C_build_rest(&a,c,2,av);
C_word t3;
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_list_ref(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a1280 in k1265 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1281(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1281,2,av);}
/* chicken-status.scm:95: terminal-size */
t2=C_fast_retrieve(lf[46]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2030 in k2011 in k2005 in k1996 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_2032(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2032,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* chicken-status.scm:243: append */
t4=*((C_word*)lf[91]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* map-loop563 in k2011 in k2005 in k1996 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_2036(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_2036,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_string(&a,2,C_make_character(45),t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k972 in main#repo-path in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_974(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_974,2,av);}
a=C_alloc(5);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[6]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_980,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-status.scm:54: ##sys#print */
t6=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[13];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* g298 in k1295 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1298(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_1298,3,t0,t1,t2);}
a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1340,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1344,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm:105: repo-path */
f_931(t4);}

/* k1295 in main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_1297,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1298,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1347,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm:113: sort */
t5=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
av2[3]=*((C_word*)lf[43]+1);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* main#list-installed-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_1293,3,av);}
a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1297,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1384,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=*((C_word*)lf[44]+1);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1267,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm:94: terminal-port? */
t8=C_fast_retrieve(lf[47]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=*((C_word*)lf[44]+1);
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k1592 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1594(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1594,2,av);}
/* chicken-status.scm:173: exit */
t2=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a1598 in k1571 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1599(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1599,2,av);}
/* chicken-status.scm:172: g406 */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[57];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1175 in map-loop240 in k1145 in main#gather-all-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1177(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1177,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1152(t6,((C_word*)t0)[5],t5);}

/* k2011 in k2005 in k1996 in k1843 in loop in k2132 in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_2013(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(21,c,3))){C_save_and_reclaim((void *)f_2013,2,av);}
a=C_alloc(21);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2032,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2036,a[2]=t5,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2036(t11,t7,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f2310,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:139: print */
t4=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[74];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* main#grep in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_998(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_998,4,av);}
a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1004,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:58: filter */
t5=C_fast_retrieve(lf[17]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t4;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k1186 in main#gather-all-extensions in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_1188(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1188,2,av);}
/* chicken-status.scm:81: glob */
t2=C_fast_retrieve(lf[28]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* main#repo-path in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_931(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_931,1,t1);}
a=C_alloc(6);
if(C_truep(C_retrieve2(lf[4],"main#\052deploy\052"))){
t2=C_retrieve2(lf[3],"main#\052prefix\052");
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_retrieve2(lf[3],"main#\052prefix\052");
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(C_truep(C_retrieve2(lf[0],"main#\052cross-chicken\052"))?C_i_not(C_retrieve2(lf[1],"main#\052host-extensions\052")):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_948,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[12]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_TARGET_LIB_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
if(C_truep(C_retrieve2(lf[3],"main#\052prefix\052"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_974,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm:54: open-output-string */
t4=C_fast_retrieve(lf[11]);{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* chicken-status.scm:55: repository-path */
t3=C_fast_retrieve(lf[14]);{
C_word av2[2];
av2[0]=t3;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}}}

/* k946 in main#repo-path in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_948(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_948,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_952,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm:50: open-output-string */
t4=C_fast_retrieve(lf[11]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* for-each-loop318 in main#list-installed-eggs in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_fcall f_1395(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1395,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1405,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-status.scm:115: g319 */
t5=*((C_word*)lf[36]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k959 in k956 in k950 in k946 in main#repo-path in k923 in k919 in k916 in k913 in k910 in k907 in k904 in k901 in k898 in k895 in k892 in k889 */
static void C_ccall f_961(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_961,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm:50: get-output-string */
t3=C_fast_retrieve(lf[8]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[133] = {
{"f_1194:chicken_2dstatus_2escm",(void*)f_1194},
{"f_1192:chicken_2dstatus_2escm",(void*)f_1192},
{"f2303:chicken_2dstatus_2escm",(void*)f2303},
{"f_952:chicken_2dstatus_2escm",(void*)f_952},
{"f2310:chicken_2dstatus_2escm",(void*)f2310},
{"f2315:chicken_2dstatus_2escm",(void*)f2315},
{"f_964:chicken_2dstatus_2escm",(void*)f_964},
{"f_1267:chicken_2dstatus_2escm",(void*)f_1267},
{"f_897:chicken_2dstatus_2escm",(void*)f_897},
{"f_894:chicken_2dstatus_2escm",(void*)f_894},
{"f_2007:chicken_2dstatus_2escm",(void*)f_2007},
{"f_958:chicken_2dstatus_2escm",(void*)f_958},
{"f_2124:chicken_2dstatus_2escm",(void*)f_2124},
{"f_891:chicken_2dstatus_2escm",(void*)f_891},
{"f_2127:chicken_2dstatus_2escm",(void*)f_2127},
{"f_1063:chicken_2dstatus_2escm",(void*)f_1063},
{"f_2073:chicken_2dstatus_2escm",(void*)f_2073},
{"f_2134:chicken_2dstatus_2escm",(void*)f_2134},
{"f_2130:chicken_2dstatus_2escm",(void*)f_2130},
{"f_1892:chicken_2dstatus_2escm",(void*)f_1892},
{"f_1899:chicken_2dstatus_2escm",(void*)f_1899},
{"f_2081:chicken_2dstatus_2escm",(void*)f_2081},
{"f_1004:chicken_2dstatus_2escm",(void*)f_1004},
{"f_1794:chicken_2dstatus_2escm",(void*)f_1794},
{"f_1791:chicken_2dstatus_2escm",(void*)f_1791},
{"f_2020:chicken_2dstatus_2escm",(void*)f_2020},
{"f_1799:chicken_2dstatus_2escm",(void*)f_1799},
{"f_1014:chicken_2dstatus_2escm",(void*)f_1014},
{"f_1010:chicken_2dstatus_2escm",(void*)f_1010},
{"f_980:chicken_2dstatus_2escm",(void*)f_980},
{"f_983:chicken_2dstatus_2escm",(void*)f_983},
{"f_1026:chicken_2dstatus_2escm",(void*)f_1026},
{"f_1021:chicken_2dstatus_2escm",(void*)f_1021},
{"f_1036:chicken_2dstatus_2escm",(void*)f_1036},
{"f_1038:chicken_2dstatus_2escm",(void*)f_1038},
{"f_986:chicken_2dstatus_2escm",(void*)f_986},
{"f_1908:chicken_2dstatus_2escm",(void*)f_1908},
{"f_1418:chicken_2dstatus_2escm",(void*)f_1418},
{"f_1915:chicken_2dstatus_2escm",(void*)f_1915},
{"f_1919:chicken_2dstatus_2escm",(void*)f_1919},
{"f_1355:chicken_2dstatus_2escm",(void*)f_1355},
{"f_1643:chicken_2dstatus_2escm",(void*)f_1643},
{"f_1437:chicken_2dstatus_2escm",(void*)f_1437},
{"f_1808:chicken_2dstatus_2escm",(void*)f_1808},
{"f_1804:chicken_2dstatus_2escm",(void*)f_1804},
{"f_1815:chicken_2dstatus_2escm",(void*)f_1815},
{"f_1817:chicken_2dstatus_2escm",(void*)f_1817},
{"f_1668:chicken_2dstatus_2escm",(void*)f_1668},
{"toplevel:chicken_2dstatus_2escm",(void*)C_toplevel},
{"f_1454:chicken_2dstatus_2escm",(void*)f_1454},
{"f_1985:chicken_2dstatus_2escm",(void*)f_1985},
{"f_1560:chicken_2dstatus_2escm",(void*)f_1560},
{"f_1452:chicken_2dstatus_2escm",(void*)f_1452},
{"f_1824:chicken_2dstatus_2escm",(void*)f_1824},
{"f_1472:chicken_2dstatus_2escm",(void*)f_1472},
{"f_1427:chicken_2dstatus_2escm",(void*)f_1427},
{"f_1992:chicken_2dstatus_2escm",(void*)f_1992},
{"f_1998:chicken_2dstatus_2escm",(void*)f_1998},
{"f_1701:chicken_2dstatus_2escm",(void*)f_1701},
{"f_1422:chicken_2dstatus_2escm",(void*)f_1422},
{"f_1531:chicken_2dstatus_2escm",(void*)f_1531},
{"f_1325:chicken_2dstatus_2escm",(void*)f_1325},
{"f_1604:chicken_2dstatus_2escm",(void*)f_1604},
{"f_1320:chicken_2dstatus_2escm",(void*)f_1320},
{"f_1506:chicken_2dstatus_2escm",(void*)f_1506},
{"f_1845:chicken_2dstatus_2escm",(void*)f_1845},
{"f_1617:chicken_2dstatus_2escm",(void*)f_1617},
{"f_1333:chicken_2dstatus_2escm",(void*)f_1333},
{"f_1611:chicken_2dstatus_2escm",(void*)f_1611},
{"f_1491:chicken_2dstatus_2escm",(void*)f_1491},
{"f_1495:chicken_2dstatus_2escm",(void*)f_1495},
{"f_1124:chicken_2dstatus_2escm",(void*)f_1124},
{"f_1726:chicken_2dstatus_2escm",(void*)f_1726},
{"f_1468:chicken_2dstatus_2escm",(void*)f_1468},
{"f_1347:chicken_2dstatus_2escm",(void*)f_1347},
{"f_1344:chicken_2dstatus_2escm",(void*)f_1344},
{"f_1623:chicken_2dstatus_2escm",(void*)f_1623},
{"f_1340:chicken_2dstatus_2escm",(void*)f_1340},
{"f_1521:chicken_2dstatus_2escm",(void*)f_1521},
{"f2298:chicken_2dstatus_2escm",(void*)f2298},
{"f_1147:chicken_2dstatus_2escm",(void*)f_1147},
{"f_1365:chicken_2dstatus_2escm",(void*)f_1365},
{"f_1744:chicken_2dstatus_2escm",(void*)f_1744},
{"f_1140:chicken_2dstatus_2escm",(void*)f_1140},
{"f_1072:chicken_2dstatus_2escm",(void*)f_1072},
{"f_1213:chicken_2dstatus_2escm",(void*)f_1213},
{"f_1152:chicken_2dstatus_2escm",(void*)f_1152},
{"f_1089:chicken_2dstatus_2escm",(void*)f_1089},
{"f_1386:chicken_2dstatus_2escm",(void*)f_1386},
{"f_1384:chicken_2dstatus_2escm",(void*)f_1384},
{"f_1405:chicken_2dstatus_2escm",(void*)f_1405},
{"f_1769:chicken_2dstatus_2escm",(void*)f_1769},
{"f_1513:chicken_2dstatus_2escm",(void*)f_1513},
{"f_1510:chicken_2dstatus_2escm",(void*)f_1510},
{"f_1093:chicken_2dstatus_2escm",(void*)f_1093},
{"f_1693:chicken_2dstatus_2escm",(void*)f_1693},
{"f_1581:chicken_2dstatus_2escm",(void*)f_1581},
{"f_918:chicken_2dstatus_2escm",(void*)f_918},
{"f_1316:chicken_2dstatus_2escm",(void*)f_1316},
{"f_915:chicken_2dstatus_2escm",(void*)f_915},
{"f_912:chicken_2dstatus_2escm",(void*)f_912},
{"f_1312:chicken_2dstatus_2escm",(void*)f_1312},
{"f_1102:chicken_2dstatus_2escm",(void*)f_1102},
{"f_1100:chicken_2dstatus_2escm",(void*)f_1100},
{"f_921:chicken_2dstatus_2escm",(void*)f_921},
{"f_925:chicken_2dstatus_2escm",(void*)f_925},
{"f_1112:chicken_2dstatus_2escm",(void*)f_1112},
{"f_1270:chicken_2dstatus_2escm",(void*)f_1270},
{"f_1573:chicken_2dstatus_2escm",(void*)f_1573},
{"f_1576:chicken_2dstatus_2escm",(void*)f_1576},
{"f_906:chicken_2dstatus_2escm",(void*)f_906},
{"f_909:chicken_2dstatus_2escm",(void*)f_909},
{"f_900:chicken_2dstatus_2escm",(void*)f_900},
{"f_903:chicken_2dstatus_2escm",(void*)f_903},
{"f_1287:chicken_2dstatus_2escm",(void*)f_1287},
{"f_1281:chicken_2dstatus_2escm",(void*)f_1281},
{"f_2032:chicken_2dstatus_2escm",(void*)f_2032},
{"f_2036:chicken_2dstatus_2escm",(void*)f_2036},
{"f_974:chicken_2dstatus_2escm",(void*)f_974},
{"f_1298:chicken_2dstatus_2escm",(void*)f_1298},
{"f_1297:chicken_2dstatus_2escm",(void*)f_1297},
{"f_1293:chicken_2dstatus_2escm",(void*)f_1293},
{"f_1594:chicken_2dstatus_2escm",(void*)f_1594},
{"f_1599:chicken_2dstatus_2escm",(void*)f_1599},
{"f_1177:chicken_2dstatus_2escm",(void*)f_1177},
{"f_2013:chicken_2dstatus_2escm",(void*)f_2013},
{"f_998:chicken_2dstatus_2escm",(void*)f_998},
{"f_1188:chicken_2dstatus_2escm",(void*)f_1188},
{"f_931:chicken_2dstatus_2escm",(void*)f_931},
{"f_948:chicken_2dstatus_2escm",(void*)f_948},
{"f_1395:chicken_2dstatus_2escm",(void*)f_1395},
{"f_961:chicken_2dstatus_2escm",(void*)f_961},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|hiding nonexported module bindings: main#*cross-chicken* 
o|hiding nonexported module bindings: main#*host-extensions* 
o|hiding nonexported module bindings: main#*target-extensions* 
o|hiding nonexported module bindings: main#*prefix* 
o|hiding nonexported module bindings: main#*deploy* 
o|hiding nonexported module bindings: main#repo-path 
o|hiding nonexported module bindings: main#grep 
o|hiding nonexported module bindings: main#gather-extensions 
o|hiding nonexported module bindings: main#gather-eggs 
o|hiding nonexported module bindings: main#gather-all-extensions 
o|hiding nonexported module bindings: main#format-string 
o|hiding nonexported module bindings: main#get-terminal-width 
o|hiding nonexported module bindings: main#list-installed-extensions 
o|hiding nonexported module bindings: main#list-installed-eggs 
o|hiding nonexported module bindings: main#list-installed-files 
o|hiding nonexported module bindings: main#dump-installed-versions 
o|hiding nonexported module bindings: main#usage 
o|hiding nonexported module bindings: main#*short-options* 
o|hiding nonexported module bindings: main#main 
S|applied compiler syntax:
S|  for-each		4
S|  map		6
S|  sprintf		2
o|eliminated procedure checks: 39 
o|specializations:
o|  1 (> fixnum fixnum)
o|  1 (char=? char char)
o|  1 (string-ref string fixnum)
o|  1 (positive? fixnum)
o|  2 (string-length string)
o|  1 (cddr (pair * pair))
o|  14 (string=? string string)
o|  3 (current-error-port)
o|  1 (current-output-port)
o|  3 (string-append string string)
o|  3 (##sys#check-list (or pair list) *)
o|  11 (cdr pair)
o|  2 (##sys#check-output-port * * *)
(o e)|safe calls: 166 
o|inlining procedure: k933 
o|propagated global variable: r9342135 main#*prefix* 
o|inlining procedure: k933 
o|substituted constant variable: a954 
o|substituted constant variable: a955 
o|inlining procedure: k965 
o|substituted constant variable: a976 
o|substituted constant variable: a977 
o|inlining procedure: k965 
o|propagated global variable: g186187 irregex-search 
o|inlining procedure: k1040 
o|inlining procedure: k1040 
o|inlining procedure: k1104 
o|inlining procedure: k1104 
o|inlining procedure: k1117 
o|inlining procedure: k1117 
o|contracted procedure: "(chicken-status.scm:74) egg-name227" 
o|inlining procedure: k1080 
o|inlining procedure: k1080 
o|inlining procedure: k1154 
o|inlining procedure: k1154 
o|merged explicitly consed rest parameter: tmp269272 
o|inlining procedure: k1214 
o|inlining procedure: k1214 
o|inlining procedure: k1262 
o|substituted constant variable: default-width286 
o|substituted constant variable: default-width286 
o|inlining procedure: k1262 
o|substituted constant variable: default-width286 
o|propagated global variable: cop287 ##sys#standard-output 
o|inlining procedure: k1303 
o|consed rest parameter at call site: "(chicken-status.scm:109) main#format-string" 3 
o|substituted constant variable: a1321 
o|consed rest parameter at call site: "(chicken-status.scm:108) main#format-string" 3 
o|inlining procedure: k1303 
o|inlining procedure: k1357 
o|inlining procedure: k1357 
o|inlining procedure: k1397 
o|inlining procedure: k1397 
o|inlining procedure: k1429 
o|inlining procedure: k1429 
o|inlining procedure: k1459 
o|inlining procedure: k1459 
o|contracted procedure: "(chicken-status.scm:248) main#main" 
o|inlining procedure: k1562 
o|inlining procedure: k1586 
o|inlining procedure: k1624 
o|inlining procedure: k1624 
o|inlining procedure: k1639 
o|propagated global variable: r16402173 main#list-installed-files 
o|inlining procedure: k1639 
o|propagated global variable: r16402174 main#list-installed-extensions 
o|inlining procedure: k1645 
o|inlining procedure: k1645 
o|inlining procedure: k1679 
o|inlining procedure: k1703 
o|contracted procedure: "(chicken-status.scm:181) g442451" 
o|inlining procedure: k1703 
o|inlining procedure: k1679 
o|inlining procedure: k1746 
o|inlining procedure: k1746 
o|inlining procedure: k1586 
o|contracted procedure: "(chicken-status.scm:192) main#dump-installed-versions" 
o|inlining procedure: k1523 
o|contracted procedure: "(chicken-status.scm:131) g358365" 
o|inlining procedure: k1497 
o|inlining procedure: k1497 
o|inlining procedure: k1523 
o|inlining procedure: k1783 
o|inlining procedure: k1783 
o|inlining procedure: k1831 
o|inlining procedure: k1831 
o|inlining procedure: k1562 
o|substituted constant variable: a1853 
o|inlining procedure: k1849 
o|inlining procedure: k1849 
o|substituted constant variable: a1864 
o|substituted constant variable: a1874 
o|inlining procedure: k1871 
o|inlining procedure: k1871 
o|substituted constant variable: a1886 
o|substituted constant variable: a1932 
o|inlining procedure: k1928 
o|inlining procedure: k1928 
o|substituted constant variable: a1943 
o|substituted constant variable: a1954 
o|inlining procedure: k1950 
o|inlining procedure: k1950 
o|substituted constant variable: a1968 
o|substituted constant variable: a1982 
o|inlining procedure: k1978 
o|inlining procedure: k1978 
o|inlining procedure: k1999 
o|inlining procedure: k2038 
o|contracted procedure: "(chicken-status.scm:243) g569578" 
o|inlining procedure: k2038 
o|substituted constant variable: main#*short-options* 
o|inlining procedure: k1999 
o|substituted constant variable: a2089 
o|substituted constant variable: a2107 
o|substituted constant variable: a2104 
o|substituted constant variable: a2110 
o|substituted constant variable: a2112 
o|substituted constant variable: a2114 
o|substituted constant variable: a2116 
o|inlining procedure: k2117 
o|inlining procedure: k2117 
o|substituted constant variable: a2121 
o|replaced variables: 231 
o|removed binding forms: 104 
o|substituted constant variable: r10812152 
o|contracted procedure: "(chicken-status.scm:102) main#get-terminal-width" 
o|substituted constant variable: r12632158 
o|substituted constant variable: r14602168 
o|removed side-effect free assignment to unused variable: main#*short-options* 
o|inlining procedure: k1633 
o|propagated global variable: r16342237 main#list-installed-eggs 
o|propagated global variable: r16342237 main#list-installed-eggs 
o|inlining procedure: k1633 
o|propagated global variable: r16342243 main#list-installed-files 
o|propagated global variable: r16342243 main#list-installed-files 
o|inlining procedure: k1633 
o|propagated global variable: r16342249 main#list-installed-extensions 
o|propagated global variable: r16342249 main#list-installed-extensions 
o|substituted constant variable: r14982187 
o|substituted constant variable: r14982187 
o|replaced variables: 3 
o|removed binding forms: 259 
o|inlining procedure: "(chicken-status.scm:204) main#usage" 
o|inlining procedure: "(chicken-status.scm:215) main#usage" 
o|inlining procedure: "(chicken-status.scm:244) main#usage" 
o|inlining procedure: "(chicken-status.scm:245) main#usage" 
o|replaced variables: 5 
o|removed binding forms: 14 
o|removed side-effect free assignment to unused variable: main#usage 
o|substituted constant variable: code3762296 
o|substituted constant variable: code3762301 
o|substituted constant variable: code3762308 
o|substituted constant variable: code3762313 
o|removed binding forms: 5 
o|removed binding forms: 5 
o|simplifications: ((if . 13) (##core#call . 108)) 
o|  call simplifications:
o|    string=?
o|    ##sys#size	2
o|    fx>
o|    string->list
o|    memq
o|    string
o|    list
o|    ##sys#call-with-values
o|    list-ref
o|    zero?
o|    -
o|    quotient
o|    cdr	3
o|    string-length
o|    fx-
o|    fxmax
o|    null?	8
o|    car	4
o|    assq	4
o|    cadr	4
o|    member
o|    ##sys#check-list	7
o|    pair?	11
o|    cons	14
o|    ##sys#setslot	6
o|    ##sys#slot	26
o|    not	3
o|    ##sys#fudge
o|contracted procedure: k939 
o|contracted procedure: k988 
o|contracted procedure: k1023 
o|contracted procedure: k1031 
o|contracted procedure: k1043 
o|contracted procedure: k1046 
o|contracted procedure: k1049 
o|contracted procedure: k1057 
o|contracted procedure: k1065 
o|contracted procedure: k1107 
o|contracted procedure: k1117 
o|contracted procedure: k1132 
o|contracted procedure: k1136 
o|contracted procedure: k1077 
o|contracted procedure: k1142 
o|contracted procedure: k1157 
o|contracted procedure: k1160 
o|contracted procedure: k1163 
o|contracted procedure: k1171 
o|contracted procedure: k1179 
o|contracted procedure: k1253 
o|contracted procedure: k1196 
o|contracted procedure: k1247 
o|contracted procedure: k1199 
o|contracted procedure: k1241 
o|contracted procedure: k1202 
o|contracted procedure: k1235 
o|contracted procedure: k1205 
o|contracted procedure: k1208 
o|contracted procedure: k1232 
o|contracted procedure: k1228 
o|contracted procedure: k1300 
o|contracted procedure: k1327 
o|contracted procedure: k1348 
o|contracted procedure: k1360 
o|contracted procedure: k1370 
o|contracted procedure: k1374 
o|contracted procedure: k1378 
o|contracted procedure: k1274 
o|contracted procedure: k1388 
o|contracted procedure: k1400 
o|contracted procedure: k1410 
o|contracted procedure: k1414 
o|contracted procedure: k1432 
o|contracted procedure: k1442 
o|contracted procedure: k1446 
o|contracted procedure: k1456 
o|contracted procedure: k1565 
o|contracted procedure: k1589 
o|contracted procedure: k1606 
o|contracted procedure: k1612 
o|contracted procedure: k1618 
o|contracted procedure: k1627 
o|contracted procedure: k1648 
o|contracted procedure: k1651 
o|contracted procedure: k1654 
o|contracted procedure: k1662 
o|contracted procedure: k1670 
o|contracted procedure: k1676 
o|contracted procedure: k1682 
o|contracted procedure: k1694 
o|contracted procedure: k1706 
o|contracted procedure: k1709 
o|contracted procedure: k1712 
o|contracted procedure: k1720 
o|contracted procedure: k1728 
o|contracted procedure: k1734 
o|contracted procedure: k1737 
o|contracted procedure: k1749 
o|contracted procedure: k1752 
o|contracted procedure: k1755 
o|contracted procedure: k1763 
o|contracted procedure: k1771 
o|contracted procedure: k1514 
o|contracted procedure: k1526 
o|contracted procedure: k1536 
o|contracted procedure: k1540 
o|contracted procedure: k1478 
o|contracted procedure: k1485 
o|contracted procedure: k1497 
o|contracted procedure: k1786 
o|contracted procedure: k1834 
o|contracted procedure: k1840 
o|contracted procedure: k1887 
o|contracted procedure: k1894 
o|contracted procedure: k1920 
o|contracted procedure: k1955 
o|contracted procedure: k1969 
o|contracted procedure: k2086 
o|contracted procedure: k2002 
o|contracted procedure: k2022 
o|contracted procedure: k2041 
o|contracted procedure: k2063 
o|contracted procedure: k2059 
o|contracted procedure: k2044 
o|contracted procedure: k2047 
o|contracted procedure: k2055 
o|contracted procedure: k2097 
o|contracted procedure: k2101 
o|simplifications: ((let . 17)) 
o|removed binding forms: 99 
o|replaced variables: 36 
o|removed binding forms: 16 
o|customizable procedures: (k1843 k1996 map-loop563588 loop385 k1571 status409 for-each-loop357370 map-loop463480 map-loop436454 map-loop413487 for-each-loop337349 for-each-loop318328 g298305 for-each-loop297309 main#format-string map-loop240257 main#repo-path k1122 loop230 main#gather-all-extensions g199208 map-loop193218) 
o|calls to known targets: 68 
o|identified direct recursive calls: f_2036 1 
o|fast box initializations: 12 
o|fast global references: 42 
o|fast global assignments: 20 
o|dropping unused closure argument: f_1194 
o|dropping unused closure argument: f_1140 
o|dropping unused closure argument: f_931 
*/
/* end of file */
