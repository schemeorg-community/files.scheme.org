/* Generated from chicken-ffi-syntax.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:49
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: chicken-ffi-syntax.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file chicken-ffi-syntax.c
   unit: chicken_2dffi_2dsyntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[93];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,24),40,97,56,52,55,32,102,111,114,109,52,52,48,32,114,52,52,49,32,99,52,52,50,41};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,52,49,52,32,103,52,50,54,52,51,51,41,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,24),40,97,56,57,49,32,102,111,114,109,52,48,54,32,114,52,48,55,32,99,52,48,56,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,51,55,51,32,103,51,56,53,51,57,57,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,24),40,97,57,56,54,32,102,111,114,109,51,54,53,32,114,51,54,54,32,99,51,54,55,41};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,51,51,57,32,103,51,53,49,51,53,56,41,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,25),40,97,49,48,55,55,32,102,111,114,109,51,51,49,32,114,51,51,50,32,99,51,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,50,57,56,32,103,51,49,48,51,50,52,41,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,25),40,97,49,49,55,50,32,102,111,114,109,50,57,48,32,114,50,57,49,32,99,50,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,50,53,55,32,103,50,54,57,50,56,51,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,50,50,56,32,103,50,52,48,50,52,54,41,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,25),40,97,49,50,54,51,32,102,111,114,109,50,49,55,32,114,50,49,56,32,99,50,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,25),40,97,49,52,51,57,32,102,111,114,109,50,49,49,32,114,50,49,50,32,99,50,49,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,25),40,97,49,52,53,51,32,102,111,114,109,50,48,53,32,114,50,48,54,32,99,50,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,25),40,97,49,52,54,55,32,102,111,114,109,49,57,56,32,114,49,57,57,32,99,50,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,97,49,52,56,56,32,102,111,114,109,49,56,53,32,114,49,56,54,32,99,49,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,25),40,97,49,53,53,48,32,102,111,114,109,49,54,50,32,114,49,54,51,32,99,49,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,6),40,103,49,50,53,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,25),40,97,49,54,53,53,32,98,49,52,57,32,97,49,53,48,32,114,101,115,116,49,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,17),40,97,49,54,57,57,32,98,49,52,55,32,97,49,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,49,49,57,32,103,49,51,49,49,51,56,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,25),40,97,49,54,49,53,32,102,111,114,109,49,49,49,32,114,49,49,50,32,99,49,49,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,22),40,97,49,55,54,48,32,102,111,114,109,57,51,32,114,57,52,32,99,57,53,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,19),40,97,49,56,51,56,32,120,56,54,32,114,56,55,32,99,56,56,41,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,54,48,32,103,55,50,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,51,51,32,103,52,53,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,19),40,97,49,56,53,53,32,102,111,114,109,54,32,114,55,32,99,56,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_1216)
static void C_ccall f_1216(C_word c,C_word *av) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word *av) C_noret;
C_noret_decl(f_790)
static void C_ccall f_790(C_word c,C_word *av) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797(C_word c,C_word *av) C_noret;
C_noret_decl(f_794)
static void C_ccall f_794(C_word c,C_word *av) C_noret;
C_noret_decl(f_803)
static void C_ccall f_803(C_word c,C_word *av) C_noret;
C_noret_decl(f_809)
static void C_ccall f_809(C_word c,C_word *av) C_noret;
C_noret_decl(f_806)
static void C_ccall f_806(C_word c,C_word *av) C_noret;
C_noret_decl(f_800)
static void C_ccall f_800(C_word c,C_word *av) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word *av) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word *av) C_noret;
C_noret_decl(f_1222)
static void C_fcall f_1222(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_833)
static void C_ccall f_833(C_word c,C_word *av) C_noret;
C_noret_decl(f_836)
static void C_ccall f_836(C_word c,C_word *av) C_noret;
C_noret_decl(f_839)
static void C_ccall f_839(C_word c,C_word *av) C_noret;
C_noret_decl(f_830)
static void C_ccall f_830(C_word c,C_word *av) C_noret;
C_noret_decl(f_1866)
static void C_fcall f_1866(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word *av) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word *av) C_noret;
C_noret_decl(f_1581)
static void C_ccall f_1581(C_word c,C_word *av) C_noret;
C_noret_decl(f_1863)
static void C_fcall f_1863(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word *av) C_noret;
C_noret_decl(f_861)
static void C_ccall f_861(C_word c,C_word *av) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word *av) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word *av) C_noret;
C_noret_decl(f_1247)
static void C_ccall f_1247(C_word c,C_word *av) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word *av) C_noret;
C_noret_decl(f_815)
static void C_ccall f_815(C_word c,C_word *av) C_noret;
C_noret_decl(f_812)
static void C_ccall f_812(C_word c,C_word *av) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word *av) C_noret;
C_noret_decl(f_818)
static void C_ccall f_818(C_word c,C_word *av) C_noret;
C_noret_decl(f_2000)
static void C_fcall f_2000(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1629)
static void C_fcall f_1629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word *av) C_noret;
C_noret_decl(f_1514)
static void C_ccall f_1514(C_word c,C_word *av) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word *av) C_noret;
C_noret_decl(f_1264)
static void C_ccall f_1264(C_word c,C_word *av) C_noret;
C_noret_decl(f_1262)
static void C_ccall f_1262(C_word c,C_word *av) C_noret;
C_noret_decl(f_1268)
static void C_ccall f_1268(C_word c,C_word *av) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word *av) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word *av) C_noret;
C_noret_decl(f_1506)
static void C_fcall f_1506(C_word t0,C_word t1) C_noret;
C_noret_decl(f_970)
static void C_ccall f_970(C_word c,C_word *av) C_noret;
C_noret_decl(f_987)
static void C_ccall f_987(C_word c,C_word *av) C_noret;
C_noret_decl(f_985)
static void C_ccall f_985(C_word c,C_word *av) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word *av) C_noret;
C_noret_decl(f_1606)
static void C_ccall f_1606(C_word c,C_word *av) C_noret;
C_noret_decl(f_1602)
static void C_ccall f_1602(C_word c,C_word *av) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word *av) C_noret;
C_noret_decl(f_1359)
static void C_ccall f_1359(C_word c,C_word *av) C_noret;
C_noret_decl(f_925)
static void C_ccall f_925(C_word c,C_word *av) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word *av) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558(C_word c,C_word *av) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word *av) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word *av) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word *av) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word *av) C_noret;
C_noret_decl(f_935)
static void C_ccall f_935(C_word c,C_word *av) C_noret;
C_noret_decl(f_931)
static void C_ccall f_931(C_word c,C_word *av) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word *av) C_noret;
C_noret_decl(f_945)
static void C_fcall f_945(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1368)
static void C_fcall f_1368(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word *av) C_noret;
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word *av) C_noret;
C_noret_decl(f_1061)
static void C_ccall f_1061(C_word c,C_word *av) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word *av) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word *av) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dffi_2dsyntax_toplevel)
C_externexport void C_ccall C_chicken_2dffi_2dsyntax_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_1466)
static void C_ccall f_1466(C_word c,C_word *av) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word *av) C_noret;
C_noret_decl(f_1173)
static void C_ccall f_1173(C_word c,C_word *av) C_noret;
C_noret_decl(f_1177)
static void C_ccall f_1177(C_word c,C_word *av) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word *av) C_noret;
C_noret_decl(f_1171)
static void C_ccall f_1171(C_word c,C_word *av) C_noret;
C_noret_decl(f_1036)
static void C_fcall f_1036(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word *av) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word *av) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word *av) C_noret;
C_noret_decl(f_848)
static void C_ccall f_848(C_word c,C_word *av) C_noret;
C_noret_decl(f_846)
static void C_ccall f_846(C_word c,C_word *av) C_noret;
C_noret_decl(f_1202)
static void C_ccall f_1202(C_word c,C_word *av) C_noret;
C_noret_decl(f_842)
static void C_ccall f_842(C_word c,C_word *av) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word *av) C_noret;
C_noret_decl(f_892)
static void C_ccall f_892(C_word c,C_word *av) C_noret;
C_noret_decl(f_1496)
static void C_ccall f_1496(C_word c,C_word *av) C_noret;
C_noret_decl(f_890)
static void C_ccall f_890(C_word c,C_word *av) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word *av) C_noret;
C_noret_decl(f_896)
static void C_ccall f_896(C_word c,C_word *av) C_noret;
C_noret_decl(f_876)
static void C_ccall f_876(C_word c,C_word *av) C_noret;
C_noret_decl(f_1748)
static void C_ccall f_1748(C_word c,C_word *av) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word *av) C_noret;
C_noret_decl(f_1078)
static void C_ccall f_1078(C_word c,C_word *av) C_noret;
C_noret_decl(f_858)
static void C_ccall f_858(C_word c,C_word *av) C_noret;
C_noret_decl(f_1076)
static void C_ccall f_1076(C_word c,C_word *av) C_noret;
C_noret_decl(f_855)
static void C_ccall f_855(C_word c,C_word *av) C_noret;
C_noret_decl(f_852)
static void C_ccall f_852(C_word c,C_word *av) C_noret;
C_noret_decl(f_1723)
static void C_fcall f_1723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2049)
static void C_fcall f_2049(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word *av) C_noret;
C_noret_decl(f_1082)
static void C_ccall f_1082(C_word c,C_word *av) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word *av) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word *av) C_noret;
C_noret_decl(f_1274)
static void C_ccall f_1274(C_word c,C_word *av) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word *av) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word *av) C_noret;
C_noret_decl(f_1271)
static void C_fcall f_1271(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word *av) C_noret;
C_noret_decl(f_1030)
static void C_ccall f_1030(C_word c,C_word *av) C_noret;
C_noret_decl(f_1972)
static void C_ccall f_1972(C_word c,C_word *av) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word *av) C_noret;
C_noret_decl(f_1286)
static void C_ccall f_1286(C_word c,C_word *av) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word *av) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word *av) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word *av) C_noret;
C_noret_decl(f_1022)
static void C_ccall f_1022(C_word c,C_word *av) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word *av) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word *av) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word *av) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word *av) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593(C_word c,C_word *av) C_noret;
C_noret_decl(f_1125)
static void C_ccall f_1125(C_word c,C_word *av) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word *av) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word *av) C_noret;
C_noret_decl(f_1131)
static void C_fcall f_1131(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word *av) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word *av) C_noret;
C_noret_decl(f_1334)
static void C_fcall f_1334(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word *av) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word *av) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word *av) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word *av) C_noret;
C_noret_decl(f_1303)
static void C_fcall f_1303(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_ccall f_1549(C_word c,C_word *av) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word *av) C_noret;
C_noret_decl(f_824)
static void C_ccall f_824(C_word c,C_word *av) C_noret;
C_noret_decl(f_827)
static void C_ccall f_827(C_word c,C_word *av) C_noret;
C_noret_decl(f_821)
static void C_ccall f_821(C_word c,C_word *av) C_noret;

C_noret_decl(trf_1222)
static void C_ccall trf_1222(C_word c,C_word *av) C_noret;
static void C_ccall trf_1222(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1222(t0,t1,t2);}

C_noret_decl(trf_1866)
static void C_ccall trf_1866(C_word c,C_word *av) C_noret;
static void C_ccall trf_1866(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1866(t0,t1);}

C_noret_decl(trf_1863)
static void C_ccall trf_1863(C_word c,C_word *av) C_noret;
static void C_ccall trf_1863(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1863(t0,t1);}

C_noret_decl(trf_2000)
static void C_ccall trf_2000(C_word c,C_word *av) C_noret;
static void C_ccall trf_2000(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2000(t0,t1,t2);}

C_noret_decl(trf_1629)
static void C_ccall trf_1629(C_word c,C_word *av) C_noret;
static void C_ccall trf_1629(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1629(t0,t1);}

C_noret_decl(trf_1506)
static void C_ccall trf_1506(C_word c,C_word *av) C_noret;
static void C_ccall trf_1506(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1506(t0,t1);}

C_noret_decl(trf_945)
static void C_ccall trf_945(C_word c,C_word *av) C_noret;
static void C_ccall trf_945(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_945(t0,t1,t2);}

C_noret_decl(trf_1368)
static void C_ccall trf_1368(C_word c,C_word *av) C_noret;
static void C_ccall trf_1368(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1368(t0,t1,t2);}

C_noret_decl(trf_1036)
static void C_ccall trf_1036(C_word c,C_word *av) C_noret;
static void C_ccall trf_1036(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1036(t0,t1,t2);}

C_noret_decl(trf_1723)
static void C_ccall trf_1723(C_word c,C_word *av) C_noret;
static void C_ccall trf_1723(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1723(t0,t1,t2);}

C_noret_decl(trf_2049)
static void C_ccall trf_2049(C_word c,C_word *av) C_noret;
static void C_ccall trf_2049(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2049(t0,t1,t2);}

C_noret_decl(trf_1271)
static void C_ccall trf_1271(C_word c,C_word *av) C_noret;
static void C_ccall trf_1271(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1271(t0,t1);}

C_noret_decl(trf_1131)
static void C_ccall trf_1131(C_word c,C_word *av) C_noret;
static void C_ccall trf_1131(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1131(t0,t1,t2);}

C_noret_decl(trf_1334)
static void C_ccall trf_1334(C_word c,C_word *av) C_noret;
static void C_ccall trf_1334(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1334(t0,t1,t2);}

C_noret_decl(trf_1303)
static void C_ccall trf_1303(C_word c,C_word *av) C_noret;
static void C_ccall trf_1303(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1303(t0,t1);}

/* k1214 in k1206 in k1200 in k1175 in a1172 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1216(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1216,2,av);}
/* chicken-ffi-syntax.scm:234: ##compiler#foreign-type->scrutiny-type */
t2=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[25];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1210 in k1206 in k1200 in k1175 in a1172 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1212(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,1))){C_save_and_reclaim((void *)f_1212,2,av);}
a=C_alloc(24);
t2=C_a_i_list(&a,3,lf[22],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=C_a_i_cons(&a,2,lf[35],t4);
t6=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_list(&a,4,lf[6],t2,C_SCHEME_FALSE,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k788 */
static void C_ccall f_790(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_790,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_794,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:43: ##sys#macro-environment */
t3=*((C_word*)lf[90]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k795 in k792 in k788 */
static void C_ccall f_797(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_797,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1837,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1839,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:85: ##sys#er-transformer */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k792 in k788 */
static void C_ccall f_794(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_794,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_797,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1854,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1856,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:48: ##sys#er-transformer */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_803(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_803,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1614,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1616,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:110: ##sys#er-transformer */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_809(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_809,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1487,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1489,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:159: ##sys#er-transformer */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_806(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_806,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1549,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1551,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:144: ##sys#er-transformer */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k798 in k795 in k792 in k788 */
static void C_ccall f_800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_800,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1759,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1761,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:93: ##sys#er-transformer */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1635 in g125 in k1618 in a1615 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1637(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1637,2,av);}
/* chicken-ffi-syntax.scm:115: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1571 in k1556 in k1553 in a1550 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_1573,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1581,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-ffi-syntax.scm:151: open-output-string */
t4=*((C_word*)lf[63]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* map-loop298 in k1200 in k1175 in a1172 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_fcall f_1222(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_1222,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1247,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[24]+1);
/* chicken-ffi-syntax.scm:232: g321 */
t6=*((C_word*)lf[24]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[26];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_833(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_833,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_890,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_892,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:270: ##sys#er-transformer */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k834 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_836,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_846,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_848,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:284: ##sys#er-transformer */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k837 in k834 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_839(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_839,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_842,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:298: ##sys#macro-subset */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_830(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_830,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_833,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_985,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_987,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:256: ##sys#er-transformer */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1864 in k1861 in a1855 in k792 in k788 */
static void C_fcall f_1866(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_1866,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:54: ##sys#check-syntax */
t3=*((C_word*)lf[17]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[81];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[82];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
/* chicken-ffi-syntax.scm:64: ##sys#check-syntax */
t3=*((C_word*)lf[17]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[81];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[88];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
/* chicken-ffi-syntax.scm:65: ##sys#check-syntax */
t3=*((C_word*)lf[17]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[81];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[89];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}}

/* k1940 in k1927 in k1864 in k1861 in a1855 in k792 in k788 */
static void C_ccall f_1942(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(!C_demand(C_calculate_demand(37,c,3))){C_save_and_reclaim((void *)f_1942,2,av);}
a=C_alloc(37);
t2=t1;
t3=C_u_i_car(((C_word*)t0)[2]);
t4=C_u_i_car(((C_word*)t0)[2]);
t5=C_a_i_list(&a,2,lf[83],t4);
t6=t5;
t7=(C_truep(((C_word*)t0)[3])?C_i_car(((C_word*)t0)[4]):lf[84]);
t8=t7;
t9=(C_truep(((C_word*)t0)[3])?C_i_caddr(((C_word*)t0)[4]):C_i_cadr(((C_word*)t0)[4]));
t10=C_a_i_list(&a,2,lf[83],t9);
t11=t10;
t12=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t13=t12;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=((C_word*)t14)[1];
t16=C_i_check_list_2(((C_word*)t0)[5],lf[21]);
t17=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2047,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t8,a[6]=t11,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t3,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2049,a[2]=t14,a[3]=t19,a[4]=t15,a[5]=((C_word)li25),tmp=(C_word)a,a+=6,tmp));
t21=((C_word*)t19)[1];
f_2049(t21,t17,((C_word*)t0)[5]);}

/* k1585 in k1579 in k1571 in k1556 in k1553 in a1550 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1587(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_1587,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-ffi-syntax.scm:151: ##sys#print */
t3=*((C_word*)lf[57]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1579 in k1571 in k1556 in k1553 in a1550 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1581(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_1581,2,av);}
a=C_alloc(8);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[54]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-ffi-syntax.scm:151: ##sys#print */
t6=*((C_word*)lf[57]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[62];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k1861 in a1855 in k792 in k788 */
static void C_fcall f_1863(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_1863,2,t0,t1);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_1866(t4,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t4=C_u_i_car(((C_word*)t0)[2]);
t5=t3;
f_1866(t5,C_i_symbolp(t4));}
else{
t4=t3;
f_1866(t4,C_SCHEME_FALSE);}}}

/* k1927 in k1864 in k1861 in a1855 in k792 in k788 */
static void C_ccall f_1929(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_1929,2,av);}
a=C_alloc(8);
t2=(C_truep(((C_word*)t0)[2])?C_i_cadr(((C_word*)t0)[3]):C_i_car(((C_word*)t0)[3]));
t3=t2;
t4=C_i_cdr(t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1942,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-ffi-syntax.scm:68: r */
t7=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[87];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k859 in k856 in k853 in k850 in a847 in k834 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_861(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_861,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:294: string-append */
t3=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[10];
av2[3]=t1;
av2[4]=lf[11];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1652 in k1648 in k1641 in k1618 in a1615 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1654(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_1654,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[68],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a1655 in k1648 in k1641 in k1618 in a1615 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1656(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(15,c,1))){C_save_and_reclaim((void *)f_1656,5,av);}
a=C_alloc(15);
t5=C_i_length(t2);
t6=C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=C_i_car(t2);
t8=C_i_cadr(t2);
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_a_i_list(&a,5,lf[69],t7,t8,t3,t4);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t7=C_i_car(t2);
t8=C_i_cadr(t2);
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_a_i_list(&a,4,lf[69],t7,t8,t4);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}

/* k1245 in map-loop298 in k1200 in k1175 in a1172 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1247,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1222(t6,((C_word*)t0)[5],t5);}

/* k1648 in k1641 in k1618 in a1615 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1650(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,5))){C_save_and_reclaim((void *)f_1650,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1656,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
t5=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t6=C_a_i_cons(&a,2,lf[68],t5);
/* chicken-ffi-syntax.scm:123: fold-right */
t7=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=t4;
av2[3]=t6;
av2[4]=((C_word*)t0)[4];
av2[5]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t7+1)))(6,av2);}}

/* k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_815(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_815,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1452,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1454,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:196: ##sys#er-transformer */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_812(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_812,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1466,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1468,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:185: ##sys#er-transformer */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k989 in a986 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_991(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_991,2,av);}
a=C_alloc(11);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_i_cdddr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:261: ##sys#strip-syntax */
t8=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_818,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1438,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1440,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:203: ##sys#er-transformer */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* map-loop60 in k1970 in k2045 in k1940 in k1927 in k1864 in k1861 in a1855 in k792 in k788 */
static void C_fcall f_2000(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_2000,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g125 in k1618 in a1615 in k801 in k798 in k795 in k792 in k788 */
static void C_fcall f_1629(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_1629,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:115: gensym */
t3=*((C_word*)lf[14]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1618 in a1615 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1620(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,3))){C_save_and_reclaim((void *)f_1620,2,av);}
a=C_alloc(23);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1629,a[2]=((C_word*)t0)[3],a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
t12=C_i_check_list_2(t3,lf[21]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1643,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1723,a[2]=t9,a[3]=t15,a[4]=t11,a[5]=t10,a[6]=((C_word)li20),tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_1723(t17,t13,t3);}

/* k1512 in k1504 in k1494 in k1491 in a1488 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1514(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,1))){C_save_and_reclaim((void *)f_1514,2,av);}
a=C_alloc(21);
t2=C_a_i_list(&a,4,lf[6],t1,C_SCHEME_FALSE,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[8],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1516 in k1504 in k1494 in k1491 in a1488 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1518(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1518,2,av);}
/* chicken-ffi-syntax.scm:174: ##compiler#foreign-type->scrutiny-type */
t2=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[25];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a1263 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1264(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1264,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1268,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:212: ##sys#check-syntax */
t6=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[37];
av2[3]=t2;
av2[4]=lf[40];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k1260 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1262(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1262,2,av);}
/* chicken-ffi-syntax.scm:207: ##sys#extend-macro-environment */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[37];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1266 in a1263 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1268(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1268,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cddr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t3))){
t4=C_i_caddr(((C_word*)t0)[2]);
t5=C_i_stringp(t4);
t6=t2;
f_1271(t6,C_i_not(t5));}
else{
t4=t2;
f_1271(t4,C_SCHEME_FALSE);}}

/* k1825 in k1763 in a1760 in k798 in k795 in k792 in k788 */
static void C_ccall f_1827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1827,2,av);}
/* chicken-ffi-syntax.scm:99: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1821 in k1785 in k1778 in k1763 in a1760 in k798 in k795 in k792 in k788 */
static void C_ccall f_1823(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(48,c,1))){C_save_and_reclaim((void *)f_1823,2,av);}
a=C_alloc(48);
t2=C_a_i_list(&a,4,lf[4],((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_a_i_list(&a,5,lf[74],((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[4]);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t4=C_u_i_car(((C_word*)t0)[5]);
t5=C_a_i_list(&a,3,lf[75],((C_word*)t0)[2],t4);
t6=C_a_i_list(&a,1,t5);
t7=C_a_i_cons(&a,2,t3,t6);
t8=C_a_i_cons(&a,2,t2,t7);
t9=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[7],t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t2,t4);
t6=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k1504 in k1494 in k1491 in a1488 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_fcall f_1506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_1506,2,t0,t1);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1518,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_caddr(((C_word*)t0)[4]);
/* chicken-ffi-syntax.scm:175: ##sys#strip-syntax */
t6=*((C_word*)lf[16]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k968 in map-loop414 in k923 in k894 in a891 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_970(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_970,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_945(t6,((C_word*)t0)[5],t5);}

/* a986 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_987(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_987,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_991,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:258: ##sys#check-syntax */
t6=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[28];
av2[3]=t2;
av2[4]=lf[30];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k983 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_985(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_985,2,av);}
/* chicken-ffi-syntax.scm:253: ##sys#extend-macro-environment */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[28];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1880 in k1870 in k1864 in k1861 in a1855 in k792 in k788 */
static void C_ccall f_1882(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(42,c,1))){C_save_and_reclaim((void *)f_1882,2,av);}
a=C_alloc(42);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,lf[4],((C_word*)t0)[3],t2);
t4=C_u_i_cdr(((C_word*)t0)[2]);
t5=C_u_i_car(t4);
t6=C_a_i_list(&a,4,lf[74],((C_word*)t0)[3],t5,C_SCHEME_TRUE);
t7=C_u_i_cdr(((C_word*)t0)[2]);
t8=C_u_i_cdr(t7);
if(C_truep(C_i_pairp(t8))){
t9=C_i_caddr(((C_word*)t0)[2]);
t10=C_a_i_list(&a,3,lf[75],((C_word*)t0)[3],t9);
t11=C_a_i_list(&a,1,t10);
t12=C_a_i_cons(&a,2,t6,t11);
t13=C_a_i_cons(&a,2,t3,t12);
t14=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_a_i_cons(&a,2,t1,t13);
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
else{
t9=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,t3,t9);
t11=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=C_a_i_cons(&a,2,t1,t10);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}

/* k1604 in k1591 in k1588 in k1585 in k1579 in k1571 in k1556 in k1553 in a1550 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1606(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1606,2,av);}
/* chicken-ffi-syntax.scm:151: ##sys#print */
t2=*((C_word*)lf[57]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1600 in k1597 in k1594 in k1591 in k1588 in k1585 in k1579 in k1571 in k1556 in k1553 in a1550 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1602(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,1))){C_save_and_reclaim((void *)f_1602,2,av);}
a=C_alloc(27);
t2=C_a_i_list(&a,2,lf[44],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
t4=C_a_i_list(&a,2,lf[55],((C_word*)t0)[3]);
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_list(&a,3,lf[8],t3,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k1870 in k1864 in k1861 in a1855 in k792 in k788 */
static void C_ccall f_1872(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_1872,2,av);}
a=C_alloc(5);
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:56: r */
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[76];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1357 in map-loop257 in k1284 in k1275 in k1272 in k1269 in k1266 in a1263 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1359(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1359,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1334(t6,((C_word*)t0)[5],t5);}

/* k923 in k894 in a891 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_925(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_925,2,av);}
a=C_alloc(12);
t2=C_i_check_list_2(t1,lf[21]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_945,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word)li1),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_945(t7,t3,t1);}

/* k1553 in a1550 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1555(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_1555,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:147: gensym */
t3=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[65];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k1556 in k1553 in a1550 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1558(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_1558,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1573,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:149: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[64];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a1550 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1551(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_1551,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1555,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:146: ##sys#check-syntax */
t6=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[53];
av2[3]=t2;
av2[4]=lf[66];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k1612 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1614(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1614,2,av);}
/* chicken-ffi-syntax.scm:107: ##sys#extend-macro-environment */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[67];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a1615 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_1616,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1620,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:112: ##sys#check-syntax */
t6=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[67];
av2[3]=t2;
av2[4]=lf[72];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k937 in k929 in k923 in k894 in a891 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_939(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_939,2,av);}
/* chicken-ffi-syntax.scm:276: ##compiler#foreign-type->scrutiny-type */
t2=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[25];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k933 in k929 in k923 in k894 in a891 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_935(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,1))){C_save_and_reclaim((void *)f_935,2,av);}
a=C_alloc(24);
t2=C_a_i_list(&a,3,lf[22],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=C_a_i_cons(&a,2,lf[23],t4);
t6=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_list(&a,4,lf[6],t2,C_SCHEME_FALSE,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k929 in k923 in k894 in a891 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_931(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_931,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_935,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_939,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:277: ##sys#strip-syntax */
t6=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k1785 in k1778 in k1763 in a1760 in k798 in k795 in k792 in k788 */
static void C_ccall f_1787(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_1787,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken-ffi-syntax.scm:101: symbol->string */
t4=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* map-loop414 in k923 in k894 in a891 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_fcall f_945(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_945,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_970,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
/* chicken-ffi-syntax.scm:274: ##compiler#foreign-type->scrutiny-type */
t6=*((C_word*)lf[24]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
av2[3]=lf[26];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* map-loop228 in k1275 in k1272 in k1269 in k1266 in a1263 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_fcall f_1368(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_1368,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a1439 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1440(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_1440,5,av);}
a=C_alloc(3);
t5=C_i_cdr(t2);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_cons(&a,2,lf[4],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k1436 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1438(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1438,2,av);}
/* chicken-ffi-syntax.scm:200: ##sys#extend-macro-environment */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[41];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1059 in map-loop373 in k1014 in k989 in a986 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1061(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1061,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1036(t6,((C_word*)t0)[5],t5);}

/* k1641 in k1618 in a1615 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1643(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_1643,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1700,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:117: append-map */
t5=*((C_word*)lf[71]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* a1453 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1454(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_1454,5,av);}
a=C_alloc(3);
t5=C_i_cdr(t2);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_cons(&a,2,lf[43],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k1450 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1452(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1452,2,av);}
/* chicken-ffi-syntax.scm:193: ##sys#extend-macro-environment */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[42];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_chicken_2dffi_2dsyntax_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("chicken_2dffi_2dsyntax_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_chicken_2dffi_2dsyntax_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(1022)){
C_save(t1);
C_rereclaim2(1022*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,93);
lf[0]=C_h_intern(&lf[0],33,"\003syschicken-ffi-macro-environment");
lf[1]=C_h_intern(&lf[1],16,"\003sysmacro-subset");
lf[2]=C_h_intern(&lf[2],28,"\003sysextend-macro-environment");
lf[3]=C_h_intern(&lf[3],17,"foreign-type-size");
lf[4]=C_h_intern(&lf[4],28,"\004coredefine-foreign-variable");
lf[5]=C_h_intern(&lf[5],6,"size_t");
lf[6]=C_h_intern(&lf[6],8,"\004corethe");
lf[7]=C_h_intern(&lf[7],6,"fixnum");
lf[8]=C_h_intern(&lf[8],10,"\004corebegin");
lf[9]=C_h_intern(&lf[9],13,"string-append");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\007sizeof(");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[12]=C_h_intern(&lf[12],33,"\010compilerforeign-type-declaration");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[14]=C_h_intern(&lf[14],6,"gensym");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\005code_");
lf[16]=C_h_intern(&lf[16],16,"\003sysstrip-syntax");
lf[17]=C_h_intern(&lf[17],16,"\003syscheck-syntax");
lf[18]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[19]=C_h_intern(&lf[19],18,"\003syser-transformer");
lf[20]=C_h_intern(&lf[20],20,"foreign-safe-lambda\052");
lf[21]=C_h_intern(&lf[21],3,"map");
lf[22]=C_h_intern(&lf[22],9,"procedure");
lf[23]=C_h_intern(&lf[23],25,"\004coreforeign-safe-lambda\052");
lf[24]=C_h_intern(&lf[24],36,"\010compilerforeign-type->scrutiny-type");
lf[25]=C_h_intern(&lf[25],6,"result");
lf[26]=C_h_intern(&lf[26],3,"arg");
lf[27]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[28]=C_h_intern(&lf[28],19,"foreign-safe-lambda");
lf[29]=C_h_intern(&lf[29],24,"\004coreforeign-safe-lambda");
lf[30]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[31]=C_h_intern(&lf[31],15,"foreign-lambda\052");
lf[32]=C_h_intern(&lf[32],20,"\004coreforeign-lambda\052");
lf[33]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[34]=C_h_intern(&lf[34],14,"foreign-lambda");
lf[35]=C_h_intern(&lf[35],19,"\004coreforeign-lambda");
lf[36]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[37]=C_h_intern(&lf[37],17,"foreign-primitive");
lf[38]=C_h_intern(&lf[38],22,"\004coreforeign-primitive");
lf[39]=C_h_intern(&lf[39],1,"\052");
lf[40]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[41]=C_h_intern(&lf[41],23,"define-foreign-variable");
lf[42]=C_h_intern(&lf[42],19,"define-foreign-type");
lf[43]=C_h_intern(&lf[43],24,"\004coredefine-foreign-type");
lf[44]=C_h_intern(&lf[44],15,"foreign-declare");
lf[45]=C_h_intern(&lf[45],12,"\004coredeclare");
lf[46]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[47]=C_h_intern(&lf[47],13,"foreign-value");
lf[48]=C_h_intern(&lf[48],14,"symbol->string");
lf[49]=C_h_intern(&lf[49],12,"syntax-error");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\052bad argument type - not a string or symbol");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\005code_");
lf[52]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[53]=C_h_intern(&lf[53],12,"foreign-code");
lf[54]=C_h_intern(&lf[54],7,"sprintf");
lf[55]=C_h_intern(&lf[55],11,"\004coreinline");
lf[56]=C_h_intern(&lf[56],17,"get-output-string");
lf[57]=C_h_intern(&lf[57],9,"\003sysprint");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000 \012; return C_SCHEME_UNDEFINED; }\012");
lf[59]=C_h_intern(&lf[59],18,"string-intersperse");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\005() { ");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\016static C_word ");
lf[63]=C_h_intern(&lf[63],18,"open-output-string");
lf[64]=C_h_intern(&lf[64],7,"declare");
lf[65]=C_h_intern(&lf[65],5,"code_");
lf[66]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\006string\376\377\001\000\000\000\000");
lf[67]=C_h_intern(&lf[67],12,"let-location");
lf[68]=C_h_intern(&lf[68],8,"\004corelet");
lf[69]=C_h_intern(&lf[69],17,"\004corelet-location");
lf[70]=C_h_intern(&lf[70],10,"fold-right");
lf[71]=C_h_intern(&lf[71],10,"append-map");
lf[72]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\000\376\001\000\000\001_");
lf[73]=C_h_intern(&lf[73],15,"define-location");
lf[74]=C_h_intern(&lf[74],29,"\004coredefine-external-variable");
lf[75]=C_h_intern(&lf[75],9,"\004coreset!");
lf[76]=C_h_intern(&lf[76],5,"begin");
lf[77]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[78]=C_h_intern(&lf[78],8,"location");
lf[79]=C_h_intern(&lf[79],13,"\004corelocation");
lf[80]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010location\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[81]=C_h_intern(&lf[81],15,"define-external");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[83]=C_h_intern(&lf[83],5,"quote");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[85]=C_h_intern(&lf[85],29,"\004coreforeign-callback-wrapper");
lf[86]=C_h_intern(&lf[86],6,"lambda");
lf[87]=C_h_intern(&lf[87],6,"define");
lf[88]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376"
"\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[89]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[90]=C_h_intern(&lf[90],21,"\003sysmacro-environment");
lf[91]=C_h_intern(&lf[91],11,"\003sysprovide");
lf[92]=C_h_intern(&lf[92],18,"chicken-ffi-syntax");
C_register_lf2(lf,93,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_790,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:38: ##sys#provide */
t3=*((C_word*)lf[91]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[92];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k1464 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1466(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1466,2,av);}
/* chicken-ffi-syntax.scm:182: ##sys#extend-macro-environment */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[44];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a1467 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1468(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1468,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1472,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:187: ##sys#check-syntax */
t6=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[44];
av2[3]=t2;
av2[4]=lf[46];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* a1172 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1173(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1173,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1177,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:230: ##sys#check-syntax */
t6=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[34];
av2[3]=t2;
av2[4]=lf[36];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k1175 in a1172 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1177(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_1177,2,av);}
a=C_alloc(11);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_i_cdddr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:233: ##sys#strip-syntax */
t8=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k1470 in a1467 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1472(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_1472,2,av);}
a=C_alloc(9);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,lf[44],t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,lf[45],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1169 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1171,2,av);}
/* chicken-ffi-syntax.scm:225: ##sys#extend-macro-environment */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[34];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop373 in k1014 in k989 in a986 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_fcall f_1036(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_1036,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1061,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[24]+1);
/* chicken-ffi-syntax.scm:260: g396 */
t6=*((C_word*)lf[24]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[26];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1778 in k1763 in a1760 in k798 in k795 in k792 in k788 */
static void C_ccall f_1780(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_1780,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-ffi-syntax.scm:100: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[76];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a1488 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1489(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1489,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1493,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:161: ##sys#check-syntax */
t6=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[47];
av2[3]=t2;
av2[4]=lf[52];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k1485 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1487(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1487,2,av);}
/* chicken-ffi-syntax.scm:156: ##sys#extend-macro-environment */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[47];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a847 in k834 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_848,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_852,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:286: ##sys#check-syntax */
t6=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[3];
av2[3]=t2;
av2[4]=lf[18];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k844 in k834 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_846(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_846,2,av);}
/* chicken-ffi-syntax.scm:281: ##sys#extend-macro-environment */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[3];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1200 in k1175 in a1172 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_1202,2,av);}
a=C_alloc(12);
t2=C_i_check_list_2(t1,lf[21]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1222,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word)li7),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1222(t7,t3,t1);}

/* k840 in k837 in k834 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_842(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_842,2,av);}
t2=C_mutate2((C_word*)lf[0]+1 /* (set! ##sys#chicken-ffi-macro-environment ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1206 in k1200 in k1175 in a1172 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1208(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_1208,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1212,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1216,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:235: ##sys#strip-syntax */
t6=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* a891 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_892,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_896,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:272: ##sys#check-syntax */
t6=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[20];
av2[3]=t2;
av2[4]=lf[27];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k1494 in k1491 in a1488 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1496(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,4))){C_save_and_reclaim((void *)f_1496,2,av);}
a=C_alloc(22);
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1506,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=C_i_caddr(((C_word*)t0)[2]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1530,a[2]=t4,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_stringp(t3))){
t8=t4;
f_1506(t8,C_a_i_list(&a,4,lf[4],t2,t6,t3));}
else{
if(C_truep(C_i_symbolp(t3))){
/* chicken-ffi-syntax.scm:168: symbol->string */
t8=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
/* chicken-ffi-syntax.scm:170: syntax-error */
t8=*((C_word*)lf[49]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[47];
av2[3]=lf[50];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}}}

/* k888 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_890,2,av);}
/* chicken-ffi-syntax.scm:267: ##sys#extend-macro-environment */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[20];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1491 in a1488 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1493(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1493,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:162: gensym */
t3=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[51];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k894 in a891 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_896(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_896,2,av);}
a=C_alloc(11);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_i_caddr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:275: ##sys#strip-syntax */
t8=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k874 in k859 in k856 in k853 in k850 in a847 in k834 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 in ... */
static void C_ccall f_876(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,1))){C_save_and_reclaim((void *)f_876,2,av);}
a=C_alloc(33);
t2=C_a_i_list(&a,4,lf[4],((C_word*)t0)[2],lf[5],t1);
t3=C_a_i_list(&a,4,lf[6],lf[7],C_SCHEME_FALSE,((C_word*)t0)[2]);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[8],t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1746 in map-loop119 in k1618 in a1615 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1748(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1748,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1723(t6,((C_word*)t0)[5],t5);}

/* a1760 in k798 in k795 in k792 in k788 */
static void C_ccall f_1761(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_1761,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1765,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:95: ##sys#check-syntax */
t6=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[73];
av2[3]=t2;
av2[4]=lf[77];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* a1077 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1078(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1078,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1082,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:244: ##sys#check-syntax */
t6=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[31];
av2[3]=t2;
av2[4]=lf[33];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k856 in k853 in k850 in a847 in k834 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_858(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_858,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_861,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
f_861(2,av2);}}
else{
/* chicken-ffi-syntax.scm:292: ##compiler#foreign-type-declaration */
t4=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[13];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k1074 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1076,2,av);}
/* chicken-ffi-syntax.scm:239: ##sys#extend-macro-environment */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[31];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k853 in k850 in a847 in k834 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_855(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_855,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_858,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:288: gensym */
t4=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[15];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k850 in a847 in k834 in k831 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_852,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_855,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* chicken-ffi-syntax.scm:287: ##sys#strip-syntax */
t4=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* map-loop119 in k1618 in a1615 in k801 in k798 in k795 in k792 in k788 */
static void C_fcall f_1723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_1723,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1748,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-ffi-syntax.scm:115: g125 */
t4=((C_word*)t0)[4];
f_1629(t4,t3);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* map-loop33 in k1940 in k1927 in k1864 in k1861 in a1855 in k792 in k788 */
static void C_fcall f_2049(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_2049,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2045 in k1940 in k1927 in k1864 in k1861 in a1855 in k792 in k788 */
static void C_ccall f_2047(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,2))){C_save_and_reclaim((void *)f_2047,2,av);}
a=C_alloc(18);
t2=C_a_i_list(&a,2,lf[83],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-ffi-syntax.scm:74: r */
t5=((C_word*)t0)[11];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[86];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1080 in a1077 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1082(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_1082,2,av);}
a=C_alloc(11);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_i_caddr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:247: ##sys#strip-syntax */
t8=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k1986 in k1970 in k2045 in k1940 in k1927 in k1864 in k1861 in a1855 in k792 in k788 */
static void C_ccall f_1988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,1))){C_save_and_reclaim((void *)f_1988,2,av);}
a=C_alloc(33);
t2=(C_truep(((C_word*)t0)[2])?C_i_cdddr(((C_word*)t0)[3]):C_i_cddr(((C_word*)t0)[3]));
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_list(&a,6,lf[85],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],t4);
t6=((C_word*)t0)[9];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,((C_word*)t0)[10],((C_word*)t0)[11],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k1763 in a1760 in k798 in k795 in k792 in k788 */
static void C_ccall f_1765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_1765,2,av);}
a=C_alloc(11);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:C_i_car(t9));
t12=t11;
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1780,a[2]=t3,a[3]=t5,a[4]=t12,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1827,a[2]=((C_word*)t0)[4],a[3]=t13,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:99: gensym */
t15=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}

/* k1272 in k1269 in k1266 in a1263 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1274(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_1274,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(((C_word*)t0)[4])?C_i_caddr(((C_word*)t0)[2]):C_i_cadr(((C_word*)t0)[2]));
/* chicken-ffi-syntax.scm:215: ##sys#strip-syntax */
t5=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1275 in k1272 in k1269 in k1266 in a1263 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1277(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_1277,2,av);}
a=C_alloc(18);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=C_i_check_list_2(t1,lf[21]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1368,a[2]=t4,a[3]=t9,a[4]=t5,a[5]=((C_word)li10),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_1368(t11,t7,t1);}

/* a1699 in k1641 in k1618 in a1615 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_1700,4,av);}
a=C_alloc(6);
t4=C_i_cddr(t2);
if(C_truep(C_i_pairp(t4))){
t5=t2;
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=C_a_i_cons(&a,2,t3,t7);
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_a_i_list1(&a,1,t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k1269 in k1266 in a1263 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_fcall f_1271(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1271,2,t0,t1);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_car(t5);
/* chicken-ffi-syntax.scm:214: ##sys#strip-syntax */
t7=*((C_word*)lf[16]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t3;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_1274(2,av2);}}}

/* k1014 in k989 in a986 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1016(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_1016,2,av);}
a=C_alloc(12);
t2=C_i_check_list_2(t1,lf[21]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1036,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1036(t7,t3,t1);}

/* k1028 in k1020 in k1014 in k989 in a986 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1030(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1030,2,av);}
/* chicken-ffi-syntax.scm:262: ##compiler#foreign-type->scrutiny-type */
t2=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[25];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1970 in k2045 in k1940 in k1927 in k1864 in k1861 in a1855 in k792 in k788 */
static void C_ccall f_1972(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,3))){C_save_and_reclaim((void *)f_1972,2,av);}
a=C_alloc(25);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2000,a[2]=t5,a[3]=t9,a[4]=t6,a[5]=((C_word)li24),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2000(t11,t7,((C_word*)t0)[11]);}

/* k1757 in k798 in k795 in k792 in k788 */
static void C_ccall f_1759(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1759,2,av);}
/* chicken-ffi-syntax.scm:90: ##sys#extend-macro-environment */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[73];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1284 in k1275 in k1272 in k1269 in k1266 in a1263 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1286(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,3))){C_save_and_reclaim((void *)f_1286,2,av);}
a=C_alloc(21);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_check_list_2(t1,lf[21]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1334,a[2]=t5,a[3]=t10,a[4]=t6,a[5]=((C_word)li9),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_1334(t12,t8,t1);}

/* k1115 in k1109 in k1080 in a1077 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1117(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_1117,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1121,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1125,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:249: ##sys#strip-syntax */
t6=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k1024 in k1020 in k1014 in k989 in a986 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1026(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,1))){C_save_and_reclaim((void *)f_1026,2,av);}
a=C_alloc(24);
t2=C_a_i_list(&a,3,lf[22],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=C_a_i_cons(&a,2,lf[29],t4);
t6=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_list(&a,4,lf[6],t2,C_SCHEME_FALSE,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k1109 in k1080 in a1077 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1111(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_1111,2,av);}
a=C_alloc(12);
t2=C_i_check_list_2(t1,lf[21]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1131,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1131(t7,t3,t1);}

/* k1020 in k1014 in k989 in a986 in k828 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1022(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_1022,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1026,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1030,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* chicken-ffi-syntax.scm:263: ##sys#strip-syntax */
t6=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* a1855 in k792 in k788 */
static void C_ccall f_1856(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_1856,5,av);}
a=C_alloc(5);
t5=C_i_cdr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1863,a[2]=t6,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t6))){
t8=C_u_i_car(t6);
t9=t7;
f_1863(t9,C_i_stringp(t8));}
else{
t8=t7;
f_1863(t8,C_SCHEME_FALSE);}}

/* k1852 in k792 in k788 */
static void C_ccall f_1854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1854,2,av);}
/* chicken-ffi-syntax.scm:45: ##sys#extend-macro-environment */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[81];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1597 in k1594 in k1591 in k1588 in k1585 in k1579 in k1571 in k1556 in k1553 in a1550 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1599(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_1599,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-ffi-syntax.scm:151: get-output-string */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k1594 in k1591 in k1588 in k1585 in k1579 in k1571 in k1556 in k1553 in a1550 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1596(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_1596,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-ffi-syntax.scm:151: ##sys#print */
t3=*((C_word*)lf[57]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[58];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1591 in k1588 in k1585 in k1579 in k1571 in k1556 in k1553 in a1550 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1593(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_1593,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1606,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[7]);
/* chicken-ffi-syntax.scm:153: string-intersperse */
t5=*((C_word*)lf[59]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[60];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k1123 in k1115 in k1109 in k1080 in a1077 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1125(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1125,2,av);}
/* chicken-ffi-syntax.scm:248: ##compiler#foreign-type->scrutiny-type */
t2=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[25];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1588 in k1585 in k1579 in k1571 in k1556 in k1553 in a1550 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1590(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_1590,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-ffi-syntax.scm:151: ##sys#print */
t3=*((C_word*)lf[57]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[61];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1119 in k1115 in k1109 in k1080 in a1077 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1121(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,1))){C_save_and_reclaim((void *)f_1121,2,av);}
a=C_alloc(24);
t2=C_a_i_list(&a,3,lf[22],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=C_a_i_cons(&a,2,lf[32],t4);
t6=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_list(&a,4,lf[6],t2,C_SCHEME_FALSE,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* map-loop339 in k1109 in k1080 in a1077 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_fcall f_1131(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_1131,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1156,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
/* chicken-ffi-syntax.scm:246: ##compiler#foreign-type->scrutiny-type */
t6=*((C_word*)lf[24]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
av2[3]=lf[26];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1841 in a1838 in k795 in k792 in k788 */
static void C_ccall f_1843(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_1843,2,av);}
a=C_alloc(6);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[79],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1330 in k1316 in k1284 in k1275 in k1272 in k1269 in k1266 in a1263 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1332(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_1332,2,av);}
a=C_alloc(6);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
f_1303(t3,C_a_i_cons(&a,2,((C_word*)t0)[3],t2));}

/* map-loop257 in k1284 in k1275 in k1272 in k1269 in k1266 in a1263 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_fcall f_1334(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_1334,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1359,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[24]+1);
/* chicken-ffi-syntax.scm:218: g280 */
t6=*((C_word*)lf[24]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[26];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1835 in k795 in k792 in k788 */
static void C_ccall f_1837(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1837,2,av);}
/* chicken-ffi-syntax.scm:82: ##sys#extend-macro-environment */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[78];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a1838 in k795 in k792 in k788 */
static void C_ccall f_1839(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1839,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1843,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:87: ##sys#check-syntax */
t6=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[78];
av2[3]=t2;
av2[4]=lf[80];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k1316 in k1284 in k1275 in k1272 in k1269 in k1266 in a1263 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1318(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1318,2,av);}
a=C_alloc(4);
t2=t1;
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1332,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-ffi-syntax.scm:221: ##compiler#foreign-type->scrutiny-type */
t4=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[25];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=((C_word*)t0)[3];
f_1303(t3,C_a_i_cons(&a,2,t2,lf[39]));}}

/* k1528 in k1494 in k1491 in a1488 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1530(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_1530,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];
f_1506(t2,C_a_i_list(&a,4,lf[4],((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* k1301 in k1284 in k1275 in k1272 in k1269 in k1266 in a1263 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_fcall f_1303(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(18,0,1))){
C_save_and_reclaim_args((void *)trf_1303,2,t0,t1);}
a=C_alloc(18);
t2=C_a_i_cons(&a,2,lf[22],t1);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_a_i_cons(&a,2,lf[38],t4);
t6=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t6;
av2[1]=C_a_i_list(&a,4,lf[6],t2,C_SCHEME_FALSE,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k1547 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1549(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1549,2,av);}
/* chicken-ffi-syntax.scm:141: ##sys#extend-macro-environment */
t2=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[53];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1154 in map-loop339 in k1109 in k1080 in a1077 in k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_1156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1156,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1131(t6,((C_word*)t0)[5],t5);}

/* k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_824(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_824,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1171,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1173,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:228: ##sys#er-transformer */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k825 in k822 in k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_827,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1076,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1078,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:242: ##sys#er-transformer */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k819 in k816 in k813 in k810 in k807 in k804 in k801 in k798 in k795 in k792 in k788 */
static void C_ccall f_821(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_821,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1262,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1264,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
/* chicken-ffi-syntax.scm:210: ##sys#er-transformer */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[139] = {
{"f_1216:chicken_2dffi_2dsyntax_2escm",(void*)f_1216},
{"f_1212:chicken_2dffi_2dsyntax_2escm",(void*)f_1212},
{"f_790:chicken_2dffi_2dsyntax_2escm",(void*)f_790},
{"f_797:chicken_2dffi_2dsyntax_2escm",(void*)f_797},
{"f_794:chicken_2dffi_2dsyntax_2escm",(void*)f_794},
{"f_803:chicken_2dffi_2dsyntax_2escm",(void*)f_803},
{"f_809:chicken_2dffi_2dsyntax_2escm",(void*)f_809},
{"f_806:chicken_2dffi_2dsyntax_2escm",(void*)f_806},
{"f_800:chicken_2dffi_2dsyntax_2escm",(void*)f_800},
{"f_1637:chicken_2dffi_2dsyntax_2escm",(void*)f_1637},
{"f_1573:chicken_2dffi_2dsyntax_2escm",(void*)f_1573},
{"f_1222:chicken_2dffi_2dsyntax_2escm",(void*)f_1222},
{"f_833:chicken_2dffi_2dsyntax_2escm",(void*)f_833},
{"f_836:chicken_2dffi_2dsyntax_2escm",(void*)f_836},
{"f_839:chicken_2dffi_2dsyntax_2escm",(void*)f_839},
{"f_830:chicken_2dffi_2dsyntax_2escm",(void*)f_830},
{"f_1866:chicken_2dffi_2dsyntax_2escm",(void*)f_1866},
{"f_1942:chicken_2dffi_2dsyntax_2escm",(void*)f_1942},
{"f_1587:chicken_2dffi_2dsyntax_2escm",(void*)f_1587},
{"f_1581:chicken_2dffi_2dsyntax_2escm",(void*)f_1581},
{"f_1863:chicken_2dffi_2dsyntax_2escm",(void*)f_1863},
{"f_1929:chicken_2dffi_2dsyntax_2escm",(void*)f_1929},
{"f_861:chicken_2dffi_2dsyntax_2escm",(void*)f_861},
{"f_1654:chicken_2dffi_2dsyntax_2escm",(void*)f_1654},
{"f_1656:chicken_2dffi_2dsyntax_2escm",(void*)f_1656},
{"f_1247:chicken_2dffi_2dsyntax_2escm",(void*)f_1247},
{"f_1650:chicken_2dffi_2dsyntax_2escm",(void*)f_1650},
{"f_815:chicken_2dffi_2dsyntax_2escm",(void*)f_815},
{"f_812:chicken_2dffi_2dsyntax_2escm",(void*)f_812},
{"f_991:chicken_2dffi_2dsyntax_2escm",(void*)f_991},
{"f_818:chicken_2dffi_2dsyntax_2escm",(void*)f_818},
{"f_2000:chicken_2dffi_2dsyntax_2escm",(void*)f_2000},
{"f_1629:chicken_2dffi_2dsyntax_2escm",(void*)f_1629},
{"f_1620:chicken_2dffi_2dsyntax_2escm",(void*)f_1620},
{"f_1514:chicken_2dffi_2dsyntax_2escm",(void*)f_1514},
{"f_1518:chicken_2dffi_2dsyntax_2escm",(void*)f_1518},
{"f_1264:chicken_2dffi_2dsyntax_2escm",(void*)f_1264},
{"f_1262:chicken_2dffi_2dsyntax_2escm",(void*)f_1262},
{"f_1268:chicken_2dffi_2dsyntax_2escm",(void*)f_1268},
{"f_1827:chicken_2dffi_2dsyntax_2escm",(void*)f_1827},
{"f_1823:chicken_2dffi_2dsyntax_2escm",(void*)f_1823},
{"f_1506:chicken_2dffi_2dsyntax_2escm",(void*)f_1506},
{"f_970:chicken_2dffi_2dsyntax_2escm",(void*)f_970},
{"f_987:chicken_2dffi_2dsyntax_2escm",(void*)f_987},
{"f_985:chicken_2dffi_2dsyntax_2escm",(void*)f_985},
{"f_1882:chicken_2dffi_2dsyntax_2escm",(void*)f_1882},
{"f_1606:chicken_2dffi_2dsyntax_2escm",(void*)f_1606},
{"f_1602:chicken_2dffi_2dsyntax_2escm",(void*)f_1602},
{"f_1872:chicken_2dffi_2dsyntax_2escm",(void*)f_1872},
{"f_1359:chicken_2dffi_2dsyntax_2escm",(void*)f_1359},
{"f_925:chicken_2dffi_2dsyntax_2escm",(void*)f_925},
{"f_1555:chicken_2dffi_2dsyntax_2escm",(void*)f_1555},
{"f_1558:chicken_2dffi_2dsyntax_2escm",(void*)f_1558},
{"f_1551:chicken_2dffi_2dsyntax_2escm",(void*)f_1551},
{"f_1614:chicken_2dffi_2dsyntax_2escm",(void*)f_1614},
{"f_1616:chicken_2dffi_2dsyntax_2escm",(void*)f_1616},
{"f_939:chicken_2dffi_2dsyntax_2escm",(void*)f_939},
{"f_935:chicken_2dffi_2dsyntax_2escm",(void*)f_935},
{"f_931:chicken_2dffi_2dsyntax_2escm",(void*)f_931},
{"f_1787:chicken_2dffi_2dsyntax_2escm",(void*)f_1787},
{"f_945:chicken_2dffi_2dsyntax_2escm",(void*)f_945},
{"f_1368:chicken_2dffi_2dsyntax_2escm",(void*)f_1368},
{"f_1440:chicken_2dffi_2dsyntax_2escm",(void*)f_1440},
{"f_1438:chicken_2dffi_2dsyntax_2escm",(void*)f_1438},
{"f_1061:chicken_2dffi_2dsyntax_2escm",(void*)f_1061},
{"f_1643:chicken_2dffi_2dsyntax_2escm",(void*)f_1643},
{"f_1454:chicken_2dffi_2dsyntax_2escm",(void*)f_1454},
{"f_1452:chicken_2dffi_2dsyntax_2escm",(void*)f_1452},
{"toplevel:chicken_2dffi_2dsyntax_2escm",(void*)C_chicken_2dffi_2dsyntax_toplevel},
{"f_1466:chicken_2dffi_2dsyntax_2escm",(void*)f_1466},
{"f_1468:chicken_2dffi_2dsyntax_2escm",(void*)f_1468},
{"f_1173:chicken_2dffi_2dsyntax_2escm",(void*)f_1173},
{"f_1177:chicken_2dffi_2dsyntax_2escm",(void*)f_1177},
{"f_1472:chicken_2dffi_2dsyntax_2escm",(void*)f_1472},
{"f_1171:chicken_2dffi_2dsyntax_2escm",(void*)f_1171},
{"f_1036:chicken_2dffi_2dsyntax_2escm",(void*)f_1036},
{"f_1780:chicken_2dffi_2dsyntax_2escm",(void*)f_1780},
{"f_1489:chicken_2dffi_2dsyntax_2escm",(void*)f_1489},
{"f_1487:chicken_2dffi_2dsyntax_2escm",(void*)f_1487},
{"f_848:chicken_2dffi_2dsyntax_2escm",(void*)f_848},
{"f_846:chicken_2dffi_2dsyntax_2escm",(void*)f_846},
{"f_1202:chicken_2dffi_2dsyntax_2escm",(void*)f_1202},
{"f_842:chicken_2dffi_2dsyntax_2escm",(void*)f_842},
{"f_1208:chicken_2dffi_2dsyntax_2escm",(void*)f_1208},
{"f_892:chicken_2dffi_2dsyntax_2escm",(void*)f_892},
{"f_1496:chicken_2dffi_2dsyntax_2escm",(void*)f_1496},
{"f_890:chicken_2dffi_2dsyntax_2escm",(void*)f_890},
{"f_1493:chicken_2dffi_2dsyntax_2escm",(void*)f_1493},
{"f_896:chicken_2dffi_2dsyntax_2escm",(void*)f_896},
{"f_876:chicken_2dffi_2dsyntax_2escm",(void*)f_876},
{"f_1748:chicken_2dffi_2dsyntax_2escm",(void*)f_1748},
{"f_1761:chicken_2dffi_2dsyntax_2escm",(void*)f_1761},
{"f_1078:chicken_2dffi_2dsyntax_2escm",(void*)f_1078},
{"f_858:chicken_2dffi_2dsyntax_2escm",(void*)f_858},
{"f_1076:chicken_2dffi_2dsyntax_2escm",(void*)f_1076},
{"f_855:chicken_2dffi_2dsyntax_2escm",(void*)f_855},
{"f_852:chicken_2dffi_2dsyntax_2escm",(void*)f_852},
{"f_1723:chicken_2dffi_2dsyntax_2escm",(void*)f_1723},
{"f_2049:chicken_2dffi_2dsyntax_2escm",(void*)f_2049},
{"f_2047:chicken_2dffi_2dsyntax_2escm",(void*)f_2047},
{"f_1082:chicken_2dffi_2dsyntax_2escm",(void*)f_1082},
{"f_1988:chicken_2dffi_2dsyntax_2escm",(void*)f_1988},
{"f_1765:chicken_2dffi_2dsyntax_2escm",(void*)f_1765},
{"f_1274:chicken_2dffi_2dsyntax_2escm",(void*)f_1274},
{"f_1277:chicken_2dffi_2dsyntax_2escm",(void*)f_1277},
{"f_1700:chicken_2dffi_2dsyntax_2escm",(void*)f_1700},
{"f_1271:chicken_2dffi_2dsyntax_2escm",(void*)f_1271},
{"f_1016:chicken_2dffi_2dsyntax_2escm",(void*)f_1016},
{"f_1030:chicken_2dffi_2dsyntax_2escm",(void*)f_1030},
{"f_1972:chicken_2dffi_2dsyntax_2escm",(void*)f_1972},
{"f_1759:chicken_2dffi_2dsyntax_2escm",(void*)f_1759},
{"f_1286:chicken_2dffi_2dsyntax_2escm",(void*)f_1286},
{"f_1117:chicken_2dffi_2dsyntax_2escm",(void*)f_1117},
{"f_1026:chicken_2dffi_2dsyntax_2escm",(void*)f_1026},
{"f_1111:chicken_2dffi_2dsyntax_2escm",(void*)f_1111},
{"f_1022:chicken_2dffi_2dsyntax_2escm",(void*)f_1022},
{"f_1856:chicken_2dffi_2dsyntax_2escm",(void*)f_1856},
{"f_1854:chicken_2dffi_2dsyntax_2escm",(void*)f_1854},
{"f_1599:chicken_2dffi_2dsyntax_2escm",(void*)f_1599},
{"f_1596:chicken_2dffi_2dsyntax_2escm",(void*)f_1596},
{"f_1593:chicken_2dffi_2dsyntax_2escm",(void*)f_1593},
{"f_1125:chicken_2dffi_2dsyntax_2escm",(void*)f_1125},
{"f_1590:chicken_2dffi_2dsyntax_2escm",(void*)f_1590},
{"f_1121:chicken_2dffi_2dsyntax_2escm",(void*)f_1121},
{"f_1131:chicken_2dffi_2dsyntax_2escm",(void*)f_1131},
{"f_1843:chicken_2dffi_2dsyntax_2escm",(void*)f_1843},
{"f_1332:chicken_2dffi_2dsyntax_2escm",(void*)f_1332},
{"f_1334:chicken_2dffi_2dsyntax_2escm",(void*)f_1334},
{"f_1837:chicken_2dffi_2dsyntax_2escm",(void*)f_1837},
{"f_1839:chicken_2dffi_2dsyntax_2escm",(void*)f_1839},
{"f_1318:chicken_2dffi_2dsyntax_2escm",(void*)f_1318},
{"f_1530:chicken_2dffi_2dsyntax_2escm",(void*)f_1530},
{"f_1303:chicken_2dffi_2dsyntax_2escm",(void*)f_1303},
{"f_1549:chicken_2dffi_2dsyntax_2escm",(void*)f_1549},
{"f_1156:chicken_2dffi_2dsyntax_2escm",(void*)f_1156},
{"f_824:chicken_2dffi_2dsyntax_2escm",(void*)f_824},
{"f_827:chicken_2dffi_2dsyntax_2escm",(void*)f_827},
{"f_821:chicken_2dffi_2dsyntax_2escm",(void*)f_821},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  sprintf		1
S|  map		9
o|eliminated procedure checks: 98 
o|specializations:
o|  5 (cdr pair)
o|  1 (##sys#check-output-port * * *)
o|  1 (= fixnum fixnum)
o|  1 (cdddr (pair * (pair * pair)))
o|  1 (##sys#check-list (or pair list) *)
o|  3 (cddr (pair * pair))
o|  2 (cadr (pair * pair))
o|  5 (car pair)
(o e)|safe calls: 191 
o|Removed `not' forms: 2 
o|inlining procedure: k947 
o|contracted procedure: "(chicken-ffi-syntax.scm:274) g420429" 
o|inlining procedure: k947 
o|inlining procedure: k1038 
o|contracted procedure: "(chicken-ffi-syntax.scm:260) g379388" 
o|propagated global variable: g396397 ##compiler#foreign-type->scrutiny-type 
o|inlining procedure: k1038 
o|inlining procedure: k1133 
o|contracted procedure: "(chicken-ffi-syntax.scm:246) g345354" 
o|inlining procedure: k1133 
o|inlining procedure: k1224 
o|contracted procedure: "(chicken-ffi-syntax.scm:232) g304313" 
o|propagated global variable: g321322 ##compiler#foreign-type->scrutiny-type 
o|inlining procedure: k1224 
o|contracted procedure: k1323 
o|inlining procedure: k1320 
o|inlining procedure: k1320 
o|inlining procedure: k1336 
o|contracted procedure: "(chicken-ffi-syntax.scm:218) g263272" 
o|propagated global variable: g280281 ##compiler#foreign-type->scrutiny-type 
o|inlining procedure: k1336 
o|inlining procedure: k1370 
o|inlining procedure: k1370 
o|inlining procedure: k1402 
o|inlining procedure: k1402 
o|inlining procedure: k1528 
o|inlining procedure: k1528 
o|substituted constant variable: a1583 
o|substituted constant variable: a1584 
o|removed unused formal parameters: (_136) 
o|inlining procedure: k1658 
o|inlining procedure: k1658 
o|substituted constant variable: a1686 
o|inlining procedure: k1702 
o|inlining procedure: k1702 
o|inlining procedure: k1725 
o|removed unused parameter to known procedure: _136 "(chicken-ffi-syntax.scm:115) g125134" 
o|inlining procedure: k1725 
o|inlining procedure: k1805 
o|inlining procedure: k1805 
o|inlining procedure: k1867 
o|inlining procedure: k1900 
o|inlining procedure: k1900 
o|inlining procedure: k1867 
o|inlining procedure: k1990 
o|inlining procedure: k1990 
o|inlining procedure: k2002 
o|contracted procedure: "(chicken-ffi-syntax.scm:75) g6675" 
o|inlining procedure: k2002 
o|inlining procedure: k2051 
o|contracted procedure: "(chicken-ffi-syntax.scm:73) g3948" 
o|inlining procedure: k2051 
o|inlining procedure: k2083 
o|inlining procedure: k2083 
o|contracted procedure: k2109 
o|inlining procedure: k2112 
o|inlining procedure: k2112 
o|replaced variables: 196 
o|removed binding forms: 82 
o|substituted constant variable: r13212141 
o|substituted constant variable: r13212141 
o|substituted constant variable: r17032158 
o|substituted constant variable: r18062163 
o|substituted constant variable: r18062163 
o|substituted constant variable: r19012168 
o|substituted constant variable: r19012168 
o|substituted constant variable: r21132184 
o|replaced variables: 4 
o|removed binding forms: 213 
o|removed call to pure procedure with unused result: "(chicken-ffi-syntax.scm:115) slot" 
o|replaced variables: 12 
o|removed binding forms: 12 
o|contracted procedure: k1750 
o|removed binding forms: 13 
o|removed binding forms: 1 
o|simplifications: ((if . 6) (##core#call . 197)) 
o|  call simplifications:
o|    null?
o|    length
o|    eq?
o|    symbol?	2
o|    cdr	6
o|    cddr	3
o|    not
o|    list	2
o|    cdddr	3
o|    caddr	9
o|    ##sys#check-list	8
o|    pair?	15
o|    car	10
o|    cons	19
o|    ##sys#setslot	9
o|    ##sys#slot	26
o|    ##sys#cons	23
o|    cadr	16
o|    string?	4
o|    ##sys#list	38
o|contracted procedure: k866 
o|contracted procedure: k870 
o|contracted procedure: k877 
o|contracted procedure: k884 
o|contracted procedure: k911 
o|contracted procedure: k926 
o|contracted procedure: k901 
o|contracted procedure: k905 
o|contracted procedure: k941 
o|contracted procedure: k950 
o|contracted procedure: k953 
o|contracted procedure: k956 
o|contracted procedure: k964 
o|contracted procedure: k972 
o|contracted procedure: k920 
o|contracted procedure: k979 
o|contracted procedure: k1006 
o|contracted procedure: k1017 
o|contracted procedure: k996 
o|contracted procedure: k1000 
o|contracted procedure: k1032 
o|contracted procedure: k1041 
o|contracted procedure: k1044 
o|contracted procedure: k1047 
o|contracted procedure: k1055 
o|contracted procedure: k1063 
o|contracted procedure: k1070 
o|contracted procedure: k1097 
o|contracted procedure: k1112 
o|contracted procedure: k1087 
o|contracted procedure: k1091 
o|contracted procedure: k1127 
o|contracted procedure: k1136 
o|contracted procedure: k1139 
o|contracted procedure: k1142 
o|contracted procedure: k1150 
o|contracted procedure: k1158 
o|contracted procedure: k1106 
o|contracted procedure: k1165 
o|contracted procedure: k1192 
o|contracted procedure: k1203 
o|contracted procedure: k1182 
o|contracted procedure: k1186 
o|contracted procedure: k1218 
o|contracted procedure: k1227 
o|contracted procedure: k1230 
o|contracted procedure: k1233 
o|contracted procedure: k1241 
o|contracted procedure: k1249 
o|contracted procedure: k1256 
o|contracted procedure: k1278 
o|contracted procedure: k1281 
o|contracted procedure: k1291 
o|contracted procedure: k1295 
o|contracted procedure: k1305 
o|contracted procedure: k1313 
o|contracted procedure: k1320 
o|contracted procedure: k1339 
o|contracted procedure: k1342 
o|contracted procedure: k1345 
o|contracted procedure: k1353 
o|contracted procedure: k1361 
o|contracted procedure: k1373 
o|contracted procedure: k1395 
o|contracted procedure: k1391 
o|contracted procedure: k1376 
o|contracted procedure: k1379 
o|contracted procedure: k1387 
o|contracted procedure: k1402 
o|contracted procedure: k1432 
o|contracted procedure: k1417 
o|contracted procedure: k1428 
o|contracted procedure: k1424 
o|contracted procedure: k1446 
o|contracted procedure: k1460 
o|contracted procedure: k1481 
o|contracted procedure: k1477 
o|contracted procedure: k1497 
o|contracted procedure: k1508 
o|contracted procedure: k1520 
o|contracted procedure: k1524 
o|contracted procedure: k1531 
o|contracted procedure: k1537 
o|contracted procedure: k1575 
o|contracted procedure: k1563 
o|contracted procedure: k1567 
o|contracted procedure: k1608 
o|contracted procedure: k1621 
o|contracted procedure: k1626 
o|contracted procedure: k1638 
o|contracted procedure: k1688 
o|contracted procedure: k1661 
o|contracted procedure: k1668 
o|contracted procedure: k1672 
o|contracted procedure: k1679 
o|contracted procedure: k1683 
o|contracted procedure: k1696 
o|contracted procedure: k1692 
o|contracted procedure: k1719 
o|contracted procedure: k1705 
o|contracted procedure: k1712 
o|contracted procedure: k1728 
o|contracted procedure: k1731 
o|contracted procedure: k1734 
o|contracted procedure: k1742 
o|contracted procedure: k1766 
o|contracted procedure: k1769 
o|contracted procedure: k1828 
o|contracted procedure: k1775 
o|contracted procedure: k1793 
o|contracted procedure: k1789 
o|contracted procedure: k1801 
o|contracted procedure: k1808 
o|contracted procedure: k1815 
o|contracted procedure: k1805 
o|contracted procedure: k1848 
o|contracted procedure: k1858 
o|contracted procedure: k1873 
o|contracted procedure: k1924 
o|contracted procedure: k1888 
o|contracted procedure: k1884 
o|contracted procedure: k1896 
o|contracted procedure: k1903 
o|contracted procedure: k1914 
o|contracted procedure: k1910 
o|contracted procedure: k1900 
o|contracted procedure: k1930 
o|contracted procedure: k1933 
o|contracted procedure: k1950 
o|contracted procedure: k1954 
o|contracted procedure: k2083 
o|contracted procedure: k1958 
o|contracted procedure: k2034 
o|contracted procedure: k2042 
o|contracted procedure: k1962 
o|contracted procedure: k1978 
o|contracted procedure: k1990 
o|contracted procedure: k1974 
o|contracted procedure: k1966 
o|contracted procedure: k1946 
o|contracted procedure: k2005 
o|contracted procedure: k2027 
o|contracted procedure: k2023 
o|contracted procedure: k2008 
o|contracted procedure: k2011 
o|contracted procedure: k2019 
o|contracted procedure: k2054 
o|contracted procedure: k2076 
o|contracted procedure: k2072 
o|contracted procedure: k2057 
o|contracted procedure: k2060 
o|contracted procedure: k2068 
o|contracted procedure: k2115 
o|contracted procedure: k2123 
o|simplifications: ((let . 18)) 
o|removed binding forms: 154 
o|inlining procedure: k1797 
o|inlining procedure: k1797 
o|inlining procedure: k1892 
o|inlining procedure: k1892 
o|replaced variables: 57 
o|removed binding forms: 36 
o|replaced variables: 6 
o|removed binding forms: 3 
o|customizable procedures: (k1861 k1864 map-loop3351 map-loop6078 g125134 map-loop119137 k1504 k1269 map-loop228245 map-loop257282 k1301 map-loop298323 map-loop339357 map-loop373398 map-loop414432) 
o|calls to known targets: 32 
o|identified direct recursive calls: f_1368 1 
o|identified direct recursive calls: f_2000 1 
o|identified direct recursive calls: f_2049 1 
o|fast box initializations: 9 
*/
/* end of file */
