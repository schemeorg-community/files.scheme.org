/* Generated from expand.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:49
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: expand.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file expand.c
   unit: expand
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[358];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,14),40,108,111,111,107,117,112,32,115,101,50,52,55,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,26),40,109,97,99,114,111,45,97,108,105,97,115,32,118,97,114,50,54,50,32,115,101,50,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,51,51,49,32,105,51,51,51,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,11),40,119,97,108,107,32,120,51,48,50,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,21),40,115,116,114,105,112,45,115,121,110,116,97,120,32,101,120,112,50,57,57,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,52,49,56,32,103,52,51,48,52,52,48,32,103,52,51,49,52,52,49,41,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,34),40,102,111,114,45,101,97,99,104,45,108,111,111,112,51,56,49,32,103,51,56,56,52,48,57,32,103,51,56,57,52,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,51,53,53,32,103,51,54,55,51,55,51,41,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,43),40,35,35,115,121,115,35,101,120,116,101,110,100,45,115,101,32,115,101,51,52,53,32,118,97,114,115,51,52,54,32,46,32,116,109,112,51,52,52,51,52,55,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,11),40,103,52,54,53,32,97,52,54,55,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,115,101,52,54,57,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,49,32,115,121,109,52,53,52,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,103,108,111,98,97,108,105,122,101,32,115,121,109,52,53,49,32,115,101,52,53,50,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,43),40,35,35,115,121,115,35,101,110,115,117,114,101,45,116,114,97,110,115,102,111,114,109,101,114,32,116,52,56,54,32,46,32,116,109,112,52,56,53,52,56,55,41,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,6),40,103,53,48,57,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,61),40,35,35,115,121,115,35,101,120,116,101,110,100,45,109,97,99,114,111,45,101,110,118,105,114,111,110,109,101,110,116,32,110,97,109,101,52,57,56,32,115,101,52,57,57,32,116,114,97,110,115,102,111,114,109,101,114,53,48,48,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,99,111,112,121,45,109,97,99,114,111,32,111,108,100,53,49,55,32,110,101,119,53,49,56,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,109,97,99,114,111,63,32,115,121,109,53,50,54,32,46,32,116,109,112,53,50,53,53,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,109,101,53,52,49,41,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,32),40,35,35,115,121,115,35,117,110,114,101,103,105,115,116,101,114,45,109,97,99,114,111,32,110,97,109,101,53,51,57,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,117,110,100,101,102,105,110,101,45,109,97,99,114,111,33,32,110,97,109,101,53,52,57,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,12),40,99,111,112,121,32,112,115,53,55,53,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,7),40,97,52,51,54,55,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,13),40,97,52,51,54,49,32,101,120,53,55,50,41,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,17),40,102,95,52,52,57,54,32,105,110,112,117,116,53,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,7),40,97,52,53,48,49,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,7),40,97,52,53,48,54,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,52,53,49,50,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,10),40,116,109,112,49,51,48,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,7),40,97,52,53,50,53,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,21),40,116,109,112,50,51,48,57,51,32,97,114,103,115,53,54,54,53,57,56,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,52,52,54,50,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,15),40,97,52,51,53,53,32,107,53,54,53,53,55,49,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,52),40,99,97,108,108,45,104,97,110,100,108,101,114,32,110,97,109,101,53,53,54,32,104,97,110,100,108,101,114,53,53,55,32,101,120,112,53,53,56,32,115,101,53,53,57,32,99,115,53,54,48,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,31),40,101,120,112,97,110,100,32,104,101,97,100,54,48,49,32,101,120,112,54,48,50,32,109,100,101,102,54,48,51,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,54,54,53,32,103,54,55,55,54,56,51,41,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,54,51,56,32,103,54,53,48,54,53,55,41,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,12),40,103,54,57,56,32,99,115,55,48,48,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,101,120,112,54,49,50,41,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,101,120,112,97,110,100,45,48,32,101,120,112,53,53,49,32,100,115,101,53,53,50,32,99,115,63,53,53,51,41,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,7),40,97,52,56,53,56,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,32),40,97,52,56,54,52,32,101,120,112,50,55,51,51,55,51,52,55,51,55,32,109,55,51,53,55,51,54,55,51,56,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,101,120,112,55,51,50,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,27),40,101,120,112,97,110,100,32,101,120,112,55,49,57,32,46,32,116,109,112,55,49,56,55,50,48,41,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,108,105,115,116,55,52,54,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,63,32,108,108,105,115,116,55,52,52,41,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,12),40,101,114,114,32,109,115,103,55,54,57,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,11),40,103,56,48,48,32,107,56,49,49,41,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,55,57,52,32,103,56,48,54,56,50,51,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,44),40,108,111,111,112,32,109,111,100,101,55,55,57,32,114,101,113,55,56,48,32,111,112,116,55,56,49,32,107,101,121,55,56,50,32,108,108,105,115,116,55,56,51,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,67),40,35,35,115,121,115,35,101,120,112,97,110,100,45,101,120,116,101,110,100,101,100,45,108,97,109,98,100,97,45,108,105,115,116,32,108,108,105,115,116,48,55,54,51,32,98,111,100,121,55,54,52,32,101,114,114,104,55,54,53,32,115,101,55,54,54,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,28),40,35,35,115,121,115,35,100,101,102,106,97,109,45,101,114,114,111,114,32,102,111,114,109,56,57,49,41,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,57,51,49,32,103,57,52,51,57,53,54,32,103,57,52,52,57,53,55,41,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,57,48,50,32,103,57,49,52,57,50,48,41,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,31),40,97,53,53,54,54,32,118,97,114,115,56,57,53,32,97,114,103,99,56,57,54,32,114,101,115,116,56,57,55,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,60),40,35,35,115,121,115,35,101,120,112,97,110,100,45,109,117,108,116,105,112,108,101,45,118,97,108,117,101,115,45,97,115,115,105,103,110,109,101,110,116,32,102,111,114,109,97,108,115,56,57,51,32,101,120,112,114,56,57,52,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,12),40,99,111,109,112,32,105,100,57,57,56,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,98,111,100,121,50,49,48,49,53,32,101,120,112,115,49,48,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,44),40,109,97,112,45,108,111,111,112,49,48,55,57,32,103,49,48,57,49,49,49,48,55,32,103,49,48,57,50,49,49,48,56,32,103,49,48,57,51,49,49,48,57,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,48,51,49,32,103,49,48,52,51,49,48,55,49,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,25),40,97,54,48,57,50,32,97,49,48,54,53,32,95,49,48,54,54,32,95,49,48,54,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,31),40,102,111,108,100,108,49,48,53,52,32,103,49,48,53,53,49,48,53,57,32,103,49,48,53,51,49,48,54,48,41,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,43),40,102,105,110,105,32,118,97,114,115,49,48,48,57,32,118,97,108,115,49,48,49,48,32,109,118,97,114,115,49,48,49,49,32,98,111,100,121,49,48,49,50,41,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,49,51,57,32,103,49,49,53,49,49,49,53,55,41};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,33),40,108,111,111,112,32,98,111,100,121,49,49,50,55,32,100,101,102,115,49,49,50,56,32,100,111,110,101,49,49,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,50),40,102,105,110,105,47,115,121,110,116,97,120,32,118,97,114,115,49,49,50,50,32,118,97,108,115,49,49,50,51,32,109,118,97,114,115,49,49,50,52,32,98,111,100,121,49,49,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,50,32,120,49,49,57,51,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,43),40,108,111,111,112,32,98,111,100,121,49,49,55,55,32,118,97,114,115,49,49,55,56,32,118,97,108,115,49,49,55,57,32,109,118,97,114,115,49,49,56,48,41,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,17),40,101,120,112,97,110,100,32,98,111,100,121,49,49,55,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,45),40,35,35,115,121,115,35,99,97,110,111,110,105,99,97,108,105,122,101,45,98,111,100,121,32,98,111,100,121,57,56,49,32,46,32,116,109,112,57,56,48,57,56,50,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,7),40,103,49,50,51,53,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,19),40,109,119,97,108,107,32,120,49,50,50,51,32,112,49,50,50,52,41,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,43),40,109,97,116,99,104,45,101,120,112,114,101,115,115,105,111,110,32,101,120,112,49,50,49,55,32,112,97,116,49,50,49,56,32,118,97,114,115,49,50,49,57,41,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,104,101,97,100,49,50,52,55,32,98,111,100,121,49,50,52,56,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,54),40,35,35,115,121,115,35,101,120,112,97,110,100,45,99,117,114,114,105,101,100,45,100,101,102,105,110,101,32,104,101,97,100,49,50,52,50,32,98,111,100,121,49,50,52,51,32,115,101,49,50,52,52,41,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,25),40,115,121,110,116,97,120,45,101,114,114,111,114,32,46,32,97,114,103,115,49,50,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,16),40,111,117,116,115,116,114,32,115,116,114,49,50,56,49,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,108,115,116,49,51,48,48,41,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,100,101,102,115,49,50,55,48,41,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,99,120,49,50,56,51,41,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,44),40,35,35,115,121,115,35,115,121,110,116,97,120,45,101,114,114,111,114,47,99,111,110,116,101,120,116,32,109,115,103,49,50,54,53,32,97,114,103,49,50,54,54,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,115,121,110,116,97,120,45,114,117,108,101,115,45,109,105,115,109,97,116,99,104,32,105,110,112,117,116,49,51,49,51,41,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,7),40,103,49,51,50,54,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,26),40,103,101,116,45,108,105,110,101,45,110,117,109,98,101,114,32,115,101,120,112,49,51,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,29),40,116,101,115,116,32,120,49,51,53,53,32,112,114,101,100,49,51,53,54,32,109,115,103,49,51,53,55,41,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,13),40,101,114,114,32,109,115,103,49,51,53,56,41,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,120,49,51,54,54,41,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,20),40,108,97,109,98,100,97,45,108,105,115,116,63,32,120,49,51,54,49,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,20),40,112,114,111,112,101,114,45,108,105,115,116,63,32,120,49,51,55,56,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,52,48,52,32,120,49,52,48,54,32,110,49,52,48,55,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,13),40,97,55,51,55,50,32,121,49,52,50,48,41,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,49,51,57,48,32,112,49,51,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,57),40,35,35,115,121,115,35,99,104,101,99,107,45,115,121,110,116,97,120,32,105,100,49,51,51,55,32,101,120,112,49,51,51,56,32,112,97,116,49,51,51,57,32,46,32,116,109,112,49,51,51,54,49,51,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,13),40,103,49,52,53,56,32,97,49,52,54,48,41,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,16),40,114,101,110,97,109,101,32,115,121,109,49,52,52,52,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,24),40,100,111,108,111,111,112,49,53,49,49,32,105,49,53,49,51,32,102,49,53,49,52,41};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,7),40,103,49,53,54,54,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,7),40,103,49,53,55,53,41,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,23),40,99,111,109,112,97,114,101,32,115,49,49,52,57,57,32,115,50,49,53,48,48,41,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,20),40,97,115,115,113,45,114,101,118,101,114,115,101,32,108,49,53,56,57,41,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,23),40,109,105,114,114,111,114,45,114,101,110,97,109,101,32,115,121,109,49,53,57,52,41,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,31),40,97,55,52,56,56,32,102,111,114,109,49,52,51,51,32,115,101,49,52,51,52,32,100,115,101,49,52,51,53,41,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,59),40,109,97,107,101,45,101,114,47,105,114,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,52,51,49,32,101,120,112,108,105,99,105,116,45,114,101,110,97,109,105,110,103,63,49,52,51,50,41,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,34),40,101,114,45,109,97,99,114,111,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,54,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,34),40,105,114,45,109,97,99,114,111,45,116,114,97,110,115,102,111,114,109,101,114,32,104,97,110,100,108,101,114,49,54,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,33),40,108,111,111,112,32,98,115,49,55,57,48,32,115,101,101,110,49,55,57,49,32,119,97,114,110,101,100,49,55,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,59),40,99,104,101,99,107,45,102,111,114,45,109,117,108,116,105,112,108,101,45,98,105,110,100,105,110,103,115,32,98,105,110,100,105,110,103,115,49,55,56,54,32,102,111,114,109,49,55,56,55,32,108,111,99,49,55,56,56,41,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,14),40,102,95,56,51,51,55,32,120,50,52,54,51,41,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,52,55,48,32,103,50,52,56,50,50,52,56,56,41};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,18),40,102,95,56,51,52,51,32,114,117,108,101,115,50,52,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,13),40,97,56,52,55,52,32,120,50,53,48,50,41,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,17),40,102,95,56,52,51,55,32,114,117,108,101,50,52,57,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,48),40,102,95,56,53,48,51,32,105,110,112,117,116,50,53,48,51,32,112,97,116,116,101,114,110,50,53,48,52,32,115,101,101,110,45,115,101,103,109,101,110,116,63,50,53,48,53,41};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,30),40,102,95,56,54,56,52,32,105,110,112,117,116,50,53,52,51,32,112,97,116,116,101,114,110,50,53,52,52,41,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,13),40,97,56,56,54,57,32,120,50,53,54,53,41,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,57),40,102,95,56,56,49,49,32,112,97,116,116,101,114,110,50,53,53,50,32,112,97,116,104,50,53,53,51,32,109,97,112,105,116,50,53,53,52,32,115,101,101,110,45,115,101,103,109,101,110,116,63,50,53,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,50,54,48,52,32,100,50,54,48,54,32,103,101,110,50,54,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,37),40,102,95,56,57,53,49,32,116,101,109,112,108,97,116,101,50,53,56,49,32,100,105,109,50,53,56,50,32,101,110,118,50,53,56,51,41,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,55),40,102,95,57,49,52,51,32,112,97,116,116,101,114,110,50,54,50,52,32,100,105,109,50,54,50,53,32,118,97,114,115,50,54,50,54,32,115,101,101,110,45,115,101,103,109,101,110,116,63,50,54,50,55,41,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,46),40,102,95,57,50,50,48,32,116,101,109,112,108,97,116,101,50,54,51,50,32,100,105,109,50,54,51,51,32,101,110,118,50,54,51,52,32,102,114,101,101,50,54,51,53,41,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,32),40,102,95,57,51,48,57,32,112,50,54,52,51,32,115,101,101,110,45,115,101,103,109,101,110,116,63,50,54,52,52,41};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,51,55,32,112,97,116,116,101,114,110,50,54,53,48,41,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,54,49,32,112,97,116,116,101,114,110,50,54,53,51,41,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,112,97,116,116,101,114,110,50,54,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,20),40,102,95,57,51,56,49,32,112,97,116,116,101,114,110,50,54,53,52,41,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,79),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,115,121,110,116,97,120,45,114,117,108,101,115,32,101,108,108,105,112,115,105,115,50,52,48,54,32,114,117,108,101,115,50,52,48,55,32,115,117,98,107,101,121,119,111,114,100,115,50,52,48,56,32,114,50,52,48,57,32,99,50,52,49,48,41,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,109,101,50,55,50,55,41,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,109,97,99,114,111,45,115,117,98,115,101,116,32,109,101,48,50,55,49,56,32,46,32,116,109,112,50,55,49,55,50,55,49,57,41,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,16),40,103,50,55,52,57,32,115,100,101,102,50,55,53,56,41};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,29),40,102,111,114,45,101,97,99,104,45,108,111,111,112,50,55,52,56,32,103,50,55,53,53,50,55,54,48,41,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,52),40,35,35,115,121,115,35,102,105,120,117,112,45,109,97,99,114,111,45,101,110,118,105,114,111,110,109,101,110,116,32,115,101,50,55,51,56,32,46,32,116,109,112,50,55,51,55,50,55,51,57,41,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,27),40,97,57,53,54,56,32,101,120,112,50,51,57,52,32,114,50,51,57,53,32,99,50,51,57,54,41,0,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,25),40,97,57,54,48,52,32,120,50,51,56,56,32,114,50,51,56,57,32,99,50,51,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,25),40,97,57,54,51,49,32,120,50,51,55,55,32,114,50,51,55,56,32,99,50,51,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,25),40,97,57,54,54,49,32,120,50,51,51,57,32,114,50,51,52,48,32,99,50,51,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,25),40,97,57,56,52,49,32,120,50,51,51,51,32,114,50,51,51,52,32,99,50,51,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,25),40,97,57,56,54,55,32,120,50,51,50,54,32,114,50,51,50,55,32,99,50,51,50,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,25),40,97,57,56,56,48,32,120,50,51,49,57,32,114,50,51,50,48,32,99,50,51,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,11),40,101,114,114,32,120,50,50,52,51,41,0,0,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,13),40,116,101,115,116,32,102,120,50,50,52,52,41,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,50,55,55,32,103,50,50,56,57,50,50,57,54,41};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,16),40,101,120,112,97,110,100,32,99,108,115,50,50,55,48,41};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,28),40,97,57,56,57,51,32,102,111,114,109,50,50,51,51,32,114,50,50,51,52,32,99,50,50,51,53,41,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,29),40,97,49,48,49,56,53,32,102,111,114,109,50,50,50,54,32,114,50,50,50,55,32,99,50,50,50,56,41,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,29),40,97,49,48,50,48,54,32,102,111,114,109,50,50,49,57,32,114,50,50,50,48,32,99,50,50,50,49,41,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,18),40,119,97,108,107,32,120,50,49,52,52,32,110,50,49,52,53,41,0,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,19),40,119,97,108,107,49,32,120,50,49,52,54,32,110,50,49,52,55,41,0,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,15),40,103,50,49,57,55,32,101,110,118,50,49,57,57,41,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,15),40,103,50,50,48,52,32,101,110,118,50,50,48,54,41,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,16),40,115,105,109,112,108,105,102,121,32,120,50,49,57,48,41};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,29),40,97,49,48,50,51,57,32,102,111,114,109,50,49,51,53,32,114,50,49,51,54,32,99,50,49,51,55,41,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,49,48,57,32,103,50,49,50,49,50,49,50,56,41};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,48,55,53,32,103,50,48,56,55,50,48,57,52,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,29),40,97,49,48,53,51,48,32,102,111,114,109,50,48,54,51,32,114,50,48,54,52,32,99,50,48,54,53,41,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,15),40,101,120,112,97,110,100,32,98,115,50,48,53,52,41,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,29),40,97,49,48,55,50,54,32,102,111,114,109,50,48,52,56,32,114,50,48,52,57,32,99,50,48,53,48,41,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,7),40,103,50,48,49,54,41,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,48,49,48,32,103,50,48,50,50,50,48,51,50,41};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,30),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,57,56,55,32,101,108,115,101,63,49,57,56,56,41,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,29),40,97,49,48,55,55,55,32,102,111,114,109,49,57,55,51,32,114,49,57,55,52,32,99,49,57,55,53,41,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,30),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,56,57,50,32,101,108,115,101,63,49,56,57,51,41,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,29),40,97,49,49,48,48,50,32,102,111,114,109,49,56,56,52,32,114,49,56,56,53,32,99,49,56,56,54,41,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,29),40,97,49,49,51,55,52,32,102,111,114,109,49,56,55,52,32,114,49,56,55,53,32,99,49,56,55,54,41,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,29),40,97,49,49,52,50,54,32,102,111,114,109,49,56,54,53,32,114,49,56,54,54,32,99,49,56,54,55,41,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,26),40,97,49,49,52,54,51,32,120,49,56,52,57,32,114,49,56,53,48,32,99,49,56,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,26),40,97,49,49,53,48,55,32,120,49,56,52,49,32,114,49,56,52,50,32,99,49,56,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,26),40,97,49,49,53,50,57,32,120,49,56,51,51,32,114,49,56,51,52,32,99,49,56,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,26),40,97,49,49,53,53,49,32,120,49,56,50,53,32,114,49,56,50,54,32,99,49,56,50,55,41,0,0,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,26),40,97,49,49,53,55,51,32,120,49,56,49,55,32,114,49,56,49,56,32,99,49,56,49,57,41,0,0,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,26),40,97,49,49,53,57,53,32,120,49,56,48,51,32,114,49,56,48,52,32,99,49,56,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,29),40,97,49,49,54,52,55,32,102,111,114,109,49,55,53,53,32,114,49,55,53,54,32,99,49,55,53,55,41,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,102,111,114,109,49,55,50,55,41,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,26),40,97,49,49,55,53,48,32,120,49,55,50,51,32,114,49,55,50,52,32,99,49,55,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,26),40,97,49,49,56,54,57,32,120,49,55,49,54,32,114,49,55,49,55,32,99,49,55,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,26),40,97,49,49,56,56,54,32,120,49,55,48,57,32,114,49,55,49,48,32,99,49,55,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,26),40,97,49,49,57,48,51,32,120,49,55,48,50,32,114,49,55,48,51,32,99,49,55,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,26),40,97,49,49,57,50,48,32,120,49,54,57,53,32,114,49,54,57,54,32,99,49,54,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,26),40,97,49,49,57,51,55,32,120,49,54,56,56,32,114,49,54,56,57,32,99,49,54,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,50),40,97,49,49,57,53,52,32,103,49,54,55,54,49,54,55,55,49,54,56,50,32,103,49,54,55,56,49,54,55,57,49,54,56,51,32,103,49,54,56,48,49,54,56,49,49,54,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,50),40,97,49,49,57,54,52,32,103,49,54,54,50,49,54,54,51,49,54,54,56,32,103,49,54,54,52,49,54,54,53,49,54,54,57,32,103,49,54,54,54,49,54,54,55,49,54,55,48,41,0,0,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,50),40,97,49,49,57,55,52,32,103,49,54,52,56,49,54,52,57,49,54,53,52,32,103,49,54,53,48,49,54,53,49,49,54,53,53,32,103,49,54,53,50,49,54,53,51,49,54,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_8651)
static void C_fcall f_8651(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4997)
static void C_ccall f_4997(C_word c,C_word *av) C_noret;
C_noret_decl(f_10936)
static C_word C_fcall f_10936(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_10951)
static void C_ccall f_10951(C_word c,C_word *av) C_noret;
C_noret_decl(f_7171)
static void C_fcall f_7171(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7176)
static void C_fcall f_7176(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4766)
static void C_fcall f_4766(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4276)
static void C_ccall f_4276(C_word c,C_word *av) C_noret;
C_noret_decl(f_4762)
static void C_fcall f_4762(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word *av) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word *av) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word *av) C_noret;
C_noret_decl(f_10953)
static void C_fcall f_10953(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7150)
static C_word C_fcall f_7150(C_word t0);
C_noret_decl(f_8330)
static void C_ccall f_8330(C_word c,C_word *av) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word *av) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word *av) C_noret;
C_noret_decl(f_7142)
static void C_ccall f_7142(C_word c,C_word *av) C_noret;
C_noret_decl(f_7144)
static void C_ccall f_7144(C_word c,C_word *av) C_noret;
C_noret_decl(f_8322)
static void C_ccall f_8322(C_word c,C_word *av) C_noret;
C_noret_decl(f_8993)
static void C_ccall f_8993(C_word c,C_word *av) C_noret;
C_noret_decl(f_8337)
static void C_ccall f_8337(C_word c,C_word *av) C_noret;
C_noret_decl(f_8999)
static void C_ccall f_8999(C_word c,C_word *av) C_noret;
C_noret_decl(f_8335)
static void C_ccall f_8335(C_word c,C_word *av) C_noret;
C_noret_decl(f_8990)
static void C_ccall f_8990(C_word c,C_word *av) C_noret;
C_noret_decl(f_9515)
static void C_ccall f_9515(C_word c,C_word *av) C_noret;
C_noret_decl(f_9517)
static void C_fcall f_9517(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5574)
static void C_ccall f_5574(C_word c,C_word *av) C_noret;
C_noret_decl(f_5571)
static void C_ccall f_5571(C_word c,C_word *av) C_noret;
C_noret_decl(f_8326)
static void C_ccall f_8326(C_word c,C_word *av) C_noret;
C_noret_decl(f_8301)
static void C_ccall f_8301(C_word c,C_word *av) C_noret;
C_noret_decl(f_9184)
static void C_ccall f_9184(C_word c,C_word *av) C_noret;
C_noret_decl(f_8318)
static void C_ccall f_8318(C_word c,C_word *av) C_noret;
C_noret_decl(f_8313)
static void C_ccall f_8313(C_word c,C_word *av) C_noret;
C_noret_decl(f_7114)
static void C_ccall f_7114(C_word c,C_word *av) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word *av) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word *av) C_noret;
C_noret_decl(f_3678)
static C_word C_fcall f_3678(C_word t0,C_word t1);
C_noret_decl(f_11311)
static void C_ccall f_11311(C_word c,C_word *av) C_noret;
C_noret_decl(f_9784)
static void C_fcall f_9784(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9169)
static void C_ccall f_9169(C_word c,C_word *av) C_noret;
C_noret_decl(f_11323)
static void C_ccall f_11323(C_word c,C_word *av) C_noret;
C_noret_decl(f_8951)
static void C_ccall f_8951(C_word c,C_word *av) C_noret;
C_noret_decl(f_3695)
static void C_fcall f_3695(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word *av) C_noret;
C_noret_decl(f_8945)
static void C_ccall f_8945(C_word c,C_word *av) C_noret;
C_noret_decl(f_11339)
static void C_ccall f_11339(C_word c,C_word *av) C_noret;
C_noret_decl(f_6361)
static void C_ccall f_6361(C_word c,C_word *av) C_noret;
C_noret_decl(f_6364)
static void C_ccall f_6364(C_word c,C_word *av) C_noret;
C_noret_decl(f_8343)
static void C_ccall f_8343(C_word c,C_word *av) C_noret;
C_noret_decl(f_8480)
static void C_ccall f_8480(C_word c,C_word *av) C_noret;
C_noret_decl(f_6305)
static void C_fcall f_6305(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8920)
static void C_ccall f_8920(C_word c,C_word *av) C_noret;
C_noret_decl(f_8475)
static void C_ccall f_8475(C_word c,C_word *av) C_noret;
C_noret_decl(f_8473)
static void C_ccall f_8473(C_word c,C_word *av) C_noret;
C_noret_decl(f_8916)
static void C_ccall f_8916(C_word c,C_word *av) C_noret;
C_noret_decl(f_9590)
static void C_ccall f_9590(C_word c,C_word *av) C_noret;
C_noret_decl(f_8638)
static void C_ccall f_8638(C_word c,C_word *av) C_noret;
C_noret_decl(f_8630)
static void C_ccall f_8630(C_word c,C_word *av) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word *av) C_noret;
C_noret_decl(f_4507)
static void C_ccall f_4507(C_word c,C_word *av) C_noret;
C_noret_decl(f_4520)
static void C_fcall f_4520(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6325)
static void C_fcall f_6325(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9563)
static void C_ccall f_9563(C_word c,C_word *av) C_noret;
C_noret_decl(f_6617)
static void C_fcall f_6617(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9569)
static void C_ccall f_9569(C_word c,C_word *av) C_noret;
C_noret_decl(f_9567)
static void C_ccall f_9567(C_word c,C_word *av) C_noret;
C_noret_decl(f_6614)
static void C_fcall f_6614(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(C_expand_toplevel)
C_externexport void C_ccall C_expand_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_4513)
static void C_ccall f_4513(C_word c,C_word *av) C_noret;
C_noret_decl(f_9573)
static void C_ccall f_9573(C_word c,C_word *av) C_noret;
C_noret_decl(f_8444)
static void C_fcall f_8444(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word *av) C_noret;
C_noret_decl(f_6631)
static C_word C_fcall f_6631(C_word t0,C_word t1);
C_noret_decl(f_8437)
static void C_ccall f_8437(C_word c,C_word *av) C_noret;
C_noret_decl(f_5755)
static C_word C_fcall f_5755(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4539)
static void C_fcall f_4539(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word *av) C_noret;
C_noret_decl(f_11085)
static void C_ccall f_11085(C_word c,C_word *av) C_noret;
C_noret_decl(f_9555)
static void C_ccall f_9555(C_word c,C_word *av) C_noret;
C_noret_decl(f_9551)
static void C_ccall f_9551(C_word c,C_word *av) C_noret;
C_noret_decl(f_8465)
static void C_ccall f_8465(C_word c,C_word *av) C_noret;
C_noret_decl(f_9559)
static void C_ccall f_9559(C_word c,C_word *av) C_noret;
C_noret_decl(f_8469)
static void C_ccall f_8469(C_word c,C_word *av) C_noret;
C_noret_decl(f_5744)
static void C_ccall f_5744(C_word c,C_word *av) C_noret;
C_noret_decl(f_5740)
static void C_ccall f_5740(C_word c,C_word *av) C_noret;
C_noret_decl(f_9527)
static void C_ccall f_9527(C_word c,C_word *av) C_noret;
C_noret_decl(f_10664)
static void C_fcall f_10664(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11073)
static void C_ccall f_11073(C_word c,C_word *av) C_noret;
C_noret_decl(f_11076)
static void C_ccall f_11076(C_word c,C_word *av) C_noret;
C_noret_decl(f_11079)
static void C_ccall f_11079(C_word c,C_word *av) C_noret;
C_noret_decl(f_11594)
static void C_ccall f_11594(C_word c,C_word *av) C_noret;
C_noret_decl(f_11596)
static void C_ccall f_11596(C_word c,C_word *av) C_noret;
C_noret_decl(f_11041)
static void C_ccall f_11041(C_word c,C_word *av) C_noret;
C_noret_decl(f_11830)
static void C_ccall f_11830(C_word c,C_word *av) C_noret;
C_noret_decl(f_11044)
static void C_ccall f_11044(C_word c,C_word *av) C_noret;
C_noret_decl(f_11833)
static void C_ccall f_11833(C_word c,C_word *av) C_noret;
C_noret_decl(f_11048)
static void C_ccall f_11048(C_word c,C_word *av) C_noret;
C_noret_decl(f_5703)
static void C_fcall f_5703(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8420)
static void C_ccall f_8420(C_word c,C_word *av) C_noret;
C_noret_decl(f_6299)
static void C_fcall f_6299(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11885)
static void C_ccall f_11885(C_word c,C_word *av) C_noret;
C_noret_decl(f_11887)
static void C_ccall f_11887(C_word c,C_word *av) C_noret;
C_noret_decl(f_11057)
static void C_ccall f_11057(C_word c,C_word *av) C_noret;
C_noret_decl(f_11054)
static void C_ccall f_11054(C_word c,C_word *av) C_noret;
C_noret_decl(f_11891)
static void C_ccall f_11891(C_word c,C_word *av) C_noret;
C_noret_decl(f_9733)
static void C_ccall f_9733(C_word c,C_word *av) C_noret;
C_noret_decl(f_9737)
static void C_ccall f_9737(C_word c,C_word *av) C_noret;
C_noret_decl(f_5728)
static void C_ccall f_5728(C_word c,C_word *av) C_noret;
C_noret_decl(f_5286)
static void C_fcall f_5286(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6343)
static void C_ccall f_6343(C_word c,C_word *av) C_noret;
C_noret_decl(f_10148)
static void C_ccall f_10148(C_word c,C_word *av) C_noret;
C_noret_decl(f_6348)
static void C_fcall f_6348(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11868)
static void C_ccall f_11868(C_word c,C_word *av) C_noret;
C_noret_decl(f_11581)
static void C_ccall f_11581(C_word c,C_word *av) C_noret;
C_noret_decl(f_3858)
static void C_fcall f_3858(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11556)
static void C_ccall f_11556(C_word c,C_word *av) C_noret;
C_noret_decl(f_11559)
static void C_ccall f_11559(C_word c,C_word *av) C_noret;
C_noret_decl(f_11550)
static void C_ccall f_11550(C_word c,C_word *av) C_noret;
C_noret_decl(f_11552)
static void C_ccall f_11552(C_word c,C_word *av) C_noret;
C_noret_decl(f_10164)
static void C_ccall f_10164(C_word c,C_word *av) C_noret;
C_noret_decl(f_10813)
static void C_ccall f_10813(C_word c,C_word *av) C_noret;
C_noret_decl(f_10815)
static void C_fcall f_10815(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11528)
static void C_ccall f_11528(C_word c,C_word *av) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word *av) C_noret;
C_noret_decl(f_5299)
static void C_fcall f_5299(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11578)
static void C_ccall f_11578(C_word c,C_word *av) C_noret;
C_noret_decl(f_11060)
static void C_ccall f_11060(C_word c,C_word *av) C_noret;
C_noret_decl(f_11063)
static void C_ccall f_11063(C_word c,C_word *av) C_noret;
C_noret_decl(f_11067)
static void C_ccall f_11067(C_word c,C_word *av) C_noret;
C_noret_decl(f_11574)
static void C_ccall f_11574(C_word c,C_word *av) C_noret;
C_noret_decl(f_11572)
static void C_ccall f_11572(C_word c,C_word *av) C_noret;
C_noret_decl(f_10190)
static void C_ccall f_10190(C_word c,C_word *av) C_noret;
C_noret_decl(f_10184)
static void C_ccall f_10184(C_word c,C_word *av) C_noret;
C_noret_decl(f_10186)
static void C_ccall f_10186(C_word c,C_word *av) C_noret;
C_noret_decl(f_9743)
static void C_ccall f_9743(C_word c,C_word *av) C_noret;
C_noret_decl(f_9740)
static void C_ccall f_9740(C_word c,C_word *av) C_noret;
C_noret_decl(f_11823)
static void C_ccall f_11823(C_word c,C_word *av) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word *av) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word *av) C_noret;
C_noret_decl(f_9755)
static void C_ccall f_9755(C_word c,C_word *av) C_noret;
C_noret_decl(f_6217)
static void C_ccall f_6217(C_word c,C_word *av) C_noret;
C_noret_decl(f_7585)
static void C_fcall f_7585(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7588)
static void C_ccall f_7588(C_word c,C_word *av) C_noret;
C_noret_decl(f_10802)
static void C_ccall f_10802(C_word c,C_word *av) C_noret;
C_noret_decl(f_5206)
static void C_fcall f_5206(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word *av) C_noret;
C_noret_decl(f_5204)
static void C_ccall f_5204(C_word c,C_word *av) C_noret;
C_noret_decl(f_7567)
static void C_fcall f_7567(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9702)
static void C_ccall f_9702(C_word c,C_word *av) C_noret;
C_noret_decl(f_6207)
static void C_ccall f_6207(C_word c,C_word *av) C_noret;
C_noret_decl(f_11902)
static void C_ccall f_11902(C_word c,C_word *av) C_noret;
C_noret_decl(f_11908)
static void C_ccall f_11908(C_word c,C_word *av) C_noret;
C_noret_decl(f_11904)
static void C_ccall f_11904(C_word c,C_word *av) C_noret;
C_noret_decl(f_4110)
static void C_fcall f_4110(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11919)
static void C_ccall f_11919(C_word c,C_word *av) C_noret;
C_noret_decl(f_4126)
static void C_fcall f_4126(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11648)
static void C_ccall f_11648(C_word c,C_word *av) C_noret;
C_noret_decl(f_11646)
static void C_ccall f_11646(C_word c,C_word *av) C_noret;
C_noret_decl(f_7516)
static void C_ccall f_7516(C_word c,C_word *av) C_noret;
C_noret_decl(f_7512)
static void C_ccall f_7512(C_word c,C_word *av) C_noret;
C_noret_decl(f_10857)
static void C_ccall f_10857(C_word c,C_word *av) C_noret;
C_noret_decl(f_10851)
static void C_ccall f_10851(C_word c,C_word *av) C_noret;
C_noret_decl(f_7496)
static void C_ccall f_7496(C_word c,C_word *av) C_noret;
C_noret_decl(f_7498)
static void C_ccall f_7498(C_word c,C_word *av) C_noret;
C_noret_decl(f_11621)
static void C_ccall f_11621(C_word c,C_word *av) C_noret;
C_noret_decl(f_7489)
static void C_ccall f_7489(C_word c,C_word *av) C_noret;
C_noret_decl(f_7483)
static void C_ccall f_7483(C_word c,C_word *av) C_noret;
C_noret_decl(f_11600)
static void C_ccall f_11600(C_word c,C_word *av) C_noret;
C_noret_decl(f_11608)
static void C_fcall f_11608(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7533)
static void C_ccall f_7533(C_word c,C_word *av) C_noret;
C_noret_decl(f_7537)
static void C_ccall f_7537(C_word c,C_word *av) C_noret;
C_noret_decl(f_9218)
static void C_ccall f_9218(C_word c,C_word *av) C_noret;
C_noret_decl(f_9262)
static void C_ccall f_9262(C_word c,C_word *av) C_noret;
C_noret_decl(f_10741)
static void C_fcall f_10741(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9203)
static void C_ccall f_9203(C_word c,C_word *av) C_noret;
C_noret_decl(f_9220)
static void C_ccall f_9220(C_word c,C_word *av) C_noret;
C_noret_decl(f_11128)
static void C_ccall f_11128(C_word c,C_word *av) C_noret;
C_noret_decl(f_5561)
static void C_ccall f_5561(C_word c,C_word *av) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567(C_word c,C_word *av) C_noret;
C_noret_decl(f_4770)
static void C_ccall f_4770(C_word c,C_word *av) C_noret;
C_noret_decl(f_5245)
static void C_ccall f_5245(C_word c,C_word *av) C_noret;
C_noret_decl(f_5555)
static void C_ccall f_5555(C_word c,C_word *av) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word *av) C_noret;
C_noret_decl(f_5231)
static void C_ccall f_5231(C_word c,C_word *av) C_noret;
C_noret_decl(f_8293)
static void C_ccall f_8293(C_word c,C_word *av) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word *av) C_noret;
C_noret_decl(f_8297)
static void C_ccall f_8297(C_word c,C_word *av) C_noret;
C_noret_decl(f_8285)
static void C_ccall f_8285(C_word c,C_word *av) C_noret;
C_noret_decl(f_8281)
static void C_ccall f_8281(C_word c,C_word *av) C_noret;
C_noret_decl(f_8289)
static void C_ccall f_8289(C_word c,C_word *av) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word *av) C_noret;
C_noret_decl(f_10250)
static void C_ccall f_10250(C_word c,C_word *av) C_noret;
C_noret_decl(f_10252)
static void C_fcall f_10252(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10407)
static void C_ccall f_10407(C_word c,C_word *av) C_noret;
C_noret_decl(f_10639)
static void C_fcall f_10639(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10637)
static void C_ccall f_10637(C_word c,C_word *av) C_noret;
C_noret_decl(f_8251)
static void C_ccall f_8251(C_word c,C_word *av) C_noret;
C_noret_decl(f_10276)
static void C_ccall f_10276(C_word c,C_word *av) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word *av) C_noret;
C_noret_decl(f_8242)
static void C_ccall f_8242(C_word c,C_word *av) C_noret;
C_noret_decl(f_8244)
static void C_ccall f_8244(C_word c,C_word *av) C_noret;
C_noret_decl(f_10244)
static void C_ccall f_10244(C_word c,C_word *av) C_noret;
C_noret_decl(f_10247)
static void C_ccall f_10247(C_word c,C_word *av) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word *av) C_noret;
C_noret_decl(f_10240)
static void C_ccall f_10240(C_word c,C_word *av) C_noret;
C_noret_decl(f_4607)
static void C_fcall f_4607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8275)
static void C_ccall f_8275(C_word c,C_word *av) C_noret;
C_noret_decl(f_8270)
static void C_ccall f_8270(C_word c,C_word *av) C_noret;
C_noret_decl(f_10299)
static void C_ccall f_10299(C_word c,C_word *av) C_noret;
C_noret_decl(f_8266)
static void C_ccall f_8266(C_word c,C_word *av) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word *av) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word *av) C_noret;
C_noret_decl(f_4853)
static void C_fcall f_4853(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10262)
static void C_fcall f_10262(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10260)
static void C_ccall f_10260(C_word c,C_word *av) C_noret;
C_noret_decl(f_8212)
static void C_ccall f_8212(C_word c,C_word *av) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word *av) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word *av) C_noret;
C_noret_decl(f_10689)
static void C_fcall f_10689(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8218)
static void C_ccall f_8218(C_word c,C_word *av) C_noret;
C_noret_decl(f_8215)
static void C_ccall f_8215(C_word c,C_word *av) C_noret;
C_noret_decl(f_8203)
static void C_ccall f_8203(C_word c,C_word *av) C_noret;
C_noret_decl(f_8200)
static void C_ccall f_8200(C_word c,C_word *av) C_noret;
C_noret_decl(f_8209)
static void C_ccall f_8209(C_word c,C_word *av) C_noret;
C_noret_decl(f_8206)
static void C_ccall f_8206(C_word c,C_word *av) C_noret;
C_noret_decl(f_10280)
static void C_ccall f_10280(C_word c,C_word *av) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word *av) C_noret;
C_noret_decl(f_4655)
static void C_fcall f_4655(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word *av) C_noret;
C_noret_decl(f_5462)
static void C_fcall f_5462(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7094)
static void C_fcall f_7094(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8767)
static void C_ccall f_8767(C_word c,C_word *av) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word *av) C_noret;
C_noret_decl(f_7080)
static void C_ccall f_7080(C_word c,C_word *av) C_noret;
C_noret_decl(f_7082)
static void C_ccall f_7082(C_word c,C_word *av) C_noret;
C_noret_decl(f_7086)
static void C_ccall f_7086(C_word c,C_word *av) C_noret;
C_noret_decl(f_4583)
static void C_fcall f_4583(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9292)
static void C_ccall f_9292(C_word c,C_word *av) C_noret;
C_noret_decl(f_7073)
static void C_ccall f_7073(C_word c,C_word *av) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480(C_word c,C_word *av) C_noret;
C_noret_decl(f_8743)
static void C_ccall f_8743(C_word c,C_word *av) C_noret;
C_noret_decl(f_4301)
static void C_fcall f_4301(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7066)
static void C_ccall f_7066(C_word c,C_word *av) C_noret;
C_noret_decl(f_6492)
static void C_ccall f_6492(C_word c,C_word *av) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word *av) C_noret;
C_noret_decl(f_8076)
static void C_ccall f_8076(C_word c,C_word *av) C_noret;
C_noret_decl(f_4351)
static void C_ccall f_4351(C_word c,C_word *av) C_noret;
C_noret_decl(f_8072)
static void C_ccall f_8072(C_word c,C_word *av) C_noret;
C_noret_decl(f_8079)
static void C_ccall f_8079(C_word c,C_word *av) C_noret;
C_noret_decl(f_7219)
static void C_ccall f_7219(C_word c,C_word *av) C_noret;
C_noret_decl(f_10596)
static void C_fcall f_10596(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7200)
static void C_fcall f_7200(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8066)
static void C_ccall f_8066(C_word c,C_word *av) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word *av) C_noret;
C_noret_decl(f_8069)
static void C_ccall f_8069(C_word c,C_word *av) C_noret;
C_noret_decl(f_5963)
static void C_ccall f_5963(C_word c,C_word *av) C_noret;
C_noret_decl(f_5966)
static void C_ccall f_5966(C_word c,C_word *av) C_noret;
C_noret_decl(f_5960)
static void C_ccall f_5960(C_word c,C_word *av) C_noret;
C_noret_decl(f_5969)
static void C_ccall f_5969(C_word c,C_word *av) C_noret;
C_noret_decl(f_8095)
static void C_ccall f_8095(C_word c,C_word *av) C_noret;
C_noret_decl(f_8091)
static void C_ccall f_8091(C_word c,C_word *av) C_noret;
C_noret_decl(f_8099)
static void C_ccall f_8099(C_word c,C_word *av) C_noret;
C_noret_decl(f_8085)
static void C_ccall f_8085(C_word c,C_word *av) C_noret;
C_noret_decl(f_4341)
static void C_fcall f_4341(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8082)
static void C_ccall f_8082(C_word c,C_word *av) C_noret;
C_noret_decl(f_8088)
static void C_ccall f_8088(C_word c,C_word *av) C_noret;
C_noret_decl(f_9273)
static void C_ccall f_9273(C_word c,C_word *av) C_noret;
C_noret_decl(f_9699)
static void C_ccall f_9699(C_word c,C_word *av) C_noret;
C_noret_decl(f_7013)
static C_word C_fcall f_7013(C_word t0,C_word t1);
C_noret_decl(f_5934)
static void C_ccall f_5934(C_word c,C_word *av) C_noret;
C_noret_decl(f_5938)
static void C_ccall f_5938(C_word c,C_word *av) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word *av) C_noret;
C_noret_decl(f_4413)
static void C_fcall f_4413(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word *av) C_noret;
C_noret_decl(f_7009)
static void C_ccall f_7009(C_word c,C_word *av) C_noret;
C_noret_decl(f_11751)
static void C_ccall f_11751(C_word c,C_word *av) C_noret;
C_noret_decl(f_11755)
static void C_ccall f_11755(C_word c,C_word *av) C_noret;
C_noret_decl(f_11248)
static void C_ccall f_11248(C_word c,C_word *av) C_noret;
C_noret_decl(f_6414)
static void C_ccall f_6414(C_word c,C_word *av) C_noret;
C_noret_decl(f_6798)
static void C_ccall f_6798(C_word c,C_word *av) C_noret;
C_noret_decl(f_6421)
static void C_ccall f_6421(C_word c,C_word *av) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word *av) C_noret;
C_noret_decl(f_5971)
static void C_fcall f_5971(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5978)
static void C_fcall f_5978(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8230)
static void C_ccall f_8230(C_word c,C_word *av) C_noret;
C_noret_decl(f_8233)
static void C_ccall f_8233(C_word c,C_word *av) C_noret;
C_noret_decl(f_8236)
static void C_ccall f_8236(C_word c,C_word *av) C_noret;
C_noret_decl(f_8239)
static void C_ccall f_8239(C_word c,C_word *av) C_noret;
C_noret_decl(f_6528)
static void C_ccall f_6528(C_word c,C_word *av) C_noret;
C_noret_decl(f_10373)
static void C_ccall f_10373(C_word c,C_word *av) C_noret;
C_noret_decl(f_8221)
static void C_ccall f_8221(C_word c,C_word *av) C_noret;
C_noret_decl(f_8224)
static void C_ccall f_8224(C_word c,C_word *av) C_noret;
C_noret_decl(f_8227)
static void C_ccall f_8227(C_word c,C_word *av) C_noret;
C_noret_decl(f_10384)
static void C_ccall f_10384(C_word c,C_word *av) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word *av) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word *av) C_noret;
C_noret_decl(f_6743)
static void C_ccall f_6743(C_word c,C_word *av) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544(C_word c,C_word *av) C_noret;
C_noret_decl(f_10392)
static void C_ccall f_10392(C_word c,C_word *av) C_noret;
C_noret_decl(f_6751)
static void C_ccall f_6751(C_word c,C_word *av) C_noret;
C_noret_decl(f_6759)
static void C_ccall f_6759(C_word c,C_word *av) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word *av) C_noret;
C_noret_decl(f_11749)
static void C_ccall f_11749(C_word c,C_word *av) C_noret;
C_noret_decl(f_5925)
static void C_ccall f_5925(C_word c,C_word *av) C_noret;
C_noret_decl(f_5928)
static void C_ccall f_5928(C_word c,C_word *av) C_noret;
C_noret_decl(f_9622)
static void C_ccall f_9622(C_word c,C_word *av) C_noret;
C_noret_decl(f_9639)
static void C_ccall f_9639(C_word c,C_word *av) C_noret;
C_noret_decl(f_6778)
static void C_fcall f_6778(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6773)
static void C_ccall f_6773(C_word c,C_word *av) C_noret;
C_noret_decl(f_11491)
static void C_ccall f_11491(C_word c,C_word *av) C_noret;
C_noret_decl(f_9630)
static void C_ccall f_9630(C_word c,C_word *av) C_noret;
C_noret_decl(f_9632)
static void C_ccall f_9632(C_word c,C_word *av) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word *av) C_noret;
C_noret_decl(f_9636)
static void C_ccall f_9636(C_word c,C_word *av) C_noret;
C_noret_decl(f_8858)
static void C_ccall f_8858(C_word c,C_word *av) C_noret;
C_noret_decl(f_8854)
static void C_ccall f_8854(C_word c,C_word *av) C_noret;
C_noret_decl(f_11803)
static void C_ccall f_11803(C_word c,C_word *av) C_noret;
C_noret_decl(f_10035)
static void C_ccall f_10035(C_word c,C_word *av) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word *av) C_noret;
C_noret_decl(f_11810)
static void C_ccall f_11810(C_word c,C_word *av) C_noret;
C_noret_decl(f_11814)
static void C_ccall f_11814(C_word c,C_word *av) C_noret;
C_noret_decl(f_8841)
static void C_ccall f_8841(C_word c,C_word *av) C_noret;
C_noret_decl(f_5069)
static void C_ccall f_5069(C_word c,C_word *av) C_noret;
C_noret_decl(f_6193)
static void C_fcall f_6193(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7889)
static C_word C_fcall f_7889(C_word t0,C_word t1);
C_noret_decl(f_8870)
static void C_ccall f_8870(C_word c,C_word *av) C_noret;
C_noret_decl(f_5013)
static void C_fcall f_5013(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11458)
static void C_ccall f_11458(C_word c,C_word *av) C_noret;
C_noret_decl(f_10896)
static void C_fcall f_10896(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11874)
static void C_ccall f_11874(C_word c,C_word *av) C_noret;
C_noret_decl(f_10008)
static void C_ccall f_10008(C_word c,C_word *av) C_noret;
C_noret_decl(f_11870)
static void C_ccall f_11870(C_word c,C_word *av) C_noret;
C_noret_decl(f_5001)
static void C_fcall f_5001(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11468)
static void C_ccall f_11468(C_word c,C_word *av) C_noret;
C_noret_decl(f_11464)
static void C_ccall f_11464(C_word c,C_word *av) C_noret;
C_noret_decl(f_11462)
static void C_ccall f_11462(C_word c,C_word *av) C_noret;
C_noret_decl(f_10829)
static void C_ccall f_10829(C_word c,C_word *av) C_noret;
C_noret_decl(f_10500)
static void C_ccall f_10500(C_word c,C_word *av) C_noret;
C_noret_decl(f_8811)
static void C_ccall f_8811(C_word c,C_word *av) C_noret;
C_noret_decl(f_10835)
static void C_ccall f_10835(C_word c,C_word *av) C_noret;
C_noret_decl(f_10838)
static void C_ccall f_10838(C_word c,C_word *av) C_noret;
C_noret_decl(f_7430)
static void C_ccall f_7430(C_word c,C_word *av) C_noret;
C_noret_decl(f_8835)
static void C_ccall f_8835(C_word c,C_word *av) C_noret;
C_noret_decl(f_10842)
static void C_ccall f_10842(C_word c,C_word *av) C_noret;
C_noret_decl(f_10848)
static void C_ccall f_10848(C_word c,C_word *av) C_noret;
C_noret_decl(f_8051)
static void C_ccall f_8051(C_word c,C_word *av) C_noret;
C_noret_decl(f_8057)
static void C_ccall f_8057(C_word c,C_word *av) C_noret;
C_noret_decl(f_8042)
static void C_ccall f_8042(C_word c,C_word *av) C_noret;
C_noret_decl(f_8046)
static void C_ccall f_8046(C_word c,C_word *av) C_noret;
C_noret_decl(f_6109)
static void C_fcall f_6109(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7050)
static void C_ccall f_7050(C_word c,C_word *av) C_noret;
C_noret_decl(f_7055)
static void C_fcall f_7055(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word *av) C_noret;
C_noret_decl(f_7811)
static C_word C_fcall f_7811(C_word t0,C_word t1);
C_noret_decl(f_9669)
static void C_ccall f_9669(C_word c,C_word *av) C_noret;
C_noret_decl(f_6119)
static void C_fcall f_6119(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6117)
static void C_ccall f_6117(C_word c,C_word *av) C_noret;
C_noret_decl(f_7043)
static void C_fcall f_7043(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9660)
static void C_ccall f_9660(C_word c,C_word *av) C_noret;
C_noret_decl(f_9662)
static void C_ccall f_9662(C_word c,C_word *av) C_noret;
C_noret_decl(f_9678)
static void C_ccall f_9678(C_word c,C_word *av) C_noret;
C_noret_decl(f_7038)
static void C_ccall f_7038(C_word c,C_word *av) C_noret;
C_noret_decl(f_10731)
static void C_ccall f_10731(C_word c,C_word *av) C_noret;
C_noret_decl(f_9675)
static void C_ccall f_9675(C_word c,C_word *av) C_noret;
C_noret_decl(f_9609)
static void C_ccall f_9609(C_word c,C_word *av) C_noret;
C_noret_decl(f_7028)
static void C_ccall f_7028(C_word c,C_word *av) C_noret;
C_noret_decl(f_10782)
static void C_ccall f_10782(C_word c,C_word *av) C_noret;
C_noret_decl(f_9603)
static void C_ccall f_9603(C_word c,C_word *av) C_noret;
C_noret_decl(f_9605)
static void C_ccall f_9605(C_word c,C_word *av) C_noret;
C_noret_decl(f_7854)
static void C_ccall f_7854(C_word c,C_word *av) C_noret;
C_noret_decl(f_9612)
static void C_ccall f_9612(C_word c,C_word *av) C_noret;
C_noret_decl(f_9615)
static void C_ccall f_9615(C_word c,C_word *av) C_noret;
C_noret_decl(f_10725)
static void C_ccall f_10725(C_word c,C_word *av) C_noret;
C_noret_decl(f_10727)
static void C_ccall f_10727(C_word c,C_word *av) C_noret;
C_noret_decl(f_10778)
static void C_ccall f_10778(C_word c,C_word *av) C_noret;
C_noret_decl(f_10776)
static void C_ccall f_10776(C_word c,C_word *av) C_noret;
C_noret_decl(f_11515)
static void C_ccall f_11515(C_word c,C_word *av) C_noret;
C_noret_decl(f_11512)
static void C_ccall f_11512(C_word c,C_word *av) C_noret;
C_noret_decl(f_10799)
static void C_ccall f_10799(C_word c,C_word *av) C_noret;
C_noret_decl(f_10796)
static void C_ccall f_10796(C_word c,C_word *av) C_noret;
C_noret_decl(f_10793)
static void C_ccall f_10793(C_word c,C_word *av) C_noret;
C_noret_decl(f_10790)
static void C_ccall f_10790(C_word c,C_word *av) C_noret;
C_noret_decl(f_11537)
static void C_ccall f_11537(C_word c,C_word *av) C_noret;
C_noret_decl(f_11534)
static void C_ccall f_11534(C_word c,C_word *av) C_noret;
C_noret_decl(f_11530)
static void C_ccall f_11530(C_word c,C_word *av) C_noret;
C_noret_decl(f_10766)
static void C_ccall f_10766(C_word c,C_word *av) C_noret;
C_noret_decl(f_11506)
static void C_ccall f_11506(C_word c,C_word *av) C_noret;
C_noret_decl(f_7953)
static void C_ccall f_7953(C_word c,C_word *av) C_noret;
C_noret_decl(f_11508)
static void C_ccall f_11508(C_word c,C_word *av) C_noret;
C_noret_decl(f_10535)
static void C_ccall f_10535(C_word c,C_word *av) C_noret;
C_noret_decl(f_10531)
static void C_ccall f_10531(C_word c,C_word *av) C_noret;
C_noret_decl(f_7949)
static void C_ccall f_7949(C_word c,C_word *av) C_noret;
C_noret_decl(f_10547)
static void C_ccall f_10547(C_word c,C_word *av) C_noret;
C_noret_decl(f_10308)
static void C_ccall f_10308(C_word c,C_word *av) C_noret;
C_noret_decl(f_7932)
static void C_ccall f_7932(C_word c,C_word *av) C_noret;
C_noret_decl(f_7928)
static void C_ccall f_7928(C_word c,C_word *av) C_noret;
C_noret_decl(f_7914)
static void C_fcall f_7914(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10575)
static void C_ccall f_10575(C_word c,C_word *av) C_noret;
C_noret_decl(f_7839)
static C_word C_fcall f_7839(C_word t0,C_word t1);
C_noret_decl(f_9337)
static void C_ccall f_9337(C_word c,C_word *av) C_noret;
C_noret_decl(f_7826)
static void C_ccall f_7826(C_word c,C_word *av) C_noret;
C_noret_decl(f_10518)
static void C_ccall f_10518(C_word c,C_word *av) C_noret;
C_noret_decl(f_9307)
static void C_ccall f_9307(C_word c,C_word *av) C_noret;
C_noret_decl(f_10058)
static void C_fcall f_10058(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9309)
static void C_ccall f_9309(C_word c,C_word *av) C_noret;
C_noret_decl(f_11701)
static void C_ccall f_11701(C_word c,C_word *av) C_noret;
C_noret_decl(f_11707)
static void C_ccall f_11707(C_word c,C_word *av) C_noret;
C_noret_decl(f_11704)
static void C_ccall f_11704(C_word c,C_word *av) C_noret;
C_noret_decl(f_11035)
static void C_ccall f_11035(C_word c,C_word *av) C_noret;
C_noret_decl(f_10529)
static void C_ccall f_10529(C_word c,C_word *av) C_noret;
C_noret_decl(f_9316)
static void C_ccall f_9316(C_word c,C_word *av) C_noret;
C_noret_decl(f_8581)
static void C_ccall f_8581(C_word c,C_word *av) C_noret;
C_noret_decl(f_5615)
static void C_ccall f_5615(C_word c,C_word *av) C_noret;
C_noret_decl(f_11003)
static void C_ccall f_11003(C_word c,C_word *av) C_noret;
C_noret_decl(f_11001)
static void C_ccall f_11001(C_word c,C_word *av) C_noret;
C_noret_decl(f_11016)
static void C_ccall f_11016(C_word c,C_word *av) C_noret;
C_noret_decl(f_11013)
static void C_ccall f_11013(C_word c,C_word *av) C_noret;
C_noret_decl(f_11010)
static void C_ccall f_11010(C_word c,C_word *av) C_noret;
C_noret_decl(f_10411)
static void C_ccall f_10411(C_word c,C_word *av) C_noret;
C_noret_decl(f_5637)
static void C_fcall f_5637(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word *av) C_noret;
C_noret_decl(f_6144)
static void C_ccall f_6144(C_word c,C_word *av) C_noret;
C_noret_decl(f_6146)
static void C_fcall f_6146(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10429)
static void C_ccall f_10429(C_word c,C_word *av) C_noret;
C_noret_decl(f_10425)
static void C_fcall f_10425(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10433)
static void C_fcall f_10433(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4033)
static void C_fcall f_4033(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8577)
static void C_ccall f_8577(C_word c,C_word *av) C_noret;
C_noret_decl(f_8573)
static void C_ccall f_8573(C_word c,C_word *av) C_noret;
C_noret_decl(f_11760)
static void C_fcall f_11760(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10455)
static void C_ccall f_10455(C_word c,C_word *av) C_noret;
C_noret_decl(f_10459)
static void C_fcall f_10459(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11775)
static void C_ccall f_11775(C_word c,C_word *av) C_noret;
C_noret_decl(f_10042)
static void C_ccall f_10042(C_word c,C_word *av) C_noret;
C_noret_decl(f_8197)
static void C_ccall f_8197(C_word c,C_word *av) C_noret;
C_noret_decl(f_11021)
static void C_fcall f_11021(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word *av) C_noret;
C_noret_decl(f_11789)
static void C_ccall f_11789(C_word c,C_word *av) C_noret;
C_noret_decl(f_11786)
static void C_ccall f_11786(C_word c,C_word *av) C_noret;
C_noret_decl(f_8194)
static void C_ccall f_8194(C_word c,C_word *av) C_noret;
C_noret_decl(f_8191)
static void C_ccall f_8191(C_word c,C_word *av) C_noret;
C_noret_decl(f_8188)
static void C_ccall f_8188(C_word c,C_word *av) C_noret;
C_noret_decl(f_8503)
static void C_ccall f_8503(C_word c,C_word *av) C_noret;
C_noret_decl(f_11710)
static void C_ccall f_11710(C_word c,C_word *av) C_noret;
C_noret_decl(f_8185)
static void C_ccall f_8185(C_word c,C_word *av) C_noret;
C_noret_decl(f_8182)
static void C_ccall f_8182(C_word c,C_word *av) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word *av) C_noret;
C_noret_decl(f_8179)
static void C_ccall f_8179(C_word c,C_word *av) C_noret;
C_noret_decl(f_4076)
static void C_fcall f_4076(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8537)
static void C_ccall f_8537(C_word c,C_word *av) C_noret;
C_noret_decl(f_8176)
static void C_ccall f_8176(C_word c,C_word *av) C_noret;
C_noret_decl(f_4396)
static void C_fcall f_4396(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10085)
static void C_fcall f_10085(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10083)
static void C_ccall f_10083(C_word c,C_word *av) C_noret;
C_noret_decl(f_4390)
static void C_ccall f_4390(C_word c,C_word *av) C_noret;
C_noret_decl(f_4092)
static void C_fcall f_4092(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5375)
static void C_fcall f_5375(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9993)
static void C_ccall f_9993(C_word c,C_word *av) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word *av) C_noret;
C_noret_decl(f_10322)
static void C_ccall f_10322(C_word c,C_word *av) C_noret;
C_noret_decl(f_4362)
static void C_ccall f_4362(C_word c,C_word *av) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word *av) C_noret;
C_noret_decl(f_10332)
static void C_ccall f_10332(C_word c,C_word *av) C_noret;
C_noret_decl(f_8140)
static void C_ccall f_8140(C_word c,C_word *av) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word *av) C_noret;
C_noret_decl(f_9973)
static void C_ccall f_9973(C_word c,C_word *av) C_noret;
C_noret_decl(f_10343)
static void C_ccall f_10343(C_word c,C_word *av) C_noret;
C_noret_decl(f_10353)
static void C_ccall f_10353(C_word c,C_word *av) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word *av) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word *av) C_noret;
C_noret_decl(f_10362)
static void C_ccall f_10362(C_word c,C_word *av) C_noret;
C_noret_decl(f_8107)
static void C_fcall f_8107(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4983)
static void C_fcall f_4983(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4379)
static void C_fcall f_4379(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6093)
static void C_ccall f_6093(C_word c,C_word *av) C_noret;
C_noret_decl(f_6091)
static void C_ccall f_6091(C_word c,C_word *av) C_noret;
C_noret_decl(f_8101)
static void C_fcall f_8101(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6097)
static void C_ccall f_6097(C_word c,C_word *av) C_noret;
C_noret_decl(f_9881)
static void C_ccall f_9881(C_word c,C_word *av) C_noret;
C_noret_decl(f_4927)
static void C_fcall f_4927(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9879)
static void C_ccall f_9879(C_word c,C_word *av) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word *av) C_noret;
C_noret_decl(f_9894)
static void C_ccall f_9894(C_word c,C_word *av) C_noret;
C_noret_decl(f_9892)
static void C_ccall f_9892(C_word c,C_word *av) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word *av) C_noret;
C_noret_decl(f_4209)
static C_word C_fcall f_4209(C_word t0,C_word t1);
C_noret_decl(f_6983)
static void C_ccall f_6983(C_word c,C_word *av) C_noret;
C_noret_decl(f_9912)
static void C_fcall f_9912(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6989)
static void C_ccall f_6989(C_word c,C_word *av) C_noret;
C_noret_decl(f_9910)
static void C_ccall f_9910(C_word c,C_word *av) C_noret;
C_noret_decl(f_4496)
static void C_ccall f_4496(C_word c,C_word *av) C_noret;
C_noret_decl(f_9922)
static void C_fcall f_9922(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5315)
static void C_ccall f_5315(C_word c,C_word *av) C_noret;
C_noret_decl(f_4465)
static void C_fcall f_4465(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word *av) C_noret;
C_noret_decl(f_6067)
static void C_fcall f_6067(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4463)
static void C_ccall f_4463(C_word c,C_word *av) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word *av) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word *av) C_noret;
C_noret_decl(f_8395)
static void C_fcall f_8395(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word *av) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word *av) C_noret;
C_noret_decl(f_9381)
static void C_ccall f_9381(C_word c,C_word *av) C_noret;
C_noret_decl(f_4908)
static void C_fcall f_4908(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word *av) C_noret;
C_noret_decl(f_9391)
static void C_fcall f_9391(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8306)
static void C_ccall f_8306(C_word c,C_word *av) C_noret;
C_noret_decl(f_4254)
static void C_ccall f_4254(C_word c,C_word *av) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word *av) C_noret;
C_noret_decl(f_11194)
static void C_ccall f_11194(C_word c,C_word *av) C_noret;
C_noret_decl(f_9398)
static void C_ccall f_9398(C_word c,C_word *av) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word *av) C_noret;
C_noret_decl(f_11191)
static void C_ccall f_11191(C_word c,C_word *av) C_noret;
C_noret_decl(f_9425)
static void C_ccall f_9425(C_word c,C_word *av) C_noret;
C_noret_decl(f_9418)
static void C_ccall f_9418(C_word c,C_word *av) C_noret;
C_noret_decl(f_9368)
static void C_ccall f_9368(C_word c,C_word *av) C_noret;
C_noret_decl(f_5871)
static void C_ccall f_5871(C_word c,C_word *av) C_noret;
C_noret_decl(f_9432)
static void C_ccall f_9432(C_word c,C_word *av) C_noret;
C_noret_decl(f_9361)
static void C_ccall f_9361(C_word c,C_word *av) C_noret;
C_noret_decl(f_9434)
static void C_fcall f_9434(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9375)
static void C_ccall f_9375(C_word c,C_word *av) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word *av) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word *av) C_noret;
C_noret_decl(f_3759)
static void C_fcall f_3759(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6901)
static void C_ccall f_6901(C_word c,C_word *av) C_noret;
C_noret_decl(f_6907)
static void C_ccall f_6907(C_word c,C_word *av) C_noret;
C_noret_decl(f_6904)
static void C_ccall f_6904(C_word c,C_word *av) C_noret;
C_noret_decl(f_9455)
static void C_ccall f_9455(C_word c,C_word *av) C_noret;
C_noret_decl(f_11145)
static void C_ccall f_11145(C_word c,C_word *av) C_noret;
C_noret_decl(f_6910)
static void C_ccall f_6910(C_word c,C_word *av) C_noret;
C_noret_decl(f_11151)
static void C_ccall f_11151(C_word c,C_word *av) C_noret;
C_noret_decl(f_11154)
static void C_ccall f_11154(C_word c,C_word *av) C_noret;
C_noret_decl(f_11942)
static void C_ccall f_11942(C_word c,C_word *av) C_noret;
C_noret_decl(f_9832)
static void C_ccall f_9832(C_word c,C_word *av) C_noret;
C_noret_decl(f_4227)
static void C_ccall f_4227(C_word c,C_word *av) C_noret;
C_noret_decl(f_5833)
static void C_fcall f_5833(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6923)
static void C_ccall f_6923(C_word c,C_word *av) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word *av) C_noret;
C_noret_decl(f_3705)
static void C_fcall f_3705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9476)
static void C_fcall f_9476(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9475)
static void C_ccall f_9475(C_word c,C_word *av) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word *av) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word *av) C_noret;
C_noret_decl(f_11955)
static void C_ccall f_11955(C_word c,C_word *av) C_noret;
C_noret_decl(f_11953)
static void C_ccall f_11953(C_word c,C_word *av) C_noret;
C_noret_decl(f_9468)
static void C_ccall f_9468(C_word c,C_word *av) C_noret;
C_noret_decl(f_6895)
static void C_ccall f_6895(C_word c,C_word *av) C_noret;
C_noret_decl(f_6898)
static void C_ccall f_6898(C_word c,C_word *av) C_noret;
C_noret_decl(f_9840)
static void C_ccall f_9840(C_word c,C_word *av) C_noret;
C_noret_decl(f_9842)
static void C_ccall f_9842(C_word c,C_word *av) C_noret;
C_noret_decl(f_6696)
static void C_ccall f_6696(C_word c,C_word *av) C_noret;
C_noret_decl(f_6694)
static void C_ccall f_6694(C_word c,C_word *av) C_noret;
C_noret_decl(f_5821)
static void C_fcall f_5821(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word *av) C_noret;
C_noret_decl(f_11965)
static void C_ccall f_11965(C_word c,C_word *av) C_noret;
C_noret_decl(f_11173)
static void C_ccall f_11173(C_word c,C_word *av) C_noret;
C_noret_decl(f_8120)
static void C_fcall f_8120(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8123)
static void C_ccall f_8123(C_word c,C_word *av) C_noret;
C_noret_decl(f_11963)
static void C_ccall f_11963(C_word c,C_word *av) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word *av) C_noret;
C_noret_decl(f_5333)
static void C_fcall f_5333(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_fcall f_5336(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9850)
static void C_ccall f_9850(C_word c,C_word *av) C_noret;
C_noret_decl(f_6699)
static void C_fcall f_6699(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6942)
static void C_ccall f_6942(C_word c,C_word *av) C_noret;
C_noret_decl(f_9492)
static void C_ccall f_9492(C_word c,C_word *av) C_noret;
C_noret_decl(f_6004)
static void C_ccall f_6004(C_word c,C_word *av) C_noret;
C_noret_decl(f_5852)
static void C_fcall f_5852(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11975)
static void C_ccall f_11975(C_word c,C_word *av) C_noret;
C_noret_decl(f_6944)
static void C_fcall f_6944(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11973)
static void C_ccall f_11973(C_word c,C_word *av) C_noret;
C_noret_decl(f_8381)
static void C_ccall f_8381(C_word c,C_word *av) C_noret;
C_noret_decl(f_6958)
static void C_ccall f_6958(C_word c,C_word *av) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word *av) C_noret;
C_noret_decl(f_11680)
static void C_ccall f_11680(C_word c,C_word *av) C_noret;
C_noret_decl(f_5194)
static void C_ccall f_5194(C_word c,C_word *av) C_noret;
C_noret_decl(f_6962)
static void C_ccall f_6962(C_word c,C_word *av) C_noret;
C_noret_decl(f_8371)
static void C_ccall f_8371(C_word c,C_word *av) C_noret;
C_noret_decl(f_3936)
static void C_fcall f_3936(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11611)
static void C_ccall f_11611(C_word c,C_word *av) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word *av) C_noret;
C_noret_decl(f_6857)
static void C_ccall f_6857(C_word c,C_word *av) C_noret;
C_noret_decl(f_11666)
static void C_ccall f_11666(C_word c,C_word *av) C_noret;
C_noret_decl(f_11921)
static void C_ccall f_11921(C_word c,C_word *av) C_noret;
C_noret_decl(f_11925)
static void C_ccall f_11925(C_word c,C_word *av) C_noret;
C_noret_decl(f_11663)
static void C_ccall f_11663(C_word c,C_word *av) C_noret;
C_noret_decl(f_6860)
static void C_ccall f_6860(C_word c,C_word *av) C_noret;
C_noret_decl(f_6869)
static void C_ccall f_6869(C_word c,C_word *av) C_noret;
C_noret_decl(f_6866)
static void C_ccall f_6866(C_word c,C_word *av) C_noret;
C_noret_decl(f_6863)
static void C_ccall f_6863(C_word c,C_word *av) C_noret;
C_noret_decl(f_11936)
static void C_ccall f_11936(C_word c,C_word *av) C_noret;
C_noret_decl(f_11938)
static void C_ccall f_11938(C_word c,C_word *av) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word *av) C_noret;
C_noret_decl(f_11677)
static void C_ccall f_11677(C_word c,C_word *av) C_noret;
C_noret_decl(f_6876)
static void C_ccall f_6876(C_word c,C_word *av) C_noret;
C_noret_decl(f_9017)
static void C_ccall f_9017(C_word c,C_word *av) C_noret;
C_noret_decl(f_9818)
static void C_ccall f_9818(C_word c,C_word *av) C_noret;
C_noret_decl(f_9014)
static void C_fcall f_9014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9030)
static void C_ccall f_9030(C_word c,C_word *av) C_noret;
C_noret_decl(f_6883)
static void C_ccall f_6883(C_word c,C_word *av) C_noret;
C_noret_decl(f_6886)
static void C_ccall f_6886(C_word c,C_word *av) C_noret;
C_noret_decl(f_7674)
static void C_ccall f_7674(C_word c,C_word *av) C_noret;
C_noret_decl(f_9040)
static void C_fcall f_9040(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6817)
static void C_ccall f_6817(C_word c,C_word *av) C_noret;
C_noret_decl(f_9038)
static void C_ccall f_9038(C_word c,C_word *av) C_noret;
C_noret_decl(f_9034)
static void C_ccall f_9034(C_word c,C_word *av) C_noret;
C_noret_decl(f_6938)
static void C_ccall f_6938(C_word c,C_word *av) C_noret;
C_noret_decl(f_3984)
static void C_fcall f_3984(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11373)
static void C_ccall f_11373(C_word c,C_word *av) C_noret;
C_noret_decl(f_11375)
static void C_ccall f_11375(C_word c,C_word *av) C_noret;
C_noret_decl(f_7652)
static void C_ccall f_7652(C_word c,C_word *av) C_noret;
C_noret_decl(f_6829)
static void C_ccall f_6829(C_word c,C_word *av) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word *av) C_noret;
C_noret_decl(f_9061)
static void C_fcall f_9061(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6831)
static void C_fcall f_6831(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6838)
static void C_ccall f_6838(C_word c,C_word *av) C_noret;
C_noret_decl(f_9866)
static void C_ccall f_9866(C_word c,C_word *av) C_noret;
C_noret_decl(f_9858)
static void C_ccall f_9858(C_word c,C_word *av) C_noret;
C_noret_decl(f_11398)
static void C_ccall f_11398(C_word c,C_word *av) C_noret;
C_noret_decl(f_7635)
static void C_ccall f_7635(C_word c,C_word *av) C_noret;
C_noret_decl(f_6847)
static void C_fcall f_6847(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6845)
static void C_ccall f_6845(C_word c,C_word *av) C_noret;
C_noret_decl(f_9868)
static void C_ccall f_9868(C_word c,C_word *av) C_noret;
C_noret_decl(f_11690)
static void C_ccall f_11690(C_word c,C_word *av) C_noret;
C_noret_decl(f_11697)
static void C_ccall f_11697(C_word c,C_word *av) C_noret;
C_noret_decl(f_6033)
static void C_fcall f_6033(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9011)
static void C_ccall f_9011(C_word c,C_word *av) C_noret;
C_noret_decl(f_7618)
static void C_ccall f_7618(C_word c,C_word *av) C_noret;
C_noret_decl(f_6671)
static void C_ccall f_6671(C_word c,C_word *av) C_noret;
C_noret_decl(f_6802)
static void C_ccall f_6802(C_word c,C_word *av) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word *av) C_noret;
C_noret_decl(f_3831)
static void C_ccall f_3831(C_word c,C_word *av) C_noret;
C_noret_decl(f_7732)
static void C_ccall f_7732(C_word c,C_word *av) C_noret;
C_noret_decl(f_7763)
static void C_fcall f_7763(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7711)
static void C_fcall f_7711(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10903)
static void C_ccall f_10903(C_word c,C_word *av) C_noret;
C_noret_decl(f_10900)
static void C_ccall f_10900(C_word c,C_word *av) C_noret;
C_noret_decl(f_9143)
static void C_ccall f_9143(C_word c,C_word *av) C_noret;
C_noret_decl(f_7771)
static void C_fcall f_7771(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9117)
static void C_ccall f_9117(C_word c,C_word *av) C_noret;
C_noret_decl(f_9113)
static void C_ccall f_9113(C_word c,C_word *av) C_noret;
C_noret_decl(f_11417)
static void C_ccall f_11417(C_word c,C_word *av) C_noret;
C_noret_decl(f_11427)
static void C_ccall f_11427(C_word c,C_word *av) C_noret;
C_noret_decl(f_11425)
static void C_ccall f_11425(C_word c,C_word *av) C_noret;
C_noret_decl(f_11221)
static void C_ccall f_11221(C_word c,C_word *av) C_noret;
C_noret_decl(f_7373)
static void C_ccall f_7373(C_word c,C_word *av) C_noret;
C_noret_decl(f_9138)
static void C_ccall f_9138(C_word c,C_word *av) C_noret;
C_noret_decl(f_9134)
static void C_ccall f_9134(C_word c,C_word *av) C_noret;
C_noret_decl(f_10218)
static void C_ccall f_10218(C_word c,C_word *av) C_noret;
C_noret_decl(f_10211)
static void C_ccall f_10211(C_word c,C_word *av) C_noret;
C_noret_decl(f_10205)
static void C_ccall f_10205(C_word c,C_word *av) C_noret;
C_noret_decl(f_10207)
static void C_ccall f_10207(C_word c,C_word *av) C_noret;
C_noret_decl(f_10238)
static void C_ccall f_10238(C_word c,C_word *av) C_noret;
C_noret_decl(f_5141)
static void C_fcall f_5141(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9904)
static void C_ccall f_9904(C_word c,C_word *av) C_noret;
C_noret_decl(f_9901)
static void C_ccall f_9901(C_word c,C_word *av) C_noret;
C_noret_decl(f_9907)
static void C_ccall f_9907(C_word c,C_word *av) C_noret;
C_noret_decl(f_9955)
static void C_ccall f_9955(C_word c,C_word *av) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word *av) C_noret;
C_noret_decl(f_5597)
static void C_ccall f_5597(C_word c,C_word *av) C_noret;
C_noret_decl(f_9936)
static void C_ccall f_9936(C_word c,C_word *av) C_noret;
C_noret_decl(f_4952)
static void C_fcall f_4952(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8688)
static void C_ccall f_8688(C_word c,C_word *av) C_noret;
C_noret_decl(f_8684)
static void C_ccall f_8684(C_word c,C_word *av) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word *av) C_noret;
C_noret_decl(f_4972)
static void C_ccall f_4972(C_word c,C_word *av) C_noret;
C_noret_decl(f_4724)
static void C_fcall f_4724(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4969)
static void C_ccall f_4969(C_word c,C_word *av) C_noret;
C_noret_decl(f_7195)
static void C_fcall f_7195(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8651)
static void C_ccall trf_8651(C_word c,C_word *av) C_noret;
static void C_ccall trf_8651(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8651(t0,t1);}

C_noret_decl(trf_7171)
static void C_ccall trf_7171(C_word c,C_word *av) C_noret;
static void C_ccall trf_7171(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7171(t0,t1);}

C_noret_decl(trf_7176)
static void C_ccall trf_7176(C_word c,C_word *av) C_noret;
static void C_ccall trf_7176(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7176(t0,t1,t2,t3);}

C_noret_decl(trf_4766)
static void C_ccall trf_4766(C_word c,C_word *av) C_noret;
static void C_ccall trf_4766(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4766(t0,t1,t2);}

C_noret_decl(trf_4762)
static void C_ccall trf_4762(C_word c,C_word *av) C_noret;
static void C_ccall trf_4762(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4762(t0,t1);}

C_noret_decl(trf_10953)
static void C_ccall trf_10953(C_word c,C_word *av) C_noret;
static void C_ccall trf_10953(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10953(t0,t1,t2);}

C_noret_decl(trf_9517)
static void C_ccall trf_9517(C_word c,C_word *av) C_noret;
static void C_ccall trf_9517(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9517(t0,t1,t2);}

C_noret_decl(trf_9784)
static void C_ccall trf_9784(C_word c,C_word *av) C_noret;
static void C_ccall trf_9784(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9784(t0,t1);}

C_noret_decl(trf_3695)
static void C_ccall trf_3695(C_word c,C_word *av) C_noret;
static void C_ccall trf_3695(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3695(t0,t1,t2);}

C_noret_decl(trf_6305)
static void C_ccall trf_6305(C_word c,C_word *av) C_noret;
static void C_ccall trf_6305(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_6305(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4520)
static void C_ccall trf_4520(C_word c,C_word *av) C_noret;
static void C_ccall trf_4520(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4520(t0,t1,t2);}

C_noret_decl(trf_6325)
static void C_ccall trf_6325(C_word c,C_word *av) C_noret;
static void C_ccall trf_6325(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6325(t0,t1);}

C_noret_decl(trf_6617)
static void C_ccall trf_6617(C_word c,C_word *av) C_noret;
static void C_ccall trf_6617(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6617(t0,t1,t2,t3);}

C_noret_decl(trf_6614)
static void C_ccall trf_6614(C_word c,C_word *av) C_noret;
static void C_ccall trf_6614(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6614(t0,t1,t2,t3);}

C_noret_decl(trf_8444)
static void C_ccall trf_8444(C_word c,C_word *av) C_noret;
static void C_ccall trf_8444(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8444(t0,t1);}

C_noret_decl(trf_4539)
static void C_ccall trf_4539(C_word c,C_word *av) C_noret;
static void C_ccall trf_4539(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_4539(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10664)
static void C_ccall trf_10664(C_word c,C_word *av) C_noret;
static void C_ccall trf_10664(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10664(t0,t1);}

C_noret_decl(trf_5703)
static void C_ccall trf_5703(C_word c,C_word *av) C_noret;
static void C_ccall trf_5703(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5703(t0,t1,t2);}

C_noret_decl(trf_6299)
static void C_ccall trf_6299(C_word c,C_word *av) C_noret;
static void C_ccall trf_6299(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6299(t0,t1,t2);}

C_noret_decl(trf_5286)
static void C_ccall trf_5286(C_word c,C_word *av) C_noret;
static void C_ccall trf_5286(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5286(t0,t1);}

C_noret_decl(trf_6348)
static void C_ccall trf_6348(C_word c,C_word *av) C_noret;
static void C_ccall trf_6348(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6348(t0,t1,t2);}

C_noret_decl(trf_3858)
static void C_ccall trf_3858(C_word c,C_word *av) C_noret;
static void C_ccall trf_3858(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3858(t0,t1,t2);}

C_noret_decl(trf_10815)
static void C_ccall trf_10815(C_word c,C_word *av) C_noret;
static void C_ccall trf_10815(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10815(t0,t1,t2,t3);}

C_noret_decl(trf_5299)
static void C_ccall trf_5299(C_word c,C_word *av) C_noret;
static void C_ccall trf_5299(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5299(t0,t1);}

C_noret_decl(trf_7585)
static void C_ccall trf_7585(C_word c,C_word *av) C_noret;
static void C_ccall trf_7585(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7585(t0,t1);}

C_noret_decl(trf_5206)
static void C_ccall trf_5206(C_word c,C_word *av) C_noret;
static void C_ccall trf_5206(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5206(t0,t1,t2);}

C_noret_decl(trf_7567)
static void C_ccall trf_7567(C_word c,C_word *av) C_noret;
static void C_ccall trf_7567(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7567(t0,t1,t2);}

C_noret_decl(trf_4110)
static void C_ccall trf_4110(C_word c,C_word *av) C_noret;
static void C_ccall trf_4110(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4110(t0,t1,t2);}

C_noret_decl(trf_4126)
static void C_ccall trf_4126(C_word c,C_word *av) C_noret;
static void C_ccall trf_4126(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4126(t0,t1);}

C_noret_decl(trf_11608)
static void C_ccall trf_11608(C_word c,C_word *av) C_noret;
static void C_ccall trf_11608(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11608(t0,t1);}

C_noret_decl(trf_10741)
static void C_ccall trf_10741(C_word c,C_word *av) C_noret;
static void C_ccall trf_10741(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10741(t0,t1,t2);}

C_noret_decl(trf_10252)
static void C_ccall trf_10252(C_word c,C_word *av) C_noret;
static void C_ccall trf_10252(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10252(t0,t1,t2,t3);}

C_noret_decl(trf_10639)
static void C_ccall trf_10639(C_word c,C_word *av) C_noret;
static void C_ccall trf_10639(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10639(t0,t1,t2);}

C_noret_decl(trf_4607)
static void C_ccall trf_4607(C_word c,C_word *av) C_noret;
static void C_ccall trf_4607(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4607(t0,t1);}

C_noret_decl(trf_4853)
static void C_ccall trf_4853(C_word c,C_word *av) C_noret;
static void C_ccall trf_4853(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4853(t0,t1,t2);}

C_noret_decl(trf_10262)
static void C_ccall trf_10262(C_word c,C_word *av) C_noret;
static void C_ccall trf_10262(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10262(t0,t1,t2,t3);}

C_noret_decl(trf_10689)
static void C_ccall trf_10689(C_word c,C_word *av) C_noret;
static void C_ccall trf_10689(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10689(t0,t1,t2);}

C_noret_decl(trf_4655)
static void C_ccall trf_4655(C_word c,C_word *av) C_noret;
static void C_ccall trf_4655(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4655(t0,t1,t2);}

C_noret_decl(trf_5462)
static void C_ccall trf_5462(C_word c,C_word *av) C_noret;
static void C_ccall trf_5462(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5462(t0,t1);}

C_noret_decl(trf_7094)
static void C_ccall trf_7094(C_word c,C_word *av) C_noret;
static void C_ccall trf_7094(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7094(t0,t1,t2);}

C_noret_decl(trf_4583)
static void C_ccall trf_4583(C_word c,C_word *av) C_noret;
static void C_ccall trf_4583(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4583(t0,t1,t2);}

C_noret_decl(trf_4301)
static void C_ccall trf_4301(C_word c,C_word *av) C_noret;
static void C_ccall trf_4301(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4301(t0,t1,t2);}

C_noret_decl(trf_10596)
static void C_ccall trf_10596(C_word c,C_word *av) C_noret;
static void C_ccall trf_10596(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10596(t0,t1);}

C_noret_decl(trf_7200)
static void C_ccall trf_7200(C_word c,C_word *av) C_noret;
static void C_ccall trf_7200(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7200(t0,t1,t2,t3);}

C_noret_decl(trf_4341)
static void C_ccall trf_4341(C_word c,C_word *av) C_noret;
static void C_ccall trf_4341(C_word c,C_word *av){
C_word t0=av[6];
C_word t1=av[5];
C_word t2=av[4];
C_word t3=av[3];
C_word t4=av[2];
C_word t5=av[1];
C_word t6=av[0];
f_4341(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4413)
static void C_ccall trf_4413(C_word c,C_word *av) C_noret;
static void C_ccall trf_4413(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4413(t0,t1);}

C_noret_decl(trf_5971)
static void C_ccall trf_5971(C_word c,C_word *av) C_noret;
static void C_ccall trf_5971(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_5971(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5978)
static void C_ccall trf_5978(C_word c,C_word *av) C_noret;
static void C_ccall trf_5978(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5978(t0,t1);}

C_noret_decl(trf_6778)
static void C_ccall trf_6778(C_word c,C_word *av) C_noret;
static void C_ccall trf_6778(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6778(t0,t1,t2);}

C_noret_decl(trf_6193)
static void C_ccall trf_6193(C_word c,C_word *av) C_noret;
static void C_ccall trf_6193(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6193(t0,t1);}

C_noret_decl(trf_5013)
static void C_ccall trf_5013(C_word c,C_word *av) C_noret;
static void C_ccall trf_5013(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5013(t0,t1);}

C_noret_decl(trf_10896)
static void C_ccall trf_10896(C_word c,C_word *av) C_noret;
static void C_ccall trf_10896(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10896(t0,t1);}

C_noret_decl(trf_5001)
static void C_ccall trf_5001(C_word c,C_word *av) C_noret;
static void C_ccall trf_5001(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5001(t0,t1);}

C_noret_decl(trf_6109)
static void C_ccall trf_6109(C_word c,C_word *av) C_noret;
static void C_ccall trf_6109(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_6109(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7055)
static void C_ccall trf_7055(C_word c,C_word *av) C_noret;
static void C_ccall trf_7055(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7055(t0,t1,t2);}

C_noret_decl(trf_6119)
static void C_ccall trf_6119(C_word c,C_word *av) C_noret;
static void C_ccall trf_6119(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_6119(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7043)
static void C_ccall trf_7043(C_word c,C_word *av) C_noret;
static void C_ccall trf_7043(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_7043(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7914)
static void C_ccall trf_7914(C_word c,C_word *av) C_noret;
static void C_ccall trf_7914(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7914(t0,t1,t2);}

C_noret_decl(trf_10058)
static void C_ccall trf_10058(C_word c,C_word *av) C_noret;
static void C_ccall trf_10058(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10058(t0,t1,t2);}

C_noret_decl(trf_5637)
static void C_ccall trf_5637(C_word c,C_word *av) C_noret;
static void C_ccall trf_5637(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5637(t0,t1,t2,t3);}

C_noret_decl(trf_6146)
static void C_ccall trf_6146(C_word c,C_word *av) C_noret;
static void C_ccall trf_6146(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6146(t0,t1,t2);}

C_noret_decl(trf_10425)
static void C_ccall trf_10425(C_word c,C_word *av) C_noret;
static void C_ccall trf_10425(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10425(t0,t1,t2);}

C_noret_decl(trf_10433)
static void C_ccall trf_10433(C_word c,C_word *av) C_noret;
static void C_ccall trf_10433(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10433(t0,t1,t2);}

C_noret_decl(trf_4033)
static void C_ccall trf_4033(C_word c,C_word *av) C_noret;
static void C_ccall trf_4033(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4033(t0,t1,t2);}

C_noret_decl(trf_11760)
static void C_ccall trf_11760(C_word c,C_word *av) C_noret;
static void C_ccall trf_11760(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11760(t0,t1,t2);}

C_noret_decl(trf_10459)
static void C_ccall trf_10459(C_word c,C_word *av) C_noret;
static void C_ccall trf_10459(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10459(t0,t1,t2);}

C_noret_decl(trf_11021)
static void C_ccall trf_11021(C_word c,C_word *av) C_noret;
static void C_ccall trf_11021(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_11021(t0,t1,t2,t3);}

C_noret_decl(trf_4076)
static void C_ccall trf_4076(C_word c,C_word *av) C_noret;
static void C_ccall trf_4076(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4076(t0,t1,t2);}

C_noret_decl(trf_4396)
static void C_ccall trf_4396(C_word c,C_word *av) C_noret;
static void C_ccall trf_4396(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4396(t0,t1,t2);}

C_noret_decl(trf_10085)
static void C_ccall trf_10085(C_word c,C_word *av) C_noret;
static void C_ccall trf_10085(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10085(t0,t1,t2);}

C_noret_decl(trf_4092)
static void C_ccall trf_4092(C_word c,C_word *av) C_noret;
static void C_ccall trf_4092(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4092(t0,t1,t2);}

C_noret_decl(trf_5375)
static void C_ccall trf_5375(C_word c,C_word *av) C_noret;
static void C_ccall trf_5375(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5375(t0,t1);}

C_noret_decl(trf_8107)
static void C_ccall trf_8107(C_word c,C_word *av) C_noret;
static void C_ccall trf_8107(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_8107(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4983)
static void C_ccall trf_4983(C_word c,C_word *av) C_noret;
static void C_ccall trf_4983(C_word c,C_word *av){
C_word t0=av[6];
C_word t1=av[5];
C_word t2=av[4];
C_word t3=av[3];
C_word t4=av[2];
C_word t5=av[1];
C_word t6=av[0];
f_4983(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4379)
static void C_ccall trf_4379(C_word c,C_word *av) C_noret;
static void C_ccall trf_4379(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4379(t0,t1);}

C_noret_decl(trf_8101)
static void C_ccall trf_8101(C_word c,C_word *av) C_noret;
static void C_ccall trf_8101(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_8101(t0,t1,t2,t3);}

C_noret_decl(trf_4927)
static void C_ccall trf_4927(C_word c,C_word *av) C_noret;
static void C_ccall trf_4927(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4927(t0,t1);}

C_noret_decl(trf_9912)
static void C_ccall trf_9912(C_word c,C_word *av) C_noret;
static void C_ccall trf_9912(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9912(t0,t1,t2);}

C_noret_decl(trf_9922)
static void C_ccall trf_9922(C_word c,C_word *av) C_noret;
static void C_ccall trf_9922(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9922(t0,t1,t2);}

C_noret_decl(trf_4465)
static void C_ccall trf_4465(C_word c,C_word *av) C_noret;
static void C_ccall trf_4465(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4465(t0,t1);}

C_noret_decl(trf_6067)
static void C_ccall trf_6067(C_word c,C_word *av) C_noret;
static void C_ccall trf_6067(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6067(t0,t1,t2,t3);}

C_noret_decl(trf_8395)
static void C_ccall trf_8395(C_word c,C_word *av) C_noret;
static void C_ccall trf_8395(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8395(t0,t1,t2);}

C_noret_decl(trf_4908)
static void C_ccall trf_4908(C_word c,C_word *av) C_noret;
static void C_ccall trf_4908(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4908(t0,t1,t2);}

C_noret_decl(trf_9391)
static void C_ccall trf_9391(C_word c,C_word *av) C_noret;
static void C_ccall trf_9391(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9391(t0,t1,t2);}

C_noret_decl(trf_9434)
static void C_ccall trf_9434(C_word c,C_word *av) C_noret;
static void C_ccall trf_9434(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9434(t0,t1,t2);}

C_noret_decl(trf_3759)
static void C_ccall trf_3759(C_word c,C_word *av) C_noret;
static void C_ccall trf_3759(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3759(t0,t1,t2);}

C_noret_decl(trf_5833)
static void C_ccall trf_5833(C_word c,C_word *av) C_noret;
static void C_ccall trf_5833(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5833(t0,t1,t2,t3);}

C_noret_decl(trf_3705)
static void C_ccall trf_3705(C_word c,C_word *av) C_noret;
static void C_ccall trf_3705(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3705(t0,t1);}

C_noret_decl(trf_9476)
static void C_ccall trf_9476(C_word c,C_word *av) C_noret;
static void C_ccall trf_9476(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9476(t0,t1,t2);}

C_noret_decl(trf_5821)
static void C_ccall trf_5821(C_word c,C_word *av) C_noret;
static void C_ccall trf_5821(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_5821(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8120)
static void C_ccall trf_8120(C_word c,C_word *av) C_noret;
static void C_ccall trf_8120(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8120(t0,t1);}

C_noret_decl(trf_5333)
static void C_ccall trf_5333(C_word c,C_word *av) C_noret;
static void C_ccall trf_5333(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5333(t0,t1);}

C_noret_decl(trf_5336)
static void C_ccall trf_5336(C_word c,C_word *av) C_noret;
static void C_ccall trf_5336(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5336(t0,t1);}

C_noret_decl(trf_6699)
static void C_ccall trf_6699(C_word c,C_word *av) C_noret;
static void C_ccall trf_6699(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6699(t0,t1,t2,t3);}

C_noret_decl(trf_5852)
static void C_ccall trf_5852(C_word c,C_word *av) C_noret;
static void C_ccall trf_5852(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5852(t0,t1);}

C_noret_decl(trf_6944)
static void C_ccall trf_6944(C_word c,C_word *av) C_noret;
static void C_ccall trf_6944(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6944(t0,t1,t2);}

C_noret_decl(trf_3936)
static void C_ccall trf_3936(C_word c,C_word *av) C_noret;
static void C_ccall trf_3936(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3936(t0,t1,t2,t3);}

C_noret_decl(trf_9014)
static void C_ccall trf_9014(C_word c,C_word *av) C_noret;
static void C_ccall trf_9014(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9014(t0,t1);}

C_noret_decl(trf_9040)
static void C_ccall trf_9040(C_word c,C_word *av) C_noret;
static void C_ccall trf_9040(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9040(t0,t1,t2,t3);}

C_noret_decl(trf_3984)
static void C_ccall trf_3984(C_word c,C_word *av) C_noret;
static void C_ccall trf_3984(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3984(t0,t1,t2,t3);}

C_noret_decl(trf_9061)
static void C_ccall trf_9061(C_word c,C_word *av) C_noret;
static void C_ccall trf_9061(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9061(t0,t1);}

C_noret_decl(trf_6831)
static void C_ccall trf_6831(C_word c,C_word *av) C_noret;
static void C_ccall trf_6831(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6831(t0,t1,t2);}

C_noret_decl(trf_6847)
static void C_ccall trf_6847(C_word c,C_word *av) C_noret;
static void C_ccall trf_6847(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6847(t0,t1,t2);}

C_noret_decl(trf_6033)
static void C_ccall trf_6033(C_word c,C_word *av) C_noret;
static void C_ccall trf_6033(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6033(t0,t1,t2);}

C_noret_decl(trf_7763)
static void C_ccall trf_7763(C_word c,C_word *av) C_noret;
static void C_ccall trf_7763(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7763(t0,t1);}

C_noret_decl(trf_7711)
static void C_ccall trf_7711(C_word c,C_word *av) C_noret;
static void C_ccall trf_7711(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7711(t0,t1,t2,t3);}

C_noret_decl(trf_7771)
static void C_ccall trf_7771(C_word c,C_word *av) C_noret;
static void C_ccall trf_7771(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7771(t0,t1);}

C_noret_decl(trf_5141)
static void C_ccall trf_5141(C_word c,C_word *av) C_noret;
static void C_ccall trf_5141(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5141(t0,t1,t2);}

C_noret_decl(trf_4952)
static void C_ccall trf_4952(C_word c,C_word *av) C_noret;
static void C_ccall trf_4952(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4952(t0,t1,t2);}

C_noret_decl(trf_4724)
static void C_ccall trf_4724(C_word c,C_word *av) C_noret;
static void C_ccall trf_4724(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4724(t0,t1,t2);}

C_noret_decl(trf_7195)
static void C_ccall trf_7195(C_word c,C_word *av) C_noret;
static void C_ccall trf_7195(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7195(t0,t1);}

/* k8649 in k8535 */
static void C_fcall f_8651(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(18,0,1))){
C_save_and_reclaim_args((void *)trf_8651,2,t0,t1);}
a=C_alloc(18);
if(C_truep(t1)){
t2=C_a_i_list(&a,2,lf[209],((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,1,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=C_a_i_list(&a,2,lf[209],((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,1,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4995 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4997(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(29,c,3))){C_save_and_reclaim((void *)f_4997,2,av);}
a=C_alloc(29);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_nullp(((C_word*)t0)[8]))){
t4=t3;
f_5001(t4,((C_word*)t0)[10]);}
else{
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5141,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5201,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* expand.scm:369: reverse */
t10=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}}

/* g2016 in k10846 in k10827 in expand in k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static C_word C_fcall f_10936(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_a_i_list(&a,2,lf[209],t1);
return(C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t2));}

/* k10949 in k10846 in k10827 in expand in k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static void C_ccall f_10951(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_10951,2,av);}
a=C_alloc(14);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10896,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10903,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=C_i_length(((C_word*)t0)[6]);
t7=C_eqp(t6,C_fix(3));
if(C_truep(t7)){
t8=C_i_cadr(((C_word*)t0)[6]);
/* expand.scm:1251: c */
t9=((C_word*)t0)[8];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t5;
av2[2]=((C_word*)t0)[9];
av2[3]=t8;
((C_proc)C_fast_retrieve_proc(t9))(4,av2);}}
else{
t8=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
f_10903(2,av2);}}}

/* k7169 in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_7171(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,4))){
C_save_and_reclaim_args((void *)trf_7171,2,t0,t1);}
a=C_alloc(11);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7176,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li92),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_7176(t5,((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9]);}

/* walk in k7169 in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_7176(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_7176,4,t0,t1,t2,t3);}
a=C_alloc(8);
if(C_truep(C_i_vectorp(t3))){
t4=C_i_vector_ref(t3,C_fix(0));
t5=t4;
t6=C_block_size(t3);
t7=C_fixnum_greaterp(t6,C_fix(1));
t8=(C_truep(t7)?C_i_vector_ref(t3,C_fix(1)):C_fix(0));
t9=t8;
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7195,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=C_eqp(t6,C_fix(1));
if(C_truep(t11)){
t12=t10;
f_7195(t12,C_fix(1));}
else{
t12=C_fixnum_greaterp(t6,C_fix(2));
t13=t10;
f_7195(t13,(C_truep(t12)?C_i_vector_ref(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep(C_immp(t3))){
t4=C_eqp(t3,t2);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
/* expand.scm:771: err */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7055(t5,t1,lf[153]);}}
else{
if(C_truep(C_i_symbolp(t3))){
t4=t3;
t5=C_eqp(t4,lf[154]);
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(t4,lf[155]);
if(C_truep(t6)){
/* expand.scm:775: test */
t7=((C_word*)((C_word*)t0)[4])[1];
f_7043(t7,t1,t2,*((C_word*)lf[156]+1),lf[157]);}
else{
t7=C_eqp(t4,lf[158]);
if(C_truep(t7)){
/* expand.scm:776: test */
t8=((C_word*)((C_word*)t0)[4])[1];
f_7043(t8,t1,t2,*((C_word*)lf[159]+1),lf[160]);}
else{
t8=C_eqp(t4,lf[161]);
if(C_truep(t8)){
/* expand.scm:777: test */
t9=((C_word*)((C_word*)t0)[4])[1];
f_7043(t9,t1,t2,*((C_word*)lf[159]+1),lf[162]);}
else{
t9=C_eqp(t4,lf[163]);
if(C_truep(t9)){
/* expand.scm:778: test */
t10=((C_word*)((C_word*)t0)[4])[1];
f_7043(t10,t1,t2,((C_word*)((C_word*)t0)[5])[1],lf[164]);}
else{
t10=C_eqp(t4,lf[165]);
if(C_truep(t10)){
/* expand.scm:779: test */
t11=((C_word*)((C_word*)t0)[4])[1];
f_7043(t11,t1,t2,*((C_word*)lf[166]+1),lf[167]);}
else{
t11=C_eqp(t4,lf[168]);
if(C_truep(t11)){
/* expand.scm:780: test */
t12=((C_word*)((C_word*)t0)[4])[1];
f_7043(t12,t1,t2,*((C_word*)lf[169]+1),lf[170]);}
else{
t12=C_eqp(t4,lf[171]);
if(C_truep(t12)){
/* expand.scm:781: test */
t13=((C_word*)((C_word*)t0)[4])[1];
f_7043(t13,t1,t2,((C_word*)((C_word*)t0)[6])[1],lf[172]);}
else{
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7373,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:783: test */
t14=((C_word*)((C_word*)t0)[4])[1];
f_7043(t14,t1,t2,t13,lf[173]);}}}}}}}}}
else{
if(C_truep(C_i_pairp(t3))){
if(C_truep(C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7430,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t2);
t6=C_i_car(t3);
/* expand.scm:793: walk */
t15=t4;
t16=t5;
t17=t6;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
/* expand.scm:791: err */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7055(t4,t1,lf[174]);}}
else{
/* expand.scm:790: err */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7055(t4,t1,lf[175]);}}}}}

/* g698 in k4760 in k4605 in loop in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4766(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,6))){
C_save_and_reclaim_args((void *)trf_4766,3,t0,t1,t2);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=C_i_car(t2);
t5=t2;
t6=C_u_i_cdr(t5);
/* expand.scm:292: call-handler */
t7=((C_word*)((C_word*)t0)[7])[1];
f_4341(t7,t3,((C_word*)t0)[4],t4,((C_word*)t0)[2],t6,C_SCHEME_TRUE);}

/* k4274 in k4252 in macro? in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4276(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4276,2,av);}
t2=f_3678(((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=(C_truep(t2)?C_i_pairp(t2):C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4760 in k4605 in loop in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4762(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,4))){
C_save_and_reclaim_args((void *)trf_4762,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li37),tmp=(C_word)a,a+=9,tmp);
/* expand.scm:274: g698 */
t3=t2;
f_4766(t3,((C_word*)t0)[8],t1);}
else{
/* expand.scm:298: expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4539(t2,((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}}

/* expand in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4835(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +5,c,2))){
C_save_and_reclaim((void*)f_4835,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+5);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4839,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
/* expand.scm:309: ##sys#current-environment */
t6=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_i_car(t4);
f_4839(2,av2);}}}

/* k4837 in expand in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4839(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_4839,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_i_nullp(((C_word*)t0)[2]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_i_cdr(((C_word*)t0)[2]));
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4853,a[2]=t2,a[3]=t7,a[4]=t11,a[5]=((C_word)li42),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_4853(t13,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* ##sys#unregister-macro in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4287(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_4287,3,av);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4295,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4299,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:192: ##sys#macro-environment */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* map-loop2010 in k10846 in k10827 in expand in k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static void C_fcall f_10953(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(18,0,2))){
C_save_and_reclaim_args((void *)trf_10953,3,t0,t1,t2);}
a=C_alloc(18);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_10936(C_a_i(&a,15),((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* loop in proper-list? in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static C_word C_fcall f_7150(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
loop:{}
t2=C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep(C_i_pairp(t1))){
t3=t1;
t4=C_u_i_cdr(t3);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* k8328 in k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in ... */
static void C_ccall f_8330(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(51,c,2))){C_save_and_reclaim((void *)f_8330,2,av);}
a=C_alloc(51);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|50,a[1]=(C_word)f_8335,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[2],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],tmp=(C_word)a,a+=51,tmp);
/* synrules.scm:101: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[52];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k4293 in unregister-macro in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4295(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4295,2,av);}
/* expand.scm:190: ##sys#macro-environment */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4297 in unregister-macro in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4299(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4299,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4301,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li18),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4301(t5,((C_word*)t0)[3],t1);}

/* k7140 in loop in k7084 in lambda-list? in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7142(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7142,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_cdr(t2);
/* expand.scm:740: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_7094(t4,((C_word*)t0)[2],t3);}}

/* proper-list? in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7144(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_7144,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7150,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=f_7150(t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in ... */
static void C_ccall f_8322(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,2))){C_save_and_reclaim((void *)f_8322,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8326,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[2],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:98: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[218];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8991 in k8988 */
static void C_ccall f_8993(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,5))){C_save_and_reclaim((void *)f_8993,2,av);}
a=C_alloc(12);
t2=t1;
t3=C_fixnum_plus(((C_word*)t0)[2],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8999,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t6=C_i_car(((C_word*)t0)[4]);
/* synrules.scm:214: free-meta-variables */
t7=((C_word*)((C_word*)t0)[10])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
av2[3]=t4;
av2[4]=((C_word*)t0)[6];
av2[5]=C_SCHEME_END_OF_LIST;
((C_proc)C_fast_retrieve_proc(t7))(6,av2);}}

/* f_8337 in k8333 in k8328 in k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in ... */
static void C_ccall f_8337(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8337,3,av);}
/* synrules.scm:104: c */
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}

/* k8997 in k8991 in k8988 */
static void C_ccall f_8999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_8999,2,av);}
a=C_alloc(12);
t2=t1;
if(C_truep(C_i_nullp(t2))){
/* synrules.scm:216: ##sys#syntax-error-hook */
t3=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[213];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_car(t4);
/* synrules.scm:217: process-template */
t6=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
av2[3]=((C_word*)t0)[11];
av2[4]=((C_word*)t0)[6];
((C_proc)C_fast_retrieve_proc(t6))(5,av2);}}}

/* k8333 in k8328 in k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in ... */
static void C_ccall f_8335(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(119,c,6))){C_save_and_reclaim((void *)f_8335,2,av);}
a=C_alloc(119);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8337,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word)li108),tmp=(C_word)a,a+=5,tmp));
t4=C_mutate2(((C_word *)((C_word*)t0)[5])+1,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8343,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word)li110),tmp=(C_word)a,a+=13,tmp));
t5=C_mutate2(((C_word *)((C_word*)t0)[14])+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8437,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[19],a[6]=((C_word*)t0)[20],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[21],a[9]=((C_word)li112),tmp=(C_word)a,a+=10,tmp));
t6=C_mutate2(((C_word *)((C_word*)t0)[21])+1,(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8503,a[2]=((C_word*)t0)[22],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[23],a[6]=((C_word*)t0)[24],a[7]=((C_word*)t0)[25],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[26],a[13]=((C_word*)t0)[27],a[14]=((C_word*)t0)[28],a[15]=((C_word*)t0)[29],a[16]=((C_word*)t0)[30],a[17]=((C_word*)t0)[31],a[18]=((C_word)li113),tmp=(C_word)a,a+=19,tmp));
t7=C_mutate2(((C_word *)((C_word*)t0)[23])+1,(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8684,a[2]=((C_word*)t0)[32],a[3]=((C_word*)t0)[33],a[4]=((C_word*)t0)[34],a[5]=((C_word*)t0)[35],a[6]=((C_word*)t0)[36],a[7]=((C_word*)t0)[37],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[38],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[39],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[26],a[17]=((C_word)li114),tmp=(C_word)a,a+=18,tmp));
t8=C_mutate2(((C_word *)((C_word*)t0)[20])+1,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8811,a[2]=((C_word*)t0)[22],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[24],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[40],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[26],a[9]=((C_word*)t0)[28],a[10]=((C_word*)t0)[31],a[11]=((C_word)li116),tmp=(C_word)a,a+=12,tmp));
t9=C_mutate2(((C_word *)((C_word*)t0)[18])+1,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8951,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[18],a[4]=((C_word*)t0)[41],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[42],a[7]=((C_word*)t0)[43],a[8]=((C_word*)t0)[44],a[9]=((C_word*)t0)[45],a[10]=((C_word*)t0)[46],a[11]=((C_word*)t0)[47],a[12]=((C_word*)t0)[48],a[13]=((C_word)li118),tmp=(C_word)a,a+=14,tmp));
t10=C_mutate2(((C_word *)((C_word*)t0)[19])+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9143,a[2]=((C_word*)t0)[22],a[3]=((C_word*)t0)[19],a[4]=((C_word*)t0)[31],a[5]=((C_word)li119),tmp=(C_word)a,a+=6,tmp));
t11=C_mutate2(((C_word *)((C_word*)t0)[43])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9220,a[2]=((C_word*)t0)[43],a[3]=((C_word*)t0)[48],a[4]=((C_word)li120),tmp=(C_word)a,a+=5,tmp));
t12=C_mutate2(((C_word *)((C_word*)t0)[31])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9309,a[2]=((C_word*)t0)[48],a[3]=((C_word)li121),tmp=(C_word)a,a+=4,tmp));
t13=C_mutate2(((C_word *)((C_word*)t0)[48])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9337,a[2]=((C_word*)t0)[3],a[3]=((C_word)li122),tmp=(C_word)a,a+=4,tmp));
t14=C_mutate2(((C_word *)((C_word*)t0)[44])+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9361,a[2]=((C_word*)t0)[44],a[3]=((C_word*)t0)[48],a[4]=((C_word)li123),tmp=(C_word)a,a+=5,tmp));
t15=C_mutate2(((C_word *)((C_word*)t0)[41])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9381,a[2]=((C_word*)t0)[3],a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp));
/* synrules.scm:314: make-transformer */
t16=((C_word*)((C_word*)t0)[5])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t16;
av2[1]=((C_word*)t0)[49];
av2[2]=((C_word*)t0)[50];
((C_proc)(void*)(*((C_word*)t16+1)))(3,av2);}}

/* k8988 */
static void C_ccall f_8990(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_8990,2,av);}
a=C_alloc(11);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* synrules.scm:211: segment-depth */
t3=((C_word*)((C_word*)t0)[11])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)C_fast_retrieve_proc(t3))(3,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9113,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[4];
t4=C_u_i_car(t3);
/* synrules.scm:236: process-template */
t5=((C_word*)((C_word*)t0)[5])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
av2[3]=((C_word*)t0)[2];
av2[4]=((C_word*)t0)[6];
((C_proc)C_fast_retrieve_proc(t5))(5,av2);}}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9138,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* synrules.scm:240: vector->list */
t4=*((C_word*)lf[178]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[14])[1],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}}

/* k9513 in k9473 in fixup-macro-environment in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in ... */
static void C_ccall f_9515(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_9515,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* for-each-loop2748 in k9473 in fixup-macro-environment in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in ... */
static void C_fcall f_9517(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_9517,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9527,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* expand.scm:1544: g2749 */
t5=((C_word*)t0)[3];
f_9476(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5572 in k5569 in a5566 in expand-multiple-values-assignment in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5574(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_5574,2,av);}
a=C_alloc(18);
t2=t1;
t3=C_a_i_list(&a,3,lf[72],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5593,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm:455: append */
t6=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[5];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k5569 in a5566 in expand-multiple-values-assignment in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5571(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_5571,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[6];
if(C_truep(t4)){
/* expand.scm:451: gensym */
t5=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_END_OF_LIST;
f_5574(2,av2);}}}

/* k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in ... */
static void C_ccall f_8326(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,2))){C_save_and_reclaim((void *)f_8326,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8330,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[2],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:99: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[217];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in ... */
static void C_ccall f_8301(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,2))){C_save_and_reclaim((void *)f_8301,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,lf[203]);
t4=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8306,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=((C_word*)t0)[22],a[21]=((C_word*)t0)[23],a[22]=((C_word*)t0)[24],a[23]=((C_word*)t0)[2],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[3],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:90: r */
t5=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[221];
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}

/* k9182 in k9167 */
static void C_ccall f_9184(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_9184,2,av);}
/* synrules.scm:252: meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
av2[4]=t1;
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t2))(6,av2);}}

/* k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in ... */
static void C_ccall f_8318(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,2))){C_save_and_reclaim((void *)f_8318,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8322,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[41],a[41]=((C_word*)t0)[42],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[44],a[44]=((C_word*)t0)[45],a[45]=((C_word*)t0)[46],a[46]=((C_word*)t0)[47],a[47]=((C_word*)t0)[2],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:97: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[219];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in ... */
static void C_ccall f_8313(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,2))){C_save_and_reclaim((void *)f_8313,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,lf[206]);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8318,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[2],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:96: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[209];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k7112 in loop in k7084 in lambda-list? in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7114(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_7114,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_not(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_3676(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,4))){C_save_and_reclaim((void *)f_3676,2,av);}
a=C_alloc(18);
t2=C_mutate2((C_word*)lf[3]+1 /* (set! ##sys#active-eval-environment ...) */,t1);
t3=C_mutate2(&lf[4] /* (set! lookup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3678,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2(&lf[6] /* (set! macro-alias ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3695,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[10]+1 /* (set! strip-syntax ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3753,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[12]+1 /* (set! ##sys#strip-syntax ...) */,*((C_word*)lf[10]+1));
t7=C_mutate2((C_word*)lf[13]+1 /* (set! ##sys#extend-se ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3890,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[17]+1 /* (set! ##sys#globalize ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4070,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4154,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:156: make-parameter */
t10=*((C_word*)lf[234]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k3670 in k3666 in k3662 */
static void C_ccall f_3672(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3672,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[2]+1 /* (set! ##sys#current-meta-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3676,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:77: make-parameter */
t4=*((C_word*)lf[234]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[1]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* lookup in k3674 in k3670 in k3666 in k3662 */
static C_word C_fcall f_3678(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;{}
t3=C_u_i_assq(t1,t2);
if(C_truep(t3)){
return(C_i_cdr(t3));}
else{
t4=t1;
t5=C_i_getprop(t4,lf[5],C_SCHEME_FALSE);
return((C_truep(t5)?t5:C_SCHEME_FALSE));}}

/* k11309 in k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_11311(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_11311,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=t1;
f_11076(2,av2);}}
else{
t2=C_u_i_car(((C_word*)t0)[3]);
t3=C_i_vectorp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
f_11076(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=C_u_i_car(((C_word*)t0)[3]);
/* expand.scm:1181: ##sys#srfi-4-vector? */
t6=*((C_word*)lf[311]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}}

/* k9782 in k9753 in k9673 in k9667 in a9661 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in ... */
static void C_fcall f_9784(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(18,0,1))){
C_save_and_reclaim_args((void *)trf_9784,2,t0,t1);}
a=C_alloc(18);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,lf[258],t2);
t4=C_a_i_list(&a,1,t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t7;
av2[1]=C_a_i_cons(&a,2,lf[259],t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[259],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k9167 */
static void C_ccall f_9169(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_9169,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9184,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_i_cddr(((C_word*)t0)[2]);
/* synrules.scm:253: meta-variables */
t8=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[6];
av2[5]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t8))(6,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9203,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* synrules.scm:256: meta-variables */
t7=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t7;
av2[1]=t4;
av2[2]=t6;
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[6];
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t7))(6,av2);}}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9218,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* synrules.scm:258: vector->list */
t3=*((C_word*)lf[178]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}}

/* k11321 in k11309 in k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_11323(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_11323,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=t1;
f_11076(2,av2);}}
else{
t2=C_u_i_car(((C_word*)t0)[3]);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11339,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1183: r */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[209];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_11076(2,av2);}}}}

/* f_8951 in k8333 in k8328 in k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in ... */
static void C_ccall f_8951(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_8951,5,av);}
a=C_alloc(15);
if(C_truep(C_i_symbolp(t2))){
t5=C_i_assq(t2,t4);
if(C_truep(t5)){
t6=C_i_cdr(t5);
t7=t3;
if(C_truep(C_fixnum_less_or_equal_p(t6,t7))){
t8=t2;
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
/* synrules.scm:207: ##sys#syntax-error-hook */
t8=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t1;
av2[2]=lf[212];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}}
else{
t6=C_a_i_list(&a,2,lf[208],t2);
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}
else{
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8990,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],tmp=(C_word)a,a+=15,tmp);
/* synrules.scm:210: segment-template? */
t6=((C_word*)((C_word*)t0)[12])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}}

/* macro-alias in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_3695(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_3695,3,t1,t2,t3);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3702,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:85: ##sys#qualified-symbol? */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[9]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[9]+1);
av2[1]=t4;
av2[2]=t2;
tp(3,av2);}}

/* k4823 in loop in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4825(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4825,2,av);}
t2=f_3678(((C_word*)((C_word*)t0)[2])[1],t1);
if(C_truep(t2)){
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
f_4607(t4,t3);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t3);
t5=((C_word*)t0)[3];
f_4607(t5,t4);}}

/* k8943 in k8839 */
static void C_ccall f_8945(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_8945,2,av);}
a=C_alloc(6);
t2=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);
/* synrules.scm:195: process-pattern */
t3=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[5];
av2[2]=t1;
av2[3]=t2;
av2[4]=((C_word*)t0)[6];
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t3))(6,av2);}}

/* k11337 in k11321 in k11309 in k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_ccall f_11339(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_11339,2,av);}
t2=C_i_caar(((C_word*)t0)[2]);
/* expand.scm:1183: c */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=t1;
av2[3]=t2;
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}

/* k6359 in loop2 in k6341 in k6323 in loop in expand in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6361(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_6361,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[4];
t4=C_u_i_car(t3);
t5=C_eqp(t4,((C_word*)t0)[2]);
if(C_truep(t5)){
/* expand.scm:567: ##sys#defjam-error */
t6=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_6364(2,av2);}}}

/* k6362 in k6359 in loop2 in k6341 in k6323 in loop in expand in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6364(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,5))){C_save_and_reclaim((void *)f_6364,2,av);}
a=C_alloc(12);
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_i_cddr(((C_word*)t0)[4]);
if(C_truep(C_i_pairp(t4))){
t5=C_i_caddr(((C_word*)t0)[4]);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[5]);
t7=C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[6]);
/* expand.scm:568: loop */
t8=((C_word*)((C_word*)t0)[7])[1];
f_6305(t8,((C_word*)t0)[8],((C_word*)t0)[9],t3,t6,t7);}
else{
t5=C_a_i_cons(&a,2,lf[110],((C_word*)t0)[5]);
t6=C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[6]);
/* expand.scm:568: loop */
t7=((C_word*)((C_word*)t0)[7])[1];
f_6305(t7,((C_word*)t0)[8],((C_word*)t0)[9],t3,t5,t6);}}

/* f_8343 in k8333 in k8328 in k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in ... */
static void C_ccall f_8343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(51,c,3))){C_save_and_reclaim((void *)f_8343,3,av);}
a=C_alloc(51);
t3=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);
t4=t3;
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[2])[1]);
t6=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[6])[1],t5);
t7=C_a_i_list(&a,1,t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8371,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t8,a[5]=((C_word*)t0)[9],a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t10=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=((C_word*)t12)[1];
t14=((C_word*)((C_word*)t0)[10])[1];
t15=C_i_check_list_2(t2,lf[16]);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8395,a[2]=t12,a[3]=t18,a[4]=t14,a[5]=t13,a[6]=((C_word)li109),tmp=(C_word)a,a+=7,tmp));
t20=((C_word*)t18)[1];
f_8395(t20,t16,t2);}

/* k8478 in k8442 */
static void C_ccall f_8480(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,5))){C_save_and_reclaim((void *)f_8480,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8465,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8475,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp);
/* synrules.scm:121: process-pattern */
t6=((C_word*)((C_word*)t0)[9])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)((C_word*)t0)[10])[1];
av2[4]=t5;
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t6))(6,av2);}}

/* loop in expand in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6305(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,5))){
C_save_and_reclaim_args((void *)trf_6305,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(15);
if(C_truep(C_i_pairp(t2))){
t6=C_i_car(t2);
t7=t6;
t8=t2;
t9=C_u_i_cdr(t8);
t10=C_i_pairp(t7);
t11=(C_truep(t10)?C_u_i_car(t7):C_SCHEME_FALSE);
t12=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=t9,a[9]=t1,a[10]=t7,a[11]=((C_word*)t0)[5],a[12]=t2,a[13]=((C_word*)t0)[6],a[14]=((C_word*)t0)[7],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t11)){
t13=C_i_symbolp(t11);
t14=t12;
f_6325(t14,(C_truep(t13)?t11:C_SCHEME_FALSE));}
else{
t13=t12;
f_6325(t13,C_SCHEME_FALSE);}}
else{
/* expand.scm:552: fini */
t6=((C_word*)((C_word*)t0)[6])[1];
f_5821(t6,t1,t3,t4,t5,t2);}}

/* k8918 in k8914 in k8839 */
static void C_ccall f_8920(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8920,2,av);}
/* synrules.scm:192: append */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a8474 in k8478 in k8442 */
static void C_ccall f_8475(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_8475,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8471 in k8463 in k8478 in k8442 */
static void C_ccall f_8473(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8473,2,av);}
/* synrules.scm:124: process-template */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=C_fix(0);
av2[4]=t1;
((C_proc)C_fast_retrieve_proc(t2))(5,av2);}}

/* k8914 in k8839 */
static void C_ccall f_8916(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_8916,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8920,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
t6=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);
/* synrules.scm:193: process-pattern */
t7=((C_word*)((C_word*)t0)[6])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=t5;
av2[3]=t6;
av2[4]=((C_word*)t0)[7];
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t7))(6,av2);}}

/* k9588 in k9571 in a9568 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in ... */
static void C_ccall f_9590(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_9590,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t6=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t5);
/* synrules.scm:58: ##sys#process-syntax-rules */
t7=*((C_word*)lf[190]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[5];
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=((C_word*)((C_word*)t0)[4])[1];
av2[4]=((C_word*)((C_word*)t0)[3])[1];
av2[5]=((C_word*)t0)[6];
av2[6]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t7+1)))(7,av2);}}

/* k8636 in k8535 */
static void C_ccall f_8638(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8638,2,av);}
/* synrules.scm:146: process-match */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t1;
av2[4]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t2))(5,av2);}}

/* k8628 in k8535 */
static void C_ccall f_8630(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,1))){C_save_and_reclaim((void *)f_8630,2,av);}
a=C_alloc(18);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5],t3);
t5=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_list(&a,1,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* a4501 in tmp13092 in a4462 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4502(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4502,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[45]+1));
t3=C_mutate2((C_word*)lf[45]+1 /* (set! ##sys#syntax-rules-mismatch ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a4506 in tmp13092 in a4462 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4507(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4507,2,av);}
/* expand.scm:238: handler */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
((C_proc)C_fast_retrieve_proc(t2))(5,av2);}}

/* tmp23093 in a4462 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4520(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_4520,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4526,a[2]=t2,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:207: k565 */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k6323 in loop in expand in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6325(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,6))){
C_save_and_reclaim_args((void *)trf_6325,2,t0,t1);}
a=C_alloc(14);
if(C_truep(C_i_symbolp(t1))){
t2=f_5755(((C_word*)((C_word*)t0)[2])[1],lf[100],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6343,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:561: ##sys#check-syntax */
t4=*((C_word*)lf[54]+1);{
C_word av2[7];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[100];
av2[3]=((C_word*)t0)[10];
av2[4]=lf[112];
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}}
else{
t3=f_5755(((C_word*)((C_word*)t0)[2])[1],lf[101],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6480,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:588: ##sys#check-syntax */
t5=*((C_word*)lf[54]+1);{
C_word av2[6];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[101];
av2[3]=((C_word*)t0)[10];
av2[4]=lf[113];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}
else{
t4=f_5755(((C_word*)((C_word*)t0)[2])[1],lf[102],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6492,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm:592: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word av2[7];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[102];
av2[3]=((C_word*)t0)[10];
av2[4]=lf[114];
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(7,av2);}}
else{
t5=f_5755(((C_word*)((C_word*)t0)[2])[1],lf[103],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6528,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t7=C_i_cdr(((C_word*)t0)[10]);
/* expand.scm:595: ##sys#append */
t8=*((C_word*)lf[70]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t6=C_a_i_list1(&a,1,t1);
if(C_truep(C_i_member(t6,((C_word*)t0)[4]))){
/* expand.scm:598: fini */
t7=((C_word*)((C_word*)t0)[13])[1];
f_5821(t7,((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[12]);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6544,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* expand.scm:599: ##sys#expand-0 */
t8=*((C_word*)lf[32]+1);{
C_word av2[5];
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[10];
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[14];
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}}}}}}
else{
/* expand.scm:558: fini */
t2=((C_word*)((C_word*)t0)[13])[1];
f_5821(t2,((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[12]);}}

/* k9561 in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in ... */
static void C_ccall f_9563(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9563,2,av);}
/* expand.scm:1558: ##sys#fixup-macro-environment */
t2=*((C_word*)lf[231]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* mwalk in match-expression in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6617(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_6617,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t3))){
if(C_truep(C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6671,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=t2;
t6=C_u_i_car(t5);
t7=C_i_car(t3);
/* expand.scm:620: mwalk */
t9=t4;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t4=C_i_assq(t3,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6631,a[2]=t2,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:614: g1235 */
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=f_6631(t5,t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
if(C_truep(C_i_memq(t3,((C_word*)t0)[4]))){
t5=C_a_i_cons(&a,2,t3,t2);
t6=C_a_i_cons(&a,2,t5,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_eqp(t2,t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}}}

/* a9568 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in ... */
static void C_ccall f_9569(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_9569,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9573,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* synrules.scm:49: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[235];
av2[3]=t2;
av2[4]=lf[238];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k9565 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in ... */
static void C_ccall f_9567(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9567,2,av);}
/* synrules.scm:44: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[235];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* match-expression in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6614(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,4))){
C_save_and_reclaim_args((void *)trf_6614,4,t1,t2,t3,t4);}
a=C_alloc(14);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6617,a[2]=t8,a[3]=t6,a[4]=t4,a[5]=((C_word)li71),tmp=(C_word)a,a+=6,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6694,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:623: mwalk */
t11=((C_word*)t8)[1];
f_6617(t11,t10,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_expand_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("expand_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,3));
if(!C_demand(C_calculate_demand(3,c,3))){
C_save_and_reclaim((void*)C_expand_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(3232)){
C_save(t1);
C_rereclaim2(3232*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,358);
lf[0]=C_h_intern(&lf[0],12,"\003sysfeatures");
lf[1]=C_h_intern(&lf[1],23,"\003syscurrent-environment");
lf[2]=C_h_intern(&lf[2],28,"\003syscurrent-meta-environment");
lf[3]=C_h_intern(&lf[3],27,"\003sysactive-eval-environment");
lf[5]=C_h_intern(&lf[5],16,"\004coremacro-alias");
lf[7]=C_h_intern(&lf[7],14,"\004corereal-name");
lf[8]=C_h_intern(&lf[8],6,"gensym");
lf[9]=C_h_intern(&lf[9],21,"\003sysqualified-symbol\077");
lf[10]=C_h_intern(&lf[10],12,"strip-syntax");
lf[11]=C_h_intern(&lf[11],11,"make-vector");
lf[12]=C_h_intern(&lf[12],16,"\003sysstrip-syntax");
lf[13]=C_h_intern(&lf[13],13,"\003sysextend-se");
lf[14]=C_h_intern(&lf[14],8,"for-each");
lf[15]=C_h_intern(&lf[15],6,"append");
lf[16]=C_h_intern(&lf[16],3,"map");
lf[17]=C_h_intern(&lf[17],13,"\003sysglobalize");
lf[18]=C_h_intern(&lf[18],21,"\003sysalias-global-hook");
lf[19]=C_h_intern(&lf[19],21,"\003sysmacro-environment");
lf[20]=C_h_intern(&lf[20],29,"\003syschicken-macro-environment");
lf[21]=C_h_intern(&lf[21],33,"\003syschicken-ffi-macro-environment");
lf[22]=C_h_intern(&lf[22],22,"\003sysensure-transformer");
lf[23]=C_h_intern(&lf[23],18,"\003syser-transformer");
lf[24]=C_h_intern(&lf[24],11,"transformer");
lf[25]=C_h_intern(&lf[25],9,"\003syserror");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000$expected syntax-transformer, but got");
lf[27]=C_h_intern(&lf[27],28,"\003sysextend-macro-environment");
lf[28]=C_h_intern(&lf[28],14,"\003syscopy-macro");
lf[29]=C_h_intern(&lf[29],10,"\003sysmacro\077");
lf[30]=C_h_intern(&lf[30],20,"\003sysunregister-macro");
lf[31]=C_h_intern(&lf[31],19,"\003sysundefine-macro!");
lf[32]=C_h_intern(&lf[32],12,"\003sysexpand-0");
lf[33]=C_h_intern(&lf[33],9,"condition");
lf[34]=C_h_intern(&lf[34],9,"\003sysabort");
lf[35]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[36]=C_h_intern(&lf[36],13,"string-append");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[39]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[40]=C_h_intern(&lf[40],3,"exn");
lf[41]=C_h_intern(&lf[41],21,"\003syssyntax-error-hook");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\030syntax transformer for `");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000@\047 returns original form, which would result in endless expansion");
lf[44]=C_h_intern(&lf[44],14,"symbol->string");
lf[45]=C_h_intern(&lf[45],25,"\003syssyntax-rules-mismatch");
lf[46]=C_h_intern(&lf[46],16,"\003sysdynamic-wind");
lf[47]=C_h_intern(&lf[47],22,"with-exception-handler");
lf[48]=C_h_intern(&lf[48],30,"call-with-current-continuation");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[50]=C_h_intern(&lf[50],8,"\004corelet");
lf[51]=C_h_intern(&lf[51],16,"\004coreloop-lambda");
lf[52]=C_h_intern(&lf[52],12,"\004coreletrec\052");
lf[53]=C_h_intern(&lf[53],8,"\004coreapp");
lf[54]=C_h_intern(&lf[54],16,"\003syscheck-syntax");
lf[55]=C_h_intern(&lf[55],3,"let");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[57]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[58]=C_h_intern(&lf[58],24,"\003syscompiler-syntax-hook");
lf[59]=C_h_intern(&lf[59],24,"\010compilercompiler-syntax");
lf[60]=C_h_intern(&lf[60],25,"\003sysenable-runtime-macros");
lf[61]=C_h_intern(&lf[61],6,"expand");
lf[62]=C_h_intern(&lf[62],10,"\003sysexpand");
lf[63]=C_h_intern(&lf[63],25,"\003sysextended-lambda-list\077");
lf[64]=C_h_intern(&lf[64],6,"#!rest");
lf[65]=C_h_intern(&lf[65],10,"#!optional");
lf[66]=C_h_intern(&lf[66],5,"#!key");
lf[67]=C_h_intern(&lf[67],31,"\003sysexpand-extended-lambda-list");
lf[68]=C_h_intern(&lf[68],5,"cadar");
lf[69]=C_h_intern(&lf[69],7,"reverse");
lf[70]=C_h_intern(&lf[70],10,"\003sysappend");
lf[71]=C_h_intern(&lf[71],10,"\004corequote");
lf[72]=C_h_intern(&lf[72],11,"\004corelambda");
lf[73]=C_h_intern(&lf[73],15,"\003sysget-keyword");
lf[74]=C_h_intern(&lf[74],15,"string->keyword");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[77]=C_h_intern(&lf[77],3,"tmp");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[86]=C_h_intern(&lf[86],14,"let-optionals\052");
lf[87]=C_h_intern(&lf[87],8,"optional");
lf[88]=C_h_intern(&lf[88],4,"let\052");
lf[89]=C_h_intern(&lf[89],16,"\003sysdefjam-error");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000,redefinition of currently used defining form");
lf[91]=C_h_intern(&lf[91],37,"\003sysexpand-multiple-values-assignment");
lf[92]=C_h_intern(&lf[92],20,"\003syscall-with-values");
lf[93]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[94]=C_h_intern(&lf[94],9,"\004coreset!");
lf[95]=C_h_intern(&lf[95],25,"\003sysdecompose-lambda-list");
lf[96]=C_h_intern(&lf[96],21,"\003sysdefine-definition");
lf[97]=C_h_intern(&lf[97],28,"\003sysdefine-syntax-definition");
lf[98]=C_h_intern(&lf[98],28,"\003sysdefine-values-definition");
lf[99]=C_h_intern(&lf[99],21,"\003syscanonicalize-body");
lf[100]=C_h_intern(&lf[100],6,"define");
lf[101]=C_h_intern(&lf[101],13,"define-syntax");
lf[102]=C_h_intern(&lf[102],13,"define-values");
lf[103]=C_h_intern(&lf[103],10,"\004corebegin");
lf[104]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[105]=C_h_intern(&lf[105],18,"\004coreletrec-syntax");
lf[106]=C_h_intern(&lf[106],5,"caadr");
lf[107]=C_h_intern(&lf[107],25,"\003sysexpand-curried-define");
lf[108]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[109]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[110]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[111]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[113]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[116]=C_h_intern(&lf[116],24,"\003sysline-number-database");
lf[117]=C_h_intern(&lf[117],24,"\003syssyntax-error-culprit");
lf[118]=C_h_intern(&lf[118],18,"\003syssyntax-context");
lf[119]=C_h_intern(&lf[119],12,"syntax-error");
lf[120]=C_h_intern(&lf[120],15,"\003syssignal-hook");
lf[121]=C_h_intern(&lf[121],13,"\000syntax-error");
lf[122]=C_h_intern(&lf[122],24,"\003syssyntax-error/context");
lf[123]=C_h_intern(&lf[123],9,"\003sysprint");
lf[124]=C_h_intern(&lf[124],17,"get-output-string");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\006 ...)\047");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\025\012inside expression `(");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\027  Suggesting: `(import ");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\002)\047");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\025  Suggesting one of:\012");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\017\012      (import ");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\002)\047");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000# ...)\047 without importing it first.\012");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000-\012\012  Perhaps you intended to use the syntax `(");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[137]=C_h_intern(&lf[137],6,"syntax");
lf[138]=C_h_intern(&lf[138],7,"\003sysget");
lf[139]=C_h_intern(&lf[139],7,"\004coredb");
lf[140]=C_h_intern(&lf[140],18,"open-output-string");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\024no rule matches form");
lf[142]=C_h_intern(&lf[142],15,"get-line-number");
lf[143]=C_h_intern(&lf[143],18,"\003syshash-table-ref");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\006) in `");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\004\047 - ");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\004in `");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\004\047 - ");
lf[149]=C_h_intern(&lf[149],8,"keyword\077");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[154]=C_h_intern(&lf[154],1,"_");
lf[155]=C_h_intern(&lf[155],4,"pair");
lf[156]=C_h_intern(&lf[156],5,"pair\077");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[158]=C_h_intern(&lf[158],8,"variable");
lf[159]=C_h_intern(&lf[159],7,"symbol\077");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[161]=C_h_intern(&lf[161],6,"symbol");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[163]=C_h_intern(&lf[163],4,"list");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[165]=C_h_intern(&lf[165],6,"number");
lf[166]=C_h_intern(&lf[166],7,"number\077");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[168]=C_h_intern(&lf[168],6,"string");
lf[169]=C_h_intern(&lf[169],7,"string\077");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[171]=C_h_intern(&lf[171],11,"lambda-list");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[176]=C_h_intern(&lf[176],22,"make-er/ir-transformer");
lf[177]=C_h_intern(&lf[177],12,"list->vector");
lf[178]=C_h_intern(&lf[178],12,"vector->list");
lf[179]=C_h_intern(&lf[179],12,"\004corealiased");
lf[180]=C_h_intern(&lf[180],14,"\004coreprimitive");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\033(expand.scm:804) not a list");
lf[182]=C_h_intern(&lf[182],20,"er-macro-transformer");
lf[183]=C_h_intern(&lf[183],20,"ir-macro-transformer");
lf[184]=C_h_intern(&lf[184],18,"\003sysir-transformer");
lf[185]=C_h_intern(&lf[185],29,"\003sysinitial-macro-environment");
lf[187]=C_h_intern(&lf[187],8,"\003syswarn");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000!variable bound multiple times in ");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\012 construct");
lf[190]=C_h_intern(&lf[190],24,"\003sysprocess-syntax-rules");
lf[191]=C_h_intern(&lf[191],7,"\003syscar");
lf[192]=C_h_intern(&lf[192],7,"\003syscdr");
lf[193]=C_h_intern(&lf[193],10,"\003syslength");
lf[194]=C_h_intern(&lf[194],11,"\003sysvector\077");
lf[195]=C_h_intern(&lf[195],16,"\003sysvector->list");
lf[196]=C_h_intern(&lf[196],16,"\003syslist->vector");
lf[197]=C_h_intern(&lf[197],6,"\003sys>=");
lf[198]=C_h_intern(&lf[198],5,"\003sys=");
lf[199]=C_h_intern(&lf[199],5,"\003sys+");
lf[200]=C_h_intern(&lf[200],8,"\003syscons");
lf[201]=C_h_intern(&lf[201],7,"\003syseq\077");
lf[202]=C_h_intern(&lf[202],10,"\003sysequal\077");
lf[203]=C_h_intern(&lf[203],9,"\003syslist\077");
lf[204]=C_h_intern(&lf[204],7,"\003sysmap");
lf[205]=C_h_intern(&lf[205],9,"\003sysmap-n");
lf[206]=C_h_intern(&lf[206],9,"\003syspair\077");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\026ill-formed syntax rule");
lf[208]=C_h_intern(&lf[208],11,"\004coresyntax");
lf[209]=C_h_intern(&lf[209],5,"quote");
lf[210]=C_h_intern(&lf[210],14,"\003sysdrop-right");
lf[211]=C_h_intern(&lf[211],14,"\003systake-right");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000,template dimension error (too few ellipses\077)");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\021too many ellipses");
lf[214]=C_h_intern(&lf[214],9,"\003sysapply");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000%Only one segment per level is allowed");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\047Cannot combine dotted tail and ellipsis");
lf[217]=C_h_intern(&lf[217],4,"temp");
lf[218]=C_h_intern(&lf[218],4,"tail");
lf[219]=C_h_intern(&lf[219],6,"rename");
lf[220]=C_h_intern(&lf[220],2,"or");
lf[221]=C_h_intern(&lf[221],4,"loop");
lf[222]=C_h_intern(&lf[222],6,"lambda");
lf[223]=C_h_intern(&lf[223],3,"len");
lf[224]=C_h_intern(&lf[224],1,"l");
lf[225]=C_h_intern(&lf[225],5,"input");
lf[226]=C_h_intern(&lf[226],4,"else");
lf[227]=C_h_intern(&lf[227],4,"cond");
lf[228]=C_h_intern(&lf[228],7,"compare");
lf[229]=C_h_intern(&lf[229],3,"and");
lf[230]=C_h_intern(&lf[230],16,"\003sysmacro-subset");
lf[231]=C_h_intern(&lf[231],27,"\003sysfixup-macro-environment");
lf[232]=C_h_intern(&lf[232],29,"\003sysdefault-macro-environment");
lf[233]=C_h_intern(&lf[233],26,"\003sysmeta-macro-environment");
lf[234]=C_h_intern(&lf[234],14,"make-parameter");
lf[235]=C_h_intern(&lf[235],12,"syntax-rules");
lf[236]=C_h_intern(&lf[236],3,"...");
lf[237]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[238]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[239]=C_h_intern(&lf[239],6,"export");
lf[240]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[241]=C_h_intern(&lf[241],22,"\003sysadd-to-export-list");
lf[242]=C_h_intern(&lf[242],18,"\003syscurrent-module");
lf[243]=C_h_intern(&lf[243],20,"\003sysvalidate-exports");
lf[244]=C_h_intern(&lf[244],16,"begin-for-syntax");
lf[245]=C_h_intern(&lf[245],24,"\004coreelaborationtimeonly");
lf[246]=C_h_intern(&lf[246],28,"\003sysregister-meta-expression");
lf[247]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[248]=C_h_intern(&lf[248],6,"module");
lf[249]=C_h_intern(&lf[249],1,"\052");
lf[250]=C_h_intern(&lf[250],1,"=");
lf[251]=C_h_intern(&lf[251],14,"string->symbol");
lf[252]=C_h_intern(&lf[252],17,"\003sysstring-append");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\001_");
lf[254]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[255]=C_h_intern(&lf[255],25,"\003sysregister-module-alias");
lf[256]=C_h_intern(&lf[256],23,"\003sysinstantiate-functor");
lf[257]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\016"
);
lf[258]=C_h_intern(&lf[258],12,"\004coreinclude");
lf[259]=C_h_intern(&lf[259],11,"\004coremodule");
lf[260]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[261]=C_h_intern(&lf[261],28,"require-extension-for-syntax");
lf[262]=C_h_intern(&lf[262],17,"require-extension");
lf[263]=C_h_intern(&lf[263],22,"\004corerequire-extension");
lf[264]=C_h_intern(&lf[264],15,"require-library");
lf[265]=C_h_intern(&lf[265],11,"cond-expand");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[267]=C_h_intern(&lf[267],12,"\003sysfeature\077");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[269]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[270]=C_h_intern(&lf[270],3,"not");
lf[271]=C_h_intern(&lf[271],11,"delay-force");
lf[272]=C_h_intern(&lf[272],16,"\003sysmake-promise");
lf[273]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[274]=C_h_intern(&lf[274],5,"delay");
lf[275]=C_h_intern(&lf[275],8,"\003syslist");
lf[276]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[277]=C_h_intern(&lf[277],10,"quasiquote");
lf[278]=C_h_intern(&lf[278],7,"unquote");
lf[279]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[280]=C_h_intern(&lf[280],16,"unquote-splicing");
lf[281]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[282]=C_h_intern(&lf[282],1,"a");
lf[283]=C_h_intern(&lf[283],1,"b");
lf[284]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\004corequote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[285]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[286]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[287]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[288]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012\004corequote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[289]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[290]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[291]=C_h_intern(&lf[291],2,"do");
lf[292]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[293]=C_h_intern(&lf[293],7,"\004coreif");
lf[294]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[295]=C_h_intern(&lf[295],6,"doloop");
lf[296]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001"
"\000\000\000\001");
lf[297]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[298]=C_h_intern(&lf[298],4,"case");
lf[299]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corebegin\376\377\016");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000(clause following `else\047 clause in `case\047");
lf[301]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[302]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[303]=C_h_intern(&lf[303],4,"eqv\077");
lf[304]=C_h_intern(&lf[304],2,"=>");
lf[305]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[306]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corebegin\376\377\016");
lf[307]=C_h_intern(&lf[307],7,"sprintf");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\022\047 clause in `cond\047");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\022clause following `");
lf[310]=C_h_intern(&lf[310],2,"if");
lf[311]=C_h_intern(&lf[311],18,"\003syssrfi-4-vector\077");
lf[312]=C_h_intern(&lf[312],5,"blob\077");
lf[313]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[314]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[315]=C_h_intern(&lf[315],4,"set!");
lf[316]=C_h_intern(&lf[316],10,"\003syssetter");
lf[317]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[318]=C_h_intern(&lf[318],13,"letrec-syntax");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\015letrec-syntax");
lf[320]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[321]=C_h_intern(&lf[321],10,"let-syntax");
lf[322]=C_h_intern(&lf[322],15,"\004corelet-syntax");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\012let-syntax");
lf[324]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[325]=C_h_intern(&lf[325],6,"letrec");
lf[326]=C_h_intern(&lf[326],11,"\004coreletrec");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\006letrec");
lf[328]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[329]=C_h_intern(&lf[329],7,"letrec\052");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\007letrec\052");
lf[331]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\003let");
lf[333]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376"
"\001\000\000\001_\376\377\001\000\000\000\001");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\003let");
lf[335]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[336]=C_h_intern(&lf[336],18,"\004coredefine-syntax");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000@redefinition of `define-syntax\047 not allowed in syntax-definition");
lf[338]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[339]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[340]=C_h_intern(&lf[340],19,"\003sysregister-export");
lf[341]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[342]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[343]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[344]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[345]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[346]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[347]=C_h_intern(&lf[347],5,"begin");
lf[348]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[349]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[350]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[351]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[352]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[353]=C_h_intern(&lf[353],8,"reexport");
lf[354]=C_h_intern(&lf[354],17,"\003sysexpand-import");
lf[355]=C_h_intern(&lf[355],17,"import-for-syntax");
lf[356]=C_h_intern(&lf[356],6,"import");
lf[357]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\020\000hygienic-macros\376\003\000\000\002\376\001\000\000\015\000syntax-rules\376\003\000\000\002\376\001\000\000\007\000srfi-0\376\003\000\000\002\376\001\000\000\007\000srf"
"i-2\376\003\000\000\002\376\001\000\000\007\000srfi-6\376\003\000\000\002\376\001\000\000\007\000srfi-9\376\003\000\000\002\376\001\000\000\010\000srfi-46\376\003\000\000\002\376\001\000\000\010\000srfi-55\376\003\000\000\002\376\001"
"\000\000\010\000srfi-61\376\377\016");
C_register_lf2(lf,358,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3664,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:55: append */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[357];
av2[3]=*((C_word*)lf[0]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a4512 in tmp13092 in a4462 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4513(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4513,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[45]+1));
t3=C_mutate2((C_word*)lf[45]+1 /* (set! ##sys#syntax-rules-mismatch ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k9571 in a9568 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in ... */
static void C_ccall f_9573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,6))){C_save_and_reclaim((void *)f_9573,2,av);}
a=C_alloc(14);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[236];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_symbolp(((C_word*)t4)[1]))){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9590,a[2]=t10,a[3]=t4,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* synrules.scm:54: ##sys#check-syntax */
t12=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t12;
av2[1]=t11;
av2[2]=lf[235];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[237];
((C_proc)(void*)(*((C_word*)t12+1)))(5,av2);}}
else{
/* synrules.scm:58: ##sys#process-syntax-rules */
t11=*((C_word*)lf[190]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t11;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t10)[1];
av2[3]=((C_word*)t8)[1];
av2[4]=((C_word*)t4)[1];
av2[5]=((C_word*)t0)[4];
av2[6]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t11+1)))(7,av2);}}}

/* k8442 */
static void C_fcall f_8444(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,4))){
C_save_and_reclaim_args((void *)trf_8444,2,t0,t1);}
a=C_alloc(11);
if(C_truep(t1)){
t2=C_i_cdar(((C_word*)t0)[2]);
t3=t2;
t4=C_i_cadr(((C_word*)t0)[2]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8480,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* synrules.scm:120: process-match */
t7=((C_word*)((C_word*)t0)[10])[1];{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)((C_word*)t0)[9])[1];
av2[3]=t3;
av2[4]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t7))(5,av2);}}
else{
/* synrules.scm:127: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=((C_word*)t0)[5];
av2[2]=lf[207];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* a4525 in tmp23093 in a4462 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4526,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* g1235 in mwalk in match-expression in k4152 in k3674 in k3670 in k3666 in k3662 */
static C_word C_fcall f_6631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_i_cdr(t1);
return(C_i_equalp(((C_word*)t0)[2],t2));}

/* f_8437 in k8333 in k8328 in k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in ... */
static void C_ccall f_8437(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_8437,3,av);}
a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8444,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=C_u_i_cdr(t4);
if(C_truep(C_i_pairp(t5))){
t6=C_i_cddr(t2);
t7=t3;
f_8444(t7,C_i_nullp(t6));}
else{
t6=t3;
f_8444(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_8444(t4,C_SCHEME_FALSE);}}

/* comp in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static C_word C_fcall f_5755(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_overflow_check;{}
t3=f_3678(t2,((C_word*)t0)[2]);
t4=C_eqp(t1,t3);
if(C_truep(t4)){
return(t4);}
else{
t5=t1;
t6=C_eqp(t5,lf[100]);
if(C_truep(t6)){
return((C_truep(t3)?C_eqp(t3,*((C_word*)lf[96]+1)):C_eqp(t1,t2)));}
else{
t7=C_eqp(t5,lf[101]);
if(C_truep(t7)){
return((C_truep(t3)?C_eqp(t3,*((C_word*)lf[97]+1)):C_eqp(t1,t2)));}
else{
t8=C_eqp(t5,lf[102]);
return((C_truep(t8)?(C_truep(t3)?C_eqp(t3,*((C_word*)lf[98]+1)):C_eqp(t1,t2)):C_eqp(t1,t2)));}}}}

/* expand in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4539(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,6))){
C_save_and_reclaim_args((void *)trf_4539,5,t0,t1,t2,t3,t4);}
a=C_alloc(3);
if(C_truep(C_i_listp(t3))){
if(C_truep(C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4565,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_i_cadr(t4);
t7=t4;
t8=C_u_i_car(t7);
/* expand.scm:263: call-handler */
t9=((C_word*)((C_word*)t0)[2])[1];
f_4341(t9,t5,t2,t6,t3,t8,C_SCHEME_FALSE);}
else{
/* expand.scm:265: values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}}
else{
/* expand.scm:259: ##sys#syntax-error-hook */
t5=*((C_word*)lf[41]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t1;
av2[2]=lf[49];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k4535 in a4462 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4537(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4537,2,av);}
a=C_alloc(3);
/* tmp23093 */
t2=((C_word*)t0)[2];
f_4520(t2,((C_word*)t0)[3],C_a_i_list(&a,1,t1));}

/* k11083 in k11077 in k11074 in k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_ccall f_11085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_11085,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[2]);
t3=C_u_i_car(((C_word*)t0)[2]);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=C_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t2))){
t3=C_u_i_car(((C_word*)t0)[2]);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[103],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* k9553 in k9549 in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in ... */
static void C_ccall f_9555(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_9555,2,av);}
t2=C_mutate2((C_word*)lf[233]+1 /* (set! ##sys#meta-macro-environment ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k9549 in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in ... */
static void C_ccall f_9551(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_9551,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[232]+1 /* (set! ##sys#default-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9555,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9559,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1560: ##sys#macro-environment */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k8463 in k8478 in k8442 */
static void C_ccall f_8465(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,5))){C_save_and_reclaim((void *)f_8465,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8469,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8473,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* synrules.scm:126: meta-variables */
t5=((C_word*)((C_word*)t0)[7])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[8];
av2[3]=C_fix(0);
av2[4]=C_SCHEME_END_OF_LIST;
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t5))(6,av2);}}

/* k9557 in k9549 in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in ... */
static void C_ccall f_9559(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9559,2,av);}
/* expand.scm:1560: make-parameter */
t2=*((C_word*)lf[234]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8467 in k8463 in k8478 in k8442 */
static void C_ccall f_8469(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,1))){C_save_and_reclaim((void *)f_8469,2,av);}
a=C_alloc(15);
t2=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,((C_word*)t0)[5],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5744(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(!C_demand(C_calculate_demand(30,c,6))){C_save_and_reclaim((void *)f_5744,2,av);}
a=C_alloc(30);
t2=t1;
t3=C_i_nullp(((C_word*)t0)[2]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_i_cdr(((C_word*)t0)[2]));
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5755,a[2]=t2,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
t19=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5821,a[2]=t17,a[3]=t11,a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp));
t20=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6109,a[2]=t13,a[3]=t11,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp));
t21=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6299,a[2]=t11,a[3]=t2,a[4]=t15,a[5]=t13,a[6]=t7,a[7]=((C_word)li68),tmp=(C_word)a,a+=8,tmp));
/* expand.scm:604: expand */
t22=((C_word*)t17)[1];
f_6299(t22,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* ##sys#canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5740(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +5,c,2))){
C_save_and_reclaim((void*)f_5740,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+5);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5744,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
/* expand.scm:471: ##sys#current-environment */
t6=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_i_car(t4);
f_5744(2,av2);}}}

/* k9525 in for-each-loop2748 in k9473 in fixup-macro-environment in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in ... */
static void C_ccall f_9527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9527,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9517(t3,((C_word*)t0)[4],t2);}

/* k10662 in map-loop2109 in k10594 in k10573 in k10545 in k10533 in a10530 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_fcall f_10664(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_10664,2,t0,t1);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10639(t6,((C_word*)t0)[5],t5);}

/* k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in ... */
static void C_ccall f_11073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_11073,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t1;
f_11076(2,av2);}}
else{
t3=C_u_i_car(((C_word*)t0)[2]);
t4=C_eqp(C_SCHEME_TRUE,t3);
if(C_truep(t4)){
t5=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
f_11076(2,av2);}}
else{
t5=C_u_i_car(((C_word*)t0)[2]);
t6=C_i_numberp(t5);
if(C_truep(t6)){
t7=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
f_11076(2,av2);}}
else{
t7=C_u_i_car(((C_word*)t0)[2]);
t8=C_charp(t7);
if(C_truep(t8)){
t9=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t8;
f_11076(2,av2);}}
else{
t9=C_u_i_car(((C_word*)t0)[2]);
t10=C_i_stringp(t9);
if(C_truep(t10)){
t11=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=t10;
f_11076(2,av2);}}
else{
t11=C_u_i_car(((C_word*)t0)[2]);
t12=C_eofp(t11);
if(C_truep(t12)){
t13=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=t12;
f_11076(2,av2);}}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11311,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t14=C_u_i_car(((C_word*)t0)[2]);
/* expand.scm:1179: blob? */
t15=*((C_word*)lf[312]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t15;
av2[1]=t13;
av2[2]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(3,av2);}}}}}}}}

/* k11074 in k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_11076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_11076,2,av);}
a=C_alloc(11);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11128,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=C_u_i_car(((C_word*)t0)[2]);
/* expand.scm:1184: strip-syntax */
t5=*((C_word*)lf[10]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=C_u_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t2))){
t3=C_u_i_car(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11145,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1192: expand */
t5=((C_word*)((C_word*)t0)[6])[1];
f_11021(t5,t4,((C_word*)t0)[7],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=C_i_length(((C_word*)t0)[2]);
t5=C_eqp(t4,C_fix(3));
if(C_truep(t5)){
t6=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1194: c */
t7=((C_word*)t0)[4];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=t6;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}
else{
t6=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
f_11151(2,av2);}}}}}

/* k11077 in k11074 in k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_11079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_11079,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_length(((C_word*)t0)[2]);
t4=C_eqp(t3,C_fix(3));
if(C_truep(t4)){
t5=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1186: c */
t6=((C_word*)t0)[4];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t6))(4,av2);}}
else{
t5=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_11085(2,av2);}}}

/* k11592 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11594(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11594,2,av);}
/* expand.scm:1060: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[55];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a11595 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11596(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_11596,5,av);}
a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11600,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11608,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cdr(t2);
if(C_truep(C_i_pairp(t7))){
t8=C_i_cadr(t2);
t9=t6;
f_11608(t9,C_i_symbolp(t8));}
else{
t8=t6;
f_11608(t8,C_SCHEME_FALSE);}}

/* k11039 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in ... */
static void C_ccall f_11041(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_11041,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11044,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1170: expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11021(t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k11828 in k11821 in loop in k11753 in a11750 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11830(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11830,2,av);}
/* expand.scm:1015: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_11760(t2,((C_word*)t0)[3],t1);}

/* k11042 in k11039 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_11044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_11044,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[306];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k11831 in loop in k11753 in a11750 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11833(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_11833,2,av);}
a=C_alloc(15);
t2=C_i_car(((C_word*)t0)[2]);
t3=C_u_i_car(((C_word*)t0)[3]);
t4=C_u_i_cdr(((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[4]);
t6=C_a_i_cons(&a,2,lf[72],t5);
t7=C_a_i_list3(&a,3,t2,t3,t6);
/* expand.scm:1018: loop */
t8=((C_word*)((C_word*)t0)[5])[1];
f_11760(t8,((C_word*)t0)[6],t7);}

/* k11046 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in ... */
static void C_ccall f_11048(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_11048,2,av);}
a=C_alloc(7);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[307]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1168: ##sys#print */
t6=*((C_word*)lf[123]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[309];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* map-loop902 in a5566 in expand-multiple-values-assignment in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5703(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_5703,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5728,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* expand.scm:450: g908 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8418 in map-loop2470 */
static void C_ccall f_8420(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8420,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8395(t6,((C_word*)t0)[5],t5);}

/* expand in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6299(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,6))){
C_save_and_reclaim_args((void *)trf_6299,3,t0,t1,t2);}
a=C_alloc(11);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li67),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_6305(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k11883 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11885(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11885,2,av);}
/* expand.scm:978: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[310];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a11886 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11887(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11887,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11891,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:983: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[310];
av2[3]=t2;
av2[4]=lf[349];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k11055 in k11052 in k11046 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_11057(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_11057,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1168: ##sys#print */
t3=*((C_word*)lf[123]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[308];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11052 in k11046 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_11054(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_11054,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1168: ##sys#print */
t3=*((C_word*)lf[123]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11889 in a11886 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11891(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_11891,2,av);}
a=C_alloc(3);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[293],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k9731 in k9676 in k9673 in k9667 in a9661 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in ... */
static void C_ccall f_9733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9733,2,av);}
/* expand.scm:1471: string->symbol */
t2=*((C_word*)lf[251]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k9735 in k9676 in k9673 in k9667 in a9661 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in ... */
static void C_ccall f_9737(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_9737,2,av);}
/* expand.scm:1472: ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[252]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[252]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=lf[253];
av2[3]=t1;
tp(4,av2);}}

/* k5726 in map-loop902 in a5566 in expand-multiple-values-assignment in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5728(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5728,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5703(t6,((C_word*)t0)[5],t5);}

/* k5284 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5286(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(13,0,6))){
C_save_and_reclaim_args((void *)trf_5286,2,t0,t1);}
a=C_alloc(13);
t2=(C_truep(t1)?t1:((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=C_eqp(t2,lf[65]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5299,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t4,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t7=t6;
f_5299(t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5315,a[2]=((C_word*)t0)[9],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:398: macro-alias */
f_3695(t7,lf[77],((C_word*)t0)[10]);}}
else{
t6=C_eqp(t2,lf[64]);
if(C_truep(t6)){
if(C_truep(C_fixnum_less_or_equal_p(((C_word*)t0)[4],C_fix(1)))){
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5333,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_pairp(t4))){
t8=C_u_i_car(t4);
t9=t7;
f_5333(t9,C_i_symbolp(t8));}
else{
t8=t7;
f_5333(t8,C_SCHEME_FALSE);}}
else{
/* expand.scm:410: err */
t7=((C_word*)t0)[8];
f_4952(t7,((C_word*)t0)[6],lf[79]);}}
else{
t7=C_eqp(t2,lf[66]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5375,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[12],a[7]=t4,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t9=((C_word*)((C_word*)t0)[9])[1];
if(C_truep(t9)){
t10=t8;
f_5375(t10,C_SCHEME_UNDEFINED);}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5394,a[2]=((C_word*)t0)[9],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:412: macro-alias */
f_3695(t10,lf[77],((C_word*)t0)[10]);}}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[2]))){
t8=((C_word*)t0)[4];
switch(t8){
case C_fix(0):
t9=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[7]);
/* expand.scm:419: loop */
t10=((C_word*)((C_word*)t0)[5])[1];
f_4983(t10,((C_word*)t0)[6],C_fix(0),t9,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t4);
case C_fix(1):
t9=C_a_i_list2(&a,2,((C_word*)t0)[2],C_SCHEME_FALSE);
t10=C_a_i_cons(&a,2,t9,((C_word*)t0)[12]);
/* expand.scm:420: loop */
t11=((C_word*)((C_word*)t0)[5])[1];
f_4983(t11,((C_word*)t0)[6],C_fix(1),((C_word*)t0)[7],t10,C_SCHEME_END_OF_LIST,t4);
case C_fix(2):
/* expand.scm:421: err */
t9=((C_word*)t0)[8];
f_4952(t9,((C_word*)t0)[6],lf[81]);
default:
t9=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t10=C_a_i_cons(&a,2,t9,((C_word*)t0)[13]);
/* expand.scm:422: loop */
t11=((C_word*)((C_word*)t0)[5])[1];
f_4983(t11,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[7],((C_word*)t0)[12],t10,t4);}}
else{
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5462,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
t9=C_u_i_length(((C_word*)t0)[2]);
t10=C_eqp(C_fix(2),t9);
if(C_truep(t10)){
t11=C_i_car(((C_word*)t0)[2]);
t12=t8;
f_5462(t12,C_i_symbolp(t11));}
else{
t11=t8;
f_5462(t11,C_SCHEME_FALSE);}}
else{
t9=t8;
f_5462(t9,C_SCHEME_FALSE);}}}}}}

/* k6341 in k6323 in loop in expand in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_6343,2,av);}
a=C_alloc(12);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6348,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word)li66),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_6348(t5,((C_word*)t0)[8],((C_word*)t0)[9]);}

/* k10146 in expand in k9908 in k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in ... */
static void C_ccall f_10148(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_10148,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_eqp(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=(C_truep(t3)?lf[269]:C_a_i_cons(&a,2,lf[103],t2));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1419: test */
t3=((C_word*)((C_word*)t0)[6])[1];
f_9922(t3,t2,((C_word*)t0)[7]);}}

/* loop2 in k6341 in k6323 in loop in expand in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6348(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,6))){
C_save_and_reclaim_args((void *)trf_6348,3,t0,t1,t2);}
a=C_alloc(10);
t3=C_i_cadr(t2);
t4=t3;
if(C_truep(C_i_pairp(t4))){
t5=C_i_car(t4);
if(C_truep(C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6414,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:575: ##sys#check-syntax */
t7=*((C_word*)lf[54]+1);{
C_word av2[7];
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[100];
av2[3]=t2;
av2[4]=lf[108];
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t7+1)))(7,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6428,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:580: ##sys#check-syntax */
t7=*((C_word*)lf[54]+1);{
C_word av2[7];
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[100];
av2[3]=t2;
av2[4]=lf[109];
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t7+1)))(7,av2);}}}
else{
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6361,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:565: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word av2[7];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[100];
av2[3]=t2;
av2[4]=lf[111];
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(7,av2);}}}

/* k11866 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11868,2,av);}
/* expand.scm:986: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[347];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k11579 in k11576 in a11573 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11581(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_11581,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[52],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* doloop331 in k3847 in walk in strip-syntax in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_3858(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3858,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[5],t2);
/* expand.scm:125: walk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3759(t5,t3,t4);}}

/* k11554 in a11551 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11556(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11556,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1088: check-for-multiple-bindings */
f_8101(t2,t3,((C_word*)t0)[2],lf[327]);}

/* k11557 in k11554 in a11551 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11559(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_11559,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[326],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k11548 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11550(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11550,2,av);}
/* expand.scm:1082: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[325];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a11551 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11552(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11552,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11556,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1087: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[325];
av2[3]=t2;
av2[4]=lf[328];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10162 in k10146 in expand in k9908 in k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in ... */
static void C_ccall f_10164(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_10164,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[103],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* expand.scm:1420: expand */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10058(t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k10811 in k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_10813(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_10813,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[55],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* expand in k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_fcall f_10815(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(13,0,4))){
C_save_and_reclaim_args((void *)trf_10815,4,t0,t1,t2,t3);}
a=C_alloc(13);
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=t2;
t7=C_u_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10829,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t5,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* expand.scm:1233: ##sys#check-syntax */
t9=*((C_word*)lf[54]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[298];
av2[3]=t5;
av2[4]=lf[301];
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[302];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k11526 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11528(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11528,2,av);}
/* expand.scm:1091: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[321];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3877 in doloop331 in k3847 in walk in strip-syntax in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_3879(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3879,2,av);}
t2=C_i_setslot(((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_3858(t4,((C_word*)t0)[5],t3);}

/* k5297 in k5284 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5299(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,6))){
C_save_and_reclaim_args((void *)trf_5299,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t2)){
/* expand.scm:400: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4983(t3,((C_word*)t0)[4],C_fix(1),((C_word*)t0)[5],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[6]);}
else{
/* expand.scm:401: err */
t3=((C_word*)t0)[7];
f_4952(t3,((C_word*)t0)[4],lf[76]);}}

/* k11576 in a11573 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11578(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11578,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1079: check-for-multiple-bindings */
f_8101(t2,t3,((C_word*)t0)[2],lf[330]);}

/* k11058 in k11055 in k11052 in k11046 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_ccall f_11060(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_11060,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1168: get-output-string */
t3=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k11061 in k11058 in k11055 in k11052 in k11046 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_ccall f_11063(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_11063,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11067,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1169: ##sys#strip-syntax */
t4=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k11065 in k11061 in k11058 in k11055 in k11052 in k11046 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static void C_ccall f_11067(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_11067,2,av);}
/* expand.scm:1167: ##sys#warn */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[187]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[187]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
tp(4,av2);}}

/* a11573 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11574(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11574,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11578,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1078: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[329];
av2[3]=t2;
av2[4]=lf[331];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k11570 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11572(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11572,2,av);}
/* expand.scm:1073: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[329];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k10188 in a10185 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_10190(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,1))){C_save_and_reclaim((void *)f_10190,2,av);}
a=C_alloc(15);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,lf[72],C_SCHEME_END_OF_LIST,t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,lf[272],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k10182 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in ... */
static void C_ccall f_10184(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10184,2,av);}
/* expand.scm:1360: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[271];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a10185 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in ... */
static void C_ccall f_10186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_10186,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10190,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1365: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[271];
av2[3]=t2;
av2[4]=lf[273];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k9741 in k9676 in k9673 in k9667 in a9661 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in ... */
static void C_ccall f_9743(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9743,2,av);}
t2=C_i_car(((C_word*)t0)[2]);
t3=C_u_i_cdr(((C_word*)t0)[2]);
/* expand.scm:1485: ##sys#instantiate-functor */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[256]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[256]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
av2[4]=t3;
tp(5,av2);}}

/* k9738 in k9676 in k9673 in k9667 in a9661 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in ... */
static void C_ccall f_9740(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_9740,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[254];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k11821 in loop in k11753 in a11750 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11823(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11823,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1015: ##sys#expand-curried-define */
t3=*((C_word*)lf[107]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* ##sys#extend-se in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_3890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +19,c,3))){
C_save_and_reclaim((void*)f_3890,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+19);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3894,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=*((C_word*)lf[8]+1);
t11=t3;
t12=C_i_check_list_2(t11,lf[16]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4033,a[2]=t8,a[3]=t14,a[4]=t10,a[5]=t9,a[6]=((C_word)li7),tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_4033(t16,t5,t11);}
else{
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_i_car(t4);
f_3894(2,av2);}}}

/* k3892 in extend-se in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_3894(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_3894,2,av);}
a=C_alloc(12);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_i_check_list_2(t2,lf[14]);
t5=C_i_check_list_2(t3,lf[14]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3984,a[2]=t8,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_3984(t10,t6,t2,t3);}

/* k9753 in k9673 in k9667 in a9661 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in ... */
static void C_ccall f_9755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_9755,2,av);}
a=C_alloc(6);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_eqp(lf[249],t1);
t5=(C_truep(t4)?C_SCHEME_TRUE:t1);
t6=t5;
t7=C_i_cdddr(((C_word*)t0)[2]);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9784,a[2]=t8,a[3]=t6,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t8))){
t10=C_u_i_cdr(t8);
if(C_truep(C_i_nullp(t10))){
t11=C_u_i_car(t8);
t12=t9;
f_9784(t12,C_i_stringp(t11));}
else{
t11=t9;
f_9784(t11,C_SCHEME_FALSE);}}
else{
t10=t9;
f_9784(t10,C_SCHEME_FALSE);}}

/* k6215 in k6191 in loop in fini/syntax in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6217(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,4))){C_save_and_reclaim((void *)f_6217,2,av);}
a=C_alloc(24);
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_u_i_car(t2);
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(((C_word*)t0)[2]);
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,t4,t6);
t8=C_a_i_cons(&a,2,lf[72],t7);
t9=C_a_i_list(&a,2,lf[23],t8);
t10=C_a_i_list(&a,3,lf[101],t1,t9);
t11=C_a_i_cons(&a,2,t10,((C_word*)t0)[3]);
/* expand.scm:532: loop */
t12=((C_word*)((C_word*)t0)[4])[1];
f_6119(t12,((C_word*)t0)[5],((C_word*)t0)[6],t11,C_SCHEME_FALSE);}

/* k7583 in g1458 in rename in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_7585(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_7585,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:823: macro-alias */
f_3695(t2,((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[6]);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t5;
av2[1]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k7586 in k7583 in g1458 in rename in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7588(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_7588,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_10802(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,4))){C_save_and_reclaim((void *)f_10802,2,av);}
a=C_alloc(25);
t2=t1;
t3=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10813,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10815,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word)li159),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_10815(t10,t6,((C_word*)t0)[9],C_SCHEME_FALSE);}

/* map-loop794 in k5199 in k4995 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5206(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_5206,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5231,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* expand.scm:362: g800 */
t5=((C_word*)t0)[4];
f_5141(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5199 in k4995 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5201(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_5201,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5206,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5206(t6,t2,t1);}

/* k5202 in k5199 in k4995 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5204(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_5204,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
f_5001(t4,C_a_i_list(&a,1,t3));}

/* g1458 in rename in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_7567(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_7567,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_i_symbolp(t2))){
t3=t2;
t4=C_i_getprop(t3,lf[179],C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=t5;
f_7585(t6,t4);}
else{
t6=t2;
t7=t5;
f_7585(t7,C_i_getprop(t6,lf[180],C_SCHEME_FALSE));}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:831: macro-alias */
f_3695(t3,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k9700 in k9697 in k9676 in k9673 in k9667 in a9661 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in ... */
static void C_ccall f_9702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(36,c,1))){C_save_and_reclaim((void *)f_9702,2,av);}
a=C_alloc(36);
t2=C_i_cddddr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,lf[249],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=C_a_i_cons(&a,2,t1,t4);
t6=C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t7=C_a_i_list(&a,4,t1,((C_word*)t0)[5],lf[250],t6);
t8=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_a_i_list(&a,3,lf[103],t5,t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* k6205 in k6191 in loop in fini/syntax in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6207(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_6207,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* expand.scm:532: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6119(t3,((C_word*)t0)[4],((C_word*)t0)[5],t2,C_SCHEME_FALSE);}

/* k11900 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11902(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11902,2,av);}
/* expand.scm:970: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[137];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k11906 in a11903 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_11908,2,av);}
a=C_alloc(6);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[208],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a11903 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11904(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11904,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11908,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:975: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[137];
av2[3]=t2;
av2[4]=lf[350];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* loop in loop1 in globalize in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4110(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_4110,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
/* expand.scm:149: ##sys#alias-global-hook */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[18]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[18]+1);
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=C_SCHEME_TRUE;
av2[4]=C_SCHEME_FALSE;
tp(5,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4126,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_i_caar(t2);
t5=C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=t2;
t7=C_u_i_car(t6);
t8=C_u_i_cdr(t7);
t9=t3;
f_4126(t9,C_i_symbolp(t8));}
else{
t6=t3;
f_4126(t6,C_SCHEME_FALSE);}}}

/* k11917 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11919(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11919,2,av);}
/* expand.scm:962: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[209];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4124 in loop in loop1 in globalize in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4126(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_4126,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_u_i_cdr(t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* expand.scm:151: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4110(t4,((C_word*)t0)[3],t3);}}

/* a11647 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11648(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_11648,5,av);}
a=C_alloc(8);
t5=C_i_cadr(t2);
t6=t5;
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
if(C_truep(C_i_pairp(t6))){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11704,a[2]=t6,a[3]=t9,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1037: ##sys#check-syntax */
t11=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[101];
av2[3]=t6;
av2[4]=lf[339];
((C_proc)(void*)(*((C_word*)t11+1)))(5,av2);}}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11663,a[2]=t6,a[3]=t9,a[4]=t1,a[5]=t2,a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1029: ##sys#check-syntax */
t11=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[101];
av2[3]=t6;
av2[4]=lf[161];
((C_proc)(void*)(*((C_word*)t11+1)))(5,av2);}}}

/* k11644 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11646(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11646,2,av);}
/* expand.scm:1021: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[101];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7514 in k7510 in rename in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7516(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_7516,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7510 in rename in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7512(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_7512,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7516,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:807: rename */
t6=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
f_7498(3,av2);}}

/* k10855 in k10849 in k10846 in k10827 in expand in k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in ... */
static void C_ccall f_10857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_10857,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,t2,((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[103],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10849 in k10846 in k10827 in expand in k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static void C_ccall f_10851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_10851,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_length(((C_word*)t0)[2]);
t4=C_eqp(t3,C_fix(3));
if(C_truep(t4)){
t5=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1243: c */
t6=((C_word*)t0)[5];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t6))(4,av2);}}
else{
t5=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_10857(2,av2);}}}

/* k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7496(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(40,c,4))){C_save_and_reclaim((void *)f_7496,2,av);}
a=C_alloc(40);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7498,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li95),tmp=(C_word)a,a+=6,tmp));
t11=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7652,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word)li99),tmp=(C_word)a,a+=5,tmp));
t12=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7889,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7914,a[2]=t9,a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=((C_word)li101),tmp=(C_word)a,a+=8,tmp));
if(C_truep(((C_word*)t0)[5])){
/* expand.scm:915: handler */
t14=((C_word*)t0)[6];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t14;
av2[1]=((C_word*)t0)[7];
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)t3)[1];
av2[4]=((C_word*)t5)[1];
((C_proc)C_fast_retrieve_proc(t14))(5,av2);}}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8042,a[2]=t9,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8046,a[2]=((C_word*)t0)[6],a[3]=t14,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:921: rename */
t16=((C_word*)t3)[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t16;
av2[1]=t15;
av2[2]=((C_word*)t0)[8];
f_7498(3,av2);}}}

/* rename in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7498(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_7498,3,av);}
a=C_alloc(7);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7512,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* expand.scm:807: rename */
t7=t3;
t8=t5;
t1=t7;
t2=t8;
c=3;
goto loop;}
else{
if(C_truep(C_i_vectorp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7533,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7537,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:809: vector->list */
t5=*((C_word*)lf[178]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
t3=C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t3)){
t4=t1;
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_i_cdr(t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=f_3678(t2,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7567,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li94),tmp=(C_word)a,a+=6,tmp);
/* expand.scm:802: g1458 */
t6=t5;
f_7567(t6,t1,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7635,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:836: macro-alias */
f_3695(t5,t2,((C_word*)t0)[4]);}}}
else{
t3=t2;
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}}

/* k11619 in k11606 in a11595 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11621(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11621,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1070: check-for-multiple-bindings */
f_8101(((C_word*)t0)[3],t2,((C_word*)t0)[2],lf[334]);}

/* a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7489(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_7489,5,av);}
a=C_alloc(11);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_listp(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7496,a[2]=t6,a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t7)){
t9=t8;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t7;
f_7496(2,av2);}}
else{
/* expand.scm:802: ##sys#error */
t9=*((C_word*)lf[25]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[181];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}}

/* make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7483(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(8,c,5))){C_save_and_reclaim((void *)f_7483,4,av);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7489,a[2]=t3,a[3]=t2,a[4]=((C_word)li102),tmp=(C_word)a,a+=5,tmp);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_record2(&a,2,lf[24],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k11598 in a11595 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11600(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_11600,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[50],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k11606 in a11595 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_11608(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,4))){
C_save_and_reclaim_args((void *)trf_11608,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11611,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1066: ##sys#check-syntax */
t3=*((C_word*)lf[54]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[55];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[333];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1069: ##sys#check-syntax */
t3=*((C_word*)lf[54]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[55];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[335];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k7531 in rename in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7533,2,av);}
/* expand.scm:809: list->vector */
t2=*((C_word*)lf[177]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7535 in rename in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7537(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7537,2,av);}
/* expand.scm:809: rename */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
f_7498(3,av2);}}

/* k9216 in k9167 */
static void C_ccall f_9218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_9218,2,av);}
/* synrules.scm:258: meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t2))(6,av2);}}

/* k9260 */
static void C_ccall f_9262(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,5))){C_save_and_reclaim((void *)f_9262,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9273,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=C_i_cddr(((C_word*)t0)[2]);
/* synrules.scm:273: free-meta-variables */
t6=((C_word*)((C_word*)t0)[3])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[6];
av2[5]=((C_word*)t0)[7];
((C_proc)C_fast_retrieve_proc(t6))(6,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9292,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* synrules.scm:278: free-meta-variables */
t7=((C_word*)((C_word*)t0)[3])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t7;
av2[1]=t4;
av2[2]=t6;
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[6];
av2[5]=((C_word*)t0)[7];
((C_proc)C_fast_retrieve_proc(t7))(6,av2);}}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9307,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* synrules.scm:281: vector->list */
t3=*((C_word*)lf[178]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}}

/* expand in k10729 in a10726 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in ... */
static void C_fcall f_10741(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_10741,3,t0,t1,t2);}
a=C_alloc(7);
t3=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_a_i_cons(&a,2,lf[50],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_i_car(t2);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10766,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=t2;
t9=C_u_i_cdr(t8);
/* expand.scm:1267: expand */
t11=t7;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* k9201 in k9167 */
static void C_ccall f_9203(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_9203,2,av);}
/* synrules.scm:255: meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
av2[4]=t1;
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t2))(6,av2);}}

/* f_9220 in k8333 in k8328 in k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in ... */
static void C_ccall f_9220(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_9220,6,av);}
a=C_alloc(8);
if(C_truep(C_i_symbolp(t2))){
if(C_truep(C_i_memq(t2,t5))){
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_i_assq(t2,t4);
if(C_truep(t6)){
t7=C_i_cdr(t6);
t8=t3;
t9=C_fixnum_greater_or_equal_p(t7,t8);
t10=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=(C_truep(t9)?C_a_i_cons(&a,2,t2,t5):t5);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9262,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=t4,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* synrules.scm:270: segment-template? */
t7=((C_word*)((C_word*)t0)[3])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
((C_proc)C_fast_retrieve_proc(t7))(3,av2);}}}

/* k11126 in k11074 in k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_11128(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_11128,2,av);}
/* expand.scm:1184: expand */
t2=((C_word*)((C_word*)t0)[2])[1];
f_11021(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* ##sys#expand-multiple-values-assignment in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5561(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(5,c,5))){C_save_and_reclaim((void *)f_5561,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5567,a[2]=t3,a[3]=t2,a[4]=((C_word)li54),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:447: ##sys#decompose-lambda-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[95]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[95]+1);
av2[1]=t1;
av2[2]=t2;
av2[3]=t4;
tp(4,av2);}}

/* a5566 in expand-multiple-values-assignment in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5567(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(21,c,3))){C_save_and_reclaim((void *)f_5567,5,av);}
a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5571,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_END_OF_LIST;
f_5571(2,av2);}}
else{
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=*((C_word*)lf[8]+1);
t11=((C_word*)t0)[3];
t12=C_i_check_list_2(t11,lf[16]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5703,a[2]=t8,a[3]=t14,a[4]=t10,a[5]=t9,a[6]=((C_word)li53),tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_5703(t16,t5,t11);}}

/* k4768 in g698 in k4760 in k4605 in loop in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4770(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4770,2,av);}
a=C_alloc(5);
t2=t1;
t3=C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
/* expand.scm:293: expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4539(t4,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4782,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[58]+1))){
/* expand.scm:296: ##sys#compiler-syntax-hook */
t5=*((C_word*)lf[58]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
/* expand.scm:297: loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_4583(t5,((C_word*)t0)[4],t2);}}}

/* k5243 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5245(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5245,2,av);}
/* expand.scm:357: ##sys#append */
t2=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##sys#defjam-error in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5555(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5555,3,av);}
/* expand.scm:437: ##sys#syntax-error-hook */
t3=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[90];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4780 in k4768 in g698 in k4760 in k4605 in loop in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4782(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4782,2,av);}
/* expand.scm:297: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4583(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k5229 in map-loop794 in k5199 in k4995 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5231(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5231,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5206(t6,((C_word*)t0)[5],t5);}

/* k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in ... */
static void C_ccall f_8293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,2))){C_save_and_reclaim((void *)f_8293,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[2],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:87: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[55];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word *a;
if(!C_demand(C_calculate_demand(78,c,6))){C_save_and_reclaim((void *)f_4154,2,av);}
a=C_alloc(78);
t2=C_mutate2((C_word*)lf[19]+1 /* (set! ##sys#macro-environment ...) */,t1);
t3=C_set_block_item(lf[20] /* ##sys#chicken-macro-environment */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[21] /* ##sys#chicken-ffi-macro-environment */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate2((C_word*)lf[22]+1 /* (set! ##sys#ensure-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4158,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[27]+1 /* (set! ##sys#extend-macro-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4195,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2((C_word*)lf[28]+1 /* (set! ##sys#copy-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4237,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[29]+1 /* (set! ##sys#macro? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4250,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2((C_word*)lf[30]+1 /* (set! ##sys#unregister-macro ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4287,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[31]+1 /* (set! ##sys#undefine-macro! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4332,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[32]+1 /* (set! ##sys#expand-0 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4338,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t12=C_set_block_item(lf[58] /* ##sys#compiler-syntax-hook */,0,C_SCHEME_FALSE);
t13=C_set_block_item(lf[60] /* ##sys#enable-runtime-macros */,0,C_SCHEME_FALSE);
t14=C_mutate2((C_word*)lf[61]+1 /* (set! expand ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4835,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate2((C_word*)lf[62]+1 /* (set! ##sys#expand ...) */,*((C_word*)lf[61]+1));
t16=C_mutate2((C_word*)lf[63]+1 /* (set! ##sys#extended-lambda-list? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4902,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate2((C_word*)lf[67]+1 /* (set! ##sys#expand-extended-lambda-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4949,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate2((C_word*)lf[89]+1 /* (set! ##sys#defjam-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5555,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate2((C_word*)lf[91]+1 /* (set! ##sys#expand-multiple-values-assignment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5561,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t20=C_set_block_item(lf[96] /* ##sys#define-definition */,0,C_SCHEME_UNDEFINED);
t21=C_set_block_item(lf[97] /* ##sys#define-syntax-definition */,0,C_SCHEME_UNDEFINED);
t22=C_set_block_item(lf[98] /* ##sys#define-values-definition */,0,C_SCHEME_UNDEFINED);
t23=C_mutate2((C_word*)lf[99]+1 /* (set! ##sys#canonicalize-body ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5740,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate2(&lf[115] /* (set! match-expression ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6614,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate2((C_word*)lf[107]+1 /* (set! ##sys#expand-curried-define ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6696,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t26=C_set_block_item(lf[116] /* ##sys#line-number-database */,0,C_SCHEME_FALSE);
t27=C_set_block_item(lf[117] /* ##sys#syntax-error-culprit */,0,C_SCHEME_FALSE);
t28=C_set_block_item(lf[118] /* ##sys#syntax-context */,0,C_SCHEME_END_OF_LIST);
t29=C_mutate2((C_word*)lf[119]+1 /* (set! syntax-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6751,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate2((C_word*)lf[41]+1 /* (set! ##sys#syntax-error-hook ...) */,*((C_word*)lf[119]+1));
t31=C_mutate2((C_word*)lf[122]+1 /* (set! ##sys#syntax-error/context ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6762,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate2((C_word*)lf[45]+1 /* (set! ##sys#syntax-rules-mismatch ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6983,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate2((C_word*)lf[142]+1 /* (set! get-line-number ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6989,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate2((C_word*)lf[54]+1 /* (set! ##sys#check-syntax ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7028,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate2((C_word*)lf[176]+1 /* (set! make-er/ir-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7483,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate2((C_word*)lf[182]+1 /* (set! er-macro-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8051,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate2((C_word*)lf[183]+1 /* (set! ir-macro-transformer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8057,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate2((C_word*)lf[23]+1 /* (set! ##sys#er-transformer ...) */,*((C_word*)lf[182]+1));
t39=C_mutate2((C_word*)lf[184]+1 /* (set! ##sys#ir-transformer ...) */,*((C_word*)lf[183]+1));
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8066,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t41=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11973,a[2]=t40,tmp=(C_word)a,a+=3,tmp);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11975,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:934: ##sys#er-transformer */
t43=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t43;
av2[1]=t41;
av2[2]=t42;
((C_proc)(void*)(*((C_word*)t43+1)))(3,av2);}}

/* k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in ... */
static void C_ccall f_8297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,2))){C_save_and_reclaim((void *)f_8297,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8301,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[2],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:88: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[88];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in ... */
static void C_ccall f_8285(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,2))){C_save_and_reclaim((void *)f_8285,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8289,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[2],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:85: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[223];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in ... */
static void C_ccall f_8281(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,2))){C_save_and_reclaim((void *)f_8281,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8285,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[2],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:84: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[224];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in ... */
static void C_ccall f_8289(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,2))){C_save_and_reclaim((void *)f_8289,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8293,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[2],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:86: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[222];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* ##sys#ensure-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4158(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +3,c,4))){
C_save_and_reclaim((void*)f_4158,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+3);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
if(C_truep(C_i_closurep(t2))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4175,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:161: ##sys#er-transformer */
t7=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
if(C_truep(C_i_structurep(t2,lf[24]))){
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_slot(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
/* expand.scm:163: ##sys#error */
t6=*((C_word*)lf[25]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t5;
av2[3]=lf[26];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}}

/* k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_10250(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(28,c,4))){C_save_and_reclaim((void *)f_10250,2,av);}
a=C_alloc(28);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10252,a[2]=t8,a[3]=t6,a[4]=((C_word)li146),tmp=(C_word)a,a+=5,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10262,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word)li147),tmp=(C_word)a,a+=8,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10425,a[2]=t8,a[3]=((C_word)li150),tmp=(C_word)a,a+=4,tmp));
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10518,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1347: ##sys#check-syntax */
t13=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t13;
av2[1]=t12;
av2[2]=lf[277];
av2[3]=((C_word*)t0)[5];
av2[4]=lf[290];
((C_proc)(void*)(*((C_word*)t13+1)))(5,av2);}}

/* walk in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_fcall f_10252(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_10252,4,t0,t1,t2,t3);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10260,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1306: walk1 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_10262(t5,t4,t2,t3);}

/* k10405 in k10351 in k10330 in k10297 in walk1 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in ... */
static void C_ccall f_10407(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_10407,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10411,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1333: walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10252(t4,t3,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* map-loop2109 in k10594 in k10573 in k10545 in k10533 in a10530 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_fcall f_10639(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_10639,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10664,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_cdr(t4);
t6=C_i_cdr(t5);
t7=C_eqp(t6,C_SCHEME_END_OF_LIST);
if(C_truep(t7)){
t8=C_u_i_car(t4);
t9=t3;
f_10664(t9,t8);}
else{
t8=C_u_i_cdr(t4);
t9=C_i_cdr(t8);
t10=t3;
f_10664(t10,C_i_car(t9));}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10635 in k10594 in k10573 in k10545 in k10533 in a10530 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_10637(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(39,c,1))){C_save_and_reclaim((void *)f_10637,2,av);}
a=C_alloc(39);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[53],t2);
t4=C_a_i_list(&a,3,lf[103],((C_word*)t0)[3],t3);
t5=C_a_i_list(&a,4,lf[293],((C_word*)t0)[4],((C_word*)t0)[5],t4);
t6=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_list(&a,4,lf[50],((C_word*)t0)[2],((C_word*)t0)[7],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in ... */
static void C_ccall f_8251(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,2))){C_save_and_reclaim((void *)f_8251,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,lf[191]);
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,lf[192]);
t5=C_mutate2(((C_word *)((C_word*)t0)[5])+1,lf[193]);
t6=C_mutate2(((C_word *)((C_word*)t0)[6])+1,lf[194]);
t7=C_mutate2(((C_word *)((C_word*)t0)[7])+1,lf[195]);
t8=C_mutate2(((C_word *)((C_word*)t0)[8])+1,lf[196]);
t9=C_mutate2(((C_word *)((C_word*)t0)[9])+1,lf[197]);
t10=C_mutate2(((C_word *)((C_word*)t0)[10])+1,lf[198]);
t11=C_mutate2(((C_word *)((C_word*)t0)[11])+1,lf[199]);
t12=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8266,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[18],a[9]=((C_word*)t0)[19],a[10]=((C_word*)t0)[20],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[22],a[13]=((C_word*)t0)[23],a[14]=((C_word*)t0)[24],a[15]=((C_word*)t0)[25],a[16]=((C_word*)t0)[26],a[17]=((C_word*)t0)[27],a[18]=((C_word*)t0)[28],a[19]=((C_word*)t0)[29],a[20]=((C_word*)t0)[30],a[21]=((C_word*)t0)[31],a[22]=((C_word*)t0)[32],a[23]=((C_word*)t0)[33],a[24]=((C_word*)t0)[34],a[25]=((C_word*)t0)[35],a[26]=((C_word*)t0)[36],a[27]=((C_word*)t0)[4],a[28]=((C_word*)t0)[37],a[29]=((C_word*)t0)[2],a[30]=((C_word*)t0)[38],a[31]=((C_word*)t0)[39],a[32]=((C_word*)t0)[40],a[33]=((C_word*)t0)[41],a[34]=((C_word*)t0)[42],a[35]=((C_word*)t0)[43],a[36]=((C_word*)t0)[3],a[37]=((C_word*)t0)[6],a[38]=((C_word*)t0)[7],a[39]=((C_word*)t0)[44],a[40]=((C_word*)t0)[5],a[41]=((C_word*)t0)[9],a[42]=((C_word*)t0)[10],a[43]=((C_word*)t0)[11],a[44]=((C_word*)t0)[45],a[45]=((C_word*)t0)[46],a[46]=((C_word*)t0)[47],a[47]=((C_word*)t0)[8],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:77: r */
t13=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t13;
av2[1]=t12;
av2[2]=lf[228];
((C_proc)C_fast_retrieve_proc(t13))(3,av2);}}

/* k10274 in walk1 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_ccall f_10276(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_10276,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[196],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* ##sys#extend-macro-environment in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4195(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_4195,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4199,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:166: ##sys#macro-environment */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in ... */
static void C_ccall f_8242(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,7))){C_save_and_reclaim((void *)f_8242,2,av);}
a=C_alloc(15);
t2=C_mutate2((C_word*)lf[190]+1 /* (set! ##sys#process-syntax-rules ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8244,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate2((C_word*)lf[230]+1 /* (set! ##sys#macro-subset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9418,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[231]+1 /* (set! ##sys#fixup-macro-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9468,a[2]=((C_word)li131),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9551,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9563,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1558: ##sys#macro-environment */
t7=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* ##sys#process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in ... */
static void C_ccall f_8244(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word *a;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_demand(C_calculate_demand(143,c,2))){C_save_and_reclaim((void *)f_8244,7,av);}
a=C_alloc(143);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_SCHEME_UNDEFINED;
t42=(*a=C_VECTOR_TYPE|1,a[1]=t41,tmp=(C_word)a,a+=2,tmp);
t43=C_SCHEME_UNDEFINED;
t44=(*a=C_VECTOR_TYPE|1,a[1]=t43,tmp=(C_word)a,a+=2,tmp);
t45=C_SCHEME_UNDEFINED;
t46=(*a=C_VECTOR_TYPE|1,a[1]=t45,tmp=(C_word)a,a+=2,tmp);
t47=C_SCHEME_UNDEFINED;
t48=(*a=C_VECTOR_TYPE|1,a[1]=t47,tmp=(C_word)a,a+=2,tmp);
t49=C_SCHEME_UNDEFINED;
t50=(*a=C_VECTOR_TYPE|1,a[1]=t49,tmp=(C_word)a,a+=2,tmp);
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_SCHEME_UNDEFINED;
t54=(*a=C_VECTOR_TYPE|1,a[1]=t53,tmp=(C_word)a,a+=2,tmp);
t55=C_SCHEME_UNDEFINED;
t56=(*a=C_VECTOR_TYPE|1,a[1]=t55,tmp=(C_word)a,a+=2,tmp);
t57=C_SCHEME_UNDEFINED;
t58=(*a=C_VECTOR_TYPE|1,a[1]=t57,tmp=(C_word)a,a+=2,tmp);
t59=C_SCHEME_UNDEFINED;
t60=(*a=C_VECTOR_TYPE|1,a[1]=t59,tmp=(C_word)a,a+=2,tmp);
t61=C_SCHEME_UNDEFINED;
t62=(*a=C_VECTOR_TYPE|1,a[1]=t61,tmp=(C_word)a,a+=2,tmp);
t63=C_SCHEME_UNDEFINED;
t64=(*a=C_VECTOR_TYPE|1,a[1]=t63,tmp=(C_word)a,a+=2,tmp);
t65=C_SCHEME_UNDEFINED;
t66=(*a=C_VECTOR_TYPE|1,a[1]=t65,tmp=(C_word)a,a+=2,tmp);
t67=C_SCHEME_UNDEFINED;
t68=(*a=C_VECTOR_TYPE|1,a[1]=t67,tmp=(C_word)a,a+=2,tmp);
t69=C_SCHEME_UNDEFINED;
t70=(*a=C_VECTOR_TYPE|1,a[1]=t69,tmp=(C_word)a,a+=2,tmp);
t71=C_SCHEME_UNDEFINED;
t72=(*a=C_VECTOR_TYPE|1,a[1]=t71,tmp=(C_word)a,a+=2,tmp);
t73=C_SCHEME_UNDEFINED;
t74=(*a=C_VECTOR_TYPE|1,a[1]=t73,tmp=(C_word)a,a+=2,tmp);
t75=C_SCHEME_UNDEFINED;
t76=(*a=C_VECTOR_TYPE|1,a[1]=t75,tmp=(C_word)a,a+=2,tmp);
t77=C_SCHEME_UNDEFINED;
t78=(*a=C_VECTOR_TYPE|1,a[1]=t77,tmp=(C_word)a,a+=2,tmp);
t79=C_SCHEME_UNDEFINED;
t80=(*a=C_VECTOR_TYPE|1,a[1]=t79,tmp=(C_word)a,a+=2,tmp);
t81=C_SCHEME_UNDEFINED;
t82=(*a=C_VECTOR_TYPE|1,a[1]=t81,tmp=(C_word)a,a+=2,tmp);
t83=C_SCHEME_UNDEFINED;
t84=(*a=C_VECTOR_TYPE|1,a[1]=t83,tmp=(C_word)a,a+=2,tmp);
t85=C_SCHEME_UNDEFINED;
t86=(*a=C_VECTOR_TYPE|1,a[1]=t85,tmp=(C_word)a,a+=2,tmp);
t87=C_SCHEME_UNDEFINED;
t88=(*a=C_VECTOR_TYPE|1,a[1]=t87,tmp=(C_word)a,a+=2,tmp);
t89=C_SCHEME_UNDEFINED;
t90=(*a=C_VECTOR_TYPE|1,a[1]=t89,tmp=(C_word)a,a+=2,tmp);
t91=C_SCHEME_UNDEFINED;
t92=(*a=C_VECTOR_TYPE|1,a[1]=t91,tmp=(C_word)a,a+=2,tmp);
t93=C_SCHEME_UNDEFINED;
t94=(*a=C_VECTOR_TYPE|1,a[1]=t93,tmp=(C_word)a,a+=2,tmp);
t95=C_SCHEME_UNDEFINED;
t96=(*a=C_VECTOR_TYPE|1,a[1]=t95,tmp=(C_word)a,a+=2,tmp);
t97=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8251,a[2]=t8,a[3]=t10,a[4]=t12,a[5]=t14,a[6]=t16,a[7]=t18,a[8]=t20,a[9]=t22,a[10]=t24,a[11]=t26,a[12]=t28,a[13]=t30,a[14]=t32,a[15]=t34,a[16]=t36,a[17]=t38,a[18]=t40,a[19]=t42,a[20]=t44,a[21]=t46,a[22]=t48,a[23]=t50,a[24]=t52,a[25]=t54,a[26]=t56,a[27]=t58,a[28]=t60,a[29]=t62,a[30]=t64,a[31]=t66,a[32]=t68,a[33]=t70,a[34]=t72,a[35]=t6,a[36]=t74,a[37]=t76,a[38]=t84,a[39]=t86,a[40]=t82,a[41]=t78,a[42]=t4,a[43]=t80,a[44]=t90,a[45]=t96,a[46]=t88,a[47]=t94,a[48]=t92,a[49]=t1,a[50]=t3,a[51]=t5,a[52]=t2,tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:65: r */
t98=t5;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t98;
av2[1]=t97;
av2[2]=lf[229];
((C_proc)C_fast_retrieve_proc(t98))(3,av2);}}

/* k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in ... */
static void C_ccall f_10244(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_10244,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10247,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1304: r */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[278];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in ... */
static void C_ccall f_10247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_10247,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10250,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1305: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[280];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k4197 in extend-macro-environment in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_4199,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4202,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:167: ##sys#ensure-transformer */
t4=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in ... */
static void C_ccall f_10240(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_10240,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10244,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1303: r */
t6=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[277];
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}

/* k4605 in loop in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,6))){
C_save_and_reclaim_args((void *)trf_4607,2,t0,t1);}
a=C_alloc(9);
t2=C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[50]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4616,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:275: ##sys#check-syntax */
t4=*((C_word*)lf[54]+1);{
C_word av2[7];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[55];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[57];
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4762,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[11])){
if(C_truep(C_i_symbolp(((C_word*)((C_word*)t0)[2])[1]))){
t4=((C_word*)((C_word*)t0)[2])[1];
t5=t3;
f_4762(t5,C_i_getprop(t4,lf[59],C_SCHEME_FALSE));}
else{
t4=t3;
f_4762(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_4762(t4,C_SCHEME_FALSE);}}}

/* k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in ... */
static void C_ccall f_8275(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,2))){C_save_and_reclaim((void *)f_8275,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,lf[201]);
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,lf[202]);
t5=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8281,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],a[24]=((C_word*)t0)[27],a[25]=((C_word*)t0)[2],a[26]=((C_word*)t0)[28],a[27]=((C_word*)t0)[29],a[28]=((C_word*)t0)[30],a[29]=((C_word*)t0)[31],a[30]=((C_word*)t0)[32],a[31]=((C_word*)t0)[33],a[32]=((C_word*)t0)[34],a[33]=((C_word*)t0)[35],a[34]=((C_word*)t0)[36],a[35]=((C_word*)t0)[37],a[36]=((C_word*)t0)[3],a[37]=((C_word*)t0)[4],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:83: r */
t6=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[225];
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}

/* k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in ... */
static void C_ccall f_8270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,2))){C_save_and_reclaim((void *)f_8270,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,lf[200]);
t4=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8275,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],a[19]=((C_word*)t0)[21],a[20]=((C_word*)t0)[22],a[21]=((C_word*)t0)[23],a[22]=((C_word*)t0)[24],a[23]=((C_word*)t0)[25],a[24]=((C_word*)t0)[26],a[25]=((C_word*)t0)[27],a[26]=((C_word*)t0)[2],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],a[35]=((C_word*)t0)[36],a[36]=((C_word*)t0)[37],a[37]=((C_word*)t0)[38],a[38]=((C_word*)t0)[39],a[39]=((C_word*)t0)[40],a[40]=((C_word*)t0)[41],a[41]=((C_word*)t0)[42],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[44],a[44]=((C_word*)t0)[45],a[45]=((C_word*)t0)[46],a[46]=((C_word*)t0)[3],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:80: r */
t5=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[226];
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}

/* k10297 in walk1 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_ccall f_10299(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_10299,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1316: ##sys#check-syntax */
t4=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[278];
av2[3]=((C_word*)t0)[5];
av2[4]=lf[279];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t3=C_a_i_list(&a,2,lf[71],((C_word*)t0)[6]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10322,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_fixnum_difference(((C_word*)t0)[2],C_fix(1));
/* expand.scm:1319: walk */
t7=((C_word*)((C_word*)t0)[7])[1];
f_10252(t7,t5,((C_word*)t0)[4],t6);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10332,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:1320: c */
t3=((C_word*)t0)[11];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)t0)[9];
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}}

/* k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in ... */
static void C_ccall f_8266(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,2))){C_save_and_reclaim((void *)f_8266,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8270,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[2],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],a[37]=((C_word*)t0)[37],a[38]=((C_word*)t0)[38],a[39]=((C_word*)t0)[39],a[40]=((C_word*)t0)[40],a[41]=((C_word*)t0)[41],a[42]=((C_word*)t0)[42],a[43]=((C_word*)t0)[43],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:78: r */
t4=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[227];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k4614 in k4605 in loop in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,6))){C_save_and_reclaim((void *)f_4616,2,av);}
a=C_alloc(5);
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4628,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:278: ##sys#check-syntax */
t5=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[55];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[56];
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(7,av2);}}
else{
/* expand.scm:289: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}}

/* a4858 in loop in k4837 in expand in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4859,2,av);}
/* expand.scm:311: ##sys#expand-0 */
t2=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* loop in k4837 in expand in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4853(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,4))){
C_save_and_reclaim_args((void *)trf_4853,3,t0,t1,t2);}
a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4859,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li40),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4865,a[2]=((C_word*)t0)[4],a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:309: ##sys#call-with-values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
C_call_with_values(4,av2);}}

/* walk1 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_fcall f_10262(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_10262,4,t0,t1,t2,t3);}
a=C_alloc(12);
if(C_truep(C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10276,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10280,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1309: vector->list */
t6=*((C_word*)lf[178]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=t2;
t7=C_u_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10299,a[2]=t3,a[3]=t1,a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[4],a[9]=t5,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* expand.scm:1314: c */
t9=((C_word*)t0)[6];{
C_word av2[4];
av2[0]=t9;
av2[1]=t8;
av2[2]=((C_word*)t0)[3];
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t9))(4,av2);}}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,lf[71],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* k10258 in walk in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_ccall f_10260(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10260,2,av);}
/* expand.scm:1306: simplify */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10425(t2,((C_word*)t0)[3],t1);}

/* k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in ... */
static void C_ccall f_8212(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8212,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8215,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10205,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10207,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1353: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k4626 in k4614 in k4605 in loop in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4628(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,3))){C_save_and_reclaim((void *)f_4628,2,av);}
a=C_alloc(19);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_i_check_list_2(t3,lf[16]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4724,a[2]=t6,a[3]=t11,a[4]=t7,a[5]=((C_word)li36),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_4724(t13,t9,t3);}

/* a4864 in loop in k4837 in expand in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4865(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4865,4,av);}
if(C_truep(t3)){
/* expand.scm:313: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4853(t4,t1,t2);}
else{
t4=t2;
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* map-loop2075 in k10545 in k10533 in a10530 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in ... */
static void C_fcall f_10689(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_10689,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_u_i_cdr(t3);
t6=C_i_car(t5);
t7=C_a_i_list2(&a,2,t4,t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t8);
t10=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t8);
t11=C_slot(t2,C_fix(1));
t13=t1;
t14=t11;
t1=t13;
t2=t14;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in ... */
static void C_ccall f_8218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8218,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8221,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9892,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9894,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1371: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in ... */
static void C_ccall f_8215(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8215,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8218,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10184,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10186,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1363: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in ... */
static void C_ccall f_8203(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8203,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8206,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10725,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10727,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1259: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in ... */
static void C_ccall f_8200(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8200,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8203,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10776,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10778,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1217: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in ... */
static void C_ccall f_8209(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8209,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8212,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10238,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10240,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1301: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in ... */
static void C_ccall f_8206(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8206,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8209,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10529,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10531,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1272: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10278 in walk1 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_ccall f_10280(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_10280,2,av);}
/* expand.scm:1309: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10252(t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k4173 in ensure-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4175(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4175,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_slot(t1,C_fix(1));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* map-loop665 in k4716 in k4626 in k4614 in k4605 in loop in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4655(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_4655,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4651 in k4716 in k4626 in k4614 in k4605 in loop in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4653(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_4653,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[53],t2);
/* expand.scm:280: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=t3;
av2[3]=C_SCHEME_TRUE;
C_values(4,av2);}}

/* k5460 in k5284 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5462(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,6))){
C_save_and_reclaim_args((void *)trf_5462,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
switch(t2){
case C_fix(0):
/* expand.scm:425: err */
t3=((C_word*)t0)[3];
f_4952(t3,((C_word*)t0)[4],lf[82]);
case C_fix(1):
t3=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* expand.scm:426: loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_4983(t4,((C_word*)t0)[4],C_fix(1),((C_word*)t0)[8],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[9]);
case C_fix(2):
/* expand.scm:427: err */
t3=((C_word*)t0)[3];
f_4952(t3,((C_word*)t0)[4],lf[83]);
default:
t3=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[10]);
/* expand.scm:428: loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_4983(t4,((C_word*)t0)[4],C_fix(3),((C_word*)t0)[8],((C_word*)t0)[6],t3,((C_word*)t0)[9]);}}
else{
/* expand.scm:429: err */
t2=((C_word*)t0)[3];
f_4952(t2,((C_word*)t0)[4],lf[84]);}}

/* loop in k7084 in lambda-list? in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_7094(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_7094,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7114,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:736: keyword? */
t5=*((C_word*)lf[149]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=C_u_i_car(t4);
if(C_truep(C_i_symbolp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7142,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:739: keyword? */
t7=*((C_word*)lf[149]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}}

/* k8765 in k8686 */
static void C_ccall f_8767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(43,c,3))){C_save_and_reclaim((void *)f_8767,2,av);}
a=C_alloc(43);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8743,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[13])[1],((C_word*)((C_word*)t0)[14])[1]);
t6=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[15])[1],((C_word*)((C_word*)t0)[16])[1],C_fix(-1));
t7=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[7])[1],t5,t6);
t8=C_a_i_list(&a,1,t7);
/* synrules.scm:61: ##sys#append */
t9=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t4;
av2[2]=((C_word*)t0)[17];
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}

/* k4563 in expand in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4565(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4565,2,av);}
/* expand.scm:261: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_TRUE;
C_values(4,av2);}}

/* k7078 in k7057 in err in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7080(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_7080,2,av);}
/* expand.scm:729: string-append */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[147];
av2[3]=t1;
av2[4]=lf[148];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* lambda-list? in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7082(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_7082,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7086,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:733: ##sys#extended-lambda-list? */
t4=*((C_word*)lf[63]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7084 in lambda-list? in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7086(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_7086,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7094,a[2]=t3,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7094(t5,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* loop in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4583(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(18,0,3))){
C_save_and_reclaim_args((void *)trf_4583,3,t0,t1,t2);}
a=C_alloc(18);
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
t5=t2;
t6=C_u_i_cdr(t5);
if(C_truep(C_i_symbolp(t4))){
t7=f_3678(t4,((C_word*)t0)[2]);
t8=(C_truep(t7)?t7:t4);
t9=t8;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4607,a[2]=t10,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_pairp(((C_word*)t10)[1]))){
t12=t11;
f_4607(t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4825,a[2]=t10,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:273: ##sys#macro-environment */
t13=*((C_word*)lf[19]+1);{
C_word av2[2];
av2[0]=t13;
av2[1]=t12;
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}}
else{
/* expand.scm:299: values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}}
else{
/* expand.scm:300: values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}}

/* k9290 in k9260 */
static void C_ccall f_9292(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_9292,2,av);}
/* synrules.scm:276: free-meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[6];
av2[5]=t1;
((C_proc)C_fast_retrieve_proc(t2))(6,av2);}}

/* k7071 in k7057 in err in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,7))){C_save_and_reclaim((void *)f_7073,2,av);}
/* expand.scm:728: string-append */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[144];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[145];
av2[5]=t1;
av2[6]=lf[146];
av2[7]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(8,av2);}}

/* k6478 in k6323 in loop in expand in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6480(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_6480,2,av);}
/* expand.scm:589: fini/syntax */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6109(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}

/* k8741 in k8765 in k8686 */
static void C_ccall f_8743(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(60,c,1))){C_save_and_reclaim((void *)f_8743,2,av);}
a=C_alloc(60);
t2=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t1);
t3=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5],t3);
t5=C_a_i_list(&a,4,((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[8],t4);
t6=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[9],t5);
t7=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[10],t6);
t8=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[11],t7);
t9=((C_word*)t0)[12];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_a_i_list(&a,1,t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}

/* loop in k4297 in unregister-macro in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4301(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_4301,3,t0,t1,t2);}
a=C_alloc(4);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_caar(t2);
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t2;
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_u_i_cdr(t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=t2;
t6=C_u_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4324,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=t2;
t9=C_u_i_cdr(t8);
/* expand.scm:195: loop */
t11=t7;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}}

/* k7064 in k7057 in err in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7066(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7066,2,av);}
/* expand.scm:726: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6490 in k6323 in loop in expand in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6492(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_6492,2,av);}
a=C_alloc(9);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_i_caddr(((C_word*)t0)[2]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[4]);
t6=C_a_i_cons(&a,2,C_SCHEME_TRUE,((C_word*)t0)[5]);
/* expand.scm:593: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_6305(t7,((C_word*)t0)[7],((C_word*)t0)[8],t3,t5,t6);}

/* a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4356(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_4356,3,av);}
a=C_alloc(15);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4362,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4463,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word)li31),tmp=(C_word)a,a+=10,tmp);
/* expand.scm:207: with-exception-handler */
t5=*((C_word*)lf[47]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8076,2,av);}
a=C_alloc(9);
t2=C_mutate2((C_word*)lf[185]+1 /* (set! ##sys#initial-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8079,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11936,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11938,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:957: ##sys#er-transformer */
t6=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k4349 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4351(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4351,2,av);}
/* expand.scm:207: g569 */
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8072(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8072,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8076,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:952: ##sys#macro-environment */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8079,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8082,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11919,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11921,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:965: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7217 in doloop1404 in k7193 in walk in k7169 in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7219(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7219,2,av);}
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_7200(t4,((C_word*)t0)[5],t2,t3);}

/* k10594 in k10573 in k10545 in k10533 in a10530 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_fcall f_10596(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(21,0,3))){
C_save_and_reclaim_args((void *)trf_10596,2,t0,t1);}
a=C_alloc(21);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10637,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10639,a[2]=t5,a[3]=t9,a[4]=t6,a[5]=((C_word)li152),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_10639(t11,t7,((C_word*)t0)[7]);}

/* doloop1404 in k7193 in walk in k7169 in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_7200(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_7200,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep(C_fixnum_lessp(t3,((C_word*)t0)[2]))){
/* expand.scm:764: err */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7055(t5,t1,lf[150]);}
else{
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7219,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
/* expand.scm:766: err */
t6=((C_word*)((C_word*)t0)[3])[1];
f_7055(t6,t5,lf[151]);}
else{
if(C_truep(C_i_pairp(t2))){
t6=C_i_car(t2);
/* expand.scm:769: walk */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7176(t7,t5,t6,((C_word*)t0)[7]);}
else{
/* expand.scm:768: err */
t6=((C_word*)((C_word*)t0)[3])[1];
f_7055(t6,t5,lf[152]);}}}}

/* k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8066(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8066,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8069,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11963,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11965,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:940: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k4322 in loop in k4297 in unregister-macro in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4324(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_4324,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8069,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8072,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11953,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11955,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:947: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5961 in k5958 in k5932 in k5926 in k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5963(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_5963,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* expand.scm:516: reverse */
t4=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5964 in k5961 in k5958 in k5932 in k5926 in k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5966(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,5))){C_save_and_reclaim((void *)f_5966,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5971,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word)li58),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5971(t6,t2,((C_word*)t0)[6],((C_word*)t0)[7],t1);}

/* k5958 in k5932 in k5926 in k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5960(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_5960,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:515: reverse */
t4=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5967 in k5964 in k5961 in k5958 in k5932 in k5926 in k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5969(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5969,2,av);}
/* expand.scm:470: ##sys#append */
t2=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8095(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8095,2,av);}
a=C_alloc(9);
t2=C_mutate2((C_word*)lf[96]+1 /* (set! ##sys#define-definition ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8099,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11646,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11648,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1024: ##sys#er-transformer */
t6=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8091(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8091,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8095,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11749,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11751,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:998: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,5))){C_save_and_reclaim((void *)f_8099,2,av);}
a=C_alloc(12);
t2=C_mutate2((C_word*)lf[97]+1 /* (set! ##sys#define-syntax-definition ...) */,t1);
t3=C_mutate2(&lf[186] /* (set! check-for-multiple-bindings ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8101,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8176,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11594,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11596,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1063: ##sys#er-transformer */
t7=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8085,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8088,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11885,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11887,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:981: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4341(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_4341,7,t0,t1,t2,t3,t4,t5,t6);}
a=C_alloc(12);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4351,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4356,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=t3,a[6]=t5,a[7]=((C_word*)t0)[2],a[8]=((C_word)li32),tmp=(C_word)a,a+=9,tmp);
/* expand.scm:207: call-with-current-continuation */
t9=*((C_word*)lf[48]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}

/* k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8082(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8082,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8085,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11902,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11904,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:973: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8088,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8091,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11868,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11870,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:989: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k9271 in k9260 */
static void C_ccall f_9273(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_9273,2,av);}
/* synrules.scm:271: free-meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[6];
av2[5]=t1;
((C_proc)C_fast_retrieve_proc(t2))(6,av2);}}

/* k9697 in k9676 in k9673 in k9667 in a9661 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in ... */
static void C_ccall f_9699(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_9699,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9702,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1475: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[248];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* g1326 in k7007 in get-line-number in k4152 in k3674 in k3670 in k3666 in k3662 */
static C_word C_fcall f_7013(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_i_assq(((C_word*)t0)[2],t1);
return((C_truep(t2)?C_i_cdr(t2):C_SCHEME_FALSE));}

/* k5932 in k5926 in k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5934(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,2))){C_save_and_reclaim((void *)f_5934,2,av);}
a=C_alloc(17);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5938,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5960,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:514: reverse */
t9=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}

/* k5936 in k5932 in k5926 in k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5938(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_5938,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[50],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* ##sys#expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4338(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(22,c,7))){C_save_and_reclaim((void *)f_4338,5,av);}
a=C_alloc(22);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4341,a[2]=t3,a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4539,a[2]=t6,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4583,a[2]=t3,a[3]=t8,a[4]=t12,a[5]=t6,a[6]=t4,a[7]=((C_word)li38),tmp=(C_word)a,a+=8,tmp));
t14=((C_word*)t12)[1];
f_4583(t14,t1,t2);}

/* k4411 in copy in k4377 in a4367 in a4361 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4413(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,5))){
C_save_and_reclaim_args((void *)trf_4413,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_i_car(((C_word*)t0)[2]);
/* expand.scm:226: string-append */
t5=*((C_word*)lf[36]+1);{
C_word av2[6];
av2[0]=t5;
av2[1]=t2;
av2[2]=lf[37];
av2[3]=t3;
av2[4]=lf[38];
av2[5]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}
else{
/* expand.scm:232: copy */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4396(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* ##sys#undefine-macro! in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4332(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4332,3,av);}
/* expand.scm:198: ##sys#unregister-macro */
t3=*((C_word*)lf[30]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7007 in get-line-number in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7009(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_7009,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7013,a[2]=((C_word*)t0)[2],a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:704: g1326 */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=f_7013(t2,t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a11750 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11751(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_11751,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11755,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1000: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[100];
av2[3]=t2;
av2[4]=lf[346];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k11753 in a11750 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_11755,2,av);}
a=C_alloc(9);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11760,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li172),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_11760(t5,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k11246 in k11189 in k11149 in k11074 in k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_ccall f_11248(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_11248,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,4,lf[293],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6412 in loop2 in k6341 in k6323 in loop in expand in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6414(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_6414,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cddr(((C_word*)t0)[4]);
/* expand.scm:578: ##sys#expand-curried-define */
t4=*((C_word*)lf[107]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=t3;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k6796 in loop in k6771 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6798(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6798,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6802,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:658: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6778(t6,t3,t5);}

/* k6419 in k6412 in loop2 in k6341 in k6323 in loop in expand in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6421(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6421,2,av);}
/* expand.scm:577: loop2 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6348(t2,((C_word*)t0)[3],t1);}

/* k6426 in loop2 in k6341 in k6323 in loop in expand in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6428(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,5))){C_save_and_reclaim((void *)f_6428,2,av);}
a=C_alloc(18);
t2=C_u_i_car(((C_word*)t0)[2]);
t3=C_a_i_list1(&a,1,t2);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=C_u_i_cdr(((C_word*)t0)[2]);
t6=C_i_cddr(((C_word*)t0)[4]);
t7=C_a_i_cons(&a,2,t5,t6);
t8=C_a_i_cons(&a,2,lf[72],t7);
t9=C_a_i_cons(&a,2,t8,((C_word*)t0)[5]);
t10=C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[6]);
/* expand.scm:583: loop */
t11=((C_word*)((C_word*)t0)[7])[1];
f_6305(t11,((C_word*)t0)[8],((C_word*)t0)[9],t4,t9,t10);}

/* map-loop1079 in k5964 in k5961 in k5958 in k5932 in k5926 in k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5971(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_5971,5,t0,t1,t2,t3,t4);}
a=C_alloc(9);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5978,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_pairp(t2))){
t6=C_i_pairp(t3);
t7=t5;
f_5978(t7,(C_truep(t6)?C_i_pairp(t4):C_SCHEME_FALSE));}
else{
t6=t5;
f_5978(t6,C_SCHEME_FALSE);}}

/* k5976 in map-loop1079 in k5964 in k5961 in k5958 in k5932 in k5926 in k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5978(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(17,0,3))){
C_save_and_reclaim_args((void *)trf_5978,2,t0,t1);}
a=C_alloc(17);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(0));
t4=C_slot(((C_word*)t0)[4],C_fix(0));
if(C_truep(C_slot(((C_word*)t0)[5],C_fix(0)))){
/* expand.scm:512: ##sys#expand-multiple-values-assignment */
t5=*((C_word*)lf[91]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t2;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=C_i_car(t3);
t6=t2;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,lf[94],t5,t4);
f_6004(2,av2);}}}
else{
t2=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_slot(((C_word*)t0)[8],C_fix(1));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_ccall f_8230(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8230,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8233,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9660,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9662,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1448: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static void C_ccall f_8233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8233,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8236,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9630,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9632,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1509: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in ... */
static void C_ccall f_8236(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8236,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8239,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9603,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9605,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1518: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in ... */
static void C_ccall f_8239(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8239,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8242,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9567,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9569,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp);
/* synrules.scm:47: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6526 in k6323 in loop in expand in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6528(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_6528,2,av);}
/* expand.scm:595: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6305(t2,((C_word*)t0)[3],t1,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k10371 in k10360 in k10351 in k10330 in k10297 in walk1 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in ... */
static void C_ccall f_10373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_10373,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[70],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_8221(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8221,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8224,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9879,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9881,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1425: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_8224(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8224,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8227,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9866,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9868,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1433: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_ccall f_8227(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8227,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8230,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9840,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9842,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1441: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10382 in k10390 in k10351 in k10330 in k10297 in walk1 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in ... */
static void C_ccall f_10384(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_10384,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[200],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5086 in k5011 in k4999 in k4995 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_5088,2,av);}
a=C_alloc(12);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_list(&a,1,t4);
/* expand.scm:356: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[5];
av2[2]=((C_word*)t0)[6];
av2[3]=t5;
C_values(4,av2);}}

/* k4422 in k4411 in copy in k4377 in a4367 in a4361 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_4424,2,av);}
a=C_alloc(6);
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[35],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6741 in expand-curried-define in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6743(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_6743,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list3(&a,3,lf[100],((C_word*)((C_word*)t0)[3])[1],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6542 in k6323 in loop in expand in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6544(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_6544,2,av);}
a=C_alloc(3);
t2=C_eqp(((C_word*)t0)[2],t1);
if(C_truep(t2)){
/* expand.scm:601: fini */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5821(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8]);}
else{
t3=C_a_i_cons(&a,2,t1,((C_word*)t0)[9]);
/* expand.scm:602: loop */
t4=((C_word*)((C_word*)t0)[10])[1];
f_6305(t4,((C_word*)t0)[4],t3,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* k10390 in k10351 in k10330 in k10297 in walk1 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in ... */
static void C_ccall f_10392(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_10392,2,av);}
a=C_alloc(13);
t2=C_a_i_list(&a,3,lf[200],((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10384,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1331: walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_10252(t5,t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* syntax-error in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6751(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,2))){
C_save_and_reclaim((void*)f_6751,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6759,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:648: ##sys#strip-syntax */
t4=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6757 in syntax-error in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6759(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6759,2,av);}{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[120]+1);
av2[3]=lf[121];
av2[4]=t1;
C_apply(5,av2);}}

/* ##sys#syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6762(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6762,4,av);}
a=C_alloc(5);
if(C_truep(C_i_nullp(*((C_word*)lf[118]+1)))){
/* expand.scm:661: ##sys#syntax-error-hook */
t4=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6829,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:662: open-output-string */
t5=*((C_word*)lf[140]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k11747 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11749(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11749,2,av);}
/* expand.scm:995: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[100];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5925(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,4))){C_save_and_reclaim((void *)f_5925,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6067,a[2]=t4,a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6067(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* k5926 in k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5928(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_5928,2,av);}
a=C_alloc(15);
t2=C_i_check_list_2(t1,lf[16]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6033,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[8],a[5]=((C_word)li59),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_6033(t7,t3,t1);}

/* k9620 in a9604 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in ... */
static void C_ccall f_9622(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_9622,2,av);}
/* expand.scm:1521: ##sys#validate-exports */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[243]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[243]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[239];
tp(4,av2);}}

/* k9637 in k9634 in a9631 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in ... */
static void C_ccall f_9639(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_9639,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,lf[103],t3);
t5=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_list(&a,2,lf[245],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* loop in k6771 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6778(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_6778,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_caar(t2);
t4=C_eqp(lf[137],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6798,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:658: cadar */
t6=*((C_word*)lf[68]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=t2;
t6=C_u_i_cdr(t5);
/* expand.scm:659: loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* k6771 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6773(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_6773,2,av);}
a=C_alloc(6);
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6778,a[2]=t4,a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6778(t6,((C_word*)t0)[2],t2);}

/* k11489 in k11466 in a11463 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in ... */
static void C_ccall f_11491(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_11491,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9628 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in ... */
static void C_ccall f_9630(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9630,2,av);}
/* expand.scm:1506: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[244];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a9631 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in ... */
static void C_ccall f_9632(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_9632,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9636,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1511: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[244];
av2[3]=t2;
av2[4]=lf[247];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k5042 in k5011 in k4999 in k4995 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,3))){C_save_and_reclaim((void *)f_5044,2,av);}
a=C_alloc(27);
t2=C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[4],t2);
t4=C_a_i_list(&a,1,t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=C_a_i_list(&a,1,t6);
/* expand.scm:356: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[7];
av2[2]=((C_word*)t0)[8];
av2[3]=t7;
C_values(4,av2);}}

/* k9634 in a9631 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in ... */
static void C_ccall f_9636(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_9636,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_cons(&a,2,lf[103],t3);
/* expand.scm:1512: ##sys#register-meta-expression */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[246]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[246]+1);
av2[1]=t2;
av2[2]=t4;
tp(3,av2);}}

/* k8856 in k8852 in k8839 */
static void C_ccall f_8858(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8858,2,av);}
/* synrules.scm:180: append */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k8852 in k8839 */
static void C_ccall f_8854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,5))){C_save_and_reclaim((void *)f_8854,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8858,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cddr(((C_word*)t0)[3]);
t5=C_a_i_list(&a,3,lf[211],((C_word*)t0)[4],((C_word*)t0)[5]);
/* synrules.scm:189: process-pattern */
t6=((C_word*)((C_word*)t0)[6])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=t5;
av2[4]=((C_word*)t0)[7];
av2[5]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t6))(6,av2);}}

/* k11801 in k11784 in k11773 in loop in k11753 in a11750 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11803(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11803,2,av);}
if(C_truep(t1)){
/* expand.scm:1009: ##sys#defjam-error */
t2=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_11789(2,av2);}}}

/* k10033 in k9991 in k9953 in test in k9908 in k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in ... */
static void C_ccall f_10035(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_10035,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10042,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* expand.scm:1400: test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9922(t4,t2,t3);}
else{
/* expand.scm:1401: err */
t2=((C_word*)((C_word*)t0)[5])[1];
f_9912(t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k5090 in k5011 in k4999 in k4995 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5092(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_5092,2,av);}
a=C_alloc(3);
t2=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t2)){
t3=C_a_i_list1(&a,1,t2);
/* expand.scm:381: ##sys#append */
t4=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=C_a_i_list1(&a,1,t3);
/* expand.scm:381: ##sys#append */
t5=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k11808 in k11784 in k11773 in loop in k11753 in a11750 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11810(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_11810,2,av);}
/* expand.scm:1008: c */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
((C_proc)C_fast_retrieve_proc(t2))(4,av2);}}

/* k11812 in k11773 in loop in k11753 in a11750 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11814(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_11814,2,av);}
/* expand.scm:1007: ##sys#register-export */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[340]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[340]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
tp(4,av2);}}

/* k8839 */
static void C_ccall f_8841(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,5))){C_save_and_reclaim((void *)f_8841,2,av);}
a=C_alloc(25);
if(C_truep(t1)){
t2=C_i_cddr(((C_word*)t0)[2]);
t3=C_i_length(t2);
t4=t3;
t5=C_eqp(t4,C_fix(0));
t6=(C_truep(t5)?((C_word*)t0)[3]:C_a_i_list(&a,3,lf[210],((C_word*)t0)[3],t4));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8854,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t9=((C_word*)t0)[2];
t10=C_u_i_car(t9);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8870,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=t7,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word)li115),tmp=(C_word)a,a+=8,tmp);
/* synrules.scm:181: process-pattern */
t12=((C_word*)((C_word*)t0)[5])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t12;
av2[1]=t8;
av2[2]=t10;
av2[3]=((C_word*)((C_word*)t0)[7])[1];
av2[4]=t11;
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t12))(6,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8916,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[11])[1],((C_word*)t0)[3]);
/* synrules.scm:192: process-pattern */
t6=((C_word*)((C_word*)t0)[5])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=t4;
av2[3]=t5;
av2[4]=((C_word*)t0)[6];
av2[5]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t6))(6,av2);}}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8945,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* synrules.scm:195: vector->list */
t3=*((C_word*)lf[178]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}}

/* k5067 in k5011 in k4999 in k4995 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_5069,2,av);}
a=C_alloc(12);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_list(&a,1,t4);
/* expand.scm:356: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[5];
av2[2]=((C_word*)t0)[6];
av2[3]=t5;
C_values(4,av2);}}

/* k6191 in loop in fini/syntax in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6193(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(13,0,4))){
C_save_and_reclaim_args((void *)trf_6193,2,t0,t1);}
a=C_alloc(13);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=C_i_cadr(t3);
if(C_truep(C_i_pairp(t7))){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6217,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:536: caadr */
t9=*((C_word*)lf[106]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t8;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t8=C_u_i_car(t3);
t9=C_u_i_cdr(t3);
t10=C_u_i_car(t9);
t11=C_eqp(t8,t10);
if(C_truep(t11)){
/* expand.scm:542: ##sys#defjam-error */
t12=*((C_word*)lf[89]+1);{
C_word av2[3];
av2[0]=t12;
av2[1]=t6;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
t12=C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* expand.scm:532: loop */
t13=((C_word*)((C_word*)t0)[4])[1];
f_6119(t13,((C_word*)t0)[5],t5,t12,C_SCHEME_FALSE);}}}
else{
/* expand.scm:546: loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6119(t2,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_TRUE);}}

/* assq-reverse in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static C_word C_fcall f_7889(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_stack_overflow_check;
loop:{}
if(C_truep(C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=C_i_cdar(t2);
t4=C_eqp(t3,t1);
if(C_truep(t4)){
t5=t2;
return(C_u_i_car(t5));}
else{
t5=t2;
t6=C_u_i_cdr(t5);
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* a8869 in k8839 */
static void C_ccall f_8870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(21,c,2))){C_save_and_reclaim((void *)f_8870,3,av);}
a=C_alloc(21);
t3=C_eqp(((C_word*)((C_word*)t0)[2])[1],t2);
if(C_truep(t3)){
/* synrules.scm:184: mapit */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=((C_word*)t0)[4];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}
else{
t4=C_a_i_list(&a,1,((C_word*)((C_word*)t0)[2])[1]);
t5=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[5])[1],t4,t2);
t6=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[6])[1],t5,((C_word*)t0)[4]);
/* synrules.scm:184: mapit */
t7=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t1;
av2[2]=t6;
((C_proc)C_fast_retrieve_proc(t7))(3,av2);}}}

/* k5011 in k4999 in k4995 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5013(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,2))){
C_save_and_reclaim_args((void *)trf_5013,2,t0,t1);}
a=C_alloc(12);
if(C_truep(t1)){
t2=C_i_caar(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5044,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* expand.scm:374: cadar */
t5=*((C_word*)lf[68]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=((C_word*)((C_word*)t0)[9])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:C_i_nullp(((C_word*)t0)[10]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5069,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:378: reverse */
t5=*((C_word*)lf[69]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5088,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5092,a[2]=((C_word*)t0)[9],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:381: reverse */
t6=*((C_word*)lf[69]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}}

/* k11456 in a11426 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in ... */
static void C_ccall f_11458(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,1))){C_save_and_reclaim((void *)f_11458,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,4,lf[293],((C_word*)t0)[4],t2,C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k10894 in k10949 in k10846 in k10827 in expand in k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in ... */
static void C_fcall f_10896(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_10896,2,t0,t1);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1254: expand */
t4=((C_word*)((C_word*)t0)[4])[1];
f_10815(t4,t3,((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k11872 in a11869 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_11874,2,av);}
a=C_alloc(3);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[103],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k10006 in k9991 in k9953 in test in k9908 in k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in ... */
static void C_ccall f_10008(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_10008,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_u_i_cdr(((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
/* expand.scm:1398: test */
t4=((C_word*)((C_word*)t0)[5])[1];
f_9922(t4,((C_word*)t0)[2],t3);}}

/* a11869 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11870,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11874,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:991: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[347];
av2[3]=t2;
av2[4]=lf[348];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4999 in k4995 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5001(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_5001,2,t0,t1);}
a=C_alloc(12);
t2=t1;
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
/* expand.scm:356: values */{
C_word av2[4];
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
C_values(4,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t4)){
t5=t3;
f_5013(t5,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[9]))){
t5=C_i_cdr(((C_word*)t0)[2]);
t6=t3;
f_5013(t6,C_i_nullp(t5));}
else{
t5=t3;
f_5013(t5,C_SCHEME_FALSE);}}}}

/* k11466 in a11463 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in ... */
static void C_ccall f_11468(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_11468,2,av);}
a=C_alloc(13);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_caddr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t2))){
t4=C_u_i_car(t2);
t5=C_a_i_list(&a,2,lf[316],t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11491,a[2]=((C_word*)t0)[3],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_u_i_cdr(t2);
t9=C_a_i_list(&a,1,t3);
/* expand.scm:1109: ##sys#append */
t10=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=t7;
av2[2]=t8;
av2[3]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}
else{
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[94],t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a11463 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 in ... */
static void C_ccall f_11464(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11464,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11468,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1114: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[315];
av2[3]=t2;
av2[4]=lf[317];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k11460 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 in ... */
static void C_ccall f_11462(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11462,2,av);}
/* expand.scm:1109: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[315];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k10827 in expand in k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_ccall f_10829(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_10829,2,av);}
a=C_alloc(11);
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10835,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10842,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1237: ##sys#strip-syntax */
t4=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10848,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=C_i_car(((C_word*)t0)[6]);
/* expand.scm:1240: c */
t4=((C_word*)t0)[8];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[12];
av2[3]=t3;
((C_proc)C_fast_retrieve_proc(t4))(4,av2);}}}

/* k10498 in k10453 in k10427 in simplify in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static void C_ccall f_10500(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_10500,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=t1;
t4=C_i_assq(lf[282],t3);
t5=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_i_cdr(t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* f_8811 in k8333 in k8328 in k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in ... */
static void C_ccall f_8811(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_8811,6,av);}
a=C_alloc(13);
if(C_truep(C_i_symbolp(t2))){
if(C_truep(C_i_memq(t2,((C_word*)t0)[2]))){
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8835,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* synrules.scm:174: mapit */
t7=t4;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t7))(3,av2);}}}
else{
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8841,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* synrules.scm:175: segment-pattern? */
t7=((C_word*)((C_word*)t0)[10])[1];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}}

/* k10833 in k10827 in expand in k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_ccall f_10835(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_10835,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10838,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1238: expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10815(t3,t2,((C_word*)t0)[4],C_SCHEME_TRUE);}

/* k10836 in k10833 in k10827 in expand in k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static void C_ccall f_10838(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_10838,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[299];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7428 in walk in k7169 in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7430,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:794: walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7176(t6,((C_word*)t0)[5],t3,t5);}

/* k8833 */
static void C_ccall f_8835(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_8835,2,av);}
a=C_alloc(9);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list1(&a,1,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k10840 in k10827 in expand in k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_ccall f_10842(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_10842,2,av);}
/* expand.scm:1235: ##sys#warn */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[187]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[187]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=lf[300];
av2[3]=t1;
tp(4,av2);}}

/* k10846 in k10827 in expand in k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_ccall f_10848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(29,c,3))){C_save_and_reclaim((void *)f_10848,2,av);}
a=C_alloc(29);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1241: expand */
t3=((C_word*)((C_word*)t0)[7])[1];
f_10815(t3,t2,((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10936,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=((C_word)li157),tmp=(C_word)a,a+=5,tmp);
t7=C_u_i_car(((C_word*)t0)[2]);
t8=C_i_check_list_2(t7,lf[16]);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10951,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10953,a[2]=t6,a[3]=t4,a[4]=t11,a[5]=t5,a[6]=((C_word)li158),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_10953(t13,t9,t7);}}

/* er-macro-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8051(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8051,3,av);}
/* expand.scm:923: make-er/ir-transformer */
t3=*((C_word*)lf[176]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* ir-macro-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8057(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8057,3,av);}
/* expand.scm:924: make-er/ir-transformer */
t3=*((C_word*)lf[176]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k8040 in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8042(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_8042,2,av);}
/* expand.scm:921: mirror-rename */
t2=((C_word*)((C_word*)t0)[2])[1];
f_7914(t2,((C_word*)t0)[3],t1);}

/* k8044 in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8046(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8046,2,av);}
/* expand.scm:921: handler */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=((C_word*)((C_word*)t0)[4])[1];
av2[4]=((C_word*)((C_word*)t0)[5])[1];
((C_proc)C_fast_retrieve_proc(t2))(5,av2);}}

/* fini/syntax in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6109(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,5))){
C_save_and_reclaim_args((void *)trf_6109,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(14);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6117,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6119,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_6119(t10,t6,t5,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k7048 in test in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7050(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7050,2,av);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* expand.scm:721: err */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7055(t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* err in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_7055(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_7055,3,t0,t1,t2);}
a=C_alloc(6);
t3=*((C_word*)lf[117]+1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7059,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:725: get-line-number */
t5=*((C_word*)lf[142]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[117]+1);
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7057 in err in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7059(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_7059,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7073,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:728: symbol->string */
t5=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7080,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:729: symbol->string */
t5=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* g1566 in k7824 in k7769 in k7761 in compare in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static C_word C_fcall f_7811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_i_cdr(t1);
return(C_eqp(t2,((C_word*)t0)[2]));}

/* k9667 in a9661 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in ... */
static void C_ccall f_9669(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_9669,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)t0)[2],C_fix(4)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9832,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1452: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[250];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_9675(2,av2);}}}

/* loop in fini/syntax in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6119(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(11,0,4))){
C_save_and_reclaim_args((void *)trf_6119,5,t0,t1,t2,t3,t4);}
a=C_alloc(11);
if(C_truep(t4)){
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6141,a[2]=t2,a[3]=t1,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:525: reverse */
t10=*((C_word*)lf[69]+1);{
C_word av2[3];
av2[0]=t10;
av2[1]=t9;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6193,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=C_i_car(t2);
if(C_truep(C_i_listp(t6))){
t7=t2;
t8=C_u_i_car(t7);
t9=C_i_length(t8);
if(C_truep(C_fixnum_greater_or_equal_p(C_fix(3),t9))){
t10=C_i_caar(t2);
if(C_truep(C_i_symbolp(t10))){
t11=t2;
t12=C_u_i_car(t11);
t13=C_u_i_car(t12);
/* expand.scm:530: comp */
t14=t5;
f_6193(t14,f_5755(((C_word*)((C_word*)t0)[3])[1],lf[101],t13));}
else{
t11=t5;
f_6193(t11,C_SCHEME_FALSE);}}
else{
t10=t5;
f_6193(t10,C_SCHEME_FALSE);}}
else{
t7=t5;
f_6193(t7,C_SCHEME_FALSE);}}
else{
/* expand.scm:526: loop */
t15=t1;
t16=t2;
t17=t3;
t18=C_SCHEME_TRUE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}}}

/* k6115 in fini/syntax in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6117(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_6117,2,av);}
/* expand.scm:521: fini */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5821(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t1);}

/* test in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_7043(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_7043,5,t0,t1,t2,t3,t4);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7050,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:721: pred */
t6=t3;{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}

/* k9658 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static void C_ccall f_9660(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9660,2,av);}
/* expand.scm:1445: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[248];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a9661 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static void C_ccall f_9662(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_9662,5,av);}
a=C_alloc(7);
t5=C_i_length(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9669,a[2]=t6,a[3]=t1,a[4]=t3,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1451: ##sys#check-syntax */
t8=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[248];
av2[3]=t2;
av2[4]=lf[260];
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}

/* k9676 in k9673 in k9667 in a9661 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in ... */
static void C_ccall f_9678(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,4))){C_save_and_reclaim((void *)f_9678,2,av);}
a=C_alloc(13);
t2=t1;
t3=C_i_cadr(t2);
t4=t3;
t5=C_i_cadddr(t2);
t6=t5;
if(C_truep(C_i_symbolp(t6))){
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[2],C_fix(4)))){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9699,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9733,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9737,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1474: symbol->string */
t10=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9740,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1480: ##sys#register-module-alias */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[255]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[255]+1);
av2[1]=t7;
av2[2]=t4;
av2[3]=t6;
tp(4,av2);}}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9743,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1483: ##sys#check-syntax */
t8=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[248];
av2[3]=t2;
av2[4]=lf[257];
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}}

/* k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7038(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,5))){C_save_and_reclaim((void *)f_7038,2,av);}
a=C_alloc(33);
t2=t1;
t3=C_i_nullp(((C_word*)t0)[2]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_i_cdr(((C_word*)t0)[2]));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7043,a[2]=t8,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t14=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7055,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li85),tmp=(C_word)a,a+=5,tmp));
t15=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7082,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7144,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t17=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7171,a[2]=t8,a[3]=t6,a[4]=t12,a[5]=t10,a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
t18=C_mutate2((C_word*)lf[117]+1 /* (set! ##sys#syntax-error-culprit ...) */,((C_word*)t0)[7]);
t19=t17;
f_7171(t19,t18);}
else{
t18=t17;
f_7171(t18,C_SCHEME_UNDEFINED);}}

/* k10729 in a10726 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in ... */
static void C_ccall f_10731(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_10731,2,av);}
a=C_alloc(7);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10741,a[2]=t5,a[3]=t7,a[4]=((C_word)li155),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_10741(t9,((C_word*)t0)[3],t2);}

/* k9673 in k9667 in a9661 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in ... */
static void C_ccall f_9675(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_9675,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1453: ##sys#strip-syntax */
t3=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9755,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9818,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_caddr(((C_word*)t0)[5]);
/* expand.scm:1493: ##sys#strip-syntax */
t5=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k9607 in a9604 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in ... */
static void C_ccall f_9609(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_9609,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9612,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1524: ##sys#current-module */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[242]+1));
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[242]+1);
av2[1]=t3;
tp(2,av2);}}

/* ##sys#check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7028(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand((c-5)*C_SIZEOF_PAIR +8,c,2))){
C_save_and_reclaim((void*)f_7028,c,av);}
a=C_alloc((c-5)*C_SIZEOF_PAIR+8);
t5=C_build_rest(&a,c,5,av);
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t6=C_i_nullp(t5);
t7=(C_truep(t6)?C_SCHEME_FALSE:C_i_car(t5));
t8=t7;
t9=C_i_nullp(t5);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:C_i_cdr(t5));
t11=t10;
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7038,a[2]=t11,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t4,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_nullp(t11))){
/* expand.scm:718: ##sys#current-environment */
t13=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=t12;
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t13=t12;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=C_i_car(t11);
f_7038(2,av2);}}}

/* k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in ... */
static void C_ccall f_10782(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_10782,2,av);}
a=C_alloc(7);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10790,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1222: r */
t8=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[77];
((C_proc)C_fast_retrieve_proc(t8))(3,av2);}}

/* k9601 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in ... */
static void C_ccall f_9603(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9603,2,av);}
/* expand.scm:1515: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[239];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a9604 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in ... */
static void C_ccall f_9605(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_9605,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9609,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9622,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=C_i_cdr(t2);
/* expand.scm:1522: ##sys#strip-syntax */
t8=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k7852 in k7769 in k7761 in compare in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_7854,2,av);}
a=C_alloc(4);
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7839,a[2]=((C_word*)t0)[3],a[3]=((C_word)li98),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:868: g1575 */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=f_7839(t3,t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9610 in k9607 in a9604 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in ... */
static void C_ccall f_9612(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_9612,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9615,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* expand.scm:1526: ##sys#add-to-export-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[241]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[241]+1);
av2[1]=t2;
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=lf[240];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9613 in k9610 in k9607 in a9604 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in ... */
static void C_ccall f_9615(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_9615,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[240];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10723 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in ... */
static void C_ccall f_10725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10725,2,av);}
/* expand.scm:1256: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[88];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a10726 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in ... */
static void C_ccall f_10727(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_10727,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10731,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1261: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[88];
av2[3]=t2;
av2[4]=lf[297];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in ... */
static void C_ccall f_10778(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_10778,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10782,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1219: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[298];
av2[3]=t2;
av2[4]=lf[305];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10774 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in ... */
static void C_ccall f_10776(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10776,2,av);}
/* expand.scm:1214: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[298];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k11513 in k11510 in a11507 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in ... */
static void C_ccall f_11515(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_11515,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[105],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k11510 in a11507 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 in ... */
static void C_ccall f_11512(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11512,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1106: check-for-multiple-bindings */
f_8101(t2,t3,((C_word*)t0)[2],lf[319]);}

/* k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in ... */
static void C_ccall f_10799(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_10799,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:1226: r */
t4=((C_word*)t0)[9];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[226];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in ... */
static void C_ccall f_10796(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_10796,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:1225: r */
t4=((C_word*)t0)[8];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[303];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in ... */
static void C_ccall f_10793(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_10793,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* expand.scm:1224: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[304];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in ... */
static void C_ccall f_10790(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_10790,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10793,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1223: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[220];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k11535 in k11532 in a11529 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 in ... */
static void C_ccall f_11537(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_11537,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[322],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k11532 in a11529 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11534(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11534,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1097: check-for-multiple-bindings */
f_8101(t2,t3,((C_word*)t0)[2],lf[323]);}

/* a11529 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11530(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11530,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11534,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1096: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[321];
av2[3]=t2;
av2[4]=lf[324];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10764 in expand in k10729 in a10726 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in ... */
static void C_ccall f_10766(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_10766,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[50],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k11504 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11506(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11506,2,av);}
/* expand.scm:1100: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[318];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7951 in mirror-rename in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7953,2,av);}
/* expand.scm:892: mirror-rename */
t2=((C_word*)((C_word*)t0)[2])[1];
f_7914(t2,((C_word*)t0)[3],t1);}

/* a11507 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11508(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11508,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11512,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1105: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[318];
av2[3]=t2;
av2[4]=lf[320];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10533 in a10530 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in ... */
static void C_ccall f_10535(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_10535,2,av);}
a=C_alloc(6);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10547,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1278: r */
t11=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[295];
((C_proc)C_fast_retrieve_proc(t11))(3,av2);}}

/* a10530 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in ... */
static void C_ccall f_10531(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10531,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10535,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1274: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[291];
av2[3]=t2;
av2[4]=lf[296];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k7947 in mirror-rename in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7949,2,av);}
/* expand.scm:892: list->vector */
t2=*((C_word*)lf[177]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k10545 in k10533 in a10530 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in ... */
static void C_ccall f_10547(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,3))){C_save_and_reclaim((void *)f_10547,2,av);}
a=C_alloc(20);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_check_list_2(((C_word*)t0)[2],lf[16]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10575,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10689,a[2]=t5,a[3]=t10,a[4]=t6,a[5]=((C_word)li153),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_10689(t12,t8,((C_word*)t0)[2]);}

/* k10306 in k10297 in walk1 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_ccall f_10308(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_10308,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_car(((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7930 in k7926 in mirror-rename in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7932(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_7932,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7926 in mirror-rename in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7928(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_7928,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7932,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:890: mirror-rename */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7914(t6,t3,t5);}

/* mirror-rename in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_7914(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_7914,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7928,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* expand.scm:890: mirror-rename */
t9=t3;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
if(C_truep(C_i_vectorp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7949,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7953,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:892: vector->list */
t5=*((C_word*)lf[178]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
t3=f_3678(t2,((C_word*)t0)[3]);
t4=f_7889(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t4)){
t5=t1;
t6=t5;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_i_car(t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
if(C_truep(t3)){
if(C_truep(C_i_pairp(t3))){
/* expand.scm:902: rename */
t5=((C_word*)((C_word*)t0)[6])[1];{
C_word av2[3];
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
f_7498(3,av2);}}
else{
t5=t2;
t6=C_i_getprop(t5,lf[7],C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t1;
t8=t7;{
C_word av2[2];
av2[0]=t8;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
/* expand.scm:909: rename */
t7=((C_word*)((C_word*)t0)[6])[1];{
C_word av2[3];
av2[0]=t7;
av2[1]=t1;
av2[2]=t2;
f_7498(3,av2);}}}}
else{
/* expand.scm:900: rename */
t5=((C_word*)((C_word*)t0)[6])[1];{
C_word av2[3];
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
f_7498(3,av2);}}}}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}}

/* k10573 in k10545 in k10533 in a10530 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in ... */
static void C_ccall f_10575(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,2))){C_save_and_reclaim((void *)f_10575,2,av);}
a=C_alloc(17);
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=t3;
t5=C_u_i_cdr(((C_word*)t0)[2]);
t6=C_eqp(t5,C_SCHEME_END_OF_LIST);
t7=(C_truep(t6)?lf[292]:C_a_i_cons(&a,2,lf[103],t5));
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10596,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t10=C_eqp(((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
if(C_truep(t10)){
t11=t9;
f_10596(t11,lf[294]);}
else{
t11=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[6]);
t12=t9;
f_10596(t12,C_a_i_cons(&a,2,lf[50],t11));}}

/* g1575 in k7852 in k7769 in k7761 in compare in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static C_word C_fcall f_7839(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_i_cdr(t1);
return(C_eqp(((C_word*)t0)[2],t2));}

/* f_9337 in k8333 in k8328 in k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in ... */
static void C_ccall f_9337(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9337,3,av);}
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_cdr(t3);
if(C_truep(C_i_pairp(t4))){
t5=C_i_cadr(t2);
/* synrules.scm:296: ellipsis? */
t6=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t5;
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}
else{
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7824 in k7769 in k7761 in compare in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7826(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_7826,2,av);}
a=C_alloc(4);
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7811,a[2]=((C_word*)t0)[3],a[3]=((C_word)li97),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:861: g1566 */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=f_7811(t3,t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10516 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_10518(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_10518,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
/* expand.scm:1348: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10252(t3,((C_word*)t0)[4],t2,C_fix(0));}

/* k9305 in k9260 */
static void C_ccall f_9307(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_9307,2,av);}
/* synrules.scm:281: free-meta-variables */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=((C_word*)t0)[6];
((C_proc)C_fast_retrieve_proc(t2))(6,av2);}}

/* expand in k9908 in k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in ... */
static void C_fcall f_10058(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(16,0,3))){
C_save_and_reclaim_args((void *)trf_10058,3,t0,t1,t2);}
a=C_alloc(16);
t3=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_i_check_list_2(((C_word*)t0)[2],lf[16]);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10083,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10085,a[2]=t6,a[3]=t11,a[4]=t7,a[5]=((C_word)li141),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_10085(t13,t9,((C_word*)t0)[2]);}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=t2;
t7=C_u_i_cdr(t6);
if(C_truep(C_i_pairp(t5))){
t8=C_i_car(t5);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10148,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t9,tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1414: c */
t11=((C_word*)t0)[5];{
C_word av2[4];
av2[0]=t11;
av2[1]=t10;
av2[2]=t9;
av2[3]=((C_word*)t0)[6];
((C_proc)C_fast_retrieve_proc(t11))(4,av2);}}
else{
/* expand.scm:1412: err */
t8=((C_word*)((C_word*)t0)[7])[1];
f_9912(t8,t1,t5);}}
else{
/* expand.scm:1407: err */
t4=((C_word*)((C_word*)t0)[7])[1];
f_9912(t4,t1,t2);}}}

/* f_9309 in k8333 in k8328 in k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in ... */
static void C_ccall f_9309(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_9309,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9316,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* synrules.scm:285: segment-template? */
t5=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}

/* k11699 in k11664 in k11661 in a11647 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11701(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_11701,2,av);}
/* expand.scm:1032: ##sys#register-export */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[340]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[340]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
tp(4,av2);}}

/* k11705 in k11702 in a11647 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11707(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_11707,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[5];
t4=C_u_i_car(t3);
t5=C_i_car(((C_word*)t0)[2]);
t6=C_eqp(t4,t5);
if(C_truep(t6)){
/* expand.scm:1040: ##sys#syntax-error-hook */
t7=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=lf[337];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t7=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_UNDEFINED;
f_11710(2,av2);}}}

/* k11702 in a11647 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11704(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_11704,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1038: ##sys#check-syntax */
t3=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[101];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[338];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in ... */
static void C_ccall f_11035(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_11035,2,av);}
a=C_alloc(11);
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11041,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11048,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1168: open-output-string */
t4=*((C_word*)lf[140]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11073,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=C_i_car(((C_word*)t0)[6]);
/* expand.scm:1172: c */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[11];
av2[3]=t3;
((C_proc)C_fast_retrieve_proc(t4))(4,av2);}}}

/* k10527 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in ... */
static void C_ccall f_10529(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10529,2,av);}
/* expand.scm:1269: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[291];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k9314 */
static void C_ccall f_9316(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_9316,2,av);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
/* synrules.scm:288: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[215];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
if(C_truep(C_i_listp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
/* synrules.scm:290: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[216];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k8579 in k8575 in k8535 */
static void C_ccall f_8581(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8581,2,av);}
/* expand.scm:1532: ##sys#append */
t2=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5613 in k5591 in k5572 in k5569 in a5566 in expand-multiple-values-assignment in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5615(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_5615,2,av);}
a=C_alloc(12);
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
/* expand.scm:449: ##sys#append */
t2=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=lf[93];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
/* expand.scm:449: ##sys#append */
t2=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=C_a_i_list(&a,3,lf[94],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=C_a_i_list(&a,1,t2);
/* expand.scm:449: ##sys#append */
t4=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}}

/* a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in ... */
static void C_ccall f_11003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_11003,5,av);}
a=C_alloc(6);
t5=C_i_cdr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11010,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1157: r */
t8=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[304];
((C_proc)C_fast_retrieve_proc(t8))(3,av2);}}

/* k10999 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in ... */
static void C_ccall f_11001(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11001,2,av);}
/* expand.scm:1151: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[227];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in ... */
static void C_ccall f_11016(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_11016,2,av);}
a=C_alloc(11);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11021,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word)li161),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_11021(t6,((C_word*)t0)[6],((C_word*)t0)[7],C_SCHEME_FALSE);}

/* k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in ... */
static void C_ccall f_11013(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_11013,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1159: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[226];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in ... */
static void C_ccall f_11010(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_11010,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11013,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1158: r */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[220];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k10409 in k10405 in k10351 in k10330 in k10297 in walk1 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in ... */
static void C_ccall f_10411(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_10411,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[200],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* map-loop931 in k5591 in k5572 in k5569 in a5566 in expand-multiple-values-assignment in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5637(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_5637,4,t0,t1,t2,t3);}
a=C_alloc(12);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,3,lf[94],t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k6139 in loop in fini/syntax in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6141(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_6141,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6146,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word)li63),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_6146(t6,t2,t1);}

/* k6142 in k6139 in loop in fini/syntax in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6144(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_6144,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,lf[105],t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,1,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* map-loop1139 in k6139 in loop in fini/syntax in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6146(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_6146,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10427 in simplify in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_ccall f_10429(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10429,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10433,a[2]=((C_word*)t0)[2],a[3]=((C_word)li148),tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1302: g2197 */
t3=t2;
f_10433(t3,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1337: match-expression */
f_6614(t2,((C_word*)t0)[4],lf[286],lf[287]);}}

/* simplify in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_fcall f_10425(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_10425,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10429,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1335: match-expression */
f_6614(t3,t2,lf[288],lf[289]);}

/* g2197 in k10427 in simplify in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_fcall f_10433(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_10433,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_i_assq(lf[282],t2);
t4=C_i_cdr(t3);
t5=C_a_i_list(&a,2,lf[275],t4);
/* expand.scm:1336: simplify */
t6=((C_word*)((C_word*)t0)[2])[1];
f_10425(t6,t1,t5);}

/* map-loop355 in extend-se in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4033(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4033,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4058,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* expand.scm:130: g361 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8575 in k8535 */
static void C_ccall f_8577(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_8577,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8581,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)t0)[5];
t6=C_u_i_cdr(t5);
/* synrules.scm:142: process-match */
t7=((C_word*)((C_word*)t0)[6])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=t4;
av2[3]=t6;
av2[4]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t7))(5,av2);}}

/* k8571 in k8535 */
static void C_ccall f_8573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,1))){C_save_and_reclaim((void *)f_8573,2,av);}
a=C_alloc(18);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5],t3);
t5=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_list(&a,1,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* loop in k11753 in a11750 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_11760(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_11760,3,t0,t1,t2);}
a=C_alloc(8);
t3=C_i_cadr(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
if(C_truep(C_i_pairp(t4))){
t8=C_i_car(t4);
if(C_truep(C_i_pairp(t8))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11823,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t4,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1014: ##sys#check-syntax */
t10=*((C_word*)lf[54]+1);{
C_word av2[5];
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[100];
av2[3]=t2;
av2[4]=lf[342];
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11833,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1017: ##sys#check-syntax */
t10=*((C_word*)lf[54]+1);{
C_word av2[5];
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[100];
av2[3]=t2;
av2[4]=lf[343];
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}}
else{
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11775,a[2]=t4,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1005: ##sys#check-syntax */
t9=*((C_word*)lf[54]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[100];
av2[3]=t2;
av2[4]=lf[345];
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}}

/* k10453 in k10427 in simplify in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_ccall f_10455(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10455,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li149),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1302: g2204 */
t3=t2;
f_10459(t3,((C_word*)t0)[4],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10500,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1344: match-expression */
f_6614(t2,((C_word*)t0)[3],lf[284],lf[285]);}}

/* g2204 in k10453 in k10427 in simplify in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static void C_fcall f_10459(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_10459,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_i_assq(lf[283],t2);
t4=C_i_length(t3);
if(C_truep(C_fixnum_lessp(t4,C_fix(32)))){
t5=C_i_assq(lf[282],t2);
t6=C_i_cdr(t5);
t7=C_u_i_cdr(t3);
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,lf[275],t8);
/* expand.scm:1341: simplify */
t10=((C_word*)((C_word*)t0)[2])[1];
f_10425(t10,t1,t9);}
else{
t5=((C_word*)t0)[3];
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k11773 in loop in k11753 in a11750 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11775(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_11775,2,av);}
a=C_alloc(12);
t2=C_i_getprop(((C_word*)t0)[2],lf[5],C_SCHEME_FALSE);
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11814,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1007: ##sys#current-module */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[242]+1));
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[242]+1);
av2[1]=t6;
tp(2,av2);}}

/* k10040 in k10033 in k9991 in k9953 in test in k9908 in k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in ... */
static void C_ccall f_10042(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_10042,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_not(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in ... */
static void C_ccall f_8197(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8197,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8200,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11001,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11003,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1154: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in ... */
static void C_fcall f_11021(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,4))){
C_save_and_reclaim_args((void *)trf_11021,4,t0,t1,t2,t3);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=t2;
t7=C_u_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11035,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t5,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
/* expand.scm:1165: ##sys#check-syntax */
t9=*((C_word*)lf[54]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[227];
av2[3]=t5;
av2[4]=lf[313];
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[314];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4056 in map-loop355 in extend-se in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4058,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4033(t6,((C_word*)t0)[5],t5);}

/* k11787 in k11784 in k11773 in loop in k11753 in a11750 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11789(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_11789,2,av);}
a=C_alloc(9);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[94],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[94],((C_word*)t0)[4],lf[344]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11784 in k11773 in loop in k11753 in a11750 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11786(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_11786,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11803,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11810,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1008: r */
t5=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[100];
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}

/* k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in ... */
static void C_ccall f_8194(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8194,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8197,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11373,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11375,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1138: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 in ... */
static void C_ccall f_8191(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8191,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8194,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11425,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11427,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1124: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8188(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8188,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8191,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11462,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11464,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1112: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* f_8503 in k8333 in k8328 in k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in ... */
static void C_ccall f_8503(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(24,c,3))){C_save_and_reclaim((void *)f_8503,5,av);}
a=C_alloc(24);
if(C_truep(C_i_symbolp(t3))){
if(C_truep(C_i_memq(t3,((C_word*)t0)[2]))){
t5=C_a_i_list(&a,2,lf[208],t3);
t6=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[3])[1],t5);
t7=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[4])[1],t2,t6);
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_a_i_list(&a,1,t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_8537,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* synrules.scm:136: segment-pattern? */
t6=((C_word*)((C_word*)t0)[17])[1];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
av2[3]=t4;
((C_proc)C_fast_retrieve_proc(t6))(4,av2);}}}

/* k11708 in k11705 in k11702 in a11647 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11710(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,1))){C_save_and_reclaim((void *)f_11710,2,av);}
a=C_alloc(21);
t2=C_u_i_car(((C_word*)t0)[2]);
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,lf[72],t4);
t6=C_a_i_list(&a,2,lf[23],t5);
t7=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[336],t2,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8185(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8185,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8188,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11506,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11508,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1103: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8182(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8182,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8185,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11528,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11530,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1094: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* ##sys#globalize in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4070(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4070,4,av);}
a=C_alloc(7);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4076,a[2]=t5,a[3]=t3,a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4076(t7,t1,t2);}

/* k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8179(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8179,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8182,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11550,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11552,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1085: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* loop1 in globalize in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4076(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_4076,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_i_symbolp(t2))){
t3=t2;
t4=C_i_getprop(t3,lf[5],C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4092,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li9),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:141: g465 */
t6=t5;
f_4092(t6,t1,t4);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4110,a[2]=t2,a[3]=t6,a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4110(t8,t1,((C_word*)t0)[3]);}}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8535 */
static void C_ccall f_8537(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(35,c,4))){C_save_and_reclaim((void *)f_8537,2,av);}
a=C_alloc(35);
if(C_truep(t1)){
/* synrules.scm:137: process-segment-match */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
((C_proc)C_fast_retrieve_proc(t2))(4,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t2=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[4]);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8573,a[2]=t6,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t4,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8577,a[2]=t7,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t9=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[12])[1],((C_word*)((C_word*)t0)[6])[1]);
t10=((C_word*)t0)[5];
t11=C_u_i_car(t10);
/* synrules.scm:141: process-match */
t12=((C_word*)((C_word*)t0)[11])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t12;
av2[1]=t8;
av2[2]=t9;
av2[3]=t11;
av2[4]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t12))(5,av2);}}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[5]))){
t2=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[4]);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[13])[1],((C_word*)((C_word*)t0)[6])[1]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8630,a[2]=t6,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t4,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[14])[1],((C_word*)((C_word*)t0)[6])[1]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8638,a[2]=((C_word*)t0)[11],a[3]=t7,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* synrules.scm:147: vector->list */
t11=*((C_word*)lf[178]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t2=C_i_nullp(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8651,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8651(t4,t2);}
else{
t4=C_booleanp(((C_word*)t0)[5]);
t5=t3;
f_8651(t5,(C_truep(t4)?t4:C_charp(((C_word*)t0)[5])));}}}}}

/* k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8176(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8176,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8179,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11572,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11574,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1076: ##sys#er-transformer */
t5=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* copy in k4377 in a4367 in a4361 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4396(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4396,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=t2;
t5=C_u_i_cdr(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4413,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_equalp(lf[39],t3))){
if(C_truep(C_i_pairp(t5))){
t7=C_u_i_car(t5);
t8=t6;
f_4413(t8,C_i_stringp(t7));}
else{
t7=t6;
f_4413(t7,C_SCHEME_FALSE);}}
else{
t7=t6;
f_4413(t7,C_SCHEME_FALSE);}}}

/* map-loop2277 in expand in k9908 in k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in ... */
static void C_fcall f_10085(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_10085,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10081 in expand in k9908 in k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in ... */
static void C_ccall f_10083(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10083,2,av);}{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[25]+1);
av2[3]=lf[268];
av2[4]=t1;
C_apply(5,av2);}}

/* k4388 in k4377 in a4367 in a4361 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4390(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4390,2,av);}
a=C_alloc(4);
t2=C_a_i_record3(&a,3,lf[33],((C_word*)t0)[2],t1);
/* expand.scm:210: ##sys#abort */
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* g465 in loop1 in globalize in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4092(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_4092,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
/* expand.scm:145: loop1 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4076(t3,t1,t2);}
else{
t3=((C_word*)t0)[3];
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5373 in k5284 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5375(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,6))){
C_save_and_reclaim_args((void *)trf_5375,2,t0,t1);}
if(C_truep(C_fixnum_less_or_equal_p(((C_word*)t0)[2],C_fix(2)))){
/* expand.scm:414: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4983(t2,((C_word*)t0)[4],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[6],C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);}
else{
/* expand.scm:415: err */
t2=((C_word*)t0)[8];
f_4952(t2,((C_word*)t0)[4],lf[80]);}}

/* k9991 in k9953 in test in k9908 in k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in ... */
static void C_ccall f_9993(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_9993,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=C_u_i_car(((C_word*)t0)[2]);
/* expand.scm:1397: test */
t5=((C_word*)((C_word*)t0)[5])[1];
f_9922(t5,t3,t4);}
else{
/* expand.scm:1399: err */
t3=((C_word*)((C_word*)t0)[6])[1];
f_9912(t3,((C_word*)t0)[3],((C_word*)t0)[7]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10035,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1400: c */
t3=((C_word*)t0)[8];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[9];
av2[3]=((C_word*)t0)[10];
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}}

/* a4367 in a4361 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4368(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4368,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4379,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_structurep(((C_word*)t0)[2],lf[33]))){
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=t2;
f_4379(t4,C_i_memq(lf[40],t3));}
else{
t3=t2;
f_4379(t3,C_SCHEME_FALSE);}}

/* k10320 in k10297 in walk1 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_ccall f_10322(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_10322,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list3(&a,3,lf[200],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a4361 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4362(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4362,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4368,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li22),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:207: k565 */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* ##sys#expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_4949,6,av);}
a=C_alloc(18);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4952,a[2]=t4,a[3]=t2,a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4969,a[2]=t8,a[3]=t10,a[4]=t3,a[5]=t6,a[6]=t5,a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* expand.scm:345: macro-alias */
f_3695(t11,lf[88],t5);}

/* k10330 in k10297 in walk1 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_ccall f_10332(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_10332,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=C_a_i_list(&a,2,lf[71],((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10343,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* expand.scm:1322: walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_10252(t6,t4,((C_word*)t0)[6],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10353,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[7]))){
t3=C_u_i_car(((C_word*)t0)[7]);
/* expand.scm:1323: c */
t4=((C_word*)t0)[9];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
av2[3]=t3;
((C_proc)C_fast_retrieve_proc(t4))(4,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_10353(2,av2);}}}}

/* k8138 in k8118 in loop in check-for-multiple-bindings in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8140(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8140,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_u_i_car(t3);
/* expand.scm:1053: ##sys#warn */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[187]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[187]+1);
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t4;
av2[4]=((C_word*)t0)[4];
tp(5,av2);}}

/* k5392 in k5284 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5394(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5394,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_5375(t3,t2);}

/* k9971 in k9953 in test in k9908 in k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in ... */
static void C_ccall f_9973(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_9973,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
/* expand.scm:1392: test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9922(t4,((C_word*)t0)[5],t3);}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k10341 in k10330 in k10297 in walk1 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static void C_ccall f_10343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_10343,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list3(&a,3,lf[200],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10351 in k10330 in k10297 in walk1 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static void C_ccall f_10353(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,4))){C_save_and_reclaim((void *)f_10353,2,av);}
a=C_alloc(13);
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10362,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1325: ##sys#check-syntax */
t4=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[280];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[281];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t3=C_a_i_list(&a,2,lf[71],((C_word*)t0)[7]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10392,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t6=C_i_cdr(((C_word*)t0)[3]);
t7=C_fixnum_difference(((C_word*)t0)[2],C_fix(1));
/* expand.scm:1330: walk */
t8=((C_word*)((C_word*)t0)[5])[1];
f_10252(t8,t5,t6,t7);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10407,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1333: walk */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10252(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4978(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,7))){C_save_and_reclaim((void *)f_4978,2,av);}
a=C_alloc(15);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t4,a[11]=((C_word*)t0)[9],a[12]=((C_word)li49),tmp=(C_word)a,a+=13,tmp));
t6=((C_word*)t4)[1];
f_4983(t6,((C_word*)t0)[10],C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[11]);}

/* k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4975(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_4975,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* expand.scm:349: macro-alias */
f_3695(t3,lf[55],((C_word*)t0)[8]);}

/* k10360 in k10351 in k10330 in k10297 in walk1 in k10248 in k10245 in k10242 in a10239 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in ... */
static void C_ccall f_10362(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_10362,2,av);}
a=C_alloc(4);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10373,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1326: walk */
t5=((C_word*)((C_word*)t0)[4])[1];
f_10252(t5,t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* loop in check-for-multiple-bindings in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_8107(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_8107,5,t0,t1,t2,t3,t4);}
a=C_alloc(9);
t5=C_i_nullp(t2);
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8120,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t7=C_i_caar(t2);
if(C_truep(C_i_memq(t7,t3))){
t8=t2;
t9=C_u_i_car(t8);
t10=C_u_i_car(t9);
t11=C_i_memq(t10,t4);
t12=t6;
f_8120(t12,C_i_not(t11));}
else{
t8=t6;
f_8120(t8,C_SCHEME_FALSE);}}}

/* loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4983(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(16,0,6))){
C_save_and_reclaim_args((void *)trf_4983,7,t0,t1,t2,t3,t4,t5,t6);}
a=C_alloc(16);
if(C_truep(C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4997,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5245,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:357: reverse */
t9=*((C_word*)lf[69]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t8;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
/* expand.scm:357: reverse */
t8=*((C_word*)lf[69]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}}
else{
if(C_truep(C_i_symbolp(t6))){
if(C_truep(C_fixnum_greaterp(t2,C_fix(2)))){
/* expand.scm:385: err */
t7=((C_word*)t0)[9];
f_4952(t7,t1,lf[75]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t7=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t6);
/* expand.scm:389: loop */
t12=t1;
t13=C_fix(4);
t14=t3;
t15=t4;
t16=C_SCHEME_END_OF_LIST;
t17=C_SCHEME_END_OF_LIST;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
t5=t16;
t6=t17;
goto loop;}
else{
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t6);
/* expand.scm:389: loop */
t12=t1;
t13=C_fix(4);
t14=t3;
t15=t4;
t16=C_SCHEME_END_OF_LIST;
t17=C_SCHEME_END_OF_LIST;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
t5=t16;
t6=t17;
goto loop;}}}
else{
if(C_truep(C_i_pairp(t6))){
t7=C_i_car(t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5286,a[2]=t8,a[3]=t6,a[4]=t2,a[5]=((C_word*)t0)[10],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[5],a[12]=t4,a[13]=t5,tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_i_symbolp(t8))){
t10=C_eqp(C_fix(3),t2);
t11=t9;
f_5286(t11,(C_truep(t10)?C_SCHEME_FALSE:f_3678(t8,((C_word*)t0)[11])));}
else{
t10=t9;
f_5286(t10,C_SCHEME_FALSE);}}
else{
/* expand.scm:391: err */
t7=((C_word*)t0)[9];
f_4952(t7,t1,lf[85]);}}}}

/* k4377 in a4367 in a4361 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4379(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,3))){
C_save_and_reclaim_args((void *)trf_4379,2,t0,t1);}
a=C_alloc(11);
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4390,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_slot(((C_word*)t0)[2],C_fix(2));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4396,a[2]=((C_word*)t0)[4],a[3]=t7,a[4]=((C_word)li21),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4396(t9,t4,t5);}
else{
t2=((C_word*)t0)[2];
/* expand.scm:210: ##sys#abort */
t3=*((C_word*)lf[34]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* a6092 in foldl1054 in k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6093(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6093,5,av);}
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k6089 in foldl1054 in k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6091(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6091,2,av);}
/* expand.scm:503: ##sys#append */
t2=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* check-for-multiple-bindings in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_8101(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,5))){
C_save_and_reclaim_args((void *)trf_8101,4,t1,t2,t3,t4);}
a=C_alloc(8);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8107,a[2]=t6,a[3]=t3,a[4]=t4,a[5]=((C_word)li106),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_8107(t8,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k6095 in foldl1054 in k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6097(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6097,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
f_6067(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* a9880 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_9881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_9881,5,av);}
a=C_alloc(9);
t5=C_i_cdr(t2);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,lf[263],t5,C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k4925 in loop in extended-lambda-list? in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4927(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_4927,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_cdr(t2);
/* expand.scm:336: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4908(t4,((C_word*)t0)[2],t3);}}

/* k9877 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_9879(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9879,2,av);}
/* expand.scm:1422: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[264];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4470 in k4467 in tmp13092 in a4462 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4472(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4472,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_9894(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_9894,5,av);}
a=C_alloc(6);
t5=C_i_cdr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9901,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1374: r */
t8=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[220];
((C_proc)C_fast_retrieve_proc(t8))(3,av2);}}

/* k9890 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_9892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9892,2,av);}
/* expand.scm:1368: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[265];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4200 in k4197 in extend-macro-environment in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_4202,2,av);}
a=C_alloc(16);
t2=t1;
t3=f_3678(((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4209,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:165: g509 */
t5=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=f_4209(t4,t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_a_i_list2(&a,2,((C_word*)t0)[4],t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4227,a[2]=((C_word*)t0)[5],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
/* expand.scm:175: ##sys#macro-environment */
t9=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t6;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}

/* g509 in k4200 in k4197 in extend-macro-environment in k4152 in k3674 in k3670 in k3666 in k3662 */
static C_word C_fcall f_4209(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;{}
t2=C_i_set_car(t1,((C_word*)t0)[2]);
t3=t1;
t4=C_u_i_cdr(t3);
t5=C_i_set_car(t4,((C_word*)t0)[3]);
return(t1);}

/* ##sys#syntax-rules-mismatch in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6983,3,av);}
/* expand.scm:702: ##sys#syntax-error-hook */
t3=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[141];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* err in k9908 in k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in ... */
static void C_fcall f_9912(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,4))){
C_save_and_reclaim_args((void *)trf_9912,3,t0,t1,t2);}
a=C_alloc(3);
t3=C_a_i_cons(&a,2,lf[265],((C_word*)t0)[2]);
/* expand.scm:1379: ##sys#error */
t4=*((C_word*)lf[25]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[266];
av2[3]=t2;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* get-line-number in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6989(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_6989,3,av);}
a=C_alloc(4);
if(C_truep(*((C_word*)lf[116]+1))){
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
if(C_truep(C_i_symbolp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7009,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:709: ##sys#hash-table-ref */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[143]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[143]+1);
av2[1]=t5;
av2[2]=*((C_word*)lf[116]+1);
av2[3]=t4;
tp(4,av2);}}
else{
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9908 in k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static void C_ccall f_9910(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(28,c,3))){C_save_and_reclaim((void *)f_9910,2,av);}
a=C_alloc(28);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9912,a[2]=((C_word*)t0)[2],a[3]=((C_word)li139),tmp=(C_word)a,a+=4,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9922,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li140),tmp=(C_word)a,a+=9,tmp));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10058,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word)li142),tmp=(C_word)a,a+=9,tmp));
t12=((C_word*)t10)[1];
f_10058(t12,((C_word*)t0)[7],((C_word*)t0)[2]);}

/* f_4496 in tmp13092 in a4462 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4496(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4496,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* test in k9908 in k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in ... */
static void C_fcall f_9922(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_9922,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9936,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:1383: ##sys#strip-syntax */
t4=*((C_word*)lf[12]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t3=C_i_car(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9955,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* expand.scm:1388: c */
t8=((C_word*)t0)[6];{
C_word av2[4];
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[2];
av2[3]=t4;
((C_proc)C_fast_retrieve_proc(t8))(4,av2);}}
else{
/* expand.scm:1384: err */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9912(t3,t1,t2);}}}

/* k5313 in k5284 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5315(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5315,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_5299(t3,t2);}

/* tmp13092 in a4462 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4465(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(31,0,4))){
C_save_and_reclaim_args((void *)trf_4465,2,t0,t1);}
a=C_alloc(31);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4469,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4496,a[2]=((C_word*)t0)[3],a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4502,a[2]=t6,a[3]=t4,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4507,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word)li26),tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4513,a[2]=t4,a[3]=t6,a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp);
/* expand.scm:237: ##sys#dynamic-wind */
t10=*((C_word*)lf[46]+1);{
C_word av2[5];
av2[0]=t10;
av2[1]=t2;
av2[2]=t7;
av2[3]=t8;
av2[4]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}
else{
/* expand.scm:239: handler */
t3=((C_word*)t0)[5];{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[6];
av2[4]=((C_word*)t0)[7];
((C_proc)C_fast_retrieve_proc(t3))(5,av2);}}}

/* k4467 in tmp13092 in a4462 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4469(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_4469,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4472,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=(C_truep(t4)?C_SCHEME_FALSE:C_eqp(((C_word*)t0)[4],t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4485,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4489,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:243: symbol->string */
t8=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t6=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* foldl1054 in k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6067(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,5))){
C_save_and_reclaim_args((void *)trf_6067,4,t0,t1,t2,t3);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6097,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(0));
t8=t6;
t9=t3;
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6091,a[2]=t8,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6093,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp);
/* expand.scm:503: ##sys#decompose-lambda-list */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[95]+1));
C_word av2[4];
av2[0]=*((C_word*)lf[95]+1);
av2[1]=t10;
av2[2]=t7;
av2[3]=t11;
tp(4,av2);}}
else{
t4=t3;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* a4462 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4463(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_4463,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li28),tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4520,a[2]=((C_word*)t0)[8],a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4537,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tmp13092 */
t5=t2;
f_4465(t5,t4);}

/* ##sys#copy-macro in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4237(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4237,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4248,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:180: ##sys#macro-environment */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k4246 in copy-macro in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4248(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4248,2,av);}
t2=f_3678(((C_word*)t0)[2],t1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=*((C_word*)lf[27]+1);
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
C_apply(5,av2);}}

/* map-loop2470 */
static void C_fcall f_8395(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8395,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8420,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* synrules.scm:110: g2476 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4483 in k4467 in tmp13092 in a4462 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4485(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4485,2,av);}
/* expand.scm:241: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4487 in k4467 in tmp13092 in a4462 in a4355 in call-handler in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4489(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4489,2,av);}
/* expand.scm:242: string-append */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[42];
av2[3]=t1;
av2[4]=lf[43];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* f_9381 in k8333 in k8328 in k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in ... */
static void C_ccall f_9381(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_9381,3,av);}
a=C_alloc(7);
t3=C_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9391,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word)li124),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_9391(t7,t1,t3);}

/* loop in extended-lambda-list? in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4908(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_4908,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_eqp(t3,lf[64]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4927,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4927(t6,t4);}
else{
t6=C_eqp(t3,lf[65]);
t7=t5;
f_4927(t7,(C_truep(t6)?t6:C_eqp(t3,lf[66])));}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* ##sys#extended-lambda-list? in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4902(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_4902,3,av);}
a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4908,a[2]=t4,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4908(t6,t1,t2);}

/* loop */
static void C_fcall f_9391(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_9391,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9398,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t2;
t5=C_u_i_car(t4);
/* synrules.scm:310: ellipsis? */
t6=((C_word*)((C_word*)t0)[3])[1];{
C_word av2[3];
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}
else{
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_9398(2,av2);}}}

/* k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in ... */
static void C_ccall f_8306(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,2))){C_save_and_reclaim((void *)f_8306,2,av);}
a=C_alloc(53);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,lf[204]);
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,lf[205]);
t5=(*a=C_CLOSURE_TYPE|52,a[1]=(C_word)f_8313,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],a[24]=((C_word*)t0)[27],a[25]=((C_word*)t0)[28],a[26]=((C_word*)t0)[29],a[27]=((C_word*)t0)[30],a[28]=((C_word*)t0)[31],a[29]=((C_word*)t0)[32],a[30]=((C_word*)t0)[33],a[31]=((C_word*)t0)[34],a[32]=((C_word*)t0)[35],a[33]=((C_word*)t0)[36],a[34]=((C_word*)t0)[37],a[35]=((C_word*)t0)[38],a[36]=((C_word*)t0)[39],a[37]=((C_word*)t0)[40],a[38]=((C_word*)t0)[41],a[39]=((C_word*)t0)[2],a[40]=((C_word*)t0)[42],a[41]=((C_word*)t0)[3],a[42]=((C_word*)t0)[43],a[43]=((C_word*)t0)[4],a[44]=((C_word*)t0)[44],a[45]=((C_word*)t0)[45],a[46]=((C_word*)t0)[46],a[47]=((C_word*)t0)[47],a[48]=((C_word*)t0)[48],a[49]=((C_word*)t0)[49],a[50]=((C_word*)t0)[50],a[51]=((C_word*)t0)[51],a[52]=((C_word*)t0)[52],tmp=(C_word)a,a+=53,tmp);
/* synrules.scm:94: r */
t6=((C_word*)t0)[51];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[220];
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}

/* k4252 in macro? in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4254(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4254,2,av);}
a=C_alloc(4);
t2=f_3678(((C_word*)t0)[2],t1);
t3=C_i_pairp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4276,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:186: ##sys#macro-environment */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* ##sys#macro? in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4250(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_4250,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+4);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4254,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* expand.scm:183: ##sys#current-environment */
t5=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_i_car(t3);
f_4254(2,av2);}}}

/* k11192 in k11189 in k11149 in k11074 in k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_ccall f_11194(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(34,c,3))){C_save_and_reclaim((void *)f_11194,2,av);}
a=C_alloc(34);
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=C_a_i_list(&a,3,lf[72],C_SCHEME_END_OF_LIST,t3);
t5=t4;
t6=C_i_cadr(((C_word*)t0)[2]);
t7=C_a_i_list(&a,3,lf[214],t6,t2);
t8=t7;
t9=C_i_cadddr(((C_word*)t0)[2]);
t10=C_a_i_list(&a,3,lf[214],t9,t2);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11221,a[2]=t8,a[3]=t11,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1209: expand */
t13=((C_word*)((C_word*)t0)[4])[1];
f_11021(t13,t12,((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k9396 in loop */
static void C_ccall f_9398(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9398,2,av);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
/* synrules.scm:311: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9391(t3,((C_word*)t0)[4],t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5857 in k5850 in loop in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_5859,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,lf[103],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k11189 in k11149 in k11074 in k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_ccall f_11191(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_11191,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1202: r */
t3=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[77];
((C_proc)C_fast_retrieve_proc(t3))(3,av2);}}
else{
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_u_i_cdr(((C_word*)t0)[2]);
t5=C_a_i_cons(&a,2,lf[103],t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11248,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1212: expand */
t8=((C_word*)((C_word*)t0)[4])[1];
f_11021(t8,t7,((C_word*)t0)[5],C_SCHEME_FALSE);}}

/* k9423 in macro-subset in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in ... */
static void C_ccall f_9425(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_9425,2,av);}
/* expand.scm:1542: ##sys#fixup-macro-environment */
t2=*((C_word*)lf[231]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##sys#macro-subset in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in ... */
static void C_ccall f_9418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +8,c,2))){
C_save_and_reclaim((void*)f_9418,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+8);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9425,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9432,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1538: ##sys#macro-environment */
t9=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}

/* k9366 */
static void C_ccall f_9368(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_9368,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9375,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* synrules.scm:302: segment-depth */
t4=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k5869 in k5861 in k5850 in loop in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_5871,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* expand.scm:495: ##sys#append */
t3=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k9430 in macro-subset in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in ... */
static void C_ccall f_9432(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_9432,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9434,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li127),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_9434(t5,((C_word*)t0)[3],t1);}

/* f_9361 in k8333 in k8328 in k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in ... */
static void C_ccall f_9361(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_9361,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9368,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* synrules.scm:301: segment-template? */
t4=((C_word*)((C_word*)t0)[3])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* loop in k9430 in macro-subset in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in ... */
static void C_fcall f_9434(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_9434,3,t0,t1,t2);}
a=C_alloc(4);
t3=C_i_nullp(t2);
t4=(C_truep(t3)?t3:C_eqp(t2,((C_word*)t0)[2]));
if(C_truep(t4)){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_i_car(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9455,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=t2;
t9=C_u_i_cdr(t8);
/* expand.scm:1541: loop */
t11=t7;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* k9373 in k9366 */
static void C_ccall f_9375(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_9375,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fixnum_plus(C_fix(1),t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5861 in k5850 in loop in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5863,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5871,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:495: expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6299(t4,t3,((C_word*)t0)[4]);}

/* strip-syntax in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_3753(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_3753,3,av);}
a=C_alloc(9);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3759,a[2]=t4,a[3]=t6,a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3759(t8,t1,t2);}

/* walk in strip-syntax in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_3759(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(16,0,2))){
C_save_and_reclaim_args((void *)trf_3759,3,t0,t1,t2);}
a=C_alloc(16);
t3=C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t3)){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_i_cdr(t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
t4=t2;
t5=C_i_getprop(t4,lf[5],C_SCHEME_FALSE);
t6=t2;
t7=C_i_getprop(t6,lf[7],C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
if(C_truep(t5)){
if(C_truep(C_i_pairp(t5))){
t8=t2;
t9=t1;{
C_word av2[2];
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}
else{
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_FALSE);
t5=t4;
t6=C_a_i_cons(&a,2,t2,t5);
t7=C_a_i_cons(&a,2,t6,((C_word*)((C_word*)t0)[2])[1]);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t7);
t9=t5;
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3831,a[2]=t9,a[3]=t5,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t11=t2;
t12=C_u_i_car(t11);
/* expand.scm:116: walk */
t14=t10;
t15=t12;
t1=t14;
t2=t15;
goto loop;}
else{
if(C_truep(C_i_vectorp(t2))){
t4=C_block_size(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3849,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* expand.scm:121: make-vector */
t7=*((C_word*)lf[11]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}}}

/* k6899 in k6896 in k6893 in k6884 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6901(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_6901,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:680: outstr */
t3=((C_word*)t0)[3];
f_6831(t3,t2,lf[135]);}

/* k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6907(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_6907,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:682: outstr */
t3=((C_word*)t0)[3];
f_6831(t3,t2,lf[134]);}

/* k6902 in k6899 in k6896 in k6893 in k6884 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6904(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_6904,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:681: ##sys#print */
t3=*((C_word*)lf[123]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k9453 in loop in k9430 in macro-subset in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in ... */
static void C_ccall f_9455(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_9455,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k11143 in k11074 in k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_11145(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_11145,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6910(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_6910,2,av);}
a=C_alloc(13);
t2=C_i_length(((C_word*)t0)[2]);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6923,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6927,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_i_car(((C_word*)t0)[2]);
/* expand.scm:687: symbol->string */
t7=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6938,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6942,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6944,a[2]=t7,a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_6944(t9,t5,((C_word*)t0)[2]);}}

/* k11149 in k11074 in k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_11151(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_11151,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1195: r */
t3=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[77];
((C_proc)C_fast_retrieve_proc(t3))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_u_i_length(((C_word*)t0)[2]);
t4=C_eqp(t3,C_fix(4));
if(C_truep(t4)){
t5=C_i_caddr(((C_word*)t0)[2]);
/* expand.scm:1201: c */
t6=((C_word*)t0)[7];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t6))(4,av2);}}
else{
t5=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_11191(2,av2);}}}}

/* k11152 in k11149 in k11074 in k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_ccall f_11154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,3))){C_save_and_reclaim((void *)f_11154,2,av);}
a=C_alloc(21);
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=C_a_i_list(&a,2,t2,t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=C_i_caddr(((C_word*)t0)[2]);
t8=C_a_i_list(&a,2,t7,t2);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11173,a[2]=t2,a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1199: expand */
t11=((C_word*)((C_word*)t0)[4])[1];
f_11021(t11,t10,((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k11940 in a11937 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11942(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_11942,2,av);}
a=C_alloc(3);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[72],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k9830 in k9667 in a9661 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in ... */
static void C_ccall f_9832(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_9832,2,av);}
t2=C_i_caddr(((C_word*)t0)[2]);
/* expand.scm:1452: c */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=t1;
av2[3]=t2;
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}

/* k4225 in k4200 in k4197 in extend-macro-environment in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4227(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4227,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5833(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_5833,4,t0,t1,t2,t3);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5852,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,a[6]=t5,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t5))){
t7=C_u_i_car(t5);
if(C_truep(C_i_symbolp(t7))){
t8=f_5755(((C_word*)((C_word*)t0)[4])[1],lf[100],t7);
t9=t6;
f_5852(t9,(C_truep(t8)?t8:f_5755(((C_word*)((C_word*)t0)[4])[1],lf[102],t7)));}
else{
t8=t6;
f_5852(t8,C_SCHEME_FALSE);}}
else{
t7=t6;
f_5852(t7,C_SCHEME_FALSE);}}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[103],((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6921 in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6923(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6923,2,av);}
/* expand.scm:684: outstr */
t2=((C_word*)t0)[2];
f_6831(t2,((C_word*)t0)[3],t1);}

/* k6925 in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6927(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6927,2,av);}
/* expand.scm:685: string-append */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[128];
av2[3]=t1;
av2[4]=lf[129];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3703 in k3700 in macro-alias in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_3705(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_3705,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:91: gensym */
t3=*((C_word*)lf[8]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* g2749 in k9473 in fixup-macro-environment in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in ... */
static void C_fcall f_9476(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_9476,3,t0,t1,t2);}
a=C_alloc(4);
t3=C_i_cdr(t2);
if(C_truep(C_i_pairp(t3))){
t4=t2;
t5=C_u_i_cdr(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9492,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cadr(t2);
if(C_truep(C_i_nullp(t7))){
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=C_i_set_car(t5,((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=t2;
t9=C_u_i_cdr(t8);
t10=C_u_i_car(t9);
/* expand.scm:1553: ##sys#append */
t11=*((C_word*)lf[70]+1);{
C_word av2[4];
av2[0]=t11;
av2[1]=t6;
av2[2]=t10;
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k9473 in fixup-macro-environment in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in ... */
static void C_ccall f_9475(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_9475,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9476,a[2]=t2,a[3]=((C_word)li129),tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
t5=C_i_check_list_2(t4,lf[14]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9517,a[2]=t8,a[3]=t3,a[4]=((C_word)li130),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_9517(t10,t6,t4);}

/* k3706 in k3703 in k3700 in macro-alias in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_3708(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,1))){C_save_and_reclaim((void *)f_3708,2,av);}
a=C_alloc(16);
t2=f_3678(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
t4=((C_word*)t0)[2];
t5=C_i_getprop(t4,lf[7],C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_a_i_putprop(&a,3,t1,lf[5],t3);
t7=C_a_i_putprop(&a,3,t1,lf[7],t5);
t8=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t6=((C_word*)t0)[2];
t7=C_a_i_putprop(&a,3,t1,lf[5],t3);
t8=C_a_i_putprop(&a,3,t1,lf[7],t6);
t9=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}

/* k3700 in macro-alias in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_3702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3702,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_3705(t3,t1);}
else{
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_block_size(t3);
if(C_truep(C_fixnum_greaterp(t4,C_fix(0)))){
t5=C_subchar(t3,C_fix(0));
t6=t2;
f_3705(t6,C_i_char_equalp(C_make_character(35),t5));}
else{
t5=t2;
f_3705(t5,C_SCHEME_FALSE);}}}

/* a11954 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11955(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(0,c,9))){C_save_and_reclaim((void *)f_11955,5,av);}
t5=*((C_word*)lf[354]+1);
/* expand.scm:948: g1685 */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[354]+1));
C_word *av2;
if(c >= 10) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(10);
}
av2[0]=*((C_word*)lf[354]+1);
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
av2[5]=*((C_word*)lf[1]+1);
av2[6]=*((C_word*)lf[19]+1);
av2[7]=C_SCHEME_FALSE;
av2[8]=C_SCHEME_TRUE;
av2[9]=lf[353];
tp(10,av2);}}

/* k11951 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11953,2,av);}
/* expand.scm:945: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[353];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* ##sys#fixup-macro-environment in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in ... */
static void C_ccall f_9468(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +4,c,3))){
C_save_and_reclaim((void*)f_9468,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+4);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9475,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
/* expand.scm:1545: ##sys#append */
t7=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t7=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t2;
f_9475(2,av2);}}}

/* k6893 in k6884 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6895(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_6895,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:678: outstr */
t3=((C_word*)t0)[3];
f_6831(t3,t2,lf[136]);}

/* k6896 in k6893 in k6884 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6898(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_6898,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:679: ##sys#print */
t3=*((C_word*)lf[123]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k9838 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_ccall f_9840(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9840,2,av);}
/* expand.scm:1438: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[261];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a9841 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_ccall f_9842(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_9842,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9850,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1443: r */
t6=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[244];
((C_proc)C_fast_retrieve_proc(t6))(3,av2);}}

/* ##sys#expand-curried-define in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6696(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(13,c,4))){C_save_and_reclaim((void *)f_6696,5,av);}
a=C_alloc(13);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6699,a[2]=t6,a[3]=t8,a[4]=((C_word)li73),tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6743,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:636: loop */
t11=((C_word*)t8)[1];
f_6699(t11,t10,t2,t3);}

/* k6692 in match-expression in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6694,2,av);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[2])[1];
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5821(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,4))){
C_save_and_reclaim_args((void *)trf_5821,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(14);
t6=C_i_nullp(t2);
t7=(C_truep(t6)?C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5833,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word)li57),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_5833(t11,t1,t5,C_SCHEME_END_OF_LIST);}
else{
t8=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t9=t8;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=((C_word*)t10)[1];
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5925,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t10,a[8]=t11,tmp=(C_word)a,a+=9,tmp);
/* expand.scm:506: reverse */
t13=*((C_word*)lf[69]+1);{
C_word av2[3];
av2[0]=t13;
av2[1]=t12;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t13+1)))(3,av2);}}}

/* k3662 */
static void C_ccall f_3664(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3664,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[0]+1 /* (set! ##sys#features ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3668,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:73: make-parameter */
t4=*((C_word*)lf[234]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a11964 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(0,c,9))){C_save_and_reclaim((void *)f_11965,5,av);}
t5=*((C_word*)lf[354]+1);
/* expand.scm:941: g1671 */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[354]+1));
C_word *av2;
if(c >= 10) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(10);
}
av2[0]=*((C_word*)lf[354]+1);
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
av2[5]=*((C_word*)lf[2]+1);
av2[6]=*((C_word*)lf[233]+1);
av2[7]=C_SCHEME_TRUE;
av2[8]=C_SCHEME_FALSE;
av2[9]=lf[355];
tp(10,av2);}}

/* k11171 in k11152 in k11149 in k11074 in k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_ccall f_11173(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,1))){C_save_and_reclaim((void *)f_11173,2,av);}
a=C_alloc(21);
t2=C_a_i_list(&a,4,lf[293],((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[50],((C_word*)t0)[5],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8118 in loop in check-for-multiple-bindings in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_8120(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,4))){
C_save_and_reclaim_args((void *)trf_8120,2,t0,t1);}
a=C_alloc(12);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8140,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1054: string-append */
t4=*((C_word*)lf[36]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[188];
av2[3]=((C_word*)t0)[8];
av2[4]=lf[189];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_i_caar(((C_word*)t0)[2]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
/* expand.scm:1058: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8107(t6,((C_word*)t0)[5],t3,t5,((C_word*)t0)[3]);}}

/* k8121 in k8118 in loop in check-for-multiple-bindings in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_8123(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_8123,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_i_caar(((C_word*)t0)[2]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
/* expand.scm:1057: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8107(t6,((C_word*)t0)[5],t3,((C_word*)t0)[6],t5);}

/* k11961 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11963(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11963,2,av);}
/* expand.scm:938: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[355];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3666 in k3662 */
static void C_ccall f_3668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3668,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[1]+1 /* (set! ##sys#current-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3672,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:74: make-parameter */
t4=*((C_word*)lf[234]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5331 in k5284 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5333(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_5333,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t3)){
t4=t2;
f_5336(t4,C_SCHEME_UNDEFINED);}
else{
t4=C_i_car(((C_word*)t0)[2]);
t5=C_mutate2(((C_word *)((C_word*)t0)[8])+1,t4);
t6=t2;
f_5336(t6,t5);}}
else{
/* expand.scm:409: err */
t2=((C_word*)t0)[9];
f_4952(t2,((C_word*)t0)[5],lf[78]);}}

/* k5334 in k5331 in k5284 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5336(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,6))){
C_save_and_reclaim_args((void *)trf_5336,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=C_u_i_cdr(((C_word*)t0)[2]);
/* expand.scm:408: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4983(t5,((C_word*)t0)[5],C_fix(2),((C_word*)t0)[6],((C_word*)t0)[7],C_SCHEME_END_OF_LIST,t4);}

/* k9848 in a9841 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static void C_ccall f_9850(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_9850,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1443: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[262];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* loop in expand-curried-define in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6699(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_6699,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=C_i_car(t2);
if(C_truep(C_i_symbolp(t4))){
t5=t2;
t6=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_u_i_car(t5));
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_a_i_cons(&a,2,t8,t3);
t10=t1;{
C_word av2[2];
av2[0]=t10;
av2[1]=C_a_i_cons(&a,2,lf[72],t9);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t5=t2;
t6=C_u_i_car(t5);
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_a_i_cons(&a,2,t8,t3);
t10=C_a_i_cons(&a,2,lf[72],t9);
t11=C_a_i_list(&a,1,t10);
/* expand.scm:635: loop */
t13=t1;
t14=t6;
t15=t11;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}

/* k6940 in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6942(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6942,2,av);}
/* expand.scm:690: string-append */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[130];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k9490 in g2749 in k9473 in fixup-macro-environment in k8240 in k8237 in k8234 in k8231 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in ... */
static void C_ccall f_9492(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_9492,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_set_car(((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6002 in k5976 in map-loop1079 in k5964 in k5961 in k5958 in k5932 in k5926 in k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6004(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_6004,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=C_slot(((C_word*)t0)[4],C_fix(1));
t7=C_slot(((C_word*)t0)[5],C_fix(1));
t8=((C_word*)((C_word*)t0)[6])[1];
f_5971(t8,((C_word*)t0)[7],t5,t6,t7);}

/* k5850 in loop in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5852(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_5852,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5859,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5863,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:495: reverse */
t4=*((C_word*)lf[69]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[4];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
/* expand.scm:496: loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_5833(t5,((C_word*)t0)[2],t3,t4);}}

/* a11974 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11975(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(0,c,9))){C_save_and_reclaim((void *)f_11975,5,av);}
t5=*((C_word*)lf[354]+1);
/* expand.scm:935: g1657 */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[354]+1));
C_word *av2;
if(c >= 10) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(10);
}
av2[0]=*((C_word*)lf[354]+1);
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
av2[5]=*((C_word*)lf[1]+1);
av2[6]=*((C_word*)lf[19]+1);
av2[7]=C_SCHEME_FALSE;
av2[8]=C_SCHEME_FALSE;
av2[9]=lf[356];
tp(10,av2);}}

/* loop in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6944(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_6944,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[131];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6958,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* expand.scm:696: symbol->string */
t5=*((C_word*)lf[44]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k11971 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11973(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11973,2,av);}
/* expand.scm:932: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[356];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k8379 */
static void C_ccall f_8381(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_8381,2,av);}
a=C_alloc(15);
t2=C_a_i_list(&a,2,lf[45],((C_word*)((C_word*)t0)[2])[1]);
t3=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=C_a_i_list(&a,1,t3);
/* synrules.scm:61: ##sys#append */
t5=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[4];
av2[2]=t1;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k6956 in loop in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6958(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6958,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6962,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:697: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6944(t6,t3,t5);}

/* k5196 in g800 in k4995 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5198(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5198,2,av);}
t2=C_slot(t1,C_fix(1));
/* expand.scm:342: string->keyword */
t3=*((C_word*)lf[74]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k11678 in k11675 in k11664 in k11661 in a11647 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11680(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_11680,2,av);}
a=C_alloc(9);
t2=C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[336],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5192 in g800 in k4995 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5194(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(30,c,1))){C_save_and_reclaim((void *)f_5194,2,av);}
a=C_alloc(30);
t2=C_a_i_list(&a,2,lf[71],t1);
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_truep(t3)?t3:((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
if(C_truep(C_i_pairp(t6))){
t7=((C_word*)t0)[4];
t8=C_u_i_cdr(t7);
t9=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t8);
t10=C_a_i_cons(&a,2,lf[72],t9);
t11=C_a_i_list(&a,1,t10);
t12=C_a_i_cons(&a,2,t4,t11);
t13=C_a_i_cons(&a,2,t2,t12);
t14=C_a_i_cons(&a,2,lf[73],t13);
t15=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_a_i_list(&a,2,((C_word*)t0)[6],t14);
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t7=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,t2,t7);
t9=C_a_i_cons(&a,2,lf[73],t8);
t10=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=C_a_i_list(&a,2,((C_word*)t0)[6],t9);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}}

/* k6960 in k6956 in loop in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6962(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_6962,2,av);}
/* expand.scm:695: string-append */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[132];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[133];
av2[5]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k8369 */
static void C_ccall f_8371(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,1))){C_save_and_reclaim((void *)f_8371,2,av);}
a=C_alloc(27);
t2=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t1);
t3=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4],t2);
t4=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[6],t3);
t5=((C_word*)t0)[7];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_list(&a,2,lf[23],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* map-loop418 in k3917 in k3892 in extend-se in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_3936(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_3936,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k11609 in k11606 in a11595 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11611(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11611,2,av);}
t2=C_i_caddr(((C_word*)t0)[2]);
/* expand.scm:1067: check-for-multiple-bindings */
f_8101(((C_word*)t0)[3],t2,((C_word*)t0)[2],lf[332]);}

/* k3932 in k3917 in k3892 in extend-se in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_3934(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3934,2,av);}
/* expand.scm:136: append */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6855 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6857,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:668: outstr */
t3=((C_word*)t0)[2];
f_6831(t3,t2,lf[127]);}

/* k11664 in k11661 in a11647 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11666(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_11666,2,av);}
a=C_alloc(12);
t2=C_i_getprop(((C_word*)t0)[2],lf[5],C_SCHEME_FALSE);
t3=(C_truep(t2)?t2:((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11677,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11701,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1032: ##sys#current-module */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[242]+1));
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[242]+1);
av2[1]=t6;
tp(2,av2);}}

/* a11920 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11921(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11921,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11925,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:967: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[209];
av2[3]=t2;
av2[4]=lf[351];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k11923 in a11920 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11925(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_11925,2,av);}
a=C_alloc(6);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[71],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k11661 in a11647 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11663(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_11663,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1030: ##sys#check-syntax */
t3=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[101];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[341];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6858 in k6855 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_6860,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:669: ##sys#print */
t3=*((C_word*)lf[123]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6867 in k6864 in k6861 in k6858 in k6855 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6869(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6869,2,av);}
/* expand.scm:672: outstr */
t2=((C_word*)t0)[2];
f_6831(t2,((C_word*)t0)[3],lf[125]);}

/* k6864 in k6861 in k6858 in k6855 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6866(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_6866,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6876,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(*((C_word*)lf[118]+1));
/* expand.scm:671: ##sys#strip-syntax */
t5=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6861 in k6858 in k6855 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_6863,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:670: outstr */
t3=((C_word*)t0)[2];
f_6831(t3,t2,lf[126]);}

/* k11934 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11936(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11936,2,av);}
/* expand.scm:954: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[222];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a11937 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11938(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11938,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11942,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* expand.scm:959: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[222];
av2[3]=t2;
av2[4]=lf[352];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3917 in k3892 in extend-se in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_3919(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,4))){C_save_and_reclaim((void *)f_3919,2,av);}
a=C_alloc(17);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=((C_word*)t0)[2];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3936,a[2]=t4,a[3]=t9,a[4]=t5,a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_3936(t11,t7,t6,((C_word*)t0)[5]);}

/* k11675 in k11664 in k11661 in a11647 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11677(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,2))){C_save_and_reclaim((void *)f_11677,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11690,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11697,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1033: r */
t5=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[101];
((C_proc)C_fast_retrieve_proc(t5))(3,av2);}}

/* k6874 in k6864 in k6861 in k6858 in k6855 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6876(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6876,2,av);}
/* expand.scm:671: ##sys#print */
t2=*((C_word*)lf[123]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k9015 in k9012 in k9009 in k8997 in k8991 in k8988 */
static void C_ccall f_9017(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_9017,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9038,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* synrules.scm:231: segment-tail */
t4=((C_word*)((C_word*)t0)[6])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[7];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k9816 in k9673 in k9667 in a9661 in k8228 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in ... */
static void C_ccall f_9818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_9818,2,av);}
/* expand.scm:1492: ##sys#validate-exports */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[243]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[243]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[248];
tp(4,av2);}}

/* k9012 in k9009 in k8997 in k8991 in k8988 */
static void C_fcall f_9014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,4))){
C_save_and_reclaim_args((void *)trf_9014,2,t0,t1);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9040,a[2]=t4,a[3]=((C_word)li117),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9040(t6,t2,((C_word*)t0)[8],t1);}

/* k9028 in k9036 in k9015 in k9012 in k9009 in k8997 in k8991 in k8988 */
static void C_ccall f_9030(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_9030,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[70],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6883(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_6883,2,av);}
a=C_alloc(16);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6773,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6817,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:655: ##sys#strip-syntax */
t7=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k6884 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6886(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_6886,2,av);}
a=C_alloc(8);
t2=t1;
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6895,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:677: outstr */
t4=((C_word*)t0)[2];
f_6831(t4,t3,((C_word*)t0)[7]);}
else{
t3=((C_word*)t0)[8];
t4=C_u_i_cdr(t3);
/* expand.scm:698: loop */
t5=((C_word*)((C_word*)t0)[9])[1];
f_6847(t5,((C_word*)t0)[3],t4);}}

/* k7672 in compare in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7674(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7674,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:845: compare */
t6=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=((C_word*)t0)[5];
av2[2]=t3;
av2[3]=t5;
f_7652(4,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* doloop2604 in k9012 in k9009 in k8997 in k8991 in k8988 */
static void C_fcall f_9040(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_9040,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=t2;
t5=C_eqp(t4,C_fix(1));
if(C_truep(t5)){
t6=t3;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=C_fixnum_difference(t2,C_fix(1));
t7=C_a_i_list(&a,3,lf[214],lf[70],t3);
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* k6815 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6817(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6817,2,av);}
/* expand.scm:655: ##sys#get */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[138]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[138]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[139];
tp(4,av2);}}

/* k9036 in k9015 in k9012 in k9009 in k8997 in k8991 in k8988 */
static void C_ccall f_9038(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_9038,2,av);}
a=C_alloc(10);
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9034,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* synrules.scm:233: segment-tail */
t4=((C_word*)((C_word*)t0)[7])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[8];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}}

/* k9032 in k9036 in k9015 in k9012 in k9009 in k8997 in k8991 in k8988 */
static void C_ccall f_9034(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9034,2,av);}
/* synrules.scm:233: process-template */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
((C_proc)C_fast_retrieve_proc(t2))(5,av2);}}

/* k6936 in k6908 in k6905 in k6902 in k6899 in k6896 in k6893 in k6884 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6938(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6938,2,av);}
/* expand.scm:689: outstr */
t2=((C_word*)t0)[2];
f_6831(t2,((C_word*)t0)[3],t1);}

/* for-each-loop381 in k3892 in extend-se in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_3984(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_3984,4,t0,t1,t2,t3);}
a=C_alloc(8);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_i_getprop(t7,lf[7],C_SCHEME_FALSE);
t9=(C_truep(t8)?C_a_i_putprop(&a,3,t6,lf[7],t8):C_a_i_putprop(&a,3,t6,lf[7],t7));
t10=C_slot(t2,C_fix(1));
t11=C_slot(t3,C_fix(1));
t13=t1;
t14=t10;
t15=t11;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k11371 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in ... */
static void C_ccall f_11373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11373,2,av);}
/* expand.scm:1135: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[220];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a11374 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in ... */
static void C_ccall f_11375(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_11375,5,av);}
a=C_alloc(6);
t5=C_i_cdr(t2);
if(C_truep(C_i_nullp(t5))){
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_i_cdr(t5);
t7=t6;
t8=C_u_i_car(t5);
if(C_truep(C_i_nullp(t7))){
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11398,a[2]=t8,a[3]=t7,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1147: r */
t10=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[77];
((C_proc)C_fast_retrieve_proc(t10))(3,av2);}}}}

/* compare in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7652(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_7652,4,av);}
a=C_alloc(10);
if(C_truep(C_i_pairp(t2))){
if(C_truep(C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7674,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=t2;
t6=C_u_i_car(t5);
t7=t3;
t8=C_u_i_car(t7);
/* expand.scm:844: compare */
t14=t4;
t15=t6;
t16=t8;
t1=t14;
t2=t15;
t3=t16;
c=4;
goto loop;}
else{
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
if(C_truep(C_i_vectorp(t2))){
if(C_truep(C_i_vectorp(t3))){
t4=t2;
t5=C_block_size(t4);
t6=t5;
t7=t3;
t8=C_block_size(t7);
t9=C_eqp(t6,t8);
if(C_truep(t9)){
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7711,a[2]=t6,a[3]=t11,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=((C_word)li96),tmp=(C_word)a,a+=8,tmp));
t13=((C_word*)t11)[1];
f_7711(t13,t1,C_fix(0),C_SCHEME_TRUE);}
else{
t10=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}}
else{
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t4=C_i_symbolp(t2);
t5=(C_truep(t4)?C_i_symbolp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t2;
t7=C_i_getprop(t6,lf[5],C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7763,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t7)){
t9=t8;
f_7763(t9,t7);}
else{
t9=t2;
t10=((C_word*)t0)[3];
t11=f_3678(t9,t10);
if(C_truep(t11)){
t12=t8;
f_7763(t12,t11);}
else{
t12=t2;
t13=t8;
f_7763(t13,t12);}}}
else{
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_eqp(t2,t3);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}}

/* k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6829(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_6829,2,av);}
a=C_alloc(18);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6831,a[2]=t2,a[3]=((C_word)li76),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6838,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6847,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word)li79),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_6847(t8,t4,*((C_word*)lf[118]+1));}

/* k3847 in walk in strip-syntax in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_3849(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_3849,2,av);}
a=C_alloc(16);
t2=t1;
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],t2);
t4=C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3858,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word)li2),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_3858(t9,((C_word*)t0)[6],C_fix(0));}

/* k9059 in k9009 in k8997 in k8991 in k8988 */
static void C_fcall f_9061(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,1))){
C_save_and_reclaim_args((void *)trf_9061,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_9014(t2,((C_word*)t0)[3]);}
else{
t2=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[5]);
t4=((C_word*)t0)[2];
f_9014(t4,C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t3));}}

/* outstr in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6831(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_6831,3,t0,t1,t2);}
/* expand.scm:664: ##sys#print */
t3=*((C_word*)lf[123]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6836 in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6838(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6838,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6845,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* expand.scm:699: get-output-string */
t3=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k9864 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_ccall f_9866(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9866,2,av);}
/* expand.scm:1430: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[262];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k9856 in k9848 in a9841 in k8225 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in ... */
static void C_ccall f_9858(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_9858,2,av);}
a=C_alloc(9);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k11396 in a11374 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in ... */
static void C_ccall f_11398(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_11398,2,av);}
a=C_alloc(15);
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11417,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* expand.scm:1149: r */
t7=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[220];
((C_proc)C_fast_retrieve_proc(t7))(3,av2);}}

/* k7633 in rename in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7635(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_7635,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6847(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_6847,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6857,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* expand.scm:667: outstr */
t4=((C_word*)t0)[2];
f_6831(t4,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6883,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t4=C_i_car(t2);
/* expand.scm:674: ##sys#strip-syntax */
t5=*((C_word*)lf[12]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k6843 in k6836 in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6845,2,av);}
/* expand.scm:699: ##sys#syntax-error-hook */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a9867 in k8222 in k8219 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_ccall f_9868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_9868,5,av);}
a=C_alloc(9);
t5=C_i_cdr(t2);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,lf[263],t5,C_SCHEME_TRUE);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k11688 in k11675 in k11664 in k11661 in a11647 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11690(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_11690,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
/* expand.scm:1034: ##sys#defjam-error */
t2=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_i_car(((C_word*)t0)[4]);
t3=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[336],((C_word*)t0)[6],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11695 in k11675 in k11664 in k11661 in a11647 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_11697(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_11697,2,av);}
/* expand.scm:1033: c */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
((C_proc)C_fast_retrieve_proc(t2))(4,av2);}}

/* map-loop1031 in k5926 in k5923 in fini in k5742 in canonicalize-body in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_6033(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_6033,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,2,t3,lf[104]);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9009 in k8997 in k8991 in k8988 */
static void C_ccall f_9011(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_9011,2,av);}
a=C_alloc(16);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9061,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[10]))){
t5=C_u_i_cdr(((C_word*)t0)[10]);
if(C_truep(C_i_nullp(t5))){
if(C_truep(C_i_symbolp(t2))){
t6=C_u_i_car(((C_word*)t0)[10]);
t7=t4;
f_9061(t7,C_eqp(t2,t6));}
else{
t6=t4;
f_9061(t6,C_SCHEME_FALSE);}}
else{
t6=t4;
f_9061(t6,C_SCHEME_FALSE);}}
else{
t5=t4;
f_9061(t5,C_SCHEME_FALSE);}}

/* k7616 in g1458 in rename in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7618(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_7618,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k6669 in mwalk in match-expression in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6671,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* expand.scm:621: mwalk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6617(t6,((C_word*)t0)[5],t3,t5);}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6800 in k6796 in loop in k6771 in k6881 in loop in k6827 in syntax-error/context in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_6802(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_6802,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3822 in k3829 in walk in strip-syntax in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_3824(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3824,2,av);}
t2=C_i_setslot(((C_word*)t0)[2],C_fix(1),t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k3829 in walk in strip-syntax in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_3831(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3831,2,av);}
a=C_alloc(5);
t2=C_i_setslot(((C_word*)t0)[2],C_fix(0),t1);
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3824,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[5];
t6=C_u_i_cdr(t5);
/* expand.scm:117: walk */
t7=((C_word*)((C_word*)t0)[6])[1];
f_3759(t7,t4,t6);}

/* k7730 in doloop1511 in compare in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7732(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7732,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
f_7711(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k7761 in compare in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_7763(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_7763,2,t0,t1);}
a=C_alloc(4);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_i_getprop(t3,lf[5],C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7771,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_7771(t6,t4);}
else{
t6=((C_word*)t0)[2];
t7=((C_word*)t0)[4];
t8=f_3678(t6,t7);
if(C_truep(t8)){
t9=t5;
f_7771(t9,t8);}
else{
t9=((C_word*)t0)[2];
t10=t5;
f_7771(t10,t9);}}}

/* doloop1511 in compare in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_7711(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_7711,4,t0,t1,t2,t3);}
a=C_alloc(5);
t4=C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
t5=(C_truep(t4)?t4:C_i_not(t3));
if(C_truep(t5)){
t6=t3;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=C_fixnum_plus(t2,C_fix(1));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7732,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=C_i_vector_ref(((C_word*)t0)[4],t2);
t10=C_i_vector_ref(((C_word*)t0)[5],t2);
/* expand.scm:851: compare */
t11=((C_word*)((C_word*)t0)[6])[1];{
C_word av2[4];
av2[0]=t11;
av2[1]=t8;
av2[2]=t9;
av2[3]=t10;
f_7652(4,av2);}}}

/* k10901 in k10949 in k10846 in k10827 in expand in k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in ... */
static void C_ccall f_10903(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_10903,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10896(t3,C_a_i_list(&a,2,t2,((C_word*)t0)[4]));}
else{
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_10896(t3,C_a_i_cons(&a,2,lf[103],t2));}}

/* k10898 in k10894 in k10949 in k10846 in k10827 in expand in k10800 in k10797 in k10794 in k10791 in k10788 in k10780 in a10777 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in ... */
static void C_ccall f_10900(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_10900,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,4,lf[293],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* f_9143 in k8333 in k8328 in k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in ... */
static void C_ccall f_9143(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_9143,6,av);}
a=C_alloc(7);
if(C_truep(C_i_symbolp(t2))){
if(C_truep(C_i_memq(t2,((C_word*)t0)[2]))){
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_a_i_cons(&a,2,t2,t3);
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_cons(&a,2,t6,t4);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9169,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* synrules.scm:251: segment-pattern? */
t7=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=t5;
((C_proc)C_fast_retrieve_proc(t7))(4,av2);}}}

/* k7769 in k7761 in compare in k7494 in a7488 in make-er/ir-transformer in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_7771(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_7771,2,t0,t1);}
a=C_alloc(5);
t2=t1;
if(C_truep(C_i_symbolp(((C_word*)t0)[2]))){
if(C_truep(C_i_symbolp(t2))){
t3=C_i_getprop(((C_word*)t0)[2],lf[180],C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:((C_word*)t0)[2]);
t5=C_i_getprop(t2,lf[180],C_SCHEME_FALSE);
t6=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(t5)?C_eqp(t4,t5):C_eqp(t4,t2));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7826,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:864: ##sys#macro-environment */
t4=*((C_word*)lf[19]+1);{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
if(C_truep(C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7854,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* expand.scm:868: ##sys#macro-environment */
t4=*((C_word*)lf[19]+1);{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=C_eqp(((C_word*)t0)[2],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}}

/* k9115 in k9111 in k8988 */
static void C_ccall f_9117(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_9117,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9111 in k8988 */
static void C_ccall f_9113(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_9113,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
t5=C_u_i_cdr(t4);
/* synrules.scm:237: process-template */
t6=((C_word*)((C_word*)t0)[5])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
av2[3]=((C_word*)t0)[6];
av2[4]=((C_word*)t0)[7];
((C_proc)C_fast_retrieve_proc(t6))(5,av2);}}

/* k11415 in k11396 in a11374 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in ... */
static void C_ccall f_11417(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,1))){C_save_and_reclaim((void *)f_11417,2,av);}
a=C_alloc(24);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,4,lf[293],((C_word*)t0)[3],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[50],((C_word*)t0)[5],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a11426 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in ... */
static void C_ccall f_11427(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_11427,5,av);}
a=C_alloc(5);
t5=C_i_cdr(t2);
if(C_truep(C_i_nullp(t5))){
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_i_cdr(t5);
t7=t6;
t8=C_u_i_car(t5);
if(C_truep(C_i_nullp(t7))){
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11458,a[2]=t7,a[3]=t1,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1133: r */
t10=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[229];
((C_proc)C_fast_retrieve_proc(t10))(3,av2);}}}}

/* k11423 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in k8067 in k8064 in k4152 in k3674 in k3670 in k3666 in ... */
static void C_ccall f_11425(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11425,2,av);}
/* expand.scm:1121: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[229];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k11219 in k11192 in k11189 in k11149 in k11074 in k11071 in k11033 in expand in k11014 in k11011 in k11008 in a11002 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in ... */
static void C_ccall f_11221(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(30,c,1))){C_save_and_reclaim((void *)f_11221,2,av);}
a=C_alloc(30);
t2=C_a_i_list(&a,4,lf[310],((C_word*)t0)[2],((C_word*)t0)[3],t1);
t3=C_a_i_list(&a,3,lf[72],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[92],((C_word*)t0)[6],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a7372 in walk in k7169 in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_7373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_7373,3,av);}
t3=(C_truep(C_i_symbolp(t2))?f_3678(t2,((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(C_i_symbolp(t3))){
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_eqp(t3,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=t2;
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_eqp(t4,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k9136 in k8988 */
static void C_ccall f_9138(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9138,2,av);}
/* synrules.scm:240: process-template */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
((C_proc)C_fast_retrieve_proc(t2))(5,av2);}}

/* k9132 in k8988 */
static void C_ccall f_9134(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_9134,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[3])[1],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10216 in k10209 in a10206 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in ... */
static void C_ccall f_10218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(30,c,1))){C_save_and_reclaim((void *)f_10218,2,av);}
a=C_alloc(30);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,lf[72],C_SCHEME_END_OF_LIST,t2);
t4=C_a_i_list(&a,3,lf[92],t3,lf[275]);
t5=C_a_i_list(&a,2,lf[272],t4);
t6=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_list(&a,2,t1,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k10209 in a10206 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in ... */
static void C_ccall f_10211(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_10211,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10218,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* expand.scm:1356: r */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[271];
((C_proc)C_fast_retrieve_proc(t3))(3,av2);}}

/* k10203 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in ... */
static void C_ccall f_10205(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10205,2,av);}
/* expand.scm:1350: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[274];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a10206 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in ... */
static void C_ccall f_10207(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10207,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10211,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* expand.scm:1355: ##sys#check-syntax */
t6=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[274];
av2[3]=t2;
av2[4]=lf[276];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10236 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in k8080 in k8077 in k8074 in k8070 in ... */
static void C_ccall f_10238(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10238,2,av);}
/* expand.scm:1298: ##sys#extend-macro-environment */
t2=*((C_word*)lf[27]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[277];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g800 in k4995 in loop in k4976 in k4973 in k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_5141(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,2))){
C_save_and_reclaim_args((void *)trf_5141,3,t0,t1,t2);}
a=C_alloc(10);
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5198,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* expand.scm:365: ##sys#strip-syntax */
t7=*((C_word*)lf[12]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in ... */
static void C_ccall f_9904(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_9904,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1376: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[226];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in k8086 in k8083 in ... */
static void C_ccall f_9901(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_9901,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9904,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* expand.scm:1375: r */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[270];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in k8097 in k8093 in k8089 in ... */
static void C_ccall f_9907(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_9907,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* expand.scm:1377: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[229];
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k9953 in test in k9908 in k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in ... */
static void C_ccall f_9955(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_9955,2,av);}
a=C_alloc(11);
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=C_u_i_car(((C_word*)t0)[2]);
/* expand.scm:1391: test */
t5=((C_word*)((C_word*)t0)[5])[1];
f_9922(t5,t3,t4);}
else{
/* expand.scm:1393: err */
t3=((C_word*)((C_word*)t0)[6])[1];
f_9912(t3,((C_word*)t0)[3],((C_word*)t0)[7]);}}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* expand.scm:1394: c */
t3=((C_word*)t0)[9];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)t0)[11];
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}}

/* k5591 in k5572 in k5569 in a5566 in expand-multiple-values-assignment in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5593(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,4))){C_save_and_reclaim((void *)f_5593,2,av);}
a=C_alloc(24);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5597,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=((C_word*)t0)[4];
t9=C_i_check_list_2(t8,lf[16]);
t10=C_i_check_list_2(((C_word*)t0)[5],lf[16]);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5615,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5637,a[2]=t6,a[3]=t13,a[4]=t7,a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_5637(t15,t11,t8,((C_word*)t0)[5]);}

/* k5595 in k5591 in k5572 in k5569 in a5566 in expand-multiple-values-assignment in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_5597(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,1))){C_save_and_reclaim((void *)f_5597,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[72],t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[92],((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k9934 in test in k9908 in k9905 in k9902 in k9899 in a9893 in k8216 in k8213 in k8210 in k8207 in k8204 in k8201 in k8198 in k8195 in k8192 in k8189 in k8186 in k8183 in k8180 in k8177 in k8174 in ... */
static void C_ccall f_9936(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9936,2,av);}
/* expand.scm:1383: ##sys#feature? */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[267]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[267]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* err in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4952(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_4952,3,t0,t1,t2);}
/* expand.scm:341: errh */
t3=((C_word*)t0)[2];{
C_word av2[4];
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t3))(4,av2);}}

/* k8686 */
static void C_ccall f_8688(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
if(!C_demand(C_calculate_demand(75,c,4))){C_save_and_reclaim((void *)f_8688,2,av);}
a=C_alloc(75);
t2=t1;
t3=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);
t4=t3;
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);
t6=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[5])[1],t5);
t7=C_a_i_list(&a,1,t6);
t8=t7;
t9=C_i_cddr(((C_word*)t0)[6]);
t10=C_i_length(t9);
t11=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[5])[1],t10);
t12=t11;
t13=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[8])[1],((C_word*)t0)[3]);
t14=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[5])[1]);
t15=C_a_i_list(&a,2,t13,t14);
t16=t15;
t17=((C_word*)t0)[6];
t18=C_u_i_cdr(t17);
t19=C_u_i_cdr(t18);
t20=C_i_length(t19);
t21=C_a_i_list(&a,3,((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[5])[1],t20);
t22=t21;
t23=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8767,a[2]=t22,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=t16,a[9]=t12,a[10]=t8,a[11]=t4,a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[5],a[17]=t2,tmp=(C_word)a,a+=18,tmp);
t24=((C_word*)t0)[6];
t25=C_u_i_cdr(t24);
t26=C_u_i_cdr(t25);
/* synrules.scm:162: process-match */
t27=((C_word*)((C_word*)t0)[18])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t27;
av2[1]=t23;
av2[2]=((C_word*)((C_word*)t0)[8])[1];
av2[3]=t26;
av2[4]=C_SCHEME_TRUE;
((C_proc)C_fast_retrieve_proc(t27))(5,av2);}}

/* f_8684 in k8333 in k8328 in k8324 in k8320 in k8316 in k8311 in k8304 in k8299 in k8295 in k8291 in k8287 in k8283 in k8279 in k8273 in k8268 in k8264 in k8249 in process-syntax-rules in k8240 in k8237 in k8234 in ... */
static void C_ccall f_8684(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(25,c,4))){C_save_and_reclaim((void *)f_8684,4,av);}
a=C_alloc(25);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8688,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=t1,a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[14],a[18]=((C_word*)t0)[15],tmp=(C_word)a,a+=19,tmp);
t5=C_a_i_list(&a,2,((C_word*)((C_word*)t0)[16])[1],((C_word*)((C_word*)t0)[6])[1]);
t6=C_i_car(t3);
/* synrules.scm:154: process-match */
t7=((C_word*)((C_word*)t0)[15])[1];{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t4;
av2[2]=t5;
av2[3]=t6;
av2[4]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t7))(5,av2);}}

/* k4716 in k4626 in k4614 in k4605 in loop in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4718(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(41,c,3))){C_save_and_reclaim((void *)f_4718,2,av);}
a=C_alloc(41);
t2=C_i_cddr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,lf[51],t3);
t5=C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=C_a_i_list(&a,1,t5);
t7=C_a_i_list(&a,3,lf[52],t6,((C_word*)t0)[3]);
t8=t7;
t9=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t11)[1];
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4653,a[2]=t8,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4655,a[2]=t11,a[3]=t15,a[4]=t12,a[5]=((C_word)li35),tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_4655(t17,t13,((C_word*)t0)[5]);}

/* k4970 in k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4972(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_4972,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4975,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* expand.scm:348: macro-alias */
f_3695(t3,lf[86],((C_word*)t0)[7]);}

/* map-loop638 in k4626 in k4614 in k4605 in loop in expand-0 in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_4724(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_4724,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4967 in expand-extended-lambda-list in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_ccall f_4969(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_4969,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* expand.scm:347: macro-alias */
f_3695(t3,lf[87],((C_word*)t0)[6]);}

/* k7193 in walk in k7169 in k7036 in check-syntax in k4152 in k3674 in k3670 in k3666 in k3662 */
static void C_fcall f_7195(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,4))){
C_save_and_reclaim_args((void *)trf_7195,2,t0,t1);}
a=C_alloc(11);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li90),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_7200(t6,((C_word*)t0)[6],((C_word*)t0)[7],C_fix(0));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[671] = {
{"f_8651:expand_2escm",(void*)f_8651},
{"f_4997:expand_2escm",(void*)f_4997},
{"f_10936:expand_2escm",(void*)f_10936},
{"f_10951:expand_2escm",(void*)f_10951},
{"f_7171:expand_2escm",(void*)f_7171},
{"f_7176:expand_2escm",(void*)f_7176},
{"f_4766:expand_2escm",(void*)f_4766},
{"f_4276:expand_2escm",(void*)f_4276},
{"f_4762:expand_2escm",(void*)f_4762},
{"f_4835:expand_2escm",(void*)f_4835},
{"f_4839:expand_2escm",(void*)f_4839},
{"f_4287:expand_2escm",(void*)f_4287},
{"f_10953:expand_2escm",(void*)f_10953},
{"f_7150:expand_2escm",(void*)f_7150},
{"f_8330:expand_2escm",(void*)f_8330},
{"f_4295:expand_2escm",(void*)f_4295},
{"f_4299:expand_2escm",(void*)f_4299},
{"f_7142:expand_2escm",(void*)f_7142},
{"f_7144:expand_2escm",(void*)f_7144},
{"f_8322:expand_2escm",(void*)f_8322},
{"f_8993:expand_2escm",(void*)f_8993},
{"f_8337:expand_2escm",(void*)f_8337},
{"f_8999:expand_2escm",(void*)f_8999},
{"f_8335:expand_2escm",(void*)f_8335},
{"f_8990:expand_2escm",(void*)f_8990},
{"f_9515:expand_2escm",(void*)f_9515},
{"f_9517:expand_2escm",(void*)f_9517},
{"f_5574:expand_2escm",(void*)f_5574},
{"f_5571:expand_2escm",(void*)f_5571},
{"f_8326:expand_2escm",(void*)f_8326},
{"f_8301:expand_2escm",(void*)f_8301},
{"f_9184:expand_2escm",(void*)f_9184},
{"f_8318:expand_2escm",(void*)f_8318},
{"f_8313:expand_2escm",(void*)f_8313},
{"f_7114:expand_2escm",(void*)f_7114},
{"f_3676:expand_2escm",(void*)f_3676},
{"f_3672:expand_2escm",(void*)f_3672},
{"f_3678:expand_2escm",(void*)f_3678},
{"f_11311:expand_2escm",(void*)f_11311},
{"f_9784:expand_2escm",(void*)f_9784},
{"f_9169:expand_2escm",(void*)f_9169},
{"f_11323:expand_2escm",(void*)f_11323},
{"f_8951:expand_2escm",(void*)f_8951},
{"f_3695:expand_2escm",(void*)f_3695},
{"f_4825:expand_2escm",(void*)f_4825},
{"f_8945:expand_2escm",(void*)f_8945},
{"f_11339:expand_2escm",(void*)f_11339},
{"f_6361:expand_2escm",(void*)f_6361},
{"f_6364:expand_2escm",(void*)f_6364},
{"f_8343:expand_2escm",(void*)f_8343},
{"f_8480:expand_2escm",(void*)f_8480},
{"f_6305:expand_2escm",(void*)f_6305},
{"f_8920:expand_2escm",(void*)f_8920},
{"f_8475:expand_2escm",(void*)f_8475},
{"f_8473:expand_2escm",(void*)f_8473},
{"f_8916:expand_2escm",(void*)f_8916},
{"f_9590:expand_2escm",(void*)f_9590},
{"f_8638:expand_2escm",(void*)f_8638},
{"f_8630:expand_2escm",(void*)f_8630},
{"f_4502:expand_2escm",(void*)f_4502},
{"f_4507:expand_2escm",(void*)f_4507},
{"f_4520:expand_2escm",(void*)f_4520},
{"f_6325:expand_2escm",(void*)f_6325},
{"f_9563:expand_2escm",(void*)f_9563},
{"f_6617:expand_2escm",(void*)f_6617},
{"f_9569:expand_2escm",(void*)f_9569},
{"f_9567:expand_2escm",(void*)f_9567},
{"f_6614:expand_2escm",(void*)f_6614},
{"toplevel:expand_2escm",(void*)C_expand_toplevel},
{"f_4513:expand_2escm",(void*)f_4513},
{"f_9573:expand_2escm",(void*)f_9573},
{"f_8444:expand_2escm",(void*)f_8444},
{"f_4526:expand_2escm",(void*)f_4526},
{"f_6631:expand_2escm",(void*)f_6631},
{"f_8437:expand_2escm",(void*)f_8437},
{"f_5755:expand_2escm",(void*)f_5755},
{"f_4539:expand_2escm",(void*)f_4539},
{"f_4537:expand_2escm",(void*)f_4537},
{"f_11085:expand_2escm",(void*)f_11085},
{"f_9555:expand_2escm",(void*)f_9555},
{"f_9551:expand_2escm",(void*)f_9551},
{"f_8465:expand_2escm",(void*)f_8465},
{"f_9559:expand_2escm",(void*)f_9559},
{"f_8469:expand_2escm",(void*)f_8469},
{"f_5744:expand_2escm",(void*)f_5744},
{"f_5740:expand_2escm",(void*)f_5740},
{"f_9527:expand_2escm",(void*)f_9527},
{"f_10664:expand_2escm",(void*)f_10664},
{"f_11073:expand_2escm",(void*)f_11073},
{"f_11076:expand_2escm",(void*)f_11076},
{"f_11079:expand_2escm",(void*)f_11079},
{"f_11594:expand_2escm",(void*)f_11594},
{"f_11596:expand_2escm",(void*)f_11596},
{"f_11041:expand_2escm",(void*)f_11041},
{"f_11830:expand_2escm",(void*)f_11830},
{"f_11044:expand_2escm",(void*)f_11044},
{"f_11833:expand_2escm",(void*)f_11833},
{"f_11048:expand_2escm",(void*)f_11048},
{"f_5703:expand_2escm",(void*)f_5703},
{"f_8420:expand_2escm",(void*)f_8420},
{"f_6299:expand_2escm",(void*)f_6299},
{"f_11885:expand_2escm",(void*)f_11885},
{"f_11887:expand_2escm",(void*)f_11887},
{"f_11057:expand_2escm",(void*)f_11057},
{"f_11054:expand_2escm",(void*)f_11054},
{"f_11891:expand_2escm",(void*)f_11891},
{"f_9733:expand_2escm",(void*)f_9733},
{"f_9737:expand_2escm",(void*)f_9737},
{"f_5728:expand_2escm",(void*)f_5728},
{"f_5286:expand_2escm",(void*)f_5286},
{"f_6343:expand_2escm",(void*)f_6343},
{"f_10148:expand_2escm",(void*)f_10148},
{"f_6348:expand_2escm",(void*)f_6348},
{"f_11868:expand_2escm",(void*)f_11868},
{"f_11581:expand_2escm",(void*)f_11581},
{"f_3858:expand_2escm",(void*)f_3858},
{"f_11556:expand_2escm",(void*)f_11556},
{"f_11559:expand_2escm",(void*)f_11559},
{"f_11550:expand_2escm",(void*)f_11550},
{"f_11552:expand_2escm",(void*)f_11552},
{"f_10164:expand_2escm",(void*)f_10164},
{"f_10813:expand_2escm",(void*)f_10813},
{"f_10815:expand_2escm",(void*)f_10815},
{"f_11528:expand_2escm",(void*)f_11528},
{"f_3879:expand_2escm",(void*)f_3879},
{"f_5299:expand_2escm",(void*)f_5299},
{"f_11578:expand_2escm",(void*)f_11578},
{"f_11060:expand_2escm",(void*)f_11060},
{"f_11063:expand_2escm",(void*)f_11063},
{"f_11067:expand_2escm",(void*)f_11067},
{"f_11574:expand_2escm",(void*)f_11574},
{"f_11572:expand_2escm",(void*)f_11572},
{"f_10190:expand_2escm",(void*)f_10190},
{"f_10184:expand_2escm",(void*)f_10184},
{"f_10186:expand_2escm",(void*)f_10186},
{"f_9743:expand_2escm",(void*)f_9743},
{"f_9740:expand_2escm",(void*)f_9740},
{"f_11823:expand_2escm",(void*)f_11823},
{"f_3890:expand_2escm",(void*)f_3890},
{"f_3894:expand_2escm",(void*)f_3894},
{"f_9755:expand_2escm",(void*)f_9755},
{"f_6217:expand_2escm",(void*)f_6217},
{"f_7585:expand_2escm",(void*)f_7585},
{"f_7588:expand_2escm",(void*)f_7588},
{"f_10802:expand_2escm",(void*)f_10802},
{"f_5206:expand_2escm",(void*)f_5206},
{"f_5201:expand_2escm",(void*)f_5201},
{"f_5204:expand_2escm",(void*)f_5204},
{"f_7567:expand_2escm",(void*)f_7567},
{"f_9702:expand_2escm",(void*)f_9702},
{"f_6207:expand_2escm",(void*)f_6207},
{"f_11902:expand_2escm",(void*)f_11902},
{"f_11908:expand_2escm",(void*)f_11908},
{"f_11904:expand_2escm",(void*)f_11904},
{"f_4110:expand_2escm",(void*)f_4110},
{"f_11919:expand_2escm",(void*)f_11919},
{"f_4126:expand_2escm",(void*)f_4126},
{"f_11648:expand_2escm",(void*)f_11648},
{"f_11646:expand_2escm",(void*)f_11646},
{"f_7516:expand_2escm",(void*)f_7516},
{"f_7512:expand_2escm",(void*)f_7512},
{"f_10857:expand_2escm",(void*)f_10857},
{"f_10851:expand_2escm",(void*)f_10851},
{"f_7496:expand_2escm",(void*)f_7496},
{"f_7498:expand_2escm",(void*)f_7498},
{"f_11621:expand_2escm",(void*)f_11621},
{"f_7489:expand_2escm",(void*)f_7489},
{"f_7483:expand_2escm",(void*)f_7483},
{"f_11600:expand_2escm",(void*)f_11600},
{"f_11608:expand_2escm",(void*)f_11608},
{"f_7533:expand_2escm",(void*)f_7533},
{"f_7537:expand_2escm",(void*)f_7537},
{"f_9218:expand_2escm",(void*)f_9218},
{"f_9262:expand_2escm",(void*)f_9262},
{"f_10741:expand_2escm",(void*)f_10741},
{"f_9203:expand_2escm",(void*)f_9203},
{"f_9220:expand_2escm",(void*)f_9220},
{"f_11128:expand_2escm",(void*)f_11128},
{"f_5561:expand_2escm",(void*)f_5561},
{"f_5567:expand_2escm",(void*)f_5567},
{"f_4770:expand_2escm",(void*)f_4770},
{"f_5245:expand_2escm",(void*)f_5245},
{"f_5555:expand_2escm",(void*)f_5555},
{"f_4782:expand_2escm",(void*)f_4782},
{"f_5231:expand_2escm",(void*)f_5231},
{"f_8293:expand_2escm",(void*)f_8293},
{"f_4154:expand_2escm",(void*)f_4154},
{"f_8297:expand_2escm",(void*)f_8297},
{"f_8285:expand_2escm",(void*)f_8285},
{"f_8281:expand_2escm",(void*)f_8281},
{"f_8289:expand_2escm",(void*)f_8289},
{"f_4158:expand_2escm",(void*)f_4158},
{"f_10250:expand_2escm",(void*)f_10250},
{"f_10252:expand_2escm",(void*)f_10252},
{"f_10407:expand_2escm",(void*)f_10407},
{"f_10639:expand_2escm",(void*)f_10639},
{"f_10637:expand_2escm",(void*)f_10637},
{"f_8251:expand_2escm",(void*)f_8251},
{"f_10276:expand_2escm",(void*)f_10276},
{"f_4195:expand_2escm",(void*)f_4195},
{"f_8242:expand_2escm",(void*)f_8242},
{"f_8244:expand_2escm",(void*)f_8244},
{"f_10244:expand_2escm",(void*)f_10244},
{"f_10247:expand_2escm",(void*)f_10247},
{"f_4199:expand_2escm",(void*)f_4199},
{"f_10240:expand_2escm",(void*)f_10240},
{"f_4607:expand_2escm",(void*)f_4607},
{"f_8275:expand_2escm",(void*)f_8275},
{"f_8270:expand_2escm",(void*)f_8270},
{"f_10299:expand_2escm",(void*)f_10299},
{"f_8266:expand_2escm",(void*)f_8266},
{"f_4616:expand_2escm",(void*)f_4616},
{"f_4859:expand_2escm",(void*)f_4859},
{"f_4853:expand_2escm",(void*)f_4853},
{"f_10262:expand_2escm",(void*)f_10262},
{"f_10260:expand_2escm",(void*)f_10260},
{"f_8212:expand_2escm",(void*)f_8212},
{"f_4628:expand_2escm",(void*)f_4628},
{"f_4865:expand_2escm",(void*)f_4865},
{"f_10689:expand_2escm",(void*)f_10689},
{"f_8218:expand_2escm",(void*)f_8218},
{"f_8215:expand_2escm",(void*)f_8215},
{"f_8203:expand_2escm",(void*)f_8203},
{"f_8200:expand_2escm",(void*)f_8200},
{"f_8209:expand_2escm",(void*)f_8209},
{"f_8206:expand_2escm",(void*)f_8206},
{"f_10280:expand_2escm",(void*)f_10280},
{"f_4175:expand_2escm",(void*)f_4175},
{"f_4655:expand_2escm",(void*)f_4655},
{"f_4653:expand_2escm",(void*)f_4653},
{"f_5462:expand_2escm",(void*)f_5462},
{"f_7094:expand_2escm",(void*)f_7094},
{"f_8767:expand_2escm",(void*)f_8767},
{"f_4565:expand_2escm",(void*)f_4565},
{"f_7080:expand_2escm",(void*)f_7080},
{"f_7082:expand_2escm",(void*)f_7082},
{"f_7086:expand_2escm",(void*)f_7086},
{"f_4583:expand_2escm",(void*)f_4583},
{"f_9292:expand_2escm",(void*)f_9292},
{"f_7073:expand_2escm",(void*)f_7073},
{"f_6480:expand_2escm",(void*)f_6480},
{"f_8743:expand_2escm",(void*)f_8743},
{"f_4301:expand_2escm",(void*)f_4301},
{"f_7066:expand_2escm",(void*)f_7066},
{"f_6492:expand_2escm",(void*)f_6492},
{"f_4356:expand_2escm",(void*)f_4356},
{"f_8076:expand_2escm",(void*)f_8076},
{"f_4351:expand_2escm",(void*)f_4351},
{"f_8072:expand_2escm",(void*)f_8072},
{"f_8079:expand_2escm",(void*)f_8079},
{"f_7219:expand_2escm",(void*)f_7219},
{"f_10596:expand_2escm",(void*)f_10596},
{"f_7200:expand_2escm",(void*)f_7200},
{"f_8066:expand_2escm",(void*)f_8066},
{"f_4324:expand_2escm",(void*)f_4324},
{"f_8069:expand_2escm",(void*)f_8069},
{"f_5963:expand_2escm",(void*)f_5963},
{"f_5966:expand_2escm",(void*)f_5966},
{"f_5960:expand_2escm",(void*)f_5960},
{"f_5969:expand_2escm",(void*)f_5969},
{"f_8095:expand_2escm",(void*)f_8095},
{"f_8091:expand_2escm",(void*)f_8091},
{"f_8099:expand_2escm",(void*)f_8099},
{"f_8085:expand_2escm",(void*)f_8085},
{"f_4341:expand_2escm",(void*)f_4341},
{"f_8082:expand_2escm",(void*)f_8082},
{"f_8088:expand_2escm",(void*)f_8088},
{"f_9273:expand_2escm",(void*)f_9273},
{"f_9699:expand_2escm",(void*)f_9699},
{"f_7013:expand_2escm",(void*)f_7013},
{"f_5934:expand_2escm",(void*)f_5934},
{"f_5938:expand_2escm",(void*)f_5938},
{"f_4338:expand_2escm",(void*)f_4338},
{"f_4413:expand_2escm",(void*)f_4413},
{"f_4332:expand_2escm",(void*)f_4332},
{"f_7009:expand_2escm",(void*)f_7009},
{"f_11751:expand_2escm",(void*)f_11751},
{"f_11755:expand_2escm",(void*)f_11755},
{"f_11248:expand_2escm",(void*)f_11248},
{"f_6414:expand_2escm",(void*)f_6414},
{"f_6798:expand_2escm",(void*)f_6798},
{"f_6421:expand_2escm",(void*)f_6421},
{"f_6428:expand_2escm",(void*)f_6428},
{"f_5971:expand_2escm",(void*)f_5971},
{"f_5978:expand_2escm",(void*)f_5978},
{"f_8230:expand_2escm",(void*)f_8230},
{"f_8233:expand_2escm",(void*)f_8233},
{"f_8236:expand_2escm",(void*)f_8236},
{"f_8239:expand_2escm",(void*)f_8239},
{"f_6528:expand_2escm",(void*)f_6528},
{"f_10373:expand_2escm",(void*)f_10373},
{"f_8221:expand_2escm",(void*)f_8221},
{"f_8224:expand_2escm",(void*)f_8224},
{"f_8227:expand_2escm",(void*)f_8227},
{"f_10384:expand_2escm",(void*)f_10384},
{"f_5088:expand_2escm",(void*)f_5088},
{"f_4424:expand_2escm",(void*)f_4424},
{"f_6743:expand_2escm",(void*)f_6743},
{"f_6544:expand_2escm",(void*)f_6544},
{"f_10392:expand_2escm",(void*)f_10392},
{"f_6751:expand_2escm",(void*)f_6751},
{"f_6759:expand_2escm",(void*)f_6759},
{"f_6762:expand_2escm",(void*)f_6762},
{"f_11749:expand_2escm",(void*)f_11749},
{"f_5925:expand_2escm",(void*)f_5925},
{"f_5928:expand_2escm",(void*)f_5928},
{"f_9622:expand_2escm",(void*)f_9622},
{"f_9639:expand_2escm",(void*)f_9639},
{"f_6778:expand_2escm",(void*)f_6778},
{"f_6773:expand_2escm",(void*)f_6773},
{"f_11491:expand_2escm",(void*)f_11491},
{"f_9630:expand_2escm",(void*)f_9630},
{"f_9632:expand_2escm",(void*)f_9632},
{"f_5044:expand_2escm",(void*)f_5044},
{"f_9636:expand_2escm",(void*)f_9636},
{"f_8858:expand_2escm",(void*)f_8858},
{"f_8854:expand_2escm",(void*)f_8854},
{"f_11803:expand_2escm",(void*)f_11803},
{"f_10035:expand_2escm",(void*)f_10035},
{"f_5092:expand_2escm",(void*)f_5092},
{"f_11810:expand_2escm",(void*)f_11810},
{"f_11814:expand_2escm",(void*)f_11814},
{"f_8841:expand_2escm",(void*)f_8841},
{"f_5069:expand_2escm",(void*)f_5069},
{"f_6193:expand_2escm",(void*)f_6193},
{"f_7889:expand_2escm",(void*)f_7889},
{"f_8870:expand_2escm",(void*)f_8870},
{"f_5013:expand_2escm",(void*)f_5013},
{"f_11458:expand_2escm",(void*)f_11458},
{"f_10896:expand_2escm",(void*)f_10896},
{"f_11874:expand_2escm",(void*)f_11874},
{"f_10008:expand_2escm",(void*)f_10008},
{"f_11870:expand_2escm",(void*)f_11870},
{"f_5001:expand_2escm",(void*)f_5001},
{"f_11468:expand_2escm",(void*)f_11468},
{"f_11464:expand_2escm",(void*)f_11464},
{"f_11462:expand_2escm",(void*)f_11462},
{"f_10829:expand_2escm",(void*)f_10829},
{"f_10500:expand_2escm",(void*)f_10500},
{"f_8811:expand_2escm",(void*)f_8811},
{"f_10835:expand_2escm",(void*)f_10835},
{"f_10838:expand_2escm",(void*)f_10838},
{"f_7430:expand_2escm",(void*)f_7430},
{"f_8835:expand_2escm",(void*)f_8835},
{"f_10842:expand_2escm",(void*)f_10842},
{"f_10848:expand_2escm",(void*)f_10848},
{"f_8051:expand_2escm",(void*)f_8051},
{"f_8057:expand_2escm",(void*)f_8057},
{"f_8042:expand_2escm",(void*)f_8042},
{"f_8046:expand_2escm",(void*)f_8046},
{"f_6109:expand_2escm",(void*)f_6109},
{"f_7050:expand_2escm",(void*)f_7050},
{"f_7055:expand_2escm",(void*)f_7055},
{"f_7059:expand_2escm",(void*)f_7059},
{"f_7811:expand_2escm",(void*)f_7811},
{"f_9669:expand_2escm",(void*)f_9669},
{"f_6119:expand_2escm",(void*)f_6119},
{"f_6117:expand_2escm",(void*)f_6117},
{"f_7043:expand_2escm",(void*)f_7043},
{"f_9660:expand_2escm",(void*)f_9660},
{"f_9662:expand_2escm",(void*)f_9662},
{"f_9678:expand_2escm",(void*)f_9678},
{"f_7038:expand_2escm",(void*)f_7038},
{"f_10731:expand_2escm",(void*)f_10731},
{"f_9675:expand_2escm",(void*)f_9675},
{"f_9609:expand_2escm",(void*)f_9609},
{"f_7028:expand_2escm",(void*)f_7028},
{"f_10782:expand_2escm",(void*)f_10782},
{"f_9603:expand_2escm",(void*)f_9603},
{"f_9605:expand_2escm",(void*)f_9605},
{"f_7854:expand_2escm",(void*)f_7854},
{"f_9612:expand_2escm",(void*)f_9612},
{"f_9615:expand_2escm",(void*)f_9615},
{"f_10725:expand_2escm",(void*)f_10725},
{"f_10727:expand_2escm",(void*)f_10727},
{"f_10778:expand_2escm",(void*)f_10778},
{"f_10776:expand_2escm",(void*)f_10776},
{"f_11515:expand_2escm",(void*)f_11515},
{"f_11512:expand_2escm",(void*)f_11512},
{"f_10799:expand_2escm",(void*)f_10799},
{"f_10796:expand_2escm",(void*)f_10796},
{"f_10793:expand_2escm",(void*)f_10793},
{"f_10790:expand_2escm",(void*)f_10790},
{"f_11537:expand_2escm",(void*)f_11537},
{"f_11534:expand_2escm",(void*)f_11534},
{"f_11530:expand_2escm",(void*)f_11530},
{"f_10766:expand_2escm",(void*)f_10766},
{"f_11506:expand_2escm",(void*)f_11506},
{"f_7953:expand_2escm",(void*)f_7953},
{"f_11508:expand_2escm",(void*)f_11508},
{"f_10535:expand_2escm",(void*)f_10535},
{"f_10531:expand_2escm",(void*)f_10531},
{"f_7949:expand_2escm",(void*)f_7949},
{"f_10547:expand_2escm",(void*)f_10547},
{"f_10308:expand_2escm",(void*)f_10308},
{"f_7932:expand_2escm",(void*)f_7932},
{"f_7928:expand_2escm",(void*)f_7928},
{"f_7914:expand_2escm",(void*)f_7914},
{"f_10575:expand_2escm",(void*)f_10575},
{"f_7839:expand_2escm",(void*)f_7839},
{"f_9337:expand_2escm",(void*)f_9337},
{"f_7826:expand_2escm",(void*)f_7826},
{"f_10518:expand_2escm",(void*)f_10518},
{"f_9307:expand_2escm",(void*)f_9307},
{"f_10058:expand_2escm",(void*)f_10058},
{"f_9309:expand_2escm",(void*)f_9309},
{"f_11701:expand_2escm",(void*)f_11701},
{"f_11707:expand_2escm",(void*)f_11707},
{"f_11704:expand_2escm",(void*)f_11704},
{"f_11035:expand_2escm",(void*)f_11035},
{"f_10529:expand_2escm",(void*)f_10529},
{"f_9316:expand_2escm",(void*)f_9316},
{"f_8581:expand_2escm",(void*)f_8581},
{"f_5615:expand_2escm",(void*)f_5615},
{"f_11003:expand_2escm",(void*)f_11003},
{"f_11001:expand_2escm",(void*)f_11001},
{"f_11016:expand_2escm",(void*)f_11016},
{"f_11013:expand_2escm",(void*)f_11013},
{"f_11010:expand_2escm",(void*)f_11010},
{"f_10411:expand_2escm",(void*)f_10411},
{"f_5637:expand_2escm",(void*)f_5637},
{"f_6141:expand_2escm",(void*)f_6141},
{"f_6144:expand_2escm",(void*)f_6144},
{"f_6146:expand_2escm",(void*)f_6146},
{"f_10429:expand_2escm",(void*)f_10429},
{"f_10425:expand_2escm",(void*)f_10425},
{"f_10433:expand_2escm",(void*)f_10433},
{"f_4033:expand_2escm",(void*)f_4033},
{"f_8577:expand_2escm",(void*)f_8577},
{"f_8573:expand_2escm",(void*)f_8573},
{"f_11760:expand_2escm",(void*)f_11760},
{"f_10455:expand_2escm",(void*)f_10455},
{"f_10459:expand_2escm",(void*)f_10459},
{"f_11775:expand_2escm",(void*)f_11775},
{"f_10042:expand_2escm",(void*)f_10042},
{"f_8197:expand_2escm",(void*)f_8197},
{"f_11021:expand_2escm",(void*)f_11021},
{"f_4058:expand_2escm",(void*)f_4058},
{"f_11789:expand_2escm",(void*)f_11789},
{"f_11786:expand_2escm",(void*)f_11786},
{"f_8194:expand_2escm",(void*)f_8194},
{"f_8191:expand_2escm",(void*)f_8191},
{"f_8188:expand_2escm",(void*)f_8188},
{"f_8503:expand_2escm",(void*)f_8503},
{"f_11710:expand_2escm",(void*)f_11710},
{"f_8185:expand_2escm",(void*)f_8185},
{"f_8182:expand_2escm",(void*)f_8182},
{"f_4070:expand_2escm",(void*)f_4070},
{"f_8179:expand_2escm",(void*)f_8179},
{"f_4076:expand_2escm",(void*)f_4076},
{"f_8537:expand_2escm",(void*)f_8537},
{"f_8176:expand_2escm",(void*)f_8176},
{"f_4396:expand_2escm",(void*)f_4396},
{"f_10085:expand_2escm",(void*)f_10085},
{"f_10083:expand_2escm",(void*)f_10083},
{"f_4390:expand_2escm",(void*)f_4390},
{"f_4092:expand_2escm",(void*)f_4092},
{"f_5375:expand_2escm",(void*)f_5375},
{"f_9993:expand_2escm",(void*)f_9993},
{"f_4368:expand_2escm",(void*)f_4368},
{"f_10322:expand_2escm",(void*)f_10322},
{"f_4362:expand_2escm",(void*)f_4362},
{"f_4949:expand_2escm",(void*)f_4949},
{"f_10332:expand_2escm",(void*)f_10332},
{"f_8140:expand_2escm",(void*)f_8140},
{"f_5394:expand_2escm",(void*)f_5394},
{"f_9973:expand_2escm",(void*)f_9973},
{"f_10343:expand_2escm",(void*)f_10343},
{"f_10353:expand_2escm",(void*)f_10353},
{"f_4978:expand_2escm",(void*)f_4978},
{"f_4975:expand_2escm",(void*)f_4975},
{"f_10362:expand_2escm",(void*)f_10362},
{"f_8107:expand_2escm",(void*)f_8107},
{"f_4983:expand_2escm",(void*)f_4983},
{"f_4379:expand_2escm",(void*)f_4379},
{"f_6093:expand_2escm",(void*)f_6093},
{"f_6091:expand_2escm",(void*)f_6091},
{"f_8101:expand_2escm",(void*)f_8101},
{"f_6097:expand_2escm",(void*)f_6097},
{"f_9881:expand_2escm",(void*)f_9881},
{"f_4927:expand_2escm",(void*)f_4927},
{"f_9879:expand_2escm",(void*)f_9879},
{"f_4472:expand_2escm",(void*)f_4472},
{"f_9894:expand_2escm",(void*)f_9894},
{"f_9892:expand_2escm",(void*)f_9892},
{"f_4202:expand_2escm",(void*)f_4202},
{"f_4209:expand_2escm",(void*)f_4209},
{"f_6983:expand_2escm",(void*)f_6983},
{"f_9912:expand_2escm",(void*)f_9912},
{"f_6989:expand_2escm",(void*)f_6989},
{"f_9910:expand_2escm",(void*)f_9910},
{"f_4496:expand_2escm",(void*)f_4496},
{"f_9922:expand_2escm",(void*)f_9922},
{"f_5315:expand_2escm",(void*)f_5315},
{"f_4465:expand_2escm",(void*)f_4465},
{"f_4469:expand_2escm",(void*)f_4469},
{"f_6067:expand_2escm",(void*)f_6067},
{"f_4463:expand_2escm",(void*)f_4463},
{"f_4237:expand_2escm",(void*)f_4237},
{"f_4248:expand_2escm",(void*)f_4248},
{"f_8395:expand_2escm",(void*)f_8395},
{"f_4485:expand_2escm",(void*)f_4485},
{"f_4489:expand_2escm",(void*)f_4489},
{"f_9381:expand_2escm",(void*)f_9381},
{"f_4908:expand_2escm",(void*)f_4908},
{"f_4902:expand_2escm",(void*)f_4902},
{"f_9391:expand_2escm",(void*)f_9391},
{"f_8306:expand_2escm",(void*)f_8306},
{"f_4254:expand_2escm",(void*)f_4254},
{"f_4250:expand_2escm",(void*)f_4250},
{"f_11194:expand_2escm",(void*)f_11194},
{"f_9398:expand_2escm",(void*)f_9398},
{"f_5859:expand_2escm",(void*)f_5859},
{"f_11191:expand_2escm",(void*)f_11191},
{"f_9425:expand_2escm",(void*)f_9425},
{"f_9418:expand_2escm",(void*)f_9418},
{"f_9368:expand_2escm",(void*)f_9368},
{"f_5871:expand_2escm",(void*)f_5871},
{"f_9432:expand_2escm",(void*)f_9432},
{"f_9361:expand_2escm",(void*)f_9361},
{"f_9434:expand_2escm",(void*)f_9434},
{"f_9375:expand_2escm",(void*)f_9375},
{"f_5863:expand_2escm",(void*)f_5863},
{"f_3753:expand_2escm",(void*)f_3753},
{"f_3759:expand_2escm",(void*)f_3759},
{"f_6901:expand_2escm",(void*)f_6901},
{"f_6907:expand_2escm",(void*)f_6907},
{"f_6904:expand_2escm",(void*)f_6904},
{"f_9455:expand_2escm",(void*)f_9455},
{"f_11145:expand_2escm",(void*)f_11145},
{"f_6910:expand_2escm",(void*)f_6910},
{"f_11151:expand_2escm",(void*)f_11151},
{"f_11154:expand_2escm",(void*)f_11154},
{"f_11942:expand_2escm",(void*)f_11942},
{"f_9832:expand_2escm",(void*)f_9832},
{"f_4227:expand_2escm",(void*)f_4227},
{"f_5833:expand_2escm",(void*)f_5833},
{"f_6923:expand_2escm",(void*)f_6923},
{"f_6927:expand_2escm",(void*)f_6927},
{"f_3705:expand_2escm",(void*)f_3705},
{"f_9476:expand_2escm",(void*)f_9476},
{"f_9475:expand_2escm",(void*)f_9475},
{"f_3708:expand_2escm",(void*)f_3708},
{"f_3702:expand_2escm",(void*)f_3702},
{"f_11955:expand_2escm",(void*)f_11955},
{"f_11953:expand_2escm",(void*)f_11953},
{"f_9468:expand_2escm",(void*)f_9468},
{"f_6895:expand_2escm",(void*)f_6895},
{"f_6898:expand_2escm",(void*)f_6898},
{"f_9840:expand_2escm",(void*)f_9840},
{"f_9842:expand_2escm",(void*)f_9842},
{"f_6696:expand_2escm",(void*)f_6696},
{"f_6694:expand_2escm",(void*)f_6694},
{"f_5821:expand_2escm",(void*)f_5821},
{"f_3664:expand_2escm",(void*)f_3664},
{"f_11965:expand_2escm",(void*)f_11965},
{"f_11173:expand_2escm",(void*)f_11173},
{"f_8120:expand_2escm",(void*)f_8120},
{"f_8123:expand_2escm",(void*)f_8123},
{"f_11963:expand_2escm",(void*)f_11963},
{"f_3668:expand_2escm",(void*)f_3668},
{"f_5333:expand_2escm",(void*)f_5333},
{"f_5336:expand_2escm",(void*)f_5336},
{"f_9850:expand_2escm",(void*)f_9850},
{"f_6699:expand_2escm",(void*)f_6699},
{"f_6942:expand_2escm",(void*)f_6942},
{"f_9492:expand_2escm",(void*)f_9492},
{"f_6004:expand_2escm",(void*)f_6004},
{"f_5852:expand_2escm",(void*)f_5852},
{"f_11975:expand_2escm",(void*)f_11975},
{"f_6944:expand_2escm",(void*)f_6944},
{"f_11973:expand_2escm",(void*)f_11973},
{"f_8381:expand_2escm",(void*)f_8381},
{"f_6958:expand_2escm",(void*)f_6958},
{"f_5198:expand_2escm",(void*)f_5198},
{"f_11680:expand_2escm",(void*)f_11680},
{"f_5194:expand_2escm",(void*)f_5194},
{"f_6962:expand_2escm",(void*)f_6962},
{"f_8371:expand_2escm",(void*)f_8371},
{"f_3936:expand_2escm",(void*)f_3936},
{"f_11611:expand_2escm",(void*)f_11611},
{"f_3934:expand_2escm",(void*)f_3934},
{"f_6857:expand_2escm",(void*)f_6857},
{"f_11666:expand_2escm",(void*)f_11666},
{"f_11921:expand_2escm",(void*)f_11921},
{"f_11925:expand_2escm",(void*)f_11925},
{"f_11663:expand_2escm",(void*)f_11663},
{"f_6860:expand_2escm",(void*)f_6860},
{"f_6869:expand_2escm",(void*)f_6869},
{"f_6866:expand_2escm",(void*)f_6866},
{"f_6863:expand_2escm",(void*)f_6863},
{"f_11936:expand_2escm",(void*)f_11936},
{"f_11938:expand_2escm",(void*)f_11938},
{"f_3919:expand_2escm",(void*)f_3919},
{"f_11677:expand_2escm",(void*)f_11677},
{"f_6876:expand_2escm",(void*)f_6876},
{"f_9017:expand_2escm",(void*)f_9017},
{"f_9818:expand_2escm",(void*)f_9818},
{"f_9014:expand_2escm",(void*)f_9014},
{"f_9030:expand_2escm",(void*)f_9030},
{"f_6883:expand_2escm",(void*)f_6883},
{"f_6886:expand_2escm",(void*)f_6886},
{"f_7674:expand_2escm",(void*)f_7674},
{"f_9040:expand_2escm",(void*)f_9040},
{"f_6817:expand_2escm",(void*)f_6817},
{"f_9038:expand_2escm",(void*)f_9038},
{"f_9034:expand_2escm",(void*)f_9034},
{"f_6938:expand_2escm",(void*)f_6938},
{"f_3984:expand_2escm",(void*)f_3984},
{"f_11373:expand_2escm",(void*)f_11373},
{"f_11375:expand_2escm",(void*)f_11375},
{"f_7652:expand_2escm",(void*)f_7652},
{"f_6829:expand_2escm",(void*)f_6829},
{"f_3849:expand_2escm",(void*)f_3849},
{"f_9061:expand_2escm",(void*)f_9061},
{"f_6831:expand_2escm",(void*)f_6831},
{"f_6838:expand_2escm",(void*)f_6838},
{"f_9866:expand_2escm",(void*)f_9866},
{"f_9858:expand_2escm",(void*)f_9858},
{"f_11398:expand_2escm",(void*)f_11398},
{"f_7635:expand_2escm",(void*)f_7635},
{"f_6847:expand_2escm",(void*)f_6847},
{"f_6845:expand_2escm",(void*)f_6845},
{"f_9868:expand_2escm",(void*)f_9868},
{"f_11690:expand_2escm",(void*)f_11690},
{"f_11697:expand_2escm",(void*)f_11697},
{"f_6033:expand_2escm",(void*)f_6033},
{"f_9011:expand_2escm",(void*)f_9011},
{"f_7618:expand_2escm",(void*)f_7618},
{"f_6671:expand_2escm",(void*)f_6671},
{"f_6802:expand_2escm",(void*)f_6802},
{"f_3824:expand_2escm",(void*)f_3824},
{"f_3831:expand_2escm",(void*)f_3831},
{"f_7732:expand_2escm",(void*)f_7732},
{"f_7763:expand_2escm",(void*)f_7763},
{"f_7711:expand_2escm",(void*)f_7711},
{"f_10903:expand_2escm",(void*)f_10903},
{"f_10900:expand_2escm",(void*)f_10900},
{"f_9143:expand_2escm",(void*)f_9143},
{"f_7771:expand_2escm",(void*)f_7771},
{"f_9117:expand_2escm",(void*)f_9117},
{"f_9113:expand_2escm",(void*)f_9113},
{"f_11417:expand_2escm",(void*)f_11417},
{"f_11427:expand_2escm",(void*)f_11427},
{"f_11425:expand_2escm",(void*)f_11425},
{"f_11221:expand_2escm",(void*)f_11221},
{"f_7373:expand_2escm",(void*)f_7373},
{"f_9138:expand_2escm",(void*)f_9138},
{"f_9134:expand_2escm",(void*)f_9134},
{"f_10218:expand_2escm",(void*)f_10218},
{"f_10211:expand_2escm",(void*)f_10211},
{"f_10205:expand_2escm",(void*)f_10205},
{"f_10207:expand_2escm",(void*)f_10207},
{"f_10238:expand_2escm",(void*)f_10238},
{"f_5141:expand_2escm",(void*)f_5141},
{"f_9904:expand_2escm",(void*)f_9904},
{"f_9901:expand_2escm",(void*)f_9901},
{"f_9907:expand_2escm",(void*)f_9907},
{"f_9955:expand_2escm",(void*)f_9955},
{"f_5593:expand_2escm",(void*)f_5593},
{"f_5597:expand_2escm",(void*)f_5597},
{"f_9936:expand_2escm",(void*)f_9936},
{"f_4952:expand_2escm",(void*)f_4952},
{"f_8688:expand_2escm",(void*)f_8688},
{"f_8684:expand_2escm",(void*)f_8684},
{"f_4718:expand_2escm",(void*)f_4718},
{"f_4972:expand_2escm",(void*)f_4972},
{"f_4724:expand_2escm",(void*)f_4724},
{"f_4969:expand_2escm",(void*)f_4969},
{"f_7195:expand_2escm",(void*)f_7195},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  sprintf		1
S|  foldl		1
S|  ##sys#map		5
S|  for-each		2
S|  map		10
o|eliminated procedure checks: 565 
o|eliminated procedure checks: 1 
o|eliminated procedure checks: 1 
o|specializations:
o|  1 (zero? fixnum)
o|  1 (cdddr (pair * (pair * pair)))
o|  1 (##sys#check-output-port * * *)
o|  2 (vector-length vector)
o|  8 (eqv? (not float) *)
o|  2 (cadr (pair * pair))
o|  8 (cddr (pair * pair))
o|  1 (cdadr (pair * (pair pair *)))
o|  3 (caar (pair pair *))
o|  1 (>= fixnum fixnum)
o|  2 (length list)
o|  15 (eqv? * (not float))
o|  1 (##sys#call-with-values (procedure () *) *)
o|  2 (cdar (pair pair *))
o|  10 (##sys#check-list (or pair list) *)
o|  1 (set-cdr! pair *)
o|  75 (cdr pair)
o|  1 (set-car! pair *)
o|  58 (car pair)
(o e)|safe calls: 1155 
o|Removed `not' forms: 36 
o|inlining procedure: k3680 
o|inlining procedure: k3680 
o|contracted procedure: "(expand.scm:81) g257258" 
o|inlining procedure: k3697 
o|inlining procedure: k3697 
o|contracted procedure: "(expand.scm:95) g288289" 
o|contracted procedure: "(expand.scm:94) g283284" 
o|contracted procedure: "(expand.scm:93) g279280" 
o|inlining procedure: k3742 
o|inlining procedure: k3742 
o|inlining procedure: k3764 
o|inlining procedure: k3764 
o|inlining procedure: k3786 
o|inlining procedure: k3786 
o|contracted procedure: k3792 
o|inlining procedure: k3795 
o|inlining procedure: k3795 
o|contracted procedure: "(expand.scm:109) g321322" 
o|contracted procedure: "(expand.scm:108) g310311" 
o|inlining procedure: k3801 
o|inlining procedure: k3801 
o|inlining procedure: k3860 
o|inlining procedure: k3860 
o|inlining procedure: k3938 
o|contracted procedure: "(expand.scm:136) g424434" 
o|inlining procedure: k3938 
o|inlining procedure: k3986 
o|contracted procedure: "(expand.scm:130) g382390" 
o|contracted procedure: "(expand.scm:134) g400401" 
o|contracted procedure: "(expand.scm:133) g396397" 
o|inlining procedure: k3986 
o|inlining procedure: k4035 
o|inlining procedure: k4035 
o|contracted procedure: k4081 
o|inlining procedure: k4078 
o|inlining procedure: k4094 
o|inlining procedure: k4094 
o|inlining procedure: k4112 
o|inlining procedure: k4112 
o|contracted procedure: "(expand.scm:144) g461462" 
o|inlining procedure: k4078 
o|inlining procedure: k4163 
o|inlining procedure: k4163 
o|inlining procedure: k4206 
o|inlining procedure: k4206 
o|inlining procedure: k4261 
o|inlining procedure: k4261 
o|removed unused formal parameters: (me2542) 
o|inlining procedure: k4303 
o|inlining procedure: k4303 
o|removed unused parameter to known procedure: me2542 loop540 
o|inlining procedure: k4374 
o|inlining procedure: k4398 
o|inlining procedure: k4398 
o|inlining procedure: k4441 
o|inlining procedure: k4441 
o|inlining procedure: k4374 
o|inlining procedure: k4470 
o|inlining procedure: k4470 
o|contracted procedure: k4490 
o|merged explicitly consed rest parameter: args566598 
o|consed rest parameter at call site: tmp23093 1 
o|contracted procedure: k4547 
o|inlining procedure: k4544 
o|inlining procedure: k4544 
o|inlining procedure: k4585 
o|inlining procedure: k4608 
o|inlining procedure: k4657 
o|inlining procedure: k4657 
o|inlining procedure: k4726 
o|contracted procedure: "(expand.scm:285) g644653" 
o|inlining procedure: k4726 
o|inlining procedure: k4608 
o|inlining procedure: k4771 
o|inlining procedure: k4771 
o|inlining procedure: k4801 
o|contracted procedure: "(expand.scm:290) g694695" 
o|inlining procedure: k4801 
o|inlining procedure: k4819 
o|inlining procedure: k4819 
o|inlining procedure: k4585 
o|inlining procedure: k4867 
o|inlining procedure: k4867 
o|inlining procedure: k4910 
o|inlining procedure: k4936 
o|inlining procedure: k4936 
o|substituted constant variable: a4943 
o|substituted constant variable: a4945 
o|substituted constant variable: a4947 
o|inlining procedure: k4910 
o|inlining procedure: k4985 
o|inlining procedure: k5002 
o|inlining procedure: k5002 
o|inlining procedure: k5045 
o|inlining procedure: k5045 
o|inlining procedure: k5098 
o|inlining procedure: k5098 
o|contracted procedure: k5101 
o|contracted procedure: k5107 
o|inlining procedure: k5110 
o|inlining procedure: k5110 
o|inlining procedure: k5170 
o|substituted constant variable: %lambda774 
o|inlining procedure: k5170 
o|contracted procedure: "(expand.scm:365) ->keyword768" 
o|inlining procedure: k5208 
o|inlining procedure: k5208 
o|inlining procedure: k4985 
o|inlining procedure: k5255 
o|inlining procedure: k5255 
o|contracted procedure: k5275 
o|inlining procedure: k5272 
o|inlining procedure: k5300 
o|inlining procedure: k5300 
o|inlining procedure: k5316 
o|inlining procedure: k5328 
o|contracted procedure: k5346 
o|inlining procedure: k5328 
o|inlining procedure: k5316 
o|inlining procedure: k5376 
o|inlining procedure: k5376 
o|contracted procedure: k5388 
o|inlining procedure: k5395 
o|inlining procedure: k5414 
o|inlining procedure: k5414 
o|substituted constant variable: a5452 
o|substituted constant variable: a5454 
o|substituted constant variable: a5456 
o|inlining procedure: k5395 
o|inlining procedure: k5463 
o|inlining procedure: k5463 
o|inlining procedure: k5485 
o|inlining procedure: k5485 
o|substituted constant variable: a5502 
o|substituted constant variable: a5504 
o|substituted constant variable: a5506 
o|inlining procedure: k5513 
o|inlining procedure: k5513 
o|substituted constant variable: a5529 
o|substituted constant variable: a5531 
o|substituted constant variable: a5533 
o|contracted procedure: k5540 
o|inlining procedure: k5537 
o|inlining procedure: k5537 
o|inlining procedure: k5272 
o|inlining procedure: k5617 
o|inlining procedure: k5617 
o|inlining procedure: k5639 
o|contracted procedure: "(expand.scm:456) g937947" 
o|inlining procedure: k5639 
o|contracted procedure: k5684 
o|inlining procedure: k5705 
o|inlining procedure: k5705 
o|inlining procedure: k5763 
o|inlining procedure: k5763 
o|inlining procedure: k5772 
o|inlining procedure: k5772 
o|inlining procedure: k5781 
o|inlining procedure: k5781 
o|inlining procedure: k5802 
o|inlining procedure: k5802 
o|substituted constant variable: a5815 
o|substituted constant variable: a5817 
o|substituted constant variable: a5819 
o|inlining procedure: k5823 
o|contracted procedure: k5838 
o|inlining procedure: k5835 
o|inlining procedure: k5885 
o|inlining procedure: k5885 
o|inlining procedure: k5835 
o|inlining procedure: k5823 
o|inlining procedure: k5973 
o|contracted procedure: "(expand.scm:507) g10851096" 
o|inlining procedure: k5945 
o|inlining procedure: k5945 
o|inlining procedure: k5973 
o|inlining procedure: k6023 
o|inlining procedure: k6023 
o|inlining procedure: k6035 
o|contracted procedure: "(expand.scm:499) g10371046" 
o|inlining procedure: k6035 
o|inlining procedure: k6069 
o|contracted procedure: "(expand.scm:502) g10611062" 
o|inlining procedure: k6069 
o|substituted constant variable: g10531056 
o|inlining procedure: k6121 
o|inlining procedure: k6148 
o|inlining procedure: k6148 
o|inlining procedure: k6121 
o|contracted procedure: k6182 
o|inlining procedure: k6188 
o|inlining procedure: k6205 
o|inlining procedure: k6205 
o|inlining procedure: k6188 
o|inlining procedure: k6261 
o|inlining procedure: k6261 
o|substituted constant variable: a6283 
o|contracted procedure: k6310 
o|inlining procedure: k6307 
o|contracted procedure: k6329 
o|inlining procedure: k6335 
o|contracted procedure: k6356 
o|inlining procedure: k6353 
o|inlining procedure: k6353 
o|inlining procedure: k6381 
o|inlining procedure: k6381 
o|inlining procedure: k6335 
o|inlining procedure: k6484 
o|inlining procedure: k6484 
o|inlining procedure: k6533 
o|inlining procedure: k6533 
o|inlining procedure: k6569 
o|inlining procedure: k6569 
o|inlining procedure: k6307 
o|contracted procedure: k6622 
o|inlining procedure: k6619 
o|inlining procedure: k6666 
o|inlining procedure: k6666 
o|inlining procedure: k6619 
o|inlining procedure: k6643 
o|inlining procedure: k6643 
o|inlining procedure: k6689 
o|inlining procedure: k6689 
o|inlining procedure: k6701 
o|inlining procedure: k6701 
o|inlining procedure: k6818 
o|inlining procedure: k6818 
o|inlining procedure: k6849 
o|inlining procedure: k6849 
o|inlining procedure: k6911 
o|inlining procedure: k6911 
o|inlining procedure: k6946 
o|inlining procedure: k6946 
o|contracted procedure: "(expand.scm:675) syntax-imports1267" 
o|inlining procedure: k6780 
o|inlining procedure: k6780 
o|inlining procedure: k6991 
o|inlining procedure: k7001 
o|inlining procedure: k7018 
o|inlining procedure: k7018 
o|inlining procedure: k7001 
o|inlining procedure: k6991 
o|inlining procedure: k7045 
o|inlining procedure: k7045 
o|inlining procedure: k7064 
o|inlining procedure: k7064 
o|propagated global variable: sexp1359 ##sys#syntax-error-culprit 
o|inlining procedure: k7087 
o|inlining procedure: k7087 
o|inlining procedure: k7099 
o|inlining procedure: k7099 
o|inlining procedure: k7115 
o|contracted procedure: k7131 
o|inlining procedure: k7128 
o|inlining procedure: k7128 
o|inlining procedure: k7115 
o|inlining procedure: k7155 
o|inlining procedure: k7155 
o|inlining procedure: k7178 
o|inlining procedure: k7202 
o|inlining procedure: k7202 
o|contracted procedure: k7240 
o|inlining procedure: k7237 
o|inlining procedure: k7237 
o|inlining procedure: k7260 
o|inlining procedure: k7260 
o|inlining procedure: k7178 
o|contracted procedure: k7284 
o|inlining procedure: k7281 
o|inlining procedure: k7281 
o|inlining procedure: k7294 
o|inlining procedure: k7306 
o|inlining procedure: k7306 
o|inlining procedure: k7324 
o|inlining procedure: k7324 
o|inlining procedure: k7342 
o|inlining procedure: k7342 
o|inlining procedure: k7360 
o|inlining procedure: k7360 
o|inlining procedure: k7382 
o|inlining procedure: k7382 
o|substituted constant variable: a7395 
o|substituted constant variable: a7397 
o|substituted constant variable: a7399 
o|substituted constant variable: a7401 
o|substituted constant variable: a7403 
o|substituted constant variable: a7405 
o|substituted constant variable: a7407 
o|substituted constant variable: a7409 
o|inlining procedure: k7294 
o|contracted procedure: k7413 
o|contracted procedure: k7422 
o|inlining procedure: k7419 
o|inlining procedure: k7419 
o|inlining procedure: k7500 
o|inlining procedure: k7500 
o|contracted procedure: k7541 
o|inlining procedure: k7538 
o|contracted procedure: "(expand.scm:802) g14511452" 
o|inlining procedure: k7569 
o|contracted procedure: "(expand.scm:822) g14761477" 
o|contracted procedure: "(expand.scm:821) g14721473" 
o|inlining procedure: k7569 
o|inlining procedure: k7564 
o|inlining procedure: k7564 
o|inlining procedure: k7538 
o|inlining procedure: k7654 
o|inlining procedure: k7669 
o|inlining procedure: k7669 
o|inlining procedure: k7654 
o|inlining procedure: k7692 
o|inlining procedure: k7713 
o|inlining procedure: k7713 
o|inlining procedure: k7692 
o|inlining procedure: k7750 
o|inlining procedure: k7778 
o|inlining procedure: k7802 
o|inlining procedure: k7802 
o|contracted procedure: "(expand.scm:863) g15611562" 
o|contracted procedure: "(expand.scm:862) g15541555" 
o|inlining procedure: k7778 
o|inlining procedure: k7827 
o|inlining procedure: k7827 
o|inlining procedure: k7861 
o|inlining procedure: k7861 
o|removed unused parameter to known procedure: n1581 "(expand.scm:858) lookup21441" 
o|contracted procedure: "(expand.scm:857) g15351536" 
o|inlining procedure: k7867 
o|inlining procedure: k7867 
o|removed unused parameter to known procedure: n1581 "(expand.scm:855) lookup21441" 
o|contracted procedure: "(expand.scm:854) g15251526" 
o|inlining procedure: k7750 
o|removed unused formal parameters: (n1581) 
o|inlining procedure: k7891 
o|inlining procedure: k7891 
o|inlining procedure: k7916 
o|inlining procedure: k7916 
o|contracted procedure: k7957 
o|inlining procedure: k7954 
o|contracted procedure: "(expand.scm:895) g16061607" 
o|contracted procedure: k7983 
o|inlining procedure: k7980 
o|inlining procedure: k8009 
o|contracted procedure: "(expand.scm:895) g16231624" 
o|inlining procedure: k8009 
o|contracted procedure: "(expand.scm:903) g16191620" 
o|inlining procedure: k7980 
o|inlining procedure: k7954 
o|inlining procedure: k8030 
o|inlining procedure: k8030 
o|inlining procedure: k8112 
o|inlining procedure: k8112 
o|removed side-effect free assignment to unused variable: %vector-length2418 
o|removed side-effect free assignment to unused variable: %vector-ref2419 
o|removed side-effect free assignment to unused variable: %null?2441 
o|removed side-effect free assignment to unused variable: %or2442 
o|removed side-effect free assignment to unused variable: %syntax-error2448 
o|inlining procedure: k8397 
o|inlining procedure: k8397 
o|inlining procedure: k8439 
o|inlining procedure: k8439 
o|inlining procedure: k8487 
o|inlining procedure: k8487 
o|inlining procedure: k8505 
o|inlining procedure: k8505 
o|inlining procedure: k8541 
o|inlining procedure: k8541 
o|inlining procedure: k8643 
o|inlining procedure: k8643 
o|inlining procedure: k8677 
o|inlining procedure: k8677 
o|inlining procedure: k8813 
o|inlining procedure: k8813 
o|inlining procedure: k8876 
o|inlining procedure: k8876 
o|inlining procedure: k8904 
o|inlining procedure: k8904 
o|inlining procedure: k8953 
o|inlining procedure: k8965 
o|inlining procedure: k8965 
o|inlining procedure: k8953 
o|inlining procedure: k9000 
o|inlining procedure: k9000 
o|substituted constant variable: %append2411 
o|inlining procedure: k9042 
o|inlining procedure: k9042 
o|substituted constant variable: %apply2412 
o|substituted constant variable: %append2411 
o|inlining procedure: k9076 
o|inlining procedure: k9076 
o|inlining procedure: k9101 
o|inlining procedure: k9101 
o|inlining procedure: k9145 
o|inlining procedure: k9145 
o|inlining procedure: k9189 
o|inlining procedure: k9189 
o|inlining procedure: k9222 
o|contracted procedure: k9237 
o|inlining procedure: k9243 
o|inlining procedure: k9243 
o|inlining procedure: k9222 
o|inlining procedure: k9278 
o|inlining procedure: k9278 
o|inlining procedure: k9311 
o|contracted procedure: k9326 
o|inlining procedure: k9323 
o|inlining procedure: k9323 
o|inlining procedure: k9311 
o|inlining procedure: k9339 
o|inlining procedure: k9339 
o|inlining procedure: k9363 
o|inlining procedure: k9363 
o|inlining procedure: k9393 
o|inlining procedure: k9393 
o|inlining procedure: k9436 
o|inlining procedure: k9436 
o|inlining procedure: k9478 
o|inlining procedure: k9490 
o|inlining procedure: k9490 
o|inlining procedure: k9478 
o|inlining procedure: k9519 
o|inlining procedure: k9519 
o|inlining procedure: k9613 
o|inlining procedure: k9613 
o|inlining procedure: k9670 
o|inlining procedure: k9691 
o|inlining procedure: k9691 
o|inlining procedure: k9670 
o|inlining procedure: k9779 
o|inlining procedure: k9779 
o|inlining procedure: k9799 
o|inlining procedure: k9799 
o|inlining procedure: k9924 
o|inlining procedure: k9924 
o|contracted procedure: k9940 
o|inlining procedure: k9950 
o|inlining procedure: k9962 
o|inlining procedure: k9962 
o|inlining procedure: k9950 
o|contracted procedure: k9997 
o|inlining procedure: k9994 
o|inlining procedure: k9994 
o|inlining procedure: k10009 
o|inlining procedure: k10009 
o|inlining procedure: k10030 
o|inlining procedure: k10030 
o|inlining procedure: k10060 
o|inlining procedure: k10087 
o|contracted procedure: "(expand.scm:1406) g22832292" 
o|inlining procedure: k10087 
o|inlining procedure: k10060 
o|contracted procedure: k10121 
o|contracted procedure: k10134 
o|inlining procedure: k10131 
o|inlining procedure: k10150 
o|inlining procedure: k10150 
o|inlining procedure: k10159 
o|inlining procedure: k10159 
o|inlining procedure: k10131 
o|inlining procedure: k10264 
o|inlining procedure: k10264 
o|contracted procedure: k10284 
o|inlining procedure: k10294 
o|inlining procedure: k10294 
o|inlining procedure: k10348 
o|inlining procedure: k10348 
o|inlining procedure: k10430 
o|inlining procedure: k10430 
o|inlining procedure: k10464 
o|inlining procedure: k10464 
o|inlining procedure: k10501 
o|contracted procedure: "(expand.scm:1302) g22122213" 
o|inlining procedure: k10501 
o|inlining procedure: k10641 
o|contracted procedure: "(expand.scm:1292) g21152124" 
o|inlining procedure: k10611 
o|inlining procedure: k10611 
o|inlining procedure: k10641 
o|inlining procedure: k10691 
o|contracted procedure: "(expand.scm:1281) g20812090" 
o|inlining procedure: k10691 
o|inlining procedure: k10743 
o|inlining procedure: k10743 
o|contracted procedure: k10820 
o|inlining procedure: k10817 
o|inlining procedure: k10843 
o|inlining procedure: k10843 
o|inlining procedure: k10955 
o|inlining procedure: k10955 
o|inlining procedure: k10817 
o|contracted procedure: k11026 
o|inlining procedure: k11023 
o|substituted constant variable: a11050 
o|substituted constant variable: a11051 
o|inlining procedure: k11068 
o|inlining procedure: k11095 
o|inlining procedure: k11095 
o|inlining procedure: k11068 
o|inlining procedure: k11146 
o|inlining procedure: k11146 
o|inlining procedure: k11282 
o|inlining procedure: k11282 
o|inlining procedure: k11294 
o|inlining procedure: k11294 
o|inlining procedure: k11306 
o|inlining procedure: k11306 
o|inlining procedure: k11318 
o|inlining procedure: k11318 
o|inlining procedure: k11327 
o|inlining procedure: k11327 
o|inlining procedure: k11023 
o|inlining procedure: k11380 
o|inlining procedure: k11380 
o|inlining procedure: k11432 
o|inlining procedure: k11432 
o|inlining procedure: k11475 
o|inlining procedure: k11475 
o|contracted procedure: k11658 
o|inlining procedure: k11655 
o|inlining procedure: k11655 
o|contracted procedure: "(expand.scm:1031) g17681769" 
o|contracted procedure: k11770 
o|inlining procedure: k11767 
o|inlining procedure: k11767 
o|inlining procedure: k11794 
o|inlining procedure: k11794 
o|contracted procedure: "(expand.scm:1006) g17381739" 
o|propagated global variable: g16851686 ##sys#expand-import 
o|propagated global variable: g16711672 ##sys#expand-import 
o|propagated global variable: g16571658 ##sys#expand-import 
o|replaced variables: 1623 
o|removed binding forms: 489 
o|substituted constant variable: prop260 
o|removed call to pure procedure with unused result: "(expand.scm:96) void" 
o|substituted constant variable: prop291 
o|substituted constant variable: prop286 
o|substituted constant variable: prop282 
o|substituted constant variable: r374311985 
o|substituted constant variable: prop324 
o|substituted constant variable: prop313 
o|substituted constant variable: prop403 
o|inlining procedure: k3908 
o|inlining procedure: k3908 
o|substituted constant variable: prop399 
o|substituted constant variable: prop464 
o|substituted constant variable: r430412014 
o|substituted constant variable: r439912018 
o|substituted constant variable: r444212021 
o|removed call to pure procedure with unused result: "(expand.scm:246) void" 
o|removed call to pure procedure with unused result: "(expand.scm:206) void" 
o|removed call to pure procedure with unused result: "(expand.scm:203) void" 
o|removed call to pure procedure with unused result: "(expand.scm:203) void" 
o|inlining procedure: k4780 
o|substituted constant variable: prop697 
o|substituted constant variable: r480212048 
o|substituted constant variable: r491112059 
o|substituted constant variable: r511112072 
o|substituted constant variable: r517112075 
o|substituted constant variable: r517112075 
o|substituted constant variable: r551412100 
o|substituted constant variable: r553812101 
o|converted assignments to bindings: (err767) 
o|substituted constant variable: r561812104 
o|substituted constant variable: r561812104 
o|inlining procedure: k5617 
o|substituted constant variable: r588612123 
o|removed call to pure procedure with unused result: "(expand.scm:497) void" 
o|substituted constant variable: r602412131 
o|inlining procedure: k6205 
o|substituted constant variable: r626212147 
o|substituted constant variable: r638212154 
o|substituted constant variable: r638212154 
o|substituted constant variable: r657012162 
o|substituted constant variable: r666712166 
o|substituted constant variable: r664412168 
o|substituted constant variable: r669012171 
o|substituted constant variable: r694712180 
o|substituted constant variable: r678112182 
o|converted assignments to bindings: (outstr1280) 
o|substituted constant variable: r701912187 
o|substituted constant variable: r700212188 
o|substituted constant variable: r699212189 
o|substituted constant variable: r712912201 
o|substituted constant variable: r711612203 
o|substituted constant variable: r726112212 
o|removed call to pure procedure with unused result: "(expand.scm:812) void" 
o|removed call to pure procedure with unused result: "(expand.scm:823) void" 
o|removed call to pure procedure with unused result: "(expand.scm:827) void" 
o|substituted constant variable: prop1479 
o|substituted constant variable: prop1475 
o|removed call to pure procedure with unused result: "(expand.scm:831) void" 
o|removed call to pure procedure with unused result: "(expand.scm:836) void" 
o|removed call to pure procedure with unused result: "(expand.scm:802) void" 
o|inlining procedure: k7654 
o|substituted constant variable: r767012247 
o|inlining procedure: k7654 
o|inlining procedure: k7654 
o|inlining procedure: k7654 
o|substituted constant variable: r769312257 
o|substituted constant variable: prop1564 
o|substituted constant variable: prop1557 
o|inlining procedure: k7654 
o|inlining procedure: k7654 
o|substituted constant variable: prop1538 
o|substituted constant variable: prop1528 
o|removed call to pure procedure with unused result: "(expand.scm:802) void" 
o|substituted constant variable: r789212272 
o|removed call to pure procedure with unused result: "(expand.scm:897) void" 
o|removed call to pure procedure with unused result: "(expand.scm:902) void" 
o|removed call to pure procedure with unused result: "(expand.scm:904) void" 
o|removed call to pure procedure with unused result: "(expand.scm:909) void" 
o|substituted constant variable: prop1622 
o|removed call to pure procedure with unused result: "(expand.scm:900) void" 
o|removed side-effect free assignment to unused variable: %append2411 
o|removed side-effect free assignment to unused variable: %apply2412 
o|substituted constant variable: r848812291 
o|substituted constant variable: r907712317 
o|substituted constant variable: r924412326 
o|substituted constant variable: r932412331 
o|substituted constant variable: r931212333 
o|substituted constant variable: r934012335 
o|substituted constant variable: r936412337 
o|substituted constant variable: r943712340 
o|substituted constant variable: r969212356 
o|substituted constant variable: r980012363 
o|substituted constant variable: r999512370 
o|substituted constant variable: r1015112381 
o|substituted constant variable: r1081812411 
o|substituted constant variable: r1132812428 
o|substituted constant variable: r1102412429 
o|substituted constant variable: r1138112430 
o|substituted constant variable: r1143312432 
o|substituted constant variable: prop1771 
o|substituted constant variable: r1179512442 
o|substituted constant variable: r1179512442 
o|substituted constant variable: prop1741 
o|simplifications: ((let . 2)) 
o|replaced variables: 68 
o|removed binding forms: 1515 
o|inlining procedure: k3688 
o|contracted procedure: k3733 
o|substituted constant variable: prop40312458 
o|substituted constant variable: prop40312464 
o|contracted procedure: k4343 
o|contracted procedure: k4346 
o|contracted procedure: k4473 
o|removed call to pure procedure with unused result: "(expand.scm:246) void" 
o|contracted procedure: k4541 
o|inlining procedure: k5264 
o|inlining procedure: k5264 
o|contracted procedure: k5907 
o|contracted procedure: k7552 
o|contracted procedure: k7589 
o|contracted procedure: k7600 
o|contracted procedure: k7619 
o|contracted procedure: k7636 
o|contracted procedure: k7657 
o|substituted constant variable: r765512577 
o|removed call to pure procedure with unused result: "(expand.scm:802) void" 
o|substituted constant variable: r765512582 
o|removed call to pure procedure with unused result: "(expand.scm:802) void" 
o|substituted constant variable: r765512591 
o|removed call to pure procedure with unused result: "(expand.scm:802) void" 
o|substituted constant variable: r765512596 
o|removed call to pure procedure with unused result: "(expand.scm:802) void" 
o|substituted constant variable: r765512601 
o|removed call to pure procedure with unused result: "(expand.scm:802) void" 
o|substituted constant variable: r765512606 
o|removed call to pure procedure with unused result: "(expand.scm:802) void" 
o|contracted procedure: k7885 
o|contracted procedure: k7971 
o|contracted procedure: k7998 
o|contracted procedure: k8014 
o|contracted procedure: k8023 
o|contracted procedure: k7986 
o|inlining procedure: k9231 
o|inlining procedure: k9231 
o|inlining procedure: k9579 
o|inlining procedure: k9579 
o|replaced variables: 49 
o|removed binding forms: 166 
o|contracted procedure: k3717 
o|contracted procedure: k3725 
o|contracted procedure: k3730 
o|contracted procedure: k3778 
o|contracted procedure: k3783 
o|contracted procedure: k3899 
o|contracted procedure: k4086 
o|contracted procedure: k447312035 
o|substituted constant variable: r561812516 
o|contracted procedure: k7580 
o|contracted procedure: k765712581 
o|substituted constant variable: result150112578 
o|contracted procedure: k765712586 
o|substituted constant variable: result150112583 
o|contracted procedure: k765712595 
o|substituted constant variable: result150112592 
o|contracted procedure: k765712600 
o|substituted constant variable: result150112597 
o|contracted procedure: k7758 
o|contracted procedure: k7766 
o|contracted procedure: k7790 
o|contracted procedure: k7799 
o|contracted procedure: k765712605 
o|substituted constant variable: result150112602 
o|contracted procedure: k765712610 
o|substituted constant variable: result150112607 
o|inlining procedure: "(expand.scm:858) lookup21441" 
o|inlining procedure: "(expand.scm:855) lookup21441" 
o|contracted procedure: k8006 
o|substituted constant variable: r923212738 
o|substituted constant variable: r923212739 
o|contracted procedure: k11669 
o|contracted procedure: k11778 
o|replaced variables: 4 
o|removed binding forms: 104 
o|removed conditional forms: 2 
o|removed side-effect free assignment to unused variable: lookup21441 
o|replaced variables: 15 
o|removed binding forms: 21 
o|replaced variables: 10 
o|removed binding forms: 13 
o|inlining procedure: k3720 
o|inlining procedure: k3720 
o|replaced variables: 2 
o|removed binding forms: 3 
o|replaced variables: 1 
o|removed binding forms: 3 
o|replaced variables: 4 
o|removed binding forms: 1 
o|removed binding forms: 3 
o|simplifications: ((if . 48) (##core#call . 1024)) 
o|  call simplifications:
o|    number?
o|    eof-object?
o|    fx-	2
o|    cdddr
o|    cadddr	2
o|    cddddr
o|    >=
o|    +	3
o|    =
o|    -
o|    <=
o|    boolean?
o|    char?	2
o|    cdar	2
o|    ##sys#immediate?
o|    vector-ref	5
o|    fx<	2
o|    not	4
o|    fx=	7
o|    memq	7
o|    member
o|    caddr	12
o|    length	11
o|    fx<=	2
o|    ##sys#call-with-values
o|    cddr	10
o|    ##sys#list	163
o|    ##sys#cons	87
o|    list?	5
o|    cadr	36
o|    values	8
o|    ##sys#apply	2
o|    memv
o|    equal?	2
o|    string?	3
o|    ##sys#make-structure	2
o|    apply	2
o|    list	16
o|    set-car!	4
o|    procedure?
o|    ##sys#structure?	2
o|    caar	9
o|    eq?	74
o|    null?	51
o|    car	66
o|    ##sys#check-list	13
o|    assq	12
o|    symbol?	42
o|    vector?	13
o|    fx>=	5
o|    fx+	4
o|    cons	82
o|    ##sys#setslot	18
o|    pair?	87
o|    ##sys#slot	71
o|    ##sys#size	5
o|    fx>	5
o|    char=?
o|    cdr	49
o|contracted procedure: k3712 
o|contracted procedure: k3736 
o|contracted procedure: k3739 
o|contracted procedure: k3745 
o|contracted procedure: k3761 
o|contracted procedure: k3773 
o|contracted procedure: k3798 
o|contracted procedure: k3804 
o|contracted procedure: k3807 
o|contracted procedure: k3835 
o|contracted procedure: k3811 
o|contracted procedure: k3814 
o|contracted procedure: k3817 
o|contracted procedure: k3841 
o|contracted procedure: k3844 
o|contracted procedure: k3885 
o|contracted procedure: k3851 
o|contracted procedure: k3863 
o|contracted procedure: k3866 
o|contracted procedure: k3873 
o|contracted procedure: k3881 
o|contracted procedure: k3911 
o|contracted procedure: k3914 
o|contracted procedure: k3924 
o|contracted procedure: k3977 
o|contracted procedure: k3941 
o|contracted procedure: k3967 
o|contracted procedure: k3971 
o|contracted procedure: k3963 
o|contracted procedure: k3944 
o|contracted procedure: k3947 
o|contracted procedure: k3955 
o|contracted procedure: k3959 
o|contracted procedure: k4014 
o|contracted procedure: k3989 
o|contracted procedure: k4007 
o|contracted procedure: k4011 
o|contracted procedure: k3992 
o|contracted procedure: k3999 
o|contracted procedure: k4003 
o|contracted procedure: k4020 
o|contracted procedure: k4023 
o|contracted procedure: k4026 
o|contracted procedure: k4038 
o|contracted procedure: k4041 
o|contracted procedure: k4044 
o|contracted procedure: k4052 
o|contracted procedure: k4060 
o|contracted procedure: k4148 
o|contracted procedure: k4097 
o|contracted procedure: k4115 
o|contracted procedure: k4144 
o|contracted procedure: k4134 
o|contracted procedure: k4188 
o|contracted procedure: k4160 
o|contracted procedure: k4166 
o|contracted procedure: k4179 
o|contracted procedure: k4211 
o|contracted procedure: k4214 
o|contracted procedure: k4222 
o|contracted procedure: k4233 
o|contracted procedure: k4229 
o|contracted procedure: k4258 
o|contracted procedure: k4277 
o|contracted procedure: k4306 
o|contracted procedure: k4328 
o|contracted procedure: k4312 
o|contracted procedure: k4384 
o|contracted procedure: k4374 
o|contracted procedure: k4392 
o|contracted procedure: k4401 
o|contracted procedure: k4404 
o|contracted procedure: k4418 
o|contracted procedure: k4428 
o|contracted procedure: k4432 
o|contracted procedure: k4438 
o|contracted procedure: k4444 
o|contracted procedure: k4452 
o|contracted procedure: k4459 
o|contracted procedure: k4476 
o|contracted procedure: k4576 
o|contracted procedure: k4556 
o|contracted procedure: k4567 
o|contracted procedure: k4588 
o|contracted procedure: k4596 
o|contracted procedure: k4602 
o|contracted procedure: k4611 
o|contracted procedure: k4617 
o|contracted procedure: k4623 
o|contracted procedure: k4629 
o|contracted procedure: k4705 
o|contracted procedure: k4713 
o|contracted procedure: k4720 
o|contracted procedure: k4701 
o|contracted procedure: k4697 
o|contracted procedure: k4693 
o|contracted procedure: k4689 
o|contracted procedure: k4644 
o|contracted procedure: k4648 
o|contracted procedure: k4640 
o|contracted procedure: k4636 
o|contracted procedure: k4660 
o|contracted procedure: k4682 
o|contracted procedure: k4678 
o|contracted procedure: k4663 
o|contracted procedure: k4666 
o|contracted procedure: k4674 
o|contracted procedure: k4729 
o|contracted procedure: k4751 
o|contracted procedure: k4747 
o|contracted procedure: k4732 
o|contracted procedure: k4735 
o|contracted procedure: k4743 
o|contracted procedure: k4774 
o|contracted procedure: k4790 
o|contracted procedure: k4804 
o|contracted procedure: k4812 
o|contracted procedure: k4885 
o|contracted procedure: k4840 
o|contracted procedure: k4879 
o|contracted procedure: k4843 
o|contracted procedure: k4873 
o|contracted procedure: k4846 
o|contracted procedure: k4891 
o|contracted procedure: k4913 
o|contracted procedure: k4916 
o|contracted procedure: k4922 
o|contracted procedure: k4933 
o|contracted procedure: k4988 
o|contracted procedure: k5005 
o|contracted procedure: k5034 
o|contracted procedure: k5038 
o|contracted procedure: k5030 
o|contracted procedure: k5026 
o|contracted procedure: k5022 
o|contracted procedure: k5018 
o|inlining procedure: k5002 
o|contracted procedure: k5048 
o|contracted procedure: k5063 
o|contracted procedure: k5059 
o|contracted procedure: k5055 
o|inlining procedure: k5002 
o|contracted procedure: k5082 
o|contracted procedure: k5078 
o|contracted procedure: k5074 
o|inlining procedure: k5002 
o|inlining procedure: k5094 
o|inlining procedure: k5094 
o|contracted procedure: k5113 
o|contracted procedure: k5120 
o|contracted procedure: k5123 
o|contracted procedure: k5138 
o|contracted procedure: k5143 
o|contracted procedure: k5158 
o|contracted procedure: k5154 
o|contracted procedure: k5150 
o|contracted procedure: k5166 
o|contracted procedure: k5173 
o|contracted procedure: k5184 
o|contracted procedure: k5180 
o|contracted procedure: k5170 
o|contracted procedure: k4964 
o|contracted procedure: k5134 
o|contracted procedure: k5130 
o|contracted procedure: k5211 
o|contracted procedure: k5214 
o|contracted procedure: k5217 
o|contracted procedure: k5225 
o|contracted procedure: k5233 
o|contracted procedure: k5252 
o|contracted procedure: k5258 
o|contracted procedure: k5551 
o|contracted procedure: k5281 
o|contracted procedure: k5287 
o|contracted procedure: k5294 
o|contracted procedure: k5303 
o|contracted procedure: k5319 
o|contracted procedure: k5325 
o|contracted procedure: k5338 
o|contracted procedure: k5350 
o|contracted procedure: k5356 
o|contracted procedure: k5370 
o|contracted procedure: k5379 
o|contracted procedure: k5398 
o|contracted procedure: k5404 
o|contracted procedure: k5411 
o|contracted procedure: k5417 
o|contracted procedure: k5428 
o|contracted procedure: k5424 
o|contracted procedure: k5434 
o|contracted procedure: k5448 
o|contracted procedure: k5444 
o|contracted procedure: k5466 
o|contracted procedure: k5475 
o|contracted procedure: k5482 
o|contracted procedure: k5488 
o|contracted procedure: k5498 
o|contracted procedure: k5510 
o|contracted procedure: k5516 
o|contracted procedure: k5523 
o|contracted procedure: k5534 
o|contracted procedure: k5547 
o|contracted procedure: k5579 
o|contracted procedure: k5587 
o|contracted procedure: k5583 
o|contracted procedure: k5599 
o|contracted procedure: k5607 
o|contracted procedure: k5610 
o|contracted procedure: k5620 
o|contracted procedure: k5626 
o|contracted procedure: k5633 
o|contracted procedure: k5617 
o|contracted procedure: k5678 
o|contracted procedure: k5642 
o|contracted procedure: k5668 
o|contracted procedure: k5672 
o|contracted procedure: k5664 
o|contracted procedure: k5645 
o|contracted procedure: k5648 
o|contracted procedure: k5656 
o|contracted procedure: k5660 
o|contracted procedure: k5690 
o|contracted procedure: k5693 
o|contracted procedure: k5696 
o|contracted procedure: k5708 
o|contracted procedure: k5711 
o|contracted procedure: k5714 
o|contracted procedure: k5722 
o|contracted procedure: k5730 
o|contracted procedure: k6598 
o|contracted procedure: k5745 
o|contracted procedure: k6592 
o|contracted procedure: k5748 
o|contracted procedure: k6586 
o|contracted procedure: k5751 
o|contracted procedure: k5760 
o|contracted procedure: k5769 
o|contracted procedure: k5784 
o|contracted procedure: k5799 
o|contracted procedure: k6102 
o|contracted procedure: k5826 
o|contracted procedure: k5901 
o|contracted procedure: k5844 
o|contracted procedure: k5865 
o|contracted procedure: k5878 
o|contracted procedure: k5881 
o|contracted procedure: k5888 
o|contracted procedure: k5915 
o|contracted procedure: k5929 
o|contracted procedure: k5911 
o|contracted procedure: k5940 
o|contracted procedure: k5979 
o|contracted procedure: k5982 
o|contracted procedure: k5990 
o|contracted procedure: k5994 
o|contracted procedure: k5998 
o|contracted procedure: k6006 
o|contracted procedure: k6010 
o|contracted procedure: k6014 
o|contracted procedure: k5955 
o|contracted procedure: k6020 
o|contracted procedure: k6026 
o|contracted procedure: k6038 
o|contracted procedure: k6060 
o|contracted procedure: k6056 
o|contracted procedure: k6041 
o|contracted procedure: k6044 
o|contracted procedure: k6052 
o|contracted procedure: k6072 
o|contracted procedure: k6079 
o|contracted procedure: k6099 
o|contracted procedure: k6136 
o|contracted procedure: k6132 
o|contracted procedure: k6128 
o|contracted procedure: k6151 
o|contracted procedure: k6173 
o|contracted procedure: k6169 
o|contracted procedure: k6154 
o|contracted procedure: k6157 
o|contracted procedure: k6165 
o|contracted procedure: k6295 
o|inlining procedure: k6201 
o|contracted procedure: k6252 
o|contracted procedure: k6208 
o|contracted procedure: k6227 
o|contracted procedure: k6223 
o|contracted procedure: k6219 
o|contracted procedure: k6240 
o|inlining procedure: k6201 
o|contracted procedure: k6291 
o|contracted procedure: k6258 
o|contracted procedure: k6285 
o|contracted procedure: k6264 
o|contracted procedure: k6280 
o|contracted procedure: k6270 
o|contracted procedure: k6580 
o|contracted procedure: k6316 
o|contracted procedure: k6575 
o|contracted procedure: k6320 
o|contracted procedure: k6566 
o|contracted procedure: k6350 
o|contracted procedure: k6469 
o|contracted procedure: k6465 
o|contracted procedure: k6409 
o|contracted procedure: k6423 
o|contracted procedure: k6459 
o|contracted procedure: k6433 
o|contracted procedure: k6455 
o|contracted procedure: k6449 
o|contracted procedure: k6445 
o|contracted procedure: k6437 
o|contracted procedure: k6441 
o|contracted procedure: k6395 
o|contracted procedure: k6369 
o|contracted procedure: k6377 
o|contracted procedure: k6391 
o|contracted procedure: k6384 
o|contracted procedure: k6381 
o|contracted procedure: k6398 
o|contracted procedure: k6513 
o|contracted procedure: k6497 
o|contracted procedure: k6509 
o|contracted procedure: k6501 
o|contracted procedure: k6505 
o|contracted procedure: k6530 
o|contracted procedure: k6562 
o|contracted procedure: k6536 
o|contracted procedure: k6548 
o|contracted procedure: k6558 
o|contracted procedure: k6572 
o|contracted procedure: k6604 
o|contracted procedure: k6686 
o|contracted procedure: k6663 
o|contracted procedure: k6682 
o|contracted procedure: k6625 
o|contracted procedure: k6637 
o|contracted procedure: k6646 
o|contracted procedure: k6654 
o|contracted procedure: k6650 
o|contracted procedure: k6738 
o|contracted procedure: k6704 
o|contracted procedure: k6713 
o|contracted procedure: k6732 
o|contracted procedure: k6728 
o|contracted procedure: k6724 
o|contracted procedure: k6821 
o|contracted procedure: k6852 
o|contracted procedure: k6878 
o|contracted procedure: k6890 
o|contracted procedure: k6970 
o|contracted procedure: k6914 
o|contracted procedure: k6929 
o|contracted procedure: k6949 
o|contracted procedure: k6966 
o|contracted procedure: k6774 
o|contracted procedure: k6783 
o|contracted procedure: k6811 
o|contracted procedure: k6789 
o|contracted procedure: k6979 
o|contracted procedure: k6997 
o|contracted procedure: k7004 
o|contracted procedure: k7015 
o|contracted procedure: k7476 
o|contracted procedure: k7030 
o|contracted procedure: k7470 
o|contracted procedure: k7033 
o|contracted procedure: k7455 
o|contracted procedure: k7039 
o|contracted procedure: k7096 
o|contracted procedure: k7105 
o|contracted procedure: k7118 
o|contracted procedure: k7125 
o|contracted procedure: k7152 
o|contracted procedure: k7161 
o|contracted procedure: k7181 
o|contracted procedure: k7184 
o|contracted procedure: k7187 
o|contracted procedure: k7269 
o|contracted procedure: k7190 
o|contracted procedure: k7205 
o|contracted procedure: k7211 
o|contracted procedure: k7224 
o|contracted procedure: k7228 
o|contracted procedure: k7231 
o|contracted procedure: k7254 
o|contracted procedure: k7250 
o|contracted procedure: k7257 
o|contracted procedure: k7263 
o|contracted procedure: k7278 
o|contracted procedure: k7291 
o|contracted procedure: k7297 
o|contracted procedure: k7303 
o|contracted procedure: k7309 
o|contracted procedure: k7318 
o|contracted procedure: k7327 
o|contracted procedure: k7336 
o|contracted procedure: k7345 
o|contracted procedure: k7354 
o|contracted procedure: k7363 
o|contracted procedure: k7385 
o|contracted procedure: k7388 
o|contracted procedure: k7451 
o|contracted procedure: k7447 
o|contracted procedure: k7439 
o|contracted procedure: k7443 
o|contracted procedure: k7461 
o|contracted procedure: k7491 
o|contracted procedure: k7503 
o|contracted procedure: k7524 
o|contracted procedure: k7648 
o|contracted procedure: k7544 
o|contracted procedure: k7572 
o|contracted procedure: k7597 
o|contracted procedure: k7593 
o|contracted procedure: k7608 
o|contracted procedure: k7604 
o|contracted procedure: k7627 
o|contracted procedure: k7623 
o|contracted procedure: k7644 
o|contracted procedure: k7640 
o|contracted procedure: k7660 
o|contracted procedure: k7666 
o|contracted procedure: k7689 
o|contracted procedure: k7695 
o|contracted procedure: k7698 
o|contracted procedure: k7745 
o|contracted procedure: k7704 
o|contracted procedure: k7716 
o|contracted procedure: k7719 
o|contracted procedure: k7726 
o|contracted procedure: k7734 
o|contracted procedure: k7738 
o|contracted procedure: k7873 
o|contracted procedure: k7753 
o|contracted procedure: k7775 
o|contracted procedure: k7781 
o|contracted procedure: k7793 
o|contracted procedure: k7805 
o|contracted procedure: k7817 
o|contracted procedure: k7830 
o|contracted procedure: k7833 
o|contracted procedure: k7845 
o|contracted procedure: k7894 
o|contracted procedure: k7910 
o|contracted procedure: k7900 
o|contracted procedure: k7919 
o|contracted procedure: k7940 
o|contracted procedure: k8027 
o|contracted procedure: k7995 
o|contracted procedure: k8109 
o|contracted procedure: k8134 
o|contracted procedure: k8130 
o|contracted procedure: k8154 
o|contracted procedure: k8150 
o|contracted procedure: k8171 
o|contracted procedure: k8157 
o|contracted procedure: k8164 
o|contracted procedure: k8353 
o|contracted procedure: k8433 
o|contracted procedure: k8429 
o|contracted procedure: k8361 
o|contracted procedure: k8365 
o|contracted procedure: k8357 
o|contracted procedure: k8349 
o|contracted procedure: k8373 
o|contracted procedure: k8376 
o|contracted procedure: k8391 
o|contracted procedure: k8387 
o|contracted procedure: k8383 
o|contracted procedure: k8400 
o|contracted procedure: k8403 
o|contracted procedure: k8406 
o|contracted procedure: k8414 
o|contracted procedure: k8422 
o|contracted procedure: k8445 
o|contracted procedure: k8448 
o|contracted procedure: k8455 
o|contracted procedure: k8459 
o|contracted procedure: k8484 
o|contracted procedure: k8490 
o|contracted procedure: k8497 
o|contracted procedure: k8508 
o|contracted procedure: k8514 
o|contracted procedure: k8529 
o|contracted procedure: k8525 
o|contracted procedure: k8521 
o|contracted procedure: k8544 
o|contracted procedure: k8595 
o|contracted procedure: k8555 
o|contracted procedure: k8567 
o|contracted procedure: k8563 
o|contracted procedure: k8559 
o|contracted procedure: k8551 
o|contracted procedure: k8583 
o|contracted procedure: k8589 
o|contracted procedure: k8601 
o|contracted procedure: k8640 
o|contracted procedure: k8612 
o|contracted procedure: k8624 
o|contracted procedure: k8620 
o|contracted procedure: k8616 
o|contracted procedure: k8608 
o|contracted procedure: k8632 
o|contracted procedure: k8646 
o|contracted procedure: k8660 
o|contracted procedure: k8656 
o|contracted procedure: k8671 
o|contracted procedure: k8667 
o|contracted procedure: k8674 
o|contracted procedure: k8697 
o|contracted procedure: k8799 
o|contracted procedure: k8795 
o|contracted procedure: k8705 
o|contracted procedure: k8791 
o|contracted procedure: k8787 
o|contracted procedure: k8713 
o|contracted procedure: k8779 
o|contracted procedure: k8783 
o|contracted procedure: k8721 
o|contracted procedure: k8772 
o|contracted procedure: k8761 
o|contracted procedure: k8729 
o|contracted procedure: k8737 
o|contracted procedure: k8733 
o|contracted procedure: k8725 
o|contracted procedure: k8717 
o|contracted procedure: k8709 
o|contracted procedure: k8701 
o|contracted procedure: k8693 
o|contracted procedure: k8753 
o|contracted procedure: k8757 
o|contracted procedure: k8749 
o|contracted procedure: k8745 
o|contracted procedure: k8803 
o|contracted procedure: k8807 
o|contracted procedure: k8816 
o|contracted procedure: k8822 
o|contracted procedure: k8829 
o|contracted procedure: k8901 
o|contracted procedure: k8842 
o|contracted procedure: k8893 
o|contracted procedure: k8845 
o|contracted procedure: k8860 
o|contracted procedure: k8864 
o|contracted procedure: k8879 
o|contracted procedure: k8890 
o|contracted procedure: k8886 
o|contracted procedure: k8876 
o|contracted procedure: k8907 
o|contracted procedure: k8924 
o|contracted procedure: k8930 
o|contracted procedure: k8936 
o|contracted procedure: k8947 
o|contracted procedure: k8956 
o|contracted procedure: k8959 
o|contracted procedure: k8975 
o|contracted procedure: k8968 
o|contracted procedure: k8982 
o|contracted procedure: k8994 
o|contracted procedure: k9003 
o|contracted procedure: k9021 
o|contracted procedure: k9045 
o|substituted constant variable: g13683 
o|contracted procedure: k9052 
o|contracted procedure: k9056 
o|contracted procedure: k9070 
o|contracted procedure: k9066 
o|contracted procedure: k9073 
o|contracted procedure: k9079 
o|contracted procedure: k9085 
o|contracted procedure: k9098 
o|contracted procedure: k9104 
o|contracted procedure: k9125 
o|contracted procedure: k9148 
o|contracted procedure: k9154 
o|contracted procedure: k9161 
o|contracted procedure: k9174 
o|contracted procedure: k9178 
o|contracted procedure: k9186 
o|contracted procedure: k9192 
o|contracted procedure: k9209 
o|contracted procedure: k9225 
o|contracted procedure: k9254 
o|contracted procedure: k9240 
o|contracted procedure: k9250 
o|contracted procedure: k9231 
o|contracted procedure: k9267 
o|contracted procedure: k9275 
o|contracted procedure: k9281 
o|contracted procedure: k9298 
o|contracted procedure: k9333 
o|contracted procedure: k9342 
o|contracted procedure: k9348 
o|contracted procedure: k9355 
o|contracted procedure: k9377 
o|contracted procedure: k9387 
o|contracted procedure: k9403 
o|contracted procedure: k9406 
o|contracted procedure: k9461 
o|contracted procedure: k9420 
o|contracted procedure: k9439 
o|contracted procedure: k9442 
o|contracted procedure: k9449 
o|contracted procedure: k9542 
o|contracted procedure: k9470 
o|contracted procedure: k9507 
o|contracted procedure: k9481 
o|contracted procedure: k9503 
o|contracted procedure: k9493 
o|contracted procedure: k9510 
o|contracted procedure: k9522 
o|contracted procedure: k9532 
o|contracted procedure: k9536 
o|contracted procedure: k9574 
o|contracted procedure: k9585 
o|contracted procedure: k9593 
o|contracted procedure: k9597 
o|contracted procedure: k9624 
o|contracted procedure: k9644 
o|contracted procedure: k9654 
o|contracted procedure: k9650 
o|contracted procedure: k9664 
o|contracted procedure: k9679 
o|contracted procedure: k9682 
o|contracted procedure: k9688 
o|contracted procedure: k9694 
o|contracted procedure: k9727 
o|contracted procedure: k9723 
o|contracted procedure: k9719 
o|contracted procedure: k9707 
o|contracted procedure: k9715 
o|contracted procedure: k9711 
o|contracted procedure: k9748 
o|contracted procedure: k9764 
o|contracted procedure: k9760 
o|contracted procedure: k9812 
o|contracted procedure: k9772 
o|contracted procedure: k9776 
o|contracted procedure: k9793 
o|contracted procedure: k9789 
o|contracted procedure: k9779 
o|contracted procedure: k9796 
o|contracted procedure: k9802 
o|contracted procedure: k9820 
o|contracted procedure: k9823 
o|contracted procedure: k9834 
o|contracted procedure: k9860 
o|contracted procedure: k9852 
o|contracted procedure: k9870 
o|contracted procedure: k9883 
o|contracted procedure: k9896 
o|contracted procedure: k9918 
o|contracted procedure: k9927 
o|contracted procedure: k10051 
o|contracted procedure: k9946 
o|contracted procedure: k9956 
o|contracted procedure: k9965 
o|contracted procedure: k9978 
o|contracted procedure: k10027 
o|contracted procedure: k10003 
o|contracted procedure: k10016 
o|contracted procedure: k10044 
o|contracted procedure: k10063 
o|contracted procedure: k10070 
o|contracted procedure: k10078 
o|contracted procedure: k10090 
o|contracted procedure: k10112 
o|contracted procedure: k10108 
o|contracted procedure: k10093 
o|contracted procedure: k10096 
o|contracted procedure: k10104 
o|contracted procedure: k10178 
o|contracted procedure: k10127 
o|contracted procedure: k10174 
o|contracted procedure: k10140 
o|contracted procedure: k10153 
o|contracted procedure: k10199 
o|contracted procedure: k10195 
o|contracted procedure: k10232 
o|contracted procedure: k10228 
o|contracted procedure: k10224 
o|contracted procedure: k10220 
o|contracted procedure: k10267 
o|contracted procedure: k10421 
o|contracted procedure: k10290 
o|contracted procedure: k10303 
o|contracted procedure: k10316 
o|contracted procedure: k10324 
o|contracted procedure: k10337 
o|contracted procedure: k10345 
o|contracted procedure: k10357 
o|contracted procedure: k10367 
o|contracted procedure: k10386 
o|contracted procedure: k10378 
o|contracted procedure: k10394 
o|contracted procedure: k10398 
o|contracted procedure: k10412 
o|contracted procedure: k10447 
o|contracted procedure: k10443 
o|contracted procedure: k10439 
o|contracted procedure: k10461 
o|contracted procedure: k10492 
o|contracted procedure: k10467 
o|contracted procedure: k10488 
o|contracted procedure: k10482 
o|contracted procedure: k10478 
o|contracted procedure: k10474 
o|contracted procedure: k10510 
o|contracted procedure: k10523 
o|contracted procedure: k10536 
o|contracted procedure: k10539 
o|contracted procedure: k10552 
o|contracted procedure: k10570 
o|contracted procedure: k10581 
o|contracted procedure: k10682 
o|contracted procedure: k10586 
o|contracted procedure: k10606 
o|contracted procedure: k10602 
o|contracted procedure: k10598 
o|contracted procedure: k10590 
o|contracted procedure: k10577 
o|contracted procedure: k10644 
o|contracted procedure: k10647 
o|contracted procedure: k10650 
o|contracted procedure: k10658 
o|contracted procedure: k10666 
o|contracted procedure: k10632 
o|contracted procedure: k10628 
o|contracted procedure: k10614 
o|contracted procedure: k10622 
o|contracted procedure: k10672 
o|contracted procedure: k10679 
o|contracted procedure: k10694 
o|contracted procedure: k10697 
o|contracted procedure: k10700 
o|contracted procedure: k10708 
o|contracted procedure: k10716 
o|contracted procedure: k10561 
o|contracted procedure: k10565 
o|contracted procedure: k10732 
o|contracted procedure: k10746 
o|contracted procedure: k10753 
o|contracted procedure: k10770 
o|contracted procedure: k10760 
o|contracted procedure: k10783 
o|contracted procedure: k10995 
o|contracted procedure: k10807 
o|contracted procedure: k10991 
o|contracted procedure: k10823 
o|contracted procedure: k10862 
o|contracted procedure: k10869 
o|contracted procedure: k10883 
o|contracted procedure: k10872 
o|contracted procedure: k10879 
o|contracted procedure: k10933 
o|contracted procedure: k10942 
o|contracted procedure: k10946 
o|contracted procedure: k10890 
o|contracted procedure: k10908 
o|contracted procedure: k10915 
o|contracted procedure: k10929 
o|contracted procedure: k10918 
o|contracted procedure: k10925 
o|contracted procedure: k10958 
o|contracted procedure: k10961 
o|contracted procedure: k10964 
o|contracted procedure: k10972 
o|contracted procedure: k10980 
o|contracted procedure: k10987 
o|contracted procedure: k11005 
o|contracted procedure: k11367 
o|contracted procedure: k11029 
o|contracted procedure: k11090 
o|contracted procedure: k11108 
o|contracted procedure: k11098 
o|contracted procedure: k11122 
o|contracted procedure: k11111 
o|contracted procedure: k11118 
o|contracted procedure: k11134 
o|contracted procedure: k11183 
o|contracted procedure: k11179 
o|contracted procedure: k11159 
o|contracted procedure: k11175 
o|contracted procedure: k11167 
o|contracted procedure: k11163 
o|contracted procedure: k11231 
o|contracted procedure: k11199 
o|contracted procedure: k11227 
o|contracted procedure: k11211 
o|contracted procedure: k11223 
o|contracted procedure: k11215 
o|contracted procedure: k11207 
o|contracted procedure: k11203 
o|contracted procedure: k11238 
o|contracted procedure: k11242 
o|contracted procedure: k11251 
o|contracted procedure: k11258 
o|contracted procedure: k11274 
o|contracted procedure: k11263 
o|contracted procedure: k11270 
o|contracted procedure: k11279 
o|contracted procedure: k11285 
o|contracted procedure: k11291 
o|contracted procedure: k11297 
o|contracted procedure: k11303 
o|contracted procedure: k11315 
o|contracted procedure: k11330 
o|contracted procedure: k11341 
o|contracted procedure: k11363 
o|contracted procedure: k11377 
o|contracted procedure: k11383 
o|contracted procedure: k11386 
o|contracted procedure: k11393 
o|contracted procedure: k11419 
o|contracted procedure: k11403 
o|contracted procedure: k11411 
o|contracted procedure: k11407 
o|contracted procedure: k11429 
o|contracted procedure: k11435 
o|contracted procedure: k11438 
o|contracted procedure: k11445 
o|contracted procedure: k11452 
o|contracted procedure: k11469 
o|contracted procedure: k11472 
o|contracted procedure: k11478 
o|contracted procedure: k11485 
o|contracted procedure: k11495 
o|contracted procedure: k11522 
o|contracted procedure: k11544 
o|contracted procedure: k11566 
o|contracted procedure: k11588 
o|contracted procedure: k11616 
o|contracted procedure: k11626 
o|contracted procedure: k11640 
o|contracted procedure: k11629 
o|contracted procedure: k11636 
o|contracted procedure: k11650 
o|contracted procedure: k11743 
o|contracted procedure: k11725 
o|contracted procedure: k11721 
o|contracted procedure: k11717 
o|contracted procedure: k11739 
o|contracted procedure: k11730 
o|contracted procedure: k11672 
o|contracted procedure: k11685 
o|contracted procedure: k11762 
o|contracted procedure: k11862 
o|contracted procedure: k11858 
o|contracted procedure: k11818 
o|contracted procedure: k11842 
o|contracted procedure: k11852 
o|contracted procedure: k11848 
o|contracted procedure: k11838 
o|contracted procedure: k11781 
o|contracted procedure: k11797 
o|contracted procedure: k11879 
o|contracted procedure: k11896 
o|contracted procedure: k11913 
o|contracted procedure: k11930 
o|contracted procedure: k11947 
o|simplifications: ((let . 185)) 
o|replaced variables: 2 
o|removed binding forms: 852 
o|inlining procedure: k5162 
o|inlining procedure: k5162 
o|inlining procedure: k6205 
o|inlining procedure: k6373 
o|inlining procedure: k6373 
o|inlining procedure: k9768 
o|inlining procedure: k9768 
o|inlining procedure: k11678 
o|replaced variables: 187 
o|removed binding forms: 6 
o|simplifications: ((let . 1) (if . 2)) 
o|replaced variables: 4 
o|removed binding forms: 110 
o|contracted procedure: k10712 
o|replaced variables: 4 
o|removed binding forms: 4 
o|removed binding forms: 2 
o|direct leaf routine/allocation: lookup 0 
o|direct leaf routine/allocation: g509510 0 
o|direct leaf routine/allocation: g12351236 0 
o|direct leaf routine/allocation: g13261327 0 
o|direct leaf routine/allocation: loop1379 0 
o|direct leaf routine/allocation: g15661567 0 
o|direct leaf routine/allocation: g15751576 0 
o|direct leaf routine/allocation: assq-reverse1442 0 
o|direct leaf routine/allocation: g20162025 15 
o|contracted procedure: "(expand.scm:92) k3709" 
o|contracted procedure: "(expand.scm:168) k4203" 
o|contracted procedure: "(expand.scm:180) k4239" 
o|contracted procedure: "(expand.scm:184) k4255" 
o|contracted procedure: "(expand.scm:186) k4264" 
o|contracted procedure: "(expand.scm:271) k4599" 
o|contracted procedure: "(expand.scm:273) k4816" 
o|contracted procedure: "(expand.scm:473) k5757" 
o|converted assignments to bindings: (loop1379) 
o|contracted procedure: "(expand.scm:815) k7561" 
o|contracted procedure: "(expand.scm:876) k7858" 
o|contracted procedure: "(expand.scm:876) k7864" 
o|contracted procedure: "(expand.scm:895) k7960" 
o|contracted procedure: "(expand.scm:896) k7963" 
o|contracted procedure: "(expand.scm:1247) k10976" 
o|simplifications: ((let . 1) (if . 2)) 
o|removed binding forms: 14 
o|contracted procedure: "(expand.scm:786) k7375" 
o|replaced variables: 12 
o|removed binding forms: 1 
o|removed binding forms: 6 
o|direct leaf routine/allocation: comp993 0 
o|contracted procedure: "(expand.scm:491) k5891" 
o|contracted procedure: "(expand.scm:560) k6338" 
o|contracted procedure: "(expand.scm:587) k6475" 
o|contracted procedure: "(expand.scm:590) k6487" 
o|contracted procedure: "(expand.scm:594) k6519" 
o|simplifications: ((if . 1)) 
o|removed binding forms: 5 
o|replaced variables: 6 
o|removed binding forms: 1 
o|customizable procedures: (loop1726 k11606 check-for-multiple-bindings expand1891 map-loop20102031 k10894 expand1986 expand2053 map-loop20752093 k10594 k10662 map-loop21092127 match-expression g22042205 g21972198 walk2141 walk12142 simplify2143 expand2269 map-loop22772295 err2241 test2242 k9782 g27492756 for-each-loop27482759 loop2726 loop2655 k9059 k9012 doloop26042605 k8649 k8442 map-loop24702487 k8118 loop1789 mirror-rename1443 k7761 k7769 doloop15111512 g14581459 k7583 k7169 test1351 k7193 walk1389 doloop14041405 loop1365 err1352 loop1269 loop1282 loop1299 outstr1280 loop1246 mwalk1222 k6323 fini/syntax995 loop1176 loop21192 k6191 loop1126 map-loop11391156 fini994 foldl10541058 map-loop10311070 k5976 map-loop10791106 k5850 loop1014 expand996 map-loop902919 map-loop931955 k5284 k5460 k5373 k5331 k5334 macro-alias k5297 loop778 err767 g800809 map-loop794822 k4999 k5011 k4925 loop745 loop731 k4605 k4760 g698699 loop611 expand555 map-loop638656 map-loop665682 call-handler554 tmp13092 tmp23093 k4377 k4411 copy574 loop540 k4124 loop468 g465466 loop1453 map-loop355372 for-each-loop381408 map-loop418439 doloop331332 walk301 k3703) 
o|calls to known targets: 361 
o|identified direct recursive calls: f_3759 1 
o|identified direct recursive calls: f_3936 1 
o|identified direct recursive calls: f_3984 1 
o|identified direct recursive calls: f_4301 1 
o|identified direct recursive calls: f_4655 1 
o|identified direct recursive calls: f_4724 1 
o|identified direct recursive calls: f_4983 2 
o|identified direct recursive calls: f_5637 1 
o|identified direct recursive calls: f_6033 1 
o|identified direct recursive calls: f_6146 1 
o|identified direct recursive calls: f_6119 1 
o|identified direct recursive calls: f_6617 1 
o|identified direct recursive calls: f_6699 1 
o|identified direct recursive calls: f_6778 1 
o|identified direct recursive calls: f_7150 1 
o|identified direct recursive calls: f_7176 1 
o|identified direct recursive calls: f_7498 1 
o|identified direct recursive calls: f_7652 1 
o|identified direct recursive calls: f_7889 1 
o|identified direct recursive calls: f_7914 1 
o|identified direct recursive calls: f_9040 1 
o|identified direct recursive calls: f_9434 1 
o|identified direct recursive calls: f_10085 1 
o|identified direct recursive calls: f_10689 1 
o|identified direct recursive calls: f_10741 1 
o|identified direct recursive calls: f_10953 1 
o|fast box initializations: 69 
o|fast global references: 32 
o|fast global assignments: 4 
o|dropping unused closure argument: f_7150 
o|dropping unused closure argument: f_3678 
o|dropping unused closure argument: f_3695 
o|dropping unused closure argument: f_6614 
o|dropping unused closure argument: f_7889 
o|dropping unused closure argument: f_8101 
*/
/* end of file */
