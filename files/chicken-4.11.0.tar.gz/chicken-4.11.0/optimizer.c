/* Generated from optimizer.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:50
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: optimizer.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -extend private-namespace.scm -no-trace -output-file optimizer.c
   unit: optimizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[229];
static double C_possibly_force_alignment;


C_noret_decl(f_10689)
static void C_ccall f_10689(C_word c,C_word *av) C_noret;
C_noret_decl(f_10683)
static void C_ccall f_10683(C_word c,C_word *av) C_noret;
C_noret_decl(f_10685)
static void C_fcall f_10685(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_5845)
static void C_ccall f_5845(C_word c,C_word *av) C_noret;
C_noret_decl(f_11138)
static void C_ccall f_11138(C_word c,C_word *av) C_noret;
C_noret_decl(f_11132)
static void C_ccall f_11132(C_word c,C_word *av) C_noret;
C_noret_decl(f_11135)
static void C_ccall f_11135(C_word c,C_word *av) C_noret;
C_noret_decl(f_10676)
static void C_ccall f_10676(C_word c,C_word *av) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word *av) C_noret;
C_noret_decl(f_4795)
static void C_ccall f_4795(C_word c,C_word *av) C_noret;
C_noret_decl(f_6537)
static void C_fcall f_6537(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6530)
static void C_ccall f_6530(C_word c,C_word *av) C_noret;
C_noret_decl(f_6533)
static C_word C_fcall f_6533(C_word t0);
C_noret_decl(f_4760)
static void C_fcall f_4760(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5755)
static void C_ccall f_5755(C_word c,C_word *av) C_noret;
C_noret_decl(f_5752)
static void C_ccall f_5752(C_word c,C_word *av) C_noret;
C_noret_decl(f_4785)
static void C_ccall f_4785(C_word c,C_word *av) C_noret;
C_noret_decl(f_9647)
static void C_ccall f_9647(C_word c,C_word *av) C_noret;
C_noret_decl(f_4305)
static void C_fcall f_4305(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word *av) C_noret;
C_noret_decl(f_12326)
static void C_ccall f_12326(C_word c,C_word *av) C_noret;
C_noret_decl(f_12786)
static void C_ccall f_12786(C_word c,C_word *av) C_noret;
C_noret_decl(f_12322)
static void C_ccall f_12322(C_word c,C_word *av) C_noret;
C_noret_decl(f_9719)
static void C_ccall f_9719(C_word c,C_word *av) C_noret;
C_noret_decl(f_11830)
static void C_ccall f_11830(C_word c,C_word *av) C_noret;
C_noret_decl(f_12314)
static void C_ccall f_12314(C_word c,C_word *av) C_noret;
C_noret_decl(f_10643)
static void C_ccall f_10643(C_word c,C_word *av) C_noret;
C_noret_decl(f_11819)
static void C_ccall f_11819(C_word c,C_word *av) C_noret;
C_noret_decl(f_11814)
static void C_ccall f_11814(C_word c,C_word *av) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547(C_word c,C_word *av) C_noret;
C_noret_decl(f_4543)
static void C_fcall f_4543(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word *av) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word *av) C_noret;
C_noret_decl(f_4551)
static void C_fcall f_4551(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7809)
static void C_ccall f_7809(C_word c,C_word *av) C_noret;
C_noret_decl(f_4563)
static void C_fcall f_4563(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12380)
static void C_fcall f_12380(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12378)
static void C_ccall f_12378(C_word c,C_word *av) C_noret;
C_noret_decl(f_10426)
static void C_ccall f_10426(C_word c,C_word *av) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word *av) C_noret;
C_noret_decl(f_7392)
static void C_fcall f_7392(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4350)
static void C_fcall f_4350(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7382)
static void C_fcall f_7382(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7379)
static void C_ccall f_7379(C_word c,C_word *av) C_noret;
C_noret_decl(f_6376)
static void C_ccall f_6376(C_word c,C_word *av) C_noret;
C_noret_decl(f_7373)
static void C_ccall f_7373(C_word c,C_word *av) C_noret;
C_noret_decl(f_6382)
static void C_ccall f_6382(C_word c,C_word *av) C_noret;
C_noret_decl(f_7363)
static void C_ccall f_7363(C_word c,C_word *av) C_noret;
C_noret_decl(f_10479)
static void C_fcall f_10479(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6389)
static void C_fcall f_6389(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7357)
static void C_ccall f_7357(C_word c,C_word *av) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359(C_word c,C_word *av) C_noret;
C_noret_decl(f_13428)
static void C_ccall f_13428(C_word c,C_word *av) C_noret;
C_noret_decl(f_6351)
static void C_fcall f_6351(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10986)
static void C_ccall f_10986(C_word c,C_word *av) C_noret;
C_noret_decl(f_7876)
static void C_ccall f_7876(C_word c,C_word *av) C_noret;
C_noret_decl(f_13419)
static void C_ccall f_13419(C_word c,C_word *av) C_noret;
C_noret_decl(f_6361)
static void C_ccall f_6361(C_word c,C_word *av) C_noret;
C_noret_decl(f_13415)
static void C_ccall f_13415(C_word c,C_word *av) C_noret;
C_noret_decl(f_13411)
static void C_ccall f_13411(C_word c,C_word *av) C_noret;
C_noret_decl(f_8890)
static void C_ccall f_8890(C_word c,C_word *av) C_noret;
C_noret_decl(f_12057)
static void C_ccall f_12057(C_word c,C_word *av) C_noret;
C_noret_decl(f_8886)
static void C_ccall f_8886(C_word c,C_word *av) C_noret;
C_noret_decl(f_10484)
static void C_ccall f_10484(C_word c,C_word *av) C_noret;
C_noret_decl(f_12989)
static void C_ccall f_12989(C_word c,C_word *av) C_noret;
C_noret_decl(f_12080)
static void C_fcall f_12080(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3953)
static void C_ccall f_3953(C_word c,C_word *av) C_noret;
C_noret_decl(f_10437)
static void C_ccall f_10437(C_word c,C_word *av) C_noret;
C_noret_decl(f_10432)
static void C_fcall f_10432(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6592)
static void C_fcall f_6592(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12070)
static void C_fcall f_12070(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7480)
static void C_fcall f_7480(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9975)
static void C_ccall f_9975(C_word c,C_word *av) C_noret;
C_noret_decl(f_7307)
static void C_fcall f_7307(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9978)
static void C_fcall f_9978(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9485)
static void C_ccall f_9485(C_word c,C_word *av) C_noret;
C_noret_decl(f_7477)
static void C_ccall f_7477(C_word c,C_word *av) C_noret;
C_noret_decl(f_10973)
static void C_ccall f_10973(C_word c,C_word *av) C_noret;
C_noret_decl(f_6565)
static void C_fcall f_6565(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6564)
static void C_ccall f_6564(C_word c,C_word *av) C_noret;
C_noret_decl(f_6936)
static void C_fcall f_6936(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6935)
static void C_ccall f_6935(C_word c,C_word *av) C_noret;
C_noret_decl(f_9473)
static void C_ccall f_9473(C_word c,C_word *av) C_noret;
C_noret_decl(f_10963)
static void C_fcall f_10963(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6932)
static void C_ccall f_6932(C_word c,C_word *av) C_noret;
C_noret_decl(f_6305)
static void C_ccall f_6305(C_word c,C_word *av) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word *av) C_noret;
C_noret_decl(f_6286)
static void C_fcall f_6286(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6923)
static void C_fcall f_6923(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13210)
static void C_ccall f_13210(C_word c,C_word *av) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word *av) C_noret;
C_noret_decl(f_6583)
static void C_ccall f_6583(C_word c,C_word *av) C_noret;
C_noret_decl(f_8864)
static void C_ccall f_8864(C_word c,C_word *av) C_noret;
C_noret_decl(f_13204)
static void C_ccall f_13204(C_word c,C_word *av) C_noret;
C_noret_decl(f_10060)
static void C_ccall f_10060(C_word c,C_word *av) C_noret;
C_noret_decl(f_13364)
static void C_ccall f_13364(C_word c,C_word *av) C_noret;
C_noret_decl(f_6345)
static void C_fcall f_6345(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_9428)
static void C_ccall f_9428(C_word c,C_word *av) C_noret;
C_noret_decl(f_8957)
static void C_ccall f_8957(C_word c,C_word *av) C_noret;
C_noret_decl(f_6317)
static void C_ccall f_6317(C_word c,C_word *av) C_noret;
C_noret_decl(f_8538)
static void C_fcall f_8538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6313)
static void C_ccall f_6313(C_word c,C_word *av) C_noret;
C_noret_decl(f_6252)
static void C_ccall f_6252(C_word c,C_word *av) C_noret;
C_noret_decl(f_7407)
static void C_ccall f_7407(C_word c,C_word *av) C_noret;
C_noret_decl(f_7198)
static void C_ccall f_7198(C_word c,C_word *av) C_noret;
C_noret_decl(f_6328)
static void C_ccall f_6328(C_word c,C_word *av) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word *av) C_noret;
C_noret_decl(f_10630)
static void C_ccall f_10630(C_word c,C_word *av) C_noret;
C_noret_decl(f_13277)
static void C_ccall f_13277(C_word c,C_word *av) C_noret;
C_noret_decl(f_9461)
static void C_ccall f_9461(C_word c,C_word *av) C_noret;
C_noret_decl(f_9463)
static void C_ccall f_9463(C_word c,C_word *av) C_noret;
C_noret_decl(f_13273)
static void C_ccall f_13273(C_word c,C_word *av) C_noret;
C_noret_decl(f_12017)
static void C_fcall f_12017(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6276)
static void C_ccall f_6276(C_word c,C_word *av) C_noret;
C_noret_decl(f_13269)
static void C_ccall f_13269(C_word c,C_word *av) C_noret;
C_noret_decl(f_8528)
static void C_ccall f_8528(C_word c,C_word *av) C_noret;
C_noret_decl(f_6208)
static void C_ccall f_6208(C_word c,C_word *av) C_noret;
C_noret_decl(f_10619)
static void C_ccall f_10619(C_word c,C_word *av) C_noret;
C_noret_decl(f_13290)
static void C_ccall f_13290(C_word c,C_word *av) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word *av) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word *av) C_noret;
C_noret_decl(f_6210)
static void C_fcall f_6210(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word *av) C_noret;
C_noret_decl(f_7442)
static void C_fcall f_7442(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7150)
static void C_ccall f_7150(C_word c,C_word *av) C_noret;
C_noret_decl(f_7152)
static void C_ccall f_7152(C_word c,C_word *av) C_noret;
C_noret_decl(f_8980)
static void C_ccall f_8980(C_word c,C_word *av) C_noret;
C_noret_decl(f_12833)
static void C_ccall f_12833(C_word c,C_word *av) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220(C_word c,C_word *av) C_noret;
C_noret_decl(f_5259)
static void C_ccall f_5259(C_word c,C_word *av) C_noret;
C_noret_decl(f_5256)
static void C_ccall f_5256(C_word c,C_word *av) C_noret;
C_noret_decl(f_6234)
static void C_ccall f_6234(C_word c,C_word *av) C_noret;
C_noret_decl(f_6235)
static void C_ccall f_6235(C_word c,C_word *av) C_noret;
C_noret_decl(f_13098)
static void C_ccall f_13098(C_word c,C_word *av) C_noret;
C_noret_decl(f_13090)
static void C_ccall f_13090(C_word c,C_word *av) C_noret;
C_noret_decl(f_7120)
static void C_ccall f_7120(C_word c,C_word *av) C_noret;
C_noret_decl(f_5242)
static void C_fcall f_5242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5245)
static void C_ccall f_5245(C_word c,C_word *av) C_noret;
C_noret_decl(f_5246)
static void C_fcall f_5246(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word *av) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word *av) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word *av) C_noret;
C_noret_decl(f_6837)
static void C_ccall f_6837(C_word c,C_word *av) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word *av) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980(C_word c,C_word *av) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word *av) C_noret;
C_noret_decl(f_6816)
static void C_ccall f_6816(C_word c,C_word *av) C_noret;
C_noret_decl(f_12885)
static void C_fcall f_12885(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13016)
static void C_fcall f_13016(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12875)
static void C_ccall f_12875(C_word c,C_word *av) C_noret;
C_noret_decl(f_12027)
static void C_ccall f_12027(C_word c,C_word *av) C_noret;
C_noret_decl(f_4175)
static C_word C_fcall f_4175(C_word t0);
C_noret_decl(f_4179)
static void C_fcall f_4179(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108(C_word c,C_word *av) C_noret;
C_noret_decl(f_12047)
static void C_fcall f_12047(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11227)
static void C_ccall f_11227(C_word c,C_word *av) C_noret;
C_noret_decl(f_11224)
static void C_ccall f_11224(C_word c,C_word *av) C_noret;
C_noret_decl(f_8699)
static void C_ccall f_8699(C_word c,C_word *av) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word *av) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word *av) C_noret;
C_noret_decl(f_7935)
static void C_ccall f_7935(C_word c,C_word *av) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word *av) C_noret;
C_noret_decl(f_8654)
static void C_ccall f_8654(C_word c,C_word *av) C_noret;
C_noret_decl(f_8650)
static void C_ccall f_8650(C_word c,C_word *av) C_noret;
C_noret_decl(f_5208)
static void C_fcall f_5208(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5711)
static void C_ccall f_5711(C_word c,C_word *av) C_noret;
C_noret_decl(f_8684)
static void C_ccall f_8684(C_word c,C_word *av) C_noret;
C_noret_decl(f_5224)
static void C_ccall f_5224(C_word c,C_word *av) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word *av) C_noret;
C_noret_decl(f_10054)
static void C_ccall f_10054(C_word c,C_word *av) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word *av) C_noret;
C_noret_decl(f_10048)
static void C_ccall f_10048(C_word c,C_word *av) C_noret;
C_noret_decl(f_5737)
static void C_ccall f_5737(C_word c,C_word *av) C_noret;
C_noret_decl(f_7764)
static void C_ccall f_7764(C_word c,C_word *av) C_noret;
C_noret_decl(f_9905)
static void C_ccall f_9905(C_word c,C_word *av) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word *av) C_noret;
C_noret_decl(f_4139)
static void C_fcall f_4139(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word *av) C_noret;
C_noret_decl(f_4136)
static void C_ccall f_4136(C_word c,C_word *av) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word *av) C_noret;
C_noret_decl(f_5281)
static void C_ccall f_5281(C_word c,C_word *av) C_noret;
C_noret_decl(f_5284)
static void C_ccall f_5284(C_word c,C_word *av) C_noret;
C_noret_decl(f_11287)
static void C_fcall f_11287(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word *av) C_noret;
C_noret_decl(f_5274)
static void C_ccall f_5274(C_word c,C_word *av) C_noret;
C_noret_decl(f_11297)
static void C_ccall f_11297(C_word c,C_word *av) C_noret;
C_noret_decl(f_11275)
static void C_ccall f_11275(C_word c,C_word *av) C_noret;
C_noret_decl(f_7829)
static void C_ccall f_7829(C_word c,C_word *av) C_noret;
C_noret_decl(f_5992)
static void C_ccall f_5992(C_word c,C_word *av) C_noret;
C_noret_decl(f_7837)
static void C_ccall f_7837(C_word c,C_word *av) C_noret;
C_noret_decl(f_12227)
static void C_ccall f_12227(C_word c,C_word *av) C_noret;
C_noret_decl(f_12219)
static void C_ccall f_12219(C_word c,C_word *av) C_noret;
C_noret_decl(f_12242)
static void C_ccall f_12242(C_word c,C_word *av) C_noret;
C_noret_decl(f_13535)
static void C_ccall f_13535(C_word c,C_word *av) C_noret;
C_noret_decl(f_4629)
static void C_ccall f_4629(C_word c,C_word *av) C_noret;
C_noret_decl(f_7983)
static void C_ccall f_7983(C_word c,C_word *av) C_noret;
C_noret_decl(f_5979)
static void C_ccall f_5979(C_word c,C_word *av) C_noret;
C_noret_decl(f_6640)
static void C_ccall f_6640(C_word c,C_word *av) C_noret;
C_noret_decl(f_6643)
static void C_ccall f_6643(C_word c,C_word *av) C_noret;
C_noret_decl(f_8075)
static void C_ccall f_8075(C_word c,C_word *av) C_noret;
C_noret_decl(f_4603)
static void C_ccall f_4603(C_word c,C_word *av) C_noret;
C_noret_decl(f_4609)
static void C_ccall f_4609(C_word c,C_word *av) C_noret;
C_noret_decl(f_11543)
static void C_fcall f_11543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6633)
static void C_fcall f_6633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6646)
static void C_ccall f_6646(C_word c,C_word *av) C_noret;
C_noret_decl(f_9878)
static void C_ccall f_9878(C_word c,C_word *av) C_noret;
C_noret_decl(f_9882)
static void C_ccall f_9882(C_word c,C_word *av) C_noret;
C_noret_decl(f_5678)
static void C_ccall f_5678(C_word c,C_word *av) C_noret;
C_noret_decl(f_5691)
static void C_ccall f_5691(C_word c,C_word *av) C_noret;
C_noret_decl(f_12290)
static void C_ccall f_12290(C_word c,C_word *av) C_noret;
C_noret_decl(f_4193)
static C_word C_fcall f_4193(C_word t0);
C_noret_decl(f_6183)
static void C_ccall f_6183(C_word c,C_word *av) C_noret;
C_noret_decl(f_12294)
static void C_ccall f_12294(C_word c,C_word *av) C_noret;
C_noret_decl(f_8176)
static void C_ccall f_8176(C_word c,C_word *av) C_noret;
C_noret_decl(f_8714)
static void C_fcall f_8714(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8718)
static void C_ccall f_8718(C_word c,C_word *av) C_noret;
C_noret_decl(f_9858)
static void C_fcall f_9858(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9852)
static void C_ccall f_9852(C_word c,C_word *av) C_noret;
C_noret_decl(f_3906)
static void C_fcall f_3906(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word *av) C_noret;
C_noret_decl(f_8150)
static void C_ccall f_8150(C_word c,C_word *av) C_noret;
C_noret_decl(f_4465)
static void C_ccall f_4465(C_word c,C_word *av) C_noret;
C_noret_decl(f_4461)
static void C_fcall f_4461(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12260)
static void C_fcall f_12260(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6177)
static void C_fcall f_6177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11529)
static void C_fcall f_11529(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12254)
static void C_ccall f_12254(C_word c,C_word *av) C_noret;
C_noret_decl(f_12250)
static void C_ccall f_12250(C_word c,C_word *av) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word *av) C_noret;
C_noret_decl(f_7280)
static void C_ccall f_7280(C_word c,C_word *av) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word *av) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word *av) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word *av) C_noret;
C_noret_decl(f_6151)
static void C_ccall f_6151(C_word c,C_word *av) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938(C_word c,C_word *av) C_noret;
C_noret_decl(f_8108)
static void C_ccall f_8108(C_word c,C_word *av) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134(C_word c,C_word *av) C_noret;
C_noret_decl(f_7257)
static void C_ccall f_7257(C_word c,C_word *av) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word *av) C_noret;
C_noret_decl(f_6103)
static void C_ccall f_6103(C_word c,C_word *av) C_noret;
C_noret_decl(f_7247)
static void C_fcall f_7247(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7743)
static void C_ccall f_7743(C_word c,C_word *av) C_noret;
C_noret_decl(f_7270)
static void C_fcall f_7270(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7717)
static void C_fcall f_7717(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6160)
static void C_ccall f_6160(C_word c,C_word *av) C_noret;
C_noret_decl(f_10830)
static void C_ccall f_10830(C_word c,C_word *av) C_noret;
C_noret_decl(f_7636)
static void C_ccall f_7636(C_word c,C_word *av) C_noret;
C_noret_decl(f_10887)
static void C_ccall f_10887(C_word c,C_word *av) C_noret;
C_noret_decl(f_10819)
static void C_ccall f_10819(C_word c,C_word *av) C_noret;
C_noret_decl(f_10816)
static void C_ccall f_10816(C_word c,C_word *av) C_noret;
C_noret_decl(f_10874)
static void C_ccall f_10874(C_word c,C_word *av) C_noret;
C_noret_decl(f_7708)
static void C_ccall f_7708(C_word c,C_word *av) C_noret;
C_noret_decl(f_7234)
static void C_ccall f_7234(C_word c,C_word *av) C_noret;
C_noret_decl(f_10864)
static void C_fcall f_10864(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7224)
static void C_fcall f_7224(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8116)
static void C_ccall f_8116(C_word c,C_word *av) C_noret;
C_noret_decl(f_10216)
static void C_fcall f_10216(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10213)
static void C_fcall f_10213(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_10859)
static void C_ccall f_10859(C_word c,C_word *av) C_noret;
C_noret_decl(f_11691)
static void C_ccall f_11691(C_word c,C_word *av) C_noret;
C_noret_decl(f_11697)
static void C_ccall f_11697(C_word c,C_word *av) C_noret;
C_noret_decl(f_10280)
static void C_ccall f_10280(C_word c,C_word *av) C_noret;
C_noret_decl(f_3783)
static C_word C_fcall f_3783(C_word t0);
C_noret_decl(f_11088)
static void C_ccall f_11088(C_word c,C_word *av) C_noret;
C_noret_decl(f_11085)
static void C_ccall f_11085(C_word c,C_word *av) C_noret;
C_noret_decl(f_3788)
static void C_fcall f_3788(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11082)
static void C_ccall f_11082(C_word c,C_word *av) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word *av) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080(C_word c,C_word *av) C_noret;
C_noret_decl(f_3781)
static void C_ccall f_3781(C_word c,C_word *av) C_noret;
C_noret_decl(f_13100)
static void C_ccall f_13100(C_word c,C_word *av) C_noret;
C_noret_decl(f_10822)
static void C_ccall f_10822(C_word c,C_word *av) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word *av) C_noret;
C_noret_decl(f_3760)
static void C_fcall f_3760(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12447)
static void C_fcall f_12447(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12445)
static void C_ccall f_12445(C_word c,C_word *av) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word *av) C_noret;
C_noret_decl(f_7722)
static void C_ccall f_7722(C_word c,C_word *av) C_noret;
C_noret_decl(f_12723)
static void C_ccall f_12723(C_word c,C_word *av) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word *av) C_noret;
C_noret_decl(f_5090)
static void C_fcall f_5090(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3790)
static void C_fcall f_3790(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word *av) C_noret;
C_noret_decl(f_8279)
static void C_ccall f_8279(C_word c,C_word *av) C_noret;
C_noret_decl(f_8277)
static void C_ccall f_8277(C_word c,C_word *av) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word *av) C_noret;
C_noret_decl(f_5468)
static void C_ccall f_5468(C_word c,C_word *av) C_noret;
C_noret_decl(f_5143)
static void C_fcall f_5143(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12703)
static void C_ccall f_12703(C_word c,C_word *av) C_noret;
C_noret_decl(f_3776)
static void C_fcall f_3776(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9828)
static void C_ccall f_9828(C_word c,C_word *av) C_noret;
C_noret_decl(f_5170)
static void C_fcall f_5170(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5173)
static void C_ccall f_5173(C_word c,C_word *av) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word *av) C_noret;
C_noret_decl(f_9803)
static void C_ccall f_9803(C_word c,C_word *av) C_noret;
C_noret_decl(f_12481)
static void C_fcall f_12481(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5486)
static void C_ccall f_5486(C_word c,C_word *av) C_noret;
C_noret_decl(f_13174)
static void C_ccall f_13174(C_word c,C_word *av) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externexport void C_ccall C_optimizer_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_11560)
static void C_ccall f_11560(C_word c,C_word *av) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word *av) C_noret;
C_noret_decl(f_4738)
static void C_fcall f_4738(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5153)
static void C_ccall f_5153(C_word c,C_word *av) C_noret;
C_noret_decl(f_5472)
static void C_ccall f_5472(C_word c,C_word *av) C_noret;
C_noret_decl(f_12422)
static void C_ccall f_12422(C_word c,C_word *av) C_noret;
C_noret_decl(f_3862)
static void C_fcall f_3862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10113)
static void C_ccall f_10113(C_word c,C_word *av) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word *av) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word *av) C_noret;
C_noret_decl(f_4721)
static void C_fcall f_4721(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11004)
static void C_ccall f_11004(C_word c,C_word *av) C_noret;
C_noret_decl(f_12416)
static void C_ccall f_12416(C_word c,C_word *av) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word *av) C_noret;
C_noret_decl(f_4751)
static void C_fcall f_4751(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word *av) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word *av) C_noret;
C_noret_decl(f_13180)
static void C_ccall f_13180(C_word c,C_word *av) C_noret;
C_noret_decl(f_8211)
static void C_fcall f_8211(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11591)
static void C_fcall f_11591(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6612)
static void C_fcall f_6612(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5539)
static void C_fcall f_5539(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_fcall f_6624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10391)
static void C_fcall f_10391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_fcall f_3879(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6661)
static void C_ccall f_6661(C_word c,C_word *av) C_noret;
C_noret_decl(f_6618)
static void C_ccall f_6618(C_word c,C_word *av) C_noret;
C_noret_decl(f_8222)
static void C_ccall f_8222(C_word c,C_word *av) C_noret;
C_noret_decl(f_5581)
static void C_ccall f_5581(C_word c,C_word *av) C_noret;
C_noret_decl(f_5586)
static void C_fcall f_5586(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8208)
static void C_fcall f_8208(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5912)
static void C_ccall f_5912(C_word c,C_word *av) C_noret;
C_noret_decl(f_5918)
static void C_ccall f_5918(C_word c,C_word *av) C_noret;
C_noret_decl(f_5121)
static void C_ccall f_5121(C_word c,C_word *av) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word *av) C_noret;
C_noret_decl(f_8202)
static void C_ccall f_8202(C_word c,C_word *av) C_noret;
C_noret_decl(f_6069)
static void C_fcall f_6069(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8236)
static void C_ccall f_8236(C_word c,C_word *av) C_noret;
C_noret_decl(f_6060)
static void C_ccall f_6060(C_word c,C_word *av) C_noret;
C_noret_decl(f_5565)
static void C_ccall f_5565(C_word c,C_word *av) C_noret;
C_noret_decl(f_8231)
static void C_ccall f_8231(C_word c,C_word *av) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word *av) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word *av) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word *av) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word *av) C_noret;
C_noret_decl(f_9832)
static void C_ccall f_9832(C_word c,C_word *av) C_noret;
C_noret_decl(f_5419)
static void C_ccall f_5419(C_word c,C_word *av) C_noret;
C_noret_decl(f_9836)
static void C_ccall f_9836(C_word c,C_word *av) C_noret;
C_noret_decl(f_9844)
static void C_ccall f_9844(C_word c,C_word *av) C_noret;
C_noret_decl(f_9838)
static void C_ccall f_9838(C_word c,C_word *av) C_noret;
C_noret_decl(f_5952)
static void C_ccall f_5952(C_word c,C_word *av) C_noret;
C_noret_decl(f_9556)
static void C_ccall f_9556(C_word c,C_word *av) C_noret;
C_noret_decl(f_4662)
static void C_fcall f_4662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10799)
static void C_ccall f_10799(C_word c,C_word *av) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word *av) C_noret;
C_noret_decl(f_10796)
static void C_ccall f_10796(C_word c,C_word *av) C_noret;
C_noret_decl(f_11415)
static void C_ccall f_11415(C_word c,C_word *av) C_noret;
C_noret_decl(f_11418)
static void C_ccall f_11418(C_word c,C_word *av) C_noret;
C_noret_decl(f_8554)
static void C_ccall f_8554(C_word c,C_word *av) C_noret;
C_noret_decl(f_5111)
static void C_fcall f_5111(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8558)
static void C_ccall f_8558(C_word c,C_word *av) C_noret;
C_noret_decl(f_6511)
static void C_ccall f_6511(C_word c,C_word *av) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544(C_word c,C_word *av) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word *av) C_noret;
C_noret_decl(f_10314)
static void C_ccall f_10314(C_word c,C_word *av) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word *av) C_noret;
C_noret_decl(f_10298)
static void C_ccall f_10298(C_word c,C_word *av) C_noret;
C_noret_decl(f_6827)
static void C_fcall f_6827(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11409)
static void C_ccall f_11409(C_word c,C_word *av) C_noret;
C_noret_decl(f_10335)
static void C_ccall f_10335(C_word c,C_word *av) C_noret;
C_noret_decl(f_8594)
static void C_ccall f_8594(C_word c,C_word *av) C_noret;
C_noret_decl(f_10745)
static void C_ccall f_10745(C_word c,C_word *av) C_noret;
C_noret_decl(f_11326)
static void C_ccall f_11326(C_word c,C_word *av) C_noret;
C_noret_decl(f_6501)
static void C_fcall f_6501(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7566)
static void C_ccall f_7566(C_word c,C_word *av) C_noret;
C_noret_decl(f_5634)
static void C_ccall f_5634(C_word c,C_word *av) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word *av) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word *av) C_noret;
C_noret_decl(f_11316)
static void C_fcall f_11316(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11704)
static void C_ccall f_11704(C_word c,C_word *av) C_noret;
C_noret_decl(f_11423)
static C_word C_fcall f_11423(C_word *a,C_word t0);
C_noret_decl(f_4289)
static C_word C_fcall f_4289(C_word t0,C_word t1);
C_noret_decl(f_11420)
static void C_ccall f_11420(C_word c,C_word *av) C_noret;
C_noret_decl(f_10396)
static void C_ccall f_10396(C_word c,C_word *av) C_noret;
C_noret_decl(f_11714)
static void C_ccall f_11714(C_word c,C_word *av) C_noret;
C_noret_decl(f_5642)
static void C_ccall f_5642(C_word c,C_word *av) C_noret;
C_noret_decl(f_11723)
static void C_fcall f_11723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11483)
static void C_fcall f_11483(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11735)
static void C_fcall f_11735(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13047)
static void C_fcall f_13047(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10369)
static void C_ccall f_10369(C_word c,C_word *av) C_noret;
C_noret_decl(f_6009)
static void C_ccall f_6009(C_word c,C_word *av) C_noret;
C_noret_decl(f_10385)
static void C_ccall f_10385(C_word c,C_word *av) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word *av) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word *av) C_noret;
C_noret_decl(f_11392)
static void C_ccall f_11392(C_word c,C_word *av) C_noret;
C_noret_decl(f_11390)
static void C_ccall f_11390(C_word c,C_word *av) C_noret;
C_noret_decl(f_6025)
static void C_ccall f_6025(C_word c,C_word *av) C_noret;
C_noret_decl(f_11398)
static void C_fcall f_11398(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12625)
static void C_ccall f_12625(C_word c,C_word *av) C_noret;
C_noret_decl(f_12627)
static void C_ccall f_12627(C_word c,C_word *av) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word *av) C_noret;
C_noret_decl(f_5598)
static void C_fcall f_5598(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4216)
static void C_fcall f_4216(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12538)
static void C_ccall f_12538(C_word c,C_word *av) C_noret;
C_noret_decl(f_5884)
static void C_fcall f_5884(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5881)
static void C_ccall f_5881(C_word c,C_word *av) C_noret;
C_noret_decl(f_9602)
static void C_ccall f_9602(C_word c,C_word *av) C_noret;
C_noret_decl(f_9600)
static void C_ccall f_9600(C_word c,C_word *av) C_noret;
C_noret_decl(f_6015)
static void C_ccall f_6015(C_word c,C_word *av) C_noret;
C_noret_decl(f_9515)
static void C_ccall f_9515(C_word c,C_word *av) C_noret;
C_noret_decl(f_11604)
static void C_fcall f_11604(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11619)
static void C_ccall f_11619(C_word c,C_word *av) C_noret;
C_noret_decl(f_11612)
static void C_ccall f_11612(C_word c,C_word *av) C_noret;
C_noret_decl(f_12519)
static void C_ccall f_12519(C_word c,C_word *av) C_noret;
C_noret_decl(f_9530)
static void C_ccall f_9530(C_word c,C_word *av) C_noret;
C_noret_decl(f_5893)
static void C_ccall f_5893(C_word c,C_word *av) C_noret;
C_noret_decl(f_5891)
static void C_ccall f_5891(C_word c,C_word *av) C_noret;
C_noret_decl(f_6954)
static void C_ccall f_6954(C_word c,C_word *av) C_noret;
C_noret_decl(f_6946)
static void C_ccall f_6946(C_word c,C_word *av) C_noret;
C_noret_decl(f_7043)
static void C_ccall f_7043(C_word c,C_word *av) C_noret;
C_noret_decl(f_13234)
static void C_ccall f_13234(C_word c,C_word *av) C_noret;
C_noret_decl(f_7037)
static void C_ccall f_7037(C_word c,C_word *av) C_noret;
C_noret_decl(f_3745)
static void C_ccall f_3745(C_word c,C_word *av) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word *av) C_noret;
C_noret_decl(f_5860)
static void C_ccall f_5860(C_word c,C_word *av) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word *av) C_noret;
C_noret_decl(f_7061)
static void C_ccall f_7061(C_word c,C_word *av) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076(C_word c,C_word *av) C_noret;
C_noret_decl(f_6078)
static void C_fcall f_6078(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12506)
static void C_ccall f_12506(C_word c,C_word *av) C_noret;
C_noret_decl(f_13383)
static void C_ccall f_13383(C_word c,C_word *av) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word *av) C_noret;
C_noret_decl(f_7055)
static void C_ccall f_7055(C_word c,C_word *av) C_noret;
C_noret_decl(f_6910)
static void C_ccall f_6910(C_word c,C_word *av) C_noret;
C_noret_decl(f_13247)
static void C_ccall f_13247(C_word c,C_word *av) C_noret;
C_noret_decl(f_12567)
static void C_ccall f_12567(C_word c,C_word *av) C_noret;
C_noret_decl(f_13377)
static void C_ccall f_13377(C_word c,C_word *av) C_noret;
C_noret_decl(f_10586)
static void C_ccall f_10586(C_word c,C_word *av) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word *av) C_noret;
C_noret_decl(f_3753)
static void C_fcall f_3753(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word *av) C_noret;
C_noret_decl(f_7078)
static void C_ccall f_7078(C_word c,C_word *av) C_noret;
C_noret_decl(f_4007)
static void C_fcall f_4007(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7070)
static void C_ccall f_7070(C_word c,C_word *av) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word *av) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word *av) C_noret;
C_noret_decl(f_11909)
static void C_ccall f_11909(C_word c,C_word *av) C_noret;
C_noret_decl(f_11915)
static void C_ccall f_11915(C_word c,C_word *av) C_noret;
C_noret_decl(f_11918)
static void C_ccall f_11918(C_word c,C_word *av) C_noret;
C_noret_decl(f_11912)
static void C_ccall f_11912(C_word c,C_word *av) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word *av) C_noret;
C_noret_decl(f_7091)
static void C_fcall f_7091(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11925)
static void C_fcall f_11925(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word *av) C_noret;
C_noret_decl(f_11924)
static void C_ccall f_11924(C_word c,C_word *av) C_noret;
C_noret_decl(f_3812)
static void C_ccall f_3812(C_word c,C_word *av) C_noret;
C_noret_decl(f_11921)
static void C_ccall f_11921(C_word c,C_word *av) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word *av) C_noret;
C_noret_decl(f_12528)
static void C_fcall f_12528(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11929)
static void C_ccall f_11929(C_word c,C_word *av) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word *av) C_noret;
C_noret_decl(f_6863)
static void C_ccall f_6863(C_word c,C_word *av) C_noret;
C_noret_decl(f_11930)
static void C_fcall f_11930(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6860)
static void C_ccall f_6860(C_word c,C_word *av) C_noret;
C_noret_decl(f_9192)
static void C_ccall f_9192(C_word c,C_word *av) C_noret;
C_noret_decl(f_9521)
static void C_ccall f_9521(C_word c,C_word *av) C_noret;
C_noret_decl(f_9527)
static void C_fcall f_9527(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12589)
static void C_ccall f_12589(C_word c,C_word *av) C_noret;
C_noret_decl(f_3825)
static void C_fcall f_3825(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12653)
static void C_ccall f_12653(C_word c,C_word *av) C_noret;
C_noret_decl(f_6878)
static void C_ccall f_6878(C_word c,C_word *av) C_noret;
C_noret_decl(f_11166)
static void C_ccall f_11166(C_word c,C_word *av) C_noret;
C_noret_decl(f_9142)
static void C_fcall f_9142(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7003)
static void C_ccall f_7003(C_word c,C_word *av) C_noret;
C_noret_decl(f_3802)
static void C_fcall f_3802(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6857)
static void C_ccall f_6857(C_word c,C_word *av) C_noret;
C_noret_decl(f_6850)
static void C_ccall f_6850(C_word c,C_word *av) C_noret;
C_noret_decl(f_12661)
static void C_ccall f_12661(C_word c,C_word *av) C_noret;
C_noret_decl(f_12665)
static void C_ccall f_12665(C_word c,C_word *av) C_noret;
C_noret_decl(f_12669)
static void C_ccall f_12669(C_word c,C_word *av) C_noret;
C_noret_decl(f_4652)
static void C_fcall f_4652(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7026)
static void C_ccall f_7026(C_word c,C_word *av) C_noret;
C_noret_decl(f_4098)
static void C_fcall f_4098(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8464)
static void C_ccall f_8464(C_word c,C_word *av) C_noret;
C_noret_decl(f_6886)
static void C_fcall f_6886(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6880)
static void C_fcall f_6880(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7013)
static void C_ccall f_7013(C_word c,C_word *av) C_noret;
C_noret_decl(f_7011)
static void C_ccall f_7011(C_word c,C_word *av) C_noret;
C_noret_decl(f_8767)
static void C_ccall f_8767(C_word c,C_word *av) C_noret;
C_noret_decl(f_11878)
static void C_ccall f_11878(C_word c,C_word *av) C_noret;
C_noret_decl(f_10717)
static void C_ccall f_10717(C_word c,C_word *av) C_noret;
C_noret_decl(f_8444)
static void C_ccall f_8444(C_word c,C_word *av) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word *av) C_noret;
C_noret_decl(f_10713)
static void C_fcall f_10713(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13437)
static void C_ccall f_13437(C_word c,C_word *av) C_noret;
C_noret_decl(f_11853)
static void C_fcall f_11853(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10172)
static void C_fcall f_10172(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word *av) C_noret;
C_noret_decl(f_9271)
static void C_ccall f_9271(C_word c,C_word *av) C_noret;
C_noret_decl(f_11783)
static void C_ccall f_11783(C_word c,C_word *av) C_noret;
C_noret_decl(f_11780)
static void C_ccall f_11780(C_word c,C_word *av) C_noret;
C_noret_decl(f_11787)
static void C_fcall f_11787(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5394)
static void C_fcall f_5394(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12171)
static void C_ccall f_12171(C_word c,C_word *av) C_noret;
C_noret_decl(f_12173)
static void C_ccall f_12173(C_word c,C_word *av) C_noret;
C_noret_decl(f_10194)
static void C_ccall f_10194(C_word c,C_word *av) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word *av) C_noret;
C_noret_decl(f_5384)
static void C_ccall f_5384(C_word c,C_word *av) C_noret;
C_noret_decl(f_12163)
static void C_ccall f_12163(C_word c,C_word *av) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word *av) C_noret;
C_noret_decl(f_10184)
static void C_fcall f_10184(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10729)
static void C_ccall f_10729(C_word c,C_word *av) C_noret;
C_noret_decl(f_12155)
static void C_ccall f_12155(C_word c,C_word *av) C_noret;
C_noret_decl(f_10726)
static void C_ccall f_10726(C_word c,C_word *av) C_noret;
C_noret_decl(f_12159)
static void C_ccall f_12159(C_word c,C_word *av) C_noret;
C_noret_decl(f_9015)
static void C_fcall f_9015(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10720)
static void C_ccall f_10720(C_word c,C_word *av) C_noret;
C_noret_decl(f_12151)
static void C_ccall f_12151(C_word c,C_word *av) C_noret;
C_noret_decl(f_10130)
static void C_ccall f_10130(C_word c,C_word *av) C_noret;
C_noret_decl(f_11119)
static void C_fcall f_11119(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10730)
static void C_fcall f_10730(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9019)
static void C_ccall f_9019(C_word c,C_word *av) C_noret;
C_noret_decl(f_11745)
static void C_ccall f_11745(C_word c,C_word *av) C_noret;
C_noret_decl(f_8341)
static void C_fcall f_8341(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5354)
static void C_fcall f_5354(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4953)
static void C_ccall f_4953(C_word c,C_word *av) C_noret;
C_noret_decl(f_10704)
static void C_ccall f_10704(C_word c,C_word *av) C_noret;
C_noret_decl(f_4956)
static void C_ccall f_4956(C_word c,C_word *av) C_noret;
C_noret_decl(f_9109)
static void C_ccall f_9109(C_word c,C_word *av) C_noret;
C_noret_decl(f_5340)
static void C_ccall f_5340(C_word c,C_word *av) C_noret;
C_noret_decl(f_11768)
static void C_ccall f_11768(C_word c,C_word *av) C_noret;
C_noret_decl(f_8435)
static void C_ccall f_8435(C_word c,C_word *av) C_noret;
C_noret_decl(f_11771)
static void C_ccall f_11771(C_word c,C_word *av) C_noret;
C_noret_decl(f_11772)
static void C_fcall f_11772(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13558)
static void C_ccall f_13558(C_word c,C_word *av) C_noret;
C_noret_decl(f_6968)
static void C_ccall f_6968(C_word c,C_word *av) C_noret;
C_noret_decl(f_6962)
static void C_ccall f_6962(C_word c,C_word *av) C_noret;
C_noret_decl(f_13548)
static void C_fcall f_13548(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5315)
static void C_ccall f_5315(C_word c,C_word *av) C_noret;
C_noret_decl(f_13543)
static void C_ccall f_13543(C_word c,C_word *av) C_noret;
C_noret_decl(f_6996)
static void C_fcall f_6996(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6464)
static void C_ccall f_6464(C_word c,C_word *av) C_noret;
C_noret_decl(f_6995)
static void C_ccall f_6995(C_word c,C_word *av) C_noret;
C_noret_decl(f_6468)
static void C_ccall f_6468(C_word c,C_word *av) C_noret;
C_noret_decl(f_5305)
static void C_fcall f_5305(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6981)
static void C_ccall f_6981(C_word c,C_word *av) C_noret;
C_noret_decl(f_6473)
static void C_ccall f_6473(C_word c,C_word *av) C_noret;
C_noret_decl(f_4597)
static void C_ccall f_4597(C_word c,C_word *av) C_noret;
C_noret_decl(f_5371)
static void C_fcall f_5371(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8472)
static void C_ccall f_8472(C_word c,C_word *av) C_noret;
C_noret_decl(f_8476)
static void C_ccall f_8476(C_word c,C_word *av) C_noret;
C_noret_decl(f_13562)
static C_word C_fcall f_13562(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_10018)
static void C_ccall f_10018(C_word c,C_word *av) C_noret;
C_noret_decl(f_9236)
static void C_ccall f_9236(C_word c,C_word *av) C_noret;
C_noret_decl(f_6410)
static void C_ccall f_6410(C_word c,C_word *av) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word *av) C_noret;
C_noret_decl(f_9245)
static void C_ccall f_9245(C_word c,C_word *av) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word *av) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899(C_word c,C_word *av) C_noret;
C_noret_decl(f_6429)
static void C_ccall f_6429(C_word c,C_word *av) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word *av) C_noret;
C_noret_decl(f_6423)
static void C_ccall f_6423(C_word c,C_word *av) C_noret;
C_noret_decl(f_9767)
static void C_ccall f_9767(C_word c,C_word *av) C_noret;
C_noret_decl(f_9212)
static void C_ccall f_9212(C_word c,C_word *av) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word *av) C_noret;
C_noret_decl(f_6432)
static void C_ccall f_6432(C_word c,C_word *av) C_noret;
C_noret_decl(f_6435)
static void C_ccall f_6435(C_word c,C_word *av) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word *av) C_noret;
C_noret_decl(f_9352)
static void C_ccall f_9352(C_word c,C_word *av) C_noret;
C_noret_decl(f_8307)
static void C_fcall f_8307(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9324)
static void C_ccall f_9324(C_word c,C_word *av) C_noret;
C_noret_decl(f_9326)
static void C_ccall f_9326(C_word c,C_word *av) C_noret;
C_noret_decl(f_8811)
static void C_fcall f_8811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4887)
static void C_ccall f_4887(C_word c,C_word *av) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word *av) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word *av) C_noret;
C_noret_decl(f_8332)
static void C_ccall f_8332(C_word c,C_word *av) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word *av) C_noret;
C_noret_decl(f_11962)
static void C_ccall f_11962(C_word c,C_word *av) C_noret;
C_noret_decl(f_11966)
static void C_ccall f_11966(C_word c,C_word *av) C_noret;
C_noret_decl(f_8366)
static void C_ccall f_8366(C_word c,C_word *av) C_noret;
C_noret_decl(f_11970)
static void C_ccall f_11970(C_word c,C_word *av) C_noret;
C_noret_decl(f_11974)
static void C_ccall f_11974(C_word c,C_word *av) C_noret;
C_noret_decl(f_4876)
static void C_ccall f_4876(C_word c,C_word *av) C_noret;
C_noret_decl(f_11982)
static void C_ccall f_11982(C_word c,C_word *av) C_noret;
C_noret_decl(f_11992)
static void C_ccall f_11992(C_word c,C_word *av) C_noret;
C_noret_decl(f_11129)
static void C_ccall f_11129(C_word c,C_word *av) C_noret;
C_noret_decl(f_10156)
static void C_ccall f_10156(C_word c,C_word *av) C_noret;

C_noret_decl(trf_10685)
static void C_ccall trf_10685(C_word c,C_word *av) C_noret;
static void C_ccall trf_10685(C_word c,C_word *av){
C_word t0=av[7];
C_word t1=av[6];
C_word t2=av[5];
C_word t3=av[4];
C_word t4=av[3];
C_word t5=av[2];
C_word t6=av[1];
C_word t7=av[0];
f_10685(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_6537)
static void C_ccall trf_6537(C_word c,C_word *av) C_noret;
static void C_ccall trf_6537(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6537(t0,t1,t2,t3);}

C_noret_decl(trf_4760)
static void C_ccall trf_4760(C_word c,C_word *av) C_noret;
static void C_ccall trf_4760(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4760(t0,t1,t2);}

C_noret_decl(trf_4305)
static void C_ccall trf_4305(C_word c,C_word *av) C_noret;
static void C_ccall trf_4305(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4305(t0,t1,t2);}

C_noret_decl(trf_4543)
static void C_ccall trf_4543(C_word c,C_word *av) C_noret;
static void C_ccall trf_4543(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4543(t0,t1,t2);}

C_noret_decl(trf_4551)
static void C_ccall trf_4551(C_word c,C_word *av) C_noret;
static void C_ccall trf_4551(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4551(t0,t1,t2);}

C_noret_decl(trf_4563)
static void C_ccall trf_4563(C_word c,C_word *av) C_noret;
static void C_ccall trf_4563(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_4563(t0,t1,t2,t3,t4);}

C_noret_decl(trf_12380)
static void C_ccall trf_12380(C_word c,C_word *av) C_noret;
static void C_ccall trf_12380(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_12380(t0,t1,t2);}

C_noret_decl(trf_7392)
static void C_ccall trf_7392(C_word c,C_word *av) C_noret;
static void C_ccall trf_7392(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7392(t0,t1);}

C_noret_decl(trf_4350)
static void C_ccall trf_4350(C_word c,C_word *av) C_noret;
static void C_ccall trf_4350(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_4350(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7382)
static void C_ccall trf_7382(C_word c,C_word *av) C_noret;
static void C_ccall trf_7382(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7382(t0,t1,t2);}

C_noret_decl(trf_10479)
static void C_ccall trf_10479(C_word c,C_word *av) C_noret;
static void C_ccall trf_10479(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10479(t0,t1);}

C_noret_decl(trf_6389)
static void C_ccall trf_6389(C_word c,C_word *av) C_noret;
static void C_ccall trf_6389(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6389(t0,t1);}

C_noret_decl(trf_6351)
static void C_ccall trf_6351(C_word c,C_word *av) C_noret;
static void C_ccall trf_6351(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_6351(t0,t1,t2,t3,t4);}

C_noret_decl(trf_12080)
static void C_ccall trf_12080(C_word c,C_word *av) C_noret;
static void C_ccall trf_12080(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12080(t0,t1);}

C_noret_decl(trf_10432)
static void C_ccall trf_10432(C_word c,C_word *av) C_noret;
static void C_ccall trf_10432(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10432(t0,t1);}

C_noret_decl(trf_6592)
static void C_ccall trf_6592(C_word c,C_word *av) C_noret;
static void C_ccall trf_6592(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6592(t0,t1);}

C_noret_decl(trf_12070)
static void C_ccall trf_12070(C_word c,C_word *av) C_noret;
static void C_ccall trf_12070(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_12070(t0,t1,t2);}

C_noret_decl(trf_7480)
static void C_ccall trf_7480(C_word c,C_word *av) C_noret;
static void C_ccall trf_7480(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7480(t0,t1);}

C_noret_decl(trf_7307)
static void C_ccall trf_7307(C_word c,C_word *av) C_noret;
static void C_ccall trf_7307(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7307(t0,t1,t2,t3);}

C_noret_decl(trf_9978)
static void C_ccall trf_9978(C_word c,C_word *av) C_noret;
static void C_ccall trf_9978(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_9978(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6565)
static void C_ccall trf_6565(C_word c,C_word *av) C_noret;
static void C_ccall trf_6565(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6565(t0,t1,t2);}

C_noret_decl(trf_6936)
static void C_ccall trf_6936(C_word c,C_word *av) C_noret;
static void C_ccall trf_6936(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6936(t0,t1,t2);}

C_noret_decl(trf_10963)
static void C_ccall trf_10963(C_word c,C_word *av) C_noret;
static void C_ccall trf_10963(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10963(t0,t1,t2);}

C_noret_decl(trf_6286)
static void C_ccall trf_6286(C_word c,C_word *av) C_noret;
static void C_ccall trf_6286(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6286(t0,t1);}

C_noret_decl(trf_6923)
static void C_ccall trf_6923(C_word c,C_word *av) C_noret;
static void C_ccall trf_6923(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6923(t0,t1,t2,t3);}

C_noret_decl(trf_6345)
static void C_ccall trf_6345(C_word c,C_word *av) C_noret;
static void C_ccall trf_6345(C_word c,C_word *av){
C_word t0=av[8];
C_word t1=av[7];
C_word t2=av[6];
C_word t3=av[5];
C_word t4=av[4];
C_word t5=av[3];
C_word t6=av[2];
C_word t7=av[1];
C_word t8=av[0];
f_6345(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_8538)
static void C_ccall trf_8538(C_word c,C_word *av) C_noret;
static void C_ccall trf_8538(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8538(t0,t1);}

C_noret_decl(trf_12017)
static void C_ccall trf_12017(C_word c,C_word *av) C_noret;
static void C_ccall trf_12017(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_12017(t0,t1,t2);}

C_noret_decl(trf_6210)
static void C_ccall trf_6210(C_word c,C_word *av) C_noret;
static void C_ccall trf_6210(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6210(t0,t1,t2);}

C_noret_decl(trf_7442)
static void C_ccall trf_7442(C_word c,C_word *av) C_noret;
static void C_ccall trf_7442(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7442(t0,t1);}

C_noret_decl(trf_5242)
static void C_ccall trf_5242(C_word c,C_word *av) C_noret;
static void C_ccall trf_5242(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5242(t0,t1);}

C_noret_decl(trf_5246)
static void C_ccall trf_5246(C_word c,C_word *av) C_noret;
static void C_ccall trf_5246(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5246(t0,t1,t2);}

C_noret_decl(trf_12885)
static void C_ccall trf_12885(C_word c,C_word *av) C_noret;
static void C_ccall trf_12885(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_12885(t0,t1,t2,t3);}

C_noret_decl(trf_13016)
static void C_ccall trf_13016(C_word c,C_word *av) C_noret;
static void C_ccall trf_13016(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_13016(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4179)
static void C_ccall trf_4179(C_word c,C_word *av) C_noret;
static void C_ccall trf_4179(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4179(t0,t1);}

C_noret_decl(trf_12047)
static void C_ccall trf_12047(C_word c,C_word *av) C_noret;
static void C_ccall trf_12047(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_12047(t0,t1,t2);}

C_noret_decl(trf_5208)
static void C_ccall trf_5208(C_word c,C_word *av) C_noret;
static void C_ccall trf_5208(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5208(t0,t1);}

C_noret_decl(trf_4139)
static void C_ccall trf_4139(C_word c,C_word *av) C_noret;
static void C_ccall trf_4139(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4139(t0,t1,t2,t3);}

C_noret_decl(trf_11287)
static void C_ccall trf_11287(C_word c,C_word *av) C_noret;
static void C_ccall trf_11287(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11287(t0,t1,t2);}

C_noret_decl(trf_11543)
static void C_ccall trf_11543(C_word c,C_word *av) C_noret;
static void C_ccall trf_11543(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11543(t0,t1);}

C_noret_decl(trf_6633)
static void C_ccall trf_6633(C_word c,C_word *av) C_noret;
static void C_ccall trf_6633(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6633(t0,t1);}

C_noret_decl(trf_8714)
static void C_ccall trf_8714(C_word c,C_word *av) C_noret;
static void C_ccall trf_8714(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8714(t0,t1);}

C_noret_decl(trf_9858)
static void C_ccall trf_9858(C_word c,C_word *av) C_noret;
static void C_ccall trf_9858(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9858(t0,t1,t2,t3);}

C_noret_decl(trf_3906)
static void C_ccall trf_3906(C_word c,C_word *av) C_noret;
static void C_ccall trf_3906(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3906(t0,t1);}

C_noret_decl(trf_4461)
static void C_ccall trf_4461(C_word c,C_word *av) C_noret;
static void C_ccall trf_4461(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4461(t0,t1);}

C_noret_decl(trf_12260)
static void C_ccall trf_12260(C_word c,C_word *av) C_noret;
static void C_ccall trf_12260(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_12260(t0,t1,t2,t3);}

C_noret_decl(trf_6177)
static void C_ccall trf_6177(C_word c,C_word *av) C_noret;
static void C_ccall trf_6177(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6177(t0,t1);}

C_noret_decl(trf_11529)
static void C_ccall trf_11529(C_word c,C_word *av) C_noret;
static void C_ccall trf_11529(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11529(t0,t1);}

C_noret_decl(trf_7247)
static void C_ccall trf_7247(C_word c,C_word *av) C_noret;
static void C_ccall trf_7247(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7247(t0,t1,t2);}

C_noret_decl(trf_7270)
static void C_ccall trf_7270(C_word c,C_word *av) C_noret;
static void C_ccall trf_7270(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7270(t0,t1,t2,t3);}

C_noret_decl(trf_7717)
static void C_ccall trf_7717(C_word c,C_word *av) C_noret;
static void C_ccall trf_7717(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7717(t0,t1);}

C_noret_decl(trf_10864)
static void C_ccall trf_10864(C_word c,C_word *av) C_noret;
static void C_ccall trf_10864(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10864(t0,t1,t2);}

C_noret_decl(trf_7224)
static void C_ccall trf_7224(C_word c,C_word *av) C_noret;
static void C_ccall trf_7224(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7224(t0,t1,t2);}

C_noret_decl(trf_10216)
static void C_ccall trf_10216(C_word c,C_word *av) C_noret;
static void C_ccall trf_10216(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_10216(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_10213)
static void C_ccall trf_10213(C_word c,C_word *av) C_noret;
static void C_ccall trf_10213(C_word c,C_word *av){
C_word t0=av[6];
C_word t1=av[5];
C_word t2=av[4];
C_word t3=av[3];
C_word t4=av[2];
C_word t5=av[1];
C_word t6=av[0];
f_10213(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3788)
static void C_ccall trf_3788(C_word c,C_word *av) C_noret;
static void C_ccall trf_3788(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3788(t0,t1,t2,t3);}

C_noret_decl(trf_3760)
static void C_ccall trf_3760(C_word c,C_word *av) C_noret;
static void C_ccall trf_3760(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3760(t0,t1);}

C_noret_decl(trf_12447)
static void C_ccall trf_12447(C_word c,C_word *av) C_noret;
static void C_ccall trf_12447(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_12447(t0,t1,t2);}

C_noret_decl(trf_5090)
static void C_ccall trf_5090(C_word c,C_word *av) C_noret;
static void C_ccall trf_5090(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5090(t0,t1);}

C_noret_decl(trf_3790)
static void C_ccall trf_3790(C_word c,C_word *av) C_noret;
static void C_ccall trf_3790(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3790(t0,t1,t2);}

C_noret_decl(trf_5143)
static void C_ccall trf_5143(C_word c,C_word *av) C_noret;
static void C_ccall trf_5143(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5143(t0,t1,t2);}

C_noret_decl(trf_3776)
static void C_ccall trf_3776(C_word c,C_word *av) C_noret;
static void C_ccall trf_3776(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3776(t0,t1,t2,t3);}

C_noret_decl(trf_5170)
static void C_ccall trf_5170(C_word c,C_word *av) C_noret;
static void C_ccall trf_5170(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5170(t0,t1);}

C_noret_decl(trf_12481)
static void C_ccall trf_12481(C_word c,C_word *av) C_noret;
static void C_ccall trf_12481(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_12481(t0,t1,t2);}

C_noret_decl(trf_4738)
static void C_ccall trf_4738(C_word c,C_word *av) C_noret;
static void C_ccall trf_4738(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4738(t0,t1);}

C_noret_decl(trf_3862)
static void C_ccall trf_3862(C_word c,C_word *av) C_noret;
static void C_ccall trf_3862(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3862(t0,t1);}

C_noret_decl(trf_4721)
static void C_ccall trf_4721(C_word c,C_word *av) C_noret;
static void C_ccall trf_4721(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4721(t0,t1);}

C_noret_decl(trf_4751)
static void C_ccall trf_4751(C_word c,C_word *av) C_noret;
static void C_ccall trf_4751(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4751(t0,t1,t2);}

C_noret_decl(trf_8211)
static void C_ccall trf_8211(C_word c,C_word *av) C_noret;
static void C_ccall trf_8211(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8211(t0,t1);}

C_noret_decl(trf_11591)
static void C_ccall trf_11591(C_word c,C_word *av) C_noret;
static void C_ccall trf_11591(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11591(t0,t1);}

C_noret_decl(trf_6612)
static void C_ccall trf_6612(C_word c,C_word *av) C_noret;
static void C_ccall trf_6612(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6612(t0,t1);}

C_noret_decl(trf_5539)
static void C_ccall trf_5539(C_word c,C_word *av) C_noret;
static void C_ccall trf_5539(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5539(t0,t1);}

C_noret_decl(trf_6624)
static void C_ccall trf_6624(C_word c,C_word *av) C_noret;
static void C_ccall trf_6624(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6624(t0,t1);}

C_noret_decl(trf_10391)
static void C_ccall trf_10391(C_word c,C_word *av) C_noret;
static void C_ccall trf_10391(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10391(t0,t1);}

C_noret_decl(trf_3879)
static void C_ccall trf_3879(C_word c,C_word *av) C_noret;
static void C_ccall trf_3879(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3879(t0,t1);}

C_noret_decl(trf_5586)
static void C_ccall trf_5586(C_word c,C_word *av) C_noret;
static void C_ccall trf_5586(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5586(t0,t1,t2);}

C_noret_decl(trf_8208)
static void C_ccall trf_8208(C_word c,C_word *av) C_noret;
static void C_ccall trf_8208(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8208(t0,t1);}

C_noret_decl(trf_6069)
static void C_ccall trf_6069(C_word c,C_word *av) C_noret;
static void C_ccall trf_6069(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6069(t0,t1,t2);}

C_noret_decl(trf_4662)
static void C_ccall trf_4662(C_word c,C_word *av) C_noret;
static void C_ccall trf_4662(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4662(t0,t1);}

C_noret_decl(trf_5111)
static void C_ccall trf_5111(C_word c,C_word *av) C_noret;
static void C_ccall trf_5111(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5111(t0,t1,t2);}

C_noret_decl(trf_6827)
static void C_ccall trf_6827(C_word c,C_word *av) C_noret;
static void C_ccall trf_6827(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6827(t0,t1,t2);}

C_noret_decl(trf_6501)
static void C_ccall trf_6501(C_word c,C_word *av) C_noret;
static void C_ccall trf_6501(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6501(t0,t1,t2);}

C_noret_decl(trf_11316)
static void C_ccall trf_11316(C_word c,C_word *av) C_noret;
static void C_ccall trf_11316(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11316(t0,t1,t2);}

C_noret_decl(trf_11723)
static void C_ccall trf_11723(C_word c,C_word *av) C_noret;
static void C_ccall trf_11723(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11723(t0,t1,t2);}

C_noret_decl(trf_11483)
static void C_ccall trf_11483(C_word c,C_word *av) C_noret;
static void C_ccall trf_11483(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_11483(t0,t1,t2,t3);}

C_noret_decl(trf_11735)
static void C_ccall trf_11735(C_word c,C_word *av) C_noret;
static void C_ccall trf_11735(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11735(t0,t1,t2);}

C_noret_decl(trf_13047)
static void C_ccall trf_13047(C_word c,C_word *av) C_noret;
static void C_ccall trf_13047(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13047(t0,t1);}

C_noret_decl(trf_11398)
static void C_ccall trf_11398(C_word c,C_word *av) C_noret;
static void C_ccall trf_11398(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11398(t0,t1);}

C_noret_decl(trf_5598)
static void C_ccall trf_5598(C_word c,C_word *av) C_noret;
static void C_ccall trf_5598(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5598(t0,t1,t2);}

C_noret_decl(trf_4216)
static void C_ccall trf_4216(C_word c,C_word *av) C_noret;
static void C_ccall trf_4216(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4216(t0,t1,t2);}

C_noret_decl(trf_5884)
static void C_ccall trf_5884(C_word c,C_word *av) C_noret;
static void C_ccall trf_5884(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5884(t0,t1);}

C_noret_decl(trf_11604)
static void C_ccall trf_11604(C_word c,C_word *av) C_noret;
static void C_ccall trf_11604(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11604(t0,t1);}

C_noret_decl(trf_6078)
static void C_ccall trf_6078(C_word c,C_word *av) C_noret;
static void C_ccall trf_6078(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6078(t0,t1,t2);}

C_noret_decl(trf_3753)
static void C_ccall trf_3753(C_word c,C_word *av) C_noret;
static void C_ccall trf_3753(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3753(t0,t1,t2);}

C_noret_decl(trf_4007)
static void C_ccall trf_4007(C_word c,C_word *av) C_noret;
static void C_ccall trf_4007(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4007(t0,t1);}

C_noret_decl(trf_7091)
static void C_ccall trf_7091(C_word c,C_word *av) C_noret;
static void C_ccall trf_7091(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7091(t0,t1);}

C_noret_decl(trf_11925)
static void C_ccall trf_11925(C_word c,C_word *av) C_noret;
static void C_ccall trf_11925(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11925(t0,t1,t2);}

C_noret_decl(trf_12528)
static void C_ccall trf_12528(C_word c,C_word *av) C_noret;
static void C_ccall trf_12528(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_12528(t0,t1,t2);}

C_noret_decl(trf_11930)
static void C_ccall trf_11930(C_word c,C_word *av) C_noret;
static void C_ccall trf_11930(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11930(t0,t1,t2);}

C_noret_decl(trf_9527)
static void C_ccall trf_9527(C_word c,C_word *av) C_noret;
static void C_ccall trf_9527(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9527(t0,t1);}

C_noret_decl(trf_3825)
static void C_ccall trf_3825(C_word c,C_word *av) C_noret;
static void C_ccall trf_3825(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3825(t0,t1,t2,t3);}

C_noret_decl(trf_9142)
static void C_ccall trf_9142(C_word c,C_word *av) C_noret;
static void C_ccall trf_9142(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9142(t0,t1);}

C_noret_decl(trf_3802)
static void C_ccall trf_3802(C_word c,C_word *av) C_noret;
static void C_ccall trf_3802(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3802(t0,t1,t2);}

C_noret_decl(trf_4652)
static void C_ccall trf_4652(C_word c,C_word *av) C_noret;
static void C_ccall trf_4652(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4652(t0,t1,t2);}

C_noret_decl(trf_4098)
static void C_ccall trf_4098(C_word c,C_word *av) C_noret;
static void C_ccall trf_4098(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4098(t0,t1,t2);}

C_noret_decl(trf_6886)
static void C_ccall trf_6886(C_word c,C_word *av) C_noret;
static void C_ccall trf_6886(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6886(t0,t1,t2,t3);}

C_noret_decl(trf_6880)
static void C_ccall trf_6880(C_word c,C_word *av) C_noret;
static void C_ccall trf_6880(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6880(t0,t1,t2,t3);}

C_noret_decl(trf_10713)
static void C_ccall trf_10713(C_word c,C_word *av) C_noret;
static void C_ccall trf_10713(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10713(t0,t1);}

C_noret_decl(trf_11853)
static void C_ccall trf_11853(C_word c,C_word *av) C_noret;
static void C_ccall trf_11853(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11853(t0,t1,t2);}

C_noret_decl(trf_10172)
static void C_ccall trf_10172(C_word c,C_word *av) C_noret;
static void C_ccall trf_10172(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10172(t0,t1,t2);}

C_noret_decl(trf_11787)
static void C_ccall trf_11787(C_word c,C_word *av) C_noret;
static void C_ccall trf_11787(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11787(t0,t1,t2);}

C_noret_decl(trf_5394)
static void C_ccall trf_5394(C_word c,C_word *av) C_noret;
static void C_ccall trf_5394(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5394(t0,t1,t2);}

C_noret_decl(trf_10184)
static void C_ccall trf_10184(C_word c,C_word *av) C_noret;
static void C_ccall trf_10184(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10184(t0,t1,t2);}

C_noret_decl(trf_9015)
static void C_ccall trf_9015(C_word c,C_word *av) C_noret;
static void C_ccall trf_9015(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9015(t0,t1);}

C_noret_decl(trf_11119)
static void C_ccall trf_11119(C_word c,C_word *av) C_noret;
static void C_ccall trf_11119(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11119(t0,t1,t2);}

C_noret_decl(trf_10730)
static void C_ccall trf_10730(C_word c,C_word *av) C_noret;
static void C_ccall trf_10730(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10730(t0,t1,t2);}

C_noret_decl(trf_8341)
static void C_ccall trf_8341(C_word c,C_word *av) C_noret;
static void C_ccall trf_8341(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8341(t0,t1,t2);}

C_noret_decl(trf_5354)
static void C_ccall trf_5354(C_word c,C_word *av) C_noret;
static void C_ccall trf_5354(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_5354(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_11772)
static void C_ccall trf_11772(C_word c,C_word *av) C_noret;
static void C_ccall trf_11772(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11772(t0,t1,t2);}

C_noret_decl(trf_13548)
static void C_ccall trf_13548(C_word c,C_word *av) C_noret;
static void C_ccall trf_13548(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_13548(t0,t1,t2);}

C_noret_decl(trf_6996)
static void C_ccall trf_6996(C_word c,C_word *av) C_noret;
static void C_ccall trf_6996(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6996(t0,t1,t2);}

C_noret_decl(trf_5305)
static void C_ccall trf_5305(C_word c,C_word *av) C_noret;
static void C_ccall trf_5305(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5305(t0,t1,t2);}

C_noret_decl(trf_5371)
static void C_ccall trf_5371(C_word c,C_word *av) C_noret;
static void C_ccall trf_5371(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5371(t0,t1,t2);}

C_noret_decl(trf_8307)
static void C_ccall trf_8307(C_word c,C_word *av) C_noret;
static void C_ccall trf_8307(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8307(t0,t1,t2);}

C_noret_decl(trf_8811)
static void C_ccall trf_8811(C_word c,C_word *av) C_noret;
static void C_ccall trf_8811(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8811(t0,t1);}

/* k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10689(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,4))){C_save_and_reclaim((void *)f_10689,2,av);}
a=C_alloc(14);
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[3];
t4=C_slot(t3,C_fix(2));
t5=t4;
t6=C_i_caddr(t5);
t7=C_i_length(t6);
t8=t7;
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10704,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[3],a[10]=t10,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:1463: get */
t12=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t12;
av2[1]=t11;
av2[2]=((C_word*)t0)[10];
av2[3]=((C_word*)t0)[5];
av2[4]=lf[126];
((C_proc)(void*)(*((C_word*)t12+1)))(5,av2);}}

/* k10681 in k10674 in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10683(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10683,2,av);}
/* optimizer.scm:1453: lset= */
t2=*((C_word*)lf[165]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[27]+1);
av2[3]=((C_word*)((C_word*)t0)[3])[1];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_10685(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(19,0,5))){
C_save_and_reclaim_args((void *)trf_10685,8,t0,t1,t2,t3,t4,t5,t6,t7);}
a=C_alloc(19);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10689,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t7,a[5]=t3,a[6]=t6,a[7]=t5,a[8]=t1,a[9]=t4,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11390,a[2]=t8,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11392,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1457: ##sys#make-promise */
t11=*((C_word*)lf[183]+1);{
C_word av2[3];
av2[0]=t11;
av2[1]=t9;
av2[2]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
/* optimizer.scm:1458: debugging */
t9=*((C_word*)lf[17]+1);{
C_word av2[6];
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[18];
av2[3]=lf[184];
av2[4]=t3;
av2[5]=t7;
((C_proc)(void*)(*((C_word*)t9+1)))(6,av2);}}}

/* k5843 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_5845,2,av);}
a=C_alloc(11);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_slot(t2,C_fix(1));
t4=C_eqp(lf[3],t3);
if(C_truep(t4)){
t5=C_u_i_car(((C_word*)t0)[2]);
t6=C_slot(t5,C_fix(2));
t7=C_i_car(t6);
t8=t7;
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5952,a[2]=t9,a[3]=((C_word*)t0)[5],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:335: test */
t11=((C_word*)((C_word*)t0)[5])[1];
f_4139(t11,t10,t8,lf[99]);}
else{
t9=((C_word*)t0)[3];
f_5170(t9,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[3];
f_5170(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_5170(t2,C_SCHEME_FALSE);}}

/* k11136 in k11133 in k11130 in k11127 in g2380 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 in ... */
static void C_ccall f_11138(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11138,2,av);}
/* optimizer.scm:1508: rec */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
f_11004(3,av2);}}

/* k11130 in k11127 in g2380 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11132(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_11132,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11135,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11166,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=C_slot(((C_word*)t0)[8],C_fix(2));
t5=C_i_caddr(t4);
/* optimizer.scm:1504: take */
t6=*((C_word*)lf[173]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
av2[3]=C_fix(1);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k11133 in k11130 in k11127 in g2380 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11135(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,3))){C_save_and_reclaim((void *)f_11135,2,av);}
a=C_alloc(22);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list2(&a,2,C_SCHEME_FALSE,((C_word*)t0)[5]);
t4=C_i_cddr(((C_word*)t0)[6]);
t5=C_a_i_record4(&a,4,lf[14],lf[171],t3,t4);
t6=C_a_i_list2(&a,2,t5,((C_word*)t0)[4]);
/* optimizer.scm:1505: node-subexpressions-set! */
t7=*((C_word*)lf[121]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k10674 in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10676(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_10676,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1453: delete */
t3=*((C_word*)lf[166]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)((C_word*)t0)[5])[1];
av2[4]=*((C_word*)lf[27]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k4381 in k4362 in walk in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4383(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4383,2,av);}
/* optimizer.scm:170: simplify */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4216(t2,((C_word*)t0)[3],t1);}

/* k4793 in k4719 in k4716 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4795(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_4795,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_u_i_car(((C_word*)t0)[2]);
t3=C_slot(t2,C_fix(2));
t4=C_i_car(t3);
t5=((C_word*)t0)[3];
f_4738(t5,C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[4],t4),((C_word*)t0)[5]));}
else{
t2=((C_word*)t0)[3];
f_4738(t2,((C_word*)t0)[5]);}}

/* test in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6537(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_6537,4,t0,t1,t2,t3);}
/* optimizer.scm:553: get */
t4=*((C_word*)lf[33]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* ##compiler#perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6530(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,4))){C_save_and_reclaim((void *)f_6530,4,av);}
a=C_alloc(22);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6533,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6537,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6544,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t9,a[6]=t3,a[7]=t11,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:555: debugging */
t15=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t15;
av2[1]=t14;
av2[2]=lf[28];
av2[3]=lf[127];
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}

/* touch in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static C_word C_fcall f_6533(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_overflow_check;{}
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* map-loop397 in k4736 in k4719 in k4716 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_4760(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4760,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4785,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:264: g403 */
t5=((C_word*)t0)[4];
f_4751(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5753 in k5750 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_5755,2,av);}
a=C_alloc(8);
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t3);
/* optimizer.scm:455: walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4350(t5,((C_word*)t0)[6],t4,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k5750 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5752(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,8))){C_save_and_reclaim((void *)f_5752,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(2));
t4=C_i_car(t3);
/* optimizer.scm:453: debugging */
t5=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=lf[76];
av2[3]=lf[96];
av2[4]=((C_word*)t0)[9];
av2[5]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}
else{
/* optimizer.scm:461: walk-generic */
t2=((C_word*)((C_word*)t0)[10])[1];
f_6345(t2,((C_word*)t0)[6],((C_word*)t0)[11],((C_word*)t0)[12],((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[7],((C_word*)t0)[8],C_SCHEME_TRUE);}}

/* k4783 in map-loop397 in k4736 in k4719 in k4716 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4785(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4785,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4760(t6,((C_word*)t0)[5],t5);}

/* a9646 in k9525 in k9519 in k9513 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9647(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_9647,3,av);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(lf[34],t4);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_eqp(((C_word*)t0)[2],t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* map-loop225 in k4239 in a4230 in k4218 in simplify in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_4305(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_4305,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_4289(((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4301 in k4239 in a4230 in k4218 in simplify in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4303(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4303,2,av);}{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
C_apply(5,av2);}}

/* k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 in ... */
static void C_ccall f_12326(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,2))){C_save_and_reclaim((void *)f_12326,2,av);}
a=C_alloc(20);
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_12322,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[2],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
/* optimizer.scm:1718: gensym */
t7=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[190];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* a12785 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12786(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8=av[8];
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_12786,9,av);}
a=C_alloc(8);
if(C_truep(C_i_equalp(t4,*((C_word*)lf[217]+1)))){
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12833,a[2]=t4,a[3]=t5,a[4]=t7,a[5]=t8,a[6]=t1,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:762: get-list */
t10=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=t2;
av2[3]=t3;
av2[4]=lf[98];
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}}

/* k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in ... */
static void C_ccall f_12322(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(37,c,2))){C_save_and_reclaim((void *)f_12322,2,av);}
a=C_alloc(37);
t2=C_a_i_list4(&a,4,t1,C_SCHEME_TRUE,((C_word*)t0)[2],C_fix(0));
t3=t2;
t4=C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t5=C_a_i_list1(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12219,a[2]=t6,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12314,a[2]=((C_word*)t0)[9],a[3]=t7,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1725: varnode */
t9=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=((C_word*)t0)[13];
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}

/* k9717 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9719(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,2))){C_save_and_reclaim((void *)f_9719,2,av);}
a=C_alloc(25);
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[2]);
t3=(C_truep(t2)?t2:*((C_word*)lf[145]+1));
if(C_truep(t3)){
t4=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t5=t4;
t6=C_eqp(*((C_word*)lf[146]+1),lf[147]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1296: fifth */
t8=*((C_word*)lf[154]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t7=C_i_cadr(((C_word*)t0)[2]);
t8=C_a_i_list2(&a,2,t7,((C_word*)t0)[6]);
t9=((C_word*)t0)[3];
t10=C_a_i_record4(&a,4,lf[14],lf[89],t8,t9);
t11=C_a_i_list2(&a,2,((C_word*)t0)[4],t10);
t12=((C_word*)t0)[5];
t13=t12;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],t5,t11);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}}
else{
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11828 in a11818 in k11812 in g2712 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11830(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_11830,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list4(&a,4,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k12312 in k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in ... */
static void C_ccall f_12314(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_12314,2,av);}
a=C_alloc(11);
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12242,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1726: append-map */
t6=*((C_word*)lf[135]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* a10642 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10643(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_10643,3,av);}
/* optimizer.scm:1448: rec */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10216(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* a11818 in k11812 in g2712 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11819(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_11819,5,av);}
a=C_alloc(16);
t5=C_slot(((C_word*)t0)[2],C_fix(3));
t6=C_i_car(t5);
t7=t6;
t8=((C_word*)((C_word*)t0)[3])[1];
t9=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t10=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t9);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11830,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=((C_word*)t0)[5],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t12=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
/* optimizer.scm:1680: copy-node! */
t13=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t13;
av2[1]=t11;
av2[2]=t12;
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t13+1)))(4,av2);}}

/* k11812 in g2712 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11814(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,5))){C_save_and_reclaim((void *)f_11814,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1674: decompose-lambda-list */
t3=*((C_word*)lf[66]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[7];
av2[2]=((C_word*)t0)[5];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4545 in replace-var in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4547(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4547,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:134: g314 */
t3=t2;
f_4551(t3,((C_word*)t0)[5],t1);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* replace-var in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_4543(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_4543,3,t0,t1,t2);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4547,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:215: test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4139(t4,t3,t2,lf[48]);}

/* k4553 in g314 in k4545 in replace-var in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4555(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,5))){C_save_and_reclaim((void *)f_4555,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4558,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:219: put! */
t4=*((C_word*)lf[47]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=lf[48];
av2[5]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}

/* k4556 in k4553 in g314 in k4545 in replace-var in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4558(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4558,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* g314 in k4545 in replace-var in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_4551(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_4551,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4555,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:217: replace-var */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4543(t4,t3,t2);}

/* k7807 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7809(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_7809,2,av);}
a=C_alloc(13);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_list2(&a,2,C_SCHEME_FALSE,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7829,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)t0)[2];
t7=C_u_i_car(t6);
/* optimizer.scm:984: varnode */
t8=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t5;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_4563(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word *a;
if(!C_demand(C_calculate_demand(27,0,8))){
C_save_and_reclaim_args((void *)trf_4563,5,t0,t1,t2,t3,t4);}
a=C_alloc(27);
t5=t2;
t6=C_slot(t5,C_fix(3));
t7=t6;
t8=t2;
t9=C_slot(t8,C_fix(2));
t10=t9;
t11=t2;
t12=C_slot(t11,C_fix(1));
t13=t12;
t14=C_eqp(t13,lf[3]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4597,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t10,a[6]=t4,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t16=C_i_car(t10);
/* optimizer.scm:230: replace-var */
t17=((C_word*)((C_word*)t0)[5])[1];
f_4543(t17,t15,t16);}
else{
t15=C_eqp(t13,lf[6]);
if(C_truep(t15)){
t16=C_i_car(t10);
t17=t16;
t18=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t7,a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=t3,a[8]=t4,a[9]=t10,a[10]=t17,a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:251: test */
t19=((C_word*)((C_word*)t0)[3])[1];
f_4139(t19,t18,t17,lf[59]);}
else{
t16=C_eqp(t13,lf[11]);
if(C_truep(t16)){
t17=C_i_caddr(t10);
t18=t17;
t19=C_u_i_car(t10);
t20=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4876,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=t7,a[6]=t19,a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=t18,a[11]=((C_word*)t0)[8],a[12]=t2,a[13]=t13,tmp=(C_word)a,a+=14,tmp);
/* optimizer.scm:269: test */
t21=((C_word*)((C_word*)t0)[3])[1];
f_4139(t21,t20,t19,lf[68]);}
else{
t17=C_eqp(t13,lf[69]);
if(C_truep(t17)){
/* optimizer.scm:302: walk-generic */
t18=((C_word*)((C_word*)t0)[8])[1];
f_6345(t18,t1,t2,t13,t10,t7,t3,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}
else{
t18=C_eqp(t13,lf[12]);
if(C_truep(t18)){
t19=C_i_car(t7);
t20=t19;
t21=C_slot(t20,C_fix(1));
t22=C_eqp(t21,lf[3]);
if(C_truep(t22)){
t23=C_slot(t20,C_fix(2));
t24=C_i_car(t23);
t25=t24;
t26=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5080,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t4,a[9]=t25,a[10]=((C_word*)t0)[8],a[11]=t2,a[12]=t13,a[13]=t10,a[14]=t20,a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[3],a[17]=((C_word*)t0)[11],tmp=(C_word)a,a+=18,tmp);
/* optimizer.scm:311: call-info */
t27=*((C_word*)lf[102]+1);{
C_word av2[4];
av2[0]=t27;
av2[1]=t26;
av2[2]=t10;
av2[3]=t25;
((C_proc)(void*)(*((C_word*)t27+1)))(4,av2);}}
else{
t23=C_eqp(t21,lf[11]);
if(C_truep(t23)){
if(C_truep(C_i_car(t10))){
/* optimizer.scm:464: walk-generic */
t24=((C_word*)((C_word*)t0)[8])[1];
f_6345(t24,t1,t2,t13,t10,t7,t3,t4,C_SCHEME_FALSE);}
else{
t24=C_u_i_cdr(t10);
t25=C_a_i_cons(&a,2,C_SCHEME_TRUE,t24);
t26=t25;
t27=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t28=t27;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=((C_word*)t29)[1];
t31=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6069,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t32=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6076,a[2]=t26,a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_set_block_item(t34,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6078,a[2]=t29,a[3]=t34,a[4]=t31,a[5]=t30,tmp=(C_word)a,a+=6,tmp));
t36=((C_word*)t34)[1];
f_6078(t36,t32,t7);}}
else{
/* optimizer.scm:469: walk-generic */
t24=((C_word*)((C_word*)t0)[8])[1];
f_6345(t24,t1,t2,t13,t10,t7,t3,t4,C_SCHEME_TRUE);}}}
else{
t19=C_eqp(t13,lf[13]);
if(C_truep(t19)){
t20=C_i_car(t10);
t21=t20;
t22=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6134,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t21,a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=t4,a[8]=t7,a[9]=((C_word*)t0)[7],a[10]=t3,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:473: test */
t23=((C_word*)((C_word*)t0)[3])[1];
f_4139(t23,t22,t21,lf[58]);}
else{
/* optimizer.scm:502: walk-generic */
t20=((C_word*)((C_word*)t0)[8])[1];
f_6345(t20,t1,t2,t13,t10,t7,t3,t4,C_SCHEME_FALSE);}}}}}}}

/* map-loop2821 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_12380(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_12380,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k12376 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12378(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_12378,2,av);}
/* optimizer.scm:1691: debugging */
t2=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[191];
av2[3]=lf[192];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k10424 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10426(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_10426,2,av);}
a=C_alloc(10);
t2=C_i_zerop(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10432,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_10432(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t4)){
t5=t3;
f_10432(t5,C_SCHEME_FALSE);}
else{
t5=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[7])[1],t1);
t6=C_mutate2(((C_word *)((C_word*)t0)[7])+1,t5);
t7=t3;
f_10432(t7,C_SCHEME_TRUE);}}}

/* k4362 in walk in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4364(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,4))){C_save_and_reclaim((void *)f_4364,2,av);}
a=C_alloc(21);
t2=t1;
t3=C_slot(t2,C_fix(3));
t4=t3;
t5=C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=C_eqp(t5,lf[5]);
if(C_truep(t7)){
t8=C_i_car(t4);
t9=C_slot(t8,C_fix(1));
t10=C_eqp(lf[34],t9);
if(C_truep(t10)){
t11=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t12=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t11);
t13=f_4175(((C_word*)((C_word*)t0)[5])[1]);
t14=C_u_i_car(t4);
t15=C_slot(t14,C_fix(2));
t16=C_i_car(t15);
t17=(C_truep(t16)?C_i_cadr(t4):C_i_caddr(t4));
/* optimizer.scm:180: walk */
t18=((C_word*)((C_word*)t0)[6])[1];
f_4350(t18,t6,t17,((C_word*)t0)[7],((C_word*)t0)[8]);}
else{
/* optimizer.scm:170: simplify */
t11=((C_word*)((C_word*)t0)[2])[1];
f_4216(t11,((C_word*)t0)[3],t2);}}
else{
t8=C_eqp(t5,lf[12]);
if(C_truep(t8)){
t9=C_i_car(t4);
t10=C_slot(t9,C_fix(1));
t11=C_eqp(lf[3],t10);
if(C_truep(t11)){
t12=C_u_i_car(t4);
t13=C_slot(t12,C_fix(2));
t14=C_i_car(t13);
t15=t14;
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4442,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t6,a[8]=t15,a[9]=((C_word*)t0)[2],a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4500,a[2]=t4,a[3]=t16,a[4]=((C_word*)t0)[11],a[5]=t15,tmp=(C_word)a,a+=6,tmp);
/* tweaks.scm:51: ##sys#get */
t18=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t18;
av2[1]=t17;
av2[2]=t15;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t18+1)))(4,av2);}}
else{
/* optimizer.scm:170: simplify */
t12=((C_word*)((C_word*)t0)[2])[1];
f_4216(t12,((C_word*)t0)[3],t2);}}
else{
/* optimizer.scm:170: simplify */
t9=((C_word*)((C_word*)t0)[2])[1];
f_4216(t9,((C_word*)t0)[3],t2);}}}

/* k7390 in argc-ok? in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_7392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_7392,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
/* optimizer.scm:925: argc-ok? */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7382(t5,t2,t4);}
else{
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* walk in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_4350(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,4))){
C_save_and_reclaim_args((void *)trf_4350,5,t0,t1,t2,t3,t4);}
a=C_alloc(12);
if(C_truep(C_i_memq(t2,*((C_word*)lf[39]+1)))){
t5=t2;
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=((C_word*)((C_word*)t0)[2])[1];
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4364,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t4,a[9]=t5,a[10]=((C_word*)t0)[2],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:172: walk1 */
t7=((C_word*)((C_word*)t0)[8])[1];
f_4563(t7,t6,t2,t3,t4);}}

/* argc-ok? in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_7382(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_7382,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_i_not(t2);
if(C_truep(t3)){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7392,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_fixnump(t2))){
t5=C_i_length(((C_word*)t0)[3]);
t6=t4;
f_7392(t6,C_eqp(t2,t5));}
else{
t5=t4;
f_7392(t5,C_SCHEME_FALSE);}}}

/* ##compiler#simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7379(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8=av[8];
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_7379,9,av);}
a=C_alloc(17);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7382,a[2]=t10,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
switch(t6){
case C_fix(1):
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7477,a[2]=t1,a[3]=t7,a[4]=t8,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t13=t4;
/* tweaks.scm:51: ##sys#get */
t14=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t14+1)))(4,av2);}
case C_fix(2):
if(C_truep(*((C_word*)lf[143]+1))){
t12=C_i_length(t8);
t13=C_i_car(t7);
if(C_truep(C_i_nequalp(t12,t13))){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7636,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t15=t4;
/* tweaks.scm:51: ##sys#get */
t16=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t16;
av2[1]=t14;
av2[2]=t15;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t16+1)))(4,av2);}}
else{
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(3):
if(C_truep(*((C_word*)lf[143]+1))){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7708,a[2]=t7,a[3]=t5,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t13=t4;
/* tweaks.scm:51: ##sys#get */
t14=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t14+1)))(4,av2);}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(4):
if(C_truep(*((C_word*)lf[143]+1))){
if(C_truep(*((C_word*)lf[145]+1))){
t12=C_i_length(t8);
t13=C_eqp(C_fix(2),t12);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7809,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t15=t4;
/* tweaks.scm:51: ##sys#get */
t16=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t16;
av2[1]=t14;
av2[2]=t15;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t16+1)))(4,av2);}}
else{
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(5):
if(C_truep(*((C_word*)lf[143]+1))){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7876,a[2]=t8,a[3]=t7,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t13=t4;
/* tweaks.scm:51: ##sys#get */
t14=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t14+1)))(4,av2);}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(6):
t12=C_i_caddr(t7);
t13=(C_truep(t12)?t12:*((C_word*)lf[145]+1));
if(C_truep(t13)){
if(C_truep(*((C_word*)lf[143]+1))){
t14=C_i_length(t8);
t15=C_eqp(C_fix(1),t14);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7983,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t17=t4;
/* tweaks.scm:51: ##sys#get */
t18=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t18;
av2[1]=t16;
av2[2]=t17;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t18+1)))(4,av2);}}
else{
t16=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t16;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}}
else{
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}
else{
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
case C_fix(7):
t12=C_i_cadddr(t7);
t13=(C_truep(t12)?t12:*((C_word*)lf[145]+1));
if(C_truep(t13)){
if(C_truep(*((C_word*)lf[143]+1))){
t14=C_i_length(t8);
t15=t7;
t16=C_u_i_car(t15);
if(C_truep(C_i_nequalp(t14,t16))){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8075,a[2]=t7,a[3]=t5,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t18=t4;
/* tweaks.scm:51: ##sys#get */
t19=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t19;
av2[1]=t17;
av2[2]=t18;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t19+1)))(4,av2);}}
else{
t17=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t17;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t17+1)))(2,av2);}}}
else{
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}
else{
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
case C_fix(8):
if(C_truep(*((C_word*)lf[143]+1))){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8150,a[2]=t7,a[3]=t1,a[4]=t2,a[5]=t5,a[6]=t8,tmp=(C_word)a,a+=7,tmp);
t13=t4;
/* tweaks.scm:51: ##sys#get */
t14=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t14+1)))(4,av2);}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(9):
if(C_truep(*((C_word*)lf[143]+1))){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8176,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t13=t4;
/* tweaks.scm:51: ##sys#get */
t14=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t14+1)))(4,av2);}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(10):
if(C_truep(*((C_word*)lf[143]+1))){
t12=C_i_cadddr(t7);
t13=(C_truep(t12)?t12:*((C_word*)lf[145]+1));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8435,a[2]=t8,a[3]=t7,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t15=t4;
/* tweaks.scm:51: ##sys#get */
t16=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t16;
av2[1]=t14;
av2[2]=t15;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t16+1)))(4,av2);}}
else{
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(11):
if(C_truep(*((C_word*)lf[143]+1))){
t12=C_i_caddr(t7);
t13=(C_truep(t12)?t12:*((C_word*)lf[145]+1));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8528,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t15=t4;
/* tweaks.scm:51: ##sys#get */
t16=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t16;
av2[1]=t14;
av2[2]=t15;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t16+1)))(4,av2);}}
else{
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(12):
if(C_truep(*((C_word*)lf[143]+1))){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8594,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t13=t4;
/* tweaks.scm:51: ##sys#get */
t14=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t14+1)))(4,av2);}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(13):
if(C_truep(*((C_word*)lf[143]+1))){
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8684,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t3,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
t13=t4;
/* tweaks.scm:51: ##sys#get */
t14=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t14+1)))(4,av2);}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(14):
if(C_truep(*((C_word*)lf[143]+1))){
t12=C_i_cadr(t7);
t13=C_i_length(t8);
if(C_truep(C_i_nequalp(t12,t13))){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8767,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t15=t4;
/* tweaks.scm:51: ##sys#get */
t16=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t16;
av2[1]=t14;
av2[2]=t15;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t16+1)))(4,av2);}}
else{
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(15):
if(C_truep(*((C_word*)lf[143]+1))){
t12=C_i_length(t8);
t13=C_eqp(C_fix(1),t12);
if(C_truep(t13)){
t14=*((C_word*)lf[145]+1);
t15=(C_truep(*((C_word*)lf[145]+1))?*((C_word*)lf[145]+1):C_i_cadddr(t7));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8864,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t17=t4;
/* tweaks.scm:51: ##sys#get */
t18=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t18;
av2[1]=t16;
av2[2]=t17;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t18+1)))(4,av2);}}
else{
t16=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t16;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}}
else{
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(16):
t12=C_i_car(t7);
t13=t12;
t14=C_i_length(t8);
t15=t14;
t16=C_i_caddr(t7);
t17=t16;
t18=C_i_cadddr(t7);
t19=t18;
t20=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8957,a[2]=t13,a[3]=t15,a[4]=t17,a[5]=t8,a[6]=t5,a[7]=t1,a[8]=t19,a[9]=t7,a[10]=t4,tmp=(C_word)a,a+=11,tmp);
t21=C_i_cddddr(t7);
if(C_truep(C_i_pairp(t21))){
/* optimizer.scm:1160: fifth */
t22=*((C_word*)lf[154]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t22;
av2[1]=t20;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t22+1)))(3,av2);}}
else{
t22=t20;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t22;
av2[1]=C_SCHEME_FALSE;
f_8957(2,av2);}}
case C_fix(17):
if(C_truep(*((C_word*)lf[143]+1))){
t12=C_i_length(t8);
t13=C_i_car(t7);
if(C_truep(C_i_nequalp(t12,t13))){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9109,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t15=t4;
/* tweaks.scm:51: ##sys#get */
t16=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t16;
av2[1]=t14;
av2[2]=t15;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t16+1)))(4,av2);}}
else{
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(18):
if(C_truep(*((C_word*)lf[143]+1))){
if(C_truep(C_i_nullp(t8))){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9192,a[2]=t5,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t13=t4;
/* tweaks.scm:51: ##sys#get */
t14=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t14+1)))(4,av2);}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(19):
if(C_truep(*((C_word*)lf[143]+1))){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9236,a[2]=t7,a[3]=t5,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t13=t4;
/* tweaks.scm:51: ##sys#get */
t14=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t14+1)))(4,av2);}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(20):
t12=C_i_length(t8);
t13=t12;
t14=C_i_cadddr(t7);
t15=(C_truep(t14)?t14:*((C_word*)lf[145]+1));
if(C_truep(t15)){
if(C_truep(*((C_word*)lf[143]+1))){
t16=t7;
t17=C_u_i_car(t16);
if(C_truep(C_i_nequalp(t13,t17))){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9428,a[2]=t7,a[3]=t5,a[4]=t1,a[5]=t13,a[6]=t8,tmp=(C_word)a,a+=7,tmp);
t19=t4;
/* tweaks.scm:51: ##sys#get */
t20=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t20;
av2[1]=t18;
av2[2]=t19;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t20+1)))(4,av2);}}
else{
t18=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t18;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}}
else{
t16=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t16;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}}
else{
t16=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t16;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}
case C_fix(21):
if(C_truep(*((C_word*)lf[143]+1))){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9515,a[2]=t7,a[3]=t5,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t13=t4;
/* tweaks.scm:51: ##sys#get */
t14=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t14+1)))(4,av2);}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
case C_fix(22):
t12=C_i_car(t7);
t13=C_i_length(t8);
t14=C_i_cadddr(t7);
t15=t14;
if(C_truep(*((C_word*)lf[143]+1))){
if(C_truep(C_i_nequalp(t13,t12))){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9719,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=t15,tmp=(C_word)a,a+=7,tmp);
t17=t4;
/* tweaks.scm:51: ##sys#get */
t18=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t18;
av2[1]=t16;
av2[2]=t17;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t18+1)))(4,av2);}}
else{
t16=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t16;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}}
else{
t16=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t16;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}
case C_fix(23):
if(C_truep(*((C_word*)lf[143]+1))){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9803,a[2]=t7,a[3]=t8,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t13=t4;
/* tweaks.scm:51: ##sys#get */
t14=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t14+1)))(4,av2);}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
default:
/* optimizer.scm:1329: bomb */
t12=*((C_word*)lf[156]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t12;
av2[1]=t1;
av2[2]=lf[157];
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}}

/* k6374 in k6359 in lp in walk-generic in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6376(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_6376,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
t5=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_record4(&a,4,lf[14],t3,t4,t1);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k7371 in k7361 in rewrite in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_7373,2,av);}
/* optimizer.scm:916: ##sys#hash-table-set! */
t2=*((C_word*)lf[129]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[140]+1);
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6380 in lp in walk-generic in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6382(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_6382,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6389,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[6])){
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
t6=t3;
f_6389(t6,C_eqp(t2,t5));}
else{
t4=t3;
f_6389(t4,C_SCHEME_FALSE);}}

/* k7361 in rewrite in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7363(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_7363,2,av);}
a=C_alloc(7);
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list1(&a,1,((C_word*)t0)[4]);
/* optimizer.scm:916: append */
t5=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t2;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k10477 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_10479(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_10479,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_u_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm:1436: every */
t4=*((C_word*)lf[43]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=((C_word*)t0)[5];
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6387 in k6380 in lp in walk-generic in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6389(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,4))){
C_save_and_reclaim_args((void *)trf_6389,2,t0,t1);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
/* optimizer.scm:514: lp */
t5=((C_word*)((C_word*)t0)[5])[1];
f_6351(t5,((C_word*)t0)[6],t1,t3,t4);}

/* k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7357(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,9))){C_save_and_reclaim((void *)f_7357,2,av);}
a=C_alloc(8);
t2=C_mutate2((C_word*)lf[140]+1 /* (set! ##compiler#substitution-table ...) */,t1);
t3=C_mutate2((C_word*)lf[141]+1 /* (set! ##compiler#rewrite ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7359,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate2((C_word*)lf[142]+1 /* (set! ##compiler#simplify-named-call ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7379,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate2((C_word*)lf[158]+1 /* (set! ##compiler#transform-direct-lambdas! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9975,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2((C_word*)lf[186]+1 /* (set! ##compiler#determine-loop-and-dispatch ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11420,tmp=(C_word)a,a+=2,tmp));
t7=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* ##compiler#rewrite in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7359(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +5,c,3))){
C_save_and_reclaim((void*)f_7359,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+5);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7363,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:915: ##sys#hash-table-ref */
t5=*((C_word*)lf[38]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[140]+1);
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k13426 in k13435 in k13381 in k13375 in a13363 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13428(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_13428,2,av);}
a=C_alloc(8);
t2=C_i_length(t1);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:651: varnode */
t5=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* lp in walk-generic in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6351(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_6351,5,t0,t1,t2,t3,t4);}
a=C_alloc(8);
if(C_truep(C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6361,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* optimizer.scm:509: invalidate-gae! */
f_4179(t5,((C_word*)t0)[7]);}
else{
t6=t5;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_6361(2,av2);}}}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6382,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(t3);
/* optimizer.scm:513: walk */
t7=((C_word*)((C_word*)t0)[9])[1];
f_4350(t7,t5,t6,((C_word*)t0)[10],((C_word*)t0)[7]);}}

/* a10985 in k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10986(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_10986,4,av);}
t4=C_i_cdr(t2);
t5=C_i_cdr(t3);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_eqp(t4,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k7874 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7876(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_7876,2,av);}
a=C_alloc(13);
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[2]);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=C_i_caddr(((C_word*)t0)[3]);
t5=C_i_not(t4);
t6=(C_truep(t5)?t5:C_eqp(t4,*((C_word*)lf[146]+1)));
if(C_truep(t6)){
t7=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t8=t7;
t9=((C_word*)t0)[3];
t10=C_u_i_car(t9);
t11=C_a_i_list1(&a,1,t10);
t12=t11;
t13=C_i_car(((C_word*)t0)[2]);
t14=t13;
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7935,a[2]=t14,a[3]=t12,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t8,tmp=(C_word)a,a+=7,tmp);
t16=((C_word*)t0)[3];
t17=C_u_i_cdr(t16);
t18=C_u_i_car(t17);
/* optimizer.scm:1002: qnode */
t19=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t19;
av2[1]=t15;
av2[2]=t18;
((C_proc)(void*)(*((C_word*)t19+1)))(3,av2);}}
else{
t7=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}
else{
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k13417 in k13413 in k13409 in k13426 in k13435 in k13381 in k13375 in a13363 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13419(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,1))){C_save_and_reclaim((void *)f_13419,2,av);}
a=C_alloc(23);
t2=C_a_i_list6(&a,6,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5],((C_word*)t0)[6]);
t3=((C_word*)t0)[7];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[22],lf[218],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6359 in lp in walk-generic in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6361(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_6361,2,av);}
a=C_alloc(5);
if(C_truep(((C_word*)t0)[2])){
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:511: reverse */
t3=*((C_word*)lf[107]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k13413 in k13409 in k13426 in k13435 in k13381 in k13375 in a13363 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13415(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_13415,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13419,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:654: qnode */
t4=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k13409 in k13426 in k13435 in k13381 in k13375 in a13363 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13411(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_13411,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13415,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:652: qnode */
t4=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k8888 in k8862 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8890,2,av);}
/* optimizer.scm:1141: cons* */
t2=*((C_word*)lf[151]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k12055 in for-each-loop2914 in k11922 in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 in ... */
static void C_ccall f_12057(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_12057,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12047(t3,((C_word*)t0)[4],t2);}

/* k8884 in k8862 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8886(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_8886,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a10483 in k10477 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10484(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_10484,3,av);}
/* optimizer.scm:1436: rec */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10216(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k12987 in k13202 in k13208 in loop1 in a12874 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12989(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_12989,2,av);}
a=C_alloc(10);
t2=t1;
if(C_truep(C_i_pairp(t2))){
t3=C_i_car(((C_word*)t0)[2]);
t4=C_u_i_car(t2);
t5=C_eqp(t3,t4);
if(C_truep(t5)){
t6=C_i_car(((C_word*)t0)[3]);
t7=C_a_i_list1(&a,1,t6);
t8=C_u_i_cdr(t2);
t9=C_i_cadr(((C_word*)t0)[4]);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13016,a[2]=t11,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_13016(t13,((C_word*)t0)[6],t7,t8,t9);}
else{
t6=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t3=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_12080(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(20,0,2))){
C_save_and_reclaim_args((void *)trf_12080,2,t0,t1);}
a=C_alloc(20);
if(C_truep(t1)){
/* optimizer.scm:1702: descend */
t2=((C_word*)((C_word*)t0)[2])[1];
f_12070(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=C_a_i_list1(&a,1,((C_word*)t0)[5]);
t3=t2;
t4=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12326,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t5,a[6]=t3,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:1711: gensym */
t7=*((C_word*)lf[83]+1);{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k3951 in k3904 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_3953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3953,2,av);}
/* optimizer.scm:82: scan-each */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3788(t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* a10436 in k10430 in k10424 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10437(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_10437,3,av);}
/* optimizer.scm:1423: rec */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10216(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k10430 in k10424 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_10432(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_10432,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1423: every */
t3=*((C_word*)lf[43]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=t2;
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6590 in k6584 in k6581 in g972 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,2))){
C_save_and_reclaim_args((void *)trf_6592,2,t0,t1);}
a=C_alloc(11);
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=C_i_caddr(t2);
t4=t3;
t5=C_slot(((C_word*)t0)[2],C_fix(3));
t6=C_i_car(t5);
t7=t6;
t8=C_slot(t7,C_fix(3));
t9=t8;
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6612,a[2]=t4,a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t9,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_listp(t4))){
t11=C_i_cdr(t4);
t12=t10;
f_6612(t12,C_i_nullp(t11));}
else{
t11=t10;
f_6612(t11,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_12070(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,2))){
C_save_and_reclaim_args((void *)trf_12070,3,t0,t1,t2);}
a=C_alloc(12);
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=C_i_cadr(t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12080,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t8=C_slot(t6,C_fix(1));
t9=C_eqp(lf[6],t8);
if(C_truep(t9)){
t10=C_slot(t6,C_fix(3));
t11=C_i_car(t10);
t12=C_slot(t11,C_fix(1));
t13=t7;
f_12080(t13,C_eqp(lf[15],t12));}
else{
t10=t7;
f_12080(t10,C_SCHEME_FALSE);}}

/* k7478 in k7475 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_7480(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(22,0,1))){
C_save_and_reclaim_args((void *)trf_7480,2,t0,t1);}
a=C_alloc(22);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(*((C_word*)lf[143]+1))){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=C_i_cadr(((C_word*)t0)[3]);
t4=C_a_i_list1(&a,1,t3);
t5=((C_word*)t0)[4];
t6=C_a_i_record4(&a,4,lf[14],lf[144],t4,t5);
t7=C_a_i_list2(&a,2,((C_word*)t0)[5],t6);
t8=((C_word*)t0)[2];
t9=t8;{
C_word av2[2];
av2[0]=t9;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],t2,t7);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* ##compiler#transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9975(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(!C_demand(C_calculate_demand(39,c,8))){C_save_and_reclaim((void *)f_9975,4,av);}
a=C_alloc(39);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9978,a[2]=t17,a[3]=t7,a[4]=t9,a[5]=t11,a[6]=t13,a[7]=t15,a[8]=t3,tmp=(C_word)a,a+=9,tmp));
t19=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10213,a[2]=t11,a[3]=t3,a[4]=t9,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t20=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10685,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11415,a[2]=t1,a[3]=t5,a[4]=t13,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1567: debugging */
t22=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t22;
av2[1]=t21;
av2[2]=lf[28];
av2[3]=lf[185];
((C_proc)(void*)(*((C_word*)t22+1)))(4,av2);}}

/* map-loop1295 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_7307(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_7307,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* walk in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_9978(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(22,0,4))){
C_save_and_reclaim_args((void *)trf_9978,5,t0,t1,t2,t3,t4);}
a=C_alloc(22);
t5=t3;
t6=C_slot(t5,C_fix(2));
t7=t3;
t8=C_slot(t7,C_fix(3));
t9=t8;
t10=t3;
t11=C_slot(t10,C_fix(1));
t12=C_eqp(t11,lf[11]);
if(C_truep(t12)){
t13=C_i_caddr(t6);
t14=t13;
t15=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10018,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=((C_word*)t0)[5],a[10]=t9,a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
t16=C_u_i_cdr(t6);
if(C_truep(C_u_i_car(t16))){
t17=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10130,a[2]=t15,a[3]=t14,a[4]=t3,a[5]=t9,a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:1355: get */
t18=*((C_word*)lf[33]+1);{
C_word av2[5];
av2[0]=t18;
av2[1]=t17;
av2[2]=((C_word*)t0)[8];
av2[3]=t2;
av2[4]=lf[99];
((C_proc)(void*)(*((C_word*)t18+1)))(5,av2);}}
else{
t17=t15;{
C_word av2[2];
av2[0]=t17;
av2[1]=C_SCHEME_FALSE;
f_10018(2,av2);}}}
else{
t16=t15;{
C_word av2[2];
av2[0]=t16;
av2[1]=C_SCHEME_FALSE;
f_10018(2,av2);}}}
else{
t13=C_eqp(t11,lf[13]);
if(C_truep(t13)){
t14=C_i_car(t6);
t15=C_i_car(t9);
/* optimizer.scm:1369: walk */
t21=t1;
t22=t14;
t23=t15;
t24=C_SCHEME_FALSE;
t1=t21;
t2=t22;
t3=t23;
t4=t24;
goto loop;}
else{
t14=C_eqp(t11,lf[6]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10156,a[2]=t9,a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t16=C_i_car(t6);
t17=C_i_car(t9);
/* optimizer.scm:1371: walk */
t21=t15;
t22=t16;
t23=t17;
t24=t3;
t1=t21;
t2=t22;
t3=t23;
t4=t24;
goto loop;}
else{
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10172,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t16=C_i_check_list_2(t9,lf[2]);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10184,a[2]=t18,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t20=((C_word*)t18)[1];
f_10184(t20,t1,t9);}}}}

/* k9483 in a9472 in k9426 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9485(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_9485,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* optimizer.scm:1243: append */
t3=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k7475 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7477(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_7477,2,av);}
a=C_alloc(14);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_length(((C_word*)t0)[4]);
t4=C_i_car(((C_word*)t0)[3]);
if(C_truep(C_i_nequalp(t3,t4))){
t5=C_i_car(((C_word*)t0)[4]);
t6=C_i_cadr(((C_word*)t0)[4]);
t7=C_slot(t5,C_fix(1));
t8=C_eqp(lf[3],t7);
if(C_truep(t8)){
t9=C_slot(t6,C_fix(1));
t10=C_eqp(lf[3],t9);
if(C_truep(t10)){
t11=C_slot(t5,C_fix(2));
t12=C_slot(t6,C_fix(2));
if(C_truep(C_i_equalp(t11,t12))){
t13=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t14=t13;
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7566,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t14,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:945: qnode */
t16=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t16;
av2[1]=t15;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t16+1)))(3,av2);}}
else{
t13=t2;
f_7480(t13,C_SCHEME_FALSE);}}
else{
t11=t2;
f_7480(t11,C_SCHEME_FALSE);}}
else{
t9=t2;
f_7480(t9,C_SCHEME_FALSE);}}
else{
t5=t2;
f_7480(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k10971 in for-each-loop2451 in k10794 in k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10973(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10973,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10963(t3,((C_word*)t0)[4],t2);}

/* g972 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6565(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,3))){
C_save_and_reclaim_args((void *)trf_6565,3,t0,t1,t2);}
a=C_alloc(14);
t3=C_i_cdr(t2);
t4=t3;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=C_i_cadr(t6);
t8=C_slot(t7,C_fix(2));
t9=C_i_car(t8);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6583,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=t10,tmp=(C_word)a,a+=9,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6800,a[2]=t11,a[3]=((C_word*)t0)[5],a[4]=t10,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:564: test */
t13=((C_word*)((C_word*)t0)[5])[1];
f_6537(t13,t12,t10,lf[99]);}

/* k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6564(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_6564,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6816,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:594: test */
t4=((C_word*)((C_word*)t0)[5])[1];
f_6537(t4,t3,lf[125],lf[126]);}
else{
t2=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_6547(2,av2);}}}

/* g1367 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6936(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_6936,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6946,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6968,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:848: filter */
t5=*((C_word*)lf[132]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6935(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,3))){C_save_and_reclaim((void *)f_6935,2,av);}
a=C_alloc(25);
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6936,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t7=((C_word*)t0)[3];
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6995,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7247,a[2]=t10,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_7247(t12,t8,t7);}

/* a9472 in k9426 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9473(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_9473,4,av);}
a=C_alloc(5);
t4=t2;
t5=t3;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9485,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm:1244: qnode */
t8=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* for-each-loop2451 in k10794 in k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_10963(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_10963,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10973,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1527: g2452 */
t5=((C_word*)t0)[3];
f_10730(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6930 in g1327 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6932(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_6932,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1),((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6303 in k6311 in k6315 in k6284 in k6326 in k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6305(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6305,2,av);}
t2=((C_word*)t0)[2];
f_6177(t2,C_i_not(t1));}

/* k6548 in k6545 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6550(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6550,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6284 in k6326 in k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6286(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_6286,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:483: test */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4139(t3,t2,((C_word*)t0)[6],lf[105]);}
else{
t2=((C_word*)t0)[2];
f_6177(t2,C_SCHEME_FALSE);}}

/* g1327 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6923(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_6923,4,t0,t1,t2,t3);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6932,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:839: scan-used-variables */
t5=*((C_word*)lf[131]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k13208 in loop1 in a12874 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13210(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_13210,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_u_i_car(((C_word*)t0)[4]);
/* optimizer.scm:702: get */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=t3;
av2[4]=lf[98];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* k6584 in k6581 in g972 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_6586,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t1)){
t3=C_i_length(t1);
t4=C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=C_i_length(((C_word*)t0)[6]);
t6=C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=C_slot(((C_word*)t0)[2],C_fix(1));
t8=t2;
f_6592(t8,C_eqp(lf[11],t7));}
else{
t7=t2;
f_6592(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_6592(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6592(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6592(t3,C_SCHEME_FALSE);}}

/* k6581 in g972 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6583(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_6583,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6586,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:565: get-list */
t4=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[7];
av2[3]=((C_word*)t0)[8];
av2[4]=lf[98];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k8862 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8864(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_8864,2,av);}
a=C_alloc(15);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_eqp(*((C_word*)lf[146]+1),t2);
if(C_truep(t3)){
t4=C_i_caddr(((C_word*)t0)[2]);
t5=C_a_i_list2(&a,2,C_SCHEME_TRUE,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8886,a[2]=((C_word*)t0)[3],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8890,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=((C_word*)t0)[2];
t10=C_u_i_cdr(t9);
t11=C_u_i_cdr(t10);
t12=C_u_i_car(t11);
/* optimizer.scm:1141: varnode */
t13=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t13;
av2[1]=t8;
av2[2]=t12;
((C_proc)(void*)(*((C_word*)t13+1)))(3,av2);}}
else{
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_eqp(*((C_word*)lf[146]+1),t4);
if(C_truep(t5)){
t6=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t7=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[5]);
t8=((C_word*)t0)[3];
t9=t8;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],t6,t7);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t6=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k13202 in k13208 in loop1 in a12874 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13204(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_13204,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_i_car(((C_word*)t0)[3]);
t3=C_slot(t2,C_fix(2));
t4=t3;
t5=C_slot(t2,C_fix(3));
t6=t5;
t7=C_slot(t2,C_fix(1));
t8=C_eqp(t7,lf[15]);
if(C_truep(t8)){
t9=C_u_i_car(((C_word*)t0)[4]);
t10=C_a_i_cons(&a,2,t9,((C_word*)t0)[5]);
t11=C_i_cadr(((C_word*)t0)[3]);
/* optimizer.scm:707: loop1 */
t12=((C_word*)((C_word*)t0)[6])[1];
f_12885(t12,((C_word*)t0)[2],t10,t11);}
else{
t9=C_eqp(t7,lf[13]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12989,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:709: reverse */
t11=*((C_word*)lf[107]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t10=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}}}}

/* k10058 in k10052 in k10046 in k10128 in walk in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10060(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_10060,2,av);}
a=C_alloc(10);
t2=t1;
if(C_truep(t2)){
t3=C_eqp(((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10113,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t5=C_slot(((C_word*)t0)[3],C_fix(2));
t6=C_i_car(t5);
/* tweaks.scm:57: ##sys#get */
t7=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t4;
av2[2]=t6;
av2[3]=lf[159];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_10018(2,av2);}}}
else{
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_10018(2,av2);}}}

/* a13363 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13364(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8=av[8];
C_word t9=av[9];
C_word t10=av[10];
C_word t11=av[11];
C_word t12=av[12];
C_word t13=av[13];
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_13364,14,av);}
a=C_alloc(12);
if(C_truep(C_i_equalp(t6,*((C_word*)lf[217]+1)))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13377,a[2]=t9,a[3]=t10,a[4]=t13,a[5]=t1,a[6]=t8,a[7]=t7,a[8]=t3,a[9]=t2,a[10]=t5,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:644: immediate? */
t15=*((C_word*)lf[219]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t15;
av2[1]=t14;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t15+1)))(3,av2);}}
else{
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}

/* walk-generic in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6345(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(13,0,5))){
C_save_and_reclaim_args((void *)trf_6345,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
a=C_alloc(13);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6351,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t8,a[6]=((C_word*)t0)[2],a[7]=t7,a[8]=t10,a[9]=((C_word*)t0)[3],a[10]=t6,tmp=(C_word)a,a+=11,tmp));
t12=((C_word*)t10)[1];
f_6351(t12,t1,C_SCHEME_TRUE,t5,C_SCHEME_END_OF_LIST);}

/* k9426 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9428(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,4))){C_save_and_reclaim((void *)f_9428,2,av);}
a=C_alloc(19);
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_a_i_list1(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9461,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9463,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9473,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1242: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t7;
av2[2]=t8;
av2[3]=t9;
C_call_with_values(4,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k8955 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8957(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_8957,2,av);}
a=C_alloc(10);
t2=t1;
if(C_truep(*((C_word*)lf[143]+1))){
t3=C_i_not(((C_word*)t0)[2]);
t4=(C_truep(t3)?t3:C_i_nequalp(((C_word*)t0)[3],((C_word*)t0)[2]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8980,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[3],a[8]=t2,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t6=((C_word*)t0)[10];
/* tweaks.scm:51: ##sys#get */
t7=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t5=((C_word*)t0)[7];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=((C_word*)t0)[7];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6315 in k6284 in k6326 in k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6317(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6317,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_6177(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:484: test */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4139(t3,t2,((C_word*)t0)[6],lf[98]);}}

/* k8536 in k8526 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_8538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,2))){
C_save_and_reclaim_args((void *)trf_8538,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list2(&a,2,C_SCHEME_TRUE,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8554,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8558,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=((C_word*)t0)[2];
t8=C_u_i_cdr(t7);
t9=C_u_i_car(t8);
/* optimizer.scm:1087: varnode */
t10=*((C_word*)lf[51]+1);{
C_word av2[3];
av2[0]=t10;
av2[1]=t6;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6311 in k6315 in k6284 in k6326 in k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6313(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_6313,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_6177(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6305,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* optimizer.scm:485: expression-has-side-effects? */
t4=*((C_word*)lf[85]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* f_6252 in k6232 in k6274 in k6175 in k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6252(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6252,3,av);}
t3=C_i_car(t2);
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t2;
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_i_set_i_slot(t5,C_fix(1),C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k7405 in k7390 in argc-ok? in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7407(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7407,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* optimizer.scm:926: argc-ok? */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7382(t4,((C_word*)t0)[4],t3);}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k7196 in a7151 in k7089 in a7077 in k7056 in k7053 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7198(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,1))){C_save_and_reclaim((void *)f_7198,2,av);}
a=C_alloc(25);
t2=C_a_i_list1(&a,1,t1);
t3=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t4=C_i_assq(((C_word*)t0)[2],((C_word*)t0)[3]);
t5=C_i_cdr(t4);
t6=C_a_i_list1(&a,1,t5);
t7=C_a_i_record4(&a,4,lf[14],lf[13],t3,t6);
t8=C_a_i_list2(&a,2,t7,((C_word*)t0)[4]);
t9=((C_word*)t0)[5];
t10=t9;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[6],t2,t8);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}

/* k6326 in k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6328(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_6328,2,av);}
a=C_alloc(10);
t2=C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6286(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6324,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:482: variable-visible? */
t5=*((C_word*)lf[106]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k6322 in k6326 in k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6324(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6324,2,av);}
t2=((C_word*)t0)[2];
f_6286(t2,C_i_not(t1));}

/* k10628 in k10617 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10630(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_10630,2,av);}
/* optimizer.scm:1447: rec */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10216(t2,((C_word*)t0)[3],((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k13275 in k13271 in k13288 in k13245 in a13233 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13277(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_13277,2,av);}
/* optimizer.scm:676: cons* */
t2=*((C_word*)lf[151]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
av2[4]=((C_word*)t0)[4];
av2[5]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k9459 in k9426 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9461(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,1))){C_save_and_reclaim((void *)f_9461,2,av);}
a=C_alloc(16);
t2=C_a_i_record4(&a,4,lf[14],lf[144],((C_word*)t0)[2],t1);
t3=C_a_i_list2(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[5],t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* a9462 in k9426 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9463(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_9463,2,av);}
a=C_alloc(4);
t2=C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
/* optimizer.scm:1242: split-at */
t3=*((C_word*)lf[87]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k13271 in k13288 in k13245 in a13233 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13273(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_13273,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13277,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:677: qnode */
t4=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* for-each-loop2928 in k11927 in g2915 in k11922 in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in ... */
static void C_fcall f_12017(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_12017,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12027,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1752: g2929 */
t5=((C_word*)t0)[3];
f_11930(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6274 in k6175 in k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6276(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_6276,2,av);}
a=C_alloc(14);
t2=C_a_i_list1(&a,1,t1);
t3=C_a_i_record4(&a,4,lf[14],lf[13],((C_word*)t0)[2],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6234,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:492: test */
t6=((C_word*)((C_word*)t0)[6])[1];
f_4139(t6,t5,((C_word*)t0)[3],lf[56]);}

/* k13267 in k13288 in k13245 in a13233 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13269(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_13269,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[22],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8526 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8528(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_8528,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_8538(t6,t4);}
else{
t6=C_i_length(((C_word*)t0)[5]);
t7=((C_word*)t0)[2];
t8=C_u_i_car(t7);
t9=t5;
f_8538(t9,C_i_nequalp(t6,t8));}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6206 in k6232 in k6274 in k6175 in k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6208(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6208,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10617 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_10619,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1447: append */
t5=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k13288 in k13245 in a13233 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13290(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,2))){C_save_and_reclaim((void *)f_13290,2,av);}
a=C_alloc(17);
t2=C_i_length(t1);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t5=C_a_i_list1(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13269,a[2]=((C_word*)t0)[3],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13273,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:676: varnode */
t9=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k3987 in k3984 in k3904 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_3989(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_3989,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4007,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t5=C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[8])[1]);
t6=t4;
f_4007(t6,C_i_not(t5));}
else{
t5=t4;
f_4007(t5,C_SCHEME_FALSE);}}

/* k3984 in k3904 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_3986(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_3986,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:93: alist-ref */
t3=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)((C_word*)t0)[9])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* for-each-loop876 in k6232 in k6274 in k6175 in k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6210(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_6210,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6220,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:490: g877 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a5266 in k5260 in k5257 in k5254 in k5243 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5267(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,7))){C_save_and_reclaim((void *)f_5267,3,av);}
a=C_alloc(18);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5270,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5284,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(((C_word*)t0)[12],C_fix(3));
t6=C_i_car(t5);
/* optimizer.scm:389: inline-lambda-bindings */
t7=*((C_word*)lf[71]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t7;
av2[1]=t4;
av2[2]=((C_word*)t0)[13];
av2[3]=((C_word*)t0)[14];
av2[4]=t6;
av2[5]=C_SCHEME_TRUE;
av2[6]=((C_word*)t0)[15];
av2[7]=t3;
((C_proc)(void*)(*((C_word*)t7+1)))(8,av2);}}

/* k7440 in loop in a9843 in k9830 in k9801 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_7442(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_7442,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm:930: qnode */
t3=*((C_word*)lf[40]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
/* optimizer.scm:931: qnode */
t2=*((C_word*)lf[40]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k7148 in k7089 in a7077 in k7056 in k7053 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7150(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_7150,2,av);}
/* optimizer.scm:888: fold-right */
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a7151 in k7089 in a7077 in k7056 in k7053 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7152(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_7152,4,av);}
a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7198,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:896: gensym */
t5=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k8978 in k8955 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8980(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_8980,2,av);}
a=C_alloc(14);
if(C_truep(t1)){
t2=*((C_word*)lf[145]+1);
t3=(C_truep(*((C_word*)lf[145]+1))?*((C_word*)lf[145]+1):((C_word*)t0)[2]);
if(C_truep(t3)){
t4=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9019,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_truep(((C_word*)t0)[8])?(C_truep(C_fixnum_greaterp(((C_word*)t0)[7],C_fix(0)))?C_fixnum_less_or_equal_p(((C_word*)t0)[7],C_fix(8)):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_i_cadr(((C_word*)t0)[9]);
/* optimizer.scm:1171: conc */
t10=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=t7;
av2[2]=t9;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}
else{
t9=t7;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_i_cadr(((C_word*)t0)[9]);
f_9019(2,av2);}}}
else{
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k12831 in a12785 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12833(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,1))){C_save_and_reclaim((void *)f_12833,2,av);}
a=C_alloc(22);
t2=C_i_length(t1);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t5=((C_word*)t0)[3];
t6=C_a_i_record4(&a,4,lf[14],lf[144],t4,t5);
t7=C_a_i_list3(&a,3,t6,((C_word*)t0)[4],((C_word*)t0)[5]);
t8=((C_word*)t0)[6];
t9=((C_word*)t0)[7];
t10=t8;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[5],t9,t7);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6218 in for-each-loop876 in k6232 in k6274 in k6175 in k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6220(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6220,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6210(t3,((C_word*)t0)[4],t2);}

/* k5257 in k5254 in k5243 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,4))){C_save_and_reclaim((void *)f_5259,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* optimizer.scm:379: debugging */
t3=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[18];
av2[3]=lf[79];
av2[4]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5254 in k5243 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5256(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,4))){C_save_and_reclaim((void *)f_5256,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5259,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* optimizer.scm:378: check-signature */
t3=*((C_word*)lf[74]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[17];
av2[3]=((C_word*)t0)[14];
av2[4]=((C_word*)t0)[13];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6232 in k6274 in k6175 in k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6234(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_6234,2,av);}
a=C_alloc(13);
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6235,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6252,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));
t3=t2;
t4=((C_word*)t0)[3];
t5=C_i_check_list_2(t4,lf[2]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6208,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6210,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_6210(t10,t6,t4);}

/* f_6235 in k6232 in k6274 in k6175 in k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6235(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6235,3,av);}
t3=C_i_cdr(t2);
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t2;
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_i_set_i_slot(t5,C_fix(1),C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k13096 in a13089 in k13045 in loop2 in k12987 in k13202 in k13208 in loop1 in a12874 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13098(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_13098,2,av);}
/* optimizer.scm:730: reorganize-recursive-bindings */
t2=*((C_word*)lf[130]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a13089 in k13045 in loop2 in k12987 in k13202 in k13208 in loop1 in a12874 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13090(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_13090,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13098,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:730: reverse */
t3=*((C_word*)lf[107]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* a7119 in k7089 in a7077 in k7056 in k7053 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7120(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,1))){C_save_and_reclaim((void *)f_7120,4,av);}
a=C_alloc(19);
t4=C_a_i_list1(&a,1,t2);
t5=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=C_a_i_list2(&a,2,t5,t3);
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[6],t4,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_5242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(23,0,6))){
C_save_and_reclaim_args((void *)trf_5242,2,t0,t1);}
a=C_alloc(23);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(C_truep(((C_word*)t0)[18])?lf[80]:lf[81]);
t4=C_i_cadddr(((C_word*)t0)[19]);
/* optimizer.scm:371: debugging */
t5=*((C_word*)lf[17]+1);{
C_word av2[7];
av2[0]=t5;
av2[1]=t2;
av2[2]=lf[76];
av2[3]=t3;
av2[4]=((C_word*)t0)[10];
av2[5]=((C_word*)t0)[20];
av2[6]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(7,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5340,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[21],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[3],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[22],a[15]=((C_word*)t0)[23],a[16]=((C_word*)t0)[2],a[17]=((C_word*)t0)[10],a[18]=((C_word*)t0)[24],a[19]=((C_word*)t0)[25],a[20]=((C_word*)t0)[26],a[21]=((C_word*)t0)[14],a[22]=((C_word*)t0)[20],tmp=(C_word)a,a+=23,tmp);
/* optimizer.scm:394: test */
t3=((C_word*)((C_word*)t0)[24])[1];
f_4139(t3,t2,((C_word*)t0)[20],lf[68]);}}

/* k5243 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5245(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,3))){C_save_and_reclaim((void *)f_5245,2,av);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5246,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
t4=C_i_check_list_2(t3,lf[2]);
t5=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5256,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[2],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5305,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5305(t9,t5,t3);}

/* g620 in k5243 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_5246(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,5))){
C_save_and_reclaim_args((void *)trf_5246,3,t0,t1,t2);}
t3=*((C_word*)lf[47]+1);
/* optimizer.scm:377: g635 */
t4=*((C_word*)lf[47]+1);{
C_word av2[6];
av2[0]=t4;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
av2[4]=lf[70];
av2[5]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}

/* k3993 in k3990 in k3987 in k3984 in k3904 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_3995(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3995,2,av);}
/* optimizer.scm:104: remember */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3776(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k5260 in k5257 in k5254 in k5243 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5262(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_5262,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm:380: call/cc */
t3=*((C_word*)lf[78]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[16];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3990 in k3987 in k3984 in k3904 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_3992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_3992,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_memq(((C_word*)t0)[4],((C_word*)t0)[6]))){
/* optimizer.scm:104: remember */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3776(t3,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
/* optimizer.scm:103: mark */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3753(t3,t2,((C_word*)t0)[4]);}}

/* k6835 in for-each-loop971 in k6814 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6837(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6837,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6827(t3,((C_word*)t0)[4],t2);}

/* k4973 in k4874 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4975(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,8))){C_save_and_reclaim((void *)f_4975,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:287: decompose-lambda-list */
t3=*((C_word*)lf[66]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[8];
av2[2]=((C_word*)t0)[9];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* optimizer.scm:299: walk-generic */
t3=((C_word*)((C_word*)t0)[10])[1];
f_6345(t3,((C_word*)t0)[8],((C_word*)t0)[11],((C_word*)t0)[12],((C_word*)t0)[3],((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}}

/* a4979 in k4973 in k4874 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4980(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_4980,5,av);}
a=C_alloc(10);
t5=f_4175(((C_word*)((C_word*)t0)[2])[1]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4987,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:291: debugging */
t7=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[18];
av2[3]=lf[67];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k4985 in a4979 in k4973 in k4874 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4987(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,4))){C_save_and_reclaim((void *)f_4987,2,av);}
a=C_alloc(14);
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_i_cadr(((C_word*)t0)[2]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5027,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t7=C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1));
/* optimizer.scm:296: build-lambda-list */
t8=*((C_word*)lf[62]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=((C_word*)t0)[9];
av2[3]=t7;
av2[4]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}

/* k6814 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6816(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_6816,2,av);}
a=C_alloc(6);
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_i_check_list_2(t2,lf[2]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6827,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6827(t7,((C_word*)t0)[3],t2);}

/* loop1 in a12874 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_12885(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_12885,4,t0,t1,t2,t3);}
a=C_alloc(8);
t4=t3;
t5=C_slot(t4,C_fix(1));
t6=t3;
t7=C_slot(t6,C_fix(2));
t8=t7;
t9=t3;
t10=C_slot(t9,C_fix(3));
t11=t10;
t12=C_eqp(t5,lf[6]);
if(C_truep(t12)){
t13=C_i_cdr(t8);
if(C_truep(C_i_nullp(t13))){
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13210,a[2]=t1,a[3]=t11,a[4]=t8,a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t15=C_u_i_car(t8);
/* optimizer.scm:701: get */
t16=*((C_word*)lf[33]+1);{
C_word av2[5];
av2[0]=t16;
av2[1]=t14;
av2[2]=((C_word*)t0)[3];
av2[3]=t15;
av2[4]=lf[105];
((C_proc)(void*)(*((C_word*)t16+1)))(5,av2);}}
else{
t14=t1;{
C_word av2[2];
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}
else{
t13=t1;{
C_word av2[2];
av2[0]=t13;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}}

/* loop2 in k12987 in k13202 in k13208 in loop1 in a12874 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_13016(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_demand(C_calculate_demand(16,0,4))){
C_save_and_reclaim_args((void *)trf_13016,5,t0,t1,t2,t3,t4);}
a=C_alloc(16);
t5=t4;
t6=C_slot(t5,C_fix(1));
t7=t4;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t4;
t11=C_slot(t10,C_fix(3));
t12=t11;
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13047,a[2]=t12,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
t14=C_eqp(t6,lf[6]);
if(C_truep(t14)){
t15=C_i_cdr(t9);
if(C_truep(C_i_nullp(t15))){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13180,a[2]=t13,a[3]=t3,a[4]=t12,a[5]=t9,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t17=C_u_i_car(t9);
/* optimizer.scm:720: get */
t18=*((C_word*)lf[33]+1);{
C_word av2[5];
av2[0]=t18;
av2[1]=t16;
av2[2]=((C_word*)t0)[4];
av2[3]=t17;
av2[4]=lf[105];
((C_proc)(void*)(*((C_word*)t18+1)))(5,av2);}}
else{
t16=t13;
f_13047(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_13047(t15,C_SCHEME_FALSE);}}

/* a12874 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12875(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_12875,5,av);}
a=C_alloc(9);
t5=C_a_i_list1(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12885,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_12885(t9,t1,t5,t4);}

/* k12025 in for-each-loop2928 in k11927 in g2915 in k11922 in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in ... */
static void C_ccall f_12027(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_12027,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12017(t3,((C_word*)t0)[4],t2);}

/* touch in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static C_word C_fcall f_4175(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_overflow_check;{}
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* invalidate-gae! in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_4179(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(2,0,2))){
C_save_and_reclaim_args((void *)trf_4179,2,t1,t2);}
a=C_alloc(2);
t3=C_i_check_list_2(t2,lf[2]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4193,tmp=(C_word)a,a+=2,tmp);
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=f_4193(t2);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k4106 in for-each-loop110 in k4069 in k4066 in k4063 in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_4108(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4108,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4098(t3,((C_word*)t0)[4],t2);}

/* for-each-loop2914 in k11922 in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_12047(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_12047,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12057,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1751: g2915 */
t5=((C_word*)t0)[3];
f_11925(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k11225 in k11222 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11227(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_11227,2,av);}
t2=C_u_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm:1513: node-subexpressions-set! */
t3=*((C_word*)lf[121]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k11222 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11224(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_11224,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1512: node-parameters-set! */
t3=*((C_word*)lf[122]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k8697 in k8682 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8699(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_8699,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8714,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[6]))){
t5=((C_word*)t0)[6];
t6=C_u_i_cdr(t5);
t7=t4;
f_8714(t7,C_a_i_cons(&a,2,C_SCHEME_TRUE,t6));}
else{
t5=t4;
f_8714(t5,((C_word*)t0)[6]);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k4127 in k4066 in k4063 in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_4129(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4129,2,av);}
/* optimizer.scm:111: debugging */
t2=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[18];
av2[3]=lf[25];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6798 in g972 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6800,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_6583(2,av2);}}
else{
/* optimizer.scm:564: test */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6537(t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[49]);}}

/* k7933 in k7874 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7935(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,1))){C_save_and_reclaim((void *)f_7935,2,av);}
a=C_alloc(22);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[14],lf[144],((C_word*)t0)[3],t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[5];
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[6],t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* constant-node? in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4145(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4145,3,av);}
t3=C_slot(t2,C_fix(1));
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_eqp(lf[34],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k8652 in k8592 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8654(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8654,2,av);}
/* optimizer.scm:1102: cons* */
t2=*((C_word*)lf[151]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k8648 in k8592 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8650(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_8650,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_5208(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(22,0,5))){
C_save_and_reclaim_args((void *)trf_5208,2,t0,t1);}
a=C_alloc(22);
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=t2;
t4=C_i_caddr(t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5224,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[2],a[15]=t5,a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],tmp=(C_word)a,a+=22,tmp);
/* optimizer.scm:358: decompose-lambda-list */
t7=*((C_word*)lf[66]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=((C_word*)t0)[20];
av2[2]=t5;
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5752,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[20],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_eqp(lf[3],t3);
if(C_truep(t4)){
t5=C_slot(((C_word*)t0)[2],C_fix(2));
t6=C_i_car(t5);
/* tweaks.scm:51: ##sys#get */
t7=*((C_word*)lf[45]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t2;
av2[2]=t6;
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t5=t2;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_5752(2,av2);}}}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_5752(2,av2);}}}}

/* k5709 in k5731 in k5735 in k5689 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5711(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5711,2,av);}
t2=C_eqp(t1,lf[53]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_5242(t3,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
f_5242(t3,((C_word*)t0)[3]);}
else{
t3=C_i_cadddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[2];
f_5242(t4,C_i_lessp(t3,*((C_word*)lf[93]+1)));}}}

/* k8682 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8684(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_8684,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[2]);
t3=(C_truep(t2)?t2:*((C_word*)lf[145]+1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
t6=C_u_i_car(t5);
/* optimizer.scm:1111: argc-ok? */
t7=((C_word*)((C_word*)t0)[7])[1];
f_7382(t7,t4,t6);}
else{
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5224(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,3))){C_save_and_reclaim((void *)f_5224,5,av);}
a=C_alloc(26);
t5=C_i_car(((C_word*)t0)[2]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_5746,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=t1,a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[2],a[19]=t6,a[20]=t3,a[21]=((C_word*)t0)[18],a[22]=((C_word*)t0)[19],a[23]=((C_word*)t0)[20],a[24]=t2,a[25]=((C_word*)t0)[21],tmp=(C_word)a,a+=26,tmp);
/* tweaks.scm:57: ##sys#get */
t8=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)t0)[17];
av2[3]=lf[95];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5746(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(35,c,3))){C_save_and_reclaim((void *)f_5746,2,av);}
a=C_alloc(35);
t2=C_i_structurep(t1,lf[14]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_5242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=t3,a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],tmp=(C_word)a,a+=27,tmp);
if(C_truep(*((C_word*)lf[92]+1))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5691,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[17],a[6]=((C_word*)t0)[23],a[7]=((C_word*)t0)[19],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:364: test */
t6=((C_word*)((C_word*)t0)[23])[1];
f_4139(t6,t5,((C_word*)t0)[17],lf[94]);}
else{
t5=t4;
f_5242(t5,C_SCHEME_FALSE);}}

/* k10052 in k10046 in k10128 in walk in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10054(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_10054,2,av);}
a=C_alloc(11);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:1359: get-list */
t4=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[10];
av2[3]=((C_word*)t0)[7];
av2[4]=lf[126];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_10018(2,av2);}}}

/* k5731 in k5735 in k5689 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5733,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_5242(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tweaks.scm:57: ##sys#get */
t3=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=lf[54];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k10046 in k10128 in walk in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10048(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_10048,2,av);}
a=C_alloc(11);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10054,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:1358: get-list */
t4=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[9];
av2[3]=((C_word*)t0)[6];
av2[4]=lf[98];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_10018(2,av2);}}}

/* k5735 in k5689 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5737(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5737,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_5242(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:366: test */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4139(t3,t2,((C_word*)t0)[7],lf[64]);}}

/* k7762 in k7715 in k7706 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7764(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_7764,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],t2);
/* optimizer.scm:971: fold-right */
t4=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[5];
av2[3]=t3;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k9903 in loop in a9843 in k9830 in k9801 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9905(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_9905,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4470 in a4450 in k4440 in k4362 in walk in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4472(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,1))){C_save_and_reclaim((void *)f_4472,2,av);}
a=C_alloc(14);
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=C_i_cadr(((C_word*)t0)[2]);
t4=C_a_i_list2(&a,2,t3,t1);
t5=((C_word*)t0)[3];
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],t2,t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* test in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_4139(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_4139,4,t0,t1,t2,t3);}
/* optimizer.scm:142: get */
t4=*((C_word*)lf[33]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(53,c,7))){C_save_and_reclaim((void *)f_4133,2,av);}
a=C_alloc(53);
t2=C_mutate2((C_word*)lf[30]+1 /* (set! ##compiler#simplifications ...) */,t1);
t3=C_set_block_item(lf[31] /* ##compiler#simplified-ops */,0,C_SCHEME_END_OF_LIST);
t4=C_mutate2((C_word*)lf[32]+1 /* (set! ##compiler#perform-high-level-optimizations ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4136,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate2((C_word*)lf[119]+1 /* (set! ##compiler#perform-pre-optimization! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6530,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2((C_word*)lf[128]+1 /* (set! register-simplifications ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6850,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6857,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=C_a_i_list(&a,1,lf[193]);
t9=C_a_i_list(&a,2,lf[3],t8);
t10=C_a_i_cons(&a,2,lf[227],lf[228]);
t11=C_a_i_cons(&a,2,t9,t10);
t12=C_a_i_cons(&a,2,lf[223],t11);
t13=C_a_i_cons(&a,2,lf[12],t12);
t14=C_a_i_list(&a,4,lf[193],lf[227],lf[228],lf[223]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13535,tmp=(C_word)a,a+=2,tmp);
t16=C_a_i_list(&a,3,t13,t14,t15);
/* optimizer.scm:606: register-simplifications */
t17=*((C_word*)lf[128]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t17;
av2[1]=t7;
av2[2]=lf[12];
av2[3]=t16;
((C_proc)(void*)(*((C_word*)t17+1)))(4,av2);}}

/* ##compiler#perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4136(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word *a;
if(!C_demand(C_calculate_demand(86,c,9))){C_save_and_reclaim((void *)f_4136,4,av);}
a=C_alloc(86);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4139,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t35=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4145,tmp=(C_word)a,a+=2,tmp));
t36=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4175,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t37=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4179,tmp=(C_word)a,a+=2,tmp));
t38=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4216,a[2]=t13,a[3]=t21,a[4]=t25,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t39=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4350,a[2]=t15,a[3]=t25,a[4]=t7,a[5]=t21,a[6]=t27,a[7]=t19,a[8]=t31,tmp=(C_word)a,a+=9,tmp));
t40=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4543,a[2]=t3,a[3]=t29,a[4]=t17,tmp=(C_word)a,a+=5,tmp));
t41=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4563,a[2]=t21,a[3]=t17,a[4]=t9,a[5]=t29,a[6]=t5,a[7]=t27,a[8]=t33,a[9]=t3,a[10]=t23,a[11]=t11,tmp=(C_word)a,a+=12,tmp));
t42=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6345,a[2]=t23,a[3]=t27,tmp=(C_word)a,a+=4,tmp));
t43=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6410,a[2]=t1,a[3]=t2,a[4]=t15,a[5]=t7,a[6]=t5,a[7]=t9,a[8]=t13,a[9]=t27,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:517: perform-pre-optimization! */
t44=*((C_word*)lf[119]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t44;
av2[1]=t43;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t44+1)))(4,av2);}}

/* a4450 in k4440 in k4362 in walk in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4451(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4451,6,av);}
a=C_alloc(4);
if(C_truep(t2)){
t6=f_4175(((C_word*)((C_word*)t0)[2])[1]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4472,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:204: qnode */
t8=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4461,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
t7=t6;
f_4461(t7,C_SCHEME_UNDEFINED);}
else{
t7=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_FALSE);
t8=t6;
f_4461(t8,t7);}}}

/* k5279 in k5272 in cfk in a5266 in k5260 in k5257 in k5254 in k5243 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 in ... */
static void C_ccall f_5281(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5281,2,av);}
/* optimizer.scm:387: return */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5282 in a5266 in k5260 in k5257 in k5254 in k5243 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5284(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5284,2,av);}
t2=f_4175(((C_word*)((C_word*)t0)[2])[1]);
/* optimizer.scm:393: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4350(t3,((C_word*)t0)[4],t1,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* for-each-loop2413 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_11287(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_11287,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11297,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1522: g2414 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* cfk in a5266 in k5260 in k5257 in k5254 in k5243 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,5))){C_save_and_reclaim((void *)f_5270,3,av);}
a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5274,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:383: debugging */
t4=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[76];
av2[3]=lf[77];
av2[4]=((C_word*)t0)[10];
av2[5]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}

/* k5272 in cfk in a5266 in k5260 in k5257 in k5254 in k5243 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5274(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,8))){C_save_and_reclaim((void *)f_5274,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:388: walk-generic */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6345(t3,t2,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9],((C_word*)t0)[10],C_SCHEME_TRUE);}

/* k11295 in for-each-loop2413 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11297,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11287(t3,((C_word*)t0)[4],t2);}

/* k11273 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11275(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11275,2,av);}
/* optimizer.scm:1521: rec */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
f_11004(3,av2);}}

/* k7827 in k7807 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7829(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_7829,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7837,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=C_i_cadr(((C_word*)t0)[6]);
/* optimizer.scm:987: qnode */
t7=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k5990 in k6007 in k5977 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5992,2,av);}
t2=((C_word*)t0)[2];
f_5090(t2,C_i_not(t1));}

/* k7835 in k7827 in k7807 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7837(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,1))){C_save_and_reclaim((void *)f_7837,2,av);}
a=C_alloc(20);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list5(&a,5,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1,t2);
t4=((C_word*)t0)[6];
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[7],t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k12225 in k12312 in k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in ... */
static void C_ccall f_12227(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_12227,2,av);}
t2=((C_word*)t0)[2];
t3=C_slot(t2,C_fix(3));
t4=C_i_cdr(t3);
/* optimizer.scm:1724: append */
t5=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t1;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k12217 in k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in ... */
static void C_ccall f_12219(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,2))){C_save_and_reclaim((void *)f_12219,2,av);}
a=C_alloc(33);
t2=C_a_i_record4(&a,4,lf[14],lf[22],((C_word*)t0)[2],t1);
t3=C_a_i_list1(&a,1,t2);
t4=C_a_i_record4(&a,4,lf[14],lf[11],((C_word*)t0)[3],t3);
t5=C_a_i_list1(&a,1,t4);
t6=C_a_i_record4(&a,4,lf[14],lf[13],((C_word*)t0)[4],t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12151,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12155,a[2]=t8,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1744: varnode */
t10=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=((C_word*)t0)[11];
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* a12241 in k12312 in k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in ... */
static void C_ccall f_12242(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_12242,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12250,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_cadr(t2);
/* optimizer.scm:1728: qnode */
t5=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* a13534 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13535(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_13535,7,av);}
a=C_alloc(8);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13543,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:612: ##sys#hash-table-ref */
t8=*((C_word*)lf[38]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=*((C_word*)lf[140]+1);
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k4627 in k4607 in k4601 in k4595 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4629(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4629,2,av);}
t2=C_slot(t1,C_fix(2));
t3=C_i_car(t2);
/* optimizer.scm:234: qnode */
t4=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7981 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,1))){C_save_and_reclaim((void *)f_7983,2,av);}
a=C_alloc(33);
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
t5=C_a_i_list1(&a,1,t4);
t6=C_i_cadr(((C_word*)t0)[2]);
t7=C_a_i_list1(&a,1,t6);
t8=((C_word*)t0)[3];
t9=C_a_i_record4(&a,4,lf[14],lf[144],t7,t8);
t10=C_a_i_list1(&a,1,t9);
t11=C_a_i_record4(&a,4,lf[14],lf[144],t5,t10);
t12=C_a_i_list2(&a,2,((C_word*)t0)[4],t11);
t13=((C_word*)t0)[5];
t14=t13;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],t2,t12);
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k5977 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5979(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5979,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:317: test */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4139(t3,t2,((C_word*)t0)[5],lf[57]);}
else{
t2=((C_word*)t0)[2];
f_5090(t2,C_SCHEME_FALSE);}}

/* k6638 in k6631 in k6622 in k6616 in k6610 in k6590 in k6584 in k6581 in g972 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6640(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_6640,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_u_i_cdr(((C_word*)t0)[6]);
/* optimizer.scm:589: node-subexpressions-set! */
t4=*((C_word*)lf[121]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k6641 in k6638 in k6631 in k6622 in k6616 in k6610 in k6590 in k6584 in k6581 in g972 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6643(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_6643,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[4]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6661,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=C_u_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm:592: reverse */
t7=*((C_word*)lf[107]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k8073 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8075(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_8075,2,av);}
a=C_alloc(16);
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_a_i_list1(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8108,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8116,a[2]=t7,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm:1026: qnode */
t10=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t8;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k4601 in k4595 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4603(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4603,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=f_4175(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:233: debugging */
t4=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[18];
av2[3]=lf[50];
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t2=C_u_i_car(((C_word*)t0)[6]);
t3=C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
t4=C_i_assq(((C_word*)t0)[5],((C_word*)t0)[7]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4652,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:230: g354 */
t6=t5;
f_4652(t6,((C_word*)t0)[3],t4);}
else{
/* optimizer.scm:247: varnode */
t5=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}
else{
t4=f_4175(((C_word*)((C_word*)t0)[2])[1]);
t5=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t6=C_mutate2(((C_word *)((C_word*)t0)[8])+1,t5);
/* optimizer.scm:238: varnode */
t7=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}}}

/* k4607 in k4601 in k4595 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4609(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4609,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4629,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:234: test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4139(t3,t2,((C_word*)t0)[4],lf[49]);}

/* k11541 in k11527 in walk in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_11543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(13,0,3))){
C_save_and_reclaim_args((void *)trf_11543,2,t0,t1);}
a=C_alloc(13);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[5]);
/* optimizer.scm:1633: walk */
t5=((C_word*)((C_word*)t0)[6])[1];
f_11483(t5,((C_word*)t0)[7],((C_word*)t0)[8],t4);}
else{
t2=f_11423(C_a_i(&a,6),((C_word*)((C_word*)t0)[9])[1]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11560,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1637: walk */
t4=((C_word*)((C_word*)t0)[6])[1];
f_11483(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k6631 in k6622 in k6616 in k6610 in k6590 in k6584 in k6581 in g972 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_6633,2,t0,t1);}
a=C_alloc(12);
if(C_truep(t1)){
t2=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6640,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:588: node-parameters-set! */
t5=*((C_word*)lf[122]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[8];
av2[3]=lf[123];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6644 in k6641 in k6638 in k6631 in k6622 in k6616 in k6610 in k6590 in k6584 in k6581 in g972 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6646(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6646,2,av);}
/* optimizer.scm:593: touch */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=f_6533(((C_word*)((C_word*)t0)[3])[1]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9876 in loop in a9843 in k9830 in k9801 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9878(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_9878,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9882,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* optimizer.scm:1325: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9858(t6,t3,C_SCHEME_END_OF_LIST,t5);}

/* k9880 in k9876 in loop in a9843 in k9830 in k9801 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9882(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_9882,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5676 in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5678(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5678,2,av);}
if(C_truep(t1)){
t2=C_i_memq(((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[4];
f_5539(t3,C_i_not(t2));}
else{
t2=((C_word*)t0)[4];
f_5539(t2,C_SCHEME_FALSE);}}

/* k5689 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5691(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_5691,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:365: test */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4139(t3,t2,((C_word*)t0)[7],lf[70]);}
else{
t2=((C_word*)t0)[2];
f_5242(t2,C_SCHEME_FALSE);}}

/* k12288 in loop in k12248 in a12241 in k12312 in k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in ... */
static void C_ccall f_12290(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_12290,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12294,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
t5=C_u_i_cdr(t4);
t6=((C_word*)t0)[5];
t7=C_u_i_cdr(t6);
/* optimizer.scm:1736: loop */
t8=((C_word*)((C_word*)t0)[6])[1];
f_12260(t8,t3,t5,t7);}

/* for-each-loop188 in invalidate-gae! in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static C_word C_fcall f_4193(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
loop:{}
if(C_truep(C_i_pairp(t1))){
t2=C_slot(t1,C_fix(0));
t3=C_i_set_cdr(t2,C_SCHEME_FALSE);
t4=C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
t2=C_SCHEME_UNDEFINED;
return(t2);}}

/* k6181 in k6175 in k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6183(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_6183,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k12292 in k12288 in loop in k12248 in a12241 in k12312 in k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in ... */
static void C_ccall f_12294(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_12294,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[6],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k8174 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8176(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_8176,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[2]);
if(C_truep(C_fixnum_lessp(t2,C_fix(2)))){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1040: qnode */
t6=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(*((C_word*)lf[145]+1))){
t4=C_eqp(*((C_word*)lf[146]+1),lf[150]);
t5=t3;
f_8208(t5,C_i_not(t4));}
else{
t4=t3;
f_8208(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k8712 in k8697 in k8682 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_8714(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,4))){
C_save_and_reclaim_args((void *)trf_8714,2,t0,t1);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8718,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],C_SCHEME_TRUE);
t5=C_a_i_record4(&a,4,lf[14],lf[152],t4,C_SCHEME_END_OF_LIST);
/* optimizer.scm:1114: cons* */
t6=*((C_word*)lf[151]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k8716 in k8712 in k8697 in k8682 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8718(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_8718,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* loop in a9843 in k9830 in k9801 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_9858(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_9858,4,t0,t1,t2,t3);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t2))){
if(C_truep(C_i_nullp(t3))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9878,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=C_i_car(t3);
t6=t4;
t7=t5;
if(C_truep(C_i_symbolp(t7))){
/* optimizer.scm:929: varnode */
t8=*((C_word*)lf[51]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7442,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t7))){
t9=C_u_i_car(t7);
t10=t8;
f_7442(t10,C_eqp(lf[34],t9));}
else{
t9=t8;
f_7442(t9,C_SCHEME_FALSE);}}}}
else{
if(C_truep(C_i_nullp(t3))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_car(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9905,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_i_cdr(t3);
/* optimizer.scm:1327: loop */
t11=t6;
t12=t8;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* k9850 in a9843 in k9830 in k9801 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_9852,2,av);}
/* optimizer.scm:1318: append */
t2=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3904 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_fcall f_3906(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_3906,2,t0,t1);}
a=C_alloc(12);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* optimizer.scm:75: scan */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3825(t4,t2,t3,((C_word*)t0)[7]);}
else{
t2=C_eqp(((C_word*)t0)[8],lf[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3938,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3953,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:82: butlast */
t5=*((C_word*)lf[9]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_eqp(((C_word*)t0)[8],lf[10]);
t4=(C_truep(t3)?t3:C_eqp(((C_word*)t0)[8],lf[11]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eqp(((C_word*)t0)[8],lf[12]);
if(C_truep(t5)){
/* optimizer.scm:87: touch */
t6=((C_word*)t0)[6];{
C_word av2[2];
av2[0]=t6;
av2[1]=f_3783(((C_word*)((C_word*)t0)[2])[1]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(((C_word*)t0)[8],lf[13]);
if(C_truep(t6)){
t7=C_i_car(((C_word*)t0)[9]);
t8=t7;
t9=C_i_car(((C_word*)t0)[4]);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3986,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[6],a[4]=t8,a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:92: scan */
t11=((C_word*)((C_word*)t0)[5])[1];
f_3825(t11,t10,t9,((C_word*)t0)[7]);}
else{
/* optimizer.scm:106: scan-each */
t7=((C_word*)((C_word*)t0)[10])[1];
f_3788(t7,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[7]);}}}}}}

/* k3907 in k3904 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_3909(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_3909,2,av);}
a=C_alloc(7);
t2=f_3783(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=C_u_i_car(((C_word*)t0)[4]);
/* optimizer.scm:77: scan */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3825(t5,t3,t4,((C_word*)t0)[7]);}

/* k8148 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8150(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_8150,2,av);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
/* optimizer.scm:1030: g1670 */
t3=t2;{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[2];
av2[4]=((C_word*)t0)[5];
av2[5]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k4463 in k4459 in a4450 in k4440 in k4362 in walk in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4465(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4465,2,av);}
t2=C_mutate2((C_word*)lf[39]+1 /* (set! ##compiler#broken-constant-nodes ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4459 in a4450 in k4440 in k4362 in walk in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_4461(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,4))){
C_save_and_reclaim_args((void *)trf_4461,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:199: lset-adjoin */
t3=*((C_word*)lf[41]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[27]+1);
av2[3]=*((C_word*)lf[39]+1);
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* loop in k12248 in a12241 in k12312 in k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in ... */
static void C_fcall f_12260(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,2))){
C_save_and_reclaim_args((void *)trf_12260,4,t0,t1,t2,t3);}
a=C_alloc(10);
if(C_truep(C_i_nullp(t3))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_i_cadddr(((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_car(t3);
t5=C_a_i_list1(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12290,a[2]=t1,a[3]=t6,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=C_i_car(t2);
/* optimizer.scm:1735: varnode */
t9=*((C_word*)lf[51]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}

/* k6175 in k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,4))){
C_save_and_reclaim_args((void *)trf_6177,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=f_4175(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6183,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:487: debugging */
t4=*((C_word*)lf[17]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[18];
av2[3]=lf[104];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6276,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[8]);
/* optimizer.scm:490: walk */
t4=((C_word*)((C_word*)t0)[9])[1];
f_4350(t4,t2,t3,((C_word*)t0)[10],((C_word*)t0)[6]);}}

/* k11527 in walk in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_11529(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(24,0,4))){
C_save_and_reclaim_args((void *)trf_11529,2,t0,t1);}
a=C_alloc(24);
if(C_truep(t1)){
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[5]);
/* optimizer.scm:1620: walk */
t4=((C_word*)((C_word*)t0)[6])[1];
f_11483(t4,((C_word*)t0)[7],((C_word*)t0)[8],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11543,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_slot(((C_word*)t0)[9],C_fix(1));
t4=C_eqp(lf[13],t3);
if(C_truep(t4)){
t5=C_slot(((C_word*)t0)[9],C_fix(3));
t6=C_i_car(t5);
t7=t6;
t8=C_slot(((C_word*)t0)[9],C_fix(2));
t9=C_i_car(t8);
t10=t9;
t11=C_slot(t7,C_fix(1));
t12=C_eqp(lf[11],t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11591,a[2]=t10,a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11604,a[2]=t13,a[3]=((C_word*)t0)[12],a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11619,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1627: get */
t16=*((C_word*)lf[33]+1);{
C_word av2[5];
av2[0]=t16;
av2[1]=t15;
av2[2]=((C_word*)t0)[12];
av2[3]=t10;
av2[4]=lf[98];
((C_proc)(void*)(*((C_word*)t16+1)))(5,av2);}}
else{
t13=t2;
f_11543(t13,C_SCHEME_FALSE);}}
else{
t5=t2;
f_11543(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_11543(t3,C_SCHEME_FALSE);}}}

/* k12252 in k12248 in a12241 in k12312 in k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in ... */
static void C_ccall f_12254(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_12254,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list2(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k12248 in a12241 in k12312 in k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in ... */
static void C_ccall f_12250(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_12250,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12254,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_caddr(((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12260,a[2]=((C_word*)t0)[3],a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_12260(t8,t3,((C_word*)t0)[4],t4);}

/* k6138 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6140(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_6140,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k7278 in for-each-loop1326 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7280(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7280,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_7270(t4,((C_word*)t0)[5],t2,t3);}

/* k3943 in k3936 in k3904 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_3945(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_3945,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:83: append */
t4=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3947 in k3943 in k3936 in k3904 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_3949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3949,2,av);}
/* optimizer.scm:83: scan */
t2=((C_word*)((C_word*)t0)[2])[1];
f_3825(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k4440 in k4362 in walk in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4442(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,6))){C_save_and_reclaim((void *)f_4442,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=C_i_cddr(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4451,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:192: constant-form-eval */
t4=*((C_word*)lf[42]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[7];
av2[2]=((C_word*)t0)[8];
av2[3]=t2;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
/* optimizer.scm:170: simplify */
t2=((C_word*)((C_word*)t0)[9])[1];
f_4216(t2,((C_word*)t0)[10],((C_word*)t0)[4]);}}

/* k6149 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6151(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_6151,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
/* optimizer.scm:476: debugging */
t2=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[76];
av2[3]=lf[103];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
t2=((C_word*)t0)[4];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3936 in k3904 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_3938(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3938,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:83: last */
t3=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8106 in k8073 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8108(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,1))){C_save_and_reclaim((void *)f_8108,2,av);}
a=C_alloc(16);
t2=C_a_i_record4(&a,4,lf[14],lf[144],((C_word*)t0)[2],t1);
t3=C_a_i_list2(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[5],t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6134(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_6134,2,av);}
a=C_alloc(12);
if(C_truep(t1)){
t2=f_4175(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6140,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6151,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:475: test */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4139(t5,t4,((C_word*)t0)[4],lf[56]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:478: test */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4139(t3,t2,((C_word*)t0)[4],lf[48]);}}

/* k7255 in for-each-loop1366 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7257(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7257,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7247(t3,((C_word*)t0)[4],t2);}

/* k3913 in k3907 in k3904 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_3915(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3915,2,av);}
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t3=C_i_cadr(((C_word*)t0)[3]);
/* optimizer.scm:79: scan */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3825(t4,((C_word*)t0)[5],t3,((C_word*)t0)[6]);}

/* k6101 in map-loop804 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6103(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6103,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6078(t6,((C_word*)t0)[5],t5);}

/* for-each-loop1366 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_7247(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_7247,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7257,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:843: g1367 */
t5=((C_word*)t0)[3];
f_6936(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7741 in a7721 in k7715 in k7706 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7743(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,1))){C_save_and_reclaim((void *)f_7743,2,av);}
a=C_alloc(14);
t2=C_a_i_list1(&a,1,t1);
t3=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=((C_word*)t0)[4];
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[6],t2,t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* for-each-loop1326 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_7270(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_7270,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7280,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* optimizer.scm:825: g1327 */
t9=((C_word*)t0)[3];
f_6923(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k7715 in k7706 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_7717(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,4))){
C_save_and_reclaim_args((void *)trf_7717,2,t0,t1);}
a=C_alloc(12);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7722,tmp=(C_word)a,a+=2,tmp);
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7764,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=((C_word*)t0)[5];
t7=C_u_i_car(t6);
/* optimizer.scm:974: varnode */
t8=*((C_word*)lf[51]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t5;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6158 in k6132 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6160(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_6160,2,av);}
a=C_alloc(18);
if(C_truep(t1)){
t2=f_4175(((C_word*)((C_word*)t0)[2])[1]);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6328,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:481: test */
t4=((C_word*)((C_word*)t0)[7])[1];
f_4139(t4,t3,((C_word*)t0)[4],lf[56]);}}

/* k10828 in for-each-loop2515 in k10820 in k10817 in k10814 in k10797 in k10794 in k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in ... */
static void C_ccall f_10830(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_10830,2,av);}
a=C_alloc(5);
t2=C_slot(((C_word*)t0)[2],C_fix(3));
t3=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_i_set_car(t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k7634 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7636(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,1))){C_save_and_reclaim((void *)f_7636,2,av);}
a=C_alloc(22);
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[2]);
t3=(C_truep(t2)?t2:*((C_word*)lf[145]+1));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[3]);
t5=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_car(t7);
t9=C_a_i_list1(&a,1,t8);
t10=((C_word*)t0)[3];
t11=C_a_i_record4(&a,4,lf[14],lf[144],t9,t10);
t12=C_a_i_list2(&a,2,((C_word*)t0)[4],t11);
t13=((C_word*)t0)[5];
t14=t13;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],t5,t12);
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
else{
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a10886 in k10814 in k10797 in k10794 in k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10887(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,1))){C_save_and_reclaim((void *)f_10887,4,av);}
a=C_alloc(19);
t4=C_i_car(t2);
t5=C_a_i_list1(&a,1,t4);
t6=t2;
t7=C_u_i_cdr(t6);
t8=C_slot(t7,C_fix(3));
t9=C_i_car(t8);
t10=C_slot(t9,C_fix(1));
t11=C_slot(t9,C_fix(2));
t12=C_slot(t9,C_fix(3));
t13=C_a_i_record4(&a,4,lf[14],t10,t11,t12);
t14=C_a_i_list2(&a,2,t13,t3);
t15=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[6],t5,t14);
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}

/* k10817 in k10814 in k10797 in k10794 in k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10819(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_10819,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1558: copy-node! */
t3=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k10814 in k10797 in k10794 in k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10816(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_10816,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10887,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:1549: fold-right */
t4=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k10872 in for-each-loop2515 in k10820 in k10817 in k10814 in k10797 in k10794 in k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in ... */
static void C_ccall f_10874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10874,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10864(t3,((C_word*)t0)[4],t2);}

/* k7706 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7708(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_7708,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7717,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_7717(t5,t3);}
else{
t5=C_i_length(((C_word*)t0)[5]);
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_car(t7);
t9=t4;
f_7717(t9,C_i_nequalp(t5,t8));}}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k7232 in for-each-loop1390 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7234(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7234,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7224(t3,((C_word*)t0)[4],t2);}

/* for-each-loop2515 in k10820 in k10817 in k10814 in k10797 in k10794 in k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in ... */
static void C_fcall f_10864(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(13,0,2))){
C_save_and_reclaim_args((void *)trf_10864,3,t0,t1,t2);}
a=C_alloc(13);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10874,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=C_i_cdr(t4);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10830,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10859,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1562: gensym */
t10=*((C_word*)lf[83]+1);{
C_word av2[2];
av2[0]=t10;
av2[1]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* for-each-loop1390 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_7224(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_7224,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7234,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:856: g1391 */
t5=((C_word*)t0)[3];
f_6996(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8114 in k8073 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8116(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_8116,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* optimizer.scm:1025: append */
t3=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_10216(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,5))){
C_save_and_reclaim_args((void *)trf_10216,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(9);
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t7;
t9=t2;
t10=C_slot(t9,C_fix(3));
t11=t10;
t12=t2;
t13=C_slot(t12,C_fix(1));
t14=C_eqp(t13,lf[3]);
if(C_truep(t14)){
t15=C_i_car(t8);
t16=t15;
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10280,a[2]=t1,a[3]=t16,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1384: get */
t18=*((C_word*)lf[33]+1);{
C_word av2[5];
av2[0]=t18;
av2[1]=t17;
av2[2]=((C_word*)t0)[5];
av2[3]=t16;
av2[4]=lf[160];
((C_proc)(void*)(*((C_word*)t18+1)))(5,av2);}}
else{
t15=C_eqp(t13,lf[11]);
if(C_truep(t15)){
if(C_truep(t3)){
t16=C_i_caddr(t8);
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10298,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t11,a[5]=((C_word*)t0)[7],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1392: decompose-lambda-list */
t18=*((C_word*)lf[66]+1);{
C_word av2[4];
av2[0]=t18;
av2[1]=t1;
av2[2]=t16;
av2[3]=t17;
((C_proc)(void*)(*((C_word*)t18+1)))(4,av2);}}
else{
t16=t1;{
C_word av2[2];
av2[0]=t16;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}}
else{
t16=C_eqp(t13,lf[89]);
if(C_truep(t16)){
t17=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t17)){
t18=t1;{
C_word av2[2];
av2[0]=t18;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}
else{
t18=C_i_cadr(t8);
t19=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[4])[1],t18);
t20=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t19);
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10335,a[2]=((C_word*)t0)[7],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1401: every */
t22=*((C_word*)lf[43]+1);{
C_word av2[4];
av2[0]=t22;
av2[1]=t1;
av2[2]=t21;
av2[3]=t11;
((C_proc)(void*)(*((C_word*)t22+1)))(4,av2);}}}
else{
t17=C_eqp(t13,lf[69]);
if(C_truep(t17)){
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[8])){
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10369,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[9],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t19=C_i_car(t11);
/* optimizer.scm:1404: scan-used-variables */
t20=*((C_word*)lf[131]+1);{
C_word av2[4];
av2[0]=t20;
av2[1]=t18;
av2[2]=t19;
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t20+1)))(4,av2);}}
else{
t18=t1;{
C_word av2[2];
av2[0]=t18;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}}
else{
t18=t1;{
C_word av2[2];
av2[0]=t18;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}}
else{
t18=C_eqp(t13,lf[161]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10385,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=t1,a[5]=t11,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t20=C_i_cadr(t8);
/* optimizer.scm:1409: estimate-foreign-result-size */
t21=*((C_word*)lf[162]+1);{
C_word av2[3];
av2[0]=t21;
av2[1]=t19;
av2[2]=t20;
((C_proc)(void*)(*((C_word*)t21+1)))(3,av2);}}
else{
t19=C_eqp(t13,lf[163]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10426,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=t1,a[5]=t11,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t21=C_i_car(t8);
/* optimizer.scm:1417: estimate-foreign-result-size */
t22=*((C_word*)lf[162]+1);{
C_word av2[3];
av2[0]=t22;
av2[1]=t20;
av2[2]=t21;
((C_proc)(void*)(*((C_word*)t22+1)))(3,av2);}}
else{
t20=C_eqp(t13,lf[12]);
if(C_truep(t20)){
t21=C_i_car(t11);
t22=C_slot(t21,C_fix(1));
t23=C_eqp(lf[3],t22);
if(C_truep(t23)){
t24=C_slot(t21,C_fix(2));
t25=C_i_car(t24);
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10479,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=t11,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t27=C_eqp(t25,((C_word*)t0)[10]);
if(C_truep(t27)){
if(C_truep(C_i_zerop(((C_word*)((C_word*)t0)[4])[1]))){
t28=C_i_cadr(t11);
t29=C_slot(t28,C_fix(1));
t30=C_eqp(lf[3],t29);
if(C_truep(t30)){
t31=C_slot(t28,C_fix(2));
t32=C_i_car(t31);
t33=C_a_i_cons(&a,2,t32,((C_word*)((C_word*)t0)[11])[1]);
t34=C_mutate2(((C_word *)((C_word*)t0)[11])+1,t33);
t35=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t36=t26;
f_10479(t36,C_SCHEME_TRUE);}
else{
t31=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t32=t26;
f_10479(t32,C_SCHEME_TRUE);}}
else{
t28=t26;
f_10479(t28,C_SCHEME_FALSE);}}
else{
t28=t26;
f_10479(t28,C_eqp(t25,((C_word*)t0)[12]));}}
else{
t24=t1;{
C_word av2[2];
av2[0]=t24;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t24+1)))(2,av2);}}}
else{
t21=C_eqp(t13,lf[164]);
if(C_truep(t21)){
t22=C_i_cadddr(t8);
t23=C_i_zerop(t22);
if(C_truep(t23)){
t24=t1;{
C_word av2[2];
av2[0]=t24;
av2[1]=t23;
((C_proc)(void*)(*((C_word*)t24+1)))(2,av2);}}
else{
t24=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t24)){
t25=t1;{
C_word av2[2];
av2[0]=t25;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t25+1)))(2,av2);}}
else{
t25=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[4])[1],t22);
t26=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t25);
t27=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10586,a[2]=((C_word*)t0)[7],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1443: every */
t28=*((C_word*)lf[43]+1);{
C_word av2[4];
av2[0]=t28;
av2[1]=t1;
av2[2]=t27;
av2[3]=t11;
((C_proc)(void*)(*((C_word*)t28+1)))(4,av2);}}}}
else{
t22=C_eqp(t13,lf[13]);
if(C_truep(t22)){
t23=C_i_car(t11);
t24=C_i_car(t8);
/* optimizer.scm:1444: rec */
t37=t1;
t38=t23;
t39=t24;
t40=C_SCHEME_FALSE;
t41=t5;
t1=t37;
t2=t38;
t3=t39;
t4=t40;
t5=t41;
goto loop;}
else{
t23=C_eqp(t13,lf[6]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10619,a[2]=t11,a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=t8,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t25=C_i_car(t11);
t26=C_i_car(t8);
/* optimizer.scm:1446: rec */
t37=t24;
t38=t25;
t39=t26;
t40=t2;
t41=t5;
t1=t37;
t2=t38;
t3=t39;
t4=t40;
t5=t41;
goto loop;}
else{
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10643,a[2]=((C_word*)t0)[7],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1448: every */
t25=*((C_word*)lf[43]+1);{
C_word av2[4];
av2[0]=t25;
av2[1]=t1;
av2[2]=t24;
av2[3]=t11;
((C_proc)(void*)(*((C_word*)t25+1)))(4,av2);}}}}}}}}}}}}

/* scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_10213(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_demand(C_calculate_demand(25,0,6))){
C_save_and_reclaim_args((void *)trf_10213,7,t0,t1,t2,t3,t4,t5,t6);}
a=C_alloc(25);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10216,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t8,a[7]=t12,a[8]=t5,a[9]=((C_word*)t0)[4],a[10]=t4,a[11]=((C_word*)t0)[5],a[12]=t3,tmp=(C_word)a,a+=13,tmp));
t14=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10676,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1452: rec */
t18=((C_word*)t12)[1];
f_10216(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k10857 in for-each-loop2515 in k10820 in k10817 in k10814 in k10797 in k10794 in k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in ... */
static void C_ccall f_10859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_10859,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* optimizer.scm:1562: node-parameters-set! */
t3=*((C_word*)lf[122]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a11690 in walk in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11691(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(29,c,4))){C_save_and_reclaim((void *)f_11691,5,av);}
a=C_alloc(29);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11697,a[2]=t10,a[3]=((C_word*)t0)[2],a[4]=t12,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11704,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11714,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=t12,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:1642: ##sys#dynamic-wind */
t16=*((C_word*)lf[187]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t16;
av2[1]=t1;
av2[2]=t13;
av2[3]=t14;
av2[4]=t15;
((C_proc)(void*)(*((C_word*)t16+1)))(5,av2);}}

/* a11696 in a11690 in walk in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11697(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_11697,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[7])[1]);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k10278 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10280(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,1))){C_save_and_reclaim((void *)f_10280,2,av);}
a=C_alloc(4);
t2=C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_memq(((C_word*)t0)[3],((C_word*)t0)[4]);
t4=C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[6])[1],C_fix(2));
t7=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t6);
t8=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}}}

/* touch in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static C_word C_fcall f_3783(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
return(t2);}

/* k11086 in k11083 in k11080 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_11088,2,av);}
t2=C_i_cddr(((C_word*)t0)[2]);
/* optimizer.scm:1494: node-subexpressions-set! */
t3=*((C_word*)lf[121]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k11083 in k11080 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_11085,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list2(&a,2,C_SCHEME_TRUE,((C_word*)t0)[5]);
/* optimizer.scm:1493: node-parameters-set! */
t4=*((C_word*)lf[122]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* scan-each in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_fcall f_3788(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_3788,4,t0,t1,t2,t3);}
a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3790,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_check_list_2(t2,lf[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3802,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3802(t9,t1,t2);}

/* k11080 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11082(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_11082,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1492: node-class-set! */
t3=*((C_word*)lf[170]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[171];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5083(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,3))){C_save_and_reclaim((void *)f_5083,2,av);}
a=C_alloc(27);
t2=t1;
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5090,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[2],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],tmp=(C_word)a,a+=21,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5979,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:316: test */
t6=((C_word*)((C_word*)t0)[17])[1];
f_4139(t6,t5,((C_word*)t0)[10],lf[58]);}

/* k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5080(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,3))){C_save_and_reclaim((void *)f_5080,2,av);}
a=C_alloc(24);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5083,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6025,a[2]=t3,a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:312: test */
t5=((C_word*)((C_word*)t0)[16])[1];
f_4139(t5,t4,((C_word*)t0)[9],lf[99]);}

/* k3779 in remember in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_3781(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3781,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a13099 in k13045 in loop2 in k12987 in k13202 in k13208 in loop1 in a12874 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13100(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_13100,4,av);}
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=(C_truep(t3)?t2:C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k10820 in k10817 in k10814 in k10797 in k10794 in k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 in ... */
static void C_ccall f_10822(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_10822,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10864,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10864(t6,((C_word*)t0)[3],t2);}

/* k4851 in k4716 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4853(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4853,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4860,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:253: test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4139(t3,t2,((C_word*)t0)[4],lf[57]);}
else{
t2=((C_word*)t0)[2];
f_4721(t2,C_SCHEME_FALSE);}}

/* k3758 in mark in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_fcall f_3760(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,1))){
C_save_and_reclaim_args((void *)trf_3760,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* map-loop2790 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_12447(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_12447,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_caddr(t3);
t5=C_i_length(t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t6);
t9=C_slot(t2,C_fix(1));
t11=t1;
t12=t9;
t1=t11;
t2=t12;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k12443 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12445(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_12445,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[194]+1);
av2[3]=t1;
C_apply(4,av2);}}

/* k5446 in k5440 in k5434 in loop in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5448(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,5))){C_save_and_reclaim((void *)f_5448,2,av);}
a=C_alloc(11);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:415: gensym */
t3=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[84];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_cdr(t2);
t4=C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
t5=((C_word*)t0)[5];
t6=C_u_i_cdr(t5);
/* optimizer.scm:418: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_5354(t7,((C_word*)t0)[2],t3,t4,t6,((C_word*)t0)[7]);}}

/* a7721 in k7715 in k7706 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7722(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_7722,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7743,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:973: gensym */
t5=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k12721 in a12702 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12723(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,1))){C_save_and_reclaim((void *)f_12723,2,av);}
a=C_alloc(25);
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);
t3=C_a_i_record4(&a,4,lf[14],lf[21],C_SCHEME_END_OF_LIST,t2);
t4=C_a_i_list2(&a,2,t1,t3);
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[6];
t7=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],t6,t4);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k5440 in k5434 in loop in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5442(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_5442,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_i_car(((C_word*)t0)[5]);
/* optimizer.scm:412: expression-has-side-effects? */
t4=*((C_word*)lf[85]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=((C_word*)t0)[11];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_5090(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(27,0,4))){
C_save_and_reclaim_args((void *)trf_5090,2,t0,t1);}
a=C_alloc(27);
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(2));
t3=C_i_caddr(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5104,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],a[9]=t4,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:323: check-signature */
t6=*((C_word*)lf[74]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[11];
av2[3]=((C_word*)t0)[9];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5170,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[3],a[15]=((C_word*)t0)[6],a[16]=((C_word*)t0)[11],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5845,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[19],tmp=(C_word)a,a+=6,tmp);
/* tweaks.scm:57: ##sys#get */
t4=*((C_word*)lf[45]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[11];
av2[3]=lf[100];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* g43 in scan-each in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_fcall f_3790(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_3790,3,t0,t1,t2);}
/* optimizer.scm:60: scan */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3825(t3,t1,t2,((C_word*)t0)[3]);}

/* k5434 in loop in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5436(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,5))){C_save_and_reclaim((void *)f_5436,2,av);}
a=C_alloc(12);
if(C_truep(t1)){
t2=f_4175(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
t4=((C_word*)t0)[4];
t5=C_u_i_car(t4);
/* optimizer.scm:409: debugging */
t6=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=lf[18];
av2[3]=lf[86];
av2[4]=t5;
av2[5]=((C_word*)t0)[13];
((C_proc)(void*)(*((C_word*)t6+1)))(6,av2);}}
else{
t2=((C_word*)t0)[4];
t3=C_u_i_cdr(t2);
t4=C_a_i_minus(&a,2,((C_word*)t0)[5],C_fix(1));
t5=C_i_cdr(((C_word*)t0)[6]);
t6=((C_word*)t0)[6];
t7=C_u_i_car(t6);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[8]);
/* optimizer.scm:419: loop */
t9=((C_word*)((C_word*)t0)[7])[1];
f_5354(t9,((C_word*)t0)[3],t3,t4,t5,t8);}}

/* a8278 in k8229 in k8220 in k8209 in k8206 in k8174 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8279(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_8279,4,av);}
a=C_alloc(11);
t4=C_a_i_list2(&a,2,t2,t3);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[144],((C_word*)t0)[2],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k8275 in k8229 in k8220 in k8209 in k8206 in k8174 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8277(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,5))){C_save_and_reclaim((void *)f_8277,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],t2);
/* optimizer.scm:1046: fold-right */
t4=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[5];
av2[3]=t3;
av2[4]=((C_word*)t0)[6];
av2[5]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}

/* k5428 in loop in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_5430,2,av);}
a=C_alloc(17);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5381,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5394,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5394(t7,t3,t2);}

/* k5466 in k5484 in k5446 in k5440 in k5434 in loop in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5468(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_5468,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5472,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
t5=C_u_i_cdr(t4);
t6=C_a_i_minus(&a,2,((C_word*)t0)[5],C_fix(1));
t7=((C_word*)t0)[6];
t8=C_u_i_cdr(t7);
/* optimizer.scm:417: loop */
t9=((C_word*)((C_word*)t0)[7])[1];
f_5354(t9,t3,t5,t6,t8,((C_word*)t0)[8]);}

/* for-each-loop502 in k5105 in k5102 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_5143(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_5143,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5153,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:326: g503 */
t5=((C_word*)t0)[3];
f_5111(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a12702 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12703(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8=av[8];
C_word t9=av[9];
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_12703,10,av);}
a=C_alloc(7);
if(C_truep(*((C_word*)lf[143]+1))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12723,a[2]=t6,a[3]=t7,a[4]=t8,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:785: varnode */
t11=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t10=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}}

/* remember in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_fcall f_3776(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,4))){
C_save_and_reclaim_args((void *)trf_3776,4,t0,t1,t2,t3);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3781,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:53: alist-update! */
t5=*((C_word*)lf[1]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
av2[3]=t3;
av2[4]=((C_word*)((C_word*)t0)[2])[1];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k9826 in k9801 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9828(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_9828,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_5170(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(21,0,4))){
C_save_and_reclaim_args((void *)trf_5170,2,t0,t1);}
a=C_alloc(21);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:345: debugging */
t3=*((C_word*)lf[17]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[18];
av2[3]=lf[75];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5208,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[4],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[2],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[3],tmp=(C_word)a,a+=21,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=t2;
f_5208(t4,C_eqp(lf[11],t3));}
else{
t3=t2;
f_5208(t3,C_SCHEME_FALSE);}}}

/* k5171 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5173(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,1))){C_save_and_reclaim((void *)f_5173,2,av);}
a=C_alloc(19);
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=C_i_car(((C_word*)t0)[2]);
t4=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t5=C_a_i_list2(&a,2,t3,t4);
t6=((C_word*)t0)[3];
t7=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],t2,t5);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k4716 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4718(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_4718,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_4721(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4853,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:252: test */
t4=((C_word*)((C_word*)t0)[11])[1];
f_4139(t4,t3,((C_word*)t0)[10],lf[58]);}}

/* k9801 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9803(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,2))){C_save_and_reclaim((void *)f_9803,2,av);}
a=C_alloc(17);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_i_length(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
t6=C_u_i_car(t5);
if(C_truep(C_i_greater_or_equalp(t4,t6))){
t7=C_i_cadr(((C_word*)t0)[2]);
t8=C_a_i_list2(&a,2,C_SCHEME_TRUE,t7);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9828,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9832,a[2]=t10,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t12=((C_word*)t0)[2];
t13=C_u_i_cdr(t12);
t14=C_u_i_car(t13);
/* optimizer.scm:1315: varnode */
t15=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t15;
av2[1]=t11;
av2[2]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(3,av2);}}
else{
t7=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* map-loop2706 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_12481(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_12481,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12506,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1666: g2712 */
t5=((C_word*)t0)[4];
f_11787(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5484 in k5446 in k5440 in k5434 in loop in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5486(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_5486,2,av);}
a=C_alloc(12);
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5468,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[5];
t6=C_u_i_car(t5);
/* optimizer.scm:416: walk */
t7=((C_word*)((C_word*)t0)[8])[1];
f_4350(t7,t4,t6,((C_word*)t0)[9],((C_word*)t0)[10]);}

/* k13172 in k13178 in loop2 in k12987 in k13202 in k13208 in loop1 in a12874 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13174(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_13174,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_13047(t2,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=C_i_car(((C_word*)t0)[4]);
t3=C_slot(t2,C_fix(1));
t4=C_eqp(lf[13],t3);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
t6=C_u_i_car(t5);
t7=C_u_i_car(((C_word*)t0)[4]);
t8=C_slot(t7,C_fix(2));
t9=C_i_car(t8);
t10=((C_word*)t0)[2];
f_13047(t10,C_eqp(t6,t9));}
else{
t5=((C_word*)t0)[2];
f_13047(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_13047(t2,C_SCHEME_FALSE);}}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_optimizer_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_optimizer_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(1297)){
C_save(t1);
C_rereclaim2(1297*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,229);
lf[0]=C_h_intern(&lf[0],34,"\010compilerscan-toplevel-assignments");
lf[1]=C_h_intern(&lf[1],13,"alist-update!");
lf[2]=C_h_intern(&lf[2],8,"for-each");
lf[3]=C_h_intern(&lf[3],13,"\004corevariable");
lf[4]=C_h_intern(&lf[4],6,"remove");
lf[5]=C_h_intern(&lf[5],2,"if");
lf[6]=C_h_intern(&lf[6],3,"let");
lf[7]=C_h_intern(&lf[7],6,"append");
lf[8]=C_h_intern(&lf[8],4,"last");
lf[9]=C_h_intern(&lf[9],7,"butlast");
lf[10]=C_h_intern(&lf[10],6,"lambda");
lf[11]=C_h_intern(&lf[11],11,"\004corelambda");
lf[12]=C_h_intern(&lf[12],9,"\004corecall");
lf[13]=C_h_intern(&lf[13],4,"set!");
lf[14]=C_h_intern(&lf[14],4,"node");
lf[15]=C_h_intern(&lf[15],14,"\004coreundefined");
lf[16]=C_h_intern(&lf[16],19,"\010compilercopy-node!");
lf[17]=C_h_intern(&lf[17],18,"\010compilerdebugging");
lf[18]=C_h_intern(&lf[18],1,"o");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000&dropping redundant toplevel assignment");
lf[20]=C_h_intern(&lf[20],9,"alist-ref");
lf[21]=C_h_intern(&lf[21],9,"\004corecond");
lf[22]=C_h_intern(&lf[22],11,"\004coreswitch");
lf[23]=C_h_intern(&lf[23],8,"\003sysput!");
lf[24]=C_h_intern(&lf[24],21,"\010compileralways-bound");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\014safe globals");
lf[26]=C_h_intern(&lf[26],17,"delete-duplicates");
lf[27]=C_h_intern(&lf[27],3,"eq\077");
lf[28]=C_h_intern(&lf[28],1,"p");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000 scanning toplevel assignments...");
lf[30]=C_h_intern(&lf[30],24,"\010compilersimplifications");
lf[31]=C_h_intern(&lf[31],23,"\010compilersimplified-ops");
lf[32]=C_h_intern(&lf[32],41,"\010compilerperform-high-level-optimizations");
lf[33]=C_h_intern(&lf[33],12,"\010compilerget");
lf[34]=C_h_intern(&lf[34],5,"quote");
lf[35]=C_h_intern(&lf[35],3,"map");
lf[36]=C_h_intern(&lf[36],19,"\010compilermatch-node");
lf[37]=C_h_intern(&lf[37],3,"any");
lf[38]=C_h_intern(&lf[38],18,"\003syshash-table-ref");
lf[39]=C_h_intern(&lf[39],30,"\010compilerbroken-constant-nodes");
lf[40]=C_h_intern(&lf[40],14,"\010compilerqnode");
lf[41]=C_h_intern(&lf[41],11,"lset-adjoin");
lf[42]=C_h_intern(&lf[42],27,"\010compilerconstant-form-eval");
lf[43]=C_h_intern(&lf[43],5,"every");
lf[44]=C_h_intern(&lf[44],9,"foldable\077");
lf[45]=C_h_intern(&lf[45],7,"\003sysget");
lf[46]=C_h_intern(&lf[46],18,"\010compilerintrinsic");
lf[47]=C_h_intern(&lf[47],13,"\010compilerput!");
lf[48]=C_h_intern(&lf[48],10,"replacable");
lf[49]=C_h_intern(&lf[49],5,"value");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\035substituted constant variable");
lf[51]=C_h_intern(&lf[51],16,"\010compilervarnode");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\032propagated global variable");
lf[53]=C_h_intern(&lf[53],2,"no");
lf[54]=C_h_intern(&lf[54],15,"\010compilerinline");
lf[55]=C_h_intern(&lf[55],11,"collapsable");
lf[56]=C_h_intern(&lf[56],6,"global");
lf[57]=C_h_intern(&lf[57],9,"replacing");
lf[58]=C_h_intern(&lf[58],12,"contractable");
lf[59]=C_h_intern(&lf[59],9,"removable");
lf[60]=C_h_intern(&lf[60],6,"unused");
lf[61]=C_h_intern(&lf[61],9,"partition");
lf[62]=C_h_intern(&lf[62],26,"\010compilerbuild-lambda-list");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[64]=C_h_intern(&lf[64],13,"explicit-rest");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000 removed unused formal parameters");
lf[66]=C_h_intern(&lf[66],30,"\010compilerdecompose-lambda-list");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[68]=C_h_intern(&lf[68],21,"has-unused-parameters");
lf[69]=C_h_intern(&lf[69],18,"\004coredirect_lambda");
lf[70]=C_h_intern(&lf[70],13,"inline-target");
lf[71]=C_h_intern(&lf[71],31,"\010compilerinline-lambda-bindings");
lf[72]=C_h_intern(&lf[72],4,"void");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\024contracted procedure");
lf[74]=C_h_intern(&lf[74],24,"\010compilercheck-signature");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\0001removed call to pure procedure with unused result");
lf[76]=C_h_intern(&lf[76],1,"i");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\0008not inlining procedure because it refers to contractable");
lf[78]=C_h_intern(&lf[78],7,"call/cc");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\022inlining procedure");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\017global inlining");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\010inlining");
lf[82]=C_h_intern(&lf[82],14,"append-reverse");
lf[83]=C_h_intern(&lf[83],6,"gensym");
lf[84]=C_h_intern(&lf[84],1,"t");
lf[85]=C_h_intern(&lf[85],37,"\010compilerexpression-has-side-effects\077");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000+removed unused parameter to known procedure");
lf[87]=C_h_intern(&lf[87],8,"split-at");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[89]=C_h_intern(&lf[89],20,"\004coreinline_allocate");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\042consed rest parameter at call site");
lf[91]=C_h_intern(&lf[91],21,"\010compilerllist-length");
lf[92]=C_h_intern(&lf[92],23,"\010compilerinline-locally");
lf[93]=C_h_intern(&lf[93],24,"\010compilerinline-max-size");
lf[94]=C_h_intern(&lf[94],9,"inlinable");
lf[95]=C_h_intern(&lf[95],22,"\010compilerinline-global");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000 inlining call to intrinsic alias");
lf[97]=C_h_intern(&lf[97],8,"assigned");
lf[98]=C_h_intern(&lf[98],10,"references");
lf[99]=C_h_intern(&lf[99],7,"unknown");
lf[100]=C_h_intern(&lf[100],13,"\010compilerpure");
lf[101]=C_h_intern(&lf[101],11,"local-value");
lf[102]=C_h_intern(&lf[102],18,"\010compilercall-info");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\034removing global contractable");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\0006removed side-effect free assignment to unused variable");
lf[105]=C_h_intern(&lf[105],16,"inline-transient");
lf[106]=C_h_intern(&lf[106],26,"\010compilervariable-visible\077");
lf[107]=C_h_intern(&lf[107],7,"reverse");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\031removed conditional forms");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\025removed binding forms");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\022replaced variables");
lf[111]=C_h_intern(&lf[111],5,"print");
lf[112]=C_h_intern(&lf[112],7,"newline");
lf[113]=C_h_intern(&lf[113],6,"print\052");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\004    ");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\027  call simplifications:");
lf[116]=C_h_intern(&lf[116],30,"\010compilerwith-debugging-output");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\017simplifications");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\022traversal phase...");
lf[119]=C_h_intern(&lf[119],34,"\010compilerperform-pre-optimization!");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\023Removed `not\047 forms");
lf[121]=C_h_intern(&lf[121],24,"node-subexpressions-set!");
lf[122]=C_h_intern(&lf[122],20,"node-parameters-set!");
lf[123]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[124]=C_h_intern(&lf[124],17,"\010compilerget-list");
lf[125]=C_h_intern(&lf[125],3,"not");
lf[126]=C_h_intern(&lf[126],10,"call-sites");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\031pre-optimization phase...");
lf[128]=C_h_intern(&lf[128],24,"register-simplifications");
lf[129]=C_h_intern(&lf[129],19,"\003syshash-table-set!");
lf[130]=C_h_intern(&lf[130],38,"\010compilerreorganize-recursive-bindings");
lf[131]=C_h_intern(&lf[131],28,"\010compilerscan-used-variables");
lf[132]=C_h_intern(&lf[132],6,"filter");
lf[133]=C_h_intern(&lf[133],6,"lset<=");
lf[134]=C_h_intern(&lf[134],10,"filter-map");
lf[135]=C_h_intern(&lf[135],10,"append-map");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000!converted assignments to bindings");
lf[137]=C_h_intern(&lf[137],10,"fold-right");
lf[138]=C_h_intern(&lf[138],4,"fold");
lf[139]=C_h_intern(&lf[139],16,"topological-sort");
lf[140]=C_h_intern(&lf[140],27,"\010compilersubstitution-table");
lf[141]=C_h_intern(&lf[141],16,"\010compilerrewrite");
lf[142]=C_h_intern(&lf[142],28,"\010compilersimplify-named-call");
lf[143]=C_h_intern(&lf[143],37,"\010compilerinline-substitutions-enabled");
lf[144]=C_h_intern(&lf[144],11,"\004coreinline");
lf[145]=C_h_intern(&lf[145],6,"unsafe");
lf[146]=C_h_intern(&lf[146],11,"number-type");
lf[147]=C_h_intern(&lf[147],6,"fixnum");
lf[148]=C_h_intern(&lf[148],21,"\010compilerfold-boolean");
lf[149]=C_h_intern(&lf[149],6,"flonum");
lf[150]=C_h_intern(&lf[150],7,"generic");
lf[151]=C_h_intern(&lf[151],5,"cons\052");
lf[152]=C_h_intern(&lf[152],9,"\004coreproc");
lf[153]=C_h_intern(&lf[153],4,"conc");
lf[154]=C_h_intern(&lf[154],5,"fifth");
lf[155]=C_h_intern(&lf[155],19,"\010compilerfold-inner");
lf[156]=C_h_intern(&lf[156],13,"\010compilerbomb");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\023bad type (optimize)");
lf[158]=C_h_intern(&lf[158],34,"\010compilertransform-direct-lambdas!");
lf[159]=C_h_intern(&lf[159],24,"\010compilercallback-lambda");
lf[160]=C_h_intern(&lf[160],5,"boxed");
lf[161]=C_h_intern(&lf[161],15,"\004coreinline_ref");
lf[162]=C_h_intern(&lf[162],37,"\010compilerestimate-foreign-result-size");
lf[163]=C_h_intern(&lf[163],19,"\004coreinline_loc_ref");
lf[164]=C_h_intern(&lf[164],16,"\004coredirect_call");
lf[165]=C_h_intern(&lf[165],5,"lset=");
lf[166]=C_h_intern(&lf[166],6,"delete");
lf[167]=C_h_intern(&lf[167],13,"\010compilerquit");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000;known procedure called with wrong number of arguments: `~A\047");
lf[169]=C_h_intern(&lf[169],15,"lset-difference");
lf[170]=C_h_intern(&lf[170],15,"node-class-set!");
lf[171]=C_h_intern(&lf[171],12,"\004corerecurse");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[173]=C_h_intern(&lf[173],4,"take");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\014missing kvar");
lf[176]=C_h_intern(&lf[176],11,"\004corereturn");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\017bad call (leaf)");
lf[178]=C_h_intern(&lf[178],6,"cdaddr");
lf[179]=C_h_intern(&lf[179],6,"caaddr");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid parameter list");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\0006direct leaf routine with hoistable closures/allocation");
lf[182]=C_h_intern(&lf[182],6,"unzip1");
lf[183]=C_h_intern(&lf[183],16,"\003sysmake-promise");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\036direct leaf routine/allocation");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000(direct leaf routine optimization pass...");
lf[186]=C_h_intern(&lf[186],36,"\010compilerdetermine-loop-and-dispatch");
lf[187]=C_h_intern(&lf[187],16,"\003sysdynamic-wind");
lf[188]=C_h_intern(&lf[188],13,"list-tabulate");
lf[189]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[190]=C_h_intern(&lf[190],2,"f_");
lf[191]=C_h_intern(&lf[191],1,"x");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\012clustering");
lf[193]=C_h_intern(&lf[193],1,"a");
lf[194]=C_h_intern(&lf[194],3,"max");
lf[195]=C_h_intern(&lf[195],1,"k");
lf[196]=C_h_intern(&lf[196],8,"dispatch");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\027collecting clusters ...");
lf[198]=C_h_intern(&lf[198],11,"make-vector");
lf[199]=C_h_intern(&lf[199],3,"var");
lf[200]=C_h_intern(&lf[200],2,"d2");
lf[201]=C_h_intern(&lf[201],1,"y");
lf[202]=C_h_intern(&lf[202],2,"d3");
lf[203]=C_h_intern(&lf[203],1,"z");
lf[204]=C_h_intern(&lf[204],2,"d1");
lf[205]=C_h_intern(&lf[205],2,"op");
lf[206]=C_h_intern(&lf[206],5,"clist");
lf[207]=C_h_intern(&lf[207],34,"\010compilermembership-test-operators");
lf[208]=C_h_intern(&lf[208],32,"\010compilermembership-unfold-limit");
lf[209]=C_h_intern(&lf[209],4,"var1");
lf[210]=C_h_intern(&lf[210],4,"var0");
lf[211]=C_h_intern(&lf[211],6,"const1");
lf[212]=C_h_intern(&lf[212],4,"var2");
lf[213]=C_h_intern(&lf[213],6,"const2");
lf[214]=C_h_intern(&lf[214],5,"body2");
lf[215]=C_h_intern(&lf[215],4,"rest");
lf[216]=C_h_intern(&lf[216],5,"body1");
lf[217]=C_h_intern(&lf[217],27,"\010compilereq-inline-operator");
lf[218]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\002\376\377\016");
lf[219]=C_h_intern(&lf[219],19,"\010compilerimmediate\077");
lf[220]=C_h_intern(&lf[220],5,"const");
lf[221]=C_h_intern(&lf[221],1,"n");
lf[222]=C_h_intern(&lf[222],7,"clauses");
lf[223]=C_h_intern(&lf[223],1,"d");
lf[224]=C_h_intern(&lf[224],4,"body");
lf[225]=C_h_intern(&lf[225],4,"more");
lf[226]=C_h_intern(&lf[226],4,"args");
lf[227]=C_h_intern(&lf[227],1,"b");
lf[228]=C_h_intern(&lf[228],1,"c");
C_register_lf2(lf,229,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3742,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* k11558 in k11541 in k11527 in walk in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11560(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_11560,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
/* optimizer.scm:1638: walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_11483(t3,((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* k5005 in k5025 in k4985 in a4979 in k4973 in k4874 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5007(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,1))){C_save_and_reclaim((void *)f_5007,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[11],((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4736 in k4719 in k4716 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_4738(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(22,0,3))){
C_save_and_reclaim_args((void *)trf_4738,2,t0,t1);}
a=C_alloc(22);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4760,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_4760(t12,t8,((C_word*)t0)[6]);}

/* k5151 in for-each-loop502 in k5105 in k5102 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5153(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5153,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5143(t3,((C_word*)t0)[4],t2);}

/* k5470 in k5466 in k5484 in k5446 in k5440 in k5434 in loop in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 in ... */
static void C_ccall f_5472(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_5472,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[6],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a12421 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12422(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_12422,2,av);}
/* optimizer.scm:1688: gensym */
t2=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[193];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3860 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_fcall f_3862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_3862,2,t0,t1);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3868,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:72: remove */
t4=*((C_word*)lf[4]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=((C_word*)((C_word*)t0)[2])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k10111 in k10058 in k10052 in k10046 in k10128 in walk in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10113(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,6))){C_save_and_reclaim((void *)f_10113,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_10018(2,av2);}}
else{
t2=C_i_length(((C_word*)t0)[3]);
t3=C_i_length(((C_word*)t0)[4]);
t4=C_eqp(t2,t3);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[5]);
t6=C_i_car(((C_word*)t0)[6]);
t7=C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* optimizer.scm:1366: scan */
t8=((C_word*)((C_word*)t0)[8])[1];
f_10213(t8,((C_word*)t0)[2],t5,t6,((C_word*)t0)[7],((C_word*)t0)[9],t7);}
else{
t5=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_10018(2,av2);}}}}

/* k3864 in k3860 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_3866(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3866,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a3867 in k3860 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_3868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3868,3,av);}
t3=C_i_car(t2);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_eqp(t3,((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4719 in k4716 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_4721(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(13,0,4))){
C_save_and_reclaim_args((void *)trf_4721,2,t0,t1);}
a=C_alloc(13);
if(C_truep(t1)){
t2=f_4175(((C_word*)((C_word*)t0)[2])[1]);
t3=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm:256: walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_4350(t6,((C_word*)t0)[6],t5,((C_word*)t0)[7],((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4738,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4795,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(((C_word*)t0)[4]);
t5=C_slot(t4,C_fix(1));
t6=C_eqp(lf[3],t5);
if(C_truep(t6)){
t7=C_u_i_car(((C_word*)t0)[4]);
t8=C_slot(t7,C_fix(2));
t9=C_i_car(t8);
/* optimizer.scm:259: test */
t10=((C_word*)((C_word*)t0)[11])[1];
f_4139(t10,t3,t9,lf[56]);}
else{
t7=t3;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
f_4795(2,av2);}}}}

/* rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11004(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_11004,3,av);}
a=C_alloc(14);
t3=t2;
t4=C_slot(t3,C_fix(2));
t5=t2;
t6=C_slot(t5,C_fix(3));
t7=t6;
t8=t2;
t9=C_slot(t8,C_fix(1));
t10=C_eqp(t9,lf[12]);
if(C_truep(t10)){
t11=C_i_car(t7);
t12=C_i_cadr(t7);
t13=C_slot(t11,C_fix(2));
t14=C_slot(t12,C_fix(2));
t15=C_slot(t11,C_fix(1));
t16=C_eqp(lf[3],t15);
if(C_truep(t16)){
t17=C_i_car(t13);
t18=C_eqp(((C_word*)t0)[2],t17);
if(C_truep(t18)){
t19=C_a_i_cons(&a,2,C_a_i_cons(&a,2,C_SCHEME_FALSE,t2),((C_word*)((C_word*)t0)[3])[1]);
t20=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t19);
t21=C_i_car(t14);
t22=C_eqp(((C_word*)t0)[4],t21);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11082,a[2]=t7,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t24=C_u_i_cdr(t7);
t25=C_i_length(t24);
t26=C_eqp(((C_word*)t0)[6],t25);
if(C_truep(t26)){
t27=t23;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t27;
av2[1]=C_SCHEME_UNDEFINED;
f_11082(2,av2);}}
else{
/* optimizer.scm:1489: quit */
t27=*((C_word*)lf[167]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t27;
av2[1]=t23;
av2[2]=lf[172];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t27+1)))(4,av2);}}}
else{
t23=C_u_i_car(t14);
t24=C_i_assq(t23,((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11119,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:1487: g2380 */
t26=t25;
f_11119(t26,t1,t24);}
else{
/* optimizer.scm:1509: bomb */
t25=*((C_word*)lf[156]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t25;
av2[1]=t1;
av2[2]=lf[175];
av2[3]=t14;
((C_proc)(void*)(*((C_word*)t25+1)))(4,av2);}}}}
else{
t19=C_u_i_car(t13);
t20=C_eqp(((C_word*)t0)[4],t19);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11224,a[2]=t7,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1511: node-class-set! */
t22=*((C_word*)lf[170]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t22;
av2[1]=t21;
av2[2]=t2;
av2[3]=lf[176];
((C_proc)(void*)(*((C_word*)t22+1)))(4,av2);}}
else{
/* optimizer.scm:1514: bomb */
t21=*((C_word*)lf[156]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t21;
av2[1]=t1;
av2[2]=lf[177];
((C_proc)(void*)(*((C_word*)t21+1)))(3,av2);}}}}
else{
t17=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t17;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t17+1)))(2,av2);}}}
else{
t11=C_eqp(t9,lf[6]);
if(C_truep(t11)){
t12=C_i_car(t4);
t13=C_i_car(t7);
if(C_truep(C_i_memq(t12,((C_word*)t0)[9]))){
t14=C_a_i_cons(&a,2,C_a_i_cons(&a,2,t12,t13),((C_word*)((C_word*)t0)[7])[1]);
t15=C_mutate2(((C_word *)((C_word*)t0)[7])+1,t14);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11275,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t17=C_i_cadr(t7);
/* optimizer.scm:1520: copy-node! */
t18=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t18;
av2[1]=t16;
av2[2]=t17;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t18+1)))(4,av2);}}
else{
t14=((C_word*)((C_word*)t0)[8])[1];
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11287,a[2]=t16,a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t18=((C_word*)t16)[1];
f_11287(t18,t1,t7);}}
else{
t12=((C_word*)((C_word*)t0)[8])[1];
t13=C_i_check_list_2(t7,lf[2]);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11316,a[2]=t15,a[3]=t12,tmp=(C_word)a,a+=4,tmp));
t17=((C_word*)t15)[1];
f_11316(t17,t1,t7);}}}

/* k12414 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12416(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_12416,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* optimizer.scm:1687: append */
t3=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5540 in k5537 in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5542(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,8))){C_save_and_reclaim((void *)f_5542,2,av);}
a=C_alloc(12);
t2=t1;
t3=C_i_length(((C_word*)t0)[2]);
if(C_truep(C_i_lessp(t3,t2))){
/* optimizer.scm:427: walk-generic */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6345(t4,((C_word*)t0)[4],t2,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9],C_SCHEME_TRUE);}
else{
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5554,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[4],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:429: debugging */
t5=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[18];
av2[3]=lf[90];
av2[4]=((C_word*)t0)[14];
av2[5]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}}

/* g403 in k4736 in k4719 in k4716 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_4751(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_4751,3,t0,t1,t2);}
/* optimizer.scm:264: g420 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4350(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k5025 in k4985 in a4979 in k4973 in k4874 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5027(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,4))){C_save_and_reclaim((void *)f_5027,2,av);}
a=C_alloc(19);
t2=C_i_cadddr(((C_word*)t0)[2]);
t3=C_a_i_list4(&a,4,((C_word*)t0)[3],((C_word*)t0)[4],t1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5007,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_car(((C_word*)t0)[6]);
t7=C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[8]);
/* optimizer.scm:298: walk */
t8=((C_word*)((C_word*)t0)[9])[1];
f_4350(t8,t5,t6,t7,C_SCHEME_END_OF_LIST);}

/* k4756 in k4736 in k4719 in k4716 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_4758,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[6],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k13178 in loop2 in k12987 in k13202 in k13208 in loop1 in a12874 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13180(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_13180,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_13047(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_u_i_car(((C_word*)t0)[5]);
/* optimizer.scm:721: get */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=t3;
av2[4]=lf[98];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* k8209 in k8206 in k8174 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_8211(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(18,0,3))){
C_save_and_reclaim_args((void *)trf_8211,2,t0,t1);}
a=C_alloc(18);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=((C_word*)t0)[2];
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8222,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8341,a[2]=t4,a[3]=t9,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_8341(t11,t7,t6);}
else{
t2=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11589 in k11527 in walk in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_11591(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,1))){
C_save_and_reclaim_args((void *)trf_11591,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_memq(((C_word*)t0)[2],((C_word*)t0)[3]))){
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=C_eqp(lf[11],t2);
if(C_truep(t3)){
t4=C_slot(((C_word*)t0)[4],C_fix(2));
t5=C_i_caddr(t4);
t6=((C_word*)t0)[5];
f_11543(t6,C_i_listp(t5));}
else{
t4=((C_word*)t0)[5];
f_11543(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_11543(t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
f_11543(t2,C_SCHEME_FALSE);}}

/* k6610 in k6590 in k6584 in k6581 in g972 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6612(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,4))){
C_save_and_reclaim_args((void *)trf_6612,2,t0,t1);}
a=C_alloc(10);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:576: get-list */
t5=*((C_word*)lf[124]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[10];
av2[3]=t3;
av2[4]=lf[98];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k5537 in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_5539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,8))){
C_save_and_reclaim_args((void *)trf_5539,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm:425: llist-length */
t3=*((C_word*)lf[91]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[15];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
/* optimizer.scm:448: walk-generic */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6345(t2,((C_word*)t0)[4],((C_word*)t0)[16],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9],C_SCHEME_TRUE);}}

/* k6622 in k6616 in k6610 in k6590 in k6584 in k6581 in g972 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_6624,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(3));
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6633,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=C_slot(t3,C_fix(1));
t6=C_eqp(lf[3],t5);
if(C_truep(t6)){
t7=C_slot(t3,C_fix(2));
t8=C_i_car(t7);
t9=t4;
f_6633(t9,C_eqp(((C_word*)t0)[9],t8));}
else{
t7=t4;
f_6633(t7,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10389 in k10383 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_10391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_10391,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1415: every */
t3=*((C_word*)lf[43]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=t2;
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k3877 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_fcall f_3879(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,1))){
C_save_and_reclaim_args((void *)trf_3879,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];
f_3862(t4,t3);}
else{
t2=((C_word*)t0)[4];
f_3862(t2,C_SCHEME_UNDEFINED);}}

/* k6659 in k6641 in k6638 in k6631 in k6622 in k6616 in k6610 in k6590 in k6584 in k6581 in g972 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6661(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_6661,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* optimizer.scm:590: node-subexpressions-set! */
t3=*((C_word*)lf[121]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6616 in k6610 in k6590 in k6584 in k6581 in g972 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6618(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_6618,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=C_i_length(t1);
t4=C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=C_slot(((C_word*)t0)[2],C_fix(1));
t6=t2;
f_6624(t6,C_eqp(lf[5],t5));}
else{
t5=t2;
f_6624(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6624(t3,C_SCHEME_FALSE);}}

/* k8220 in k8209 in k8206 in k8174 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,3))){C_save_and_reclaim((void *)f_8222,2,av);}
a=C_alloc(20);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=*((C_word*)lf[51]+1);
t8=C_i_check_list_2(t2,lf[35]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8307,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_8307(t13,t9,t2);}

/* k5579 in k5594 in k5632 in a5564 in k5552 in k5540 in k5537 in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 in ... */
static void C_ccall f_5581(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5581,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* g742 in a5564 in k5552 in k5540 in k5537 in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_5586(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_5586,3,t0,t1,t2);}
/* optimizer.scm:434: g759 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4350(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k8206 in k8174 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_8208(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8208,2,t0,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_8211(t3,t1);}
else{
t3=C_eqp(*((C_word*)lf[146]+1),lf[147]);
t4=(C_truep(t3)?C_i_caddr(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_8211(t5,t4);}
else{
t5=C_eqp(*((C_word*)lf[146]+1),lf[149]);
t6=t2;
f_8211(t6,(C_truep(t5)?C_i_cadddr(((C_word*)t0)[3]):C_SCHEME_FALSE));}}}

/* k5910 in k5916 in k5879 in k5858 in k5843 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5912(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5912,2,av);}
t2=((C_word*)t0)[2];
f_5884(t2,C_i_not(t1));}

/* k5916 in k5879 in k5858 in k5843 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5918(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_5918,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_5884(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5912,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_u_i_car(((C_word*)t0)[3]);
/* optimizer.scm:341: test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4139(t4,t2,t3,lf[97]);}}

/* k5119 in k5105 in k5102 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5121(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,7))){C_save_and_reclaim((void *)f_5121,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[6],C_fix(3));
t4=C_i_car(t3);
/* optimizer.scm:328: inline-lambda-bindings */
t5=*((C_word*)lf[71]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=((C_word*)t0)[8];
av2[4]=t4;
av2[5]=C_SCHEME_FALSE;
av2[6]=((C_word*)t0)[9];
av2[7]=*((C_word*)lf[72]+1);
((C_proc)(void*)(*((C_word*)t5+1)))(8,av2);}}

/* k5126 in k5119 in k5105 in k5102 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5128(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5128,2,av);}
/* optimizer.scm:327: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4350(t2,((C_word*)t0)[3],t1,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k8200 in k8174 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_8202,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* g810 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6069(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_6069,3,t0,t1,t2);}
/* optimizer.scm:466: g827 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4350(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* a8235 in k8229 in k8220 in k8209 in k8206 in k8174 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8236(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,1))){C_save_and_reclaim((void *)f_8236,5,av);}
a=C_alloc(14);
t5=C_a_i_list1(&a,1,t3);
t6=C_a_i_list2(&a,2,t2,t4);
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[6],t5,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k6058 in k6074 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6060(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6060,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a5564 in k5552 in k5540 in k5537 in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5565(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(43,c,3))){C_save_and_reclaim((void *)f_5565,4,av);}
a=C_alloc(43);
t4=t2;
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5634,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],a[8]=t7,a[9]=t9,a[10]=t8,tmp=(C_word)a,a+=11,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5642,a[2]=t10,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* optimizer.scm:440: qnode */
t12=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t12;
av2[1]=t11;
av2[2]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
t12=C_i_length(t3);
t13=C_a_i_times(&a,2,C_fix(3),t12);
t14=C_a_i_list2(&a,2,lf[88],t13);
t15=C_a_i_record4(&a,4,lf[14],lf[89],t14,t3);
t16=C_a_i_list1(&a,1,t15);
/* optimizer.scm:436: append */
t17=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t17;
av2[1]=t10;
av2[2]=t4;
av2[3]=t16;
((C_proc)(void*)(*((C_word*)t17+1)))(4,av2);}}}

/* k8229 in k8220 in k8209 in k8206 in k8174 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8231(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,5))){C_save_and_reclaim((void *)f_8231,2,av);}
a=C_alloc(19);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8236,tmp=(C_word)a,a+=2,tmp);
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=C_eqp(*((C_word*)lf[146]+1),lf[147]);
t6=(C_truep(t5)?C_i_car(((C_word*)t0)[2]):C_i_cadr(((C_word*)t0)[2]));
t7=C_a_i_list1(&a,1,t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8277,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8279,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1056: fold-boolean */
t11=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t11;
av2[1]=t9;
av2[2]=t10;
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}

/* k5552 in k5540 in k5537 in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5554(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,4))){C_save_and_reclaim((void *)f_5554,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5565,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:430: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[11];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* k5102 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5104(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_5104,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:324: debugging */
t3=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[18];
av2[3]=lf[73];
av2[4]=((C_word*)t0)[11];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* a5558 in k5552 in k5540 in k5537 in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5559(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5559,2,av);}
/* optimizer.scm:430: split-at */
t2=*((C_word*)lf[87]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5105 in k5102 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5107(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,3))){C_save_and_reclaim((void *)f_5107,2,av);}
a=C_alloc(19);
t2=f_4175(((C_word*)((C_word*)t0)[2])[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5111,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[4];
t5=C_i_check_list_2(t4,lf[2]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5121,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5143,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_5143(t10,t6,t4);}

/* k9830 in k9801 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9832(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_9832,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9836,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9838,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9844,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1317: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t3;
av2[2]=t4;
av2[3]=t5;
C_call_with_values(4,av2);}}

/* k5417 in map-loop671 in k5428 in loop in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5419(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5419,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5394(t6,((C_word*)t0)[5],t5);}

/* k9834 in k9830 in k9801 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9836,2,av);}
/* optimizer.scm:1314: cons* */
t2=*((C_word*)lf[151]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a9843 in k9830 in k9801 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9844(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_9844,4,av);}
a=C_alloc(9);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9852,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cddr(((C_word*)t0)[2]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9858,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=((C_word*)t8)[1];
f_9858(t10,t5,t3,t6);}

/* a9837 in k9830 in k9801 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9838(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_9838,2,av);}
/* optimizer.scm:1317: split-at */
t2=*((C_word*)lf[87]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5950 in k5843 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5952(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5952,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_5860(2,av2);}}
else{
/* optimizer.scm:336: test */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4139(t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[49]);}}

/* k9554 in k9528 in k9525 in k9519 in k9513 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9556(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_9556,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4660 in g354 in k4601 in k4595 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_4662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,5))){
C_save_and_reclaim_args((void *)trf_4662,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:244: debugging */
t3=*((C_word*)lf[17]+1);{
C_word av2[6];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[18];
av2[3]=lf[52];
av2[4]=((C_word*)t0)[4];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}
else{
/* optimizer.scm:246: varnode */
t2=*((C_word*)lf[51]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k10797 in k10794 in k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10799(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_10799,2,av);}
a=C_alloc(11);
t2=(C_truep(((C_word*)t0)[2])?C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=C_a_i_record4(&a,4,lf[14],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10816,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1547: copy-node! */
t6=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4663 in k4660 in g354 in k4601 in k4595 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4665(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4665,2,av);}
/* optimizer.scm:245: varnode */
t2=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k10794 in k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10796(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_10796,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10963,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10963(t6,t2,t1);}

/* k11413 in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11415(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11415,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1568: walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9978(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k11416 in k11413 in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_11418,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k8552 in k8536 in k8526 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8554(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_8554,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* g503 in k5105 in k5102 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_5111(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,5))){
C_save_and_reclaim_args((void *)trf_5111,3,t0,t1,t2);}
t3=*((C_word*)lf[47]+1);
/* optimizer.scm:326: g518 */
t4=*((C_word*)lf[47]+1);{
C_word av2[6];
av2[0]=t4;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
av2[4]=lf[70];
av2[5]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}

/* k8556 in k8536 in k8526 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8558(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8558,2,av);}
/* optimizer.scm:1087: cons* */
t2=*((C_word*)lf[151]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6509 in for-each-loop921 in k6466 in a6463 in k6421 in k6418 in k6414 in k6408 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6511(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6511,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6501(t3,((C_word*)t0)[4],t2);}

/* k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6544(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_6544,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6564,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* tweaks.scm:51: ##sys#get */
t4=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[125];
av2[3]=lf[46];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k6545 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6547(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_6547,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_greaterp(((C_word*)((C_word*)t0)[4])[1],C_fix(0)))){
/* optimizer.scm:596: debugging */
t3=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[18];
av2[3]=lf[120];
av2[4]=((C_word*)((C_word*)t0)[4])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10312 in a10297 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10314(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_10314,2,av);}
/* optimizer.scm:1396: rec */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10216(t2,((C_word*)t0)[3],((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k4685 in g354 in k4601 in k4595 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4687(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4687,2,av);}
t2=C_eqp(lf[53],t1);
t3=((C_word*)t0)[2];
f_4662(t3,C_i_not(t2));}

/* a10297 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10298(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_10298,5,av);}
a=C_alloc(8);
t5=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t7=C_i_car(((C_word*)t0)[4]);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10314,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1396: append */
t10=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=t2;
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}

/* for-each-loop971 in k6814 in k6562 in k6542 in perform-pre-optimization! in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6827(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_6827,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6837,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:559: g972 */
t5=((C_word*)t0)[3];
f_6565(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k11407 in a11391 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11409(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_11409,2,av);}
a=C_alloc(3);
t2=C_a_i_list(&a,1,t1);
/* optimizer.scm:1457: ##sys#make-promise */
t3=*((C_word*)lf[183]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* a10334 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10335(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_10335,3,av);}
/* optimizer.scm:1401: rec */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10216(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k8592 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8594(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_8594,2,av);}
a=C_alloc(15);
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=(C_truep(t2)?t2:*((C_word*)lf[145]+1));
if(C_truep(t3)){
t4=C_i_length(((C_word*)t0)[3]);
t5=C_i_caddr(((C_word*)t0)[2]);
if(C_truep(C_i_less_or_equalp(t4,t5))){
t6=C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t8=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t9=((C_word*)t0)[5];
t10=t9;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],t7,t8);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t7=((C_word*)t0)[2];
t8=C_u_i_car(t7);
t9=C_a_i_list2(&a,2,C_SCHEME_TRUE,t8);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8650,a[2]=((C_word*)t0)[5],a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8654,a[2]=t11,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t13=((C_word*)t0)[2];
t14=C_u_i_car(t13);
/* optimizer.scm:1102: varnode */
t15=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t15;
av2[1]=t12;
av2[2]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(3,av2);}}}
else{
t6=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k10743 in g2452 in k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10745(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,3))){C_save_and_reclaim((void *)f_10745,2,av);}
a=C_alloc(26);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list4(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[4]);
t4=C_u_i_car(((C_word*)t0)[2]);
t5=C_u_i_cdr(((C_word*)t0)[2]);
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,t4,t6);
t8=C_a_i_record4(&a,4,lf[14],lf[164],t3,t7);
t9=C_a_i_list2(&a,2,t2,t8);
/* optimizer.scm:1535: node-subexpressions-set! */
t10=*((C_word*)lf[121]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=((C_word*)t0)[5];
av2[2]=((C_word*)t0)[6];
av2[3]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}

/* k11324 in for-each-loop2430 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11326(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11326,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11316(t3,((C_word*)t0)[4],t2);}

/* for-each-loop921 in k6466 in a6463 in k6421 in k6418 in k6414 in k6408 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6501(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_6501,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6511,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6473,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_i_car(t6);
/* optimizer.scm:531: print* */
t9=*((C_word*)lf[113]+1);{
C_word av2[4];
av2[0]=t9;
av2[1]=t7;
av2[2]=lf[114];
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7564 in k7475 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7566(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_7566,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
f_7480(t3,C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t2));}

/* k5632 in a5564 in k5552 in k5540 in k5537 in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5634(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_5634,2,av);}
a=C_alloc(18);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5596,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5598,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5598(t7,t3,t2);}

/* k5621 in map-loop736 in k5632 in a5564 in k5552 in k5540 in k5537 in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 in ... */
static void C_ccall f_5623(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5623,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5598(t6,((C_word*)t0)[5],t5);}

/* a4230 in k4218 in simplify in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4231(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_4231,3,av);}
a=C_alloc(9);
t3=C_i_cadr(t2);
t4=t3;
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4241,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t4,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t6=t2;
t7=C_u_i_car(t6);
/* optimizer.scm:154: match-node */
t8=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t5;
av2[2]=((C_word*)t0)[6];
av2[3]=t7;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* for-each-loop2430 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_11316(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_11316,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11326,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1524: g2431 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a11703 in a11690 in walk in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11704(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_11704,2,av);}
t2=C_i_car(((C_word*)t0)[2]);
/* optimizer.scm:1646: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11483(t3,t1,t2,((C_word*)t0)[4]);}

/* close in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static C_word C_fcall f_11423(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;{}
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t1=C_i_length(((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(C_fixnum_greaterp(t1,C_fix(1)))){
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]),((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t2);
t4=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
return(t5);}
else{
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t3=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
return(t3);}}
else{
t1=C_SCHEME_UNDEFINED;
return(t1);}}

/* g231 in k4239 in a4230 in k4218 in simplify in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static C_word C_fcall f_4289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_i_assq(t1,((C_word*)t0)[2]);
return(C_i_cdr(t2));}

/* ##compiler#determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11420(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(29,c,4))){C_save_and_reclaim((void *)f_11420,4,av);}
a=C_alloc(29);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11423,a[2]=t9,a[3]=t7,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t15=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11483,a[2]=t7,a[3]=t13,a[4]=t9,a[5]=t11,a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11768,a[2]=t3,a[3]=t5,a[4]=t1,a[5]=t2,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1652: debugging */
t17=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t17;
av2[1]=t16;
av2[2]=lf[28];
av2[3]=lf[197];
((C_proc)(void*)(*((C_word*)t17+1)))(4,av2);}}

/* a10395 in k10389 in k10383 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10396(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_10396,3,av);}
/* optimizer.scm:1415: rec */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10216(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* a11713 in a11690 in walk in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11714(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_11714,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[7])[1]);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k5640 in a5564 in k5552 in k5540 in k5537 in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5642(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_5642,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* optimizer.scm:436: append */
t3=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* g2662 in walk in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_11723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_11723,3,t0,t1,t2);}
/* optimizer.scm:1650: g2677 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11483(t3,t1,t2,((C_word*)t0)[3]);}

/* walk in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_11483(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(!C_demand(C_calculate_demand(16,0,5))){
C_save_and_reclaim_args((void *)trf_11483,4,t0,t1,t2,t3);}
a=C_alloc(16);
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(2));
t9=t2;
t10=C_slot(t9,C_fix(1));
t11=C_eqp(t10,lf[6]);
if(C_truep(t11)){
t12=C_i_car(t8);
t13=t12;
t14=C_i_car(t6);
t15=t14;
t16=C_i_cadr(t6);
t17=t16;
t18=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_11529,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t13,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=t17,a[9]=t15,a[10]=((C_word*)t0)[4],a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[6],tmp=(C_word)a,a+=13,tmp);
t19=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t19)){
t20=t18;
f_11529(t20,C_SCHEME_FALSE);}
else{
t20=C_slot(t15,C_fix(1));
t21=t18;
f_11529(t21,C_eqp(lf[15],t20));}}
else{
t12=C_eqp(t10,lf[11]);
t13=(C_truep(t12)?t12:C_eqp(t10,lf[69]));
if(C_truep(t13)){
t14=C_i_caddr(t8);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11691,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1640: decompose-lambda-list */
t16=*((C_word*)lf[66]+1);{
C_word av2[4];
av2[0]=t16;
av2[1]=t1;
av2[2]=t14;
av2[3]=t15;
((C_proc)(void*)(*((C_word*)t16+1)))(4,av2);}}
else{
t14=f_11423(C_a_i(&a,6),((C_word*)((C_word*)t0)[5])[1]);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11723,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t16=C_i_check_list_2(t6,lf[2]);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11735,a[2]=t18,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t20=((C_word*)t18)[1];
f_11735(t20,t1,t6);}}}

/* for-each-loop2661 in walk in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_11735(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_11735,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11745,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1650: g2662 */
t5=((C_word*)t0)[3];
f_11723(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k13045 in loop2 in k12987 in k13202 in k13208 in loop1 in a12874 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_13047(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,4))){
C_save_and_reclaim_args((void *)trf_13047,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_slot(t2,C_fix(3));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=C_i_cdr(((C_word*)t0)[4]);
t7=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm:725: loop2 */
t8=((C_word*)((C_word*)t0)[5])[1];
f_13016(t8,((C_word*)t0)[6],t5,t6,t7);}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13090,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13100,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:729: ##sys#call-with-values */{
C_word av2[4];
av2[0]=0;
av2[1]=((C_word*)t0)[6];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}
else{
t2=((C_word*)t0)[6];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* k10367 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10369(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_10369,2,av);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t1))){
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]),((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6007 in k5977 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6009(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_6009,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_5090(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(2));
t4=C_i_car(t3);
/* optimizer.scm:319: test */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4139(t5,t2,t4,lf[70]);}}

/* k10383 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10385(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_10385,2,av);}
a=C_alloc(10);
t2=C_i_zerop(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_10391(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[6])[1];
if(C_truep(t4)){
t5=t3;
f_10391(t5,C_SCHEME_FALSE);}
else{
t5=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[7])[1],t1);
t6=C_mutate2(((C_word *)((C_word*)t0)[7])+1,t5);
t7=t3;
f_10391(t7,C_SCHEME_TRUE);}}}

/* k4221 in k4218 in simplify in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4223(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4223,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4218 in simplify in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4220(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_4220,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4231,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:152: any */
t4=*((C_word*)lf[37]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a11391 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11392(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_11392,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11398,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11409,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* tmp13627 */
t4=t2;
f_11398(t4,t3);}

/* k11388 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11390(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_11390,2,av);}
/* optimizer.scm:1457: debugging */
t2=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[18];
av2[3]=lf[181];
av2[4]=((C_word*)t0)[3];
av2[5]=t1;
av2[6]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* k6023 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6025(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6025,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_5083(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:313: test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4139(t3,t2,((C_word*)t0)[4],lf[49]);}}

/* tmp13627 in a11391 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_11398(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_11398,2,t0,t1);}
/* optimizer.scm:1457: unzip1 */
t2=*((C_word*)lf[182]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k12623 in k12587 in a12566 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12625(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,1))){C_save_and_reclaim((void *)f_12625,2,av);}
a=C_alloc(25);
t2=C_a_i_list3(&a,3,t1,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)t0)[4];
t4=C_a_i_record4(&a,4,lf[14],lf[5],t3,t2);
t5=C_a_i_list2(&a,2,((C_word*)t0)[5],t4);
t6=((C_word*)t0)[6];
t7=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[6],((C_word*)t0)[7],t5);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* a12626 in k12587 in a12566 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12627(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_12627,4,av);}
a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12661,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:814: varnode */
t5=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5594 in k5632 in a5564 in k5552 in k5540 in k5537 in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5596(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_5596,2,av);}
a=C_alloc(12);
t2=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[2],t1);
t3=t2;
t4=C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5581,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:446: invalidate-gae! */
f_4179(t6,((C_word*)t0)[6]);}

/* map-loop736 in k5632 in a5564 in k5552 in k5540 in k5537 in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_5598(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_5598,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5623,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:434: g742 */
t5=((C_word*)t0)[4];
f_5586(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* simplify in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_4216(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_4216,3,t0,t1,t2);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4220,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=t2;
t5=C_slot(t4,C_fix(1));
/* optimizer.scm:151: ##sys#hash-table-ref */
t6=*((C_word*)lf[38]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=*((C_word*)lf[30]+1);
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k12536 in for-each-loop2687 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12538(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_12538,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12528(t3,((C_word*)t0)[4],t2);}

/* k5882 in k5879 in k5858 in k5843 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_5884(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_5884,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5891,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5893,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_u_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm:343: any */
t5=*((C_word*)lf[37]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t2;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t2=((C_word*)t0)[2];
f_5170(t2,C_SCHEME_FALSE);}}

/* k5879 in k5858 in k5843 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_5881,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_5884(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5918,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=C_u_i_car(((C_word*)t0)[5]);
/* optimizer.scm:340: test */
t5=((C_word*)((C_word*)t0)[6])[1];
f_4139(t5,t3,t4,lf[98]);}}

/* a9601 in k9528 in k9525 in k9519 in k9513 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9602(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,1))){C_save_and_reclaim((void *)f_9602,4,av);}
a=C_alloc(17);
t4=C_eqp(*((C_word*)lf[146]+1),lf[147]);
if(C_truep(t4)){
t5=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t6=C_a_i_list2(&a,2,t2,t3);
t7=t1;
t8=t7;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[144],t5,t6);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t5=C_a_i_list2(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t6=C_a_i_list2(&a,2,t2,t3);
t7=t1;
t8=t7;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[89],t5,t6);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k9598 in k9528 in k9525 in k9519 in k9513 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9600(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_9600,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6013 in k6023 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6015(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6015,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
f_5083(2,av2);}}
else{
/* optimizer.scm:314: test */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4139(t2,((C_word*)t0)[2],((C_word*)t0)[4],lf[101]);}}

/* k9513 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9515(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_9515,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1256: fifth */
t5=*((C_word*)lf[154]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11602 in k11527 in walk in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_11604(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,4))){
C_save_and_reclaim_args((void *)trf_11604,2,t0,t1);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11612,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1628: get */
t4=*((C_word*)lf[33]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=lf[126];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k11617 in k11527 in walk in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_11619,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_11604(t3,C_i_length(t2));}
else{
t2=((C_word*)t0)[2];
f_11604(t2,C_fix(0));}}

/* k11610 in k11602 in k11527 in walk in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11612(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_11612,2,av);}
if(C_truep(t1)){
t2=t1;
t3=C_i_length(t2);
t4=((C_word*)t0)[2];
f_11591(t4,C_eqp(((C_word*)t0)[3],t3));}
else{
t2=((C_word*)t0)[2];
f_11591(t2,C_eqp(((C_word*)t0)[3],C_fix(0)));}}

/* k12517 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12519(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_12519,2,av);}
t2=C_i_pairp(((C_word*)((C_word*)t0)[2])[1]);
/* optimizer.scm:1773: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
C_values(4,av2);}}

/* k9528 in k9525 in k9519 in k9513 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9530(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,4))){C_save_and_reclaim((void *)f_9530,2,av);}
a=C_alloc(14);
if(C_truep(C_i_nullp(t1))){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1265: qnode */
t5=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=C_u_i_car(t1);
t5=C_a_i_list2(&a,2,((C_word*)t0)[2],t4);
t6=((C_word*)t0)[3];
t7=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],t3,t5);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9602,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1273: fold-inner */
t7=*((C_word*)lf[155]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}}

/* a5892 in k5882 in k5879 in k5858 in k5843 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5893,3,av);}
t3=*((C_word*)lf[85]+1);
/* optimizer.scm:343: g562 */
t4=*((C_word*)lf[85]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5889 in k5882 in k5879 in k5858 in k5843 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5891(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5891,2,av);}
t2=((C_word*)t0)[2];
f_5170(t2,C_i_not(t1));}

/* k6952 in k6960 in k6944 in g1367 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6954(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6954,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6944 in g1367 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6946(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_6946,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6962,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:851: gensym */
t4=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a7042 in a7036 in g1391 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7043(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7043,3,av);}
/* optimizer.scm:862: find-path */
t3=((C_word*)t0)[2];
f_6880(t3,t1,((C_word*)t0)[3],t2);}

/* a13233 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13234(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8=av[8];
C_word t9=av[9];
C_word t10=av[10];
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_13234,11,av);}
a=C_alloc(10);
if(C_truep(C_i_equalp(t4,*((C_word*)lf[217]+1)))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13247,a[2]=t9,a[3]=t1,a[4]=t8,a[5]=t10,a[6]=t6,a[7]=t5,a[8]=t2,a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:671: immediate? */
t12=*((C_word*)lf[219]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t12;
av2[1]=t11;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
t11=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}

/* a7036 in g1391 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_7037,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7043,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:862: filter */
t4=*((C_word*)lf[132]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3743 in k3740 */
static void C_ccall f_3745(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3745,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3748,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_chicken_2dsyntax_toplevel(2,av2);}}

/* k3740 */
static void C_ccall f_3742(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3742,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3745,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k5858 in k5843 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_5860,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=C_slot(t1,C_fix(1));
t3=C_eqp(lf[11],t2);
if(C_truep(t3)){
t4=C_slot(t1,C_fix(2));
t5=C_i_caddr(t4);
t6=t5;
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t8=C_i_car(t6);
/* optimizer.scm:339: test */
t9=((C_word*)((C_word*)t0)[5])[1];
f_4139(t9,t7,t8,lf[60]);}
else{
t7=((C_word*)t0)[2];
f_5170(t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
f_5170(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_5170(t2,C_SCHEME_FALSE);}}

/* k3746 in k3743 in k3740 */
static void C_ccall f_3748(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_3748,2,av);}
a=C_alloc(5);
t2=C_mutate2((C_word*)lf[0]+1 /* (set! ##compiler#scan-toplevel-assignments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3750,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4133,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:131: make-vector */
t4=*((C_word*)lf[198]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_fix(301);
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k7059 in k7056 in k7053 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7061(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_7061,2,av);}
a=C_alloc(4);
t2=t1;
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7070,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:905: debugging */
t4=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[18];
av2[3]=lf[136];
av2[4]=((C_word*)((C_word*)t0)[2])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
/* optimizer.scm:907: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}}

/* k6074 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_6076,2,av);}
a=C_alloc(9);
t2=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6060,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:467: invalidate-gae! */
f_4179(t4,((C_word*)t0)[5]);}

/* map-loop804 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6078(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_6078,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6103,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:466: g810 */
t5=((C_word*)t0)[4];
f_6069(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k12504 in map-loop2706 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12506(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_12506,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_12481(t6,((C_word*)t0)[5],t5);}

/* k13381 in k13375 in a13363 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13383(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_13383,2,av);}
a=C_alloc(11);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:646: get-list */
t3=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[9];
av2[3]=((C_word*)t0)[11];
av2[4]=lf[98];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k7056 in k7053 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_7058,2,av);}
a=C_alloc(12);
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7061,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7078,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:879: fold */
t6=*((C_word*)lf[138]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=((C_word*)t0)[6];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k7053 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7055(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_7055,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:874: topological-sort */
t3=*((C_word*)lf[139]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[7])[1];
av2[3]=*((C_word*)lf[27]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a6909 in find in find-path in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6910(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6910,3,av);}
/* optimizer.scm:835: find */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6886(t3,t1,t2,((C_word*)t0)[3]);}

/* k13245 in a13233 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_13247,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:672: get-list */
t3=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)t0)[9];
av2[4]=lf[98];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a12566 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12567(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8=av[8];
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_12567,9,av);}
a=C_alloc(9);
t9=C_i_assoc(t4,*((C_word*)lf[207]+1));
t10=t9;
if(C_truep(t10)){
if(C_truep(C_i_listp(t6))){
t11=C_i_length(t6);
if(C_truep(C_i_lessp(t11,*((C_word*)lf[208]+1)))){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12589,a[2]=t10,a[3]=t7,a[4]=t8,a[5]=t3,a[6]=t5,a[7]=t1,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:800: gensym */
t13=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=t12;
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}}
else{
t11=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}
else{
t11=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}

/* k13375 in a13363 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13377(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_13377,2,av);}
a=C_alloc(12);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:645: immediate? */
t3=*((C_word*)lf[219]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a10585 in rec in scan in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_10586,3,av);}
/* optimizer.scm:1443: rec */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10216(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k4008 in k4005 in k3987 in k3984 in k3904 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_4010(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4010,2,av);}
a=C_alloc(5);
t2=C_a_i_record4(&a,4,lf[14],lf[15],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
/* optimizer.scm:100: copy-node! */
t3=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* mark in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_fcall f_3753(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_3753,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3760,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_3760(t5,C_SCHEME_FALSE);}
else{
t5=C_i_memq(t2,((C_word*)((C_word*)t0)[4])[1]);
t6=t3;
f_3760(t6,C_i_not(t5));}}

/* ##compiler#scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_3750(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
if(!C_demand(C_calculate_demand(48,c,4))){C_save_and_reclaim((void *)f_3750,3,av);}
a=C_alloc(48);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3753,a[2]=t4,a[3]=t8,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t22=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3776,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t23=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3783,a[2]=t8,a[3]=t10,tmp=(C_word)a,a+=4,tmp));
t24=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3788,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3825,a[2]=t10,a[3]=t6,a[4]=t16,a[5]=t20,a[6]=t18,a[7]=t14,a[8]=t12,tmp=(C_word)a,a+=9,tmp));
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4065,a[2]=t4,a[3]=t1,a[4]=t20,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:108: debugging */
t27=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t27;
av2[1]=t26;
av2[2]=lf[28];
av2[3]=lf[29];
((C_proc)(void*)(*((C_word*)t27+1)))(4,av2);}}

/* a7077 in k7056 in k7053 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7078(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_7078,4,av);}
a=C_alloc(8);
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_i_cdr(t4);
t6=t5;
t7=C_i_car(t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7091,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t10=C_u_i_cdr(t6);
if(C_truep(C_i_nullp(t10))){
t11=C_i_assq(t8,((C_word*)((C_word*)t0)[5])[1]);
t12=C_i_cdr(t11);
t13=C_i_memq(t8,t12);
t14=t9;
f_7091(t14,C_i_not(t13));}
else{
t11=t9;
f_7091(t11,C_SCHEME_FALSE);}}

/* k4005 in k3987 in k3984 in k3904 in scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_fcall f_4007(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,4))){
C_save_and_reclaim_args((void *)trf_4007,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:99: debugging */
t3=*((C_word*)lf[17]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[18];
av2[3]=lf[19];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_3992(2,av2);}}}

/* k7068 in k7059 in k7056 in k7053 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7070(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7070,2,av);}
/* optimizer.scm:906: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_TRUE;
C_values(4,av2);}}

/* k4245 in k4239 in a4230 in k4218 in simplify in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_4247,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_caar(((C_word*)t0)[2]);
t3=C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t3)){
t4=C_i_cdr(t3);
t5=C_a_i_plus(&a,2,t4,C_fix(1));
t6=C_i_set_cdr(t3,t5);
t7=f_4175(((C_word*)((C_word*)t0)[4])[1]);
/* optimizer.scm:163: simplify */
t8=((C_word*)((C_word*)t0)[5])[1];
f_4216(t8,((C_word*)t0)[6],t1);}
else{
t4=C_a_i_cons(&a,2,C_a_i_cons(&a,2,t2,C_fix(1)),((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t4);
t6=f_4175(((C_word*)((C_word*)t0)[4])[1]);
/* optimizer.scm:163: simplify */
t7=((C_word*)((C_word*)t0)[5])[1];
f_4216(t7,((C_word*)t0)[6],t1);}}
else{
t2=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k4239 in a4230 in k4218 in simplify in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4241(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(28,c,3))){C_save_and_reclaim((void *)f_4241,2,av);}
a=C_alloc(28);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4247,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4289,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=C_i_check_list_2(((C_word*)t0)[7],lf[35]);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4303,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4305,a[2]=t10,a[3]=t8,a[4]=t14,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_4305(t16,t12,((C_word*)t0)[7]);}
else{
t3=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11909(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_11909,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:1685: gensym */
t4=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[195];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11915(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_11915,2,av);}
a=C_alloc(16);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11918,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12416,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12422,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:1688: list-tabulate */
t6=*((C_word*)lf[188]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t2;
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11918(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,3))){C_save_and_reclaim((void *)f_11918,2,av);}
a=C_alloc(26);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12378,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12380,a[2]=t6,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_12380(t12,t8,((C_word*)t0)[6]);}

/* k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11912(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,3))){C_save_and_reclaim((void *)f_11912,2,av);}
a=C_alloc(24);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_check_list_2(((C_word*)t0)[5],lf[35]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12445,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12447,a[2]=t5,a[3]=t10,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_12447(t12,t8,((C_word*)t0)[5]);}

/* k4069 in k4066 in k4063 in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_4071(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4071,2,av);}
a=C_alloc(5);
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_i_check_list_2(t2,lf[2]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4098,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4098(t7,((C_word*)t0)[3],t2);}

/* k7089 in a7077 in k7056 in k7053 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_7091(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,4))){
C_save_and_reclaim_args((void *)trf_7091,2,t0,t1);}
a=C_alloc(14);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=C_i_assq(((C_word*)t0)[2],((C_word*)t0)[4]);
t5=C_i_cdr(t4);
t6=C_a_i_list2(&a,2,t5,((C_word*)t0)[5]);
t7=((C_word*)t0)[6];
t8=t7;{
C_word av2[2];
av2[0]=t8;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[6],((C_word*)t0)[7],t6);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7120,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7150,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7152,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:893: fold-right */
t5=*((C_word*)lf[137]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* g2915 in k11922 in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_11925(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_11925,3,t0,t1,t2);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11929,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(t2);
/* optimizer.scm:1753: get */
t5=*((C_word*)lf[33]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=t4;
av2[4]=lf[126];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k4063 in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_4065(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_4065,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:109: scan */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3825(t3,t2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k11922 in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11924(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_11924,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12047,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_12047(t6,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k3810 in for-each-loop42 in scan-each in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_3812(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3812,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3802(t3,((C_word*)t0)[4],t2);}

/* k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11921(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_11921,2,av);}
a=C_alloc(18);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12070,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_12070(t6,t2,((C_word*)t0)[10]);}

/* k4066 in k4063 in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_ccall f_4068(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4068,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4129,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:111: delete-duplicates */
t4=*((C_word*)lf[26]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=*((C_word*)lf[27]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_4071(2,av2);}}}

/* for-each-loop2687 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_12528(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_12528,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12538,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1658: g2688 */
t5=((C_word*)t0)[3];
f_11772(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k11927 in g2915 in k11922 in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 in ... */
static void C_ccall f_11929(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_11929,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_check_list_2(t1,lf[2]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12017,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_12017(t7,((C_word*)t0)[5],t1);}

/* ##compiler#reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6865(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,4))){C_save_and_reclaim((void *)f_6865,5,av);}
a=C_alloc(21);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=t2;
t12=t3;
t13=C_i_check_list_2(t11,lf[35]);
t14=C_i_check_list_2(t12,lf[35]);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6878,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7307,a[2]=t9,a[3]=t17,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t19=((C_word*)t17)[1];
f_7307(t19,t15,t11,t12);}

/* k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,5))){C_save_and_reclaim((void *)f_6863,2,av);}
a=C_alloc(5);
t2=C_mutate2((C_word*)lf[130]+1 /* (set! ##compiler#reorganize-recursive-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6865,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7357,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:912: make-vector */
t4=*((C_word*)lf[198]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_fix(301);
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* g2929 in k11927 in g2915 in k11922 in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in ... */
static void C_fcall f_11930(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,2))){
C_save_and_reclaim_args((void *)trf_11930,3,t0,t1,t2);}
a=C_alloc(11);
t3=C_i_cdr(t2);
t4=t3;
t5=C_slot(t4,C_fix(3));
t6=C_i_cdr(t5);
t7=t6;
t8=C_slot(t4,C_fix(2));
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11962,a[2]=t9,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11966,a[2]=t10,a[3]=t7,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1761: varnode */
t12=*((C_word*)lf[51]+1);{
C_word av2[3];
av2[0]=t12;
av2[1]=t11;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}

/* k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(!C_demand(C_calculate_demand(160,c,10))){C_save_and_reclaim((void *)f_6860,2,av);}
a=C_alloc(160);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6863,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_list(&a,1,lf[199]);
t4=C_a_i_list(&a,2,lf[3],t3);
t5=C_a_i_list(&a,4,lf[12],lf[200],t4,lf[201]);
t6=C_a_i_list(&a,1,lf[199]);
t7=C_a_i_list(&a,2,lf[3],t6);
t8=C_a_i_list(&a,4,lf[12],lf[202],t7,lf[203]);
t9=C_a_i_list(&a,5,lf[5],lf[204],lf[191],t5,t8);
t10=C_a_i_list(&a,7,lf[204],lf[200],lf[202],lf[191],lf[201],lf[203],lf[199]);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12703,tmp=(C_word)a,a+=2,tmp);
t12=C_a_i_list(&a,3,t9,t10,t11);
t13=C_a_i_list(&a,1,lf[205]);
t14=C_a_i_list(&a,1,lf[206]);
t15=C_a_i_list(&a,2,lf[34],t14);
t16=C_a_i_list(&a,4,lf[144],t13,lf[191],t15);
t17=C_a_i_list(&a,5,lf[5],lf[204],t16,lf[201],lf[203]);
t18=C_a_i_list(&a,6,lf[204],lf[205],lf[191],lf[206],lf[201],lf[203]);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12567,tmp=(C_word)a,a+=2,tmp);
t20=C_a_i_list(&a,3,t17,t18,t19);
/* optimizer.scm:769: register-simplifications */
t21=*((C_word*)lf[128]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t21;
av2[1]=t2;
av2[2]=lf[5];
av2[3]=t12;
av2[4]=t20;
((C_proc)(void*)(*((C_word*)t21+1)))(5,av2);}}

/* k9190 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9192(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_9192,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_i_car(((C_word*)t0)[4]);
/* optimizer.scm:1198: qnode */
t6=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k9519 in k9513 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9521(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_9521,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_i_cadddr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9527,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(*((C_word*)lf[145]+1))){
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=t5;
f_9527(t9,C_u_i_car(t8));}
else{
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=t5;
f_9527(t8,C_u_i_car(t7));}}

/* k9525 in k9519 in k9513 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_9527(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,3))){
C_save_and_reclaim_args((void *)trf_9527,2,t0,t1);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9647,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1260: remove */
t5=*((C_word*)lf[4]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k12587 in a12566 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12589(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,4))){C_save_and_reclaim((void *)f_12589,2,av);}
a=C_alloc(23);
t2=t1;
t3=C_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_list1(&a,1,t3);
t5=t4;
t6=C_a_i_list1(&a,1,t2);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12625,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12627,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12669,a[2]=t8,a[3]=t9,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:817: qnode */
t11=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}

/* scan in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_fcall f_3825(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,2))){
C_save_and_reclaim_args((void *)trf_3825,4,t0,t1,t2,t3);}
a=C_alloc(15);
t4=t2;
t5=C_slot(t4,C_fix(2));
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(3));
t9=t8;
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=t11;
t13=C_eqp(t12,lf[3]);
if(C_truep(t13)){
t14=C_i_car(t6);
t15=t14;
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3862,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t15,tmp=(C_word)a,a+=5,tmp);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3879,a[2]=t15,a[3]=((C_word*)t0)[3],a[4]=t16,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_memq(t15,t3))){
t18=t17;
f_3879(t18,C_SCHEME_FALSE);}
else{
t18=C_i_memq(t15,((C_word*)((C_word*)t0)[3])[1]);
t19=t17;
f_3879(t19,C_i_not(t18));}}
else{
t14=C_eqp(t12,lf[5]);
t15=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3906,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t3,a[8]=t12,a[9]=t6,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=t2,a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[3],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t14)){
t16=t15;
f_3906(t16,t14);}
else{
t16=C_eqp(t12,lf[21]);
t17=t15;
f_3906(t17,(C_truep(t16)?t16:C_eqp(t12,lf[22])));}}}

/* k12651 in k12663 in k12659 in a12626 in k12587 in a12566 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12653(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,1))){C_save_and_reclaim((void *)f_12653,2,av);}
a=C_alloc(14);
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[4];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[21],C_SCHEME_END_OF_LIST,t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6878(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,4))){C_save_and_reclaim((void *)f_6878,2,av);}
a=C_alloc(21);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6880,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6935,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7270,a[2]=t9,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_7270(t11,t7,t5,t6);}

/* k11164 in k11130 in k11127 in g2380 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11166(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_11166,2,av);}
/* optimizer.scm:1504: node-parameters-set! */
t2=*((C_word*)lf[122]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k9140 in k9107 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_9142(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(19,0,1))){
C_save_and_reclaim_args((void *)trf_9142,2,t0,t1);}
a=C_alloc(19);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=C_a_i_record4(&a,4,lf[14],lf[144],t2,t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[4];
t7=t6;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[5],t5);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k7001 in g1391 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_7003,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7013,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:867: filter-map */
t5=*((C_word*)lf[134]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=((C_word*)((C_word*)t0)[6])[1];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* for-each-loop42 in scan-each in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_fcall f_3802(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_3802,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3812,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:41: g43 */
t5=((C_word*)t0)[3];
f_3790(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word *a;
if(!C_demand(C_calculate_demand(434,c,14))){C_save_and_reclaim((void *)f_6857,2,av);}
a=C_alloc(434);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6860,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_list(&a,1,lf[209]);
t4=C_a_i_list(&a,1,lf[205]);
t5=C_a_i_list(&a,1,lf[210]);
t6=C_a_i_list(&a,2,lf[3],t5);
t7=C_a_i_list(&a,1,lf[211]);
t8=C_a_i_list(&a,2,lf[34],t7);
t9=C_a_i_list(&a,4,lf[144],t4,t6,t8);
t10=C_a_i_list(&a,1,lf[209]);
t11=C_a_i_list(&a,2,lf[3],t10);
t12=C_a_i_list(&a,1,lf[212]);
t13=C_a_i_list(&a,1,lf[205]);
t14=C_a_i_list(&a,1,lf[210]);
t15=C_a_i_list(&a,2,lf[3],t14);
t16=C_a_i_list(&a,1,lf[213]);
t17=C_a_i_list(&a,2,lf[34],t16);
t18=C_a_i_list(&a,4,lf[144],t13,t15,t17);
t19=C_a_i_list(&a,1,lf[212]);
t20=C_a_i_list(&a,2,lf[3],t19);
t21=C_a_i_list(&a,5,lf[5],lf[200],t20,lf[214],lf[215]);
t22=C_a_i_list(&a,4,lf[6],t12,t18,t21);
t23=C_a_i_list(&a,5,lf[5],lf[204],t11,lf[216],t22);
t24=C_a_i_list(&a,4,lf[6],t3,t9,t23);
t25=C_a_i_list(&a,11,lf[210],lf[209],lf[212],lf[205],lf[211],lf[213],lf[216],lf[214],lf[204],lf[200],lf[215]);
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13364,tmp=(C_word)a,a+=2,tmp);
t27=C_a_i_list(&a,3,t24,t25,t26);
t28=C_a_i_list(&a,1,lf[199]);
t29=C_a_i_list(&a,1,lf[205]);
t30=C_a_i_list(&a,1,lf[210]);
t31=C_a_i_list(&a,2,lf[3],t30);
t32=C_a_i_list(&a,1,lf[220]);
t33=C_a_i_list(&a,2,lf[34],t32);
t34=C_a_i_list(&a,4,lf[144],t29,t31,t33);
t35=C_a_i_list(&a,1,lf[199]);
t36=C_a_i_list(&a,2,lf[3],t35);
t37=C_a_i_list(&a,1,lf[221]);
t38=C_a_i_list(&a,1,lf[210]);
t39=C_a_i_list(&a,2,lf[3],t38);
t40=C_a_i_cons(&a,2,t39,lf[222]);
t41=C_a_i_cons(&a,2,t37,t40);
t42=C_a_i_cons(&a,2,lf[22],t41);
t43=C_a_i_list(&a,5,lf[5],lf[223],t36,lf[224],t42);
t44=C_a_i_list(&a,4,lf[6],t28,t34,t43);
t45=C_a_i_list(&a,8,lf[199],lf[205],lf[210],lf[220],lf[223],lf[224],lf[221],lf[222]);
t46=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13234,tmp=(C_word)a,a+=2,tmp);
t47=C_a_i_list(&a,3,t44,t45,t46);
t48=C_a_i_list(&a,1,lf[209]);
t49=C_a_i_list(&a,2,lf[15],C_SCHEME_END_OF_LIST);
t50=C_a_i_list(&a,4,lf[6],t48,t49,lf[225]);
t51=C_a_i_list(&a,2,lf[209],lf[225]);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12875,tmp=(C_word)a,a+=2,tmp);
t53=C_a_i_list(&a,3,t50,t51,t52);
t54=C_a_i_list(&a,1,lf[199]);
t55=C_a_i_list(&a,1,lf[205]);
t56=C_a_i_cons(&a,2,t55,lf[226]);
t57=C_a_i_cons(&a,2,lf[144],t56);
t58=C_a_i_list(&a,1,lf[199]);
t59=C_a_i_list(&a,2,lf[3],t58);
t60=C_a_i_list(&a,5,lf[5],lf[223],t59,lf[191],lf[201]);
t61=C_a_i_list(&a,4,lf[6],t54,t57,t60);
t62=C_a_i_list(&a,6,lf[199],lf[205],lf[226],lf[223],lf[191],lf[201]);
t63=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12786,tmp=(C_word)a,a+=2,tmp);
t64=C_a_i_list(&a,3,t61,t62,t63);
/* optimizer.scm:624: register-simplifications */
t65=*((C_word*)lf[128]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t65;
av2[1]=t2;
av2[2]=lf[6];
av2[3]=t27;
av2[4]=t47;
av2[5]=t53;
av2[6]=t64;
((C_proc)(void*)(*((C_word*)t65+1)))(7,av2);}}

/* register-simplifications in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6850(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +0,c,4))){
C_save_and_reclaim((void*)f_6850,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+0);
t3=C_build_rest(&a,c,3,av);
C_word t4;
/* optimizer.scm:603: ##sys#hash-table-set! */
t4=*((C_word*)lf[129]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=*((C_word*)lf[30]+1);
av2[3]=t2;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k12659 in a12626 in k12587 in a12566 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12661(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_12661,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12665,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:814: qnode */
t4=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k12663 in k12659 in a12626 in k12587 in a12566 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12665(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_12665,2,av);}
a=C_alloc(16);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_record4(&a,4,lf[14],lf[144],((C_word*)t0)[3],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12653,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:815: qnode */
t6=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k12667 in k12587 in a12566 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_12669(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_12669,2,av);}
/* optimizer.scm:809: fold-right */
t2=*((C_word*)lf[137]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g354 in k4601 in k4595 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_4652(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_4652,3,t0,t1,t2);}
a=C_alloc(8);
t3=C_i_cdr(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4662,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4687,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* tweaks.scm:57: ##sys#get */
t7=*((C_word*)lf[45]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
av2[3]=lf[54];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t6=t5;
f_4662(t6,C_SCHEME_FALSE);}}

/* k7024 in a7012 in k7001 in g1391 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7026(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_7026,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_u_i_car(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* for-each-loop110 in k4069 in k4066 in k4063 in scan-toplevel-assignments in k3746 in k3743 in k3740 */
static void C_fcall f_4098(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_4098,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4108,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_SCHEME_END_OF_LIST;
if(C_truep(C_i_nullp(t5))){
/* tweaks.scm:54: ##sys#put! */
t6=*((C_word*)lf[23]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[24];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t6=C_i_car(t5);
/* tweaks.scm:54: ##sys#put! */
t7=*((C_word*)lf[23]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[24];
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8462 in k8442 in k8433 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8464(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_8464,2,av);}
a=C_alloc(9);
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8472,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t6=C_i_cadr(((C_word*)t0)[6]);
/* optimizer.scm:1072: qnode */
t7=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* find in find-path in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6886(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_6886,4,t0,t1,t2,t3);}
a=C_alloc(7);
if(C_truep(C_i_memq(t2,t3))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_i_cdr(t4);
t6=C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_a_i_cons(&a,2,t2,t3);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6910,a[2]=((C_word*)t0)[4],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:835: any */
t10=*((C_word*)lf[37]+1);{
C_word av2[4];
av2[0]=t10;
av2[1]=t1;
av2[2]=t9;
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}}}

/* find-path in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6880(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,4))){
C_save_and_reclaim_args((void *)trf_6880,4,t0,t1,t2,t3);}
a=C_alloc(7);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6886,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6886(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* a7012 in k7001 in g1391 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7013(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_7013,3,av);}
a=C_alloc(4);
t3=C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7026,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cdr(t2);
/* optimizer.scm:868: lset<= */
t6=*((C_word*)lf[133]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=*((C_word*)lf[27]+1);
av2[3]=t5;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}

/* k7009 in k7001 in g1391 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_7011(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_7011,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1),((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k8765 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_8767,2,av);}
a=C_alloc(12);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_eqp(*((C_word*)lf[146]+1),t3);
if(C_truep(t4)){
t5=C_i_cadddr(((C_word*)t0)[2]);
t6=(C_truep(t5)?t5:*((C_word*)lf[145]+1));
if(C_truep(t6)){
t7=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8811,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
if(C_truep(*((C_word*)lf[145]+1))){
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
t12=C_u_i_cdr(t11);
t13=C_u_i_cdr(t12);
t14=C_u_i_car(t13);
t15=t9;
f_8811(t15,C_a_i_list1(&a,1,t14));}
else{
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
t12=C_u_i_cdr(t11);
t13=C_u_i_car(t12);
t14=t9;
f_8811(t14,C_a_i_list1(&a,1,t13));}}
else{
t7=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}
else{
t5=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11876 in map-loop2740 in g2712 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11878(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_11878,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_11853(t6,((C_word*)t0)[5],t5);}

/* k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10717(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_10717,2,av);}
a=C_alloc(16);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm:1468: cdaddr */
t4=*((C_word*)lf[178]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k8442 in k8433 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8444(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_8444,2,av);}
a=C_alloc(13);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_a_i_list2(&a,2,C_SCHEME_FALSE,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8464,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[2];
t8=C_u_i_car(t7);
/* optimizer.scm:1069: varnode */
t9=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t6;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k4904 in a4898 in a4880 in k4874 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4906(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_4906,2,av);}
a=C_alloc(16);
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_i_cadr(((C_word*)t0)[2]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4946,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4953,a[2]=((C_word*)t0)[8],a[3]=t6,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[10])){
/* optimizer.scm:279: test */
t8=((C_word*)((C_word*)t0)[11])[1];
f_4139(t8,t7,((C_word*)t0)[5],lf[64]);}
else{
t8=t7;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
f_4953(2,av2);}}}

/* k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_10713(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,3))){
C_save_and_reclaim_args((void *)trf_10713,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
t2=C_u_i_car(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_10717,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm:1467: caaddr */
t4=*((C_word*)lf[179]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
/* optimizer.scm:1565: bomb */
t2=*((C_word*)lf[156]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=((C_word*)t0)[8];
av2[2]=lf[180];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* k13435 in k13381 in k13375 in a13363 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13437(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_13437,2,av);}
a=C_alloc(9);
t2=C_i_length(t1);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:647: get-list */
t5=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[9];
av2[3]=((C_word*)t0)[10];
av2[4]=lf[98];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* map-loop2740 in g2712 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_11853(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_11853,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11878,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1673: g2746 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g2192 in walk in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_10172(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_10172,3,t0,t1,t2);}
/* optimizer.scm:1373: walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9978(t3,t1,C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k4924 in k4944 in k4904 in a4898 in a4880 in k4874 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,1))){C_save_and_reclaim((void *)f_4926,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[11],((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k9269 in k9243 in k9234 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9271(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_9271,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11783(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,3))){C_save_and_reclaim((void *)f_11783,2,av);}
a=C_alloc(26);
t2=t1;
t3=C_fix(1);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11787,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=C_i_check_list_2(((C_word*)t0)[2],lf[35]);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11909,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12481,a[2]=t7,a[3]=t13,a[4]=t9,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_12481(t15,t11,((C_word*)t0)[2]);}

/* k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11780(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_11780,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11783,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1663: gensym */
t4=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[76];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* g2712 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_11787(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
if(!C_demand(C_calculate_demand(21,0,3))){
C_save_and_reclaim_args((void *)trf_11787,3,t0,t1,t2);}
a=C_alloc(21);
t3=t2;
t4=C_slot(t3,C_fix(2));
t5=C_i_car(t4);
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(3));
t9=C_i_car(t8);
t10=t9;
t11=C_slot(t10,C_fix(2));
t12=C_i_caddr(t11);
t13=t12;
t14=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t15=t14;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=((C_word*)t16)[1];
t18=*((C_word*)lf[83]+1);
t19=C_i_check_list_2(t13,lf[35]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11814,a[2]=t10,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=t13,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11853,a[2]=t16,a[3]=t22,a[4]=t18,a[5]=t17,tmp=(C_word)a,a+=6,tmp));
t24=((C_word*)t22)[1];
f_11853(t24,t20,t13);}

/* map-loop671 in k5428 in loop in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_5394(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_5394,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5419,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:401: g677 */
t5=((C_word*)t0)[4];
f_5371(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k12169 in k12161 in k12153 in k12217 in k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in ... */
static void C_ccall f_12171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_12171,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* optimizer.scm:1745: append */
t3=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a12172 in k12153 in k12217 in k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in ... */
static void C_ccall f_12173(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_12173,2,av);}
/* optimizer.scm:1746: qnode */
t2=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k10192 in for-each-loop2191 in walk in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10194(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10194,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10184(t3,((C_word*)t0)[4],t2);}

/* k5379 in k5428 in loop in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5381(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5381,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:405: invalidate-gae! */
f_4179(t3,((C_word*)t0)[5]);}

/* k5382 in k5379 in k5428 in loop in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5384(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_5384,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k12161 in k12153 in k12217 in k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in ... */
static void C_ccall f_12163(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_12163,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12171,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1747: qnode */
t4=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4944 in k4904 in a4898 in a4880 in k4874 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4946(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,4))){C_save_and_reclaim((void *)f_4946,2,av);}
a=C_alloc(19);
t2=C_i_cadddr(((C_word*)t0)[2]);
t3=C_a_i_list4(&a,4,((C_word*)t0)[3],((C_word*)t0)[4],t1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4926,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_car(((C_word*)t0)[6]);
t7=C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[8]);
/* optimizer.scm:285: walk */
t8=((C_word*)((C_word*)t0)[9])[1];
f_4350(t8,t5,t6,t7,C_SCHEME_END_OF_LIST);}

/* for-each-loop2191 in walk in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_10184(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_10184,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10194,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1373: g2192 */
t5=((C_word*)t0)[3];
f_10172(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10729(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,4))){C_save_and_reclaim((void *)f_10729,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10796,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10986,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:1542: lset-difference */
t5=*((C_word*)lf[169]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=((C_word*)t0)[9];
av2[4]=((C_word*)((C_word*)t0)[10])[1];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k12153 in k12217 in k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in ... */
static void C_ccall f_12155(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_12155,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12159,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12163,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12173,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:1746: list-tabulate */
t6=*((C_word*)lf[188]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10726(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,3))){C_save_and_reclaim((void *)f_10726,2,av);}
a=C_alloc(23);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[11];
t4=C_slot(t3,C_fix(3));
t5=C_i_car(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11004,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[13],a[8]=t7,a[9]=((C_word*)t0)[14],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t2;
av2[2]=t5;
f_11004(3,av2);}}

/* k12157 in k12153 in k12217 in k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in ... */
static void C_ccall f_12159(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_12159,2,av);}
/* optimizer.scm:1744: cons* */
t2=*((C_word*)lf[151]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k9013 in k8978 in k8955 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_9015(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(16,0,1))){
C_save_and_reclaim_args((void *)trf_9015,2,t0,t1);}
a=C_alloc(16);
t2=((C_word*)t0)[2];
t3=C_a_i_record4(&a,4,lf[14],lf[89],t1,t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
t6=t5;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[5],t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10720(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_10720,2,av);}
a=C_alloc(15);
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=C_u_i_cdr(t2);
t4=C_i_setslot(t3,C_fix(0),t1);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_10726,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm:1472: node-class-set! */
t6=*((C_word*)lf[170]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[12];
av2[3]=lf[69];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k12149 in k12217 in k12320 in k12324 in k12078 in descend in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in ... */
static void C_ccall f_12151(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,3))){C_save_and_reclaim((void *)f_12151,2,av);}
a=C_alloc(27);
t2=C_a_i_record4(&a,4,lf[14],lf[12],lf[189],t1);
t3=C_a_i_list2(&a,2,((C_word*)t0)[2],t2);
t4=C_a_i_record4(&a,4,lf[14],lf[6],((C_word*)t0)[3],t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[4],t4);
t6=C_a_i_record4(&a,4,lf[14],lf[6],((C_word*)t0)[5],t5);
/* optimizer.scm:1704: copy-node! */
t7=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[6];
av2[2]=t6;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k10128 in walk in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_10130,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_10018(2,av2);}}
else{
if(C_truep(C_i_listp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10048,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:1357: get */
t3=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[9];
av2[3]=((C_word*)t0)[6];
av2[4]=lf[49];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_10018(2,av2);}}}}

/* g2380 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_11119(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_11119,3,t0,t1,t2);}
a=C_alloc(9);
t3=C_i_cdr(t2);
t4=t3;
t5=C_slot(t4,C_fix(3));
t6=C_i_car(t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11129,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
t9=C_i_cdr(((C_word*)t0)[4]);
t10=C_i_length(t9);
t11=C_eqp(((C_word*)t0)[6],t10);
if(C_truep(t11)){
t12=t8;{
C_word av2[2];
av2[0]=t12;
av2[1]=C_SCHEME_UNDEFINED;
f_11129(2,av2);}}
else{
/* optimizer.scm:1500: quit */
t12=*((C_word*)lf[167]+1);{
C_word av2[4];
av2[0]=t12;
av2[1]=t8;
av2[2]=lf[174];
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t12+1)))(4,av2);}}}

/* g2452 in k10727 in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_10730(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_10730,3,t0,t1,t2);}
a=C_alloc(7);
t3=C_i_cdr(t2);
t4=t3;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10745,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t8=C_i_cdr(t6);
t9=C_i_length(t8);
t10=C_eqp(((C_word*)t0)[4],t9);
if(C_truep(t10)){
t11=t7;{
C_word av2[2];
av2[0]=t11;
av2[1]=C_SCHEME_UNDEFINED;
f_10745(2,av2);}}
else{
/* optimizer.scm:1532: quit */
t11=*((C_word*)lf[167]+1);{
C_word av2[4];
av2[0]=t11;
av2[1]=t7;
av2[2]=lf[168];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}}

/* k9017 in k8978 in k8955 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9019(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,1))){C_save_and_reclaim((void *)f_9019,2,av);}
a=C_alloc(14);
t2=C_eqp(C_SCHEME_TRUE,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t4=((C_word*)t0)[4];
f_9015(t4,C_a_i_list2(&a,2,t1,t3));}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=C_u_i_car(((C_word*)t0)[2]);
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_a_i_times(&a,2,((C_word*)t0)[3],t4);
t6=C_a_i_plus(&a,2,t3,t5);
t7=((C_word*)t0)[4];
f_9015(t7,C_a_i_list2(&a,2,t1,t6));}
else{
t3=((C_word*)t0)[4];
f_9015(t3,C_a_i_list2(&a,2,t1,((C_word*)t0)[2]));}}}

/* k11743 in for-each-loop2661 in walk in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11745(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11745,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11735(t3,((C_word*)t0)[4],t2);}

/* map-loop1695 in k8209 in k8206 in k8174 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_8341(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8341,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8366,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1044: gensym */
t4=*((C_word*)lf[83]+1);{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* loop in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_5354(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(20,0,3))){
C_save_and_reclaim_args((void *)trf_5354,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(20);
t6=C_i_nullp(t2);
t7=(C_truep(t6)?t6:C_i_zerop(t3));
if(C_truep(t7)){
t8=f_4175(((C_word*)((C_word*)t0)[2])[1]);
t9=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t11)[1];
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5371,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5430,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=t11,a[8]=t13,a[9]=t12,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:404: append-reverse */
t15=*((C_word*)lf[82]+1);{
C_word av2[4];
av2[0]=t15;
av2[1]=t14;
av2[2]=t5;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}
else{
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5436,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[9],a[8]=t5,a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[4],a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
t9=C_i_car(t2);
/* optimizer.scm:407: test */
t10=((C_word*)((C_word*)t0)[12])[1];
f_4139(t10,t8,t9,lf[60]);}}

/* k4951 in k4904 in a4898 in a4880 in k4874 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4953,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:280: debugging */
t3=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[18];
av2[3]=lf[63];
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
/* optimizer.scm:283: build-lambda-list */
t2=*((C_word*)lf[62]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[2];
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}}

/* k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10704(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_10704,2,av);}
a=C_alloc(16);
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=t2;
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
t7=C_u_i_length(((C_word*)t0)[2]);
t8=C_eqp(t7,C_fix(4));
if(C_truep(t8)){
t9=C_i_caddr(((C_word*)t0)[2]);
t10=t6;
f_10713(t10,C_i_listp(t9));}
else{
t9=t6;
f_10713(t9,C_SCHEME_FALSE);}}
else{
t7=t6;
f_10713(t7,C_SCHEME_FALSE);}}

/* k4954 in k4951 in k4904 in a4898 in a4880 in k4874 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4956(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_4956,2,av);}
a=C_alloc(4);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* optimizer.scm:282: build-lambda-list */
t3=*((C_word*)lf[62]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
av2[4]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k9107 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9109(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_9109,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(*((C_word*)lf[145]+1))){
t5=C_i_cddr(((C_word*)t0)[5]);
t6=C_i_pairp(t5);
t7=t4;
f_9142(t7,(C_truep(t6)?C_i_caddr(((C_word*)t0)[5]):C_i_cadr(((C_word*)t0)[5])));}
else{
t5=t4;
f_9142(t5,C_i_cadr(((C_word*)t0)[5]));}}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5340(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,8))){C_save_and_reclaim((void *)f_5340,2,av);}
a=C_alloc(22);
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[2]);
if(C_truep(C_i_lessp(t2,((C_word*)t0)[3]))){
/* optimizer.scm:396: walk-generic */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6345(t3,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8],((C_word*)t0)[9],((C_word*)t0)[10],((C_word*)t0)[11],C_SCHEME_TRUE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5354,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[15],a[9]=t4,a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],tmp=(C_word)a,a+=13,tmp));
t6=((C_word*)t4)[1];
f_5354(t6,((C_word*)t0)[5],((C_word*)t0)[19],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[20],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[6],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5678,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[20],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:423: test */
t4=((C_word*)((C_word*)t0)[18])[1];
f_4139(t4,t3,((C_word*)t0)[22],lf[64]);}}

/* k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11768(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_11768,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11771,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1655: walk */
t3=((C_word*)((C_word*)t0)[6])[1];
f_11483(t3,t2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k8433 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8435(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_8435,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8444,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1067: < */{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t3;
av2[2]=C_fix(0);
av2[3]=t2;
av2[4]=C_fix(3);
C_lessp(5,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11771(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_11771,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11772,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_i_check_list_2(t3,lf[2]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12519,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12528,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_12528(t9,t5,t3);}

/* g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_11772(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_11772,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_i_car(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11780,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1662: gensym */
t8=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[196];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k13556 in loop in k13541 in a13534 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13558(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_13558,2,av);}
a=C_alloc(13);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13562,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:611: g1068 */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=f_13562(C_a_i(&a,10),t2,t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[4];
t3=C_u_i_cdr(t2);
/* optimizer.scm:621: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_13548(t4,((C_word*)t0)[3],t3);}}

/* a6967 in g1367 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6968(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_6968,3,av);}
a=C_alloc(6);
t3=C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6981,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:849: find-path */
t5=((C_word*)t0)[3];
f_6880(t5,t4,((C_word*)t0)[2],t2);}}

/* k6960 in k6944 in g1367 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6962(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,4))){C_save_and_reclaim((void *)f_6962,2,av);}
a=C_alloc(16);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,C_a_i_cons(&a,2,t1,t2),((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6954,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* optimizer.scm:852: append */
t7=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)((C_word*)t0)[5])[1];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* loop in k13541 in a13534 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_13548(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,8))){
C_save_and_reclaim_args((void *)trf_13548,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13558,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=C_i_caar(t2);
t5=t2;
t6=C_u_i_car(t5);
t7=C_u_i_cdr(t6);
/* optimizer.scm:614: simplify-named-call */
t8=*((C_word*)lf[142]+1);{
C_word av2[9];
av2[0]=t8;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[2];
av2[5]=((C_word*)t0)[6];
av2[6]=t4;
av2[7]=t7;
av2[8]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t8+1)))(9,av2);}}}

/* k5313 in for-each-loop619 in k5243 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_5315(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5315,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5305(t3,((C_word*)t0)[4],t2);}

/* k13541 in a13534 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_13543(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_13543,2,av);}
a=C_alloc(10);
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13548,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_13548(t6,((C_word*)t0)[7],t2);}

/* g1391 in k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_6996(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,3))){
C_save_and_reclaim_args((void *)trf_6996,3,t0,t1,t2);}
a=C_alloc(11);
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7003,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7037,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=t2;
t8=C_u_i_cdr(t7);
/* optimizer.scm:861: append-map */
t9=*((C_word*)lf[135]+1);{
C_word av2[4];
av2[0]=t9;
av2[1]=t5;
av2[2]=t6;
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}

/* a6463 in k6421 in k6418 in k6414 in k6408 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6464(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6464,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6468,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:528: print */
t3=*((C_word*)lf[111]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[115];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6993 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6995(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,3))){C_save_and_reclaim((void *)f_6995,2,av);}
a=C_alloc(22);
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6996,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)((C_word*)t0)[2])[1];
t6=C_i_check_list_2(t5,lf[2]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7055,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7224,a[2]=t9,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_7224(t11,t7,t5);}

/* k6466 in a6463 in k6421 in k6418 in k6414 in k6408 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6468(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6468,2,av);}
a=C_alloc(5);
t2=*((C_word*)lf[31]+1);
t3=C_i_check_list_2(*((C_word*)lf[31]+1),lf[2]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6501,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_6501(t7,((C_word*)t0)[2],*((C_word*)lf[31]+1));}

/* for-each-loop619 in k5243 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_5305(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_5305,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5315,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:377: g620 */
t5=((C_word*)t0)[3];
f_5246(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6979 in a6967 in g1367 in k6933 in k6876 in reorganize-recursive-bindings in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6981(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6981,2,av);}
if(C_truep(t1)){
/* optimizer.scm:849: find-path */
t2=((C_word*)t0)[2];
f_6880(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6471 in for-each-loop921 in k6466 in a6463 in k6421 in k6418 in k6414 in k6408 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6473(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6473,2,av);}
t2=C_u_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_greaterp(t2,C_fix(1)))){
t3=C_u_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm:533: print */
t4=*((C_word*)lf[111]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=C_make_character(9);
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
/* optimizer.scm:534: newline */
t3=*((C_word*)lf[112]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4595 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4597(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_4597,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:231: test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4139(t4,t3,t2,lf[55]);}

/* g677 in loop in k5338 in k5240 in k5744 in a5223 in k5206 in k5168 in k5088 in k5081 in k5078 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_5371(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_5371,3,t0,t1,t2);}
/* optimizer.scm:401: g694 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4350(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k8470 in k8462 in k8442 in k8433 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8472(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_8472,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[7];
t5=C_u_i_cdr(t4);
if(C_truep(C_i_nullp(t5))){
t6=C_i_caddr(((C_word*)t0)[8]);
/* optimizer.scm:1074: varnode */
t7=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t6=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_i_cadr(((C_word*)t0)[7]);
f_8476(2,av2);}}}

/* k8474 in k8470 in k8462 in k8442 in k8433 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8476(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,1))){C_save_and_reclaim((void *)f_8476,2,av);}
a=C_alloc(20);
t2=C_a_i_list5(&a,5,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);
t3=((C_word*)t0)[6];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[7],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* g1068 in k13556 in loop in k13541 in a13534 in k4131 in k3746 in k3743 in k3740 */
static C_word C_fcall f_13562(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;{}
t2=C_i_assq(((C_word*)t0)[2],*((C_word*)lf[31]+1));
if(C_truep(t2)){
t3=C_i_cdr(t2);
t4=C_a_i_plus(&a,2,t3,C_fix(1));
t5=C_i_set_cdr(t2,t4);
return(t1);}
else{
t3=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],C_fix(1)),*((C_word*)lf[31]+1));
t4=C_mutate2((C_word*)lf[31]+1 /* (set! ##compiler#simplified-ops ...) */,t3);
return(t1);}}

/* k10016 in walk in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10018(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,7))){C_save_and_reclaim((void *)f_10018,2,av);}
if(C_truep(t1)){
/* optimizer.scm:1367: transform */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10685(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[8],((C_word*)((C_word*)t0)[9])[1]);}
else{
t2=C_i_car(((C_word*)t0)[10]);
/* optimizer.scm:1368: walk */
t3=((C_word*)((C_word*)t0)[11])[1];
f_9978(t3,((C_word*)t0)[3],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* k9234 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9236(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_9236,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(C_truep(*((C_word*)lf[145]+1))?C_i_caddr(((C_word*)t0)[2]):C_i_cadr(((C_word*)t0)[2]));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9245,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9352,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1211: remove */
t8=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6408 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6410(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_6410,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
/* optimizer.scm:518: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_TRUE;
C_values(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:520: debugging */
t3=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[28];
av2[3]=lf[118];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k6414 in k6408 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6416(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_6416,2,av);}
a=C_alloc(8);
t2=C_set_block_item(lf[31] /* ##compiler#simplified-ops */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:522: walk */
t4=((C_word*)((C_word*)t0)[8])[1];
f_4350(t4,t3,((C_word*)t0)[9],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k9243 in k9234 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9245(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,4))){C_save_and_reclaim((void *)f_9245,2,av);}
a=C_alloc(14);
if(C_truep(C_i_nullp(t1))){
t2=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1216: qnode */
t5=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=C_u_i_car(t1);
t5=C_a_i_list2(&a,2,((C_word*)t0)[2],t4);
t6=((C_word*)t0)[3];
t7=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],t3,t5);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t3=C_i_cadddr(((C_word*)t0)[5]);
t4=(C_truep(t3)?t3:C_eqp(*((C_word*)lf[146]+1),lf[147]));
if(C_truep(t4)){
t5=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9326,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1224: fold-inner */
t9=*((C_word*)lf[155]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
t5=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}}}

/* k6418 in k6414 in k6408 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6420(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_6420,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6423,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[7])[1]))){
/* optimizer.scm:523: debugging */
t4=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[18];
av2[3]=lf[117];
av2[4]=((C_word*)((C_word*)t0)[7])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_6423(2,av2);}}}

/* a4898 in a4880 in k4874 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4899(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_4899,4,av);}
a=C_alloc(12);
t4=f_4175(((C_word*)((C_word*)t0)[2])[1]);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4906,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:275: debugging */
t6=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[18];
av2[3]=lf[65];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k6427 in k6424 in k6421 in k6418 in k6414 in k6408 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6429(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_6429,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6432,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_greaterp(((C_word*)((C_word*)t0)[6])[1],C_fix(0)))){
/* optimizer.scm:537: debugging */
t3=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[18];
av2[3]=lf[109];
av2[4]=((C_word*)((C_word*)t0)[6])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6432(2,av2);}}}

/* k6424 in k6421 in k6418 in k6414 in k6408 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6426(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_6426,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_greaterp(((C_word*)((C_word*)t0)[7])[1],C_fix(0)))){
/* optimizer.scm:536: debugging */
t3=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[18];
av2[3]=lf[110];
av2[4]=((C_word*)((C_word*)t0)[7])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6429(2,av2);}}}

/* k6421 in k6418 in k6414 in k6408 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6423(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_6423,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(*((C_word*)lf[31]+1)))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6464,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:525: with-debugging-output */
t4=*((C_word*)lf[116]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[18];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6426(2,av2);}}}

/* k9765 in k9717 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,1))){C_save_and_reclaim((void *)f_9767,2,av);}
a=C_alloc(19);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=C_a_i_record4(&a,4,lf[14],lf[144],t2,t3);
t5=C_a_i_list2(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[4];
t7=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[5],t5);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k9210 in k9190 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9212(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_9212,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a4892 in a4886 in a4880 in k4874 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4893,3,av);}
/* optimizer.scm:273: test */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4139(t3,t1,t2,lf[60]);}

/* k6430 in k6427 in k6424 in k6421 in k6418 in k6414 in k6408 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6432(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_6432,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_greaterp(((C_word*)((C_word*)t0)[5])[1],C_fix(0)))){
/* optimizer.scm:538: debugging */
t3=*((C_word*)lf[17]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[18];
av2[3]=lf[108];
av2[4]=((C_word*)((C_word*)t0)[5])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
/* optimizer.scm:539: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)((C_word*)t0)[4])[1];
C_values(4,av2);}}}

/* k6433 in k6430 in k6427 in k6424 in k6421 in k6418 in k6414 in k6408 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_6435(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6435,2,av);}
/* optimizer.scm:539: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)((C_word*)t0)[4])[1];
C_values(4,av2);}}

/* k4858 in k4851 in k4716 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4860,2,av);}
t2=((C_word*)t0)[2];
f_4721(t2,C_i_not(t1));}

/* a9351 in k9234 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9352(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_9352,3,av);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(lf[34],t4);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_eqp(((C_word*)t0)[2],t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* map-loop1723 in k8220 in k8209 in k8206 in k8174 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_8307(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8307,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8332,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:1045: g1729 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9322 in k9243 in k9234 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9324(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_9324,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a9325 in k9243 in k9234 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_9326(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,1))){C_save_and_reclaim((void *)f_9326,4,av);}
a=C_alloc(14);
t4=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t5=C_a_i_list2(&a,2,t2,t3);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[144],t4,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k8809 in k8765 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_fcall f_8811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(16,0,1))){
C_save_and_reclaim_args((void *)trf_8811,2,t0,t1);}
a=C_alloc(16);
t2=((C_word*)t0)[2];
t3=C_a_i_record4(&a,4,lf[14],lf[144],t1,t2);
t4=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
t6=t5;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[5],t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* a4886 in a4880 in k4874 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4887(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_4887,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4893,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:273: partition */
t3=*((C_word*)lf[61]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a4880 in k4874 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,4))){C_save_and_reclaim((void *)f_4881,5,av);}
a=C_alloc(15);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4887,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t3,a[9]=t4,a[10]=((C_word*)t0)[2],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:272: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t5;
av2[3]=t6;
C_call_with_values(4,av2);}}

/* k4504 in k4498 in k4362 in walk in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4506(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4506,2,av);}
if(C_truep(t1)){
t2=C_i_cddr(((C_word*)t0)[2]);
/* optimizer.scm:191: every */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)((C_word*)t0)[4])[1];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_4442(2,av2);}}}

/* k8330 in map-loop1723 in k8220 in k8209 in k8206 in k8174 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8332(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8332,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8307(t6,((C_word*)t0)[5],t5);}

/* k4498 in k4362 in walk in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4500(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4500,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:190: foldable? */
t3=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_4442(2,av2);}}}

/* k11960 in g2929 in k11927 in g2915 in k11922 in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in ... */
static void C_ccall f_11962(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_11962,2,av);}
a=C_alloc(5);
t2=C_a_i_record4(&a,4,lf[14],lf[12],((C_word*)t0)[2],t1);
/* optimizer.scm:1758: copy-node! */
t3=*((C_word*)lf[16]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k11964 in g2929 in k11927 in g2915 in k11922 in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in ... */
static void C_ccall f_11966(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_11966,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11970,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11974,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=C_i_length(((C_word*)t0)[3]);
t6=C_a_i_minus(&a,2,((C_word*)t0)[5],t5);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11992,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:1764: list-tabulate */
t8=*((C_word*)lf[188]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t4;
av2[2]=t6;
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k8364 in map-loop1695 in k8209 in k8206 in k8174 in simplify-named-call in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_8366(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8366,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8341(t6,((C_word*)t0)[5],t5);}

/* k11968 in k11964 in g2929 in k11927 in g2915 in k11922 in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in ... */
static void C_ccall f_11970(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_11970,2,av);}
/* optimizer.scm:1761: cons* */
t2=*((C_word*)lf[151]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k11972 in k11964 in g2929 in k11927 in g2915 in k11922 in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in ... */
static void C_ccall f_11974(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_11974,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm:1767: qnode */
t5=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k4874 in walk1 in perform-high-level-optimizations in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_4876(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,5))){C_save_and_reclaim((void *)f_4876,2,av);}
a=C_alloc(13);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:270: decompose-lambda-list */
t3=*((C_word*)lf[66]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[9];
av2[2]=((C_word*)t0)[10];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4975,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm:286: test */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4139(t3,t2,((C_word*)t0)[6],lf[64]);}}

/* k11980 in k11972 in k11964 in g2929 in k11927 in g2915 in k11922 in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in ... */
static void C_ccall f_11982(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_11982,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* optimizer.scm:1762: append */
t3=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* a11991 in k11964 in g2929 in k11927 in g2915 in k11922 in k11919 in k11916 in k11913 in k11910 in k11907 in k11781 in k11778 in g2688 in k11769 in k11766 in determine-loop-and-dispatch in k7355 in k6861 in k6858 in k6855 in k4131 in ... */
static void C_ccall f_11992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11992,2,av);}
/* optimizer.scm:1766: qnode */
t2=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k11127 in g2380 in rec in k10724 in k10718 in k10715 in k10711 in k10702 in k10687 in transform in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_11129(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_11129,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:1503: node-class-set! */
t3=*((C_word*)lf[170]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=lf[6];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k10154 in walk in transform-direct-lambdas! in k7355 in k6861 in k6858 in k6855 in k4131 in k3746 in k3743 in k3740 */
static void C_ccall f_10156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10156,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm:1372: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9978(t3,((C_word*)t0)[4],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[589] = {
{"f_10689:optimizer_2escm",(void*)f_10689},
{"f_10683:optimizer_2escm",(void*)f_10683},
{"f_10685:optimizer_2escm",(void*)f_10685},
{"f_5845:optimizer_2escm",(void*)f_5845},
{"f_11138:optimizer_2escm",(void*)f_11138},
{"f_11132:optimizer_2escm",(void*)f_11132},
{"f_11135:optimizer_2escm",(void*)f_11135},
{"f_10676:optimizer_2escm",(void*)f_10676},
{"f_4383:optimizer_2escm",(void*)f_4383},
{"f_4795:optimizer_2escm",(void*)f_4795},
{"f_6537:optimizer_2escm",(void*)f_6537},
{"f_6530:optimizer_2escm",(void*)f_6530},
{"f_6533:optimizer_2escm",(void*)f_6533},
{"f_4760:optimizer_2escm",(void*)f_4760},
{"f_5755:optimizer_2escm",(void*)f_5755},
{"f_5752:optimizer_2escm",(void*)f_5752},
{"f_4785:optimizer_2escm",(void*)f_4785},
{"f_9647:optimizer_2escm",(void*)f_9647},
{"f_4305:optimizer_2escm",(void*)f_4305},
{"f_4303:optimizer_2escm",(void*)f_4303},
{"f_12326:optimizer_2escm",(void*)f_12326},
{"f_12786:optimizer_2escm",(void*)f_12786},
{"f_12322:optimizer_2escm",(void*)f_12322},
{"f_9719:optimizer_2escm",(void*)f_9719},
{"f_11830:optimizer_2escm",(void*)f_11830},
{"f_12314:optimizer_2escm",(void*)f_12314},
{"f_10643:optimizer_2escm",(void*)f_10643},
{"f_11819:optimizer_2escm",(void*)f_11819},
{"f_11814:optimizer_2escm",(void*)f_11814},
{"f_4547:optimizer_2escm",(void*)f_4547},
{"f_4543:optimizer_2escm",(void*)f_4543},
{"f_4555:optimizer_2escm",(void*)f_4555},
{"f_4558:optimizer_2escm",(void*)f_4558},
{"f_4551:optimizer_2escm",(void*)f_4551},
{"f_7809:optimizer_2escm",(void*)f_7809},
{"f_4563:optimizer_2escm",(void*)f_4563},
{"f_12380:optimizer_2escm",(void*)f_12380},
{"f_12378:optimizer_2escm",(void*)f_12378},
{"f_10426:optimizer_2escm",(void*)f_10426},
{"f_4364:optimizer_2escm",(void*)f_4364},
{"f_7392:optimizer_2escm",(void*)f_7392},
{"f_4350:optimizer_2escm",(void*)f_4350},
{"f_7382:optimizer_2escm",(void*)f_7382},
{"f_7379:optimizer_2escm",(void*)f_7379},
{"f_6376:optimizer_2escm",(void*)f_6376},
{"f_7373:optimizer_2escm",(void*)f_7373},
{"f_6382:optimizer_2escm",(void*)f_6382},
{"f_7363:optimizer_2escm",(void*)f_7363},
{"f_10479:optimizer_2escm",(void*)f_10479},
{"f_6389:optimizer_2escm",(void*)f_6389},
{"f_7357:optimizer_2escm",(void*)f_7357},
{"f_7359:optimizer_2escm",(void*)f_7359},
{"f_13428:optimizer_2escm",(void*)f_13428},
{"f_6351:optimizer_2escm",(void*)f_6351},
{"f_10986:optimizer_2escm",(void*)f_10986},
{"f_7876:optimizer_2escm",(void*)f_7876},
{"f_13419:optimizer_2escm",(void*)f_13419},
{"f_6361:optimizer_2escm",(void*)f_6361},
{"f_13415:optimizer_2escm",(void*)f_13415},
{"f_13411:optimizer_2escm",(void*)f_13411},
{"f_8890:optimizer_2escm",(void*)f_8890},
{"f_12057:optimizer_2escm",(void*)f_12057},
{"f_8886:optimizer_2escm",(void*)f_8886},
{"f_10484:optimizer_2escm",(void*)f_10484},
{"f_12989:optimizer_2escm",(void*)f_12989},
{"f_12080:optimizer_2escm",(void*)f_12080},
{"f_3953:optimizer_2escm",(void*)f_3953},
{"f_10437:optimizer_2escm",(void*)f_10437},
{"f_10432:optimizer_2escm",(void*)f_10432},
{"f_6592:optimizer_2escm",(void*)f_6592},
{"f_12070:optimizer_2escm",(void*)f_12070},
{"f_7480:optimizer_2escm",(void*)f_7480},
{"f_9975:optimizer_2escm",(void*)f_9975},
{"f_7307:optimizer_2escm",(void*)f_7307},
{"f_9978:optimizer_2escm",(void*)f_9978},
{"f_9485:optimizer_2escm",(void*)f_9485},
{"f_7477:optimizer_2escm",(void*)f_7477},
{"f_10973:optimizer_2escm",(void*)f_10973},
{"f_6565:optimizer_2escm",(void*)f_6565},
{"f_6564:optimizer_2escm",(void*)f_6564},
{"f_6936:optimizer_2escm",(void*)f_6936},
{"f_6935:optimizer_2escm",(void*)f_6935},
{"f_9473:optimizer_2escm",(void*)f_9473},
{"f_10963:optimizer_2escm",(void*)f_10963},
{"f_6932:optimizer_2escm",(void*)f_6932},
{"f_6305:optimizer_2escm",(void*)f_6305},
{"f_6550:optimizer_2escm",(void*)f_6550},
{"f_6286:optimizer_2escm",(void*)f_6286},
{"f_6923:optimizer_2escm",(void*)f_6923},
{"f_13210:optimizer_2escm",(void*)f_13210},
{"f_6586:optimizer_2escm",(void*)f_6586},
{"f_6583:optimizer_2escm",(void*)f_6583},
{"f_8864:optimizer_2escm",(void*)f_8864},
{"f_13204:optimizer_2escm",(void*)f_13204},
{"f_10060:optimizer_2escm",(void*)f_10060},
{"f_13364:optimizer_2escm",(void*)f_13364},
{"f_6345:optimizer_2escm",(void*)f_6345},
{"f_9428:optimizer_2escm",(void*)f_9428},
{"f_8957:optimizer_2escm",(void*)f_8957},
{"f_6317:optimizer_2escm",(void*)f_6317},
{"f_8538:optimizer_2escm",(void*)f_8538},
{"f_6313:optimizer_2escm",(void*)f_6313},
{"f_6252:optimizer_2escm",(void*)f_6252},
{"f_7407:optimizer_2escm",(void*)f_7407},
{"f_7198:optimizer_2escm",(void*)f_7198},
{"f_6328:optimizer_2escm",(void*)f_6328},
{"f_6324:optimizer_2escm",(void*)f_6324},
{"f_10630:optimizer_2escm",(void*)f_10630},
{"f_13277:optimizer_2escm",(void*)f_13277},
{"f_9461:optimizer_2escm",(void*)f_9461},
{"f_9463:optimizer_2escm",(void*)f_9463},
{"f_13273:optimizer_2escm",(void*)f_13273},
{"f_12017:optimizer_2escm",(void*)f_12017},
{"f_6276:optimizer_2escm",(void*)f_6276},
{"f_13269:optimizer_2escm",(void*)f_13269},
{"f_8528:optimizer_2escm",(void*)f_8528},
{"f_6208:optimizer_2escm",(void*)f_6208},
{"f_10619:optimizer_2escm",(void*)f_10619},
{"f_13290:optimizer_2escm",(void*)f_13290},
{"f_3989:optimizer_2escm",(void*)f_3989},
{"f_3986:optimizer_2escm",(void*)f_3986},
{"f_6210:optimizer_2escm",(void*)f_6210},
{"f_5267:optimizer_2escm",(void*)f_5267},
{"f_7442:optimizer_2escm",(void*)f_7442},
{"f_7150:optimizer_2escm",(void*)f_7150},
{"f_7152:optimizer_2escm",(void*)f_7152},
{"f_8980:optimizer_2escm",(void*)f_8980},
{"f_12833:optimizer_2escm",(void*)f_12833},
{"f_6220:optimizer_2escm",(void*)f_6220},
{"f_5259:optimizer_2escm",(void*)f_5259},
{"f_5256:optimizer_2escm",(void*)f_5256},
{"f_6234:optimizer_2escm",(void*)f_6234},
{"f_6235:optimizer_2escm",(void*)f_6235},
{"f_13098:optimizer_2escm",(void*)f_13098},
{"f_13090:optimizer_2escm",(void*)f_13090},
{"f_7120:optimizer_2escm",(void*)f_7120},
{"f_5242:optimizer_2escm",(void*)f_5242},
{"f_5245:optimizer_2escm",(void*)f_5245},
{"f_5246:optimizer_2escm",(void*)f_5246},
{"f_3995:optimizer_2escm",(void*)f_3995},
{"f_5262:optimizer_2escm",(void*)f_5262},
{"f_3992:optimizer_2escm",(void*)f_3992},
{"f_6837:optimizer_2escm",(void*)f_6837},
{"f_4975:optimizer_2escm",(void*)f_4975},
{"f_4980:optimizer_2escm",(void*)f_4980},
{"f_4987:optimizer_2escm",(void*)f_4987},
{"f_6816:optimizer_2escm",(void*)f_6816},
{"f_12885:optimizer_2escm",(void*)f_12885},
{"f_13016:optimizer_2escm",(void*)f_13016},
{"f_12875:optimizer_2escm",(void*)f_12875},
{"f_12027:optimizer_2escm",(void*)f_12027},
{"f_4175:optimizer_2escm",(void*)f_4175},
{"f_4179:optimizer_2escm",(void*)f_4179},
{"f_4108:optimizer_2escm",(void*)f_4108},
{"f_12047:optimizer_2escm",(void*)f_12047},
{"f_11227:optimizer_2escm",(void*)f_11227},
{"f_11224:optimizer_2escm",(void*)f_11224},
{"f_8699:optimizer_2escm",(void*)f_8699},
{"f_4129:optimizer_2escm",(void*)f_4129},
{"f_6800:optimizer_2escm",(void*)f_6800},
{"f_7935:optimizer_2escm",(void*)f_7935},
{"f_4145:optimizer_2escm",(void*)f_4145},
{"f_8654:optimizer_2escm",(void*)f_8654},
{"f_8650:optimizer_2escm",(void*)f_8650},
{"f_5208:optimizer_2escm",(void*)f_5208},
{"f_5711:optimizer_2escm",(void*)f_5711},
{"f_8684:optimizer_2escm",(void*)f_8684},
{"f_5224:optimizer_2escm",(void*)f_5224},
{"f_5746:optimizer_2escm",(void*)f_5746},
{"f_10054:optimizer_2escm",(void*)f_10054},
{"f_5733:optimizer_2escm",(void*)f_5733},
{"f_10048:optimizer_2escm",(void*)f_10048},
{"f_5737:optimizer_2escm",(void*)f_5737},
{"f_7764:optimizer_2escm",(void*)f_7764},
{"f_9905:optimizer_2escm",(void*)f_9905},
{"f_4472:optimizer_2escm",(void*)f_4472},
{"f_4139:optimizer_2escm",(void*)f_4139},
{"f_4133:optimizer_2escm",(void*)f_4133},
{"f_4136:optimizer_2escm",(void*)f_4136},
{"f_4451:optimizer_2escm",(void*)f_4451},
{"f_5281:optimizer_2escm",(void*)f_5281},
{"f_5284:optimizer_2escm",(void*)f_5284},
{"f_11287:optimizer_2escm",(void*)f_11287},
{"f_5270:optimizer_2escm",(void*)f_5270},
{"f_5274:optimizer_2escm",(void*)f_5274},
{"f_11297:optimizer_2escm",(void*)f_11297},
{"f_11275:optimizer_2escm",(void*)f_11275},
{"f_7829:optimizer_2escm",(void*)f_7829},
{"f_5992:optimizer_2escm",(void*)f_5992},
{"f_7837:optimizer_2escm",(void*)f_7837},
{"f_12227:optimizer_2escm",(void*)f_12227},
{"f_12219:optimizer_2escm",(void*)f_12219},
{"f_12242:optimizer_2escm",(void*)f_12242},
{"f_13535:optimizer_2escm",(void*)f_13535},
{"f_4629:optimizer_2escm",(void*)f_4629},
{"f_7983:optimizer_2escm",(void*)f_7983},
{"f_5979:optimizer_2escm",(void*)f_5979},
{"f_6640:optimizer_2escm",(void*)f_6640},
{"f_6643:optimizer_2escm",(void*)f_6643},
{"f_8075:optimizer_2escm",(void*)f_8075},
{"f_4603:optimizer_2escm",(void*)f_4603},
{"f_4609:optimizer_2escm",(void*)f_4609},
{"f_11543:optimizer_2escm",(void*)f_11543},
{"f_6633:optimizer_2escm",(void*)f_6633},
{"f_6646:optimizer_2escm",(void*)f_6646},
{"f_9878:optimizer_2escm",(void*)f_9878},
{"f_9882:optimizer_2escm",(void*)f_9882},
{"f_5678:optimizer_2escm",(void*)f_5678},
{"f_5691:optimizer_2escm",(void*)f_5691},
{"f_12290:optimizer_2escm",(void*)f_12290},
{"f_4193:optimizer_2escm",(void*)f_4193},
{"f_6183:optimizer_2escm",(void*)f_6183},
{"f_12294:optimizer_2escm",(void*)f_12294},
{"f_8176:optimizer_2escm",(void*)f_8176},
{"f_8714:optimizer_2escm",(void*)f_8714},
{"f_8718:optimizer_2escm",(void*)f_8718},
{"f_9858:optimizer_2escm",(void*)f_9858},
{"f_9852:optimizer_2escm",(void*)f_9852},
{"f_3906:optimizer_2escm",(void*)f_3906},
{"f_3909:optimizer_2escm",(void*)f_3909},
{"f_8150:optimizer_2escm",(void*)f_8150},
{"f_4465:optimizer_2escm",(void*)f_4465},
{"f_4461:optimizer_2escm",(void*)f_4461},
{"f_12260:optimizer_2escm",(void*)f_12260},
{"f_6177:optimizer_2escm",(void*)f_6177},
{"f_11529:optimizer_2escm",(void*)f_11529},
{"f_12254:optimizer_2escm",(void*)f_12254},
{"f_12250:optimizer_2escm",(void*)f_12250},
{"f_6140:optimizer_2escm",(void*)f_6140},
{"f_7280:optimizer_2escm",(void*)f_7280},
{"f_3945:optimizer_2escm",(void*)f_3945},
{"f_3949:optimizer_2escm",(void*)f_3949},
{"f_4442:optimizer_2escm",(void*)f_4442},
{"f_6151:optimizer_2escm",(void*)f_6151},
{"f_3938:optimizer_2escm",(void*)f_3938},
{"f_8108:optimizer_2escm",(void*)f_8108},
{"f_6134:optimizer_2escm",(void*)f_6134},
{"f_7257:optimizer_2escm",(void*)f_7257},
{"f_3915:optimizer_2escm",(void*)f_3915},
{"f_6103:optimizer_2escm",(void*)f_6103},
{"f_7247:optimizer_2escm",(void*)f_7247},
{"f_7743:optimizer_2escm",(void*)f_7743},
{"f_7270:optimizer_2escm",(void*)f_7270},
{"f_7717:optimizer_2escm",(void*)f_7717},
{"f_6160:optimizer_2escm",(void*)f_6160},
{"f_10830:optimizer_2escm",(void*)f_10830},
{"f_7636:optimizer_2escm",(void*)f_7636},
{"f_10887:optimizer_2escm",(void*)f_10887},
{"f_10819:optimizer_2escm",(void*)f_10819},
{"f_10816:optimizer_2escm",(void*)f_10816},
{"f_10874:optimizer_2escm",(void*)f_10874},
{"f_7708:optimizer_2escm",(void*)f_7708},
{"f_7234:optimizer_2escm",(void*)f_7234},
{"f_10864:optimizer_2escm",(void*)f_10864},
{"f_7224:optimizer_2escm",(void*)f_7224},
{"f_8116:optimizer_2escm",(void*)f_8116},
{"f_10216:optimizer_2escm",(void*)f_10216},
{"f_10213:optimizer_2escm",(void*)f_10213},
{"f_10859:optimizer_2escm",(void*)f_10859},
{"f_11691:optimizer_2escm",(void*)f_11691},
{"f_11697:optimizer_2escm",(void*)f_11697},
{"f_10280:optimizer_2escm",(void*)f_10280},
{"f_3783:optimizer_2escm",(void*)f_3783},
{"f_11088:optimizer_2escm",(void*)f_11088},
{"f_11085:optimizer_2escm",(void*)f_11085},
{"f_3788:optimizer_2escm",(void*)f_3788},
{"f_11082:optimizer_2escm",(void*)f_11082},
{"f_5083:optimizer_2escm",(void*)f_5083},
{"f_5080:optimizer_2escm",(void*)f_5080},
{"f_3781:optimizer_2escm",(void*)f_3781},
{"f_13100:optimizer_2escm",(void*)f_13100},
{"f_10822:optimizer_2escm",(void*)f_10822},
{"f_4853:optimizer_2escm",(void*)f_4853},
{"f_3760:optimizer_2escm",(void*)f_3760},
{"f_12447:optimizer_2escm",(void*)f_12447},
{"f_12445:optimizer_2escm",(void*)f_12445},
{"f_5448:optimizer_2escm",(void*)f_5448},
{"f_7722:optimizer_2escm",(void*)f_7722},
{"f_12723:optimizer_2escm",(void*)f_12723},
{"f_5442:optimizer_2escm",(void*)f_5442},
{"f_5090:optimizer_2escm",(void*)f_5090},
{"f_3790:optimizer_2escm",(void*)f_3790},
{"f_5436:optimizer_2escm",(void*)f_5436},
{"f_8279:optimizer_2escm",(void*)f_8279},
{"f_8277:optimizer_2escm",(void*)f_8277},
{"f_5430:optimizer_2escm",(void*)f_5430},
{"f_5468:optimizer_2escm",(void*)f_5468},
{"f_5143:optimizer_2escm",(void*)f_5143},
{"f_12703:optimizer_2escm",(void*)f_12703},
{"f_3776:optimizer_2escm",(void*)f_3776},
{"f_9828:optimizer_2escm",(void*)f_9828},
{"f_5170:optimizer_2escm",(void*)f_5170},
{"f_5173:optimizer_2escm",(void*)f_5173},
{"f_4718:optimizer_2escm",(void*)f_4718},
{"f_9803:optimizer_2escm",(void*)f_9803},
{"f_12481:optimizer_2escm",(void*)f_12481},
{"f_5486:optimizer_2escm",(void*)f_5486},
{"f_13174:optimizer_2escm",(void*)f_13174},
{"toplevel:optimizer_2escm",(void*)C_optimizer_toplevel},
{"f_11560:optimizer_2escm",(void*)f_11560},
{"f_5007:optimizer_2escm",(void*)f_5007},
{"f_4738:optimizer_2escm",(void*)f_4738},
{"f_5153:optimizer_2escm",(void*)f_5153},
{"f_5472:optimizer_2escm",(void*)f_5472},
{"f_12422:optimizer_2escm",(void*)f_12422},
{"f_3862:optimizer_2escm",(void*)f_3862},
{"f_10113:optimizer_2escm",(void*)f_10113},
{"f_3866:optimizer_2escm",(void*)f_3866},
{"f_3868:optimizer_2escm",(void*)f_3868},
{"f_4721:optimizer_2escm",(void*)f_4721},
{"f_11004:optimizer_2escm",(void*)f_11004},
{"f_12416:optimizer_2escm",(void*)f_12416},
{"f_5542:optimizer_2escm",(void*)f_5542},
{"f_4751:optimizer_2escm",(void*)f_4751},
{"f_5027:optimizer_2escm",(void*)f_5027},
{"f_4758:optimizer_2escm",(void*)f_4758},
{"f_13180:optimizer_2escm",(void*)f_13180},
{"f_8211:optimizer_2escm",(void*)f_8211},
{"f_11591:optimizer_2escm",(void*)f_11591},
{"f_6612:optimizer_2escm",(void*)f_6612},
{"f_5539:optimizer_2escm",(void*)f_5539},
{"f_6624:optimizer_2escm",(void*)f_6624},
{"f_10391:optimizer_2escm",(void*)f_10391},
{"f_3879:optimizer_2escm",(void*)f_3879},
{"f_6661:optimizer_2escm",(void*)f_6661},
{"f_6618:optimizer_2escm",(void*)f_6618},
{"f_8222:optimizer_2escm",(void*)f_8222},
{"f_5581:optimizer_2escm",(void*)f_5581},
{"f_5586:optimizer_2escm",(void*)f_5586},
{"f_8208:optimizer_2escm",(void*)f_8208},
{"f_5912:optimizer_2escm",(void*)f_5912},
{"f_5918:optimizer_2escm",(void*)f_5918},
{"f_5121:optimizer_2escm",(void*)f_5121},
{"f_5128:optimizer_2escm",(void*)f_5128},
{"f_8202:optimizer_2escm",(void*)f_8202},
{"f_6069:optimizer_2escm",(void*)f_6069},
{"f_8236:optimizer_2escm",(void*)f_8236},
{"f_6060:optimizer_2escm",(void*)f_6060},
{"f_5565:optimizer_2escm",(void*)f_5565},
{"f_8231:optimizer_2escm",(void*)f_8231},
{"f_5554:optimizer_2escm",(void*)f_5554},
{"f_5104:optimizer_2escm",(void*)f_5104},
{"f_5559:optimizer_2escm",(void*)f_5559},
{"f_5107:optimizer_2escm",(void*)f_5107},
{"f_9832:optimizer_2escm",(void*)f_9832},
{"f_5419:optimizer_2escm",(void*)f_5419},
{"f_9836:optimizer_2escm",(void*)f_9836},
{"f_9844:optimizer_2escm",(void*)f_9844},
{"f_9838:optimizer_2escm",(void*)f_9838},
{"f_5952:optimizer_2escm",(void*)f_5952},
{"f_9556:optimizer_2escm",(void*)f_9556},
{"f_4662:optimizer_2escm",(void*)f_4662},
{"f_10799:optimizer_2escm",(void*)f_10799},
{"f_4665:optimizer_2escm",(void*)f_4665},
{"f_10796:optimizer_2escm",(void*)f_10796},
{"f_11415:optimizer_2escm",(void*)f_11415},
{"f_11418:optimizer_2escm",(void*)f_11418},
{"f_8554:optimizer_2escm",(void*)f_8554},
{"f_5111:optimizer_2escm",(void*)f_5111},
{"f_8558:optimizer_2escm",(void*)f_8558},
{"f_6511:optimizer_2escm",(void*)f_6511},
{"f_6544:optimizer_2escm",(void*)f_6544},
{"f_6547:optimizer_2escm",(void*)f_6547},
{"f_10314:optimizer_2escm",(void*)f_10314},
{"f_4687:optimizer_2escm",(void*)f_4687},
{"f_10298:optimizer_2escm",(void*)f_10298},
{"f_6827:optimizer_2escm",(void*)f_6827},
{"f_11409:optimizer_2escm",(void*)f_11409},
{"f_10335:optimizer_2escm",(void*)f_10335},
{"f_8594:optimizer_2escm",(void*)f_8594},
{"f_10745:optimizer_2escm",(void*)f_10745},
{"f_11326:optimizer_2escm",(void*)f_11326},
{"f_6501:optimizer_2escm",(void*)f_6501},
{"f_7566:optimizer_2escm",(void*)f_7566},
{"f_5634:optimizer_2escm",(void*)f_5634},
{"f_5623:optimizer_2escm",(void*)f_5623},
{"f_4231:optimizer_2escm",(void*)f_4231},
{"f_11316:optimizer_2escm",(void*)f_11316},
{"f_11704:optimizer_2escm",(void*)f_11704},
{"f_11423:optimizer_2escm",(void*)f_11423},
{"f_4289:optimizer_2escm",(void*)f_4289},
{"f_11420:optimizer_2escm",(void*)f_11420},
{"f_10396:optimizer_2escm",(void*)f_10396},
{"f_11714:optimizer_2escm",(void*)f_11714},
{"f_5642:optimizer_2escm",(void*)f_5642},
{"f_11723:optimizer_2escm",(void*)f_11723},
{"f_11483:optimizer_2escm",(void*)f_11483},
{"f_11735:optimizer_2escm",(void*)f_11735},
{"f_13047:optimizer_2escm",(void*)f_13047},
{"f_10369:optimizer_2escm",(void*)f_10369},
{"f_6009:optimizer_2escm",(void*)f_6009},
{"f_10385:optimizer_2escm",(void*)f_10385},
{"f_4223:optimizer_2escm",(void*)f_4223},
{"f_4220:optimizer_2escm",(void*)f_4220},
{"f_11392:optimizer_2escm",(void*)f_11392},
{"f_11390:optimizer_2escm",(void*)f_11390},
{"f_6025:optimizer_2escm",(void*)f_6025},
{"f_11398:optimizer_2escm",(void*)f_11398},
{"f_12625:optimizer_2escm",(void*)f_12625},
{"f_12627:optimizer_2escm",(void*)f_12627},
{"f_5596:optimizer_2escm",(void*)f_5596},
{"f_5598:optimizer_2escm",(void*)f_5598},
{"f_4216:optimizer_2escm",(void*)f_4216},
{"f_12538:optimizer_2escm",(void*)f_12538},
{"f_5884:optimizer_2escm",(void*)f_5884},
{"f_5881:optimizer_2escm",(void*)f_5881},
{"f_9602:optimizer_2escm",(void*)f_9602},
{"f_9600:optimizer_2escm",(void*)f_9600},
{"f_6015:optimizer_2escm",(void*)f_6015},
{"f_9515:optimizer_2escm",(void*)f_9515},
{"f_11604:optimizer_2escm",(void*)f_11604},
{"f_11619:optimizer_2escm",(void*)f_11619},
{"f_11612:optimizer_2escm",(void*)f_11612},
{"f_12519:optimizer_2escm",(void*)f_12519},
{"f_9530:optimizer_2escm",(void*)f_9530},
{"f_5893:optimizer_2escm",(void*)f_5893},
{"f_5891:optimizer_2escm",(void*)f_5891},
{"f_6954:optimizer_2escm",(void*)f_6954},
{"f_6946:optimizer_2escm",(void*)f_6946},
{"f_7043:optimizer_2escm",(void*)f_7043},
{"f_13234:optimizer_2escm",(void*)f_13234},
{"f_7037:optimizer_2escm",(void*)f_7037},
{"f_3745:optimizer_2escm",(void*)f_3745},
{"f_3742:optimizer_2escm",(void*)f_3742},
{"f_5860:optimizer_2escm",(void*)f_5860},
{"f_3748:optimizer_2escm",(void*)f_3748},
{"f_7061:optimizer_2escm",(void*)f_7061},
{"f_6076:optimizer_2escm",(void*)f_6076},
{"f_6078:optimizer_2escm",(void*)f_6078},
{"f_12506:optimizer_2escm",(void*)f_12506},
{"f_13383:optimizer_2escm",(void*)f_13383},
{"f_7058:optimizer_2escm",(void*)f_7058},
{"f_7055:optimizer_2escm",(void*)f_7055},
{"f_6910:optimizer_2escm",(void*)f_6910},
{"f_13247:optimizer_2escm",(void*)f_13247},
{"f_12567:optimizer_2escm",(void*)f_12567},
{"f_13377:optimizer_2escm",(void*)f_13377},
{"f_10586:optimizer_2escm",(void*)f_10586},
{"f_4010:optimizer_2escm",(void*)f_4010},
{"f_3753:optimizer_2escm",(void*)f_3753},
{"f_3750:optimizer_2escm",(void*)f_3750},
{"f_7078:optimizer_2escm",(void*)f_7078},
{"f_4007:optimizer_2escm",(void*)f_4007},
{"f_7070:optimizer_2escm",(void*)f_7070},
{"f_4247:optimizer_2escm",(void*)f_4247},
{"f_4241:optimizer_2escm",(void*)f_4241},
{"f_11909:optimizer_2escm",(void*)f_11909},
{"f_11915:optimizer_2escm",(void*)f_11915},
{"f_11918:optimizer_2escm",(void*)f_11918},
{"f_11912:optimizer_2escm",(void*)f_11912},
{"f_4071:optimizer_2escm",(void*)f_4071},
{"f_7091:optimizer_2escm",(void*)f_7091},
{"f_11925:optimizer_2escm",(void*)f_11925},
{"f_4065:optimizer_2escm",(void*)f_4065},
{"f_11924:optimizer_2escm",(void*)f_11924},
{"f_3812:optimizer_2escm",(void*)f_3812},
{"f_11921:optimizer_2escm",(void*)f_11921},
{"f_4068:optimizer_2escm",(void*)f_4068},
{"f_12528:optimizer_2escm",(void*)f_12528},
{"f_11929:optimizer_2escm",(void*)f_11929},
{"f_6865:optimizer_2escm",(void*)f_6865},
{"f_6863:optimizer_2escm",(void*)f_6863},
{"f_11930:optimizer_2escm",(void*)f_11930},
{"f_6860:optimizer_2escm",(void*)f_6860},
{"f_9192:optimizer_2escm",(void*)f_9192},
{"f_9521:optimizer_2escm",(void*)f_9521},
{"f_9527:optimizer_2escm",(void*)f_9527},
{"f_12589:optimizer_2escm",(void*)f_12589},
{"f_3825:optimizer_2escm",(void*)f_3825},
{"f_12653:optimizer_2escm",(void*)f_12653},
{"f_6878:optimizer_2escm",(void*)f_6878},
{"f_11166:optimizer_2escm",(void*)f_11166},
{"f_9142:optimizer_2escm",(void*)f_9142},
{"f_7003:optimizer_2escm",(void*)f_7003},
{"f_3802:optimizer_2escm",(void*)f_3802},
{"f_6857:optimizer_2escm",(void*)f_6857},
{"f_6850:optimizer_2escm",(void*)f_6850},
{"f_12661:optimizer_2escm",(void*)f_12661},
{"f_12665:optimizer_2escm",(void*)f_12665},
{"f_12669:optimizer_2escm",(void*)f_12669},
{"f_4652:optimizer_2escm",(void*)f_4652},
{"f_7026:optimizer_2escm",(void*)f_7026},
{"f_4098:optimizer_2escm",(void*)f_4098},
{"f_8464:optimizer_2escm",(void*)f_8464},
{"f_6886:optimizer_2escm",(void*)f_6886},
{"f_6880:optimizer_2escm",(void*)f_6880},
{"f_7013:optimizer_2escm",(void*)f_7013},
{"f_7011:optimizer_2escm",(void*)f_7011},
{"f_8767:optimizer_2escm",(void*)f_8767},
{"f_11878:optimizer_2escm",(void*)f_11878},
{"f_10717:optimizer_2escm",(void*)f_10717},
{"f_8444:optimizer_2escm",(void*)f_8444},
{"f_4906:optimizer_2escm",(void*)f_4906},
{"f_10713:optimizer_2escm",(void*)f_10713},
{"f_13437:optimizer_2escm",(void*)f_13437},
{"f_11853:optimizer_2escm",(void*)f_11853},
{"f_10172:optimizer_2escm",(void*)f_10172},
{"f_4926:optimizer_2escm",(void*)f_4926},
{"f_9271:optimizer_2escm",(void*)f_9271},
{"f_11783:optimizer_2escm",(void*)f_11783},
{"f_11780:optimizer_2escm",(void*)f_11780},
{"f_11787:optimizer_2escm",(void*)f_11787},
{"f_5394:optimizer_2escm",(void*)f_5394},
{"f_12171:optimizer_2escm",(void*)f_12171},
{"f_12173:optimizer_2escm",(void*)f_12173},
{"f_10194:optimizer_2escm",(void*)f_10194},
{"f_5381:optimizer_2escm",(void*)f_5381},
{"f_5384:optimizer_2escm",(void*)f_5384},
{"f_12163:optimizer_2escm",(void*)f_12163},
{"f_4946:optimizer_2escm",(void*)f_4946},
{"f_10184:optimizer_2escm",(void*)f_10184},
{"f_10729:optimizer_2escm",(void*)f_10729},
{"f_12155:optimizer_2escm",(void*)f_12155},
{"f_10726:optimizer_2escm",(void*)f_10726},
{"f_12159:optimizer_2escm",(void*)f_12159},
{"f_9015:optimizer_2escm",(void*)f_9015},
{"f_10720:optimizer_2escm",(void*)f_10720},
{"f_12151:optimizer_2escm",(void*)f_12151},
{"f_10130:optimizer_2escm",(void*)f_10130},
{"f_11119:optimizer_2escm",(void*)f_11119},
{"f_10730:optimizer_2escm",(void*)f_10730},
{"f_9019:optimizer_2escm",(void*)f_9019},
{"f_11745:optimizer_2escm",(void*)f_11745},
{"f_8341:optimizer_2escm",(void*)f_8341},
{"f_5354:optimizer_2escm",(void*)f_5354},
{"f_4953:optimizer_2escm",(void*)f_4953},
{"f_10704:optimizer_2escm",(void*)f_10704},
{"f_4956:optimizer_2escm",(void*)f_4956},
{"f_9109:optimizer_2escm",(void*)f_9109},
{"f_5340:optimizer_2escm",(void*)f_5340},
{"f_11768:optimizer_2escm",(void*)f_11768},
{"f_8435:optimizer_2escm",(void*)f_8435},
{"f_11771:optimizer_2escm",(void*)f_11771},
{"f_11772:optimizer_2escm",(void*)f_11772},
{"f_13558:optimizer_2escm",(void*)f_13558},
{"f_6968:optimizer_2escm",(void*)f_6968},
{"f_6962:optimizer_2escm",(void*)f_6962},
{"f_13548:optimizer_2escm",(void*)f_13548},
{"f_5315:optimizer_2escm",(void*)f_5315},
{"f_13543:optimizer_2escm",(void*)f_13543},
{"f_6996:optimizer_2escm",(void*)f_6996},
{"f_6464:optimizer_2escm",(void*)f_6464},
{"f_6995:optimizer_2escm",(void*)f_6995},
{"f_6468:optimizer_2escm",(void*)f_6468},
{"f_5305:optimizer_2escm",(void*)f_5305},
{"f_6981:optimizer_2escm",(void*)f_6981},
{"f_6473:optimizer_2escm",(void*)f_6473},
{"f_4597:optimizer_2escm",(void*)f_4597},
{"f_5371:optimizer_2escm",(void*)f_5371},
{"f_8472:optimizer_2escm",(void*)f_8472},
{"f_8476:optimizer_2escm",(void*)f_8476},
{"f_13562:optimizer_2escm",(void*)f_13562},
{"f_10018:optimizer_2escm",(void*)f_10018},
{"f_9236:optimizer_2escm",(void*)f_9236},
{"f_6410:optimizer_2escm",(void*)f_6410},
{"f_6416:optimizer_2escm",(void*)f_6416},
{"f_9245:optimizer_2escm",(void*)f_9245},
{"f_6420:optimizer_2escm",(void*)f_6420},
{"f_4899:optimizer_2escm",(void*)f_4899},
{"f_6429:optimizer_2escm",(void*)f_6429},
{"f_6426:optimizer_2escm",(void*)f_6426},
{"f_6423:optimizer_2escm",(void*)f_6423},
{"f_9767:optimizer_2escm",(void*)f_9767},
{"f_9212:optimizer_2escm",(void*)f_9212},
{"f_4893:optimizer_2escm",(void*)f_4893},
{"f_6432:optimizer_2escm",(void*)f_6432},
{"f_6435:optimizer_2escm",(void*)f_6435},
{"f_4860:optimizer_2escm",(void*)f_4860},
{"f_9352:optimizer_2escm",(void*)f_9352},
{"f_8307:optimizer_2escm",(void*)f_8307},
{"f_9324:optimizer_2escm",(void*)f_9324},
{"f_9326:optimizer_2escm",(void*)f_9326},
{"f_8811:optimizer_2escm",(void*)f_8811},
{"f_4887:optimizer_2escm",(void*)f_4887},
{"f_4881:optimizer_2escm",(void*)f_4881},
{"f_4506:optimizer_2escm",(void*)f_4506},
{"f_8332:optimizer_2escm",(void*)f_8332},
{"f_4500:optimizer_2escm",(void*)f_4500},
{"f_11962:optimizer_2escm",(void*)f_11962},
{"f_11966:optimizer_2escm",(void*)f_11966},
{"f_8366:optimizer_2escm",(void*)f_8366},
{"f_11970:optimizer_2escm",(void*)f_11970},
{"f_11974:optimizer_2escm",(void*)f_11974},
{"f_4876:optimizer_2escm",(void*)f_4876},
{"f_11982:optimizer_2escm",(void*)f_11982},
{"f_11992:optimizer_2escm",(void*)f_11992},
{"f_11129:optimizer_2escm",(void*)f_11129},
{"f_10156:optimizer_2escm",(void*)f_10156},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  o		1
S|  map		12
S|  for-each		20
o|eliminated procedure checks: 294 
o|eliminated procedure checks: 1 
o|eliminated procedure checks: 1 
o|eliminated procedure checks: 1 
o|specializations:
o|  1 (> fixnum fixnum)
o|  1 (set-car! pair *)
o|  2 (cddr (pair * pair))
o|  1 (length list)
o|  1 (##sys#call-with-values (procedure () *) *)
o|  1 (<= fixnum fixnum)
o|  1 (positive? fixnum)
o|  3 (third (pair * (pair * pair)))
o|  1 (fourth (pair * (pair * (pair * pair))))
o|  1 (eqv? (not float) *)
o|  1 (< fixnum fixnum)
o|  7 (second (pair * pair))
o|  1 (cdar (pair pair *))
o|  17 (= fixnum fixnum)
o|  2 (set-cdr! pair *)
o|  30 (cdr pair)
o|  13 (##sys#check-list (or pair list) *)
o|  16 (car pair)
o|  32 (first pair)
o|  63 (eqv? * (not float))
(o e)|safe calls: 1364 
o|safe globals: (##compiler#scan-toplevel-assignments) 
o|Removed `not' forms: 30 
o|inlining procedure: k3755 
o|inlining procedure: k3755 
o|contracted procedure: k3765 
o|inlining procedure: k3804 
o|inlining procedure: k3804 
o|inlining procedure: k3851 
o|contracted procedure: k3884 
o|inlining procedure: k3851 
o|inlining procedure: k3930 
o|inlining procedure: k3930 
o|inlining procedure: k3963 
o|inlining procedure: k3963 
o|inlining procedure: k3993 
o|inlining procedure: k3993 
o|contracted procedure: "(optimizer.scm:101) g99100" 
o|substituted constant variable: a4034 
o|substituted constant variable: a4036 
o|substituted constant variable: a4041 
o|substituted constant variable: a4043 
o|substituted constant variable: a4045 
o|inlining procedure: k4049 
o|inlining procedure: k4049 
o|substituted constant variable: a4056 
o|substituted constant variable: a4058 
o|substituted constant variable: a4060 
o|substituted constant variable: a4062 
o|contracted procedure: "(optimizer.scm:65) g7475" 
o|contracted procedure: "(optimizer.scm:64) g6566" 
o|contracted procedure: "(optimizer.scm:63) g6263" 
o|inlining procedure: k4100 
o|contracted procedure: "(optimizer.scm:112) g111118" 
o|contracted procedure: "(optimizer.scm:112) g126127" 
o|inlining procedure: k4100 
o|contracted procedure: "(optimizer.scm:143) g178179" 
o|inlining procedure: k4195 
o|contracted procedure: "(optimizer.scm:134) g189196" 
o|inlining procedure: k4195 
o|inlining procedure: k4224 
o|inlining procedure: k4224 
o|inlining procedure: k4236 
o|inlining procedure: k4248 
o|inlining procedure: k4248 
o|inlining procedure: k4307 
o|inlining procedure: k4307 
o|inlining procedure: k4236 
o|contracted procedure: "(optimizer.scm:151) g216217" 
o|inlining procedure: k4352 
o|inlining procedure: k4352 
o|inlining procedure: k4381 
o|inlining procedure: k4404 
o|inlining procedure: k4404 
o|contracted procedure: "(optimizer.scm:180) node-value167" 
o|contracted procedure: "(optimizer.scm:144) g182183" 
o|inlining procedure: k4381 
o|inlining procedure: k4428 
o|contracted procedure: k4456 
o|inlining procedure: k4453 
o|contracted procedure: "(optimizer.scm:205) g301302" 
o|inlining procedure: k4453 
o|inlining procedure: k4501 
o|inlining procedure: k4501 
o|contracted procedure: "(optimizer.scm:189) g286287" 
o|contracted procedure: "(optimizer.scm:188) g282283" 
o|inlining procedure: k4428 
o|contracted procedure: "(optimizer.scm:187) g278279" 
o|substituted constant variable: a4539 
o|substituted constant variable: a4541 
o|contracted procedure: "(optimizer.scm:174) g269270" 
o|contracted procedure: "(optimizer.scm:173) g260261" 
o|inlining procedure: k4548 
o|inlining procedure: k4548 
o|inlining procedure: k4589 
o|contracted procedure: "(optimizer.scm:234) g346347" 
o|contracted procedure: k4633 
o|inlining procedure: k4630 
o|inlining procedure: k4657 
o|inlining procedure: k4657 
o|contracted procedure: "(optimizer.scm:243) g363364" 
o|inlining procedure: k4630 
o|inlining procedure: k4589 
o|inlining procedure: k4713 
o|inlining procedure: k4713 
o|contracted procedure: "(optimizer.scm:264) g390391" 
o|inlining procedure: k4762 
o|inlining procedure: k4762 
o|contracted procedure: "(optimizer.scm:261) g387388" 
o|contracted procedure: "(optimizer.scm:259) g384385" 
o|contracted procedure: "(optimizer.scm:258) g381382" 
o|inlining procedure: k4848 
o|inlining procedure: k4848 
o|inlining procedure: k4861 
o|contracted procedure: "(optimizer.scm:276) g441442" 
o|inlining procedure: k4970 
o|contracted procedure: "(optimizer.scm:292) g457458" 
o|inlining procedure: k4970 
o|inlining procedure: k4861 
o|inlining procedure: k5052 
o|propagated global variable: g518519 ##compiler#put! 
o|inlining procedure: k5085 
o|contracted procedure: "(optimizer.scm:329) g525526" 
o|inlining procedure: k5145 
o|inlining procedure: k5145 
o|contracted procedure: "(optimizer.scm:321) g496497" 
o|inlining procedure: k5085 
o|contracted procedure: "(optimizer.scm:349) g564565" 
o|contracted procedure: "(optimizer.scm:352) g569570" 
o|inlining procedure: k5203 
o|propagated global variable: g635636 ##compiler#put! 
o|inlining procedure: k5237 
o|contracted procedure: "(optimizer.scm:390) g647648" 
o|inlining procedure: k5307 
o|inlining procedure: k5307 
o|inlining procedure: k5237 
o|inlining procedure: k5341 
o|inlining procedure: k5341 
o|inlining procedure: k5356 
o|contracted procedure: "(optimizer.scm:406) g703704" 
o|inlining procedure: k5396 
o|inlining procedure: k5396 
o|inlining procedure: k5356 
o|inlining procedure: k5443 
o|contracted procedure: "(optimizer.scm:413) g710711" 
o|inlining procedure: k5443 
o|inlining procedure: k5534 
o|contracted procedure: "(optimizer.scm:431) g729730" 
o|inlining procedure: k5600 
o|inlining procedure: k5600 
o|inlining procedure: k5640 
o|inlining procedure: k5640 
o|contracted procedure: "(optimizer.scm:441) g761762" 
o|inlining procedure: k5534 
o|inlining procedure: k5686 
o|contracted procedure: k5695 
o|contracted procedure: k5701 
o|inlining procedure: k5698 
o|inlining procedure: k5698 
o|inlining procedure: k5718 
o|inlining procedure: k5718 
o|substituted constant variable: a5729 
o|contracted procedure: "(optimizer.scm:367) g610611" 
o|inlining procedure: k5686 
o|contracted procedure: "(optimizer.scm:362) g589590" 
o|contracted procedure: "(optimizer.scm:362) g592593" 
o|contracted procedure: "(optimizer.scm:356) g580581" 
o|inlining procedure: k5203 
o|contracted procedure: "(optimizer.scm:456) g790791" 
o|contracted procedure: "(optimizer.scm:454) g787788" 
o|inlining procedure: k5790 
o|contracted procedure: "(optimizer.scm:451) g781782" 
o|contracted procedure: "(optimizer.scm:451) g784785" 
o|inlining procedure: k5790 
o|contracted procedure: "(optimizer.scm:450) g778779" 
o|contracted procedure: "(optimizer.scm:354) g576577" 
o|inlining procedure: k5846 
o|inlining procedure: k5861 
o|inlining procedure: k5873 
o|propagated global variable: g562563 ##compiler#expression-has-side-effects? 
o|contracted procedure: k5903 
o|inlining procedure: k5900 
o|inlining procedure: k5900 
o|inlining procedure: k5873 
o|contracted procedure: "(optimizer.scm:338) g549550" 
o|contracted procedure: "(optimizer.scm:337) g545546" 
o|inlining procedure: k5861 
o|contracted procedure: k5943 
o|contracted procedure: "(optimizer.scm:334) g540541" 
o|inlining procedure: k5846 
o|contracted procedure: "(optimizer.scm:333) g536537" 
o|contracted procedure: "(optimizer.scm:332) g532533" 
o|contracted procedure: k5983 
o|inlining procedure: k5980 
o|inlining procedure: k5980 
o|contracted procedure: "(optimizer.scm:319) g492493" 
o|contracted procedure: k6010 
o|inlining procedure: k6016 
o|inlining procedure: k6016 
o|contracted procedure: "(optimizer.scm:310) g476477" 
o|inlining procedure: k6035 
o|contracted procedure: "(optimizer.scm:465) g797798" 
o|inlining procedure: k6080 
o|inlining procedure: k6080 
o|inlining procedure: k6035 
o|substituted constant variable: a6117 
o|substituted constant variable: a6119 
o|contracted procedure: "(optimizer.scm:306) g466467" 
o|inlining procedure: k5052 
o|inlining procedure: k6129 
o|contracted procedure: "(optimizer.scm:477) g842843" 
o|inlining procedure: k6129 
o|contracted procedure: "(optimizer.scm:480) g849850" 
o|inlining procedure: k6172 
o|contracted procedure: "(optimizer.scm:488) g861862" 
o|inlining procedure: k6172 
o|inlining procedure: k6212 
o|inlining procedure: k6212 
o|inlining procedure: k6237 
o|substituted constant variable: a6247 
o|inlining procedure: k6237 
o|inlining procedure: k6254 
o|substituted constant variable: a6264 
o|inlining procedure: k6254 
o|contracted procedure: "(optimizer.scm:490) g869870" 
o|contracted procedure: k6290 
o|inlining procedure: k6287 
o|inlining procedure: k6287 
o|contracted procedure: k6296 
o|substituted constant variable: a6333 
o|substituted constant variable: a6335 
o|substituted constant variable: a6337 
o|substituted constant variable: a6339 
o|substituted constant variable: a6341 
o|substituted constant variable: a6343 
o|contracted procedure: "(optimizer.scm:226) g331332" 
o|contracted procedure: "(optimizer.scm:225) g328329" 
o|contracted procedure: "(optimizer.scm:224) g325326" 
o|inlining procedure: k6353 
o|contracted procedure: "(optimizer.scm:511) g909910" 
o|inlining procedure: k6353 
o|inlining procedure: k6405 
o|inlining procedure: k6405 
o|inlining procedure: k6503 
o|contracted procedure: "(optimizer.scm:529) g922929" 
o|inlining procedure: k6474 
o|inlining procedure: k6474 
o|inlining procedure: k6503 
o|propagated global variable: g928930 ##compiler#simplified-ops 
o|inlining procedure: k6548 
o|inlining procedure: k6548 
o|inlining procedure: k6587 
o|inlining procedure: k6619 
o|contracted procedure: "(optimizer.scm:583) g10291030" 
o|contracted procedure: "(optimizer.scm:582) g10261027" 
o|contracted procedure: "(optimizer.scm:580) g10221023" 
o|inlining procedure: k6619 
o|inlining procedure: k6703 
o|contracted procedure: "(optimizer.scm:578) g10181019" 
o|inlining procedure: k6703 
o|substituted constant variable: a6721 
o|contracted procedure: "(optimizer.scm:572) g10101011" 
o|contracted procedure: "(optimizer.scm:571) g10061007" 
o|contracted procedure: "(optimizer.scm:570) g10021003" 
o|inlining procedure: k6587 
o|inlining procedure: k6754 
o|inlining procedure: k6763 
o|contracted procedure: "(optimizer.scm:569) g998999" 
o|inlining procedure: k6763 
o|substituted constant variable: a6781 
o|substituted constant variable: a6786 
o|inlining procedure: k6754 
o|contracted procedure: k6791 
o|contracted procedure: "(optimizer.scm:563) g988989" 
o|contracted procedure: "(optimizer.scm:562) g984985" 
o|inlining procedure: k6829 
o|inlining procedure: k6829 
o|contracted procedure: "(optimizer.scm:558) g966967" 
o|contracted procedure: k6891 
o|inlining procedure: k6888 
o|inlining procedure: k6888 
o|contracted procedure: k6941 
o|inlining procedure: k6938 
o|inlining procedure: k6938 
o|contracted procedure: k6973 
o|inlining procedure: k6970 
o|inlining procedure: k6970 
o|contracted procedure: k7018 
o|inlining procedure: k7015 
o|inlining procedure: k7015 
o|inlining procedure: k7062 
o|inlining procedure: k7062 
o|inlining procedure: k7086 
o|contracted procedure: "(optimizer.scm:886) g14251426" 
o|inlining procedure: k7086 
o|contracted procedure: "(optimizer.scm:890) g14331434" 
o|contracted procedure: "(optimizer.scm:892) g14381439" 
o|contracted procedure: "(optimizer.scm:895) g14451446" 
o|contracted procedure: "(optimizer.scm:897) g14501451" 
o|inlining procedure: k7226 
o|inlining procedure: k7226 
o|inlining procedure: k7249 
o|inlining procedure: k7249 
o|inlining procedure: k7272 
o|inlining procedure: k7272 
o|inlining procedure: k7309 
o|inlining procedure: k7309 
o|inlining procedure: k7387 
o|inlining procedure: k7387 
o|inlining procedure: k7396 
o|inlining procedure: k7396 
o|inlining procedure: k7461 
o|inlining procedure: k7481 
o|inlining procedure: k7481 
o|contracted procedure: "(optimizer.scm:947) g15351536" 
o|contracted procedure: "(optimizer.scm:949) g15401541" 
o|inlining procedure: k7529 
o|inlining procedure: k7541 
o|contracted procedure: "(optimizer.scm:945) g15291530" 
o|inlining procedure: k7541 
o|contracted procedure: "(optimizer.scm:944) g15261527" 
o|contracted procedure: "(optimizer.scm:944) g15231524" 
o|contracted procedure: "(optimizer.scm:943) g15191520" 
o|inlining procedure: k7529 
o|contracted procedure: "(optimizer.scm:942) g15151516" 
o|contracted procedure: "(optimizer.scm:938) g15051506" 
o|inlining procedure: k7461 
o|inlining procedure: k7617 
o|inlining procedure: k7626 
o|contracted procedure: "(optimizer.scm:959) g15561557" 
o|contracted procedure: "(optimizer.scm:963) g15611562" 
o|inlining procedure: k7626 
o|contracted procedure: "(optimizer.scm:956) g15481549" 
o|inlining procedure: k7617 
o|inlining procedure: k7689 
o|inlining procedure: k7698 
o|contracted procedure: "(optimizer.scm:973) g15771578" 
o|contracted procedure: "(optimizer.scm:974) g15821583" 
o|inlining procedure: k7698 
o|contracted procedure: "(optimizer.scm:969) g15681569" 
o|inlining procedure: k7689 
o|inlining procedure: k7787 
o|inlining procedure: k7793 
o|contracted procedure: "(optimizer.scm:983) g15941595" 
o|contracted procedure: "(optimizer.scm:982) g15911592" 
o|inlining procedure: k7793 
o|substituted constant variable: a7852 
o|inlining procedure: k7787 
o|inlining procedure: k7857 
o|inlining procedure: k7866 
o|inlining procedure: k7883 
o|contracted procedure: "(optimizer.scm:998) g16101611" 
o|contracted procedure: "(optimizer.scm:1000) g16151616" 
o|inlining procedure: k7883 
o|substituted constant variable: a7944 
o|inlining procedure: k7866 
o|contracted procedure: "(optimizer.scm:994) g16011602" 
o|inlining procedure: k7857 
o|inlining procedure: k7955 
o|inlining procedure: k7967 
o|contracted procedure: "(optimizer.scm:1010) g16301631" 
o|contracted procedure: "(optimizer.scm:1012) g16351636" 
o|contracted procedure: "(optimizer.scm:1013) g16401641" 
o|contracted procedure: "(optimizer.scm:1009) g16271628" 
o|inlining procedure: k7967 
o|substituted constant variable: a8036 
o|inlining procedure: k7955 
o|inlining procedure: k8041 
o|inlining procedure: k8056 
o|inlining procedure: k8065 
o|contracted procedure: "(optimizer.scm:1022) g16551656" 
o|contracted procedure: "(optimizer.scm:1024) g16601661" 
o|inlining procedure: k8065 
o|contracted procedure: "(optimizer.scm:1021) g16521653" 
o|inlining procedure: k8056 
o|inlining procedure: k8041 
o|inlining procedure: k8137 
o|contracted procedure: "(optimizer.scm:1031) g16671668" 
o|inlining procedure: k8137 
o|inlining procedure: k8157 
o|inlining procedure: k8166 
o|contracted procedure: "(optimizer.scm:1040) g16771678" 
o|inlining procedure: k8203 
o|contracted procedure: "(optimizer.scm:1047) g17501751" 
o|contracted procedure: "(optimizer.scm:1048) g17551756" 
o|contracted procedure: "(optimizer.scm:1057) g17631764" 
o|inlining procedure: k8294 
o|inlining procedure: k8294 
o|inlining procedure: k8309 
o|inlining procedure: k8309 
o|inlining procedure: k8343 
o|contracted procedure: "(optimizer.scm:1044) g17011710" 
o|inlining procedure: k8343 
o|inlining procedure: k8203 
o|inlining procedure: k8377 
o|inlining procedure: k8377 
o|substituted constant variable: a8406 
o|inlining procedure: k8166 
o|contracted procedure: "(optimizer.scm:1038) g16741675" 
o|inlining procedure: k8157 
o|inlining procedure: k8413 
o|inlining procedure: k8425 
o|contracted procedure: "(optimizer.scm:1068) g17791780" 
o|inlining procedure: k8474 
o|inlining procedure: k8474 
o|inlining procedure: k8425 
o|contracted procedure: "(optimizer.scm:1065) g17741775" 
o|inlining procedure: k8413 
o|inlining procedure: k8500 
o|inlining procedure: k8509 
o|inlining procedure: k8530 
o|contracted procedure: "(optimizer.scm:1086) g17981799" 
o|inlining procedure: k8530 
o|contracted procedure: "(optimizer.scm:1082) g17901791" 
o|inlining procedure: k8509 
o|inlining procedure: k8500 
o|inlining procedure: k8581 
o|inlining procedure: k8595 
o|inlining procedure: k8613 
o|contracted procedure: "(optimizer.scm:1100) g18201821" 
o|inlining procedure: k8613 
o|contracted procedure: "(optimizer.scm:1101) g18251826" 
o|substituted constant variable: a8660 
o|inlining procedure: k8595 
o|contracted procedure: "(optimizer.scm:1095) g18051806" 
o|inlining procedure: k8581 
o|inlining procedure: k8665 
o|inlining procedure: k8674 
o|inlining procedure: k8694 
o|contracted procedure: "(optimizer.scm:1113) g18411842" 
o|contracted procedure: "(optimizer.scm:1114) g18461847" 
o|inlining procedure: k8694 
o|inlining procedure: k8674 
o|contracted procedure: "(optimizer.scm:1109) g18321833" 
o|inlining procedure: k8665 
o|inlining procedure: k8748 
o|inlining procedure: k8757 
o|inlining procedure: k8774 
o|contracted procedure: "(optimizer.scm:1124) g18621863" 
o|contracted procedure: "(optimizer.scm:1127) g18671868" 
o|inlining procedure: k8813 
o|inlining procedure: k8813 
o|inlining procedure: k8774 
o|inlining procedure: k8757 
o|contracted procedure: "(optimizer.scm:1121) g18541855" 
o|inlining procedure: k8748 
o|inlining procedure: k8833 
o|inlining procedure: k8842 
o|inlining procedure: k8854 
o|contracted procedure: "(optimizer.scm:1140) g18861887" 
o|inlining procedure: k8899 
o|contracted procedure: "(optimizer.scm:1143) g18911892" 
o|inlining procedure: k8899 
o|inlining procedure: k8854 
o|contracted procedure: "(optimizer.scm:1138) g18791880" 
o|propagated global variable: tmp18751877 unsafe 
o|propagated global variable: tmp18751877 unsafe 
o|inlining procedure: k8842 
o|substituted constant variable: a8932 
o|inlining procedure: k8833 
o|inlining procedure: k8958 
o|inlining procedure: k8970 
o|contracted procedure: "(optimizer.scm:1165) g19151916" 
o|contracted procedure: "(optimizer.scm:1168) g19201921" 
o|inlining procedure: k9021 
o|inlining procedure: k9021 
o|inlining procedure: k9062 
o|substituted constant variable: a9070 
o|inlining procedure: k9062 
o|propagated global variable: tmp19121914 unsafe 
o|propagated global variable: tmp19121914 unsafe 
o|inlining procedure: k8970 
o|contracted procedure: "(optimizer.scm:1163) g19081909" 
o|inlining procedure: k8958 
o|inlining procedure: k9084 
o|inlining procedure: k9093 
o|contracted procedure: "(optimizer.scm:1184) g19371938" 
o|contracted procedure: "(optimizer.scm:1187) g19421943" 
o|inlining procedure: k9140 
o|inlining procedure: k9140 
o|contracted procedure: "(optimizer.scm:1183) g19341935" 
o|inlining procedure: k9093 
o|inlining procedure: k9084 
o|inlining procedure: k9173 
o|inlining procedure: k9182 
o|contracted procedure: "(optimizer.scm:1198) g19541955" 
o|inlining procedure: k9182 
o|contracted procedure: "(optimizer.scm:1197) g19511952" 
o|inlining procedure: k9173 
o|inlining procedure: k9217 
o|inlining procedure: k9226 
o|contracted procedure: "(optimizer.scm:1216) g19791980" 
o|inlining procedure: k9272 
o|contracted procedure: "(optimizer.scm:1218) g19841985" 
o|inlining procedure: k9272 
o|contracted procedure: "(optimizer.scm:1220) g19921993" 
o|contracted procedure: "(optimizer.scm:1226) g19992000" 
o|inlining procedure: k9354 
o|contracted procedure: "(optimizer.scm:1214) g19721973" 
o|inlining procedure: k9354 
o|contracted procedure: "(optimizer.scm:1213) g19691970" 
o|inlining procedure: k9226 
o|contracted procedure: "(optimizer.scm:1207) g19611962" 
o|inlining procedure: k9217 
o|inlining procedure: k9400 
o|inlining procedure: k9412 
o|contracted procedure: "(optimizer.scm:1237) g20152016" 
o|contracted procedure: "(optimizer.scm:1240) g20202021" 
o|contracted procedure: "(optimizer.scm:1236) g20122013" 
o|inlining procedure: k9412 
o|inlining procedure: k9400 
o|inlining procedure: k9496 
o|inlining procedure: k9505 
o|contracted procedure: "(optimizer.scm:1265) g20552056" 
o|inlining procedure: k9557 
o|contracted procedure: "(optimizer.scm:1267) g20602061" 
o|inlining procedure: k9557 
o|contracted procedure: "(optimizer.scm:1269) g20652066" 
o|inlining procedure: k9604 
o|contracted procedure: "(optimizer.scm:1276) g20722073" 
o|inlining procedure: k9604 
o|contracted procedure: "(optimizer.scm:1277) g20772078" 
o|inlining procedure: k9649 
o|contracted procedure: "(optimizer.scm:1263) g20482049" 
o|inlining procedure: k9649 
o|contracted procedure: "(optimizer.scm:1262) g20452046" 
o|inlining procedure: k9505 
o|contracted procedure: "(optimizer.scm:1254) g20352036" 
o|inlining procedure: k9496 
o|inlining procedure: k9700 
o|inlining procedure: k9709 
o|contracted procedure: "(optimizer.scm:1290) g20952096" 
o|inlining procedure: k9746 
o|contracted procedure: "(optimizer.scm:1294) g21002101" 
o|inlining procedure: k9746 
o|contracted procedure: "(optimizer.scm:1298) g21052106" 
o|inlining procedure: k9709 
o|contracted procedure: "(optimizer.scm:1288) g20882089" 
o|inlining procedure: k9700 
o|inlining procedure: k9784 
o|inlining procedure: k9793 
o|contracted procedure: "(optimizer.scm:1312) g21172118" 
o|inlining procedure: k9860 
o|contracted procedure: "(optimizer.scm:1325) defarg1486" 
o|inlining procedure: k7428 
o|inlining procedure: k7428 
o|inlining procedure: k9860 
o|inlining procedure: k9793 
o|contracted procedure: "(optimizer.scm:1309) g21122113" 
o|inlining procedure: k9784 
o|substituted constant variable: a9929 
o|substituted constant variable: a9931 
o|substituted constant variable: a9933 
o|substituted constant variable: a9935 
o|substituted constant variable: a9937 
o|substituted constant variable: a9939 
o|substituted constant variable: a9941 
o|substituted constant variable: a9943 
o|substituted constant variable: a9945 
o|substituted constant variable: a9947 
o|substituted constant variable: a9949 
o|substituted constant variable: a9951 
o|substituted constant variable: a9953 
o|substituted constant variable: a9955 
o|substituted constant variable: a9957 
o|substituted constant variable: a9959 
o|substituted constant variable: a9961 
o|substituted constant variable: a9963 
o|substituted constant variable: a9965 
o|substituted constant variable: a9967 
o|substituted constant variable: a9969 
o|substituted constant variable: a9971 
o|substituted constant variable: a9973 
o|inlining procedure: k10004 
o|inlining procedure: k10029 
o|contracted procedure: k10037 
o|inlining procedure: k10040 
o|inlining procedure: k10055 
o|inlining procedure: k10064 
o|contracted procedure: k10073 
o|inlining procedure: k10076 
o|inlining procedure: k10076 
o|contracted procedure: "(optimizer.scm:1362) g21802181" 
o|contracted procedure: "(optimizer.scm:1363) g21842185" 
o|inlining procedure: k10064 
o|inlining procedure: k10055 
o|inlining procedure: k10040 
o|inlining procedure: k10029 
o|inlining procedure: k10004 
o|inlining procedure: k10148 
o|inlining procedure: k10148 
o|inlining procedure: k10186 
o|inlining procedure: k10186 
o|substituted constant variable: a10207 
o|substituted constant variable: a10209 
o|substituted constant variable: a10211 
o|contracted procedure: "(optimizer.scm:1350) g21672168" 
o|contracted procedure: "(optimizer.scm:1349) g21582159" 
o|contracted procedure: "(optimizer.scm:1348) g21552156" 
o|inlining procedure: k10242 
o|inlining procedure: k10260 
o|inlining procedure: k10260 
o|contracted procedure: k10266 
o|inlining procedure: k10242 
o|inlining procedure: k10287 
o|inlining procedure: k10287 
o|inlining procedure: k10315 
o|contracted procedure: k10324 
o|inlining procedure: k10315 
o|inlining procedure: k10350 
o|inlining procedure: k10356 
o|inlining procedure: k10356 
o|inlining procedure: k10350 
o|inlining procedure: k10374 
o|contracted procedure: k10404 
o|inlining procedure: k10401 
o|inlining procedure: k10401 
o|inlining procedure: k10374 
o|inlining procedure: k10421 
o|inlining procedure: k10421 
o|contracted procedure: k10445 
o|inlining procedure: k10442 
o|inlining procedure: k10442 
o|inlining procedure: k10456 
o|inlining procedure: k10471 
o|inlining procedure: k10471 
o|inlining procedure: k10494 
o|contracted procedure: "(optimizer.scm:1432) g22922293" 
o|contracted procedure: "(optimizer.scm:1431) g22892290" 
o|inlining procedure: k10494 
o|contracted procedure: "(optimizer.scm:1427) g22802281" 
o|contracted procedure: "(optimizer.scm:1426) g22752276" 
o|inlining procedure: k10456 
o|inlining procedure: k10569 
o|inlining procedure: k10569 
o|contracted procedure: k10575 
o|inlining procedure: k10591 
o|inlining procedure: k10591 
o|inlining procedure: k10614 
o|inlining procedure: k10614 
o|substituted constant variable: a10649 
o|substituted constant variable: a10651 
o|substituted constant variable: a10653 
o|substituted constant variable: a10655 
o|substituted constant variable: a10657 
o|substituted constant variable: a10659 
o|substituted constant variable: a10661 
o|substituted constant variable: a10663 
o|substituted constant variable: a10665 
o|substituted constant variable: a10667 
o|contracted procedure: "(optimizer.scm:1381) g22332234" 
o|contracted procedure: "(optimizer.scm:1380) g22242225" 
o|contracted procedure: "(optimizer.scm:1379) g22212222" 
o|inlining procedure: k10671 
o|inlining procedure: k10671 
o|contracted procedure: "(optimizer.scm:1538) g24672468" 
o|contracted procedure: "(optimizer.scm:1530) g24642465" 
o|inlining procedure: k10708 
o|inlining procedure: k10866 
o|contracted procedure: "(optimizer.scm:1559) g25162523" 
o|contracted procedure: "(optimizer.scm:1563) g25302531" 
o|contracted procedure: "(optimizer.scm:1563) g25272528" 
o|inlining procedure: k10866 
o|contracted procedure: "(optimizer.scm:1551) g24902491" 
o|contracted procedure: "(optimizer.scm:1554) g24992500" 
o|contracted procedure: "(optimizer.scm:1554) g25102511" 
o|contracted procedure: "(optimizer.scm:1554) g25072508" 
o|contracted procedure: "(optimizer.scm:1554) g25042505" 
o|contracted procedure: "(optimizer.scm:1553) g24962497" 
o|contracted procedure: "(optimizer.scm:1546) g24822483" 
o|inlining procedure: k10965 
o|inlining procedure: k10965 
o|inlining procedure: k11030 
o|inlining procedure: k11064 
o|contracted procedure: "(optimizer.scm:1507) g23912392" 
o|contracted procedure: "(optimizer.scm:1504) g23882389" 
o|contracted procedure: "(optimizer.scm:1498) g23852386" 
o|inlining procedure: k11116 
o|inlining procedure: k11116 
o|inlining procedure: k11064 
o|contracted procedure: "(optimizer.scm:1484) g23642365" 
o|contracted procedure: "(optimizer.scm:1483) g23612362" 
o|contracted procedure: "(optimizer.scm:1482) g23572358" 
o|inlining procedure: k11030 
o|inlining procedure: k11263 
o|inlining procedure: k11263 
o|inlining procedure: k11289 
o|inlining procedure: k11289 
o|inlining procedure: k11318 
o|inlining procedure: k11318 
o|substituted constant variable: a11339 
o|substituted constant variable: a11341 
o|contracted procedure: "(optimizer.scm:1478) g23512352" 
o|contracted procedure: "(optimizer.scm:1477) g23422343" 
o|contracted procedure: "(optimizer.scm:1476) g23392340" 
o|contracted procedure: "(optimizer.scm:1475) g24462447" 
o|inlining procedure: k10708 
o|inlining procedure: k11361 
o|inlining procedure: k11361 
o|substituted constant variable: a11376 
o|contracted procedure: "(optimizer.scm:1460) g23202321" 
o|inlining procedure: k11425 
o|substituted constant variable: a11447 
o|inlining procedure: k11425 
o|inlining procedure: k11509 
o|inlining procedure: k11538 
o|inlining procedure: k11538 
o|inlining procedure: k11568 
o|inlining procedure: k11586 
o|contracted procedure: "(optimizer.scm:1630) user-lambda?2561" 
o|inlining procedure: k11451 
o|contracted procedure: "(optimizer.scm:1605) g25702571" 
o|inlining procedure: k11451 
o|contracted procedure: "(optimizer.scm:1604) g25672568" 
o|inlining procedure: k11586 
o|inlining procedure: k11613 
o|inlining procedure: k11613 
o|inlining procedure: k11620 
o|inlining procedure: k11620 
o|contracted procedure: "(optimizer.scm:1626) g26192620" 
o|contracted procedure: "(optimizer.scm:1624) g26152616" 
o|contracted procedure: "(optimizer.scm:1623) g26122613" 
o|inlining procedure: k11568 
o|contracted procedure: "(optimizer.scm:1622) g26072608" 
o|contracted procedure: k11659 
o|contracted procedure: "(optimizer.scm:1617) g26012602" 
o|inlining procedure: k11509 
o|inlining procedure: k11737 
o|inlining procedure: k11737 
o|substituted constant variable: a11761 
o|substituted constant variable: a11763 
o|substituted constant variable: a11765 
o|contracted procedure: "(optimizer.scm:1610) g25842585" 
o|contracted procedure: "(optimizer.scm:1609) g25812582" 
o|contracted procedure: "(optimizer.scm:1608) g25782579" 
o|contracted procedure: "(optimizer.scm:1681) g27722773" 
o|contracted procedure: "(optimizer.scm:1677) g27692770" 
o|inlining procedure: k11855 
o|inlining procedure: k11855 
o|contracted procedure: "(optimizer.scm:1671) g27332734" 
o|contracted procedure: "(optimizer.scm:1670) g27292730" 
o|contracted procedure: "(optimizer.scm:1669) g27252726" 
o|contracted procedure: "(optimizer.scm:1759) g29442945" 
o|contracted procedure: "(optimizer.scm:1760) g29492950" 
o|contracted procedure: "(optimizer.scm:1757) g29412942" 
o|inlining procedure: k12019 
o|inlining procedure: k12019 
o|inlining procedure: k12049 
o|inlining procedure: k12049 
o|inlining procedure: k12075 
o|inlining procedure: k12075 
o|contracted procedure: "(optimizer.scm:1705) g28622863" 
o|contracted procedure: "(optimizer.scm:1710) g28722873" 
o|contracted procedure: "(optimizer.scm:1742) g29052906" 
o|contracted procedure: "(optimizer.scm:1713) g28772878" 
o|contracted procedure: "(optimizer.scm:1716) g28822883" 
o|contracted procedure: "(optimizer.scm:1721) g28872888" 
o|contracted procedure: "(optimizer.scm:1738) g29022903" 
o|inlining procedure: k12262 
o|inlining procedure: k12262 
o|contracted procedure: "(optimizer.scm:1733) g28962897" 
o|contracted procedure: "(optimizer.scm:1709) g28672868" 
o|contracted procedure: "(optimizer.scm:1701) g28592860" 
o|contracted procedure: "(optimizer.scm:1700) g28562857" 
o|contracted procedure: "(optimizer.scm:1699) g28522853" 
o|contracted procedure: "(optimizer.scm:1698) g28482849" 
o|inlining procedure: k12382 
o|inlining procedure: k12382 
o|inlining procedure: k12449 
o|contracted procedure: "(optimizer.scm:1686) g27962805" 
o|inlining procedure: k12449 
o|inlining procedure: k12483 
o|inlining procedure: k12483 
o|inlining procedure: k12530 
o|inlining procedure: k12530 
o|inlining procedure: k12572 
o|inlining procedure: k12581 
o|contracted procedure: "(optimizer.scm:802) g12651266" 
o|contracted procedure: "(optimizer.scm:806) g12701271" 
o|contracted procedure: "(optimizer.scm:811) g12771278" 
o|contracted procedure: "(optimizer.scm:814) g12821283" 
o|inlining procedure: k12581 
o|inlining procedure: k12572 
o|inlining procedure: k12705 
o|contracted procedure: "(optimizer.scm:783) g12421243" 
o|contracted procedure: "(optimizer.scm:786) g12471248" 
o|inlining procedure: k12705 
o|contracted procedure: k12791 
o|inlining procedure: k12788 
o|inlining procedure: k12788 
o|contracted procedure: "(optimizer.scm:763) g12201221" 
o|contracted procedure: "(optimizer.scm:765) g12251226" 
o|substituted constant variable: a12825 
o|inlining procedure: k12911 
o|contracted procedure: k12926 
o|inlining procedure: k12923 
o|inlining procedure: k12923 
o|contracted procedure: k12932 
o|inlining procedure: k12962 
o|inlining procedure: k12962 
o|inlining procedure: k12990 
o|inlining procedure: k13042 
o|contracted procedure: "(optimizer.scm:725) g12001201" 
o|inlining procedure: k13042 
o|inlining procedure: k13102 
o|inlining procedure: k13102 
o|inlining procedure: k13108 
o|contracted procedure: k13117 
o|contracted procedure: k13123 
o|inlining procedure: k13120 
o|inlining procedure: k13120 
o|inlining procedure: k13132 
o|contracted procedure: "(optimizer.scm:724) g11971198" 
o|inlining procedure: k13132 
o|contracted procedure: "(optimizer.scm:723) g11941195" 
o|inlining procedure: k13108 
o|contracted procedure: "(optimizer.scm:717) g11811182" 
o|contracted procedure: "(optimizer.scm:716) g11781179" 
o|contracted procedure: "(optimizer.scm:715) g11751176" 
o|inlining procedure: k12990 
o|substituted constant variable: a13198 
o|substituted constant variable: a13200 
o|contracted procedure: "(optimizer.scm:706) g11621163" 
o|contracted procedure: "(optimizer.scm:705) g11531154" 
o|contracted procedure: "(optimizer.scm:704) g11491150" 
o|inlining procedure: k12911 
o|contracted procedure: "(optimizer.scm:698) g11401141" 
o|contracted procedure: "(optimizer.scm:697) g11371138" 
o|contracted procedure: "(optimizer.scm:696) g11341135" 
o|inlining procedure: k13236 
o|inlining procedure: k13248 
o|contracted procedure: "(optimizer.scm:673) g11171118" 
o|inlining procedure: k13248 
o|substituted constant variable: a13282 
o|inlining procedure: k13236 
o|inlining procedure: k13366 
o|inlining procedure: k13378 
o|inlining procedure: k13390 
o|contracted procedure: "(optimizer.scm:648) g10971098" 
o|inlining procedure: k13390 
o|substituted constant variable: a13420 
o|substituted constant variable: a13429 
o|inlining procedure: k13378 
o|inlining procedure: k13366 
o|inlining procedure: k13550 
o|inlining procedure: k13550 
o|inlining procedure: k13567 
o|inlining procedure: k13567 
o|replaced variables: 1980 
o|removed binding forms: 606 
o|substituted constant variable: c101 
o|substituted constant variable: p102 
o|substituted constant variable: s103 
o|substituted constant variable: tmp132135 
o|substituted constant variable: mark134 
o|substituted constant variable: r424913650 
o|substituted constant variable: r423713653 
o|inlining procedure: k4381 
o|substituted constant variable: c303 
o|inlining procedure: k4381 
o|substituted constant variable: r450213668 
o|inlining procedure: k4381 
o|inlining procedure: k4381 
o|substituted constant variable: mark366 
o|substituted constant variable: c392 
o|substituted constant variable: r484913683 
o|substituted constant variable: c443 
o|substituted constant variable: c459 
o|substituted constant variable: c566 
o|substituted constant variable: c571 
o|substituted constant variable: p572 
o|substituted constant variable: s573 
o|converted assignments to bindings: (cfk643) 
o|substituted constant variable: c705 
o|substituted constant variable: c712 
o|substituted constant variable: c731 
o|substituted constant variable: c763 
o|substituted constant variable: r569913715 
o|substituted constant variable: mark613 
o|substituted constant variable: r568713719 
o|substituted constant variable: mark595 
o|substituted constant variable: c792 
o|substituted constant variable: r579113722 
o|substituted constant variable: r590113726 
o|substituted constant variable: r587413728 
o|substituted constant variable: r586213729 
o|substituted constant variable: r584713730 
o|substituted constant variable: mark535 
o|substituted constant variable: r598113731 
o|substituted constant variable: c799 
o|substituted constant variable: c844 
o|substituted constant variable: p845 
o|substituted constant variable: s846 
o|substituted constant variable: c851 
o|substituted constant variable: p852 
o|substituted constant variable: s853 
o|substituted constant variable: c863 
o|substituted constant variable: p864 
o|substituted constant variable: s865 
o|substituted constant variable: c871 
o|substituted constant variable: r628813750 
o|substituted constant variable: r670413768 
o|substituted constant variable: r676413772 
o|substituted constant variable: r675513773 
o|substituted constant variable: sym968 
o|substituted constant variable: r688913776 
o|substituted constant variable: r697113780 
o|substituted constant variable: r701613782 
o|substituted constant variable: c1427 
o|substituted constant variable: c1435 
o|substituted constant variable: c1440 
o|substituted constant variable: p1441 
o|substituted constant variable: s1442 
o|substituted constant variable: c1447 
o|substituted constant variable: c1452 
o|converted assignments to bindings: (find-path1335) 
o|substituted constant variable: r739713799 
o|substituted constant variable: c1537 
o|substituted constant variable: c1542 
o|substituted constant variable: c1531 
o|substituted constant variable: r754213805 
o|substituted constant variable: r753013806 
o|substituted constant variable: c1558 
o|substituted constant variable: c1563 
o|substituted constant variable: r762713810 
o|substituted constant variable: r761813811 
o|substituted constant variable: c1579 
o|substituted constant variable: c1584 
o|substituted constant variable: r769913814 
o|substituted constant variable: c1596 
o|substituted constant variable: r779413818 
o|substituted constant variable: r778813819 
o|substituted constant variable: c1612 
o|substituted constant variable: c1617 
o|substituted constant variable: r788413823 
o|substituted constant variable: r786713824 
o|substituted constant variable: c1632 
o|substituted constant variable: c1637 
o|substituted constant variable: c1642 
o|substituted constant variable: r796813828 
o|substituted constant variable: r795613829 
o|substituted constant variable: c1657 
o|substituted constant variable: c1662 
o|substituted constant variable: r806613833 
o|substituted constant variable: r805713834 
o|substituted constant variable: r813813837 
o|substituted constant variable: c1679 
o|substituted constant variable: c1752 
o|substituted constant variable: c1757 
o|substituted constant variable: c1765 
o|substituted constant variable: r820413849 
o|substituted constant variable: r816713852 
o|substituted constant variable: c1781 
o|substituted constant variable: r842613860 
o|substituted constant variable: r841413861 
o|substituted constant variable: c1800 
o|substituted constant variable: r853113865 
o|substituted constant variable: r851013866 
o|substituted constant variable: c1822 
o|substituted constant variable: c1827 
o|substituted constant variable: r859613872 
o|substituted constant variable: r858213873 
o|substituted constant variable: c1843 
o|substituted constant variable: c1848 
o|substituted constant variable: s1850 
o|substituted constant variable: r869513877 
o|substituted constant variable: r867513878 
o|substituted constant variable: c1864 
o|substituted constant variable: c1869 
o|substituted constant variable: r877513887 
o|substituted constant variable: r875813888 
o|substituted constant variable: r874913889 
o|substituted constant variable: c1888 
o|substituted constant variable: c1893 
o|substituted constant variable: r890013894 
o|substituted constant variable: r885513895 
o|substituted constant variable: r884313896 
o|substituted constant variable: c1917 
o|substituted constant variable: c1922 
o|inlining procedure: k9021 
o|substituted constant variable: r906313905 
o|substituted constant variable: r897113906 
o|substituted constant variable: r895913907 
o|substituted constant variable: c1939 
o|substituted constant variable: c1944 
o|substituted constant variable: r909413914 
o|substituted constant variable: c1956 
o|substituted constant variable: r918313918 
o|substituted constant variable: r917413919 
o|substituted constant variable: c1981 
o|substituted constant variable: c1986 
o|substituted constant variable: c1994 
o|substituted constant variable: c2001 
o|substituted constant variable: r935513925 
o|substituted constant variable: r922713926 
o|substituted constant variable: c2017 
o|substituted constant variable: c2022 
o|substituted constant variable: r941313930 
o|substituted constant variable: r940113931 
o|substituted constant variable: c2057 
o|substituted constant variable: c2062 
o|substituted constant variable: c2067 
o|substituted constant variable: c2074 
o|substituted constant variable: c2079 
o|substituted constant variable: r965013939 
o|substituted constant variable: r950613940 
o|substituted constant variable: c2097 
o|substituted constant variable: c2102 
o|substituted constant variable: c2107 
o|substituted constant variable: r971013948 
o|substituted constant variable: r970113949 
o|substituted constant variable: c2119 
o|substituted constant variable: r979413956 
o|substituted constant variable: r1007713964 
o|substituted constant variable: mark2183 
o|substituted constant variable: r1006513965 
o|substituted constant variable: r1005613966 
o|substituted constant variable: r1004113967 
o|substituted constant variable: r1003013968 
o|substituted constant variable: r1028813979 
o|substituted constant variable: r1035713983 
o|substituted constant variable: r1035713984 
o|substituted constant variable: r1035113985 
o|substituted constant variable: r1040213987 
o|substituted constant variable: r1040213988 
o|substituted constant variable: r1042213991 
o|substituted constant variable: r1044313992 
o|substituted constant variable: r1044313993 
o|substituted constant variable: r1047213996 
o|substituted constant variable: r1049513997 
o|inlining procedure: k10503 
o|inlining procedure: k10503 
o|substituted constant variable: r1049513998 
o|substituted constant variable: r1061514005 
o|substituted constant variable: r1067214007 
o|substituted constant variable: c2469 
o|substituted constant variable: c2532 
o|substituted constant variable: p2533 
o|substituted constant variable: s2534 
o|substituted constant variable: c2492 
o|substituted constant variable: c2484 
o|substituted constant variable: p2485 
o|substituted constant variable: s2486 
o|substituted constant variable: c2393 
o|substituted constant variable: r1136214027 
o|inlining procedure: k11431 
o|inlining procedure: k11431 
o|substituted constant variable: r1145214036 
o|substituted constant variable: r1158714037 
o|substituted constant variable: r1161414040 
o|substituted constant variable: r1161414040 
o|folded constant expression: (length (quote ())) 
o|substituted constant variable: r1162114044 
o|substituted constant variable: r1162114044 
o|folded constant expression: (length (quote ())) 
o|substituted constant variable: r1156914046 
o|substituted constant variable: c2774 
o|substituted constant variable: p2775 
o|substituted constant variable: s2776 
o|substituted constant variable: c2946 
o|substituted constant variable: c2864 
o|substituted constant variable: c2874 
o|substituted constant variable: c2907 
o|substituted constant variable: p2908 
o|substituted constant variable: c2879 
o|substituted constant variable: c2884 
o|substituted constant variable: c2889 
o|substituted constant variable: c2898 
o|substituted constant variable: c2869 
o|substituted constant variable: p2870 
o|substituted constant variable: s2871 
o|substituted constant variable: c1267 
o|substituted constant variable: c1272 
o|substituted constant variable: c1279 
o|substituted constant variable: p1280 
o|substituted constant variable: c1284 
o|substituted constant variable: r1258214070 
o|substituted constant variable: r1257314071 
o|substituted constant variable: c1244 
o|substituted constant variable: c1249 
o|substituted constant variable: p1250 
o|substituted constant variable: r1270614073 
o|substituted constant variable: r1278914074 
o|substituted constant variable: c1222 
o|substituted constant variable: c1227 
o|substituted constant variable: r1292414077 
o|substituted constant variable: r1310314085 
o|substituted constant variable: r1312114087 
o|substituted constant variable: r1313314090 
o|substituted constant variable: r1310914091 
o|substituted constant variable: r1299114092 
o|substituted constant variable: r1291214093 
o|substituted constant variable: c1119 
o|substituted constant variable: r1324914096 
o|substituted constant variable: r1323714097 
o|substituted constant variable: c1099 
o|substituted constant variable: p1100 
o|substituted constant variable: r1339114101 
o|substituted constant variable: r1337914102 
o|substituted constant variable: r1336714103 
o|substituted constant variable: r1355114104 
o|simplifications: ((let . 2)) 
o|replaced variables: 163 
o|removed binding forms: 1869 
o|inlining procedure: k4076 
o|inlining procedure: k4257 
o|inlining procedure: k4221 
o|inlining procedure: k6138 
o|inlining procedure: k6433 
o|removed call to pure procedure with unused result: "(optimizer.scm:1044) slot" 
o|inlining procedure: k9143 
o|substituted constant variable: r104951399714194 
o|substituted constant variable: r104951399714197 
o|inlining procedure: k11606 
o|replaced variables: 319 
o|removed binding forms: 413 
o|substituted constant variable: r407714272 
o|substituted constant variable: r422214283 
o|substituted constant variable: r422214283 
o|substituted constant variable: r422214283 
o|contracted procedure: k8368 
o|substituted constant variable: r914414328 
o|substituted constant variable: r1160714347 
o|removed binding forms: 328 
o|removed conditional forms: 2 
o|inlining procedure: "(optimizer.scm:177) constant-node?166" 
o|removed binding forms: 5 
o|replaced variables: 1 
o|removed binding forms: 1 
o|simplifications: ((if . 36) (##core#call . 1260)) 
o|  call simplifications:
o|    ##sys#cons	9
o|    assoc
o|    -
o|    fx>
o|    ##sys#list	74
o|    list?	3
o|    set-car!
o|    >=
o|    symbol?
o|    cddddr
o|    fx<=
o|    <=
o|    fx<
o|    =	10
o|    equal?	4
o|    fixnum?
o|    fx=
o|    proper-list?	3
o|    >	5
o|    values	6
o|    ##sys#structure?
o|    *	2
o|    length	41
o|    <	5
o|    zero?	5
o|    sub1	5
o|    ##sys#call-with-values	5
o|    fourth	16
o|    +	8
o|    cddr	6
o|    list	144
o|    caddr	2
o|    cadr	4
o|    third	30
o|    ##sys#setslot	15
o|    apply	2
o|    caar	2
o|    assq	10
o|    alist-cons	10
o|    cdr	31
o|    add1	9
o|    set-cdr!	3
o|    null?	21
o|    ##sys#make-structure	99
o|    second	44
o|    first	94
o|    car	26
o|    eq?	142
o|    ##sys#check-list	21
o|    pair?	50
o|    ##sys#slot	190
o|    memq	14
o|    not	21
o|    cons	56
o|contracted procedure: k3762 
o|contracted procedure: k3772 
o|contracted procedure: k3795 
o|contracted procedure: k3807 
o|contracted procedure: k3817 
o|contracted procedure: k3821 
o|contracted procedure: k3832 
o|contracted procedure: k3840 
o|contracted procedure: k3848 
o|contracted procedure: k3854 
o|contracted procedure: k3857 
o|contracted procedure: k3874 
o|contracted procedure: k3881 
o|contracted procedure: k3895 
o|contracted procedure: k3891 
o|contracted procedure: k3901 
o|contracted procedure: k3921 
o|contracted procedure: k3927 
o|contracted procedure: k3933 
o|contracted procedure: k3957 
o|contracted procedure: k3960 
o|contracted procedure: k3966 
o|contracted procedure: k3975 
o|contracted procedure: k3978 
o|contracted procedure: k3981 
o|contracted procedure: k3999 
o|contracted procedure: k4020 
o|contracted procedure: k4027 
o|contracted procedure: k4046 
o|contracted procedure: k4091 
o|contracted procedure: k4103 
o|contracted procedure: k4113 
o|contracted procedure: k4117 
o|contracted procedure: k4082 
o|contracted procedure: k4076 
o|contracted procedure: k4120 
o|contracted procedure: k4156 
o|contracted procedure: k4186 
o|contracted procedure: k4198 
o|contracted procedure: k4212 
o|contracted procedure: k4201 
o|contracted procedure: k4208 
o|contracted procedure: k4233 
o|contracted procedure: k4251 
o|contracted procedure: k4254 
o|contracted procedure: k4274 
o|contracted procedure: k4270 
o|contracted procedure: k4257 
o|contracted procedure: k4278 
o|contracted procedure: k4282 
o|contracted procedure: k4286 
o|contracted procedure: k4295 
o|contracted procedure: k4298 
o|contracted procedure: k4310 
o|contracted procedure: k4313 
o|contracted procedure: k4316 
o|contracted procedure: k4324 
o|contracted procedure: k4332 
o|contracted procedure: k4346 
o|contracted procedure: k4355 
o|contracted procedure: k4370 
o|contracted procedure: k4378 
o|contracted procedure: k4384 
o|contracted procedure: k4394 
o|contracted procedure: k4404 
o|contracted procedure: k4171 
o|contracted procedure: k4419 
o|contracted procedure: k415614474 
o|contracted procedure: k4425 
o|contracted procedure: k4535 
o|contracted procedure: k4531 
o|contracted procedure: k4431 
o|contracted procedure: k4520 
o|contracted procedure: k4434 
o|contracted procedure: k4447 
o|contracted procedure: k4482 
o|contracted procedure: k4490 
o|contracted procedure: k4486 
o|contracted procedure: k4511 
o|contracted procedure: k4570 
o|contracted procedure: k4578 
o|contracted procedure: k4586 
o|contracted procedure: k4592 
o|contracted procedure: k4623 
o|contracted procedure: k4614 
o|contracted procedure: k4695 
o|contracted procedure: k4646 
o|contracted procedure: k4654 
o|contracted procedure: k4676 
o|contracted procedure: k4640 
o|contracted procedure: k4701 
o|contracted procedure: k4707 
o|contracted procedure: k4710 
o|contracted procedure: k4726 
o|contracted procedure: k4733 
o|contracted procedure: k4748 
o|contracted procedure: k4765 
o|contracted procedure: k4768 
o|contracted procedure: k4771 
o|contracted procedure: k4779 
o|contracted procedure: k4787 
o|contracted procedure: k4809 
o|contracted procedure: k4800 
o|contracted procedure: k4845 
o|contracted procedure: k4841 
o|contracted procedure: k4814 
o|contracted procedure: k4830 
o|contracted procedure: k4821 
o|contracted procedure: k4864 
o|contracted procedure: k4867 
o|contracted procedure: k4936 
o|contracted procedure: k4940 
o|contracted procedure: k4948 
o|contracted procedure: k4916 
o|contracted procedure: k4920 
o|contracted procedure: k4928 
o|contracted procedure: k4932 
o|contracted procedure: k4961 
o|contracted procedure: k5017 
o|contracted procedure: k5021 
o|contracted procedure: k5029 
o|contracted procedure: k4997 
o|contracted procedure: k5001 
o|contracted procedure: k5009 
o|contracted procedure: k5013 
o|contracted procedure: k5033 
o|contracted procedure: k5040 
o|contracted procedure: k5046 
o|contracted procedure: k5055 
o|contracted procedure: k5058 
o|contracted procedure: k5066 
o|contracted procedure: k5072 
o|contracted procedure: k6032 
o|contracted procedure: k5075 
o|contracted procedure: k5096 
o|contracted procedure: k5099 
o|contracted procedure: k5116 
o|contracted procedure: k5139 
o|contracted procedure: k5130 
o|contracted procedure: k5148 
o|contracted procedure: k5158 
o|contracted procedure: k5162 
o|contracted procedure: k5183 
o|contracted procedure: k5191 
o|contracted procedure: k5200 
o|contracted procedure: k5187 
o|contracted procedure: k5214 
o|contracted procedure: k5217 
o|contracted procedure: k5226 
o|contracted procedure: k5234 
o|contracted procedure: k5251 
o|contracted procedure: k5301 
o|contracted procedure: k5292 
o|contracted procedure: k5310 
o|contracted procedure: k5320 
o|contracted procedure: k5324 
o|contracted procedure: k5328 
o|contracted procedure: k5332 
o|contracted procedure: k5531 
o|contracted procedure: k5344 
o|contracted procedure: k5359 
o|contracted procedure: k5362 
o|contracted procedure: k5368 
o|contracted procedure: k5376 
o|contracted procedure: k5399 
o|contracted procedure: k5402 
o|contracted procedure: k5405 
o|contracted procedure: k5413 
o|contracted procedure: k5421 
o|contracted procedure: k5458 
o|contracted procedure: k5462 
o|contracted procedure: k5476 
o|contracted procedure: k5493 
o|contracted procedure: k5499 
o|contracted procedure: k5510 
o|contracted procedure: k5514 
o|contracted procedure: k5518 
o|contracted procedure: k5524 
o|contracted procedure: k5670 
o|contracted procedure: k5546 
o|contracted procedure: k5583 
o|contracted procedure: k5591 
o|contracted procedure: k5572 
o|contracted procedure: k5576 
o|contracted procedure: k5603 
o|contracted procedure: k5606 
o|contracted procedure: k5609 
o|contracted procedure: k5617 
o|contracted procedure: k5625 
o|contracted procedure: k5636 
o|contracted procedure: k5643 
o|contracted procedure: k5666 
o|contracted procedure: k5662 
o|contracted procedure: k5658 
o|contracted procedure: k5683 
o|contracted procedure: k5715 
o|contracted procedure: k5725 
o|contracted procedure: k5769 
o|contracted procedure: k5765 
o|contracted procedure: k5784 
o|contracted procedure: k5775 
o|contracted procedure: k5823 
o|contracted procedure: k5793 
o|contracted procedure: k5814 
o|contracted procedure: k5805 
o|contracted procedure: k5835 
o|contracted procedure: k5974 
o|contracted procedure: k5970 
o|contracted procedure: k5849 
o|contracted procedure: k5959 
o|contracted procedure: k5852 
o|contracted procedure: k5940 
o|contracted procedure: k5867 
o|contracted procedure: k5931 
o|contracted procedure: k5870 
o|contracted procedure: k5922 
o|contracted procedure: k6003 
o|contracted procedure: k5994 
o|contracted procedure: k6038 
o|contracted procedure: k6044 
o|contracted procedure: k6062 
o|contracted procedure: k6066 
o|contracted procedure: k6055 
o|contracted procedure: k6083 
o|contracted procedure: k6086 
o|contracted procedure: k6089 
o|contracted procedure: k6097 
o|contracted procedure: k6105 
o|contracted procedure: k6123 
o|contracted procedure: k6126 
o|contracted procedure: k6270 
o|contracted procedure: k6197 
o|contracted procedure: k6200 
o|contracted procedure: k6249 
o|contracted procedure: k6240 
o|contracted procedure: k6266 
o|contracted procedure: k6257 
o|contracted procedure: k6203 
o|contracted procedure: k6215 
o|contracted procedure: k6225 
o|contracted procedure: k6229 
o|contracted procedure: k6278 
o|contracted procedure: k6281 
o|contracted procedure: k6307 
o|contracted procedure: k6356 
o|contracted procedure: k6393 
o|contracted procedure: k6402 
o|contracted procedure: k6439 
o|contracted procedure: k6445 
o|contracted procedure: k6451 
o|contracted procedure: k6457 
o|contracted procedure: k6494 
o|contracted procedure: k6506 
o|contracted procedure: k6516 
o|contracted procedure: k6520 
o|contracted procedure: k6477 
o|contracted procedure: k6491 
o|propagated global variable: g928930 ##compiler#simplified-ops 
o|contracted procedure: k6523 
o|contracted procedure: k6551 
o|contracted procedure: k6567 
o|contracted procedure: k6575 
o|contracted procedure: k6811 
o|contracted procedure: k6807 
o|contracted procedure: k6578 
o|contracted procedure: k6751 
o|contracted procedure: k6593 
o|contracted procedure: k6742 
o|contracted procedure: k6596 
o|contracted procedure: k6604 
o|contracted procedure: k6613 
o|contracted procedure: k6700 
o|contracted procedure: k6625 
o|contracted procedure: k6635 
o|contracted procedure: k6655 
o|contracted procedure: k6651 
o|contracted procedure: k6691 
o|contracted procedure: k6666 
o|contracted procedure: k6682 
o|contracted procedure: k6673 
o|contracted procedure: k6723 
o|contracted procedure: k6706 
o|contracted procedure: k6718 
o|contracted procedure: k6726 
o|contracted procedure: k6733 
o|contracted procedure: k6788 
o|contracted procedure: k6760 
o|contracted procedure: k6783 
o|contracted procedure: k6766 
o|contracted procedure: k6778 
o|contracted procedure: k6817 
o|contracted procedure: k6820 
o|contracted procedure: k6832 
o|contracted procedure: k6842 
o|contracted procedure: k6846 
o|contracted procedure: k6867 
o|contracted procedure: k6870 
o|contracted procedure: k6873 
o|contracted procedure: k6920 
o|contracted procedure: k6916 
o|contracted procedure: k6894 
o|contracted procedure: k6897 
o|contracted procedure: k6903 
o|contracted procedure: k6926 
o|contracted procedure: k6990 
o|contracted procedure: k6964 
o|contracted procedure: k6948 
o|contracted procedure: k6956 
o|contracted procedure: k6986 
o|contracted procedure: k6998 
o|contracted procedure: k7005 
o|contracted procedure: k7033 
o|contracted procedure: k7029 
o|contracted procedure: k7050 
o|contracted procedure: k7065 
o|contracted procedure: k7220 
o|contracted procedure: k7080 
o|contracted procedure: k7083 
o|contracted procedure: k7093 
o|contracted procedure: k7113 
o|contracted procedure: k7109 
o|contracted procedure: k7105 
o|contracted procedure: k7131 
o|contracted procedure: k7144 
o|contracted procedure: k7135 
o|contracted procedure: k7163 
o|contracted procedure: k7180 
o|contracted procedure: k7192 
o|contracted procedure: k7188 
o|contracted procedure: k7184 
o|contracted procedure: k7176 
o|contracted procedure: k7167 
o|contracted procedure: k7199 
o|contracted procedure: k7214 
o|contracted procedure: k7210 
o|contracted procedure: k7206 
o|contracted procedure: k7229 
o|contracted procedure: k7239 
o|contracted procedure: k7243 
o|contracted procedure: k7252 
o|contracted procedure: k7262 
o|contracted procedure: k7266 
o|contracted procedure: k7300 
o|contracted procedure: k7275 
o|contracted procedure: k7285 
o|contracted procedure: k7289 
o|contracted procedure: k7293 
o|contracted procedure: k7297 
o|contracted procedure: k7348 
o|contracted procedure: k7312 
o|contracted procedure: k7338 
o|contracted procedure: k7342 
o|contracted procedure: k7334 
o|contracted procedure: k7315 
o|contracted procedure: k7318 
o|contracted procedure: k7326 
o|contracted procedure: k7330 
o|contracted procedure: k7364 
o|contracted procedure: k7375 
o|contracted procedure: k7384 
o|contracted procedure: k7399 
o|contracted procedure: k7415 
o|contracted procedure: k7422 
o|contracted procedure: k7464 
o|contracted procedure: k7496 
o|contracted procedure: k7517 
o|contracted procedure: k7513 
o|contracted procedure: k7509 
o|contracted procedure: k7500 
o|contracted procedure: k7604 
o|contracted procedure: k7608 
o|contracted procedure: k7520 
o|contracted procedure: k7523 
o|contracted procedure: k7526 
o|contracted procedure: k7600 
o|contracted procedure: k7532 
o|contracted procedure: k7591 
o|contracted procedure: k7538 
o|contracted procedure: k7573 
o|contracted procedure: k7582 
o|contracted procedure: k7544 
o|contracted procedure: k7556 
o|contracted procedure: k7560 
o|contracted procedure: k7614 
o|contracted procedure: k7682 
o|contracted procedure: k7686 
o|contracted procedure: k7623 
o|contracted procedure: k7640 
o|contracted procedure: k7643 
o|contracted procedure: k7646 
o|contracted procedure: k7658 
o|contracted procedure: k7675 
o|contracted procedure: k7671 
o|contracted procedure: k7662 
o|contracted procedure: k7692 
o|contracted procedure: k7778 
o|contracted procedure: k7712 
o|contracted procedure: k7733 
o|contracted procedure: k7737 
o|contracted procedure: k7754 
o|contracted procedure: k7758 
o|contracted procedure: k7750 
o|contracted procedure: k7771 
o|contracted procedure: k7784 
o|contracted procedure: k7854 
o|contracted procedure: k7796 
o|contracted procedure: k7849 
o|contracted procedure: k7819 
o|contracted procedure: k7831 
o|contracted procedure: k7839 
o|contracted procedure: k7823 
o|contracted procedure: k7843 
o|contracted procedure: k7860 
o|contracted procedure: k7946 
o|contracted procedure: k7880 
o|contracted procedure: k7886 
o|contracted procedure: k7889 
o|contracted procedure: k7892 
o|contracted procedure: k7904 
o|contracted procedure: k7921 
o|contracted procedure: k7929 
o|contracted procedure: k7925 
o|contracted procedure: k7917 
o|contracted procedure: k7908 
o|contracted procedure: k7952 
o|contracted procedure: k7958 
o|contracted procedure: k7961 
o|contracted procedure: k8038 
o|contracted procedure: k7970 
o|contracted procedure: k7993 
o|contracted procedure: k8010 
o|contracted procedure: k8031 
o|contracted procedure: k8027 
o|contracted procedure: k8023 
o|contracted procedure: k8014 
o|contracted procedure: k8006 
o|contracted procedure: k7997 
o|contracted procedure: k8044 
o|contracted procedure: k8050 
o|contracted procedure: k8053 
o|contracted procedure: k8126 
o|contracted procedure: k8062 
o|contracted procedure: k8085 
o|contracted procedure: k8122 
o|contracted procedure: k8102 
o|contracted procedure: k8098 
o|contracted procedure: k8089 
o|contracted procedure: k8110 
o|contracted procedure: k8118 
o|contracted procedure: k8134 
o|contracted procedure: k8151 
o|contracted procedure: k8160 
o|contracted procedure: k8403 
o|contracted procedure: k8180 
o|contracted procedure: k8192 
o|contracted procedure: k8196 
o|contracted procedure: k8212 
o|contracted procedure: k8223 
o|contracted procedure: k8226 
o|contracted procedure: k8247 
o|contracted procedure: k8251 
o|contracted procedure: k8264 
o|contracted procedure: k8297 
o|contracted procedure: k8294 
o|contracted procedure: k8272 
o|contracted procedure: k8268 
o|contracted procedure: k8260 
o|contracted procedure: k8290 
o|contracted procedure: k8312 
o|contracted procedure: k8315 
o|contracted procedure: k8318 
o|contracted procedure: k8326 
o|contracted procedure: k8334 
o|contracted procedure: k8346 
o|contracted procedure: k8349 
o|contracted procedure: k8352 
o|contracted procedure: k8360 
o|contracted procedure: k8389 
o|contracted procedure: k8374 
o|contracted procedure: k8383 
o|contracted procedure: k8399 
o|contracted procedure: k8410 
o|contracted procedure: k8419 
o|contracted procedure: k8422 
o|contracted procedure: k8436 
o|contracted procedure: k8454 
o|contracted procedure: k8466 
o|contracted procedure: k8458 
o|contracted procedure: k8477 
o|contracted procedure: k8484 
o|contracted procedure: k8493 
o|contracted procedure: k8503 
o|contracted procedure: k8512 
o|contracted procedure: k8515 
o|contracted procedure: k8533 
o|contracted procedure: k8563 
o|contracted procedure: k8548 
o|contracted procedure: k8570 
o|contracted procedure: k8578 
o|contracted procedure: k8598 
o|contracted procedure: k8601 
o|contracted procedure: k8604 
o|contracted procedure: k8662 
o|contracted procedure: k8610 
o|contracted procedure: k8616 
o|contracted procedure: k8628 
o|contracted procedure: k8632 
o|contracted procedure: k8644 
o|contracted procedure: k8668 
o|contracted procedure: k8688 
o|contracted procedure: k8691 
o|contracted procedure: k8700 
o|contracted procedure: k8729 
o|contracted procedure: k8725 
o|contracted procedure: k8732 
o|contracted procedure: k8745 
o|contracted procedure: k8826 
o|contracted procedure: k8830 
o|contracted procedure: k8754 
o|contracted procedure: k8771 
o|contracted procedure: k8777 
o|contracted procedure: k8780 
o|contracted procedure: k8792 
o|contracted procedure: k8805 
o|contracted procedure: k8796 
o|contracted procedure: k8836 
o|contracted procedure: k8934 
o|contracted procedure: k8845 
o|contracted procedure: k8851 
o|contracted procedure: k8926 
o|contracted procedure: k8868 
o|contracted procedure: k8896 
o|contracted procedure: k8880 
o|contracted procedure: k8922 
o|contracted procedure: k8902 
o|contracted procedure: k8914 
o|contracted procedure: k8918 
o|contracted procedure: k8940 
o|contracted procedure: k8943 
o|contracted procedure: k8946 
o|contracted procedure: k8949 
o|contracted procedure: k8952 
o|contracted procedure: k8964 
o|contracted procedure: k8967 
o|contracted procedure: k8984 
o|contracted procedure: k8996 
o|contracted procedure: k9009 
o|contracted procedure: k9000 
o|contracted procedure: k9024 
o|inlining procedure: k9021 
o|contracted procedure: k9033 
o|contracted procedure: k9046 
o|contracted procedure: k9042 
o|inlining procedure: k9021 
o|contracted procedure: k9049 
o|contracted procedure: k9056 
o|contracted procedure: k9081 
o|contracted procedure: k9074 
o|contracted procedure: k9087 
o|contracted procedure: k9160 
o|contracted procedure: k9164 
o|contracted procedure: k9096 
o|contracted procedure: k9119 
o|contracted procedure: k9136 
o|contracted procedure: k9132 
o|contracted procedure: k9123 
o|contracted procedure: k9156 
o|contracted procedure: k9143 
o|contracted procedure: k9170 
o|contracted procedure: k9179 
o|contracted procedure: k9202 
o|contracted procedure: k9206 
o|contracted procedure: k9214 
o|contracted procedure: k9220 
o|contracted procedure: k9237 
o|contracted procedure: k9240 
o|contracted procedure: k9249 
o|contracted procedure: k9261 
o|contracted procedure: k9265 
o|contracted procedure: k9348 
o|contracted procedure: k9275 
o|contracted procedure: k9287 
o|contracted procedure: k9291 
o|contracted procedure: k9299 
o|contracted procedure: k9302 
o|contracted procedure: k9314 
o|contracted procedure: k9318 
o|contracted procedure: k9337 
o|contracted procedure: k9341 
o|contracted procedure: k9382 
o|contracted procedure: k9357 
o|contracted procedure: k9373 
o|contracted procedure: k9364 
o|contracted procedure: k9394 
o|contracted procedure: k9397 
o|contracted procedure: k9403 
o|contracted procedure: k9406 
o|contracted procedure: k9415 
o|contracted procedure: k9438 
o|contracted procedure: k9491 
o|contracted procedure: k9455 
o|contracted procedure: k9451 
o|contracted procedure: k9442 
o|contracted procedure: k9469 
o|contracted procedure: k9479 
o|contracted procedure: k9487 
o|contracted procedure: k9499 
o|contracted procedure: k9516 
o|contracted procedure: k9522 
o|contracted procedure: k9534 
o|contracted procedure: k9546 
o|contracted procedure: k9550 
o|contracted procedure: k9643 
o|contracted procedure: k9560 
o|contracted procedure: k9572 
o|contracted procedure: k9576 
o|contracted procedure: k9590 
o|contracted procedure: k9594 
o|contracted procedure: k9607 
o|contracted procedure: k9619 
o|contracted procedure: k9623 
o|contracted procedure: k9635 
o|contracted procedure: k9639 
o|contracted procedure: k9677 
o|contracted procedure: k9652 
o|contracted procedure: k9668 
o|contracted procedure: k9659 
o|contracted procedure: k9688 
o|contracted procedure: k9691 
o|contracted procedure: k9694 
o|contracted procedure: k9697 
o|contracted procedure: k9706 
o|contracted procedure: k9723 
o|contracted procedure: k9726 
o|contracted procedure: k9738 
o|contracted procedure: k9742 
o|contracted procedure: k9749 
o|contracted procedure: k9761 
o|contracted procedure: k9781 
o|contracted procedure: k9777 
o|contracted procedure: k9787 
o|contracted procedure: k9804 
o|contracted procedure: k9920 
o|contracted procedure: k9810 
o|contracted procedure: k9916 
o|contracted procedure: k9822 
o|contracted procedure: k9854 
o|contracted procedure: k9863 
o|contracted procedure: k9869 
o|contracted procedure: k9886 
o|contracted procedure: k7431 
o|contracted procedure: k7447 
o|contracted procedure: k7453 
o|contracted procedure: k9892 
o|contracted procedure: k9899 
o|contracted procedure: k9909 
o|contracted procedure: k9985 
o|contracted procedure: k9993 
o|contracted procedure: k10001 
o|contracted procedure: k10007 
o|contracted procedure: k10010 
o|contracted procedure: k10026 
o|contracted procedure: k10043 
o|contracted procedure: k10067 
o|contracted procedure: k10098 
o|contracted procedure: k10102 
o|contracted procedure: k10079 
o|contracted procedure: k10086 
o|contracted procedure: k10090 
o|contracted procedure: k10094 
o|contracted procedure: k10124 
o|contracted procedure: k10115 
o|contracted procedure: k10134 
o|contracted procedure: k10141 
o|contracted procedure: k10145 
o|contracted procedure: k10151 
o|contracted procedure: k10161 
o|contracted procedure: k10165 
o|contracted procedure: k10169 
o|contracted procedure: k10177 
o|contracted procedure: k10189 
o|contracted procedure: k10199 
o|contracted procedure: k10203 
o|contracted procedure: k10223 
o|contracted procedure: k10231 
o|contracted procedure: k10239 
o|contracted procedure: k10245 
o|contracted procedure: k10248 
o|contracted procedure: k10251 
o|contracted procedure: k10274 
o|contracted procedure: k10257 
o|contracted procedure: k10270 
o|contracted procedure: k10284 
o|contracted procedure: k10294 
o|contracted procedure: k10301 
o|contracted procedure: k10308 
o|contracted procedure: k10318 
o|contracted procedure: k10341 
o|contracted procedure: k10328 
o|contracted procedure: k10347 
o|contracted procedure: k10359 
o|contracted procedure: k10363 
o|contracted procedure: k10371 
o|contracted procedure: k10377 
o|contracted procedure: k10386 
o|contracted procedure: k10408 
o|contracted procedure: k10412 
o|contracted procedure: k10418 
o|contracted procedure: k10427 
o|contracted procedure: k10449 
o|contracted procedure: k10453 
o|contracted procedure: k10459 
o|contracted procedure: k10462 
o|contracted procedure: k10554 
o|contracted procedure: k10468 
o|contracted procedure: k10545 
o|contracted procedure: k10474 
o|contracted procedure: k10491 
o|contracted procedure: k10497 
o|contracted procedure: k10500 
o|contracted procedure: k10533 
o|contracted procedure: k10507 
o|contracted procedure: k10524 
o|contracted procedure: k10515 
o|contracted procedure: k10511 
o|contracted procedure: k10560 
o|contracted procedure: k10563 
o|contracted procedure: k10566 
o|contracted procedure: k10579 
o|contracted procedure: k10594 
o|contracted procedure: k10601 
o|contracted procedure: k10605 
o|contracted procedure: k10611 
o|contracted procedure: k10624 
o|contracted procedure: k10632 
o|contracted procedure: k10636 
o|contracted procedure: k10696 
o|contracted procedure: k11378 
o|contracted procedure: k10699 
o|contracted procedure: k10705 
o|contracted procedure: k10721 
o|contracted procedure: k10732 
o|contracted procedure: k10740 
o|contracted procedure: k10754 
o|contracted procedure: k10767 
o|contracted procedure: k10771 
o|contracted procedure: k10763 
o|contracted procedure: k10750 
o|contracted procedure: k10791 
o|contracted procedure: k10787 
o|contracted procedure: k10779 
o|contracted procedure: k10803 
o|contracted procedure: k10811 
o|contracted procedure: k10869 
o|contracted procedure: k10879 
o|contracted procedure: k10883 
o|contracted procedure: k10825 
o|contracted procedure: k10840 
o|contracted procedure: k10849 
o|contracted procedure: k10853 
o|contracted procedure: k10956 
o|contracted procedure: k10898 
o|contracted procedure: k10950 
o|contracted procedure: k10902 
o|contracted procedure: k10923 
o|contracted procedure: k10932 
o|contracted procedure: k10941 
o|contracted procedure: k10914 
o|contracted procedure: k10905 
o|contracted procedure: k10968 
o|contracted procedure: k10978 
o|contracted procedure: k10982 
o|contracted procedure: k10992 
o|contracted procedure: k10996 
o|contracted procedure: k11348 
o|contracted procedure: k11000 
o|contracted procedure: k11011 
o|contracted procedure: k11019 
o|contracted procedure: k11027 
o|contracted procedure: k11033 
o|contracted procedure: k11036 
o|contracted procedure: k11039 
o|contracted procedure: k11047 
o|contracted procedure: k11055 
o|contracted procedure: k11248 
o|contracted procedure: k11061 
o|contracted procedure: k11239 
o|contracted procedure: k11067 
o|contracted procedure: k11071 
o|contracted procedure: k11213 
o|contracted procedure: k11077 
o|contracted procedure: k11093 
o|contracted procedure: k11097 
o|contracted procedure: k11108 
o|contracted procedure: k11100 
o|contracted procedure: k11113 
o|contracted procedure: k11121 
o|contracted procedure: k11201 
o|contracted procedure: k11124 
o|contracted procedure: k11156 
o|contracted procedure: k11160 
o|contracted procedure: k11152 
o|contracted procedure: k11143 
o|contracted procedure: k11177 
o|contracted procedure: k11168 
o|contracted procedure: k11192 
o|contracted procedure: k11188 
o|contracted procedure: k11180 
o|contracted procedure: k11219 
o|contracted procedure: k11254 
o|contracted procedure: k11257 
o|contracted procedure: k11260 
o|contracted procedure: k11266 
o|contracted procedure: k11270 
o|contracted procedure: k11280 
o|contracted procedure: k11292 
o|contracted procedure: k11302 
o|contracted procedure: k11306 
o|contracted procedure: k11309 
o|contracted procedure: k11321 
o|contracted procedure: k11331 
o|contracted procedure: k11335 
o|contracted procedure: k11358 
o|contracted procedure: k11364 
o|contracted procedure: k11371 
o|contracted procedure: k11381 
o|contracted procedure: k11403 
o|contracted procedure: k11428 
o|contracted procedure: k11444 
o|contracted procedure: k11436 
o|contracted procedure: k11440 
o|contracted procedure: k11490 
o|contracted procedure: k11498 
o|contracted procedure: k11506 
o|contracted procedure: k11512 
o|contracted procedure: k11515 
o|contracted procedure: k11518 
o|contracted procedure: k11521 
o|contracted procedure: k11535 
o|contracted procedure: k11545 
o|contracted procedure: k11552 
o|contracted procedure: k11565 
o|contracted procedure: k11656 
o|contracted procedure: k11571 
o|contracted procedure: k11647 
o|contracted procedure: k11574 
o|contracted procedure: k11638 
o|contracted procedure: k11577 
o|contracted procedure: k11629 
o|contracted procedure: k11583 
o|contracted procedure: k11595 
o|contracted procedure: k11479 
o|contracted procedure: k11454 
o|contracted procedure: k11470 
o|contracted procedure: k11461 
o|contracted procedure: k11606 
o|contracted procedure: k11671 
o|contracted procedure: k11677 
o|contracted procedure: k11680 
o|contracted procedure: k11687 
o|contracted procedure: k11710 
o|contracted procedure: k11728 
o|contracted procedure: k11740 
o|contracted procedure: k11750 
o|contracted procedure: k11754 
o|contracted procedure: k11774 
o|contracted procedure: k11784 
o|contracted procedure: k11901 
o|contracted procedure: k11789 
o|contracted procedure: k11892 
o|contracted procedure: k11792 
o|contracted procedure: k11800 
o|contracted procedure: k11803 
o|contracted procedure: k11806 
o|contracted procedure: k11809 
o|contracted procedure: k11849 
o|contracted procedure: k11821 
o|contracted procedure: k11825 
o|contracted procedure: k11840 
o|contracted procedure: k11858 
o|contracted procedure: k11861 
o|contracted procedure: k11864 
o|contracted procedure: k11872 
o|contracted procedure: k11880 
o|contracted procedure: k11904 
o|contracted procedure: k11932 
o|contracted procedure: k12007 
o|contracted procedure: k11935 
o|contracted procedure: k11956 
o|contracted procedure: k11947 
o|contracted procedure: k11976 
o|contracted procedure: k11984 
o|contracted procedure: k11998 
o|contracted procedure: k11988 
o|contracted procedure: k12010 
o|contracted procedure: k12022 
o|contracted procedure: k12032 
o|contracted procedure: k12036 
o|contracted procedure: k12040 
o|contracted procedure: k12052 
o|contracted procedure: k12062 
o|contracted procedure: k12066 
o|contracted procedure: k12369 
o|contracted procedure: k12072 
o|contracted procedure: k12097 
o|contracted procedure: k12110 
o|contracted procedure: k12123 
o|contracted procedure: k12179 
o|contracted procedure: k12196 
o|contracted procedure: k12316 
o|contracted procedure: k12213 
o|contracted procedure: k12209 
o|contracted procedure: k12200 
o|contracted procedure: k12192 
o|contracted procedure: k12183 
o|contracted procedure: k12136 
o|contracted procedure: k12145 
o|contracted procedure: k12127 
o|contracted procedure: k12119 
o|contracted procedure: k12101 
o|contracted procedure: k12093 
o|contracted procedure: k12165 
o|contracted procedure: k12221 
o|contracted procedure: k12238 
o|contracted procedure: k12229 
o|contracted procedure: k12256 
o|contracted procedure: k12265 
o|contracted procedure: k12304 
o|contracted procedure: k12280 
o|contracted procedure: k12284 
o|contracted procedure: k12300 
o|contracted procedure: k12308 
o|contracted procedure: k12360 
o|contracted procedure: k12327 
o|contracted procedure: k12351 
o|contracted procedure: k12330 
o|contracted procedure: k12342 
o|contracted procedure: k12373 
o|contracted procedure: k12385 
o|contracted procedure: k12407 
o|contracted procedure: k12403 
o|contracted procedure: k12388 
o|contracted procedure: k12391 
o|contracted procedure: k12399 
o|contracted procedure: k12418 
o|contracted procedure: k12428 
o|contracted procedure: k12440 
o|contracted procedure: k12452 
o|contracted procedure: k12455 
o|contracted procedure: k12458 
o|contracted procedure: k12466 
o|contracted procedure: k12474 
o|contracted procedure: k12437 
o|contracted procedure: k12486 
o|contracted procedure: k12489 
o|contracted procedure: k12492 
o|contracted procedure: k12500 
o|contracted procedure: k12508 
o|contracted procedure: k12514 
o|contracted procedure: k12524 
o|contracted procedure: k12533 
o|contracted procedure: k12543 
o|contracted procedure: k12547 
o|contracted procedure: k12758 
o|contracted procedure: k12754 
o|contracted procedure: k12738 
o|contracted procedure: k12750 
o|contracted procedure: k12746 
o|contracted procedure: k12742 
o|contracted procedure: k12695 
o|contracted procedure: k12699 
o|contracted procedure: k12734 
o|contracted procedure: k12730 
o|contracted procedure: k12717 
o|contracted procedure: k12551 
o|contracted procedure: k12683 
o|contracted procedure: k12691 
o|contracted procedure: k12687 
o|contracted procedure: k12679 
o|contracted procedure: k12559 
o|contracted procedure: k12563 
o|contracted procedure: k12569 
o|contracted procedure: k12578 
o|contracted procedure: k12675 
o|contracted procedure: k12584 
o|contracted procedure: k12671 
o|contracted procedure: k12590 
o|contracted procedure: k12602 
o|contracted procedure: k12619 
o|contracted procedure: k12615 
o|contracted procedure: k12606 
o|contracted procedure: k12655 
o|contracted procedure: k12647 
o|contracted procedure: k12638 
o|contracted procedure: k12555 
o|contracted procedure: k13439 
o|contracted procedure: k13503 
o|contracted procedure: k13519 
o|contracted procedure: k13507 
o|contracted procedure: k13515 
o|contracted procedure: k13511 
o|contracted procedure: k13443 
o|contracted procedure: k13499 
o|contracted procedure: k13451 
o|contracted procedure: k13459 
o|contracted procedure: k13479 
o|contracted procedure: k13495 
o|contracted procedure: k13483 
o|contracted procedure: k13491 
o|contracted procedure: k13487 
o|contracted procedure: k13463 
o|contracted procedure: k13475 
o|contracted procedure: k13471 
o|contracted procedure: k13467 
o|contracted procedure: k13455 
o|contracted procedure: k13447 
o|contracted procedure: k13356 
o|contracted procedure: k13360 
o|contracted procedure: k13369 
o|contracted procedure: k13431 
o|contracted procedure: k13387 
o|contracted procedure: k13422 
o|contracted procedure: k13393 
o|contracted procedure: k13405 
o|contracted procedure: k12762 
o|contracted procedure: k13292 
o|contracted procedure: k13336 
o|contracted procedure: k13352 
o|contracted procedure: k13340 
o|contracted procedure: k13348 
o|contracted procedure: k13344 
o|contracted procedure: k13296 
o|contracted procedure: k13332 
o|contracted procedure: k13304 
o|contracted procedure: k13316 
o|contracted procedure: k13328 
o|contracted procedure: k13324 
o|contracted procedure: k13320 
o|contracted procedure: k13312 
o|contracted procedure: k13308 
o|contracted procedure: k13300 
o|contracted procedure: k13226 
o|contracted procedure: k13230 
o|contracted procedure: k13239 
o|contracted procedure: k13284 
o|contracted procedure: k13251 
o|contracted procedure: k13279 
o|contracted procedure: k13263 
o|contracted procedure: k12766 
o|contracted procedure: k13218 
o|contracted procedure: k13222 
o|contracted procedure: k12867 
o|contracted procedure: k12871 
o|contracted procedure: k12881 
o|contracted procedure: k12892 
o|contracted procedure: k12900 
o|contracted procedure: k12908 
o|contracted procedure: k12914 
o|contracted procedure: k13214 
o|contracted procedure: k12920 
o|contracted procedure: k12935 
o|contracted procedure: k12943 
o|contracted procedure: k12951 
o|contracted procedure: k12959 
o|contracted procedure: k12965 
o|contracted procedure: k12972 
o|contracted procedure: k12976 
o|contracted procedure: k12984 
o|contracted procedure: k12993 
o|contracted procedure: k13192 
o|contracted procedure: k12999 
o|contracted procedure: k13188 
o|contracted procedure: k13006 
o|contracted procedure: k13012 
o|contracted procedure: k13023 
o|contracted procedure: k13031 
o|contracted procedure: k13039 
o|contracted procedure: k13077 
o|contracted procedure: k13073 
o|contracted procedure: k13064 
o|contracted procedure: k13052 
o|contracted procedure: k13056 
o|contracted procedure: k13060 
o|contracted procedure: k13083 
o|contracted procedure: k13105 
o|contracted procedure: k13184 
o|contracted procedure: k13111 
o|contracted procedure: k13129 
o|contracted procedure: k13168 
o|contracted procedure: k13164 
o|contracted procedure: k13135 
o|contracted procedure: k13153 
o|contracted procedure: k13144 
o|contracted procedure: k12770 
o|contracted procedure: k12839 
o|contracted procedure: k12863 
o|contracted procedure: k12859 
o|contracted procedure: k12843 
o|contracted procedure: k12855 
o|contracted procedure: k12851 
o|contracted procedure: k12847 
o|contracted procedure: k12778 
o|contracted procedure: k12782 
o|contracted procedure: k12835 
o|contracted procedure: k12827 
o|contracted procedure: k12797 
o|contracted procedure: k12822 
o|contracted procedure: k12818 
o|contracted procedure: k12809 
o|contracted procedure: k12774 
o|contracted procedure: k13617 
o|contracted procedure: k13609 
o|contracted procedure: k13613 
o|contracted procedure: k13605 
o|contracted procedure: k13601 
o|contracted procedure: k13527 
o|contracted procedure: k13531 
o|contracted procedure: k13544 
o|contracted procedure: k13553 
o|contracted procedure: k13564 
o|contracted procedure: k13578 
o|contracted procedure: k13574 
o|contracted procedure: k13567 
o|contracted procedure: k13582 
o|contracted procedure: k13594 
o|contracted procedure: k13523 
o|simplifications: ((let . 122)) 
o|removed binding forms: 1123 
o|inlining procedure: k5640 
o|inlining procedure: k9746 
o|inlining procedure: k9746 
o|replaced variables: 273 
o|removed binding forms: 1 
o|simplifications: ((if . 1)) 
o|replaced variables: 3 
o|removed binding forms: 184 
o|contracted procedure: k4390 
o|contracted procedure: k4407 
o|contracted procedure: k12470 
o|removed binding forms: 4 
o|direct leaf routine/allocation: touch30 0 
o|direct leaf routine/allocation: touch168 0 
o|direct leaf routine/allocation: for-each-loop188206 0 
o|direct leaf routine/allocation: g231240 0 
o|direct leaf routine/allocation: touch961 0 
o|direct leaf routine/allocation: close2560 6 
o|direct leaf routine/allocation: g10681069 10 
o|contracted procedure: "(optimizer.scm:76) k3910" 
o|converted assignments to bindings: (for-each-loop188206) 
o|contracted procedure: "(optimizer.scm:162) k4260" 
o|contracted procedure: "(optimizer.scm:162) k426014280" 
o|contracted procedure: "(optimizer.scm:156) k4328" 
o|contracted procedure: "(optimizer.scm:179) k4397" 
o|contracted procedure: "(optimizer.scm:202) k4467" 
o|contracted procedure: "(optimizer.scm:232) k4604" 
o|contracted procedure: "(optimizer.scm:236) k4636" 
o|contracted procedure: "(optimizer.scm:254) k4722" 
o|contracted procedure: "(optimizer.scm:274) k4901" 
o|contracted procedure: "(optimizer.scm:290) k4982" 
o|contracted procedure: "(optimizer.scm:325) k5108" 
o|contracted procedure: "(optimizer.scm:392) k5285" 
o|contracted procedure: "(optimizer.scm:399) k5365" 
o|contracted procedure: "(optimizer.scm:408) k5437" 
o|contracted procedure: "(optimizer.scm:474) k6135" 
o|contracted procedure: "(optimizer.scm:479) k6161" 
o|contracted procedure: "(optimizer.scm:486) k6178" 
o|contracted procedure: "(optimizer.scm:1636) k11555" 
o|contracted procedure: "(optimizer.scm:1649) k11720" 
o|simplifications: ((let . 1)) 
o|removed binding forms: 20 
o|replaced variables: 4 
o|removed binding forms: 2 
o|customizable procedures: (loop1060 k13045 loop21168 loop11128 g26882695 for-each-loop26872965 g27122721 map-loop27062779 map-loop27902810 map-loop28212838 k12078 loop2893 descend2845 g29152922 for-each-loop29142958 g29292936 for-each-loop29282953 map-loop27402757 g26622669 for-each-loop26612679 k11527 k11602 k11589 k11541 walk2562 tmp13627 k10711 for-each-loop24302440 for-each-loop24132423 g23802381 g24522459 for-each-loop24512475 for-each-loop25152536 k10477 k10430 k10389 rec2214 g21922199 for-each-loop21912202 scan2148 walk2147 transform2149 k7440 loop2130 k9525 k9140 k9013 k8809 k8712 k8536 k8206 k8209 map-loop16951713 map-loop17231740 k7715 k7478 k7390 argc-ok?1485 map-loop12951314 g13271349 for-each-loop13261354 g13671374 for-each-loop13661382 g13911398 for-each-loop13901408 k7089 find-path1335 find1338 g972979 for-each-loop9711039 test962 k6590 k6610 k6622 k6631 for-each-loop921933 k6387 lp901 k6284 k6175 for-each-loop876888 g810819 map-loop804829 k5088 k5882 k5168 k5206 k5240 k5537 g742751 map-loop736766 loop656 g677686 map-loop671696 invalidate-gae!169 g620627 for-each-loop619637 g503510 for-each-loop502520 walk-generic174 k4719 k4736 g403412 map-loop397422 g354355 k4660 test165 g314315 replace-var172 walk1173 k4459 walk171 map-loop225243 simplify170 for-each-loop110141 k3904 k4005 mark28 remember29 scan-each31 k3877 k3860 g4350 for-each-loop4253 scan32 k3758) 
o|calls to known targets: 393 
o|identified direct recursive calls: f_4193 1 
o|identified direct recursive calls: f_4305 1 
o|identified direct recursive calls: f_7307 1 
o|identified direct recursive calls: f_9858 1 
o|identified direct recursive calls: f_9978 2 
o|identified direct recursive calls: f_10216 2 
o|unused rest argument: _2952 f_11992 
o|unused rest argument: _2910 f_12173 
o|identified direct recursive calls: f_12380 1 
o|unused rest argument: _2818 f_12422 
o|identified direct recursive calls: f_12447 1 
o|fast box initializations: 64 
o|dropping unused closure argument: f_4179 
o|dropping unused closure argument: f_4193 
*/
/* end of file */
