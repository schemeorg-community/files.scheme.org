/* Generated from support.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:51
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: support.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -extend private-namespace.scm -no-trace -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[568];
static double C_possibly_force_alignment;


#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
C_regparm static C_word C_fcall stub3725(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from k5678 */
C_regparm static C_word C_fcall stub346(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k5671 */
C_regparm static C_word C_fcall stub341(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(f_6991)
static void C_ccall f_6991(C_word c,C_word *av) C_noret;
C_noret_decl(f_5780)
static void C_ccall f_5780(C_word c,C_word *av) C_noret;
C_noret_decl(f_7499)
static void C_ccall f_7499(C_word c,C_word *av) C_noret;
C_noret_decl(f_7497)
static void C_ccall f_7497(C_word c,C_word *av) C_noret;
C_noret_decl(f_14574)
static void C_ccall f_14574(C_word c,C_word *av) C_noret;
C_noret_decl(f_14576)
static void C_ccall f_14576(C_word c,C_word *av) C_noret;
C_noret_decl(f_14570)
static void C_ccall f_14570(C_word c,C_word *av) C_noret;
C_noret_decl(f_12826)
static void C_ccall f_12826(C_word c,C_word *av) C_noret;
C_noret_decl(f_15118)
static void C_ccall f_15118(C_word c,C_word *av) C_noret;
C_noret_decl(f_15112)
static void C_ccall f_15112(C_word c,C_word *av) C_noret;
C_noret_decl(f_15184)
static void C_ccall f_15184(C_word c,C_word *av) C_noret;
C_noret_decl(f_6948)
static void C_fcall f_6948(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12840)
static void C_fcall f_12840(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8607)
static void C_ccall f_8607(C_word c,C_word *av) C_noret;
C_noret_decl(f_8600)
static void C_ccall f_8600(C_word c,C_word *av) C_noret;
C_noret_decl(f_15171)
static void C_ccall f_15171(C_word c,C_word *av) C_noret;
C_noret_decl(f_6954)
static void C_ccall f_6954(C_word c,C_word *av) C_noret;
C_noret_decl(f_12832)
static void C_ccall f_12832(C_word c,C_word *av) C_noret;
C_noret_decl(f_12836)
static void C_ccall f_12836(C_word c,C_word *av) C_noret;
C_noret_decl(f_7899)
static void C_ccall f_7899(C_word c,C_word *av) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word *av) C_noret;
C_noret_decl(f_12865)
static void C_ccall f_12865(C_word c,C_word *av) C_noret;
C_noret_decl(f_7865)
static void C_ccall f_7865(C_word c,C_word *av) C_noret;
C_noret_decl(f_8317)
static void C_ccall f_8317(C_word c,C_word *av) C_noret;
C_noret_decl(f_5726)
static void C_ccall f_5726(C_word c,C_word *av) C_noret;
C_noret_decl(f_7535)
static void C_ccall f_7535(C_word c,C_word *av) C_noret;
C_noret_decl(f_7538)
static void C_ccall f_7538(C_word c,C_word *av) C_noret;
C_noret_decl(f_12887)
static void C_fcall f_12887(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12311)
static void C_ccall f_12311(C_word c,C_word *av) C_noret;
C_noret_decl(f_10231)
static void C_ccall f_10231(C_word c,C_word *av) C_noret;
C_noret_decl(f_12871)
static void C_ccall f_12871(C_word c,C_word *av) C_noret;
C_noret_decl(f_9424)
static void C_ccall f_9424(C_word c,C_word *av) C_noret;
C_noret_decl(f_12877)
static void C_ccall f_12877(C_word c,C_word *av) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word *av) C_noret;
C_noret_decl(f_9437)
static void C_fcall f_9437(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9435)
static void C_ccall f_9435(C_word c,C_word *av) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word *av) C_noret;
C_noret_decl(f_8361)
static void C_ccall f_8361(C_word c,C_word *av) C_noret;
C_noret_decl(f_8357)
static void C_ccall f_8357(C_word c,C_word *av) C_noret;
C_noret_decl(f_7605)
static void C_ccall f_7605(C_word c,C_word *av) C_noret;
C_noret_decl(f_7607)
static void C_fcall f_7607(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15102)
static void C_fcall f_15102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15106)
static void C_ccall f_15106(C_word c,C_word *av) C_noret;
C_noret_decl(f_5224)
static void C_fcall f_5224(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5218)
static void C_ccall f_5218(C_word c,C_word *av) C_noret;
C_noret_decl(f_5215)
static void C_ccall f_5215(C_word c,C_word *av) C_noret;
C_noret_decl(f_14868)
static void C_ccall f_14868(C_word c,C_word *av) C_noret;
C_noret_decl(f_8398)
static void C_fcall f_8398(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9406)
static void C_ccall f_9406(C_word c,C_word *av) C_noret;
C_noret_decl(f_10265)
static void C_ccall f_10265(C_word c,C_word *av) C_noret;
C_noret_decl(f_10267)
static void C_fcall f_10267(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9417)
static void C_fcall f_9417(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16096)
static void C_ccall f_16096(C_word c,C_word *av) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word *av) C_noret;
C_noret_decl(f_14856)
static void C_ccall f_14856(C_word c,C_word *av) C_noret;
C_noret_decl(f_4898)
static void C_ccall f_4898(C_word c,C_word *av) C_noret;
C_noret_decl(f_11400)
static void C_ccall f_11400(C_word c,C_word *av) C_noret;
C_noret_decl(f_11407)
static void C_fcall f_11407(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word *av) C_noret;
C_noret_decl(f_14826)
static void C_ccall f_14826(C_word c,C_word *av) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word *av) C_noret;
C_noret_decl(f_14837)
static void C_ccall f_14837(C_word c,C_word *av) C_noret;
C_noret_decl(f_5582)
static void C_ccall f_5582(C_word c,C_word *av) C_noret;
C_noret_decl(f_10292)
static void C_ccall f_10292(C_word c,C_word *av) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word *av) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word *av) C_noret;
C_noret_decl(f_4888)
static void C_fcall f_4888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5576)
static void C_ccall f_5576(C_word c,C_word *av) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word *av) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word *av) C_noret;
C_noret_decl(f_14817)
static void C_ccall f_14817(C_word c,C_word *av) C_noret;
C_noret_decl(f_15743)
static void C_ccall f_15743(C_word c,C_word *av) C_noret;
C_noret_decl(f_9365)
static void C_fcall f_9365(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_15844)
static void C_ccall f_15844(C_word c,C_word *av) C_noret;
C_noret_decl(f_15848)
static void C_ccall f_15848(C_word c,C_word *av) C_noret;
C_noret_decl(f_15755)
static void C_ccall f_15755(C_word c,C_word *av) C_noret;
C_noret_decl(f_15758)
static void C_ccall f_15758(C_word c,C_word *av) C_noret;
C_noret_decl(f_4823)
static void C_ccall f_4823(C_word c,C_word *av) C_noret;
C_noret_decl(f_9379)
static void C_ccall f_9379(C_word c,C_word *av) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word *av) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word *av) C_noret;
C_noret_decl(f_5815)
static void C_ccall f_5815(C_word c,C_word *av) C_noret;
C_noret_decl(f_8621)
static void C_ccall f_8621(C_word c,C_word *av) C_noret;
C_noret_decl(f_11429)
static void C_ccall f_11429(C_word c,C_word *av) C_noret;
C_noret_decl(f_9383)
static void C_ccall f_9383(C_word c,C_word *av) C_noret;
C_noret_decl(f_10255)
static void C_fcall f_10255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10250)
static void C_ccall f_10250(C_word c,C_word *av) C_noret;
C_noret_decl(f_5800)
static void C_fcall f_5800(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11478)
static void C_ccall f_11478(C_word c,C_word *av) C_noret;
C_noret_decl(f_9053)
static void C_fcall f_9053(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11480)
static void C_ccall f_11480(C_word c,C_word *av) C_noret;
C_noret_decl(f_11450)
static void C_ccall f_11450(C_word c,C_word *av) C_noret;
C_noret_decl(f_10943)
static void C_fcall f_10943(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11437)
static void C_ccall f_11437(C_word c,C_word *av) C_noret;
C_noret_decl(f_11431)
static void C_ccall f_11431(C_word c,C_word *av) C_noret;
C_noret_decl(f_5907)
static void C_ccall f_5907(C_word c,C_word *av) C_noret;
C_noret_decl(f_10712)
static void C_ccall f_10712(C_word c,C_word *av) C_noret;
C_noret_decl(f_5879)
static void C_ccall f_5879(C_word c,C_word *av) C_noret;
C_noret_decl(f_8377)
static void C_ccall f_8377(C_word c,C_word *av) C_noret;
C_noret_decl(f_5891)
static void C_ccall f_5891(C_word c,C_word *av) C_noret;
C_noret_decl(f_11410)
static void C_ccall f_11410(C_word c,C_word *av) C_noret;
C_noret_decl(f_10889)
static void C_ccall f_10889(C_word c,C_word *av) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word *av) C_noret;
C_noret_decl(f_5831)
static void C_ccall f_5831(C_word c,C_word *av) C_noret;
C_noret_decl(f_6711)
static void C_ccall f_6711(C_word c,C_word *av) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715(C_word c,C_word *av) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word *av) C_noret;
C_noret_decl(f_7520)
static void C_ccall f_7520(C_word c,C_word *av) C_noret;
C_noret_decl(f_10705)
static void C_ccall f_10705(C_word c,C_word *av) C_noret;
C_noret_decl(f_10703)
static void C_ccall f_10703(C_word c,C_word *av) C_noret;
C_noret_decl(f_10773)
static void C_fcall f_10773(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6164)
static void C_ccall f_6164(C_word c,C_word *av) C_noret;
C_noret_decl(f_10770)
static void C_ccall f_10770(C_word c,C_word *av) C_noret;
C_noret_decl(f_6160)
static void C_fcall f_6160(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5843)
static void C_ccall f_5843(C_word c,C_word *av) C_noret;
C_noret_decl(f_5845)
static void C_ccall f_5845(C_word c,C_word *av) C_noret;
C_noret_decl(f_7829)
static void C_ccall f_7829(C_word c,C_word *av) C_noret;
C_noret_decl(f_7505)
static void C_ccall f_7505(C_word c,C_word *av) C_noret;
C_noret_decl(f_5981)
static void C_ccall f_5981(C_word c,C_word *av) C_noret;
C_noret_decl(f_6020)
static void C_ccall f_6020(C_word c,C_word *av) C_noret;
C_noret_decl(f_5983)
static void C_ccall f_5983(C_word c,C_word *av) C_noret;
C_noret_decl(f_15600)
static void C_ccall f_15600(C_word c,C_word *av) C_noret;
C_noret_decl(f_6100)
static void C_ccall f_6100(C_word c,C_word *av) C_noret;
C_noret_decl(f_7953)
static void C_ccall f_7953(C_word c,C_word *av) C_noret;
C_noret_decl(f_6037)
static void C_ccall f_6037(C_word c,C_word *av) C_noret;
C_noret_decl(f_6039)
static void C_ccall f_6039(C_word c,C_word *av) C_noret;
C_noret_decl(f_5937)
static void C_ccall f_5937(C_word c,C_word *av) C_noret;
C_noret_decl(f_10815)
static void C_ccall f_10815(C_word c,C_word *av) C_noret;
C_noret_decl(f_6720)
static void C_ccall f_6720(C_word c,C_word *av) C_noret;
C_noret_decl(f_6118)
static void C_ccall f_6118(C_word c,C_word *av) C_noret;
C_noret_decl(f_6117)
static void C_ccall f_6117(C_word c,C_word *av) C_noret;
C_noret_decl(f_6114)
static void C_ccall f_6114(C_word c,C_word *av) C_noret;
C_noret_decl(f_6005)
static void C_ccall f_6005(C_word c,C_word *av) C_noret;
C_noret_decl(f_11490)
static void C_ccall f_11490(C_word c,C_word *av) C_noret;
C_noret_decl(f_15669)
static void C_ccall f_15669(C_word c,C_word *av) C_noret;
C_noret_decl(f_6777)
static void C_ccall f_6777(C_word c,C_word *av) C_noret;
C_noret_decl(f_6771)
static void C_ccall f_6771(C_word c,C_word *av) C_noret;
C_noret_decl(f_15665)
static void C_ccall f_15665(C_word c,C_word *av) C_noret;
C_noret_decl(f_6127)
static void C_ccall f_6127(C_word c,C_word *av) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word *av) C_noret;
C_noret_decl(f_5999)
static void C_ccall f_5999(C_word c,C_word *av) C_noret;
C_noret_decl(f_7974)
static void C_ccall f_7974(C_word c,C_word *av) C_noret;
C_noret_decl(f_15657)
static void C_ccall f_15657(C_word c,C_word *av) C_noret;
C_noret_decl(f_6740)
static void C_fcall f_6740(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15659)
static void C_ccall f_15659(C_word c,C_word *av) C_noret;
C_noret_decl(f_6744)
static void C_fcall f_6744(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6139)
static void C_ccall f_6139(C_word c,C_word *av) C_noret;
C_noret_decl(f_6133)
static void C_ccall f_6133(C_word c,C_word *av) C_noret;
C_noret_decl(f_10850)
static void C_ccall f_10850(C_word c,C_word *av) C_noret;
C_noret_decl(f_6069)
static void C_fcall f_6069(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10866)
static void C_ccall f_10866(C_word c,C_word *av) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word *av) C_noret;
C_noret_decl(f_6790)
static void C_ccall f_6790(C_word c,C_word *av) C_noret;
C_noret_decl(f_7996)
static void C_ccall f_7996(C_word c,C_word *av) C_noret;
C_noret_decl(f_10856)
static void C_ccall f_10856(C_word c,C_word *av) C_noret;
C_noret_decl(f_10789)
static void C_ccall f_10789(C_word c,C_word *av) C_noret;
C_noret_decl(f_6045)
static void C_fcall f_6045(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10848)
static void C_ccall f_10848(C_word c,C_word *av) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word *av) C_noret;
C_noret_decl(f_11392)
static void C_ccall f_11392(C_word c,C_word *av) C_noret;
C_noret_decl(f_11394)
static void C_ccall f_11394(C_word c,C_word *av) C_noret;
C_noret_decl(f_6186)
static void C_ccall f_6186(C_word c,C_word *av) C_noret;
C_noret_decl(f_15674)
static void C_fcall f_15674(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word *av) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085(C_word c,C_word *av) C_noret;
C_noret_decl(f_7451)
static void C_ccall f_7451(C_word c,C_word *av) C_noret;
C_noret_decl(f_6095)
static void C_ccall f_6095(C_word c,C_word *av) C_noret;
C_noret_decl(f_11359)
static void C_ccall f_11359(C_word c,C_word *av) C_noret;
C_noret_decl(f_11353)
static void C_ccall f_11353(C_word c,C_word *av) C_noret;
C_noret_decl(f_10402)
static void C_ccall f_10402(C_word c,C_word *av) C_noret;
C_noret_decl(f_5941)
static void C_fcall f_5941(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6147)
static void C_ccall f_6147(C_word c,C_word *av) C_noret;
C_noret_decl(f_13315)
static void C_ccall f_13315(C_word c,C_word *av) C_noret;
C_noret_decl(f_7428)
static void C_ccall f_7428(C_word c,C_word *av) C_noret;
C_noret_decl(f_6158)
static void C_ccall f_6158(C_word c,C_word *av) C_noret;
C_noret_decl(f_6150)
static void C_ccall f_6150(C_word c,C_word *av) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word *av) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word *av) C_noret;
C_noret_decl(f_7442)
static void C_ccall f_7442(C_word c,C_word *av) C_noret;
C_noret_decl(f_14243)
static void C_fcall f_14243(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7436)
static void C_ccall f_7436(C_word c,C_word *av) C_noret;
C_noret_decl(f_7430)
static void C_ccall f_7430(C_word c,C_word *av) C_noret;
C_noret_decl(f_7469)
static void C_ccall f_7469(C_word c,C_word *av) C_noret;
C_noret_decl(f_7460)
static void C_ccall f_7460(C_word c,C_word *av) C_noret;
C_noret_decl(f_14221)
static void C_fcall f_14221(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15383)
static void C_ccall f_15383(C_word c,C_word *av) C_noret;
C_noret_decl(f_15494)
static void C_ccall f_15494(C_word c,C_word *av) C_noret;
C_noret_decl(f_15386)
static void C_ccall f_15386(C_word c,C_word *av) C_noret;
C_noret_decl(f_11369)
static void C_ccall f_11369(C_word c,C_word *av) C_noret;
C_noret_decl(f_11366)
static void C_fcall f_11366(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15488)
static void C_ccall f_15488(C_word c,C_word *av) C_noret;
C_noret_decl(f_4972)
static void C_ccall f_4972(C_word c,C_word *av) C_noret;
C_noret_decl(f_15482)
static void C_ccall f_15482(C_word c,C_word *av) C_noret;
C_noret_decl(f_15476)
static void C_ccall f_15476(C_word c,C_word *av) C_noret;
C_noret_decl(f_6562)
static void C_ccall f_6562(C_word c,C_word *av) C_noret;
C_noret_decl(f_15470)
static void C_ccall f_15470(C_word c,C_word *av) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word *av) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word *av) C_noret;
C_noret_decl(f_14004)
static void C_ccall f_14004(C_word c,C_word *av) C_noret;
C_noret_decl(f_14008)
static void C_ccall f_14008(C_word c,C_word *av) C_noret;
C_noret_decl(f_4930)
static void C_fcall f_4930(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526(C_word c,C_word *av) C_noret;
C_noret_decl(f_6522)
static void C_ccall f_6522(C_word c,C_word *av) C_noret;
C_noret_decl(f_8983)
static void C_ccall f_8983(C_word c,C_word *av) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word *av) C_noret;
C_noret_decl(f_4984)
static void C_ccall f_4984(C_word c,C_word *av) C_noret;
C_noret_decl(f_8999)
static void C_ccall f_8999(C_word c,C_word *av) C_noret;
C_noret_decl(f_8995)
static void C_ccall f_8995(C_word c,C_word *av) C_noret;
C_noret_decl(f_4993)
static void C_ccall f_4993(C_word c,C_word *av) C_noret;
C_noret_decl(f_8986)
static void C_ccall f_8986(C_word c,C_word *av) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word *av) C_noret;
C_noret_decl(f_15247)
static void C_ccall f_15247(C_word c,C_word *av) C_noret;
C_noret_decl(f_15244)
static void C_ccall f_15244(C_word c,C_word *av) C_noret;
C_noret_decl(f_6540)
static void C_ccall f_6540(C_word c,C_word *av) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544(C_word c,C_word *av) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word *av) C_noret;
C_noret_decl(f_4960)
static void C_ccall f_4960(C_word c,C_word *av) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word *av) C_noret;
C_noret_decl(f_15237)
static void C_ccall f_15237(C_word c,C_word *av) C_noret;
C_noret_decl(f_6558)
static void C_ccall f_6558(C_word c,C_word *av) C_noret;
C_noret_decl(f_11004)
static void C_ccall f_11004(C_word c,C_word *av) C_noret;
C_noret_decl(f_7930)
static void C_fcall f_7930(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6552)
static void C_ccall f_6552(C_word c,C_word *av) C_noret;
C_noret_decl(f_15231)
static void C_ccall f_15231(C_word c,C_word *av) C_noret;
C_noret_decl(f_15223)
static void C_ccall f_15223(C_word c,C_word *av) C_noret;
C_noret_decl(f_12237)
static void C_fcall f_12237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15219)
static void C_ccall f_15219(C_word c,C_word *av) C_noret;
C_noret_decl(f_15717)
static void C_ccall f_15717(C_word c,C_word *av) C_noret;
C_noret_decl(f_15214)
static void C_ccall f_15214(C_word c,C_word *av) C_noret;
C_noret_decl(f_15711)
static void C_ccall f_15711(C_word c,C_word *av) C_noret;
C_noret_decl(f_15714)
static void C_ccall f_15714(C_word c,C_word *av) C_noret;
C_noret_decl(f_15210)
static void C_ccall f_15210(C_word c,C_word *av) C_noret;
C_noret_decl(f_15702)
static void C_ccall f_15702(C_word c,C_word *av) C_noret;
C_noret_decl(f_15289)
static void C_ccall f_15289(C_word c,C_word *av) C_noret;
C_noret_decl(f_15275)
static void C_ccall f_15275(C_word c,C_word *av) C_noret;
C_noret_decl(f_15279)
static void C_ccall f_15279(C_word c,C_word *av) C_noret;
C_noret_decl(f_8910)
static void C_ccall f_8910(C_word c,C_word *av) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word *av) C_noret;
C_noret_decl(f_12240)
static void C_ccall f_12240(C_word c,C_word *av) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word *av) C_noret;
C_noret_decl(f_9522)
static void C_ccall f_9522(C_word c,C_word *av) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word *av) C_noret;
C_noret_decl(f_9536)
static void C_ccall f_9536(C_word c,C_word *av) C_noret;
C_noret_decl(f_9548)
static void C_fcall f_9548(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15723)
static void C_ccall f_15723(C_word c,C_word *av) C_noret;
C_noret_decl(f_15720)
static void C_ccall f_15720(C_word c,C_word *av) C_noret;
C_noret_decl(f_9546)
static void C_ccall f_9546(C_word c,C_word *av) C_noret;
C_noret_decl(f_6453)
static void C_fcall f_6453(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15737)
static void C_ccall f_15737(C_word c,C_word *av) C_noret;
C_noret_decl(f_10143)
static void C_ccall f_10143(C_word c,C_word *av) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word *av) C_noret;
C_noret_decl(f_12204)
static void C_fcall f_12204(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12200)
static void C_ccall f_12200(C_word c,C_word *av) C_noret;
C_noret_decl(f_5283)
static void C_fcall f_5283(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6463)
static void C_ccall f_6463(C_word c,C_word *av) C_noret;
C_noret_decl(f_15727)
static void C_fcall f_15727(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15726)
static void C_ccall f_15726(C_word c,C_word *av) C_noret;
C_noret_decl(f_15782)
static void C_ccall f_15782(C_word c,C_word *av) C_noret;
C_noret_decl(f_5274)
static void C_ccall f_5274(C_word c,C_word *av) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word *av) C_noret;
C_noret_decl(f_10127)
static void C_ccall f_10127(C_word c,C_word *av) C_noret;
C_noret_decl(f_15799)
static void C_fcall f_15799(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11891)
static void C_ccall f_11891(C_word c,C_word *av) C_noret;
C_noret_decl(f_10135)
static void C_ccall f_10135(C_word c,C_word *av) C_noret;
C_noret_decl(f_14982)
static void C_ccall f_14982(C_word c,C_word *av) C_noret;
C_noret_decl(f_14690)
static void C_ccall f_14690(C_word c,C_word *av) C_noret;
C_noret_decl(f_15203)
static void C_ccall f_15203(C_word c,C_word *av) C_noret;
C_noret_decl(f_13297)
static void C_ccall f_13297(C_word c,C_word *av) C_noret;
C_noret_decl(f_15761)
static void C_ccall f_15761(C_word c,C_word *av) C_noret;
C_noret_decl(f_6499)
static void C_fcall f_6499(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15779)
static void C_ccall f_15779(C_word c,C_word *av) C_noret;
C_noret_decl(f_14991)
static void C_fcall f_14991(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15766)
static void C_fcall f_15766(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14965)
static void C_fcall f_14965(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11841)
static void C_ccall f_11841(C_word c,C_word *av) C_noret;
C_noret_decl(f_6476)
static void C_fcall f_6476(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12275)
static void C_ccall f_12275(C_word c,C_word *av) C_noret;
C_noret_decl(f_8290)
static void C_ccall f_8290(C_word c,C_word *av) C_noret;
C_noret_decl(f_8292)
static void C_fcall f_8292(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11823)
static void C_fcall f_11823(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14955)
static void C_ccall f_14955(C_word c,C_word *av) C_noret;
C_noret_decl(f_14950)
static void C_ccall f_14950(C_word c,C_word *av) C_noret;
C_noret_decl(f_10156)
static void C_ccall f_10156(C_word c,C_word *av) C_noret;
C_noret_decl(f_14926)
static void C_fcall f_14926(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10158)
static void C_fcall f_10158(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11808)
static void C_fcall f_11808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word *av) C_noret;
C_noret_decl(f_14626)
static void C_ccall f_14626(C_word c,C_word *av) C_noret;
C_noret_decl(f_14936)
static void C_ccall f_14936(C_word c,C_word *av) C_noret;
C_noret_decl(f_13884)
static void C_ccall f_13884(C_word c,C_word *av) C_noret;
C_noret_decl(f_4953)
static void C_fcall f_4953(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14616)
static void C_fcall f_14616(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6509)
static void C_ccall f_6509(C_word c,C_word *av) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word *av) C_noret;
C_noret_decl(f_14914)
static void C_fcall f_14914(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14680)
static void C_fcall f_14680(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8206)
static void C_ccall f_8206(C_word c,C_word *av) C_noret;
C_noret_decl(f_14182)
static void C_fcall f_14182(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14912)
static void C_fcall f_14912(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14672)
static void C_fcall f_14672(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10116)
static void C_ccall f_10116(C_word c,C_word *av) C_noret;
C_noret_decl(f_16234)
static void C_ccall f_16234(C_word c,C_word *av) C_noret;
C_noret_decl(f_16230)
static void C_ccall f_16230(C_word c,C_word *av) C_noret;
C_noret_decl(f_16237)
static void C_ccall f_16237(C_word c,C_word *av) C_noret;
C_noret_decl(f_12115)
static void C_ccall f_12115(C_word c,C_word *av) C_noret;
C_noret_decl(f_12112)
static void C_fcall f_12112(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16242)
static void C_ccall f_16242(C_word c,C_word *av) C_noret;
C_noret_decl(f_16248)
static void C_ccall f_16248(C_word c,C_word *av) C_noret;
C_noret_decl(f_6486)
static void C_ccall f_6486(C_word c,C_word *av) C_noret;
C_noret_decl(f_9497)
static void C_fcall f_9497(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13856)
static void C_fcall f_13856(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16212)
static void C_ccall f_16212(C_word c,C_word *av) C_noret;
C_noret_decl(f_9495)
static void C_ccall f_9495(C_word c,C_word *av) C_noret;
C_noret_decl(f_9168)
static void C_ccall f_9168(C_word c,C_word *av) C_noret;
C_noret_decl(f_16219)
static void C_ccall f_16219(C_word c,C_word *av) C_noret;
C_noret_decl(f_9164)
static void C_ccall f_9164(C_word c,C_word *av) C_noret;
C_noret_decl(f_9176)
static void C_fcall f_9176(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9462)
static void C_ccall f_9462(C_word c,C_word *av) C_noret;
C_noret_decl(f_13337)
static void C_fcall f_13337(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15092)
static void C_ccall f_15092(C_word c,C_word *av) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word *av) C_noret;
C_noret_decl(f_15099)
static void C_ccall f_15099(C_word c,C_word *av) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word *av) C_noret;
C_noret_decl(f_13347)
static void C_fcall f_13347(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15314)
static void C_ccall f_15314(C_word c,C_word *av) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word *av) C_noret;
C_noret_decl(f_5078)
static void C_ccall f_5078(C_word c,C_word *av) C_noret;
C_noret_decl(f_5072)
static void C_ccall f_5072(C_word c,C_word *av) C_noret;
C_noret_decl(f_13343)
static void C_ccall f_13343(C_word c,C_word *av) C_noret;
C_noret_decl(f_14640)
static void C_fcall f_14640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5367)
static void C_fcall f_5367(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5361)
static void C_ccall f_5361(C_word c,C_word *av) C_noret;
C_noret_decl(f_15307)
static void C_ccall f_15307(C_word c,C_word *av) C_noret;
C_noret_decl(f_5069)
static void C_ccall f_5069(C_word c,C_word *av) C_noret;
C_noret_decl(f_5017)
static void C_ccall f_5017(C_word c,C_word *av) C_noret;
C_noret_decl(f_13325)
static void C_fcall f_13325(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5010)
static void C_fcall f_5010(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8119)
static void C_ccall f_8119(C_word c,C_word *av) C_noret;
C_noret_decl(f_16205)
static void C_ccall f_16205(C_word c,C_word *av) C_noret;
C_noret_decl(f_16203)
static void C_ccall f_16203(C_word c,C_word *av) C_noret;
C_noret_decl(f_15368)
static void C_ccall f_15368(C_word c,C_word *av) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643(C_word c,C_word *av) C_noret;
C_noret_decl(f_5005)
static void C_ccall f_5005(C_word c,C_word *av) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word *av) C_noret;
C_noret_decl(f_5008)
static void C_fcall f_5008(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6608)
static void C_ccall f_6608(C_word c,C_word *av) C_noret;
C_noret_decl(f_6604)
static void C_ccall f_6604(C_word c,C_word *av) C_noret;
C_noret_decl(f_5333)
static void C_fcall f_5333(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word *av) C_noret;
C_noret_decl(f_5037)
static void C_ccall f_5037(C_word c,C_word *av) C_noret;
C_noret_decl(f_13380)
static void C_fcall f_13380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6656)
static void C_ccall f_6656(C_word c,C_word *av) C_noret;
C_noret_decl(f_15344)
static void C_ccall f_15344(C_word c,C_word *av) C_noret;
C_noret_decl(f_5666)
static void C_ccall f_5666(C_word c,C_word *av) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word *av) C_noret;
C_noret_decl(f_5023)
static void C_ccall f_5023(C_word c,C_word *av) C_noret;
C_noret_decl(f_5020)
static void C_ccall f_5020(C_word c,C_word *av) C_noret;
C_noret_decl(f_6663)
static void C_fcall f_6663(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6660)
static void C_ccall f_6660(C_word c,C_word *av) C_noret;
C_noret_decl(f_12930)
static void C_fcall f_12930(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5695)
static void C_ccall f_5695(C_word c,C_word *av) C_noret;
C_noret_decl(f_12920)
static void C_fcall f_12920(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12926)
static void C_ccall f_12926(C_word c,C_word *av) C_noret;
C_noret_decl(f_5682)
static void C_ccall f_5682(C_word c,C_word *av) C_noret;
C_noret_decl(f_12908)
static void C_fcall f_12908(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10688)
static void C_ccall f_10688(C_word c,C_word *av) C_noret;
C_noret_decl(f_16255)
static void C_ccall f_16255(C_word c,C_word *av) C_noret;
C_noret_decl(f_13303)
static void C_ccall f_13303(C_word c,C_word *av) C_noret;
C_noret_decl(f_11129)
static void C_ccall f_11129(C_word c,C_word *av) C_noret;
C_noret_decl(f_16258)
static void C_ccall f_16258(C_word c,C_word *av) C_noret;
C_noret_decl(f_11123)
static void C_ccall f_11123(C_word c,C_word *av) C_noret;
C_noret_decl(f_10664)
static void C_ccall f_10664(C_word c,C_word *av) C_noret;
C_noret_decl(f_16261)
static void C_ccall f_16261(C_word c,C_word *av) C_noret;
C_noret_decl(f_16264)
static void C_ccall f_16264(C_word c,C_word *av) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word *av) C_noret;
C_noret_decl(f_10678)
static void C_fcall f_10678(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10673)
static void C_ccall f_10673(C_word c,C_word *av) C_noret;
C_noret_decl(f_11053)
static void C_ccall f_11053(C_word c,C_word *av) C_noret;
C_noret_decl(f_10670)
static void C_ccall f_10670(C_word c,C_word *av) C_noret;
C_noret_decl(f_5052)
static void C_ccall f_5052(C_word c,C_word *av) C_noret;
C_noret_decl(f_11022)
static void C_fcall f_11022(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11155)
static void C_fcall f_11155(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5042)
static void C_fcall f_5042(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16199)
static void C_ccall f_16199(C_word c,C_word *av) C_noret;
C_noret_decl(f_10655)
static void C_ccall f_10655(C_word c,C_word *av) C_noret;
C_noret_decl(f_10659)
static void C_ccall f_10659(C_word c,C_word *av) C_noret;
C_noret_decl(f_16196)
static void C_ccall f_16196(C_word c,C_word *av) C_noret;
C_noret_decl(f_7804)
static void C_fcall f_7804(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16193)
static void C_ccall f_16193(C_word c,C_word *av) C_noret;
C_noret_decl(f_16190)
static void C_ccall f_16190(C_word c,C_word *av) C_noret;
C_noret_decl(f_11169)
static void C_ccall f_11169(C_word c,C_word *av) C_noret;
C_noret_decl(f_10627)
static void C_ccall f_10627(C_word c,C_word *av) C_noret;
C_noret_decl(f_11177)
static void C_ccall f_11177(C_word c,C_word *av) C_noret;
C_noret_decl(f_5622)
static void C_ccall f_5622(C_word c,C_word *av) C_noret;
C_noret_decl(f_15028)
static void C_ccall f_15028(C_word c,C_word *av) C_noret;
C_noret_decl(f_12014)
static void C_fcall f_12014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15022)
static void C_ccall f_15022(C_word c,C_word *av) C_noret;
C_noret_decl(f_9701)
static void C_ccall f_9701(C_word c,C_word *av) C_noret;
C_noret_decl(f_9707)
static void C_ccall f_9707(C_word c,C_word *av) C_noret;
C_noret_decl(f_9687)
static void C_ccall f_9687(C_word c,C_word *av) C_noret;
C_noret_decl(f_9683)
static void C_ccall f_9683(C_word c,C_word *av) C_noret;
C_noret_decl(f_9723)
static void C_ccall f_9723(C_word c,C_word *av) C_noret;
C_noret_decl(f_9130)
static void C_ccall f_9130(C_word c,C_word *av) C_noret;
C_noret_decl(f_15034)
static void C_ccall f_15034(C_word c,C_word *av) C_noret;
C_noret_decl(f_9726)
static void C_ccall f_9726(C_word c,C_word *av) C_noret;
C_noret_decl(f_15069)
static void C_ccall f_15069(C_word c,C_word *av) C_noret;
C_noret_decl(f_15066)
static void C_ccall f_15066(C_word c,C_word *av) C_noret;
C_noret_decl(f_15063)
static void C_ccall f_15063(C_word c,C_word *av) C_noret;
C_noret_decl(f_15060)
static void C_ccall f_15060(C_word c,C_word *av) C_noret;
C_noret_decl(f_16135)
static void C_ccall f_16135(C_word c,C_word *av) C_noret;
C_noret_decl(f_16139)
static void C_ccall f_16139(C_word c,C_word *av) C_noret;
C_noret_decl(f_15161)
static void C_ccall f_15161(C_word c,C_word *av) C_noret;
C_noret_decl(f_11669)
static void C_ccall f_11669(C_word c,C_word *av) C_noret;
C_noret_decl(f_11660)
static void C_ccall f_11660(C_word c,C_word *av) C_noret;
C_noret_decl(f_11663)
static void C_ccall f_11663(C_word c,C_word *av) C_noret;
C_noret_decl(f_5395)
static void C_ccall f_5395(C_word c,C_word *av) C_noret;
C_noret_decl(f_15043)
static void C_ccall f_15043(C_word c,C_word *av) C_noret;
C_noret_decl(f_16111)
static void C_ccall f_16111(C_word c,C_word *av) C_noret;
C_noret_decl(f_11672)
static void C_ccall f_11672(C_word c,C_word *av) C_noret;
C_noret_decl(f_11675)
static void C_ccall f_11675(C_word c,C_word *av) C_noret;
C_noret_decl(f_16117)
static void C_ccall f_16117(C_word c,C_word *av) C_noret;
C_noret_decl(f_8179)
static void C_ccall f_8179(C_word c,C_word *av) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word *av) C_noret;
C_noret_decl(f_15077)
static void C_ccall f_15077(C_word c,C_word *av) C_noret;
C_noret_decl(f_5469)
static void C_ccall f_5469(C_word c,C_word *av) C_noret;
C_noret_decl(f_15073)
static void C_ccall f_15073(C_word c,C_word *av) C_noret;
C_noret_decl(f_16123)
static void C_ccall f_16123(C_word c,C_word *av) C_noret;
C_noret_decl(f_11645)
static void C_ccall f_11645(C_word c,C_word *av) C_noret;
C_noret_decl(f_11648)
static void C_ccall f_11648(C_word c,C_word *av) C_noret;
C_noret_decl(f_11642)
static void C_ccall f_11642(C_word c,C_word *av) C_noret;
C_noret_decl(f_11097)
static void C_ccall f_11097(C_word c,C_word *av) C_noret;
C_noret_decl(f_11103)
static void C_ccall f_11103(C_word c,C_word *av) C_noret;
C_noret_decl(f_11657)
static void C_ccall f_11657(C_word c,C_word *av) C_noret;
C_noret_decl(f_8181)
static void C_fcall f_8181(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11651)
static void C_ccall f_11651(C_word c,C_word *av) C_noret;
C_noret_decl(f_15057)
static void C_ccall f_15057(C_word c,C_word *av) C_noret;
C_noret_decl(f_15051)
static void C_ccall f_15051(C_word c,C_word *av) C_noret;
C_noret_decl(f_16181)
static void C_ccall f_16181(C_word c,C_word *av) C_noret;
C_noret_decl(f_16187)
static void C_ccall f_16187(C_word c,C_word *av) C_noret;
C_noret_decl(f_11626)
static void C_ccall f_11626(C_word c,C_word *av) C_noret;
C_noret_decl(f_11620)
static void C_ccall f_11620(C_word c,C_word *av) C_noret;
C_noret_decl(f_15199)
static void C_ccall f_15199(C_word c,C_word *av) C_noret;
C_noret_decl(f_15081)
static void C_ccall f_15081(C_word c,C_word *av) C_noret;
C_noret_decl(f_11639)
static void C_ccall f_11639(C_word c,C_word *av) C_noret;
C_noret_decl(f_11633)
static void C_ccall f_11633(C_word c,C_word *av) C_noret;
C_noret_decl(f_10965)
static void C_ccall f_10965(C_word c,C_word *av) C_noret;
C_noret_decl(f_8853)
static void C_ccall f_8853(C_word c,C_word *av) C_noret;
C_noret_decl(f_5425)
static void C_ccall f_5425(C_word c,C_word *av) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word *av) C_noret;
C_noret_decl(f_8883)
static void C_ccall f_8883(C_word c,C_word *av) C_noret;
C_noret_decl(f_10917)
static C_word C_fcall f_10917(C_word t0,C_word t1);
C_noret_decl(f_9776)
static void C_ccall f_9776(C_word c,C_word *av) C_noret;
C_noret_decl(f_5454)
static void C_ccall f_5454(C_word c,C_word *av) C_noret;
C_noret_decl(f_5457)
static void C_ccall f_5457(C_word c,C_word *av) C_noret;
C_noret_decl(f_5459)
static void C_ccall f_5459(C_word c,C_word *av) C_noret;
C_noret_decl(f_8885)
static void C_fcall f_8885(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11614)
static void C_ccall f_11614(C_word c,C_word *av) C_noret;
C_noret_decl(f_10909)
static void C_fcall f_10909(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10906)
static void C_ccall f_10906(C_word c,C_word *av) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word *av) C_noret;
C_noret_decl(f_10900)
static void C_ccall f_10900(C_word c,C_word *av) C_noret;
C_noret_decl(f_14781)
static void C_ccall f_14781(C_word c,C_word *av) C_noret;
C_noret_decl(f_5122)
static void C_fcall f_5122(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5125)
static void C_ccall f_5125(C_word c,C_word *av) C_noret;
C_noret_decl(f_5126)
static void C_fcall f_5126(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15809)
static void C_ccall f_15809(C_word c,C_word *av) C_noret;
C_noret_decl(f_14203)
static void C_fcall f_14203(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9731)
static void C_ccall f_9731(C_word c,C_word *av) C_noret;
C_noret_decl(f_9106)
static void C_ccall f_9106(C_word c,C_word *av) C_noret;
C_noret_decl(f_12157)
static void C_fcall f_12157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14787)
static void C_ccall f_14787(C_word c,C_word *av) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word *av) C_noret;
C_noret_decl(f_16107)
static void C_ccall f_16107(C_word c,C_word *av) C_noret;
C_noret_decl(f_12041)
static void C_fcall f_12041(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109(C_word c,C_word *av) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word *av) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word *av) C_noret;
C_noret_decl(f_9752)
static void C_fcall f_9752(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9756)
static void C_ccall f_9756(C_word c,C_word *av) C_noret;
C_noret_decl(f_12130)
static void C_fcall f_12130(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14725)
static void C_ccall f_14725(C_word c,C_word *av) C_noret;
C_noret_decl(f_14728)
static void C_fcall f_14728(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5136)
static void C_ccall f_5136(C_word c,C_word *av) C_noret;
C_noret_decl(f_5139)
static void C_ccall f_5139(C_word c,C_word *av) C_noret;
C_noret_decl(f_11591)
static void C_fcall f_11591(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10314)
static void C_fcall f_10314(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12068)
static void C_fcall f_12068(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11687)
static void C_ccall f_11687(C_word c,C_word *av) C_noret;
C_noret_decl(f_11681)
static void C_ccall f_11681(C_word c,C_word *av) C_noret;
C_noret_decl(f_11684)
static void C_ccall f_11684(C_word c,C_word *av) C_noret;
C_noret_decl(f_11696)
static void C_ccall f_11696(C_word c,C_word *av) C_noret;
C_noret_decl(f_11693)
static void C_ccall f_11693(C_word c,C_word *av) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word *av) C_noret;
C_noret_decl(f_5116)
static void C_ccall f_5116(C_word c,C_word *av) C_noret;
C_noret_decl(f_11699)
static void C_ccall f_11699(C_word c,C_word *av) C_noret;
C_noret_decl(f_10982)
static void C_fcall f_10982(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8555)
static void C_ccall f_8555(C_word c,C_word *av) C_noret;
C_noret_decl(f_10517)
static void C_ccall f_10517(C_word c,C_word *av) C_noret;
C_noret_decl(f_11946)
static void C_fcall f_11946(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_fcall f_5144(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9657)
static void C_fcall f_9657(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15826)
static void C_ccall f_15826(C_word c,C_word *av) C_noret;
C_noret_decl(f_15829)
static void C_fcall f_15829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9651)
static void C_ccall f_9651(C_word c,C_word *av) C_noret;
C_noret_decl(f_15822)
static void C_ccall f_15822(C_word c,C_word *av) C_noret;
C_noret_decl(f_10508)
static void C_ccall f_10508(C_word c,C_word *av) C_noret;
C_noret_decl(f_8557)
static void C_fcall f_8557(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12071)
static void C_ccall f_12071(C_word c,C_word *av) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177(C_word c,C_word *av) C_noret;
C_noret_decl(f_5171)
static void C_ccall f_5171(C_word c,C_word *av) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word *av) C_noret;
C_noret_decl(f_11949)
static void C_ccall f_11949(C_word c,C_word *av) C_noret;
C_noret_decl(f_8813)
static void C_fcall f_8813(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11964)
static void C_fcall f_11964(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15884)
static void C_ccall f_15884(C_word c,C_word *av) C_noret;
C_noret_decl(f_6349)
static void C_ccall f_6349(C_word c,C_word *av) C_noret;
C_noret_decl(f_15881)
static void C_ccall f_15881(C_word c,C_word *av) C_noret;
C_noret_decl(f_10481)
static void C_ccall f_10481(C_word c,C_word *av) C_noret;
C_noret_decl(f_10483)
static void C_fcall f_10483(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word *av) C_noret;
C_noret_decl(f_7668)
static void C_ccall f_7668(C_word c,C_word *av) C_noret;
C_noret_decl(f_7661)
static void C_ccall f_7661(C_word c,C_word *av) C_noret;
C_noret_decl(f_9078)
static void C_ccall f_9078(C_word c,C_word *av) C_noret;
C_noret_decl(f_14791)
static void C_ccall f_14791(C_word c,C_word *av) C_noret;
C_noret_decl(f_15865)
static void C_ccall f_15865(C_word c,C_word *av) C_noret;
C_noret_decl(f_16151)
static void C_ccall f_16151(C_word c,C_word *av) C_noret;
C_noret_decl(f_13736)
static void C_ccall f_13736(C_word c,C_word *av) C_noret;
C_noret_decl(f_16156)
static void C_fcall f_16156(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11988)
static void C_fcall f_11988(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11512)
static C_word C_fcall f_11512(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_15896)
static void C_ccall f_15896(C_word c,C_word *av) C_noret;
C_noret_decl(f17604)
static void C_ccall f17604(C_word c,C_word *av) C_noret;
C_noret_decl(f_11510)
static void C_ccall f_11510(C_word c,C_word *av) C_noret;
C_noret_decl(f_8532)
static void C_ccall f_8532(C_word c,C_word *av) C_noret;
C_noret_decl(f_13730)
static void C_ccall f_13730(C_word c,C_word *av) C_noret;
C_noret_decl(f_6378)
static void C_ccall f_6378(C_word c,C_word *av) C_noret;
C_noret_decl(f_12764)
static void C_ccall f_12764(C_word c,C_word *av) C_noret;
C_noret_decl(f_16166)
static void C_ccall f_16166(C_word c,C_word *av) C_noret;
C_noret_decl(f_13740)
static void C_ccall f_13740(C_word c,C_word *av) C_noret;
C_noret_decl(f_12758)
static void C_ccall f_12758(C_word c,C_word *av) C_noret;
C_noret_decl(f_15871)
static void C_ccall f_15871(C_word c,C_word *av) C_noret;
C_noret_decl(f_10862)
static void C_fcall f_10862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10206)
static void C_fcall f_10206(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6329)
static void C_ccall f_6329(C_word c,C_word *av) C_noret;
C_noret_decl(f_8582)
static void C_ccall f_8582(C_word c,C_word *av) C_noret;
C_noret_decl(f_6325)
static void C_ccall f_6325(C_word c,C_word *av) C_noret;
C_noret_decl(f_14762)
static void C_fcall f_14762(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12808)
static void C_ccall f_12808(C_word c,C_word *av) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word *av) C_noret;
C_noret_decl(f_8514)
static void C_ccall f_8514(C_word c,C_word *av) C_noret;
C_noret_decl(f_8526)
static void C_ccall f_8526(C_word c,C_word *av) C_noret;
C_noret_decl(f_11906)
static void C_fcall f_11906(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11501)
static void C_ccall f_11501(C_word c,C_word *av) C_noret;
C_noret_decl(f_11505)
static void C_ccall f_11505(C_word c,C_word *av) C_noret;
C_noret_decl(f_14032)
static void C_fcall f_14032(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10437)
static void C_ccall f_10437(C_word c,C_word *av) C_noret;
C_noret_decl(f_10431)
static void C_ccall f_10431(C_word c,C_word *av) C_noret;
C_noret_decl(f_9252)
static void C_fcall f_9252(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10736)
static void C_fcall f_10736(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6397)
static void C_ccall f_6397(C_word c,C_word *av) C_noret;
C_noret_decl(f_9713)
static void C_ccall f_9713(C_word c,C_word *av) C_noret;
C_noret_decl(f_8826)
static void C_ccall f_8826(C_word c,C_word *av) C_noret;
C_noret_decl(f_8828)
static void C_fcall f_8828(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9719)
static void C_ccall f_9719(C_word c,C_word *av) C_noret;
C_noret_decl(f_10091)
static void C_fcall f_10091(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9277)
static void C_ccall f_9277(C_word c,C_word *av) C_noret;
C_noret_decl(f_10079)
static void C_fcall f_10079(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12795)
static void C_ccall f_12795(C_word c,C_word *av) C_noret;
C_noret_decl(f_10089)
static void C_ccall f_10089(C_word c,C_word *av) C_noret;
C_noret_decl(f_9573)
static void C_ccall f_9573(C_word c,C_word *av) C_noret;
C_noret_decl(f_8597)
static void C_ccall f_8597(C_word c,C_word *av) C_noret;
C_noret_decl(f_8593)
static void C_fcall f_8593(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12777)
static void C_ccall f_12777(C_word c,C_word *av) C_noret;
C_noret_decl(f_8779)
static void C_ccall f_8779(C_word c,C_word *av) C_noret;
C_noret_decl(f_8773)
static void C_ccall f_8773(C_word c,C_word *av) C_noret;
C_noret_decl(f_8721)
static void C_ccall f_8721(C_word c,C_word *av) C_noret;
C_noret_decl(f_8723)
static void C_fcall f_8723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14608)
static void C_fcall f_14608(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7632)
static void C_ccall f_7632(C_word c,C_word *av) C_noret;
C_noret_decl(f_15965)
static void C_ccall f_15965(C_word c,C_word *av) C_noret;
C_noret_decl(f_15960)
static void C_ccall f_15960(C_word c,C_word *av) C_noret;
C_noret_decl(f_10018)
static void C_ccall f_10018(C_word c,C_word *av) C_noret;
C_noret_decl(f_15952)
static void C_ccall f_15952(C_word c,C_word *av) C_noret;
C_noret_decl(f_15406)
static void C_ccall f_15406(C_word c,C_word *av) C_noret;
C_noret_decl(f_15409)
static void C_ccall f_15409(C_word c,C_word *av) C_noret;
C_noret_decl(f_8004)
static void C_ccall f_8004(C_word c,C_word *av) C_noret;
C_noret_decl(f_7658)
static void C_fcall f_7658(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word *av) C_noret;
C_noret_decl(f_5539)
static void C_fcall f_5539(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5537)
static void C_ccall f_5537(C_word c,C_word *av) C_noret;
C_noret_decl(f_8765)
static void C_ccall f_8765(C_word c,C_word *av) C_noret;
C_noret_decl(f_15949)
static void C_ccall f_15949(C_word c,C_word *av) C_noret;
C_noret_decl(f_8008)
static void C_ccall f_8008(C_word c,C_word *av) C_noret;
C_noret_decl(f_8762)
static void C_ccall f_8762(C_word c,C_word *av) C_noret;
C_noret_decl(f_5521)
static void C_ccall f_5521(C_word c,C_word *av) C_noret;
C_noret_decl(f_15937)
static void C_ccall f_15937(C_word c,C_word *av) C_noret;
C_noret_decl(f_15468)
static void C_ccall f_15468(C_word c,C_word *av) C_noret;
C_noret_decl(f_15460)
static void C_ccall f_15460(C_word c,C_word *av) C_noret;
C_noret_decl(f_15454)
static void C_ccall f_15454(C_word c,C_word *av) C_noret;
C_noret_decl(f_10053)
static void C_ccall f_10053(C_word c,C_word *av) C_noret;
C_noret_decl(f_7795)
static void C_ccall f_7795(C_word c,C_word *av) C_noret;
C_noret_decl(f_10059)
static void C_ccall f_10059(C_word c,C_word *av) C_noret;
C_noret_decl(f_10050)
static void C_ccall f_10050(C_word c,C_word *av) C_noret;
C_noret_decl(f_15448)
static void C_ccall f_15448(C_word c,C_word *av) C_noret;
C_noret_decl(f_8016)
static void C_ccall f_8016(C_word c,C_word *av) C_noret;
C_noret_decl(f_9005)
static void C_fcall f_9005(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9003)
static void C_ccall f_9003(C_word c,C_word *av) C_noret;
C_noret_decl(f_10062)
static void C_ccall f_10062(C_word c,C_word *av) C_noret;
C_noret_decl(f_7768)
static void C_ccall f_7768(C_word c,C_word *av) C_noret;
C_noret_decl(f_7760)
static void C_ccall f_7760(C_word c,C_word *av) C_noret;
C_noret_decl(f_8041)
static void C_ccall f_8041(C_word c,C_word *av) C_noret;
C_noret_decl(f_15989)
static void C_ccall f_15989(C_word c,C_word *av) C_noret;
C_noret_decl(f_7734)
static void C_ccall f_7734(C_word c,C_word *av) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word *av) C_noret;
C_noret_decl(f_7731)
static void C_ccall f_7731(C_word c,C_word *av) C_noret;
C_noret_decl(f_5568)
static void C_fcall f_5568(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5561)
static void C_fcall f_5561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8037)
static void C_ccall f_8037(C_word c,C_word *av) C_noret;
C_noret_decl(f_10046)
static void C_fcall f_10046(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10041)
static void C_ccall f_10041(C_word c,C_word *av) C_noret;
C_noret_decl(f_16037)
static void C_ccall f_16037(C_word c,C_word *av) C_noret;
C_noret_decl(f_16039)
static void C_ccall f_16039(C_word c,C_word *av) C_noret;
C_noret_decl(f_5093)
static void C_ccall f_5093(C_word c,C_word *av) C_noret;
C_noret_decl(f_7770)
static void C_fcall f_7770(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10588)
static void C_ccall f_10588(C_word c,C_word *av) C_noret;
C_noret_decl(f_16029)
static void C_ccall f_16029(C_word c,C_word *av) C_noret;
C_noret_decl(f_9334)
static void C_ccall f_9334(C_word c,C_word *av) C_noret;
C_noret_decl(f_5084)
static void C_ccall f_5084(C_word c,C_word *av) C_noret;
C_noret_decl(f_15926)
static void C_ccall f_15926(C_word c,C_word *av) C_noret;
C_noret_decl(f_16079)
static void C_ccall f_16079(C_word c,C_word *av) C_noret;
C_noret_decl(f_10595)
static void C_ccall f_10595(C_word c,C_word *av) C_noret;
C_noret_decl(f_10592)
static void C_ccall f_10592(C_word c,C_word *av) C_noret;
C_noret_decl(f_5509)
static void C_ccall f_5509(C_word c,C_word *av) C_noret;
C_noret_decl(f_7039)
static void C_fcall f_7039(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16009)
static void C_ccall f_16009(C_word c,C_word *av) C_noret;
C_noret_decl(f_15905)
static void C_fcall f_15905(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15909)
static void C_ccall f_15909(C_word c,C_word *av) C_noret;
C_noret_decl(f_10579)
static void C_ccall f_10579(C_word c,C_word *av) C_noret;
C_noret_decl(f_15900)
static void C_ccall f_15900(C_word c,C_word *av) C_noret;
C_noret_decl(f_7052)
static void C_ccall f_7052(C_word c,C_word *av) C_noret;
C_noret_decl(f_9936)
static void C_ccall f_9936(C_word c,C_word *av) C_noret;
C_noret_decl(f_16064)
static void C_ccall f_16064(C_word c,C_word *av) C_noret;
C_noret_decl(f_9933)
static void C_ccall f_9933(C_word c,C_word *av) C_noret;
C_noret_decl(f_10554)
static void C_fcall f_10554(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10552)
static void C_ccall f_10552(C_word c,C_word *av) C_noret;
C_noret_decl(f_9307)
static void C_ccall f_9307(C_word c,C_word *av) C_noret;
C_noret_decl(f_9309)
static void C_fcall f_9309(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10523)
static void C_ccall f_10523(C_word c,C_word *av) C_noret;
C_noret_decl(f_16043)
static void C_ccall f_16043(C_word c,C_word *av) C_noret;
C_noret_decl(f_11705)
static void C_ccall f_11705(C_word c,C_word *av) C_noret;
C_noret_decl(f_11708)
static void C_ccall f_11708(C_word c,C_word *av) C_noret;
C_noret_decl(f_9965)
static void C_ccall f_9965(C_word c,C_word *av) C_noret;
C_noret_decl(f_9973)
static void C_ccall f_9973(C_word c,C_word *av) C_noret;
C_noret_decl(f_9989)
static void C_ccall f_9989(C_word c,C_word *av) C_noret;
C_noret_decl(f_9806)
static void C_ccall f_9806(C_word c,C_word *av) C_noret;
C_noret_decl(f_9992)
static void C_ccall f_9992(C_word c,C_word *av) C_noret;
C_noret_decl(f_9998)
static void C_ccall f_9998(C_word c,C_word *av) C_noret;
C_noret_decl(f_9820)
static void C_fcall f_9820(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15255)
static void C_ccall f_15255(C_word c,C_word *av) C_noret;
C_noret_decl(f_8748)
static void C_ccall f_8748(C_word c,C_word *av) C_noret;
C_noret_decl(f_15250)
static void C_ccall f_15250(C_word c,C_word *av) C_noret;
C_noret_decl(f_8053)
static void C_ccall f_8053(C_word c,C_word *av) C_noret;
C_noret_decl(f_11734)
static void C_ccall f_11734(C_word c,C_word *av) C_noret;
C_noret_decl(f_11783)
static void C_fcall f_11783(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8080)
static void C_fcall f_8080(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11755)
static void C_ccall f_11755(C_word c,C_word *av) C_noret;
C_noret_decl(f_9875)
static void C_fcall f_9875(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11728)
static void C_ccall f_11728(C_word c,C_word *av) C_noret;
C_noret_decl(f_11720)
static void C_ccall f_11720(C_word c,C_word *av) C_noret;
C_noret_decl(f_8094)
static void C_fcall f_8094(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8092)
static void C_ccall f_8092(C_word c,C_word *av) C_noret;
C_noret_decl(f_11745)
static void C_fcall f_11745(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11717)
static void C_ccall f_11717(C_word c,C_word *av) C_noret;
C_noret_decl(f_11713)
static void C_ccall f_11713(C_word c,C_word *av) C_noret;
C_noret_decl(f_6808)
static void C_fcall f_6808(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6806)
static void C_ccall f_6806(C_word c,C_word *av) C_noret;
C_noret_decl(f_9845)
static void C_ccall f_9845(C_word c,C_word *av) C_noret;
C_noret_decl(f_9854)
static void C_ccall f_9854(C_word c,C_word *av) C_noret;
C_noret_decl(f_7063)
static void C_fcall f_7063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9867)
static void C_ccall f_9867(C_word c,C_word *av) C_noret;
C_noret_decl(f_9200)
static void C_ccall f_9200(C_word c,C_word *av) C_noret;
C_noret_decl(f_7069)
static void C_ccall f_7069(C_word c,C_word *av) C_noret;
C_noret_decl(f_9215)
static void C_ccall f_9215(C_word c,C_word *av) C_noret;
C_noret_decl(f_10617)
static void C_fcall f_10617(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7743)
static void C_fcall f_7743(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7151)
static void C_ccall f_7151(C_word c,C_word *av) C_noret;
C_noret_decl(f_7154)
static void C_ccall f_7154(C_word c,C_word *av) C_noret;
C_noret_decl(f_9227)
static void C_ccall f_9227(C_word c,C_word *av) C_noret;
C_noret_decl(f_10601)
static void C_ccall f_10601(C_word c,C_word *av) C_noret;
C_noret_decl(f_6207)
static void C_ccall f_6207(C_word c,C_word *av) C_noret;
C_noret_decl(f_6201)
static void C_fcall f_6201(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10609)
static void C_ccall f_10609(C_word c,C_word *av) C_noret;
C_noret_decl(f_6200)
static void C_ccall f_6200(C_word c,C_word *av) C_noret;
C_noret_decl(f_7148)
static void C_ccall f_7148(C_word c,C_word *av) C_noret;
C_noret_decl(f_7142)
static void C_fcall f_7142(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11777)
static void C_ccall f_11777(C_word c,C_word *av) C_noret;
C_noret_decl(f_11771)
static void C_ccall f_11771(C_word c,C_word *av) C_noret;
C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_6268)
static void C_ccall f_6268(C_word c,C_word *av) C_noret;
C_noret_decl(f_15518)
static void C_fcall f_15518(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15516)
static void C_ccall f_15516(C_word c,C_word *av) C_noret;
C_noret_decl(f_6230)
static C_word C_fcall f_6230(C_word t0,C_word t1);
C_noret_decl(f_6885)
static void C_ccall f_6885(C_word c,C_word *av) C_noret;
C_noret_decl(f_5479)
static void C_ccall f_5479(C_word c,C_word *av) C_noret;
C_noret_decl(f_5477)
static void C_ccall f_5477(C_word c,C_word *av) C_noret;
C_noret_decl(f_8451)
static void C_ccall f_8451(C_word c,C_word *av) C_noret;
C_noret_decl(f_10399)
static void C_ccall f_10399(C_word c,C_word *av) C_noret;
C_noret_decl(f_10396)
static void C_ccall f_10396(C_word c,C_word *av) C_noret;
C_noret_decl(f_10392)
static void C_ccall f_10392(C_word c,C_word *av) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word *av) C_noret;
C_noret_decl(f_6864)
static void C_ccall f_6864(C_word c,C_word *av) C_noret;
C_noret_decl(f_6861)
static void C_ccall f_6861(C_word c,C_word *av) C_noret;
C_noret_decl(f_10368)
static void C_fcall f_10368(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10362)
static void C_ccall f_10362(C_word c,C_word *av) C_noret;
C_noret_decl(f_5183)
static void C_ccall f_5183(C_word c,C_word *av) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word *av) C_noret;
C_noret_decl(f_6272)
static void C_ccall f_6272(C_word c,C_word *av) C_noret;
C_noret_decl(f_15552)
static void C_fcall f_15552(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5485)
static void C_fcall f_5485(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6873)
static void C_ccall f_6873(C_word c,C_word *av) C_noret;
C_noret_decl(f_6870)
static void C_ccall f_6870(C_word c,C_word *av) C_noret;
C_noret_decl(f_15586)
static void C_ccall f_15586(C_word c,C_word *av) C_noret;
C_noret_decl(f_11232)
static void C_ccall f_11232(C_word c,C_word *av) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word *av) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195(C_word c,C_word *av) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word *av) C_noret;
C_noret_decl(f_6218)
static void C_ccall f_6218(C_word c,C_word *av) C_noret;
C_noret_decl(f_8487)
static void C_ccall f_8487(C_word c,C_word *av) C_noret;
C_noret_decl(f_8489)
static void C_fcall f_8489(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6224)
static void C_ccall f_6224(C_word c,C_word *av) C_noret;
C_noret_decl(f_6221)
static void C_ccall f_6221(C_word c,C_word *av) C_noret;
C_noret_decl(f_8424)
static void C_ccall f_8424(C_word c,C_word *av) C_noret;
C_noret_decl(f_8426)
static void C_fcall f_8426(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6846)
static void C_fcall f_6846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6842)
static void C_ccall f_6842(C_word c,C_word *av) C_noret;
C_noret_decl(f_16085)
static void C_ccall f_16085(C_word c,C_word *av) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word *av) C_noret;
C_noret_decl(f_11260)
static void C_ccall f_11260(C_word c,C_word *av) C_noret;
C_noret_decl(f_10386)
static void C_ccall f_10386(C_word c,C_word *av) C_noret;
C_noret_decl(f_10382)
static void C_ccall f_10382(C_word c,C_word *av) C_noret;
C_noret_decl(f_7478)
static void C_ccall f_7478(C_word c,C_word *av) C_noret;
C_noret_decl(f_6901)
static void C_ccall f_6901(C_word c,C_word *av) C_noret;
C_noret_decl(f_7487)
static void C_ccall f_7487(C_word c,C_word *av) C_noret;
C_noret_decl(f_5707)
static void C_fcall f_5707(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6911)
static void C_fcall f_6911(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6917)
static void C_ccall f_6917(C_word c,C_word *av) C_noret;
C_noret_decl(f_12896)
static void C_fcall f_12896(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9926)
static void C_ccall f_9926(C_word c,C_word *av) C_noret;
C_noret_decl(f_5754)
static void C_fcall f_5754(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5752)
static void C_ccall f_5752(C_word c,C_word *av) C_noret;
C_noret_decl(f_14107)
static void C_fcall f_14107(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5738)
static void C_ccall f_5738(C_word c,C_word *av) C_noret;
C_noret_decl(f_5251)
static void C_ccall f_5251(C_word c,C_word *av) C_noret;
C_noret_decl(f_15147)
static void C_fcall f_15147(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_15145)
static void C_ccall f_15145(C_word c,C_word *av) C_noret;
C_noret_decl(f_5262)
static void C_fcall f_5262(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6985)
static void C_fcall f_6985(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794(C_word c,C_word *av) C_noret;
C_noret_decl(f_5259)
static void C_ccall f_5259(C_word c,C_word *av) C_noret;

C_noret_decl(trf_6948)
static void C_ccall trf_6948(C_word c,C_word *av) C_noret;
static void C_ccall trf_6948(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6948(t0,t1);}

C_noret_decl(trf_12840)
static void C_ccall trf_12840(C_word c,C_word *av) C_noret;
static void C_ccall trf_12840(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_12840(t0,t1,t2);}

C_noret_decl(trf_12887)
static void C_ccall trf_12887(C_word c,C_word *av) C_noret;
static void C_ccall trf_12887(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12887(t0,t1);}

C_noret_decl(trf_9437)
static void C_ccall trf_9437(C_word c,C_word *av) C_noret;
static void C_ccall trf_9437(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9437(t0,t1,t2);}

C_noret_decl(trf_7607)
static void C_ccall trf_7607(C_word c,C_word *av) C_noret;
static void C_ccall trf_7607(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7607(t0,t1,t2);}

C_noret_decl(trf_15102)
static void C_ccall trf_15102(C_word c,C_word *av) C_noret;
static void C_ccall trf_15102(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15102(t0,t1);}

C_noret_decl(trf_5224)
static void C_ccall trf_5224(C_word c,C_word *av) C_noret;
static void C_ccall trf_5224(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5224(t0,t1,t2);}

C_noret_decl(trf_8398)
static void C_ccall trf_8398(C_word c,C_word *av) C_noret;
static void C_ccall trf_8398(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8398(t0,t1);}

C_noret_decl(trf_10267)
static void C_ccall trf_10267(C_word c,C_word *av) C_noret;
static void C_ccall trf_10267(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10267(t0,t1,t2);}

C_noret_decl(trf_9417)
static void C_ccall trf_9417(C_word c,C_word *av) C_noret;
static void C_ccall trf_9417(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9417(t0,t1);}

C_noret_decl(trf_11407)
static void C_ccall trf_11407(C_word c,C_word *av) C_noret;
static void C_ccall trf_11407(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11407(t0,t1);}

C_noret_decl(trf_4888)
static void C_ccall trf_4888(C_word c,C_word *av) C_noret;
static void C_ccall trf_4888(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4888(t0,t1);}

C_noret_decl(trf_9365)
static void C_ccall trf_9365(C_word c,C_word *av) C_noret;
static void C_ccall trf_9365(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_9365(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10255)
static void C_ccall trf_10255(C_word c,C_word *av) C_noret;
static void C_ccall trf_10255(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10255(t0,t1,t2);}

C_noret_decl(trf_5800)
static void C_ccall trf_5800(C_word c,C_word *av) C_noret;
static void C_ccall trf_5800(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5800(t0,t1,t2,t3);}

C_noret_decl(trf_9053)
static void C_ccall trf_9053(C_word c,C_word *av) C_noret;
static void C_ccall trf_9053(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9053(t0,t1,t2);}

C_noret_decl(trf_10943)
static void C_ccall trf_10943(C_word c,C_word *av) C_noret;
static void C_ccall trf_10943(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10943(t0,t1,t2,t3);}

C_noret_decl(trf_10773)
static void C_ccall trf_10773(C_word c,C_word *av) C_noret;
static void C_ccall trf_10773(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10773(t0,t1);}

C_noret_decl(trf_6160)
static void C_ccall trf_6160(C_word c,C_word *av) C_noret;
static void C_ccall trf_6160(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6160(t0,t1);}

C_noret_decl(trf_6740)
static void C_ccall trf_6740(C_word c,C_word *av) C_noret;
static void C_ccall trf_6740(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6740(t0,t1);}

C_noret_decl(trf_6744)
static void C_ccall trf_6744(C_word c,C_word *av) C_noret;
static void C_ccall trf_6744(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6744(t0,t1,t2);}

C_noret_decl(trf_6069)
static void C_ccall trf_6069(C_word c,C_word *av) C_noret;
static void C_ccall trf_6069(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6069(t0,t1);}

C_noret_decl(trf_6045)
static void C_ccall trf_6045(C_word c,C_word *av) C_noret;
static void C_ccall trf_6045(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6045(t0,t1,t2);}

C_noret_decl(trf_15674)
static void C_ccall trf_15674(C_word c,C_word *av) C_noret;
static void C_ccall trf_15674(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_15674(t0,t1,t2,t3);}

C_noret_decl(trf_5941)
static void C_ccall trf_5941(C_word c,C_word *av) C_noret;
static void C_ccall trf_5941(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5941(t0,t1);}

C_noret_decl(trf_14243)
static void C_ccall trf_14243(C_word c,C_word *av) C_noret;
static void C_ccall trf_14243(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14243(t0,t1);}

C_noret_decl(trf_14221)
static void C_ccall trf_14221(C_word c,C_word *av) C_noret;
static void C_ccall trf_14221(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14221(t0,t1);}

C_noret_decl(trf_11366)
static void C_ccall trf_11366(C_word c,C_word *av) C_noret;
static void C_ccall trf_11366(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11366(t0,t1);}

C_noret_decl(trf_4930)
static void C_ccall trf_4930(C_word c,C_word *av) C_noret;
static void C_ccall trf_4930(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4930(t0,t1,t2);}

C_noret_decl(trf_7930)
static void C_ccall trf_7930(C_word c,C_word *av) C_noret;
static void C_ccall trf_7930(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_7930(t0,t1,t2,t3,t4);}

C_noret_decl(trf_12237)
static void C_ccall trf_12237(C_word c,C_word *av) C_noret;
static void C_ccall trf_12237(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12237(t0,t1);}

C_noret_decl(trf_9548)
static void C_ccall trf_9548(C_word c,C_word *av) C_noret;
static void C_ccall trf_9548(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9548(t0,t1,t2);}

C_noret_decl(trf_6453)
static void C_ccall trf_6453(C_word c,C_word *av) C_noret;
static void C_ccall trf_6453(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6453(t0,t1,t2);}

C_noret_decl(trf_12204)
static void C_ccall trf_12204(C_word c,C_word *av) C_noret;
static void C_ccall trf_12204(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_12204(t0,t1,t2);}

C_noret_decl(trf_5283)
static void C_ccall trf_5283(C_word c,C_word *av) C_noret;
static void C_ccall trf_5283(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5283(t0,t1,t2,t3);}

C_noret_decl(trf_15727)
static void C_ccall trf_15727(C_word c,C_word *av) C_noret;
static void C_ccall trf_15727(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_15727(t0,t1,t2);}

C_noret_decl(trf_15799)
static void C_ccall trf_15799(C_word c,C_word *av) C_noret;
static void C_ccall trf_15799(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_15799(t0,t1,t2);}

C_noret_decl(trf_6499)
static void C_ccall trf_6499(C_word c,C_word *av) C_noret;
static void C_ccall trf_6499(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6499(t0,t1,t2);}

C_noret_decl(trf_14991)
static void C_ccall trf_14991(C_word c,C_word *av) C_noret;
static void C_ccall trf_14991(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_14991(t0,t1,t2);}

C_noret_decl(trf_15766)
static void C_ccall trf_15766(C_word c,C_word *av) C_noret;
static void C_ccall trf_15766(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_15766(t0,t1,t2);}

C_noret_decl(trf_14965)
static void C_ccall trf_14965(C_word c,C_word *av) C_noret;
static void C_ccall trf_14965(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14965(t0,t1);}

C_noret_decl(trf_6476)
static void C_ccall trf_6476(C_word c,C_word *av) C_noret;
static void C_ccall trf_6476(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6476(t0,t1,t2);}

C_noret_decl(trf_8292)
static void C_ccall trf_8292(C_word c,C_word *av) C_noret;
static void C_ccall trf_8292(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8292(t0,t1,t2);}

C_noret_decl(trf_11823)
static void C_ccall trf_11823(C_word c,C_word *av) C_noret;
static void C_ccall trf_11823(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11823(t0,t1);}

C_noret_decl(trf_14926)
static void C_ccall trf_14926(C_word c,C_word *av) C_noret;
static void C_ccall trf_14926(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_14926(t0,t1,t2);}

C_noret_decl(trf_10158)
static void C_ccall trf_10158(C_word c,C_word *av) C_noret;
static void C_ccall trf_10158(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10158(t0,t1,t2,t3);}

C_noret_decl(trf_11808)
static void C_ccall trf_11808(C_word c,C_word *av) C_noret;
static void C_ccall trf_11808(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11808(t0,t1);}

C_noret_decl(trf_4953)
static void C_ccall trf_4953(C_word c,C_word *av) C_noret;
static void C_ccall trf_4953(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4953(t0,t1,t2);}

C_noret_decl(trf_14616)
static void C_ccall trf_14616(C_word c,C_word *av) C_noret;
static void C_ccall trf_14616(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_14616(t0,t1,t2);}

C_noret_decl(trf_14914)
static void C_ccall trf_14914(C_word c,C_word *av) C_noret;
static void C_ccall trf_14914(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_14914(t0,t1,t2);}

C_noret_decl(trf_14680)
static void C_ccall trf_14680(C_word c,C_word *av) C_noret;
static void C_ccall trf_14680(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_14680(t0,t1,t2);}

C_noret_decl(trf_14182)
static void C_ccall trf_14182(C_word c,C_word *av) C_noret;
static void C_ccall trf_14182(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14182(t0,t1);}

C_noret_decl(trf_14912)
static void C_ccall trf_14912(C_word c,C_word *av) C_noret;
static void C_ccall trf_14912(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_14912(t0,t1,t2,t3);}

C_noret_decl(trf_14672)
static void C_ccall trf_14672(C_word c,C_word *av) C_noret;
static void C_ccall trf_14672(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14672(t0,t1);}

C_noret_decl(trf_12112)
static void C_ccall trf_12112(C_word c,C_word *av) C_noret;
static void C_ccall trf_12112(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12112(t0,t1);}

C_noret_decl(trf_9497)
static void C_ccall trf_9497(C_word c,C_word *av) C_noret;
static void C_ccall trf_9497(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9497(t0,t1,t2);}

C_noret_decl(trf_13856)
static void C_ccall trf_13856(C_word c,C_word *av) C_noret;
static void C_ccall trf_13856(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13856(t0,t1);}

C_noret_decl(trf_9176)
static void C_ccall trf_9176(C_word c,C_word *av) C_noret;
static void C_ccall trf_9176(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9176(t0,t1,t2,t3);}

C_noret_decl(trf_13337)
static void C_ccall trf_13337(C_word c,C_word *av) C_noret;
static void C_ccall trf_13337(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13337(t0,t1);}

C_noret_decl(trf_13347)
static void C_ccall trf_13347(C_word c,C_word *av) C_noret;
static void C_ccall trf_13347(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_13347(t0,t1,t2);}

C_noret_decl(trf_14640)
static void C_ccall trf_14640(C_word c,C_word *av) C_noret;
static void C_ccall trf_14640(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14640(t0,t1);}

C_noret_decl(trf_5367)
static void C_ccall trf_5367(C_word c,C_word *av) C_noret;
static void C_ccall trf_5367(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5367(t0,t1,t2,t3);}

C_noret_decl(trf_13325)
static void C_ccall trf_13325(C_word c,C_word *av) C_noret;
static void C_ccall trf_13325(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13325(t0,t1);}

C_noret_decl(trf_5010)
static void C_ccall trf_5010(C_word c,C_word *av) C_noret;
static void C_ccall trf_5010(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5010(t0,t1,t2);}

C_noret_decl(trf_5008)
static void C_ccall trf_5008(C_word c,C_word *av) C_noret;
static void C_ccall trf_5008(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5008(t0,t1,t2);}

C_noret_decl(trf_5333)
static void C_ccall trf_5333(C_word c,C_word *av) C_noret;
static void C_ccall trf_5333(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5333(t0,t1,t2,t3);}

C_noret_decl(trf_13380)
static void C_ccall trf_13380(C_word c,C_word *av) C_noret;
static void C_ccall trf_13380(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_13380(t0,t1);}

C_noret_decl(trf_6663)
static void C_ccall trf_6663(C_word c,C_word *av) C_noret;
static void C_ccall trf_6663(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6663(t0,t1);}

C_noret_decl(trf_12930)
static void C_ccall trf_12930(C_word c,C_word *av) C_noret;
static void C_ccall trf_12930(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_12930(t0,t1,t2);}

C_noret_decl(trf_12920)
static void C_ccall trf_12920(C_word c,C_word *av) C_noret;
static void C_ccall trf_12920(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12920(t0,t1);}

C_noret_decl(trf_12908)
static void C_ccall trf_12908(C_word c,C_word *av) C_noret;
static void C_ccall trf_12908(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12908(t0,t1);}

C_noret_decl(trf_10678)
static void C_ccall trf_10678(C_word c,C_word *av) C_noret;
static void C_ccall trf_10678(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10678(t0,t1,t2);}

C_noret_decl(trf_11022)
static void C_ccall trf_11022(C_word c,C_word *av) C_noret;
static void C_ccall trf_11022(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_11022(t0,t1,t2,t3);}

C_noret_decl(trf_11155)
static void C_ccall trf_11155(C_word c,C_word *av) C_noret;
static void C_ccall trf_11155(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11155(t0,t1);}

C_noret_decl(trf_5042)
static void C_ccall trf_5042(C_word c,C_word *av) C_noret;
static void C_ccall trf_5042(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5042(t0,t1,t2);}

C_noret_decl(trf_7804)
static void C_ccall trf_7804(C_word c,C_word *av) C_noret;
static void C_ccall trf_7804(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7804(t0,t1,t2);}

C_noret_decl(trf_12014)
static void C_ccall trf_12014(C_word c,C_word *av) C_noret;
static void C_ccall trf_12014(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12014(t0,t1);}

C_noret_decl(trf_8181)
static void C_ccall trf_8181(C_word c,C_word *av) C_noret;
static void C_ccall trf_8181(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8181(t0,t1,t2);}

C_noret_decl(trf_8885)
static void C_ccall trf_8885(C_word c,C_word *av) C_noret;
static void C_ccall trf_8885(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8885(t0,t1,t2);}

C_noret_decl(trf_10909)
static void C_ccall trf_10909(C_word c,C_word *av) C_noret;
static void C_ccall trf_10909(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10909(t0,t1,t2,t3);}

C_noret_decl(trf_5122)
static void C_ccall trf_5122(C_word c,C_word *av) C_noret;
static void C_ccall trf_5122(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5122(t0,t1);}

C_noret_decl(trf_5126)
static void C_ccall trf_5126(C_word c,C_word *av) C_noret;
static void C_ccall trf_5126(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5126(t0,t1,t2);}

C_noret_decl(trf_14203)
static void C_ccall trf_14203(C_word c,C_word *av) C_noret;
static void C_ccall trf_14203(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14203(t0,t1);}

C_noret_decl(trf_12157)
static void C_ccall trf_12157(C_word c,C_word *av) C_noret;
static void C_ccall trf_12157(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12157(t0,t1);}

C_noret_decl(trf_12041)
static void C_ccall trf_12041(C_word c,C_word *av) C_noret;
static void C_ccall trf_12041(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12041(t0,t1);}

C_noret_decl(trf_9752)
static void C_ccall trf_9752(C_word c,C_word *av) C_noret;
static void C_ccall trf_9752(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9752(t0,t1);}

C_noret_decl(trf_12130)
static void C_ccall trf_12130(C_word c,C_word *av) C_noret;
static void C_ccall trf_12130(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12130(t0,t1);}

C_noret_decl(trf_14728)
static void C_ccall trf_14728(C_word c,C_word *av) C_noret;
static void C_ccall trf_14728(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_14728(t0,t1,t2,t3);}

C_noret_decl(trf_11591)
static void C_ccall trf_11591(C_word c,C_word *av) C_noret;
static void C_ccall trf_11591(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11591(t0,t1,t2);}

C_noret_decl(trf_10314)
static void C_ccall trf_10314(C_word c,C_word *av) C_noret;
static void C_ccall trf_10314(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10314(t0,t1,t2,t3);}

C_noret_decl(trf_12068)
static void C_ccall trf_12068(C_word c,C_word *av) C_noret;
static void C_ccall trf_12068(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12068(t0,t1);}

C_noret_decl(trf_10982)
static void C_ccall trf_10982(C_word c,C_word *av) C_noret;
static void C_ccall trf_10982(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10982(t0,t1,t2,t3);}

C_noret_decl(trf_11946)
static void C_ccall trf_11946(C_word c,C_word *av) C_noret;
static void C_ccall trf_11946(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11946(t0,t1);}

C_noret_decl(trf_5144)
static void C_ccall trf_5144(C_word c,C_word *av) C_noret;
static void C_ccall trf_5144(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5144(t0,t1,t2);}

C_noret_decl(trf_9657)
static void C_ccall trf_9657(C_word c,C_word *av) C_noret;
static void C_ccall trf_9657(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9657(t0,t1,t2);}

C_noret_decl(trf_15829)
static void C_ccall trf_15829(C_word c,C_word *av) C_noret;
static void C_ccall trf_15829(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15829(t0,t1);}

C_noret_decl(trf_8557)
static void C_ccall trf_8557(C_word c,C_word *av) C_noret;
static void C_ccall trf_8557(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8557(t0,t1,t2);}

C_noret_decl(trf_8813)
static void C_ccall trf_8813(C_word c,C_word *av) C_noret;
static void C_ccall trf_8813(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8813(t0,t1);}

C_noret_decl(trf_11964)
static void C_ccall trf_11964(C_word c,C_word *av) C_noret;
static void C_ccall trf_11964(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11964(t0,t1);}

C_noret_decl(trf_10483)
static void C_ccall trf_10483(C_word c,C_word *av) C_noret;
static void C_ccall trf_10483(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10483(t0,t1,t2);}

C_noret_decl(trf_16156)
static void C_ccall trf_16156(C_word c,C_word *av) C_noret;
static void C_ccall trf_16156(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_16156(t0,t1,t2);}

C_noret_decl(trf_11988)
static void C_ccall trf_11988(C_word c,C_word *av) C_noret;
static void C_ccall trf_11988(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11988(t0,t1);}

C_noret_decl(trf_10862)
static void C_ccall trf_10862(C_word c,C_word *av) C_noret;
static void C_ccall trf_10862(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10862(t0,t1);}

C_noret_decl(trf_10206)
static void C_ccall trf_10206(C_word c,C_word *av) C_noret;
static void C_ccall trf_10206(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10206(t0,t1,t2);}

C_noret_decl(trf_14762)
static void C_ccall trf_14762(C_word c,C_word *av) C_noret;
static void C_ccall trf_14762(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14762(t0,t1);}

C_noret_decl(trf_11906)
static void C_ccall trf_11906(C_word c,C_word *av) C_noret;
static void C_ccall trf_11906(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11906(t0,t1);}

C_noret_decl(trf_14032)
static void C_ccall trf_14032(C_word c,C_word *av) C_noret;
static void C_ccall trf_14032(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14032(t0,t1);}

C_noret_decl(trf_9252)
static void C_ccall trf_9252(C_word c,C_word *av) C_noret;
static void C_ccall trf_9252(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9252(t0,t1,t2);}

C_noret_decl(trf_10736)
static void C_ccall trf_10736(C_word c,C_word *av) C_noret;
static void C_ccall trf_10736(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10736(t0,t1);}

C_noret_decl(trf_8828)
static void C_ccall trf_8828(C_word c,C_word *av) C_noret;
static void C_ccall trf_8828(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8828(t0,t1,t2);}

C_noret_decl(trf_10091)
static void C_ccall trf_10091(C_word c,C_word *av) C_noret;
static void C_ccall trf_10091(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10091(t0,t1,t2);}

C_noret_decl(trf_10079)
static void C_ccall trf_10079(C_word c,C_word *av) C_noret;
static void C_ccall trf_10079(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10079(t0,t1,t2);}

C_noret_decl(trf_8593)
static void C_ccall trf_8593(C_word c,C_word *av) C_noret;
static void C_ccall trf_8593(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8593(t0,t1);}

C_noret_decl(trf_8723)
static void C_ccall trf_8723(C_word c,C_word *av) C_noret;
static void C_ccall trf_8723(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8723(t0,t1,t2);}

C_noret_decl(trf_14608)
static void C_ccall trf_14608(C_word c,C_word *av) C_noret;
static void C_ccall trf_14608(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14608(t0,t1);}

C_noret_decl(trf_7658)
static void C_ccall trf_7658(C_word c,C_word *av) C_noret;
static void C_ccall trf_7658(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7658(t0,t1);}

C_noret_decl(trf_5539)
static void C_ccall trf_5539(C_word c,C_word *av) C_noret;
static void C_ccall trf_5539(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5539(t0,t1,t2);}

C_noret_decl(trf_9005)
static void C_ccall trf_9005(C_word c,C_word *av) C_noret;
static void C_ccall trf_9005(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9005(t0,t1,t2,t3);}

C_noret_decl(trf_5568)
static void C_ccall trf_5568(C_word c,C_word *av) C_noret;
static void C_ccall trf_5568(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5568(t0,t1);}

C_noret_decl(trf_5561)
static void C_ccall trf_5561(C_word c,C_word *av) C_noret;
static void C_ccall trf_5561(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5561(t0,t1);}

C_noret_decl(trf_10046)
static void C_ccall trf_10046(C_word c,C_word *av) C_noret;
static void C_ccall trf_10046(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10046(t0,t1,t2);}

C_noret_decl(trf_7770)
static void C_ccall trf_7770(C_word c,C_word *av) C_noret;
static void C_ccall trf_7770(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7770(t0,t1,t2);}

C_noret_decl(trf_7039)
static void C_ccall trf_7039(C_word c,C_word *av) C_noret;
static void C_ccall trf_7039(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7039(t0,t1,t2);}

C_noret_decl(trf_15905)
static void C_ccall trf_15905(C_word c,C_word *av) C_noret;
static void C_ccall trf_15905(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_15905(t0,t1);}

C_noret_decl(trf_10554)
static void C_ccall trf_10554(C_word c,C_word *av) C_noret;
static void C_ccall trf_10554(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10554(t0,t1,t2);}

C_noret_decl(trf_9309)
static void C_ccall trf_9309(C_word c,C_word *av) C_noret;
static void C_ccall trf_9309(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9309(t0,t1,t2);}

C_noret_decl(trf_9820)
static void C_ccall trf_9820(C_word c,C_word *av) C_noret;
static void C_ccall trf_9820(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9820(t0,t1,t2);}

C_noret_decl(trf_11783)
static void C_ccall trf_11783(C_word c,C_word *av) C_noret;
static void C_ccall trf_11783(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11783(t0,t1,t2);}

C_noret_decl(trf_8080)
static void C_ccall trf_8080(C_word c,C_word *av) C_noret;
static void C_ccall trf_8080(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8080(t0,t1);}

C_noret_decl(trf_9875)
static void C_ccall trf_9875(C_word c,C_word *av) C_noret;
static void C_ccall trf_9875(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9875(t0,t1,t2,t3);}

C_noret_decl(trf_8094)
static void C_ccall trf_8094(C_word c,C_word *av) C_noret;
static void C_ccall trf_8094(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8094(t0,t1,t2);}

C_noret_decl(trf_11745)
static void C_ccall trf_11745(C_word c,C_word *av) C_noret;
static void C_ccall trf_11745(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11745(t0,t1,t2);}

C_noret_decl(trf_6808)
static void C_ccall trf_6808(C_word c,C_word *av) C_noret;
static void C_ccall trf_6808(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6808(t0,t1,t2);}

C_noret_decl(trf_7063)
static void C_ccall trf_7063(C_word c,C_word *av) C_noret;
static void C_ccall trf_7063(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7063(t0,t1);}

C_noret_decl(trf_10617)
static void C_ccall trf_10617(C_word c,C_word *av) C_noret;
static void C_ccall trf_10617(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10617(t0,t1,t2);}

C_noret_decl(trf_7743)
static void C_ccall trf_7743(C_word c,C_word *av) C_noret;
static void C_ccall trf_7743(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7743(t0,t1,t2);}

C_noret_decl(trf_6201)
static void C_ccall trf_6201(C_word c,C_word *av) C_noret;
static void C_ccall trf_6201(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6201(t0,t1,t2);}

C_noret_decl(trf_7142)
static void C_ccall trf_7142(C_word c,C_word *av) C_noret;
static void C_ccall trf_7142(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7142(t0,t1);}

C_noret_decl(trf_15518)
static void C_ccall trf_15518(C_word c,C_word *av) C_noret;
static void C_ccall trf_15518(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_15518(t0,t1,t2);}

C_noret_decl(trf_10368)
static void C_ccall trf_10368(C_word c,C_word *av) C_noret;
static void C_ccall trf_10368(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10368(t0,t1,t2);}

C_noret_decl(trf_15552)
static void C_ccall trf_15552(C_word c,C_word *av) C_noret;
static void C_ccall trf_15552(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_15552(t0,t1,t2);}

C_noret_decl(trf_5485)
static void C_ccall trf_5485(C_word c,C_word *av) C_noret;
static void C_ccall trf_5485(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5485(t0,t1,t2,t3);}

C_noret_decl(trf_8489)
static void C_ccall trf_8489(C_word c,C_word *av) C_noret;
static void C_ccall trf_8489(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8489(t0,t1,t2);}

C_noret_decl(trf_8426)
static void C_ccall trf_8426(C_word c,C_word *av) C_noret;
static void C_ccall trf_8426(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8426(t0,t1,t2);}

C_noret_decl(trf_6846)
static void C_ccall trf_6846(C_word c,C_word *av) C_noret;
static void C_ccall trf_6846(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6846(t0,t1);}

C_noret_decl(trf_5707)
static void C_ccall trf_5707(C_word c,C_word *av) C_noret;
static void C_ccall trf_5707(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5707(t0,t1);}

C_noret_decl(trf_6911)
static void C_ccall trf_6911(C_word c,C_word *av) C_noret;
static void C_ccall trf_6911(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6911(t0,t1);}

C_noret_decl(trf_12896)
static void C_ccall trf_12896(C_word c,C_word *av) C_noret;
static void C_ccall trf_12896(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_12896(t0,t1);}

C_noret_decl(trf_5754)
static void C_ccall trf_5754(C_word c,C_word *av) C_noret;
static void C_ccall trf_5754(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5754(t0,t1,t2);}

C_noret_decl(trf_14107)
static void C_ccall trf_14107(C_word c,C_word *av) C_noret;
static void C_ccall trf_14107(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_14107(t0,t1);}

C_noret_decl(trf_15147)
static void C_ccall trf_15147(C_word c,C_word *av) C_noret;
static void C_ccall trf_15147(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_15147(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5262)
static void C_ccall trf_5262(C_word c,C_word *av) C_noret;
static void C_ccall trf_5262(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5262(t0,t1);}

C_noret_decl(trf_6985)
static void C_ccall trf_6985(C_word c,C_word *av) C_noret;
static void C_ccall trf_6985(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6985(t0,t1);}

/* k6989 in k6983 in k6946 in k6909 in k6862 in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6991(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_6991,2,av);}
a=C_alloc(3);
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
t5=C_slot(t4,C_fix(2));
t6=C_a_i_cons(&a,2,t3,t5);
/* support.scm:494: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[3];
av2[2]=t6;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k5778 in fold in k5750 in fold-inner in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5780(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5780,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_a_i_list2(&a,2,t1,t3);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t4;
C_apply(4,av2);}}

/* make-node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7499(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_7499,5,av);}
a=C_alloc(5);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_record4(&a,4,lf[211],t2,t3,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7497(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word *a;
if(!C_demand(C_calculate_demand(135,c,8))){C_save_and_reclaim((void *)f_7497,2,av);}
a=C_alloc(135);
t2=C_mutate2((C_word*)lf[210]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7499,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate2((C_word*)lf[220]+1 /* (set! ##compiler#varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7505,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate2((C_word*)lf[222]+1 /* (set! ##compiler#qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7520,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate2((C_word*)lf[223]+1 /* (set! ##compiler#build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7535,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2((C_word*)lf[263]+1 /* (set! ##compiler#build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8773,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate2((C_word*)lf[279]+1 /* (set! ##compiler#fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9651,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate2((C_word*)lf[281]+1 /* (set! ##compiler#inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9701,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate2((C_word*)lf[286]+1 /* (set! ##compiler#copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9854,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate2((C_word*)lf[290]+1 /* (set! ##compiler#tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10362,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate2((C_word*)lf[291]+1 /* (set! ##compiler#copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10392,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate2((C_word*)lf[292]+1 /* (set! ##compiler#node->sexpr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10431,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2((C_word*)lf[293]+1 /* (set! ##compiler#sexpr->node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10517,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate2((C_word*)lf[294]+1 /* (set! ##compiler#emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10588,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2((C_word*)lf[314]+1 /* (set! ##compiler#load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10850,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate2((C_word*)lf[316]+1 /* (set! ##compiler#match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10906,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate2((C_word*)lf[319]+1 /* (set! ##compiler#expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11123,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate2((C_word*)lf[323]+1 /* (set! ##compiler#simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11232,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate2((C_word*)lf[324]+1 /* (set! ##compiler#dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11353,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate2((C_word*)lf[326]+1 /* (set! ##compiler#dump-defined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11394,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate2((C_word*)lf[327]+1 /* (set! ##compiler#dump-global-refs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11431,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate2((C_word*)lf[328]+1 /* (set! ##sys#toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11480,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate2((C_word*)lf[331]+1 /* (set! ##compiler#compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11501,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate2((C_word*)lf[334]+1 /* (set! ##compiler#print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11614,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate2((C_word*)lf[344]+1 /* (set! ##compiler#pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11713,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate2((C_word*)lf[349]+1 /* (set! ##compiler#foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11771,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate2((C_word*)lf[434]+1 /* (set! ##compiler#foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12764,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate2((C_word*)lf[435]+1 /* (set! ##compiler#foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12795,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate2((C_word*)lf[436]+1 /* (set! ##compiler#final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12826,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate2((C_word*)lf[438]+1 /* (set! ##compiler#estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12871,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate2((C_word*)lf[443]+1 /* (set! ##compiler#estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13303,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate2((C_word*)lf[446]+1 /* (set! ##compiler#finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13736,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate2((C_word*)lf[460]+1 /* (set! ##compiler#foreign-type->scrutiny-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14004,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate2((C_word*)lf[480]+1 /* (set! ##compiler#scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14570,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate2((C_word*)lf[481]+1 /* (set! ##compiler#scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14725,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate2((C_word*)lf[483]+1 /* (set! ##compiler#chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14955,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate2((C_word*)lf[486]+1 /* (set! ##compiler#chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14982,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate2((C_word*)lf[487]+1 /* (set! ##compiler#make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15022,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate2((C_word*)lf[489]+1 /* (set! ##compiler#block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15028,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate2((C_word*)lf[490]+1 /* (set! ##compiler#block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15034,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate2((C_word*)lf[492]+1 /* (set! ##compiler#make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15043,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate2((C_word*)lf[495]+1 /* (set! ##compiler#set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15092,tmp=(C_word)a,a+=2,tmp));
t43=C_set_block_item(lf[497] /* real-name-max-depth */,0,C_fix(20));
t44=C_mutate2((C_word*)lf[47]+1 /* (set! ##compiler#real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15099,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate2((C_word*)lf[503]+1 /* (set! ##compiler#real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15219,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate2((C_word*)lf[504]+1 /* (set! ##compiler#display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15231,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate2((C_word*)lf[505]+1 /* (set! ##compiler#source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15255,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate2((C_word*)lf[511]+1 /* (set! ##compiler#source-info->line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15289,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate2((C_word*)lf[512]+1 /* (set! ##compiler#call-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15307,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate2((C_word*)lf[515]+1 /* (set! ##compiler#constant-form-eval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15344,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate2((C_word*)lf[518]+1 /* (set! ##compiler#encodeable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15586,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate2((C_word*)lf[525]+1 /* (set! ##compiler#dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15665,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate2((C_word*)lf[527]+1 /* (set! ##compiler#read-info-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15822,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate2((C_word*)lf[531]+1 /* (set! ##compiler#read/source-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15865,tmp=(C_word)a,a+=2,tmp));
t55=*((C_word*)lf[533]+1);
t56=C_mutate2((C_word*)lf[533]+1 /* (set! ##sys#user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15871,a[2]=t55,tmp=(C_word)a,a+=3,tmp));
t57=C_mutate2((C_word*)lf[536]+1 /* (set! ##compiler#scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15896,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate2((C_word*)lf[102]+1 /* (set! ##compiler#big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15965,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate2((C_word*)lf[329]+1 /* (set! ##compiler#hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15989,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate2((C_word*)lf[541]+1 /* (set! ##compiler#export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16009,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate2((C_word*)lf[543]+1 /* (set! ##compiler#variable-hidden? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16029,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate2((C_word*)lf[313]+1 /* (set! ##compiler#variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16039,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate2((C_word*)lf[545]+1 /* (set! ##compiler#mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16064,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate2((C_word*)lf[546]+1 /* (set! ##compiler#variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16079,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate2((C_word*)lf[547]+1 /* (set! ##compiler#intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16085,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate2((C_word*)lf[548]+1 /* (set! foldable? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16096,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate2((C_word*)lf[549]+1 /* (set! ##compiler#load-identifier-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16107,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate2((C_word*)lf[557]+1 /* (set! ##compiler#print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16205,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate2((C_word*)lf[560]+1 /* (set! ##compiler#print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16230,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate2((C_word*)lf[562]+1 /* (set! ##compiler#print-debug-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16242,tmp=(C_word)a,a+=2,tmp));
t71=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t71;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t71+1)))(2,av2);}}

/* k14572 in scan-used-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14574(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_14574,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* walk in scan-used-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14576(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_14576,3,av);}
a=C_alloc(10);
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(1));
t8=C_eqp(t7,lf[221]);
t9=(C_truep(t8)?t8:C_eqp(t7,lf[246]));
if(C_truep(t9)){
t10=t2;
t11=C_slot(t10,C_fix(2));
t12=C_i_car(t11);
t13=t12;
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14608,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14640,a[2]=t13,a[3]=((C_word*)t0)[3],a[4]=t14,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_memq(t13,((C_word*)t0)[4]))){
t16=C_i_memq(t13,((C_word*)((C_word*)t0)[3])[1]);
t17=t15;
f_14640(t17,C_i_not(t16));}
else{
t16=t15;
f_14640(t16,C_SCHEME_FALSE);}}
else{
t10=C_eqp(t7,lf[97]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14672,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t10)){
t12=t11;
f_14672(t12,t10);}
else{
t12=C_eqp(t7,lf[226]);
t13=t11;
f_14672(t13,(C_truep(t12)?t12:C_eqp(t7,lf[241])));}}}

/* ##compiler#scan-used-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14570(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_14570,4,av);}
a=C_alloc(13);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14574,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14576,a[2]=t8,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t6;
av2[2]=t2;
f_14576(3,av2);}}

/* ##compiler#final-foreign-type in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_12826(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_12826,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12832,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12865,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1160: follow-without-loop */
t5=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k15116 in real-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15118(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_15118,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15214,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1439: ##sys#symbol->qualified-string */
t5=*((C_word*)lf[254]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
/* support.scm:1453: ##sys#symbol->qualified-string */
t2=*((C_word*)lf[254]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}
else{
/* support.scm:1436: ##sys#symbol->qualified-string */
t2=*((C_word*)lf[254]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k15110 in k15104 in resolve in real-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15112(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_15112,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=(C_truep(t1)?t1:((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k15182 in k15169 in loop in k15143 in k15212 in k15116 in real-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15184(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_15184,2,av);}
/* support.scm:1448: string-intersperse */
t2=*((C_word*)lf[498]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[501];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6946 in k6909 in k6862 in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_6948(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_6948,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:492: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[167];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6985,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[169]);
t4=t2;
f_6985(t4,C_i_not(t3));}
else{
t3=t2;
f_6985(t3,C_SCHEME_FALSE);}}}

/* g2862 in k12834 in a12831 in final-foreign-type in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_12840(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_12840,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1165: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t2;
/* support.scm:1165: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k8605 in k8598 in k8591 in a8531 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_8607,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list2(&a,2,((C_word*)t0)[3],t1);
f_8597(2,av2);}}

/* k8598 in k8591 in a8531 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8600(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_8600,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t1;
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list2(&a,2,((C_word*)t0)[3],t3);
f_8597(2,av2);}}
else{
/* support.scm:614: ##sys#symbol->qualified-string */
t3=*((C_word*)lf[254]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k15169 in loop in k15143 in k15212 in k15116 in real-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_15171,2,av);}
a=C_alloc(8);
t2=C_eqp(t1,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15184,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1448: reverse */
t4=*((C_word*)lf[91]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15203,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* support.scm:1449: symbol->string */
t4=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k6952 in k6946 in k6909 in k6862 in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6954(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_6954,2,av);}
a=C_alloc(3);
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
t5=C_slot(t4,C_fix(2));
t6=C_a_i_cons(&a,2,t3,t5);
/* support.scm:492: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[3];
av2[2]=t6;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* a12831 in final-foreign-type in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_12832(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_12832,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12836,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(t2))){
/* support.scm:1163: ##sys#hash-table-ref */
t5=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[397]+1);
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_12836(2,av2);}}}

/* k12834 in a12831 in final-foreign-type in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_12836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_12836,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12840,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1162: g2862 */
t3=t2;
f_12840(t3,((C_word*)t0)[3],t1);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7897 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7899(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,1))){C_save_and_reclaim((void *)f_7899,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[236],((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5245 in loop in map-llist in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5247,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5251,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:134: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5224(t6,t3,t5);}

/* a12864 in final-foreign-type in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_12865(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_12865,2,av);}
/* support.scm:1167: quit */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[437];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k7863 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7865(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,1))){C_save_and_reclaim((void *)f_7865,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[235],((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k8315 in map-loop1275 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8317(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8317,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8292(t6,((C_word*)t0)[5],t5);}

/* ##compiler#close-checked-input-file in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5726(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5726,4,av);}
if(C_truep(C_i_string_equal_p(t3,lf[88]))){
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
/* support.scm:227: close-input-port */
t4=*((C_word*)lf[89]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* ##compiler#build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7535(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_7535,3,av);}
a=C_alloc(12);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7538,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8762,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:618: walk */
t9=((C_word*)t6)[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=t2;
f_7538(3,av2);}}

/* walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7538(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(21,c,3))){C_save_and_reclaim((void *)f_7538,3,av);}
a=C_alloc(21);
if(C_truep(C_i_symbolp(t2))){
/* support.scm:524: varnode */
t3=*((C_word*)lf[220]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t2;
if(C_truep(C_i_structurep(t3,lf[211]))){
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_not_pair_p(t2))){
/* support.scm:526: bomb */
t4=*((C_word*)lf[3]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[224];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=C_i_car(t2);
if(C_truep(C_i_symbolp(t4))){
t5=t2;
t6=C_u_i_car(t5);
t7=C_eqp(t6,lf[225]);
t8=(C_truep(t7)?t7:C_eqp(t6,lf[226]));
if(C_truep(t8)){
t9=t2;
t10=C_u_i_car(t9);
t11=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t12=t11;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=((C_word*)t13)[1];
t15=((C_word*)((C_word*)t0)[2])[1];
t16=t2;
t17=C_u_i_cdr(t16);
t18=C_i_check_list_2(t17,lf[161]);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7605,a[2]=t1,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7607,a[2]=t13,a[3]=t21,a[4]=t15,a[5]=t14,tmp=(C_word)a,a+=6,tmp));
t23=((C_word*)t21)[1];
f_7607(t23,t19,t17);}
else{
t9=C_eqp(t6,lf[97]);
if(C_truep(t9)){
t10=C_i_cadr(t2);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7658,a[2]=t1,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_numberp(t11))){
t13=C_eqp(lf[230],*((C_word*)lf[231]+1));
if(C_truep(t13)){
t14=C_i_integerp(t11);
t15=t12;
f_7658(t15,C_i_not(t14));}
else{
t14=t12;
f_7658(t14,C_SCHEME_FALSE);}}
else{
t13=t12;
f_7658(t13,C_SCHEME_FALSE);}}
else{
t10=C_eqp(t6,lf[109]);
if(C_truep(t10)){
t11=C_i_cadr(t2);
t12=C_i_caddr(t2);
t13=t12;
if(C_truep(C_i_nullp(t11))){
/* support.scm:544: walk */
t39=t1;
t40=t13;
t1=t39;
t2=t40;
c=3;
goto loop;}
else{
t14=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t15=t14;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=((C_word*)t16)[1];
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7731,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t13,a[6]=t16,a[7]=t17,tmp=(C_word)a,a+=8,tmp);
/* support.scm:550: unzip1 */
t19=*((C_word*)lf[234]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t19;
av2[1]=t18;
av2[2]=t11;
((C_proc)(void*)(*((C_word*)t19+1)))(3,av2);}}}
else{
t11=C_eqp(t6,lf[235]);
t12=(C_truep(t11)?t11:C_eqp(t6,lf[133]));
if(C_truep(t12)){
t13=C_i_cadr(t2);
t14=C_a_i_list1(&a,1,t13);
t15=t14;
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7865,a[2]=t1,a[3]=t15,tmp=(C_word)a,a+=4,tmp);
t17=C_i_caddr(t2);
/* support.scm:554: walk */
t39=t16;
t40=t17;
t1=t39;
t2=t40;
c=3;
goto loop;}
else{
t13=C_eqp(t6,lf[236]);
if(C_truep(t13)){
t14=C_i_cadr(t2);
t15=C_i_caddr(t2);
t16=C_a_i_list2(&a,2,t14,t15);
t17=t16;
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7899,a[2]=t1,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
t19=C_i_cadddr(t2);
/* support.scm:558: walk */
t39=t18;
t40=t19;
t1=t39;
t2=t40;
c=3;
goto loop;}
else{
t14=C_eqp(t6,lf[237]);
if(C_truep(t14)){
t15=C_i_cdddr(t2);
t16=t15;
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8053,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=t2;
t19=C_u_i_cdr(t18);
t20=C_u_i_cdr(t19);
t21=C_u_i_car(t20);
/* support.scm:561: walk */
t39=t17;
t40=t21;
t1=t39;
t2=t40;
c=3;
goto loop;}
else{
t15=C_eqp(t6,lf[241]);
if(C_truep(t15)){
t16=C_i_cadr(t2);
t17=t2;
t18=C_u_i_car(t17);
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8080,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t18,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t16))){
t20=C_u_i_car(t16);
t21=C_eqp(lf[97],t20);
if(C_truep(t21)){
t22=C_i_cadr(t16);
t23=t19;
f_8080(t23,C_a_i_list1(&a,1,t22));}
else{
t22=t19;
f_8080(t22,C_a_i_list1(&a,1,t16));}}
else{
t20=t19;
f_8080(t20,C_a_i_list1(&a,1,t16));}}
else{
t16=C_eqp(t6,lf[242]);
t17=(C_truep(t16)?t16:C_eqp(t6,lf[243]));
if(C_truep(t17)){
t18=t2;
t19=C_u_i_car(t18);
t20=C_i_cadr(t2);
t21=C_a_i_list1(&a,1,t20);
t22=t21;
t23=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t24=t23;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=((C_word*)t25)[1];
t27=((C_word*)((C_word*)t0)[2])[1];
t28=t2;
t29=C_u_i_cdr(t28);
t30=C_u_i_cdr(t29);
t31=C_i_check_list_2(t30,lf[161]);
t32=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8179,a[2]=t1,a[3]=t19,a[4]=t22,tmp=(C_word)a,a+=5,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_set_block_item(t34,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8181,a[2]=t25,a[3]=t34,a[4]=t27,a[5]=t26,tmp=(C_word)a,a+=6,tmp));
t36=((C_word*)t34)[1];
f_8181(t36,t32,t30);}
else{
t18=C_eqp(t6,lf[244]);
if(C_truep(t18)){
t19=t2;
t20=C_u_i_car(t19);
t21=t2;
t22=C_u_i_cdr(t21);
t23=t1;
t24=t23;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t24;
av2[1]=C_a_i_record4(&a,4,lf[211],t20,t22,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t24+1)))(2,av2);}}
else{
t19=C_eqp(t6,lf[245]);
if(C_truep(t19)){
t20=C_i_cadr(t2);
t21=C_a_i_list2(&a,2,t20,C_SCHEME_TRUE);
t22=t1;
t23=t22;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t23;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[245],t21,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t23+1)))(2,av2);}}
else{
t20=C_eqp(t6,lf[246]);
t21=(C_truep(t20)?t20:C_eqp(t6,lf[247]));
if(C_truep(t21)){
t22=C_i_cadr(t2);
t23=C_a_i_list1(&a,1,t22);
t24=t23;
t25=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t26=t25;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=((C_word*)t27)[1];
t29=((C_word*)((C_word*)t0)[2])[1];
t30=t2;
t31=C_u_i_cdr(t30);
t32=C_u_i_cdr(t31);
t33=C_i_check_list_2(t32,lf[161]);
t34=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8290,a[2]=t1,a[3]=t24,tmp=(C_word)a,a+=4,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_set_block_item(t36,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8292,a[2]=t27,a[3]=t36,a[4]=t29,a[5]=t28,tmp=(C_word)a,a+=6,tmp));
t38=((C_word*)t36)[1];
f_8292(t38,t34,t32);}
else{
t22=C_eqp(t6,lf[248]);
if(C_truep(t22)){
t23=C_i_cadr(t2);
t24=C_i_cadr(t23);
t25=t24;
t26=C_i_caddr(t2);
t27=C_i_cadr(t26);
t28=t27;
t29=C_i_cadddr(t2);
t30=C_i_cadr(t29);
t31=t30;
t32=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8377,a[2]=t25,a[3]=t28,a[4]=t31,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm:596: fifth */
t33=*((C_word*)lf[250]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t33;
av2[1]=t32;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t33+1)))(3,av2);}}
else{
t23=C_eqp(t6,lf[251]);
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8398,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t6,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t23)){
t25=t24;
f_8398(t25,t23);}
else{
t25=C_eqp(t6,lf[257]);
if(C_truep(t25)){
t26=t24;
f_8398(t26,t25);}
else{
t26=C_eqp(t6,lf[258]);
if(C_truep(t26)){
t27=t24;
f_8398(t27,t26);}
else{
t27=C_eqp(t6,lf[259]);
t28=t24;
f_8398(t28,(C_truep(t27)?t27:C_eqp(t6,lf[260])));}}}}}}}}}}}}}}}}
else{
t5=C_a_i_list1(&a,1,C_SCHEME_FALSE);
t6=t5;
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=((C_word*)((C_word*)t0)[2])[1];
t12=t2;
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8721,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8723,a[2]=t9,a[3]=t15,a[4]=t11,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_8723(t17,t13,t12);}}}}}

/* k12885 in a12876 in estimate-foreign-result-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_12887(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_12887,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[380]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_12896(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[383]);
if(C_truep(t4)){
t5=t3;
f_12896(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[377]);
if(C_truep(t5)){
t6=t3;
f_12896(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[379]);
if(C_truep(t6)){
t7=t3;
f_12896(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[384]);
if(C_truep(t7)){
t8=t3;
f_12896(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[3],lf[400]);
if(C_truep(t8)){
t9=t3;
f_12896(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[3],lf[398]);
if(C_truep(t9)){
t10=t3;
f_12896(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[3],lf[401]);
if(C_truep(t10)){
t11=t3;
f_12896(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[3],lf[402]);
if(C_truep(t11)){
t12=t3;
f_12896(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[3],lf[399]);
if(C_truep(t12)){
t13=t3;
f_12896(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[3],lf[403]);
t14=t3;
f_12896(t14,(C_truep(t13)?t13:C_eqp(((C_word*)t0)[3],lf[404])));}}}}}}}}}}}}

/* k12309 in k12235 in k12198 in k12155 in k12110 in k12066 in k12039 in k12012 in k11986 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 in ... */
static void C_ccall f_12311(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(42,c,1))){C_save_and_reclaim((void *)f_12311,2,av);}
a=C_alloc(42);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=(C_truep(*((C_word*)lf[352]+1))?t1:C_a_i_list(&a,2,lf[360],t1));
t5=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[225],t1,t4,t5);
t7=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[109],t3,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k10229 in map-loop1938 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10231(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_10231,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10206(t6,((C_word*)t0)[5],t5);}

/* ##compiler#estimate-foreign-result-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_12871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_12871,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12877,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13297,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1173: follow-without-loop */
t5=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k9422 in k9415 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,3))){C_save_and_reclaim((void *)f_9424,2,av);}
a=C_alloc(19);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)((C_word*)t0)[2])[1];
t8=C_u_i_cdr(((C_word*)t0)[3]);
t9=C_i_check_list_2(t8,lf[161]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9435,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9437,a[2]=t5,a[3]=t12,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_9437(t14,t10,t8);}

/* a12876 in estimate-foreign-result-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_12877(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_12877,4,av);}
a=C_alloc(6);
t4=t2;
t5=C_eqp(t4,lf[350]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12887,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_12887(t7,t5);}
else{
t7=C_eqp(t4,lf[354]);
if(C_truep(t7)){
t8=t6;
f_12887(t8,t7);}
else{
t8=C_eqp(t4,lf[427]);
if(C_truep(t8)){
t9=t6;
f_12887(t9,t8);}
else{
t9=C_eqp(t4,lf[439]);
if(C_truep(t9)){
t10=t6;
f_12887(t10,t9);}
else{
t10=C_eqp(t4,lf[440]);
if(C_truep(t10)){
t11=t6;
f_12887(t11,t10);}
else{
t11=C_eqp(t4,lf[428]);
if(C_truep(t11)){
t12=t6;
f_12887(t12,t11);}
else{
t12=C_eqp(t4,lf[441]);
if(C_truep(t12)){
t13=t6;
f_12887(t13,t12);}
else{
t13=C_eqp(t4,lf[351]);
if(C_truep(t13)){
t14=t6;
f_12887(t14,t13);}
else{
t14=C_eqp(t4,lf[426]);
if(C_truep(t14)){
t15=t6;
f_12887(t15,t14);}
else{
t15=C_eqp(t4,lf[429]);
if(C_truep(t15)){
t16=t6;
f_12887(t16,t15);}
else{
t16=C_eqp(t4,lf[430]);
if(C_truep(t16)){
t17=t6;
f_12887(t17,t16);}
else{
t17=C_eqp(t4,lf[431]);
t18=t6;
f_12887(t18,(C_truep(t17)?t17:C_eqp(t4,lf[432])));}}}}}}}}}}}}

/* ##compiler#compiler-cleanup-hook in k4827 in k4824 in k4821 */
static void C_ccall f_4833(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4833,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* map-loop1699 in k9422 in k9415 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_9437(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_9437,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9462,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:671: g1705 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9433 in k9422 in k9415 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9435(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_9435,2,av);}
/* support.scm:671: cons* */
t2=*((C_word*)lf[270]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* ##compiler#bomb in k4827 in k4824 in k4821 */
static void C_ccall f_4838(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,3))){
C_save_and_reclaim((void*)f_4838,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4852,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* support.scm:49: string-append */
t6=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=lf[6];
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
/* support.scm:50: error */
t3=*((C_word*)lf[4]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[7];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k8359 in k8375 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8361(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_8361,2,av);}
/* support.scm:597: walk */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
f_7538(3,av2);}}

/* k8355 in k8375 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8357(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,1))){C_save_and_reclaim((void *)f_8357,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[248],((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k7603 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7605(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_7605,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],C_SCHEME_END_OF_LIST,t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1062 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_7607(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_7607,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7632,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:529: g1068 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* resolve in real-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_15102(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_15102,2,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15106,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1430: ##sys#hash-table-ref */
t4=*((C_word*)lf[149]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[496]+1);
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k15104 in resolve in real-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15106(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_15106,2,av);}
a=C_alloc(4);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15112,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1432: ##sys#hash-table-ref */
t4=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[496]+1);
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* loop in map-llist in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5224(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_5224,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
/* support.scm:133: proc */
t3=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5247,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* support.scm:134: proc */
t5=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}}

/* map-llist in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5218,4,av);}
a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5224,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5224(t7,t1,t3);}

/* ##compiler#emit-syntax-trace-info in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5215(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5215,4,av);}
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_emit_syntax_trace_info(t2,t3,*((C_word*)lf[37]+1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k14866 in a14855 in k14760 in walk in scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_14868,2,av);}
/* support.scm:1370: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_14728(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_8398(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(!C_demand(C_calculate_demand(20,0,4))){
C_save_and_reclaim_args((void *)trf_8398,2,t0,t1);}
a=C_alloc(20);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_i_cadr(((C_word*)t0)[2]);
t5=t4;
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=((C_word*)((C_word*)t0)[3])[1];
t11=((C_word*)t0)[2];
t12=C_u_i_cdr(t11);
t13=C_u_i_cdr(t12);
t14=C_i_check_list_2(t13,lf[161]);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8424,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8426,a[2]=t8,a[3]=t17,a[4]=t10,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t19=((C_word*)t17)[1];
f_8426(t19,t15,t13);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[252]);
if(C_truep(t2)){
t3=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t4=t3;
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=((C_word*)((C_word*)t0)[3])[1];
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
t12=C_i_check_list_2(t11,lf[161]);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8487,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8489,a[2]=t7,a[3]=t15,a[4]=t9,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_8489(t17,t13,t11);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8526,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* support.scm:604: ##sys#call-with-values */{
C_word av2[4];
av2[0]=0;
av2[1]=((C_word*)t0)[4];
av2[2]=t3;
av2[3]=t4;
C_call_with_values(4,av2);}}}}

/* k9404 in loop in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_9406,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:669: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9365(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* k10263 in k10248 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10265(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_10265,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop2044 in k10248 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10267(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_10267,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10292,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:754: g2050 */
t5=((C_word*)t0)[4];
f_10255(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9415 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_9417(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(21,0,3))){
C_save_and_reclaim_args((void *)trf_9417,2,t0,t1);}
a=C_alloc(21);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* support.scm:671: walk */
t4=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
f_8779(3,av2);}}
else{
t2=C_eqp(((C_word*)t0)[7],lf[251]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[7],lf[273]));
if(C_truep(t3)){
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=((C_word*)((C_word*)t0)[2])[1];
t9=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9495,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9497,a[2]=t6,a[3]=t12,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_9497(t14,t10,((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9536,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=((C_word*)((C_word*)t0)[2])[1];
t10=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9546,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9548,a[2]=t7,a[3]=t13,a[4]=t9,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_9548(t15,t11,((C_word*)t0)[3]);}}}

/* foldable? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16096(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_16096,3,av);}
/* tweaks.scm:57: ##sys#get */
t3=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[145];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a4893 in text in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4894(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4894,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4898,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:66: display */
t3=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* a14855 in k14760 in walk in scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14856(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_14856,5,av);}
a=C_alloc(5);
t5=C_i_car(((C_word*)t0)[2]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14868,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1370: append */
t8=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k4896 in a4893 in text in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4898(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_4898,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4910,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:68: display */
t4=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[22];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
/* support.scm:72: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a11399 in dump-defined-globals in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11400(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_11400,4,av);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11407,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11429,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:916: keyword? */
t6=*((C_word*)lf[325]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k11405 in a11399 in dump-defined-globals in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_11407(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_11407,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11410,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:919: write */
t3=*((C_word*)lf[207]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word *a;
if(!C_demand(C_calculate_demand(61,c,5))){C_save_and_reclaim((void *)f_4863,2,av);}
a=C_alloc(61);
t2=C_mutate2((C_word*)lf[8]+1 /* (set! ##compiler#collected-debugging-output ...) */,t1);
t3=C_mutate2((C_word*)lf[9]+1 /* (set! +logged-debugging-modes+ ...) */,lf[10]);
t4=C_mutate2((C_word*)lf[11]+1 /* (set! test-debugging-mode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4866,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate2((C_word*)lf[14]+1 /* (set! ##compiler#debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4885,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2((C_word*)lf[26]+1 /* (set! ##compiler#with-debugging-output ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5005,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate2((C_word*)lf[29]+1 /* (set! ##compiler#quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5102,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate2((C_word*)lf[33]+1 /* (set! ##sys#syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5118,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate2((C_word*)lf[42]+1 /* (set! syntax-error ...) */,*((C_word*)lf[33]+1));
t10=C_mutate2((C_word*)lf[43]+1 /* (set! ##compiler#emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5215,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate2((C_word*)lf[44]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5218,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate2((C_word*)lf[45]+1 /* (set! ##compiler#check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5259,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2((C_word*)lf[48]+1 /* (set! ##compiler#posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5327,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate2((C_word*)lf[49]+1 /* (set! ##compiler#posv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5361,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2((C_word*)lf[50]+1 /* (set! ##compiler#stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5395,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate2((C_word*)lf[55]+1 /* (set! ##compiler#symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5425,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate2((C_word*)lf[57]+1 /* (set! ##compiler#backslashify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5459,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate2((C_word*)lf[61]+1 /* (set! ##compiler#uncommentify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5469,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate2((C_word*)lf[63]+1 /* (set! ##compiler#build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5479,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate2((C_word*)lf[64]+1 /* (set! ##compiler#string->c-identifier ...) */,*((C_word*)lf[65]+1));
t21=C_mutate2((C_word*)lf[66]+1 /* (set! ##compiler#c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5521,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate2((C_word*)lf[76]+1 /* (set! ##compiler#valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5618,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate2((C_word*)lf[78]+1 /* (set! ##compiler#words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5668,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate2((C_word*)lf[79]+1 /* (set! ##compiler#words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5675,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate2((C_word*)lf[80]+1 /* (set! ##compiler#check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5682,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate2((C_word*)lf[87]+1 /* (set! ##compiler#close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5726,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate2((C_word*)lf[90]+1 /* (set! ##compiler#fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5738,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate2((C_word*)lf[92]+1 /* (set! ##compiler#follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5794,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate2((C_word*)lf[93]+1 /* (set! ##compiler#sort-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5825,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate2((C_word*)lf[96]+1 /* (set! ##compiler#constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5845,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate2((C_word*)lf[100]+1 /* (set! ##compiler#collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5907,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate2((C_word*)lf[101]+1 /* (set! ##compiler#immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5937,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate2((C_word*)lf[103]+1 /* (set! ##compiler#basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5983,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate2((C_word*)lf[106]+1 /* (set! ##compiler#canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6039,tmp=(C_word)a,a+=2,tmp));
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6114,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:302: condition-predicate */
t36=*((C_word*)lf[567]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t36;
av2[1]=t35;
av2[2]=lf[520];
((C_proc)(void*)(*((C_word*)t36+1)))(3,av2);}}

/* k14824 in k14760 in walk in scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14826(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_14826,2,av);}
a=C_alloc(5);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14837,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1365: append */
t5=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* test-debugging-mode in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4866(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_4866,4,av);}
a=C_alloc(3);
if(C_truep(C_i_symbolp(t2))){
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_i_memq(t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4883,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:60: lset-intersection */
t5=*((C_word*)lf[12]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[13]+1);
av2[3]=t2;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* k14835 in k14824 in k14760 in walk in scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14837(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_14837,2,av);}
/* support.scm:1365: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_14728(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k5580 in k5566 in k5559 in loop in k5535 in c-ify-string in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5582(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5582,2,av);}
/* string->list */
t2=*((C_word*)lf[71]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k10290 in map-loop2044 in k10248 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10292(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_10292,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10267(t6,((C_word*)t0)[5],t5);}

/* ##compiler#debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4885(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +17,c,3))){
C_save_and_reclaim((void*)f_4885,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+17);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4888,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4953,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4972,a[2]=t1,a[3]=t8,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* support.scm:75: test-debugging-mode */
t12=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t12;
av2[1]=t11;
av2[2]=t2;
av2[3]=*((C_word*)lf[1]+1);
((C_proc)(void*)(*((C_word*)t12+1)))(4,av2);}}

/* k4881 in test-debugging-mode in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4883(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4883,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_pairp(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* text in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_4888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_4888,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:64: with-output-to-string */
t3=*((C_word*)lf[23]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5574 in k5570 in k5566 in k5559 in loop in k5535 in c-ify-string in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5576(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_5576,2,av);}
/* support.scm:193: append */
t2=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[70];
av2[3]=((C_word*)t0)[3];
av2[4]=((C_word*)t0)[4];
av2[5]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k5570 in k5566 in k5559 in loop in k5535 in c-ify-string in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5572(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5572,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
t5=C_u_i_cdr(t4);
/* support.scm:198: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5539(t6,t3,t5);}

/* k4850 in bomb in k4827 in k4824 in k4821 */
static void C_ccall f_4852(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4852,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=*((C_word*)lf[4]+1);
av2[3]=t1;
av2[4]=t3;
C_apply(5,av2);}}

/* k14815 in k14760 in walk in scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14817(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_14817,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_i_car(((C_word*)t0)[3]);
/* support.scm:1362: walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_14728(t4,((C_word*)t0)[5],t3,((C_word*)t0)[6]);}

/* k15741 in k15735 in k15724 in k15721 in k15718 in k15715 in k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15743(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_15743,2,av);}
/* write-char/port */
t2=*((C_word*)lf[526]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(62);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* loop in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_9365(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,2))){
C_save_and_reclaim_args((void *)trf_9365,5,t0,t1,t2,t3,t4);}
a=C_alloc(11);
if(C_truep(C_i_zerop(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9379,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm:668: reverse */
t6=*((C_word*)lf[91]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=C_a_i_minus(&a,2,t2,C_fix(1));
t6=t5;
t7=C_i_cdr(t3);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9406,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t6,a[6]=t8,tmp=(C_word)a,a+=7,tmp);
t10=t3;
t11=C_u_i_car(t10);
/* support.scm:669: walk */
t12=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t12;
av2[1]=t9;
av2[2]=t11;
f_8779(3,av2);}}}

/* k15842 in k15827 in read-info-hook in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15844(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_15844,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15848,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
/* support.scm:1566: ##sys#hash-table-ref */
t6=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=*((C_word*)lf[158]+1);
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k15846 in k15842 in k15827 in read-info-hook in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_15848,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=t1;
t3=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]),t2);
/* support.scm:1561: ##sys#hash-table-set! */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=*((C_word*)lf[158]+1);
av2[3]=((C_word*)t0)[5];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]),C_SCHEME_END_OF_LIST);
/* support.scm:1561: ##sys#hash-table-set! */
t3=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=*((C_word*)lf[158]+1);
av2[3]=((C_word*)t0)[5];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k15753 in k15735 in k15724 in k15721 in k15718 in k15715 in k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_15755,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[4],C_fix(4));
/* support.scm:1548: ##sys#print */
t4=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k15756 in k15753 in k15735 in k15724 in k15721 in k15718 in k15715 in k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_15758,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15761,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15766,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_15766(t6,t2,C_fix(5));}

/* k4821 */
static void C_ccall f_4823(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4823,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4826,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k9377 in loop in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9379(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_9379,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9383,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[3]);
/* support.scm:668: walk */
t5=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
f_8779(3,av2);}}

/* k4827 in k4824 in k4821 */
static void C_ccall f_4829(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_4829,2,av);}
a=C_alloc(7);
t2=C_mutate2((C_word*)lf[0]+1 /* (set! ##compiler#compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4833,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[1] /* ##compiler#debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[2] /* ##compiler#disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate2((C_word*)lf[3]+1 /* (set! ##compiler#bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4838,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4863,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:53: open-output-string */
t7=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k4824 in k4821 */
static void C_ccall f_4826(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4826,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4829,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_chicken_2dsyntax_toplevel(2,av2);}}

/* a5814 in loop in follow-without-loop in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5815(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_5815,3,av);}
a=C_alloc(3);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
/* support.scm:243: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5800(t4,t1,t2,t3);}

/* k8619 in a8531 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8621(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,1))){C_save_and_reclaim((void *)f_8621,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
f_8593(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_8593(t2,C_SCHEME_FALSE);}}

/* k11427 in a11399 in dump-defined-globals in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11429(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_11429,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_11407(t2,C_SCHEME_FALSE);}
else{
t2=C_i_assq(lf[189],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_11407(t3,(C_truep(t2)?C_i_assq(lf[187],((C_word*)t0)[3]):C_SCHEME_FALSE));}}

/* k9381 in k9377 in loop in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9383(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_9383,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[271],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* g2050 in k10248 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_10255,3,t0,t1,t2);}
/* support.scm:754: g2067 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9875(t3,t1,t2,((C_word*)t0)[3]);}

/* k10248 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10250(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,3))){C_save_and_reclaim((void *)f_10250,2,av);}
a=C_alloc(22);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=C_i_check_list_2(((C_word*)t0)[4],lf[161]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10265,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10267,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_10267(t13,t9,((C_word*)t0)[4]);}

/* loop in follow-without-loop in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5800(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_5800,4,t0,t1,t2,t3);}
a=C_alloc(5);
if(C_truep(C_i_member(t2,t3))){
/* support.scm:242: abort */
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5815,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:243: proc */
t5=((C_word*)t0)[4];{
C_word av2[4];
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k11476 in a11436 in dump-global-refs in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11478(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_11478,2,av);}
a=C_alloc(9);
t2=(C_truep(t1)?C_SCHEME_FALSE:C_i_assq(lf[189],((C_word*)t0)[2]));
if(C_truep(t2)){
t3=C_i_assq(lf[176],((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11450,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=C_i_cdr(t3);
t6=C_i_length(t5);
t7=C_a_i_list2(&a,2,((C_word*)t0)[4],t6);
/* support.scm:928: write */
t8=*((C_word*)lf[207]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t4;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t5=C_a_i_list2(&a,2,((C_word*)t0)[4],C_fix(0));
/* support.scm:928: write */
t6=*((C_word*)lf[207]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* map-loop1581 in k8981 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_9053(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_9053,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9078,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:639: g1587 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* ##sys#toplevel-definition-hook in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11480(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11480,6,av);}
a=C_alloc(4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11490,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:938: debugging */
t8=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[261];
av2[3]=lf[330];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* k11448 in k11476 in a11436 in dump-global-refs in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11450(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_11450,2,av);}
/* support.scm:929: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* match1 in match-node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10943(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_10943,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm:843: resolve */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10909(t4,t1,t3,t2);}
else{
if(C_truep(C_i_not_pair_p(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10965,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t2);
t6=C_i_car(t3);
/* support.scm:845: match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* a11436 in dump-global-refs in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11437(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_11437,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11478,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:926: keyword? */
t5=*((C_word*)lf[325]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* ##compiler#dump-global-refs in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11431(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(2,c,4))){C_save_and_reclaim((void *)f_11431,3,av);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11437,tmp=(C_word)a,a+=2,tmp);
/* support.scm:924: ##sys#hash-table-for-each */
t4=*((C_word*)lf[162]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* ##compiler#collapsable-literal? in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5907(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5907,3,av);}
t3=C_booleanp(t2);
if(C_truep(t3)){
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_charp(t2);
if(C_truep(t4)){
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eofp(t2);
if(C_truep(t5)){
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_i_numberp(t2);
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=(C_truep(t6)?t6:C_i_symbolp(t2));
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}}}

/* k10710 in a10704 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10712(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_10712,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=C_i_assq(lf[173],((C_word*)t0)[2]);
t3=t2;
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[4];
/* tweaks.scm:57: ##sys#get */
t6=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=lf[312];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5877 in constant? in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5879(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5879,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_i_vectorp(((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:259: ##sys#srfi-4-vector? */
t4=*((C_word*)lf[98]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}}

/* k8375 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8377(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,2))){C_save_and_reclaim((void *)f_8377,2,av);}
a=C_alloc(20);
t2=C_i_cadr(t1);
t3=C_a_i_list4(&a,4,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8357,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8361,a[2]=((C_word*)t0)[6],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm:597: sixth */
t7=*((C_word*)lf[249]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k5889 in k5877 in constant? in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5891(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5891,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_eqp(lf[97],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* k11408 in k11405 in a11399 in dump-defined-globals in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11410(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_11410,2,av);}
/* support.scm:920: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10887 in k10864 in loop in a10855 in load-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10889(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_10889,2,av);}
/* support.scm:827: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_10862(t2,((C_word*)t0)[3]);}

/* k5837 in a5830 in sort-symbols in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5839(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5839,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5843,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:246: symbol->string */
t4=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a5830 in sort-symbols in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5831(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5831,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5839,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:246: symbol->string */
t5=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* ##compiler#get-list in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6711(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_6711,5,av);}
a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6715,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:412: get */
t6=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k6713 in get-list in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6715(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6715,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* ##compiler#sort-symbols in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5825(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(2,c,4))){C_save_and_reclaim((void *)f_5825,3,av);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5831,tmp=(C_word)a,a+=2,tmp);
/* support.scm:246: sort */
t4=*((C_word*)lf[95]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* ##compiler#qnode in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7520(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,1))){C_save_and_reclaim((void *)f_7520,3,av);}
a=C_alloc(8);
t3=C_a_i_list1(&a,1,t2);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[97],t3,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a10704 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_10705,4,av);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10712,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* support.scm:784: variable-visible? */
t5=*((C_word*)lf[313]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10701 in a10654 in k10590 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10703(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_10703,2,av);}
/* support.scm:805: print */
t2=*((C_word*)lf[295]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[302];
av2[3]=t1;
av2[4]=lf[303];
av2[5]=*((C_word*)lf[304]+1);
av2[6]=lf[305];
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* k10771 in k10768 in k10813 in k10734 in k10846 in k10710 in a10704 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10773(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_10773,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_u_i_cdr(((C_word*)t0)[6]);
/* support.scm:799: node->sexpr */
t6=*((C_word*)lf[292]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6162 in tmp14363 in a6157 in a6126 in string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6164(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_6164,2,av);}
a=C_alloc(3);
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[115];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_i_cdr(t1);
t3=C_i_nullp(t2);
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=(C_truep(t3)?C_u_i_car(t1):C_a_i_cons(&a,2,lf[116],t1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k10768 in k10813 in k10734 in k10846 in k10710 in a10704 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10770(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_10770,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(t1,lf[308]);
if(C_truep(t3)){
t4=t2;
f_10773(t4,C_SCHEME_TRUE);}
else{
t4=C_eqp(t1,lf[309]);
if(C_truep(t4)){
t5=t2;
f_10773(t5,C_SCHEME_FALSE);}
else{
t5=C_i_cadddr(((C_word*)t0)[7]);
t6=t2;
f_10773(t6,C_i_lessp(t5,*((C_word*)lf[310]+1)));}}}

/* tmp14363 in a6157 in a6126 in string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_6160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_6160,2,t0,t1);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6164,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6186,tmp=(C_word)a,a+=2,tmp);
/* support.scm:311: with-input-from-string */
t4=*((C_word*)lf[121]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5841 in k5837 in a5830 in sort-symbols in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5843(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5843,2,av);}
/* support.scm:246: string<? */
t2=*((C_word*)lf[94]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##compiler#constant? in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5845,3,av);}
a=C_alloc(4);
t3=C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_charp(t2);
if(C_truep(t4)){
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_booleanp(t2);
if(C_truep(t6)){
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_eofp(t2);
if(C_truep(t7)){
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5879,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:257: blob? */
t9=*((C_word*)lf[99]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}}}}}

/* k7827 in map-loop1099 in k7729 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7829(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_7829,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7804(t6,((C_word*)t0)[5],t5);}

/* ##compiler#varnode in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,1))){C_save_and_reclaim((void *)f_7505,3,av);}
a=C_alloc(8);
t3=C_a_i_list1(&a,1,t2);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[221],t3,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5979 in immediate? in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5981(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5981,2,av);}
t2=((C_word*)t0)[2];
f_5941(t2,C_i_not(t1));}

/* k6018 in k6003 in k5997 in basic-literal? in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6020(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6020,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* support.scm:284: basic-literal? */
t4=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* ##compiler#basic-literal? in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5983,3,av);}
a=C_alloc(4);
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5999,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:280: constant? */
t6=*((C_word*)lf[96]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}}

/* k15598 in encodeable-literal? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15600(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_15600,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_fixnump(((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_flonump(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
t4=C_slot(((C_word*)t0)[3],C_fix(1));
t5=C_i_string_length(t4);
t6=((C_word*)t0)[2];
t7=C_a_i_arithmetic_shift(&a,2,t5,C_fix(-24));
t8=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_u_i_zerop(t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
if(C_truep(C_byteblockp(((C_word*)t0)[3]))){
t4=((C_word*)t0)[3];
t5=stub3725(C_SCHEME_UNDEFINED,t4);
t6=((C_word*)t0)[2];
t7=C_a_i_arithmetic_shift(&a,2,t5,C_fix(-24));
t8=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_u_i_zerop(t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t4=((C_word*)t0)[3];
t5=stub3725(C_SCHEME_UNDEFINED,t4);
t6=C_a_i_arithmetic_shift(&a,2,t5,C_fix(-24));
if(C_truep(C_u_i_zerop(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15657,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15659,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1531: list-tabulate */
t9=*((C_word*)lf[524]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t7;
av2[2]=t5;
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
t7=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}}}}}}

/* k6098 in loop in canonicalize-begin-body in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6100(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6100,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_6069(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_6069(t2,C_i_equalp(((C_word*)t0)[3],lf[112]));}}

/* k7951 in k7972 in loop in k8051 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_7953,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[237],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6035 in k5997 in basic-literal? in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6037,2,av);}
/* support.scm:281: every */
t2=*((C_word*)lf[104]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[103]+1);
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##compiler#canonicalize-begin-body in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6039(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6039,3,av);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6045,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6045(t6,t1,t2);}

/* ##compiler#immediate? in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5937(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5937,3,av);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5941,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5981,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:270: big-fixnum? */
t5=*((C_word*)lf[102]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=t3;
f_5941(t4,C_SCHEME_FALSE);}}

/* k10813 in k10734 in k10846 in k10710 in a10704 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10815(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_10815,2,av);}
a=C_alloc(8);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10770,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[3];
/* tweaks.scm:57: ##sys#get */
t4=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=lf[311];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* ##compiler#get-line in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6720(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6720,3,av);}
t3=C_i_car(t2);
/* support.scm:419: get */
t4=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=*((C_word*)lf[158]+1);
av2[3]=t3;
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* ##compiler#string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6118(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_6118,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6122,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6127,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:302: call-with-current-continuation */
t5=*((C_word*)lf[123]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6117(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word *a;
if(!C_demand(C_calculate_demand(59,c,6))){C_save_and_reclaim((void *)f_6117,2,av);}
a=C_alloc(59);
t2=t1;
t3=C_mutate2((C_word*)lf[113]+1 /* (set! ##compiler#string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6118,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t4=C_mutate2((C_word*)lf[124]+1 /* (set! ##compiler#decompose-lambda-list ...) */,*((C_word*)lf[125]+1));
t5=C_mutate2((C_word*)lf[126]+1 /* (set! ##compiler#llist-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6221,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2((C_word*)lf[127]+1 /* (set! ##compiler#llist-match? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6224,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate2((C_word*)lf[128]+1 /* (set! ##compiler#expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6268,tmp=(C_word)a,a+=2,tmp));
t8=C_SCHEME_TRUE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_mutate2((C_word*)lf[137]+1 /* (set! ##compiler#initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6325,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2((C_word*)lf[148]+1 /* (set! ##compiler#get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6522,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate2((C_word*)lf[150]+1 /* (set! ##compiler#get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6540,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2((C_word*)lf[152]+1 /* (set! ##compiler#put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6558,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate2((C_word*)lf[154]+1 /* (set! ##compiler#collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6604,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2((C_word*)lf[155]+1 /* (set! ##compiler#count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6656,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate2((C_word*)lf[156]+1 /* (set! ##compiler#get-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6711,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate2((C_word*)lf[157]+1 /* (set! ##compiler#get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6720,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate2((C_word*)lf[159]+1 /* (set! ##compiler#get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6730,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate2((C_word*)lf[160]+1 /* (set! ##compiler#display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6771,tmp=(C_word)a,a+=2,tmp));
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_mutate2((C_word*)lf[163]+1 /* (set! ##compiler#display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6842,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=C_mutate2((C_word*)lf[210]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7430,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate2((C_word*)lf[212]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7436,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate2((C_word*)lf[213]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7442,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate2((C_word*)lf[214]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7451,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate2((C_word*)lf[216]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7460,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate2((C_word*)lf[217]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7469,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate2((C_word*)lf[218]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7478,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate2((C_word*)lf[219]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7487,tmp=(C_word)a,a+=2,tmp));
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7497,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t32=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16248,tmp=(C_word)a,a+=2,tmp);
/* support.scm:512: ##sys#register-record-printer */
t33=*((C_word*)lf[565]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t33;
av2[1]=t31;
av2[2]=lf[211];
av2[3]=t32;
((C_proc)(void*)(*((C_word*)t33+1)))(4,av2);}}

/* k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6114(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_6114,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6117,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:303: condition-property-accessor */
t4=*((C_word*)lf[566]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[520];
av2[3]=lf[521];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k6003 in k5997 in basic-literal? in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6005(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6005,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
/* support.scm:283: basic-literal? */
t5=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* k11488 in toplevel-definition-hook in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11490(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11490,2,av);}
/* support.scm:939: hide-variable */
t2=*((C_word*)lf[329]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k15667 in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15669(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_15669,2,av);}
/* support.scm:1554: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a6776 in display-line-number-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6777(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_6777,4,av);}
a=C_alloc(5);
if(C_truep(t3)){
t4=*((C_word*)lf[16]+1);
t5=*((C_word*)lf[16]+1);
t6=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6787,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:431: ##sys#print */
t8=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* ##compiler#display-line-number-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6771(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(2,c,4))){C_save_and_reclaim((void *)f_6771,2,av);}
a=C_alloc(2);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6777,tmp=(C_word)a,a+=2,tmp);
/* support.scm:429: ##sys#hash-table-for-each */
t3=*((C_word*)lf[162]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=*((C_word*)lf[158]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* ##compiler#dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15665(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_15665,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15669,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15674,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_15674(t7,t3,C_fix(0),t2);}

/* a6126 in string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_6127,3,av);}
a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6158,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:302: with-exception-handler */
t5=*((C_word*)lf[122]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k6120 in string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6122(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6122,2,av);}
/* support.scm:302: g488 */
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5997 in basic-literal? in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5999,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_vectorp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6037,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:281: vector->list */
t4=*((C_word*)lf[105]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_6005(2,av2);}}}}

/* k7972 in loop in k8051 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7974(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_7974,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7953,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_a_i_record4(&a,4,lf[211],lf[226],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[4]);
/* support.scm:566: reverse */
t7=*((C_word*)lf[91]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t4;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k15655 in k15598 in encodeable-literal? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15657(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_15657,2,av);}
/* support.scm:1529: every */
t2=*((C_word*)lf[104]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[518]+1);
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6738 in k6735 in get-line-2 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_6740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,3))){
C_save_and_reclaim_args((void *)trf_6740,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6744,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:421: g732 */
t3=t2;
f_6744(t3,((C_word*)t0)[3],t1);}
else{
/* support.scm:426: values */{
C_word av2[4];
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}}

/* a15658 in k15598 in encodeable-literal? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15659(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_15659,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[2],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* g732 in k6738 in k6735 in get-line-2 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_6744(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_6744,3,t0,t1,t2);}
t3=C_i_car(((C_word*)t0)[2]);
t4=C_i_cdr(t2);
/* support.scm:425: values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
C_values(4,av2);}}

/* a6138 in a6132 in a6126 in string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_6139,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6147,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6150,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:308: exn? */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a6132 in a6126 in string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6133,3,av);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:302: k484 */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* ##compiler#load-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10850(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(2,c,3))){C_save_and_reclaim((void *)f_10850,3,av);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10856,tmp=(C_word)a,a+=2,tmp);
/* support.scm:818: with-input-from-file */
t4=*((C_word*)lf[315]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k6067 in loop in canonicalize-begin-body in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_6069(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_6069,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* support.scm:297: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6045(t4,((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:298: gensym */
t3=*((C_word*)lf[110]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[111];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k10864 in loop in a10855 in load-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10866(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_10866,2,av);}
a=C_alloc(8);
if(C_truep(C_eofp(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(t1);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10900,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cadr(t1);
/* support.scm:826: sexpr->node */
t7=*((C_word*)lf[293]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}}

/* k6791 in k6788 in k6785 in a6776 in display-line-number-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6793(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6793,2,av);}
/* support.scm:431: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6788 in k6785 in a6776 in display-line-number-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6790(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,3))){C_save_and_reclaim((void *)f_6790,2,av);}
a=C_alloc(20);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)t0)[4];
t8=C_i_check_list_2(t7,lf[161]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6806,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6808,a[2]=t5,a[3]=t11,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_6808(t13,t9,t7);}

/* k7994 in k8014 in loop in k8051 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7996(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_7996,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[237],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a10855 in load-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10856(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_10856,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10862,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_10862(t5,t1);}

/* k10787 in k10771 in k10768 in k10813 in k10734 in k10846 in k10710 in a10704 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10789(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_10789,2,av);}
a=C_alloc(9);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* loop in canonicalize-begin-body in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_6045(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_6045,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[107];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_u_i_car(t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=t2;
t5=C_u_i_car(t4);
t6=C_i_equalp(t5,lf[108]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6069,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_6069(t8,t6);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6100,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm:295: constant? */
t9=*((C_word*)lf[96]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t8;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}}}

/* k10846 in k10710 in a10704 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_10848,2,av);}
a=C_alloc(9);
if(C_truep(C_i_structurep(t1,lf[211]))){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_i_assq(lf[172],((C_word*)t0)[3]);
t3=C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10736,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_10736(t5,t3);}
else{
t5=C_i_cdr(t2);
t6=C_eqp(lf[169],t5);
t7=t4;
f_10736(t7,C_i_not(t6));}}}

/* k6785 in a6776 in display-line-number-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6787(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6787,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:431: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k11390 in a11358 in dump-undefined-globals in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11392(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_11392,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_11366(t2,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_assq(lf[189],((C_word*)t0)[3]))){
t2=C_i_assq(lf[187],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_11366(t3,C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_11366(t2,C_SCHEME_FALSE);}}}

/* ##compiler#dump-defined-globals in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11394(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(2,c,4))){C_save_and_reclaim((void *)f_11394,3,av);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11400,tmp=(C_word)a,a+=2,tmp);
/* support.scm:914: ##sys#hash-table-for-each */
t4=*((C_word*)lf[162]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* a6185 in tmp14363 in a6157 in a6126 in string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_6186,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6192,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6200,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:313: read */
t4=*((C_word*)lf[117]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_15674(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_15674,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=t3;
t5=C_slot(t4,C_fix(1));
t6=t5;
t7=t3;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t3;
t11=C_slot(t10,C_fix(3));
t12=t11;
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15702,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t12,a[5]=t3,a[6]=t1,a[7]=t9,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* support.scm:1542: make-string */
t14=*((C_word*)lf[509]+1);{
C_word av2[4];
av2[0]=t14;
av2[1]=t13;
av2[2]=t2;
av2[3]=C_make_character(32);
((C_proc)(void*)(*((C_word*)t14+1)))(4,av2);}}

/* a6191 in a6185 in tmp14363 in a6157 in a6126 in string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6192(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6192,3,av);}
/* support.scm:313: read */
t3=*((C_word*)lf[117]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6083 in k6093 in k6067 in loop in canonicalize-begin-body in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_6085,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[109],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* node-class-set! in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7451(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_7451,4,av);}
t4=C_i_check_structure_2(t2,lf[211],C_SCHEME_FALSE);
/* support.scm:505: ##sys#block-set! */
t5=*((C_word*)lf[215]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(1);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k6093 in k6067 in loop in canonicalize-begin-body in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6095(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_6095,2,av);}
a=C_alloc(13);
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_a_i_list(&a,2,t1,t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6085,a[2]=((C_word*)t0)[3],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
/* support.scm:299: loop */
t10=((C_word*)((C_word*)t0)[4])[1];
f_6045(t10,t7,t9);}

/* a11358 in dump-undefined-globals in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11359(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_11359,4,av);}
a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11366,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11392,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:906: keyword? */
t6=*((C_word*)lf[325]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* ##compiler#dump-undefined-globals in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11353(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(2,c,4))){C_save_and_reclaim((void *)f_11353,3,av);}
a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11359,tmp=(C_word)a,a+=2,tmp);
/* support.scm:904: ##sys#hash-table-for-each */
t4=*((C_word*)lf[162]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k10400 in k10397 in k10394 in copy-node! in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10402(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_10402,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5939 in immediate? in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5941(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,1))){
C_save_and_reclaim_args((void *)trf_5941,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_nullp(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eofp(((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_charp(((C_word*)t0)[3]);
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(t5)?t5:C_booleanp(((C_word*)t0)[3]));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}}}

/* k6145 in a6138 in a6132 in a6126 in string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6147(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6147,2,av);}
/* support.scm:306: quit */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[114];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a13314 in estimate-foreign-result-location-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_13315(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_13315,4,av);}
a=C_alloc(6);
t4=t2;
t5=C_eqp(t4,lf[350]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13325,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_13325(t7,t5);}
else{
t7=C_eqp(t4,lf[354]);
if(C_truep(t7)){
t8=t6;
f_13325(t8,t7);}
else{
t8=C_eqp(t4,lf[427]);
if(C_truep(t8)){
t9=t6;
f_13325(t9,t8);}
else{
t9=C_eqp(t4,lf[439]);
if(C_truep(t9)){
t10=t6;
f_13325(t10,t9);}
else{
t10=C_eqp(t4,lf[428]);
if(C_truep(t10)){
t11=t6;
f_13325(t11,t10);}
else{
t11=C_eqp(t4,lf[351]);
if(C_truep(t11)){
t12=t6;
f_13325(t12,t11);}
else{
t12=C_eqp(t4,lf[426]);
if(C_truep(t12)){
t13=t6;
f_13325(t13,t12);}
else{
t13=C_eqp(t4,lf[407]);
if(C_truep(t13)){
t14=t6;
f_13325(t14,t13);}
else{
t14=C_eqp(t4,lf[406]);
if(C_truep(t14)){
t15=t6;
f_13325(t15,t14);}
else{
t15=C_eqp(t4,lf[429]);
if(C_truep(t15)){
t16=t6;
f_13325(t16,t15);}
else{
t16=C_eqp(t4,lf[430]);
if(C_truep(t16)){
t17=t6;
f_13325(t17,t16);}
else{
t17=C_eqp(t4,lf[377]);
if(C_truep(t17)){
t18=t6;
f_13325(t18,t17);}
else{
t18=C_eqp(t4,lf[379]);
if(C_truep(t18)){
t19=t6;
f_13325(t19,t18);}
else{
t19=C_eqp(t4,lf[373]);
if(C_truep(t19)){
t20=t6;
f_13325(t20,t19);}
else{
t20=C_eqp(t4,lf[369]);
if(C_truep(t20)){
t21=t6;
f_13325(t21,t20);}
else{
t21=C_eqp(t4,lf[356]);
if(C_truep(t21)){
t22=t6;
f_13325(t22,t21);}
else{
t22=C_eqp(t4,lf[380]);
if(C_truep(t22)){
t23=t6;
f_13325(t23,t22);}
else{
t23=C_eqp(t4,lf[384]);
if(C_truep(t23)){
t24=t6;
f_13325(t24,t23);}
else{
t24=C_eqp(t4,lf[359]);
if(C_truep(t24)){
t25=t6;
f_13325(t25,t24);}
else{
t25=C_eqp(t4,lf[361]);
if(C_truep(t25)){
t26=t6;
f_13325(t26,t25);}
else{
t26=C_eqp(t4,lf[431]);
if(C_truep(t26)){
t27=t6;
f_13325(t27,t26);}
else{
t27=C_eqp(t4,lf[432]);
if(C_truep(t27)){
t28=t6;
f_13325(t28,t27);}
else{
t28=C_eqp(t4,lf[409]);
if(C_truep(t28)){
t29=t6;
f_13325(t29,t28);}
else{
t29=C_eqp(t4,lf[405]);
if(C_truep(t29)){
t30=t6;
f_13325(t30,t29);}
else{
t30=C_eqp(t4,lf[401]);
if(C_truep(t30)){
t31=t6;
f_13325(t31,t30);}
else{
t31=C_eqp(t4,lf[402]);
if(C_truep(t31)){
t32=t6;
f_13325(t32,t31);}
else{
t32=C_eqp(t4,lf[399]);
if(C_truep(t32)){
t33=t6;
f_13325(t33,t32);}
else{
t33=C_eqp(t4,lf[408]);
if(C_truep(t33)){
t34=t6;
f_13325(t34,t33);}
else{
t34=C_eqp(t4,lf[383]);
if(C_truep(t34)){
t35=t6;
f_13325(t35,t34);}
else{
t35=C_eqp(t4,lf[400]);
if(C_truep(t35)){
t36=t6;
f_13325(t36,t35);}
else{
t36=C_eqp(t4,lf[398]);
if(C_truep(t36)){
t37=t6;
f_13325(t37,t36);}
else{
t37=C_eqp(t4,lf[403]);
t38=t6;
f_13325(t38,(C_truep(t37)?t37:C_eqp(t4,lf[404])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k7426 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7428(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_7428,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_6846(t3,t2);}

/* a6157 in a6126 in string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6158(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_6158,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6160,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6201,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6218,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tmp14363 */
t5=t2;
f_6160(t5,t4);}

/* k6148 in a6138 in a6132 in a6126 in string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6150(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6150,2,av);}
if(C_truep(t1)){
/* support.scm:309: exn-msg */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
/* support.scm:310: ->string */
t2=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k6735 in get-line-2 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6737(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_6737,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6740,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=C_i_cdr(t2);
t5=t3;
f_6740(t5,C_i_assq(((C_word*)t0)[4],t4));}
else{
t4=t3;
f_6740(t4,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6730(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6730,3,av);}
a=C_alloc(5);
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6737,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:423: ##sys#hash-table-ref */
t6=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=*((C_word*)lf[158]+1);
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* node-class in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7442(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_7442,3,av);}
t3=C_i_check_structure_2(t2,lf[211],lf[213]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k14241 in k14219 in k14201 in k14180 in k14105 in k14030 in k14006 in foreign-type->scrutiny-type in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14243(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_14243,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[479];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[392]);
if(C_truep(t2)){
t3=C_i_cadr(((C_word*)t0)[4]);
/* support.scm:1318: foreign-type->scrutiny-type */
t4=*((C_word*)lf[460]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=C_eqp(((C_word*)t0)[3],lf[393]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[425];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[394]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t5;
av2[1]=(C_truep(t4)?lf[395]:lf[240]);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eqp(((C_word*)t0)[3],lf[379]);
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(t5)?lf[395]:lf[240]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}}}

/* node? in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7436(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_7436,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[211]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* f_7430 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_7430,5,av);}
a=C_alloc(5);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_record4(&a,4,lf[211],t2,t3,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* node-parameters-set! in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7469(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_7469,4,av);}
t4=C_i_check_structure_2(t2,lf[211],C_SCHEME_FALSE);
/* support.scm:505: ##sys#block-set! */
t5=*((C_word*)lf[215]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(2);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* node-parameters in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7460(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_7460,3,av);}
t3=C_i_check_structure_2(t2,lf[211],lf[216]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(2));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k14219 in k14201 in k14180 in k14105 in k14030 in k14006 in foreign-type->scrutiny-type in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14221(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_14221,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[478];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[384]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[384];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[4];
t4=C_u_i_car(t3);
t5=C_eqp(t4,lf[386]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14243,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_14243(t7,t5);}
else{
t7=C_eqp(t4,lf[395]);
if(C_truep(t7)){
t8=t6;
f_14243(t8,t7);}
else{
t8=C_eqp(t4,lf[396]);
t9=t6;
f_14243(t9,(C_truep(t8)?t8:C_eqp(t4,lf[377])));}}}
else{
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[240];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}}}

/* k15381 in k15514 in k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15383(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_15383,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1494: g3700 */
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a15493 in a15487 in a15469 in a15447 in k15514 in k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15494(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_15494,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k15384 in k15381 in k15514 in k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15386(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_15386,2,av);}
a=C_alloc(6);
t2=t1;
if(C_truep(C_i_structurep(t2,lf[211]))){
/* support.scm:1499: k */
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_FALSE;
av2[3]=((C_word*)t0)[4];
av2[4]=C_SCHEME_FALSE;
av2[5]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15406,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_i_length(t2);
t5=C_eqp(C_fix(1),t4);
if(C_truep(t5)){
t6=C_i_car(t2);
/* support.scm:1501: encodeable-literal? */
t7=*((C_word*)lf[518]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t6=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
f_15406(2,av2);}}}}

/* k11367 in k11364 in a11358 in dump-undefined-globals in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11369(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_11369,2,av);}
/* support.scm:910: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k11364 in a11358 in dump-undefined-globals in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_11366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_11366,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11369,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:909: write */
t3=*((C_word*)lf[207]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a15487 in a15469 in a15447 in k15514 in k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15488(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,2))){
C_save_and_reclaim((void*)f_15488,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15494,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1494: k3696 */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4970 in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4972(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_4972,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:76: text */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4888(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4993,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4996,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* support.scm:83: test-debugging-mode */
t4=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* a15481 in a15475 in a15469 in a15447 in k15514 in k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15482(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_15482,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[3];
C_apply(4,av2);}}

/* a15475 in a15469 in a15447 in k15514 in k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15476(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_15476,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1494: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=*((C_word*)lf[522]+1);
C_call_with_values(4,av2);}}

/* k6560 in put! in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_6562,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(((C_word*)t0)[4])){
t3=C_slot(t1,C_fix(1));
t4=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]),t3);
t5=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_i_setslot(t1,C_fix(1),t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
t3=C_a_i_list1(&a,1,t2);
/* support.scm:392: ##sys#hash-table-set! */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* a15469 in a15447 in k15514 in k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15470(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_15470,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15488,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1494: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* k4976 in k4973 in k4970 in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4978(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_4978,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:78: flush-output */
t3=*((C_word*)lf[25]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4973 in k4970 in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4975(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_4975,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:77: display */
t4=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* ##compiler#foreign-type->scrutiny-type in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14004(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_14004,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14008,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1268: final-foreign-type */
t5=*((C_word*)lf[436]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k14006 in foreign-type->scrutiny-type in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14008(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_14008,2,av);}
a=C_alloc(7);
t2=t1;
t3=t2;
t4=C_eqp(t3,lf[440]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=lf[195];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eqp(t3,lf[350]);
t6=(C_truep(t5)?t5:C_eqp(t3,lf[351]));
if(C_truep(t6)){
t7=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=lf[350];
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_eqp(t3,lf[354]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14032,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_14032(t9,t7);}
else{
t9=C_eqp(t3,lf[426]);
if(C_truep(t9)){
t10=t8;
f_14032(t10,t9);}
else{
t10=C_eqp(t3,lf[427]);
if(C_truep(t10)){
t11=t8;
f_14032(t11,t10);}
else{
t11=C_eqp(t3,lf[428]);
if(C_truep(t11)){
t12=t8;
f_14032(t12,t11);}
else{
t12=C_eqp(t3,lf[429]);
if(C_truep(t12)){
t13=t8;
f_14032(t13,t12);}
else{
t13=C_eqp(t3,lf[430]);
if(C_truep(t13)){
t14=t8;
f_14032(t14,t13);}
else{
t14=C_eqp(t3,lf[431]);
t15=t8;
f_14032(t15,(C_truep(t14)?t14:C_eqp(t3,lf[432])));}}}}}}}}}

/* for-each-loop50 in k4908 in k4896 in a4893 in text in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_4930(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(13,0,2))){
C_save_and_reclaim_args((void *)trf_4930,3,t0,t1,t2);}
a=C_alloc(13);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4940,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=*((C_word*)lf[16]+1);
t7=*((C_word*)lf[16]+1);
t8=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4918,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4925,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm:70: force */
t11=*((C_word*)lf[20]+1);{
C_word av2[3];
av2[0]=t11;
av2[1]=t10;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6524 in get in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6526,2,av);}
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=(C_truep(t2)?C_slot(t2,C_fix(1)):C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* ##compiler#get in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6522(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_6522,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6526,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:375: ##sys#hash-table-ref */
t6=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k8981 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_8983,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9053,a[2]=((C_word*)t0)[8],a[3]=t4,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_9053(t6,t2,t1);}

/* k4979 in k4976 in k4973 in k4970 in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4981(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_4981,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4984,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4987,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* support.scm:79: test-debugging-mode */
t4=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k4982 in k4979 in k4976 in k4973 in k4970 in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4984(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4984,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k8997 in k8993 in k8984 in k8981 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8999(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_8999,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[109],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k8993 in k8984 in k8981 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8995(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_8995,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8999,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9003,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:640: last */
t5=*((C_word*)lf[265]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k4991 in k4970 in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4993(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4993,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k8984 in k8981 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8986(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_8986,2,av);}
a=C_alloc(12);
t2=C_i_check_list_2(((C_word*)t0)[2],lf[161]);
t3=C_i_check_list_2(t1,lf[161]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9005,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_9005(t8,t4,((C_word*)t0)[2],t1);}

/* k4985 in k4979 in k4976 in k4973 in k4970 in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4987(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4987,2,av);}
if(C_truep(t1)){
/* support.scm:80: dump */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4953(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k15245 in k15242 in a15236 in display-real-name-table in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_15247,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1461: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k15242 in a15236 in display-real-name-table in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15244(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_15244,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15247,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1461: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(9);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* ##compiler#get-all in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6540(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +4,c,3))){
C_save_and_reclaim((void*)f_6540,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+4);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6544,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:381: ##sys#hash-table-ref */
t6=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k6542 in get-all in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6544(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_6544,2,av);}
a=C_alloc(3);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6552,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:383: filter-map */
t4=*((C_word*)lf[151]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t3;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4961 in k4958 in dump in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4963(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4963,2,av);}
/* support.scm:62: ##sys#print */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4958 in dump in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4960(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4960,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:62: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(124);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k4994 in k4970 in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4996(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4996,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:84: text */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4888(t3,t2);}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a15236 in display-real-name-table in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15237(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_15237,4,av);}
a=C_alloc(5);
t4=*((C_word*)lf[16]+1);
t5=*((C_word*)lf[16]+1);
t6=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15244,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1461: ##sys#print */
t8=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}

/* ##compiler#put! in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6558(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_6558,6,av);}
a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6562,a[2]=t4,a[3]=t1,a[4]=t5,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:387: ##sys#hash-table-ref */
t7=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k11002 in matchn in match-node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11004(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_11004,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_slot(t2,C_fix(3));
t4=C_i_cddr(((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11022,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_11022(t8,((C_word*)t0)[6],t3,t4);}
else{
t2=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* loop in k8051 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_7930(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,2))){
C_save_and_reclaim_args((void *)trf_7930,5,t0,t1,t2,t3,t4);}
a=C_alloc(14);
if(C_truep(C_i_nullp(t2))){
t5=C_i_cadr(((C_word*)t0)[2]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7974,a[2]=t6,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* support.scm:565: reverse */
t8=*((C_word*)lf[91]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t5=C_i_caar(t2);
t6=C_eqp(lf[238],t5);
if(C_truep(t6)){
t7=C_i_cadr(((C_word*)t0)[2]);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8016,a[2]=t8,a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t10=C_a_i_cons(&a,2,lf[240],t3);
/* support.scm:571: reverse */
t11=*((C_word*)lf[91]+1);{
C_word av2[3];
av2[0]=t11;
av2[1]=t9;
av2[2]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_i_caar(t2);
t10=C_a_i_cons(&a,2,t9,t3);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8037,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t8,a[6]=t11,tmp=(C_word)a,a+=7,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8041,a[2]=((C_word*)t0)[3],a[3]=t12,tmp=(C_word)a,a+=4,tmp);
/* support.scm:575: cadar */
t14=*((C_word*)lf[239]+1);{
C_word av2[3];
av2[0]=t14;
av2[1]=t13;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t14+1)))(3,av2);}}}}

/* a6551 in k6542 in get-all in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6552(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6552,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_assq(t2,((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* ##compiler#display-real-name-table in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15231(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(2,c,4))){C_save_and_reclaim((void *)f_15231,2,av);}
a=C_alloc(2);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15237,tmp=(C_word)a,a+=2,tmp);
/* support.scm:1460: ##sys#hash-table-for-each */
t3=*((C_word*)lf[162]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=*((C_word*)lf[496]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k15221 in real-name2 in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15223(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_15223,2,av);}
if(C_truep(t1)){
/* support.scm:1457: real-name */
t2=*((C_word*)lf[47]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k12235 in k12198 in k12155 in k12110 in k12066 in k12039 in k12012 in k11986 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_12237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,2))){
C_save_and_reclaim_args((void *)trf_12237,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1108: gensym */
t3=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[387]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[388]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12275,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1114: gensym */
t5=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[4],lf[359]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1120: gensym */
t6=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_eqp(((C_word*)t0)[4],lf[361]);
if(C_truep(t5)){
if(C_truep(*((C_word*)lf[352]+1))){
t6=((C_word*)t0)[2];
t7=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t6;
av2[1]=C_a_i_list(&a,2,lf[360],((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t6=C_eqp(((C_word*)t0)[4],lf[391]);
if(C_truep(t6)){
t7=C_a_i_list(&a,2,lf[97],lf[389]);
t8=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t8;
av2[1]=C_a_i_list(&a,3,lf[390],((C_word*)t0)[2],t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=C_eqp(((C_word*)t0)[4],lf[392]);
if(C_truep(t7)){
t8=C_i_cadr(((C_word*)t0)[5]);
/* support.scm:1133: repeat */
t9=((C_word*)((C_word*)t0)[6])[1];
f_11783(t9,((C_word*)t0)[3],t8);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[393]);
if(C_truep(t8)){
t9=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t9;
av2[1]=(C_truep(*((C_word*)lf[352]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[370],((C_word*)t0)[2]));
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t9=C_eqp(((C_word*)t0)[4],lf[394]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t10;
av2[1]=(C_truep(t9)?C_a_i_list(&a,2,lf[378],((C_word*)t0)[2]):((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=C_eqp(((C_word*)t0)[4],lf[379]);
t11=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t11;
av2[1]=(C_truep(t10)?C_a_i_list(&a,2,lf[378],((C_word*)t0)[2]):((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}}}}}}}}

/* ##compiler#real-name2 in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15219(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_15219,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15223,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1456: ##sys#hash-table-ref */
t5=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[496]+1);
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k15715 in k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15717(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_15717,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* support.scm:1537: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[9];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k15212 in k15116 in real-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15214(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_15214,2,av);}
a=C_alloc(9);
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15145,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1441: get */
t5=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[5];
av2[4]=lf[181];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15711(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_15711,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_15714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:1537: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[10];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15714(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_15714,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_15717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:1537: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(60);
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k15208 in loop in k15143 in k15212 in k15116 in real-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15210(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_15210,2,av);}
/* support.scm:1452: string-intersperse */
t2=*((C_word*)lf[498]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[502];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_15702,2,av);}
a=C_alloc(15);
t2=t1;
t3=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(2));
t4=t3;
t5=*((C_word*)lf[16]+1);
t6=*((C_word*)lf[16]+1);
t7=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_15711,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t5,a[9]=((C_word*)t0)[8],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* support.scm:1537: ##sys#write-char-0 */
t9=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=C_make_character(10);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}

/* ##compiler#source-info->line in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15289(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_15289,3,av);}
if(C_truep(C_i_listp(t2))){
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_car(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(t2)){
/* support.scm:1475: ->string */
t3=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}}

/* k15273 in source-info->string in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15275(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_15275,2,av);}
/* support.scm:1469: conc */
t2=*((C_word*)lf[506]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[507];
av2[4]=t1;
av2[5]=lf[508];
av2[6]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* k15277 in source-info->string in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15279(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_15279,2,av);}
/* support.scm:1469: make-string */
t2=*((C_word*)lf[509]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_make_character(32);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k8908 in map-loop1518 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8910(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8910,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8885(t6,((C_word*)t0)[5],t5);}

/* k6424 in k6376 in initialize-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6426(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6426,2,av);}
a=C_alloc(5);
t2=*((C_word*)lf[140]+1);
t3=C_i_check_list_2(*((C_word*)lf[140]+1),lf[35]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6453,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_6453(t7,((C_word*)t0)[2],*((C_word*)lf[140]+1));}

/* k12238 in k12235 in k12198 in k12155 in k12110 in k12066 in k12039 in k12012 in k11986 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 in ... */
static void C_ccall f_12240(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(42,c,1))){C_save_and_reclaim((void *)f_12240,2,av);}
a=C_alloc(42);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[378],t1);
t5=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[225],t1,t4,t5);
t7=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[109],t3,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k4899 in k4896 in a4893 in text in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4901(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4901,2,av);}
/* support.scm:72: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9520 in map-loop1728 in k9415 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9522(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_9522,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9497(t6,((C_word*)t0)[5],t5);}

/* k4908 in k4896 in a4893 in text in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4910(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4910,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4930,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4930(t6,((C_word*)t0)[3],t2);}

/* k9534 in k9415 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9536(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_9536,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* map-loop1754 in k9415 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_9548(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_9548,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9573,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:674: g1760 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k15721 in k15718 in k15715 in k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15723(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_15723,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:1537: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k15718 in k15715 in k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15720(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_15720,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* support.scm:1537: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k9544 in k9415 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9546(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_9546,2,av);}
/* support.scm:674: append */
t2=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* for-each-loop632 in k6424 in k6376 in initialize-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_6453(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_6453,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6463,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_list(&a,1,lf[141]);
if(C_truep(C_i_nullp(t5))){
/* tweaks.scm:54: ##sys#put! */
t6=*((C_word*)lf[142]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[143];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t6=C_i_car(t5);
/* tweaks.scm:54: ##sys#put! */
t7=*((C_word*)lf[142]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[143];
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k15735 in k15724 in k15721 in k15718 in k15715 in k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15737(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_15737,2,av);}
a=C_alloc(9);
t2=C_block_size(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15743,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fixnum_greaterp(t3,C_fix(4)))){
t5=*((C_word*)lf[16]+1);
t6=*((C_word*)lf[16]+1);
t7=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15755,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1548: ##sys#write-char-0 */
t9=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=C_make_character(91);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
/* write-char/port */
t5=*((C_word*)lf[526]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=C_make_character(62);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k10141 in k10125 in k10060 in k10057 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10143(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10143,2,av);}
/* support.scm:751: build-lambda-list */
t2=*((C_word*)lf[63]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4916 in for-each-loop50 in k4908 in k4896 in a4893 in text in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4918(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4918,2,av);}
/* support.scm:70: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* g2785 in k12198 in k12155 in k12110 in k12066 in k12039 in k12012 in k11986 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_12204(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_12204,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1104: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t2;
/* support.scm:1104: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k12198 in k12155 in k12110 in k12066 in k12039 in k12012 in k11986 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_12200(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_12200,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12204,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1102: g2785 */
t3=t2;
f_12204(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[386]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12237,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=t5;
f_12237(t6,t4);}
else{
t6=C_eqp(t3,lf[395]);
if(C_truep(t6)){
t7=t5;
f_12237(t7,t6);}
else{
t7=C_eqp(t3,lf[396]);
t8=t5;
f_12237(t8,(C_truep(t7)?t7:C_eqp(t3,lf[377])));}}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* loop in check-signature in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5283(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_5283,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* support.scm:142: err */
t4=((C_word*)t0)[2];
f_5262(t4,t1);}}
else{
t4=C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
if(C_truep(C_i_nullp(t2))){
/* support.scm:144: err */
t5=((C_word*)t0)[2];
f_5262(t5,t1);}
else{
t5=C_i_cdr(t2);
t6=C_i_cdr(t3);
/* support.scm:145: loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* k6461 in for-each-loop632 in k6424 in k6376 in initialize-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6463(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6463,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6453(t3,((C_word*)t0)[4],t2);}

/* g3775 in k15724 in k15721 in k15718 in k15715 in k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_15727(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_15727,3,t0,t1,t2);}
/* support.scm:1545: g3790 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_15674(t3,t1,((C_word*)t0)[3],t2);}

/* k15724 in k15721 in k15718 in k15715 in k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15726(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_15726,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_check_list_2(((C_word*)t0)[4],lf[35]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15737,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15799,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_15799(t8,t4,((C_word*)t0)[4]);}

/* k15780 in k15777 in doloop3805 in k15756 in k15753 in k15735 in k15724 in k15721 in k15718 in k15715 in k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 in ... */
static void C_ccall f_15782(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_15782,2,av);}
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_15766(t3,((C_word*)t0)[4],t2);}

/* k5272 in k5268 in err in check-signature in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5274(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5274,2,av);}
/* support.scm:138: quit */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[46];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5268 in err in check-signature in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_5270,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5274,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
/* support.scm:140: map-llist */
t5=*((C_word*)lf[44]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=*((C_word*)lf[47]+1);
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k10125 in k10060 in k10057 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,5))){C_save_and_reclaim((void *)f_10127,2,av);}
a=C_alloc(14);
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10135,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10143,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[9])){
t7=((C_word*)t0)[9];
/* support.scm:712: alist-ref */
t8=*((C_word*)lf[287]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=((C_word*)t0)[4];
av2[4]=*((C_word*)lf[13]+1);
av2[5]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(6,av2);}}
else{
/* support.scm:751: build-lambda-list */
t7=*((C_word*)lf[63]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=((C_word*)t0)[7];
av2[3]=((C_word*)t0)[8];
av2[4]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}}

/* for-each-loop3774 in k15724 in k15721 in k15718 in k15715 in k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_15799(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_15799,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15809,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1545: g3775 */
t5=((C_word*)t0)[3];
f_15727(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k11889 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11891(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(29,c,2))){C_save_and_reclaim((void *)f_11891,2,av);}
a=C_alloc(29);
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11906,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[352]+1))){
t7=t6;
f_11906(t7,t2);}
else{
t7=C_a_i_list(&a,2,lf[97],lf[363]);
t8=t6;
f_11906(t8,C_a_i_list(&a,3,lf[364],t7,t2));}}

/* k10133 in k10125 in k10060 in k10057 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10135(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,3))){C_save_and_reclaim((void *)f_10135,2,av);}
a=C_alloc(33);
t2=C_i_cadddr(((C_word*)t0)[2]);
t3=C_a_i_list4(&a,4,((C_word*)t0)[3],((C_word*)t0)[4],t1,t2);
t4=t3;
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10079,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t10=C_i_check_list_2(((C_word*)t0)[7],lf[161]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10089,a[2]=((C_word*)t0)[8],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10091,a[2]=t7,a[3]=t13,a[4]=t9,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_10091(t15,t11,((C_word*)t0)[7]);}

/* ##compiler#chop-extension in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14982(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_14982,3,av);}
a=C_alloc(10);
t3=C_i_string_length(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14991,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_14991(t8,t1,t4);}

/* k14688 in for-each-loop3432 in k14670 in walk in scan-used-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14690(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_14690,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_14680(t3,((C_word*)t0)[4],t2);}

/* k15201 in k15169 in loop in k15143 in k15212 in k15116 in real-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15203(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_15203,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=t2;
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15199,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1451: get */
t7=*((C_word*)lf[148]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[7];
av2[4]=lf[181];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* a13296 in estimate-foreign-result-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_13297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_13297,2,av);}
/* support.scm:1198: quit */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[442];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k15759 in k15756 in k15753 in k15735 in k15724 in k15721 in k15718 in k15715 in k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15761(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_15761,2,av);}
/* write-char/port */
t2=*((C_word*)lf[526]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(93);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* for-each-loop534 in initialize-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_6499(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,4))){
C_save_and_reclaim_args((void *)trf_6499,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6509,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6349,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_a_i_list(&a,1,lf[147]);
if(C_truep(C_i_nullp(t8))){
/* tweaks.scm:54: ##sys#put! */
t9=*((C_word*)lf[142]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t7;
av2[2]=t6;
av2[3]=lf[143];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t9=C_i_car(t8);
/* tweaks.scm:54: ##sys#put! */
t10=*((C_word*)lf[142]+1);{
C_word av2[5];
av2[0]=t10;
av2[1]=t7;
av2[2]=t6;
av2[3]=lf[143];
av2[4]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k15777 in doloop3805 in k15756 in k15753 in k15735 in k15724 in k15721 in k15718 in k15715 in k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15779(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_15779,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[5],((C_word*)t0)[2]);
/* support.scm:1549: ##sys#print */
t4=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* loop in chop-extension in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14991(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(4,0,4))){
C_save_and_reclaim_args((void *)trf_14991,3,t0,t1,t2);}
a=C_alloc(4);
if(C_truep(C_i_zerop(t2))){
t3=((C_word*)t0)[2];
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_i_string_ref(((C_word*)t0)[2],t2);
if(C_truep(C_u_i_char_equalp(C_make_character(46),t3))){
/* support.scm:1393: substring */
t4=*((C_word*)lf[484]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(0);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=C_a_i_minus(&a,2,t2,C_fix(1));
/* support.scm:1394: loop */
t6=t1;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}}

/* doloop3805 in k15756 in k15753 in k15735 in k15724 in k15721 in k15718 in k15715 in k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_15766(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_15766,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=*((C_word*)lf[16]+1);
t4=*((C_word*)lf[16]+1);
t5=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15779,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:1549: ##sys#write-char-0 */
t7=*((C_word*)lf[18]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=C_make_character(32);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}

/* k14963 in chop-separator in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14965(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_14965,2,t0,t1);}
if(C_truep(t1)){
/* support.scm:1386: substring */
t2=*((C_word*)lf[484]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_fix(0);
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11839 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11841(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(42,c,1))){C_save_and_reclaim((void *)f_11841,2,av);}
a=C_alloc(42);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=(C_truep(*((C_word*)lf[352]+1))?t1:C_a_i_list(&a,2,lf[360],t1));
t5=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[225],t1,t4,t5);
t7=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[109],t3,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* for-each-loop583 in k6376 in initialize-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_6476(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,4))){
C_save_and_reclaim_args((void *)trf_6476,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6486,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6397,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_a_i_list(&a,1,lf[146]);
if(C_truep(C_i_nullp(t8))){
/* tweaks.scm:54: ##sys#put! */
t9=*((C_word*)lf[142]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t7;
av2[2]=t6;
av2[3]=lf[143];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t9=C_i_car(t8);
/* tweaks.scm:54: ##sys#put! */
t10=*((C_word*)lf[142]+1);{
C_word av2[5];
av2[0]=t10;
av2[1]=t7;
av2[2]=t6;
av2[3]=lf[143];
av2[4]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k12273 in k12235 in k12198 in k12155 in k12110 in k12066 in k12039 in k12012 in k11986 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 in ... */
static void C_ccall f_12275(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(51,c,1))){C_save_and_reclaim((void *)f_12275,2,av);}
a=C_alloc(51);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[97],lf[389]);
t5=C_a_i_list(&a,3,lf[390],((C_word*)t0)[2],t4);
t6=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t7=C_a_i_list(&a,4,lf[225],t1,t5,t6);
t8=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_a_i_list(&a,3,lf[109],t3,t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* k8288 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8290(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_8290,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[246],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1275 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_8292(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8292,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8317,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:591: g1281 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_11823(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,2))){
C_save_and_reclaim_args((void *)trf_11823,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=(C_truep(*((C_word*)lf[352]+1))?((C_word*)t0)[3]:C_a_i_list(&a,2,lf[357],((C_word*)t0)[3]));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[358]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[359]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1027: gensym */
t5=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[4],lf[361]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[362]));
if(C_truep(t5)){
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(*((C_word*)lf[352]+1))?((C_word*)t0)[3]:C_a_i_list(&a,2,lf[360],((C_word*)t0)[3]));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(((C_word*)t0)[4],lf[363]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11891,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1039: gensym */
t8=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=C_eqp(((C_word*)t0)[4],lf[365]);
if(C_truep(t7)){
if(C_truep(*((C_word*)lf[352]+1))){
t8=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t8;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_a_i_list(&a,2,lf[97],lf[363]);
t9=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t9;
av2[1]=C_a_i_list(&a,3,lf[364],t8,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}
else{
t8=C_eqp(((C_word*)t0)[4],lf[366]);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11946,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t8)){
t10=t9;
f_11946(t10,t8);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[417]);
if(C_truep(t10)){
t11=t9;
f_11946(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[418]);
if(C_truep(t11)){
t12=t9;
f_11946(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[419]);
if(C_truep(t12)){
t13=t9;
f_11946(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[420]);
if(C_truep(t13)){
t14=t9;
f_11946(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[421]);
if(C_truep(t14)){
t15=t9;
f_11946(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[4],lf[422]);
t16=t9;
f_11946(t16,(C_truep(t15)?t15:C_eqp(((C_word*)t0)[4],lf[423])));}}}}}}}}}}}}

/* ##compiler#chop-separator in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14955(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_14955,3,av);}
a=C_alloc(9);
t3=C_i_string_length(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14965,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_greaterp(t5,C_fix(0)))){
t7=C_i_string_ref(t2,t5);
t8=t6;
f_14965(t8,C_u_i_memq(t7,lf[485]));}
else{
t7=t6;
f_14965(t7,C_SCHEME_FALSE);}}

/* k14948 in scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14950(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_14950,2,av);}
/* support.scm:1377: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=((C_word*)((C_word*)t0)[4])[1];
C_values(4,av2);}}

/* k10154 in k10057 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_10156,2,av);}
/* support.scm:747: append */
t2=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* for-each-loop3498 in walkeach in scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14926(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_14926,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14936,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1344: g3499 */
t5=((C_word*)t0)[3];
f_14914(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* map-loop1968 in k10057 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10158(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_10158,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_11808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_11808,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[352]+1))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[355],((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[356]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11823,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_11823(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[424]);
t5=t3;
f_11823(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[425])));}}}

/* k4938 in for-each-loop50 in k4908 in k4896 in a4893 in text in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4940(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4940,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4930(t3,((C_word*)t0)[4],t2);}

/* k14624 in for-each-loop3408 in k14606 in walk in scan-used-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14626(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_14626,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_14616(t3,((C_word*)t0)[4],t2);}

/* k14934 in for-each-loop3498 in walkeach in scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14936(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_14936,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_14926(t3,((C_word*)t0)[4],t2);}

/* k13882 in k13854 in k13738 in finish-foreign-result in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_13884(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(60,c,1))){C_save_and_reclaim((void *)f_13884,2,av);}
a=C_alloc(60);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[454],t1);
t5=C_a_i_list(&a,2,lf[455],t4);
t6=C_i_caddr(((C_word*)t0)[3]);
t7=C_a_i_list(&a,2,lf[97],lf[389]);
t8=C_a_i_list(&a,4,lf[456],t6,t7,t1);
t9=C_a_i_list(&a,4,lf[457],t1,t5,t8);
t10=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=C_a_i_list(&a,3,lf[109],t3,t9);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}

/* dump in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_4953(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_4953,3,t0,t1,t2);}
a=C_alloc(5);
t3=*((C_word*)lf[8]+1);
t4=*((C_word*)lf[8]+1);
t5=C_i_check_port_2(*((C_word*)lf[8]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[24]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4960,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:62: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[2];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[8]+1);
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* for-each-loop3408 in k14606 in walk in scan-used-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14616(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_14616,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14626,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1336: g3409 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6507 in for-each-loop534 in initialize-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6509(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6509,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6499(t3,((C_word*)t0)[4],t2);}

/* k4923 in for-each-loop50 in k4908 in k4896 in a4893 in text in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_4925(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4925,2,av);}
/* support.scm:70: ##sys#print */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g3499 in walkeach in scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14914(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_14914,3,t0,t1,t2);}
/* support.scm:1374: walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_14728(t3,t1,t2,((C_word*)t0)[3]);}

/* for-each-loop3432 in k14670 in walk in scan-used-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14680(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_14680,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14690,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1338: g3433 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8204 in map-loop1231 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8206(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8206,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8181(t6,((C_word*)t0)[5],t5);}

/* k14180 in k14105 in k14030 in k14006 in foreign-type->scrutiny-type in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14182(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_14182,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[425];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[377]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[475];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[3],lf[379]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[395];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[380]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_14203(t6,t4);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[400]);
if(C_truep(t6)){
t7=t5;
f_14203(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[401]);
t8=t5;
f_14203(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[3],lf[402])));}}}}}}

/* walkeach in scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14912(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_14912,4,t0,t1,t2,t3);}
a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14914,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_check_list_2(t2,lf[35]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14926,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_14926(t9,t1,t2);}

/* k14670 in walk in scan-used-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14672(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_14672,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=C_i_check_list_2(((C_word*)t0)[4],lf[35]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14680,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_14680(t7,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k10114 in map-loop2005 in k10133 in k10125 in k10060 in k10057 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10116(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_10116,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10091(t6,((C_word*)t0)[5],t5);}

/* k16232 in print-usage in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16234(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_16234,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16237,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1666: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* ##compiler#print-usage in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16230(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_16230,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16234,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1665: print-version */
t3=*((C_word*)lf[557]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k16235 in k16232 in print-usage in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16237(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_16237,2,av);}
/* support.scm:1667: display */
t2=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[561];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k12113 in k12110 in k12066 in k12039 in k12012 in k11986 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_12115(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,2))){C_save_and_reclaim((void *)f_12115,2,av);}
a=C_alloc(26);
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12130,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[352]+1))){
t7=t6;
f_12130(t7,C_a_i_list(&a,2,lf[381],t2));}
else{
t7=C_a_i_list(&a,2,lf[382],t2);
t8=t6;
f_12130(t8,C_a_i_list(&a,2,lf[381],t7));}}

/* k12110 in k12066 in k12039 in k12012 in k11986 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_12112(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_12112,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1086: gensym */
t3=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[383]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12157,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_12157(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[398]);
t5=t3;
f_12157(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[399])));}}}

/* ##compiler#print-debug-options in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16242(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_16242,2,av);}
/* support.scm:1794: display */
t2=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[563];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a16247 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16248(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_16248,4,av);}
a=C_alloc(5);
t4=t3;
t5=C_i_check_port_2(t4,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[24]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16255,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:512: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[564];
av2[3]=C_SCHEME_FALSE;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k6484 in for-each-loop583 in k6376 in initialize-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6486(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6486,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6476(t3,((C_word*)t0)[4],t2);}

/* map-loop1728 in k9415 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_9497(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_9497,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9522,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:673: g1734 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k13854 in k13738 in finish-foreign-result in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_13856(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(18,0,3))){
C_save_and_reclaim_args((void *)trf_13856,2,t0,t1);}
a=C_alloc(18);
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
/* support.scm:1249: finish-foreign-result */
t3=*((C_word*)lf[446]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=C_i_length(((C_word*)t0)[2]);
t3=C_eqp(C_fix(3),t2);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[2]);
t5=C_eqp(t4,lf[387]);
t6=(C_truep(t5)?t5:C_eqp(t4,lf[388]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13884,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1253: gensym */
t8=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=C_eqp(t4,lf[391]);
if(C_truep(t7)){
t8=C_i_caddr(((C_word*)t0)[2]);
t9=C_a_i_list(&a,2,lf[97],lf[389]);
t10=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t10;
av2[1]=C_a_i_list(&a,4,lf[456],t8,t9,((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t8=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t8;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}}
else{
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* k16210 in print-version in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16212(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_16212,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16219,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1662: chicken-version */
t3=*((C_word*)lf[306]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k9493 in k9415 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9495(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9495,2,av);}
/* support.scm:673: cons* */
t2=*((C_word*)lf[270]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k9166 in k9162 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9168(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_9168,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[269],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k16217 in k16210 in print-version in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16219(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_16219,2,av);}
/* support.scm:1662: print */
t2=*((C_word*)lf[295]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k9162 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9164(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_9164,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9168,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
t5=C_u_i_cdr(((C_word*)t0)[4]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9176,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_9176(t9,t3,t4,t5);}

/* loop in k9162 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_9176(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_9176,4,t0,t1,t2,t3);}
a=C_alloc(7);
if(C_truep(C_i_nullp(t2))){
if(C_truep(C_i_nullp(t3))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9200,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_i_car(t3);
/* support.scm:658: walk */
t6=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
f_8779(3,av2);}}}
else{
t4=C_i_car(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9227,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=C_i_car(t3);
/* support.scm:659: walk */
t8=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
f_8779(3,av2);}}}

/* k9460 in map-loop1699 in k9422 in k9415 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9462(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_9462,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9437(t6,((C_word*)t0)[5],t5);}

/* k13335 in k13323 in a13314 in estimate-foreign-result-location-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_13337(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_13337,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
/* support.scm:1214: words->bytes */
t2=*((C_word*)lf[79]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(2);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13343,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
/* support.scm:1216: ##sys#hash-table-ref */
t3=*((C_word*)lf[149]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[397]+1);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_13343(2,av2);}}}}

/* ##compiler#set-real-name! in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15092(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_15092,4,av);}
/* support.scm:1423: ##sys#hash-table-set! */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=*((C_word*)lf[496]+1);
av2[3]=t2;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k5600 in k5559 in loop in k5535 in c-ify-string in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5602(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_5602,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* ##compiler#real-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +8,c,3))){
C_save_and_reclaim((void*)f_15099,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+8);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15102,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15118,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1435: resolve */
f_15102(t5,t2);}

/* ##compiler#valid-c-identifier? in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5618(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5618,3,av);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5622,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5666,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:202: ->string */
t5=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* g3138 in k13341 in k13335 in k13323 in a13314 in estimate-foreign-result-location-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_13347(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_13347,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1218: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t2;
/* support.scm:1218: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k15312 in call-info in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15314(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_15314,2,av);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5073 in k5070 in k5067 in with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5075(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5075,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:98: flush-output */
t3=*((C_word*)lf[25]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5076 in k5073 in k5070 in k5067 in with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5078(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5078,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:99: test-debugging-mode */
t3=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5070 in k5067 in with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5072(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5072,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:97: display */
t4=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k13341 in k13335 in k13323 in a13314 in estimate-foreign-result-location-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_13343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_13343,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1216: g3138 */
t3=t2;
f_13347(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[386]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13380,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_13380(t6,t4);}
else{
t6=C_eqp(t3,lf[394]);
if(C_truep(t6)){
t7=t5;
f_13380(t7,t6);}
else{
t7=C_eqp(t3,lf[395]);
if(C_truep(t7)){
t8=t5;
f_13380(t8,t7);}
else{
t8=C_eqp(t3,lf[377]);
if(C_truep(t8)){
t9=t5;
f_13380(t9,t8);}
else{
t9=C_eqp(t3,lf[379]);
if(C_truep(t9)){
t10=t5;
f_13380(t10,t9);}
else{
t10=C_eqp(t3,lf[396]);
if(C_truep(t10)){
t11=t5;
f_13380(t11,t10);}
else{
t11=C_eqp(t3,lf[359]);
t12=t5;
f_13380(t12,(C_truep(t11)?t11:C_eqp(t3,lf[361])));}}}}}}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[4];
/* support.scm:1202: quit */
t4=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[444];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}}

/* k14638 in walk in scan-used-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14640(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,1))){
C_save_and_reclaim_args((void *)trf_14640,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];
f_14608(t4,t3);}
else{
t2=((C_word*)t0)[4];
f_14608(t2,C_SCHEME_UNDEFINED);}}

/* loop in posv in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5367(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_5367,4,t0,t1,t2,t3);}
a=C_alloc(4);
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_car(t2);
if(C_truep(C_i_eqvp(((C_word*)t0)[2],t4))){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=t2;
t6=C_u_i_cdr(t5);
t7=C_a_i_plus(&a,2,t3,C_fix(1));
/* support.scm:160: loop */
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}}

/* ##compiler#posv in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5361(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_5361,4,av);}
a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5367,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5367(t7,t1,t3,C_fix(0));}

/* ##compiler#call-info in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15307(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,5))){C_save_and_reclaim((void *)f_15307,4,av);}
a=C_alloc(4);
t4=C_i_cdr(t2);
t5=C_i_pairp(t4);
t6=(C_truep(t5)?C_i_cadr(t2):C_SCHEME_FALSE);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15314,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t6)){
if(C_truep(C_i_listp(t6))){
t8=C_i_car(t6);
t9=C_i_cadr(t6);
/* support.scm:1482: conc */
t10=*((C_word*)lf[506]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t10;
av2[1]=t7;
av2[2]=lf[513];
av2[3]=t8;
av2[4]=lf[514];
av2[5]=t3;
((C_proc)(void*)(*((C_word*)t10+1)))(6,av2);}}
else{
t8=t3;
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}
else{
t8=t3;
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}

/* k5067 in with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5069,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:96: with-output-to-string */
t3=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:101: test-debugging-mode */
t3=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=*((C_word*)lf[9]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k5015 in g104 in collect in with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5017(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5017,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:90: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(124);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k13323 in a13314 in estimate-foreign-result-location-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_13325(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_13325,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
/* support.scm:1212: words->bytes */
t2=*((C_word*)lf[79]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[424]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_13337(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[425]);
if(C_truep(t4)){
t5=t3;
f_13337(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[371]);
t6=t3;
f_13337(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[3],lf[375])));}}}}

/* g104 in collect in with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5010(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_5010,3,t0,t1,t2);}
a=C_alloc(5);
t3=*((C_word*)lf[8]+1);
t4=*((C_word*)lf[8]+1);
t5=C_i_check_port_2(*((C_word*)lf[8]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[24]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5017,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t7=((C_word*)t0)[2];
t8=C_u_i_car(t7);
/* support.scm:90: ##sys#print */
t9=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t6;
av2[2]=t8;
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[8]+1);
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t7=((C_word*)t0)[2];
/* support.scm:90: ##sys#print */
t8=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}}

/* k8117 in map-loop1197 in k8078 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8119(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8119,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8094(t6,((C_word*)t0)[5],t5);}

/* ##compiler#print-version in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16205(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +6,c,2))){
C_save_and_reclaim((void*)f_16205,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+6);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16212,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t4)){
/* support.scm:1661: print* */
t6=*((C_word*)lf[558]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[559];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f17604,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1662: chicken-version */
t7=*((C_word*)lf[306]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}}

/* k16201 in k16109 in load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16203(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_16203,2,av);}
/* support.scm:1647: file-exists? */
t2=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15368(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_15368,2,av);}
a=C_alloc(18);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_check_list_2(t2,lf[161]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15518,a[2]=t5,a[3]=t10,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_15518(t12,t8,t2);}

/* a5642 in k5620 in valid-c-identifier? in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5643(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5643,3,av);}
t3=C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_u_i_char_numericp(t2);
if(C_truep(t4)){
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=t2;
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_u_i_char_equalp(C_make_character(95),t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}

/* ##compiler#with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5005(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_5005,4,av);}
a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5008,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5069,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:95: test-debugging-mode */
t6=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
av2[3]=*((C_word*)lf[1]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k5001 in k4994 in k4970 in debugging in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5003,2,av);}
/* support.scm:84: dump */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4953(t2,((C_word*)t0)[3],t1);}

/* collect in with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5008(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_5008,3,t0,t1,t2);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5010,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5037,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:94: string-split */
t5=*((C_word*)lf[27]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
av2[3]=lf[28];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k6606 in collect! in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6608(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_6608,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=C_slot(t2,C_fix(1));
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_i_setslot(t2,C_fix(1),t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
t4=C_slot(t1,C_fix(1));
t5=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t3),t4);
t6=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_i_setslot(t1,C_fix(1),t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_list1(&a,1,t2);
/* support.scm:400: ##sys#hash-table-set! */
t4=*((C_word*)lf[153]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* ##compiler#collect! in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_6604,6,av);}
a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6608,a[2]=t4,a[3]=t5,a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:395: ##sys#hash-table-ref */
t7=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* loop in posq in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5333(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_5333,4,t0,t1,t2,t3);}
a=C_alloc(4);
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_car(t2);
t5=C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=t2;
t7=C_u_i_cdr(t6);
t8=C_a_i_plus(&a,2,t3,C_fix(1));
/* support.scm:154: loop */
t10=t1;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}}

/* ##compiler#words->bytes in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5675(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5675,3,av);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=stub346(C_SCHEME_UNDEFINED,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5035 in collect in with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5037,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5042,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5042(t5,((C_word*)t0)[3],t1);}

/* k13378 in k13341 in k13335 in k13323 in a13314 in estimate-foreign-result-location-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_13380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_13380,2,t0,t1);}
if(C_truep(t1)){
/* support.scm:1223: words->bytes */
t2=*((C_word*)lf[79]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
/* support.scm:1202: quit */
t4=*((C_word*)lf[29]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[444];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* ##compiler#count! in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6656(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand((c-5)*C_SIZEOF_PAIR +7,c,3))){
C_save_and_reclaim((void*)f_6656,c,av);}
a=C_alloc((c-5)*C_SIZEOF_PAIR+7);
t5=C_build_rest(&a,c,5,av);
C_word t6;
C_word t7;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6660,a[2]=t4,a[3]=t1,a[4]=t5,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:403: ##sys#hash-table-ref */
t7=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* ##compiler#constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15344(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_15344,5,av);}
a=C_alloc(17);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=C_i_check_list_2(t3,lf[161]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15368,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15552,a[2]=t7,a[3]=t12,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_15552(t14,t10,t3);}

/* k5664 in valid-c-identifier? in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5666(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5666,2,av);}
/* string->list */
t2=*((C_word*)lf[71]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* ##compiler#words in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5668,3,av);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=stub341(C_SCHEME_UNDEFINED,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5021 in k5018 in k5015 in g104 in collect in with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5023(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5023,2,av);}
/* support.scm:90: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5018 in k5015 in g104 in collect in with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5020(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_5020,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5023,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:90: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6661 in k6658 in count! in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_6663(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_6663,2,t0,t1);}
a=C_alloc(6);
if(C_truep(((C_word*)t0)[2])){
t2=C_i_assq(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t2)){
t3=C_slot(t2,C_fix(1));
t4=C_a_i_plus(&a,2,t3,t1);
t5=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_i_setslot(t2,C_fix(1),t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1),t3);
t5=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_i_setslot(((C_word*)t0)[2],C_fix(1),t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[5]);
t3=C_a_i_list1(&a,1,t2);
/* support.scm:409: ##sys#hash-table-set! */
t4=*((C_word*)lf[153]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[7];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* k6658 in count! in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6660(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_6660,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6663,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t4=((C_word*)t0)[4];
t5=t3;
f_6663(t5,C_u_i_car(t4));}
else{
t4=t3;
f_6663(t4,C_fix(1));}}

/* g2981 in k12924 in k12918 in k12906 in k12894 in k12885 in a12876 in estimate-foreign-result-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_12930(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_12930,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1191: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=t2;
/* support.scm:1191: next */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k5693 in check-and-open-input-file in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5695(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5695,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
/* support.scm:222: open-input-file */
t2=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_i_nullp(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_5707(t4,t2);}
else{
t4=C_i_car(((C_word*)t0)[4]);
t5=t3;
f_5707(t5,C_i_not(t4));}}}

/* k12918 in k12906 in k12894 in k12885 in a12876 in estimate-foreign-result-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_12920(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_12920,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
/* support.scm:1187: words->bytes */
t2=*((C_word*)lf[79]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(4);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
/* support.scm:1189: ##sys#hash-table-ref */
t3=*((C_word*)lf[149]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[397]+1);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_12926(2,av2);}}}}

/* k12924 in k12918 in k12906 in k12894 in k12885 in a12876 in estimate-foreign-result-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_12926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_12926,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12930,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1189: g2981 */
t3=t2;
f_12930(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[386]);
if(C_truep(t4)){
if(C_truep(t4)){
/* support.scm:1195: words->bytes */
t5=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t5=C_eqp(t3,lf[394]);
if(C_truep(t5)){
if(C_truep(t5)){
/* support.scm:1195: words->bytes */
t6=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t6=C_eqp(t3,lf[395]);
if(C_truep(t6)){
if(C_truep(t6)){
/* support.scm:1195: words->bytes */
t7=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t7=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}
else{
t7=C_eqp(t3,lf[377]);
if(C_truep(t7)){
if(C_truep(t7)){
/* support.scm:1195: words->bytes */
t8=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t8=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}
else{
t8=C_eqp(t3,lf[379]);
if(C_truep(t8)){
if(C_truep(t8)){
/* support.scm:1195: words->bytes */
t9=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t9=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}
else{
t9=C_eqp(t3,lf[396]);
if(C_truep(t9)){
if(C_truep(t9)){
/* support.scm:1195: words->bytes */
t10=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}
else{
t10=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}}
else{
t10=C_eqp(t3,lf[387]);
if(C_truep(t10)){
if(C_truep(t10)){
/* support.scm:1195: words->bytes */
t11=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t11=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}
else{
t11=C_eqp(t3,lf[388]);
if(C_truep(t11)){
if(C_truep(t11)){
/* support.scm:1195: words->bytes */
t12=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t12;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
t12=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}}
else{
t12=C_eqp(t3,lf[391]);
if(C_truep(t12)){
/* support.scm:1195: words->bytes */
t13=*((C_word*)lf[79]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t13;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t13+1)))(3,av2);}}
else{
t13=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}}}}}}}}}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}}

/* ##compiler#check-and-open-input-file in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5682(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +5,c,2))){
C_save_and_reclaim((void*)f_5682,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+5);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
if(C_truep(C_i_string_equal_p(t2,lf[81]))){
t4=*((C_word*)lf[82]+1);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=*((C_word*)lf[82]+1);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5695,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:222: file-exists? */
t5=*((C_word*)lf[86]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k12906 in k12894 in k12885 in a12876 in estimate-foreign-result-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_12908(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_12908,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
/* support.scm:1185: words->bytes */
t2=*((C_word*)lf[79]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(4);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[356]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_12920(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[424]);
if(C_truep(t4)){
t5=t3;
f_12920(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[425]);
if(C_truep(t5)){
t6=t3;
f_12920(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[371]);
t7=t3;
f_12920(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[3],lf[375])));}}}}}

/* k10686 in for-each-loop2213 in k10668 in k10657 in a10654 in k10590 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10688(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10688,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10678(t3,((C_word*)t0)[4],t2);}

/* k16253 in a16247 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16255(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_16255,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(1));
/* support.scm:512: ##sys#print */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* ##compiler#estimate-foreign-result-location-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_13303(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_13303,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13315,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13730,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1203: follow-without-loop */
t5=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* walk in expression-has-side-effects? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11129(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_11129,3,av);}
a=C_alloc(7);
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(1));
t8=t7;
t9=C_eqp(t8,lf[221]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11155,a[2]=t1,a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_11155(t11,t9);}
else{
t11=C_eqp(t8,lf[97]);
if(C_truep(t11)){
t12=t10;
f_11155(t12,t11);}
else{
t12=C_eqp(t8,lf[226]);
t13=t10;
f_11155(t13,(C_truep(t12)?t12:C_eqp(t8,lf[245])));}}}

/* k16256 in k16253 in a16247 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16258(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_16258,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:512: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* ##compiler#expression-has-side-effects? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11123(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_11123,4,av);}
a=C_alloc(5);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11129,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t1;
av2[2]=t2;
f_11129(3,av2);}}

/* k10662 in for-each-loop2213 in k10668 in k10657 in a10654 in k10590 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10664(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_10664,2,av);}
/* support.scm:810: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k16259 in k16256 in k16253 in a16247 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16261(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_16261,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(2));
/* support.scm:512: ##sys#print */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k16262 in k16259 in k16256 in k16253 in a16247 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16264(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_16264,2,av);}
/* support.scm:512: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(62);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##compiler#posq in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5327(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_5327,4,av);}
a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5333,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5333(t7,t1,t3,C_fix(0));}

/* for-each-loop2213 in k10668 in k10657 in a10654 in k10590 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10678(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_10678,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10688,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10664,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm:809: pp */
t7=*((C_word*)lf[301]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k10671 in k10668 in k10657 in a10654 in k10590 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10673(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10673,2,av);}
/* support.scm:812: print */
t2=*((C_word*)lf[295]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[300];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k11051 in loop in k11002 in matchn in match-node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11053(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_11053,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:859: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11022(t6,((C_word*)t0)[5],t3,t5);}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k10668 in k10657 in a10654 in k10590 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10670(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_10670,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10673,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10678,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10678(t6,t2,t1);}

/* k5050 in for-each-loop103 in k5035 in collect in with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5052(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5052,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5042(t3,((C_word*)t0)[4],t2);}

/* loop in k11002 in matchn in match-node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_11022(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_11022,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t3))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_i_nullp(t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm:856: resolve */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10909(t4,t1,t3,t2);}
else{
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11053,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t2);
t6=C_i_car(t3);
/* support.scm:858: matchn */
t7=((C_word*)((C_word*)t0)[4])[1];
f_10982(t7,t4,t5,t6);}}}}

/* k11153 in walk in expression-has-side-effects? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_11155(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,3))){
C_save_and_reclaim_args((void *)trf_11155,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[133]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(2));
t5=C_i_car(t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11169,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* support.scm:877: find */
t8=*((C_word*)lf[321]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=((C_word*)t0)[2];
av2[2]=t7;
av2[3]=*((C_word*)lf[322]+1);
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t3=C_eqp(((C_word*)t0)[3],lf[225]);
if(C_truep(t3)){
if(C_truep(t3)){
/* support.scm:880: any */
t4=*((C_word*)lf[77]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)((C_word*)t0)[5])[1];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[109]);
if(C_truep(t4)){
/* support.scm:880: any */
t5=*((C_word*)lf[77]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)((C_word*)t0)[5])[1];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}}}}

/* for-each-loop103 in k5035 in collect in with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5042(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_5042,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5052,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:87: g104 */
t5=((C_word*)t0)[3];
f_5010(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k16197 in k16194 in k16191 in k16188 in k16185 in k16179 in k16115 in k16109 in load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_16199,2,av);}
/* support.scm:1648: debugging */
t2=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[552];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a10654 in k10590 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10655(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_10655,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10659,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10703,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:805: chicken-version */
t4=*((C_word*)lf[306]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k10657 in a10654 in k10590 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10659(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_10659,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:811: reverse */
t3=*((C_word*)lf[91]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k16194 in k16191 in k16188 in k16185 in k16179 in k16115 in k16109 in load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16196(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_16196,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16199,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1648: get-output-string */
t3=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* map-loop1099 in k7729 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_7804(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_7804,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7829,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_eqp(lf[232],t4);
if(C_truep(t5)){
/* support.scm:549: error */
t6=*((C_word*)lf[4]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t3;
av2[2]=lf[233];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t6=t3;{
C_word av2[2];
av2[0]=t6;
av2[1]=t4;
f_7829(2,av2);}}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k16191 in k16188 in k16185 in k16179 in k16115 in k16109 in load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16193(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_16193,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1648: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k16188 in k16185 in k16179 in k16115 in k16109 in load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16190(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_16190,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1648: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[553];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* a11168 in k11153 in walk in expression-has-side-effects? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11169(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_11169,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11177,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:878: foreign-callback-stub-id */
t4=*((C_word*)lf[320]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k10625 in for-each-loop2235 in k10607 in k10599 in k10593 in k10590 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10627(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_10627,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10617(t3,((C_word*)t0)[4],t2);}

/* k11175 in a11168 in k11153 in walk in expression-has-side-effects? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11177(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_11177,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_eqp(((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5620 in valid-c-identifier? in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5622(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(2,c,3))){C_save_and_reclaim((void *)f_5622,2,av);}
a=C_alloc(2);
if(C_truep(C_i_pairp(t1))){
t2=C_u_i_car(t1);
t3=C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:C_u_i_char_equalp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5643,tmp=(C_word)a,a+=2,tmp);
t6=C_u_i_cdr(t1);
/* support.scm:206: any */
t7=*((C_word*)lf[77]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[2];
av2[2]=t5;
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t5=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* ##compiler#block-variable-literal? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15028(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_15028,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_structurep(t2,lf[488]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k12012 in k11986 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_12014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_12014,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[352]+1))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[370],((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[371]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=(C_truep(*((C_word*)lf[352]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[372],((C_word*)t0)[2]));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[4],lf[373]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_12041(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[405]);
t6=t4;
f_12041(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[4],lf[406])));}}}}

/* ##compiler#make-block-variable-literal in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15022(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_15022,3,av);}
a=C_alloc(3);
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record2(&a,2,lf[488],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* ##compiler#inline-lambda-bindings in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9701(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,5))){C_save_and_reclaim((void *)f_9701,8,av);}
a=C_alloc(7);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9707,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* support.scm:686: decompose-lambda-list */
t9=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t1;
av2[2]=t2;
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}

/* a9706 in inline-lambda-bindings in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9707(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,4))){C_save_and_reclaim((void *)f_9707,5,av);}
a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9713,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9719,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* support.scm:688: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t5;
av2[3]=t6;
C_call_with_values(4,av2);}}

/* k9685 in k9681 in fold in fold-boolean in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9687(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_9687,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[242],lf[280],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k9681 in fold in fold-boolean in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9683(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_9683,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9687,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:683: fold */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9657(t6,t3,t5);}

/* k9721 in a9718 in a9706 in inline-lambda-bindings in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9723(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,6))){C_save_and_reclaim((void *)f_9723,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
/* support.scm:692: copy-node-tree-and-rename */
t4=*((C_word*)lf[286]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)t0)[9];
av2[4]=t2;
av2[5]=((C_word*)t0)[10];
av2[6]=((C_word*)t0)[11];
((C_proc)(void*)(*((C_word*)t4+1)))(7,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[8];
f_9726(2,av2);}}}

/* k9128 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_9130,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[267],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* ##compiler#block-variable-literal-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15034(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_15034,3,av);}
t3=C_i_check_structure_2(t2,lf[488],lf[491]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(1));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k9724 in k9721 in a9718 in a9706 in inline-lambda-bindings in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9726(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,5))){C_save_and_reclaim((void *)f_9726,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9731,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9752,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[6])){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9806,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm:698: last */
t6=*((C_word*)lf[265]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=t4;
f_9752(t5,t2);}}

/* k15067 in k15064 in k15061 in k15058 in k15055 in k15049 in make-random-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_15069,2,av);}
/* support.scm:1408: string->symbol */
t2=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k15064 in k15061 in k15058 in k15055 in k15049 in make-random-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15066(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_15066,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15069,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1409: get-output-string */
t3=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k15061 in k15058 in k15055 in k15049 in make-random-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15063(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_15063,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15073,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1412: random */
t4=*((C_word*)lf[493]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_fix(1000);
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k15058 in k15055 in k15049 in make-random-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15060(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_15060,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15077,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1411: current-seconds */
t4=*((C_word*)lf[494]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k16133 in for-each-loop3969 in k16149 in k16121 in k16115 in k16109 in load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16135(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_16135,2,av);}
/* support.scm:1652: ##sys#put! */
t2=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[550];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k16137 in for-each-loop3969 in k16149 in k16121 in k16115 in k16109 in load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_16139,2,av);}
a=C_alloc(3);
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_list1(&a,1,t3);
/* support.scm:1654: append */
t5=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k15159 in loop in k15143 in k15212 in k15116 in real-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15161(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_15161,2,av);}
/* support.scm:1444: string-intersperse */
t2=*((C_word*)lf[498]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[499];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k11667 in k11661 in k11658 in k11655 in k11649 in k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11669(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_11669,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:989: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11658 in k11655 in k11649 in k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11660(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_11660,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:988: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k11661 in k11658 in k11655 in k11649 in k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11663(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_11663,2,av);}
a=C_alloc(8);
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* support.scm:989: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[338];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* ##compiler#stringify in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5395(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5395,3,av);}
a=C_alloc(4);
if(C_truep(C_i_stringp(t2))){
t3=t2;
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(t2))){
/* support.scm:164: symbol->string */
t3=*((C_word*)lf[51]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5414,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:165: open-output-string */
t4=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* ##compiler#make-random-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15043(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_15043,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15051,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1409: open-output-string */
t4=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k16109 in load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16111(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_16111,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16117,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16203,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1647: make-pathname */
t4=*((C_word*)lf[555]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11670 in k11667 in k11661 in k11658 in k11655 in k11649 in k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11672(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_11672,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:989: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k11673 in k11670 in k11667 in k11661 in k11658 in k11655 in k11649 in k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11675(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_11675,2,av);}
a=C_alloc(7);
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* support.scm:990: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[337];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k16115 in k16109 in load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16117(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_16117,2,av);}
a=C_alloc(8);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16123,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16181,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1648: open-output-string */
t5=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8177 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8179(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_8179,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5465 in backslashify in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5467(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5467,2,av);}
/* support.scm:172: string-translate* */
t2=*((C_word*)lf[58]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[59];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k15075 in k15058 in k15055 in k15049 in make-random-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_15077,2,av);}
/* support.scm:1409: ##sys#print */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* ##compiler#uncommentify in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5469(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5469,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5477,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:174: ->string */
t4=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k15071 in k15061 in k15058 in k15055 in k15049 in make-random-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_15073,2,av);}
/* support.scm:1409: ##sys#print */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k16121 in k16115 in k16109 in load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16123(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_16123,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16151,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1655: read-file */
t3=*((C_word*)lf[551]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11645(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_11645,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* support.scm:987: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[9];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11648(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_11648,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* support.scm:987: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11642(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_11642,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:987: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[340];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11095 in match-node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11097(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,6))){C_save_and_reclaim((void *)f_11097,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11103,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(1));
t5=((C_word*)t0)[4];
t6=C_slot(t5,C_fix(2));
/* support.scm:864: debugging */
t7=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=lf[317];
av2[3]=lf[318];
av2[4]=t4;
av2[5]=t6;
av2[6]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t7+1)))(7,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k11101 in k11095 in match-node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11103(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_11103,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k11655 in k11649 in k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11657(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_11657,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* support.scm:988: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* map-loop1231 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_8181(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8181,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8206,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:583: g1237 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11649 in k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11651(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_11651,2,av);}
a=C_alloc(9);
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm:988: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[339];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k15055 in k15049 in make-random-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15057(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_15057,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1409: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(45);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k15049 in make-random-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15051(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_15051,2,av);}
a=C_alloc(9);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[52]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15057,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[3];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15081,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t6))){
/* support.scm:1410: gensym */
t8=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_i_car(t6);
/* support.scm:1409: ##sys#print */
t9=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t9;
av2[1]=t5;
av2[2]=t8;
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}}

/* k16179 in k16115 in k16109 in load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16181(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_16181,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[52]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16187,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1648: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[554];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k16185 in k16179 in k16115 in k16109 in load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16187(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_16187,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1648: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11626(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7=av[7];
C_word t8=av[8];
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_11626,9,av);}
a=C_alloc(10);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11633,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t6,a[6]=t5,a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* support.scm:986: debugging */
t10=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[342];
av2[3]=lf[343];
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}

/* a11619 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11620(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11620,2,av);}
/* support.scm:985: compute-database-statistics */
t2=*((C_word*)lf[331]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k15197 in k15201 in k15169 in loop in k15143 in k15212 in k15116 in real-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_15199,2,av);}
/* support.scm:1449: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_15147(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k15079 in k15049 in make-random-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15081(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_15081,2,av);}
/* support.scm:1409: ##sys#print */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11639(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_11639,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:987: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[10];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11633(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_11633,2,av);}
a=C_alloc(11);
if(C_truep(t1)){
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* support.scm:987: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[341];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10963 in match1 in match-node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_10965,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:845: match1 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10943(t6,((C_word*)t0)[5],t3,t5);}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k8851 in map-loop1489 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8853(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8853,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8828(t6,((C_word*)t0)[5],t5);}

/* ##compiler#symbolify in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5425(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5425,3,av);}
a=C_alloc(4);
if(C_truep(C_i_symbolp(t2))){
t3=t2;
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_stringp(t2))){
/* support.scm:169: string->symbol */
t3=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5448,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:170: open-output-string */
t4=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* k5418 in k5412 in stringify in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5420(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5420,2,av);}
/* support.scm:165: get-output-string */
t2=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8881 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8883(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_8883,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[264],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* g2297 in resolve in match-node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static C_word C_fcall f_10917(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_i_cdr(t1);
return(C_i_equalp(((C_word*)t0)[2],t2));}

/* k9774 in k9804 in k9724 in k9721 in a9718 in a9706 in inline-lambda-bindings in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9776(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_9776,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_9752(t3,C_a_i_record4(&a,4,lf[211],lf[109],((C_word*)t0)[4],t2));}

/* k5452 in k5446 in symbolify in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5454(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5454,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5457,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:170: get-output-string */
t3=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5455 in k5452 in k5446 in symbolify in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5457(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5457,2,av);}
/* support.scm:170: string->symbol */
t2=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* ##compiler#backslashify in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5459(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5459,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5467,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:172: ->string */
t4=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* map-loop1518 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_8885(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8885,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8910,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:631: g1524 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* ##compiler#print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11614(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,9))){C_save_and_reclaim((void *)f_11614,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11620,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11626,tmp=(C_word)a,a+=2,tmp);
/* support.scm:983: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
C_call_with_values(4,av2);}}

/* resolve in match-node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10909(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_10909,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10917,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:832: g2297 */
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=f_10917(t5,t4);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
if(C_truep(C_i_memq(t2,((C_word*)t0)[3]))){
t5=C_a_i_cons(&a,2,C_a_i_cons(&a,2,t2,t3),((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_eqp(t2,t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}}

/* ##compiler#match-node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10906(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,4))){C_save_and_reclaim((void *)f_10906,5,av);}
a=C_alloc(27);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10909,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t14=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10943,a[2]=t8,a[3]=t10,tmp=(C_word)a,a+=4,tmp));
t15=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10982,a[2]=t8,a[3]=t12,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11097,a[2]=t6,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:861: matchn */
t17=((C_word*)t12)[1];
f_10982(t17,t16,t2,t3);}

/* k5446 in symbolify in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5448(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_5448,2,av);}
a=C_alloc(4);
t2=t1;
t3=C_i_check_port_2(t2,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[52]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5454,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:170: ##sys#print */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k10898 in k10864 in loop in a10855 in load-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10900(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_10900,2,av);}
a=C_alloc(3);
t2=C_a_i_list(&a,1,t1);
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:54: ##sys#put! */
t3=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[312];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t3=C_i_car(t2);
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[312];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* k14779 in k14760 in walk in scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14781(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_14781,2,av);}
a=C_alloc(5);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14787,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1357: variable-visible? */
t4=*((C_word*)lf[313]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5120 in syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5122(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,4))){
C_save_and_reclaim_args((void *)trf_5122,2,t0,t1);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=((C_word*)t0)[2];
t5=C_i_check_port_2(t4,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[24]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5171,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* support.scm:119: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[40];
av2[3]=C_SCHEME_FALSE;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t4=((C_word*)t0)[2];
t5=C_i_check_port_2(t4,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[24]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5192,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:120: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[41];
av2[3]=C_SCHEME_FALSE;
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}}

/* k5123 in k5120 in syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5125(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_5125,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5126,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_i_check_list_2(t3,lf[35]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5136,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5144,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5144(t9,t5,t3);}

/* g169 in k5123 in k5120 in syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5126(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_5126,3,t0,t1,t2);}
/* support.scm:121: g184 */
t3=*((C_word*)lf[24]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=lf[34];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k15807 in for-each-loop3774 in k15724 in k15721 in k15718 in k15715 in k15712 in k15709 in k15700 in loop in dump-nodes in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15809(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_15809,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_15799(t3,((C_word*)t0)[4],t2);}

/* k14201 in k14180 in k14105 in k14030 in k14006 in foreign-type->scrutiny-type in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14203(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_14203,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[476];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[403]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[3],lf[404]));
if(C_truep(t3)){
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[477];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[383]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_14221(t6,t4);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[398]);
t7=t5;
f_14221(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[3],lf[399])));}}}}

/* a9730 in k9724 in k9721 in a9718 in a9706 in inline-lambda-bindings in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9731(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,1))){C_save_and_reclaim((void *)f_9731,5,av);}
a=C_alloc(14);
t5=C_a_i_list1(&a,1,t2);
t6=C_a_i_list2(&a,2,t3,t4);
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[109],t5,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k9104 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9106(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_9106,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list3(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k12155 in k12110 in k12066 in k12039 in k12012 in k11986 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_12157(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(18,0,3))){
C_save_and_reclaim_args((void *)trf_12157,2,t0,t1);}
a=C_alloc(18);
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[352]+1))){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[381],((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_a_i_list(&a,2,lf[382],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[381],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[384]);
if(C_truep(t2)){
if(C_truep(*((C_word*)lf[352]+1))){
t3=C_a_i_list(&a,2,lf[385],((C_word*)t0)[3]);
t4=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,lf[381],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_a_i_list(&a,2,lf[385],((C_word*)t0)[3]);
t4=C_a_i_list(&a,2,lf[382],t3);
t5=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_a_i_list(&a,2,lf[381],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12200,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[6]))){
/* support.scm:1102: ##sys#hash-table-ref */
t4=*((C_word*)lf[149]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[397]+1);
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_12200(2,av2);}}}}}

/* k14785 in k14779 in k14760 in walk in scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14787(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_14787,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1358: lset-adjoin */
t3=*((C_word*)lf[482]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[13]+1);
av2[3]=((C_word*)((C_word*)t0)[3])[1];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* ##compiler#quit in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5102(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +9,c,3))){
C_save_and_reclaim((void*)f_5102,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+9);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t4=*((C_word*)lf[30]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5106,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5116,a[2]=t5,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:106: string-append */
t7=*((C_word*)lf[5]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[32];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* ##compiler#load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16107(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_16107,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16111,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1646: repository-path */
t4=*((C_word*)lf[556]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k12039 in k12012 in k11986 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_12041(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_12041,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[352]+1))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,lf[374],((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=(C_truep(*((C_word*)lf[352]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[376],((C_word*)t0)[2]));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[4],lf[377]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_12068(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[403]);
t6=t4;
f_12068(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[4],lf[404])));}}}}

/* k5107 in k5104 in quit in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5109(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5109,2,av);}
/* support.scm:108: exit */
t2=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5104 in quit in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5106(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5106,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5109,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:107: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5098 in k5091 in k5067 in with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5100(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5100,2,av);}
/* support.scm:102: collect */
t2=((C_word*)t0)[2];
f_5008(t2,((C_word*)t0)[3],t1);}

/* k9750 in k9724 in k9721 in a9718 in a9706 in inline-lambda-bindings in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_9752(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_9752,2,t0,t1);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:707: take */
t4=*((C_word*)lf[284]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k9754 in k9750 in k9724 in k9721 in a9718 in a9706 in inline-lambda-bindings in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9756(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_9756,2,av);}
/* support.scm:694: fold-right */
t2=*((C_word*)lf[283]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
av2[5]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k12128 in k12113 in k12110 in k12066 in k12039 in k12012 in k11986 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_12130(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(27,0,1))){
C_save_and_reclaim_args((void *)trf_12130,2,t0,t1);}
a=C_alloc(27);
t2=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t3=C_a_i_list(&a,4,lf[225],((C_word*)t0)[2],t1,t2);
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[109],((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* ##compiler#scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,4))){C_save_and_reclaim((void *)f_14725,3,av);}
a=C_alloc(22);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14728,a[2]=t4,a[3]=t6,a[4]=t8,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14912,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14950,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1376: walk */
t14=((C_word*)t8)[1];
f_14728(t14,t13,t2,C_SCHEME_END_OF_LIST);}

/* walk in scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14728(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,2))){
C_save_and_reclaim_args((void *)trf_14728,4,t0,t1,t2,t3);}
a=C_alloc(11);
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=t11;
t13=C_eqp(t12,lf[97]);
t14=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_14762,a[2]=t1,a[3]=t12,a[4]=t9,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=t6,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t13)){
t15=t14;
f_14762(t15,t13);}
else{
t15=C_eqp(t12,lf[226]);
if(C_truep(t15)){
t16=t14;
f_14762(t16,t15);}
else{
t16=C_eqp(t12,lf[241]);
if(C_truep(t16)){
t17=t14;
f_14762(t17,t16);}
else{
t17=C_eqp(t12,lf[245]);
t18=t14;
f_14762(t18,(C_truep(t17)?t17:C_eqp(t12,lf[257])));}}}}

/* k5134 in k5123 in k5120 in syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5136(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_5136,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5139,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:122: print-call-chain */
t3=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=C_fix(0);
av2[4]=*((C_word*)lf[37]+1);
av2[5]=lf[38];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k5137 in k5134 in k5123 in k5120 in syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5139,2,av);}
/* support.scm:123: exit */
t2=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(70);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* for-each-loop2454 in a11509 in compute-database-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_11591(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(20,0,2))){
C_save_and_reclaim_args((void *)trf_11591,3,t0,t1,t2);}
a=C_alloc(20);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_11512(C_a_i(&a,20),((C_word*)t0)[2],t3);
t5=C_slot(t2,C_fix(1));
t7=t1;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* map-loop1857 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10314(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_10314,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k12066 in k12039 in k12012 in k11986 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_12068(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_12068,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1078: gensym */
t3=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[379]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[378],((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[4],lf[380]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_12112(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[400]);
if(C_truep(t5)){
t6=t4;
f_12112(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[401]);
t7=t4;
f_12112(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[402])));}}}}}

/* k11685 in k11682 in k11679 in k11673 in k11670 in k11667 in k11661 in k11658 in k11655 in k11649 in k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in ... */
static void C_ccall f_11687(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_11687,2,av);}
a=C_alloc(6);
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:991: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[336];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k11679 in k11673 in k11670 in k11667 in k11661 in k11658 in k11655 in k11649 in k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 in ... */
static void C_ccall f_11681(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_11681,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:990: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11682 in k11679 in k11673 in k11670 in k11667 in k11661 in k11658 in k11655 in k11649 in k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in ... */
static void C_ccall f_11684(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_11684,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:990: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k11694 in k11691 in k11685 in k11682 in k11679 in k11673 in k11670 in k11667 in k11661 in k11658 in k11655 in k11649 in k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in ... */
static void C_ccall f_11696(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_11696,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:991: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k11691 in k11685 in k11682 in k11679 in k11673 in k11670 in k11667 in k11661 in k11658 in k11655 in k11649 in k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in k6112 in k4861 in ... */
static void C_ccall f_11693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_11693,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:991: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* ##sys#syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5118(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +10,c,2))){
C_save_and_reclaim((void*)f_5118,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+10);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[30]+1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5122,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_symbolp(((C_word*)t4)[1]))){
t8=((C_word*)t4)[1];
t9=C_i_car(((C_word*)t5)[1]);
t10=C_set_block_item(t4,0,t9);
t11=C_i_cdr(((C_word*)t5)[1]);
t12=C_set_block_item(t5,0,t11);
t13=t7;
f_5122(t13,t8);}
else{
t8=t7;
f_5122(t8,C_SCHEME_FALSE);}}

/* k5114 in quit in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5116(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_5116,2,av);}{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[24]+1);
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
av2[5]=((C_word*)t0)[4];
C_apply(6,av2);}}

/* k11697 in k11694 in k11691 in k11685 in k11682 in k11679 in k11673 in k11670 in k11667 in k11661 in k11658 in k11655 in k11649 in k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in k6115 in ... */
static void C_ccall f_11699(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_11699,2,av);}
a=C_alloc(5);
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11705,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:992: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[335];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* matchn in match-node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10982(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_10982,4,t0,t1,t2,t3);}
a=C_alloc(7);
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm:850: resolve */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10909(t4,t1,t3,t2);}
else{
t4=t2;
t5=C_slot(t4,C_fix(1));
t6=C_i_car(t3);
t7=C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11004,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t9=t2;
t10=C_slot(t9,C_fix(2));
t11=C_i_cadr(t3);
/* support.scm:852: match1 */
t12=((C_word*)((C_word*)t0)[4])[1];
f_10943(t12,t8,t10,t11);}
else{
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}}

/* k8553 in k8595 in k8591 in a8531 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8555(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_8555,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[253],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* ##compiler#sexpr->node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10517(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_10517,3,av);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10523,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
f_10523(3,av2);}}

/* k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_11946(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_11946,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1051: gensym */
t3=*((C_word*)lf[110]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[367]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_11988(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[410]);
if(C_truep(t4)){
t5=t3;
f_11988(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[411]);
if(C_truep(t5)){
t6=t3;
f_11988(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[412]);
if(C_truep(t6)){
t7=t3;
f_11988(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[413]);
if(C_truep(t7)){
t8=t3;
f_11988(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[414]);
if(C_truep(t8)){
t9=t3;
f_11988(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[415]);
t10=t3;
f_11988(t10,(C_truep(t9)?t9:C_eqp(((C_word*)t0)[5],lf[416])));}}}}}}}}

/* for-each-loop168 in k5123 in k5120 in syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5144(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_5144,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5154,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:121: g169 */
t5=((C_word*)t0)[3];
f_5126(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* fold in fold-boolean in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_9657(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_9657,3,t0,t1,t2);}
a=C_alloc(5);
t3=C_i_cddr(t2);
if(C_truep(C_i_nullp(t3))){{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t2;
C_apply(4,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9683,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=C_u_i_car(t5);
t7=C_i_cadr(t2);
/* support.scm:682: proc */
t8=((C_word*)t0)[2];{
C_word av2[4];
av2[0]=t8;
av2[1]=t4;
av2[2]=t6;
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}}

/* k15824 in read-info-hook in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15826(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_15826,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k15827 in read-info-hook in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_15829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_15829,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1565: conc */
t5=*((C_word*)lf[506]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[528]+1);
av2[3]=lf[529];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* ##compiler#fold-boolean in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9651(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_9651,4,av);}
a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9657,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_9657(t7,t1,t3);}

/* ##compiler#read-info-hook in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15822(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_15822,5,av);}
a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15826,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15829,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_eqp(lf[530],t2);
if(C_truep(t7)){
t8=C_i_car(t3);
t9=t6;
f_15829(t9,C_i_symbolp(t8));}
else{
t8=t6;
f_15829(t8,C_SCHEME_FALSE);}}

/* k10506 in map-loop2113 in walk in node->sexpr in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10508(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_10508,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10483(t6,((C_word*)t0)[5],t5);}

/* map-loop1401 in k8595 in k8591 in a8531 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_8557(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8557,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8582,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:616: g1407 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k12069 in k12066 in k12039 in k12012 in k11986 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_12071(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(42,c,1))){C_save_and_reclaim((void *)f_12071,2,av);}
a=C_alloc(42);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[378],t1);
t5=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[225],t1,t4,t5);
t7=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[109],t3,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k5175 in k5172 in k5169 in k5120 in syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5177(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_5177,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:119: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5169 in k5120 in syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_5171,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:119: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5172 in k5169 in k5120 in syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5174(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_5174,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:119: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[39];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11947 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(29,c,2))){C_save_and_reclaim((void *)f_11949,2,av);}
a=C_alloc(29);
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11964,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[352]+1))){
t7=t6;
f_11964(t7,t2);}
else{
t7=C_a_i_list(&a,2,lf[97],((C_word*)t0)[4]);
t8=t6;
f_11964(t8,C_a_i_list(&a,3,lf[364],t7,t2));}}

/* k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_8813(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
if(!C_demand(C_calculate_demand(21,0,5))){
C_save_and_reclaim_args((void *)trf_8813,2,t0,t1);}
a=C_alloc(21);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=((C_word*)((C_word*)t0)[2])[1];
t7=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8826,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8828,a[2]=t4,a[3]=t10,a[4]=t6,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8828(t12,t8,((C_word*)t0)[3]);}
else{
t2=C_eqp(((C_word*)t0)[6],lf[264]);
if(C_truep(t2)){
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)((C_word*)t0)[2])[1];
t8=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8883,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8885,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_8885(t13,t9,((C_word*)t0)[3]);}
else{
t3=C_eqp(((C_word*)t0)[6],lf[221]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_i_car(((C_word*)t0)[7]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[6],lf[97]);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[7]);
t6=C_booleanp(t5);
if(C_truep(t6)){
if(C_truep(t6)){
t7=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t7;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_u_i_car(((C_word*)t0)[7]);
t8=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t8;
av2[1]=C_a_i_list(&a,2,lf[97],t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}
else{
t7=C_i_stringp(t5);
if(C_truep(t7)){
if(C_truep(t7)){
t8=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t8;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_u_i_car(((C_word*)t0)[7]);
t9=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t9;
av2[1]=C_a_i_list(&a,2,lf[97],t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}
else{
t8=C_i_numberp(t5);
t9=(C_truep(t8)?t8:C_charp(t5));
if(C_truep(t9)){
t10=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t10;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=C_u_i_car(((C_word*)t0)[7]);
t11=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t11;
av2[1]=C_a_i_list(&a,2,lf[97],t10);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}}}
else{
t5=C_eqp(((C_word*)t0)[6],lf[109]);
if(C_truep(t5)){
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=((C_word*)t0)[7];
t11=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t12=t11;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=((C_word*)t13)[1];
t15=((C_word*)((C_word*)t0)[2])[1];
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8983,a[2]=t10,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t8,a[7]=t9,a[8]=t13,a[9]=t15,a[10]=t14,tmp=(C_word)a,a+=11,tmp);
/* support.scm:639: butlast */
t17=*((C_word*)lf[266]+1);{
C_word av2[3];
av2[0]=t17;
av2[1]=t16;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t17+1)))(3,av2);}}
else{
t6=C_eqp(((C_word*)t0)[6],lf[133]);
if(C_truep(t6)){
t7=C_i_cadr(((C_word*)t0)[7]);
t8=(C_truep(t7)?lf[235]:lf[133]);
t9=t8;
t10=C_i_caddr(((C_word*)t0)[7]);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9106,a[2]=((C_word*)t0)[4],a[3]=t9,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t13=C_i_car(((C_word*)t0)[3]);
/* support.scm:646: walk */
t14=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t14;
av2[1]=t12;
av2[2]=t13;
f_8779(3,av2);}}
else{
t7=C_eqp(((C_word*)t0)[6],lf[236]);
if(C_truep(t7)){
t8=C_i_car(((C_word*)t0)[7]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9130,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=C_i_car(((C_word*)t0)[3]);
/* support.scm:648: walk */
t12=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t12;
av2[1]=t10;
av2[2]=t11;
f_8779(3,av2);}}
else{
t8=C_eqp(((C_word*)t0)[6],lf[268]);
if(C_truep(t8)){
t9=C_i_car(((C_word*)t0)[3]);
/* support.scm:650: walk */
t10=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t10;
av2[1]=((C_word*)t0)[4];
av2[2]=t9;
f_8779(3,av2);}}
else{
t9=C_eqp(((C_word*)t0)[6],lf[237]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9164,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t11=C_i_car(((C_word*)t0)[3]);
/* support.scm:653: walk */
t12=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t12;
av2[1]=t10;
av2[2]=t11;
f_8779(3,av2);}}
else{
t10=C_eqp(((C_word*)t0)[6],lf[253]);
if(C_truep(t10)){
t11=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t12=t11;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=((C_word*)t13)[1];
t15=((C_word*)((C_word*)t0)[2])[1];
t16=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9252,a[2]=t13,a[3]=t18,a[4]=t15,a[5]=t14,tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_9252(t20,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t11=C_eqp(((C_word*)t0)[6],lf[243]);
if(C_truep(t11)){
t12=C_i_car(((C_word*)t0)[7]);
t13=t12;
t14=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t15=t14;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=((C_word*)t16)[1];
t18=((C_word*)((C_word*)t0)[2])[1];
t19=C_i_check_list_2(((C_word*)t0)[3],lf[161]);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9307,a[2]=((C_word*)t0)[4],a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9309,a[2]=t16,a[3]=t22,a[4]=t18,a[5]=t17,tmp=(C_word)a,a+=6,tmp));
t24=((C_word*)t22)[1];
f_9309(t24,t20,((C_word*)t0)[3]);}
else{
t12=C_eqp(((C_word*)t0)[6],lf[226]);
if(C_truep(t12)){
t13=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t13;
av2[1]=C_a_i_list1(&a,1,((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t13=C_eqp(((C_word*)t0)[6],lf[271]);
if(C_truep(t13)){
t14=C_i_car(((C_word*)t0)[7]);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9365,a[2]=((C_word*)t0)[2],a[3]=t16,tmp=(C_word)a,a+=4,tmp));
t18=((C_word*)t16)[1];
f_9365(t18,((C_word*)t0)[4],t14,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t14=C_eqp(((C_word*)t0)[6],lf[272]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9417,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_9417(t16,t14);}
else{
t16=C_eqp(((C_word*)t0)[6],lf[274]);
if(C_truep(t16)){
t17=t15;
f_9417(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[6],lf[275]);
t18=t15;
f_9417(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[6],lf[276])));}}}}}}}}}}}}}}}}

/* k11962 in k11947 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_11964(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(27,0,1))){
C_save_and_reclaim_args((void *)trf_11964,2,t0,t1);}
a=C_alloc(27);
t2=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t3=C_a_i_list(&a,4,lf[225],((C_word*)t0)[2],t1,t2);
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[109],((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k15882 in k15879 in user-read-hook in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15884(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_15884,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,2,lf[534],t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[535],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6347 in for-each-loop534 in initialize-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6349(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_6349,2,av);}
a=C_alloc(3);
if(C_truep(C_i_memq(((C_word*)t0)[2],*((C_word*)lf[144]+1)))){
t2=C_a_i_list(&a,1,C_SCHEME_TRUE);
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:54: ##sys#put! */
t3=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
av2[3]=lf[145];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t3=C_i_car(t2);
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
av2[3]=lf[145];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k15879 in user-read-hook in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_15881,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15884,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1581: scan-sharp-greater-string */
t3=*((C_word*)lf[536]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k10479 in walk in node->sexpr in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10481(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_10481,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop2113 in walk in node->sexpr in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10483(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_10483,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10508,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:773: g2119 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5152 in for-each-loop168 in k5123 in k5120 in syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5154,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5144(t3,((C_word*)t0)[4],t2);}

/* k7666 in k7659 in k7656 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7668,2,av);}
t2=C_i_inexact_to_exact(t1);
/* support.scm:532: qnode */
t3=*((C_word*)lf[222]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7659 in k7656 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7661(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_7661,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7668,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:538: truncate */
t3=*((C_word*)lf[227]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k9076 in map-loop1581 in k8981 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9078(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_9078,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9053(t6,((C_word*)t0)[5],t5);}

/* k14789 in k14785 in k14779 in k14760 in walk in scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_14791(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_14791,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* ##compiler#read/source-info in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15865(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_15865,3,av);}
/* support.scm:1571: ##sys#read */
t3=*((C_word*)lf[532]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=*((C_word*)lf[527]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k16149 in k16121 in k16115 in k16109 in load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16151(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_16151,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16156,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_16156(t5,((C_word*)t0)[2],t1);}

/* ##compiler#finish-foreign-result in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_13736(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_13736,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13740,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1232: ##sys#strip-syntax */
t5=*((C_word*)lf[459]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* for-each-loop3969 in k16149 in k16121 in k16115 in k16109 in load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_16156(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(13,0,3))){
C_save_and_reclaim_args((void *)trf_16156,3,t0,t1,t2);}
a=C_alloc(13);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16166,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=C_i_car(t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16135,a[2]=t5,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16139,a[2]=t6,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1654: ##sys#get */
t11=*((C_word*)lf[255]+1);{
C_word av2[4];
av2[0]=t11;
av2[1]=t10;
av2[2]=t8;
av2[3]=lf[550];
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k11986 in k11944 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_11988(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,2))){
C_save_and_reclaim_args((void *)trf_11988,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[352]+1))){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=((C_word*)t0)[4];
t3=C_u_i_assq(t2,lf[368]);
t4=C_slot(t3,C_fix(1));
t5=C_a_i_list(&a,2,lf[97],t4);
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,lf[364],t5,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[369]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_12014(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[407]);
if(C_truep(t4)){
t5=t3;
f_12014(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[408]);
t6=t3;
f_12014(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[5],lf[409])));}}}}

/* g2455 in a11509 in compute-database-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static C_word C_fcall f_11512(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_stack_overflow_check;{}
t2=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_i_car(t1);
t5=C_eqp(t4,lf[189]);
if(C_truep(t5)){
t6=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t6);
return(t7);}
else{
t6=C_eqp(t4,lf[172]);
if(C_truep(t6)){
t7=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t8=C_mutate2(((C_word *)((C_word*)t0)[4])+1,t7);
t9=t1;
t10=C_u_i_cdr(t9);
t11=C_slot(t10,C_fix(1));
t12=C_eqp(lf[133],t11);
if(C_truep(t12)){
t13=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t14=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t13);
return(t14);}
else{
t13=C_SCHEME_UNDEFINED;
return(t13);}}
else{
t7=C_eqp(t4,lf[177]);
if(C_truep(t7)){
t8=t1;
t9=C_u_i_cdr(t8);
t10=C_i_length(t9);
t11=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[6])[1],t10);
t12=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t11);
return(t12);}
else{
t8=C_SCHEME_UNDEFINED;
return(t8);}}}}

/* ##compiler#scan-sharp-greater-string in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15896(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_15896,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15900,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1586: open-output-string */
t4=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* f17604 in print-version in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f17604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f17604,2,av);}
/* support.scm:1662: print */
t2=*((C_word*)lf[295]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a11509 in compute-database-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11510(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_11510,4,av);}
a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=C_i_check_list_2(t3,lf[35]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11591,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_11591(t9,t1,t3);}

/* a8531 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8532(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_8532,4,av);}
a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8621,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=t2;
/* tweaks.scm:57: ##sys#get */
t7=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
av2[3]=lf[256];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* a13729 in estimate-foreign-result-location-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_13730(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_13730,2,av);}
/* support.scm:1226: quit */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[445];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6376 in initialize-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6378(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_6378,2,av);}
a=C_alloc(8);
t2=*((C_word*)lf[139]+1);
t3=C_i_check_list_2(*((C_word*)lf[139]+1),lf[35]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6426,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6476,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_6476(t8,t4,*((C_word*)lf[139]+1));}

/* ##compiler#foreign-type-convert-result in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_12764(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_12764,4,av);}
a=C_alloc(4);
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12777,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1147: ##sys#hash-table-ref */
t5=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[397]+1);
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t4=t2;
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k16164 in for-each-loop3969 in k16149 in k16121 in k16115 in k16109 in load-identifier-database in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16166(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_16166,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_16156(t3,((C_word*)t0)[4],t2);}

/* k13738 in finish-foreign-result in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_13740(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,2))){C_save_and_reclaim((void *)f_13740,2,av);}
a=C_alloc(21);
t2=t1;
t3=C_eqp(t2,lf[380]);
t4=(C_truep(t3)?t3:C_eqp(t2,lf[401]));
if(C_truep(t4)){
t5=C_a_i_list(&a,2,lf[97],C_fix(0));
t6=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_list(&a,3,lf[447],((C_word*)t0)[3],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_eqp(t2,lf[383]);
if(C_truep(t5)){
t6=C_a_i_list(&a,2,lf[97],C_fix(0));
t7=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[448],((C_word*)t0)[3],t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=C_eqp(t2,lf[400]);
t7=(C_truep(t6)?t6:C_eqp(t2,lf[402]));
if(C_truep(t7)){
t8=C_a_i_list(&a,2,lf[97],C_fix(0));
t9=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_a_i_list(&a,3,lf[449],((C_word*)t0)[3],t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t8=C_eqp(t2,lf[398]);
t9=(C_truep(t8)?t8:C_eqp(t2,lf[399]));
if(C_truep(t9)){
t10=C_a_i_list(&a,2,lf[97],C_fix(0));
t11=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=C_a_i_list(&a,3,lf[450],((C_word*)t0)[3],t10);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t10=C_eqp(t2,lf[384]);
if(C_truep(t10)){
t11=C_a_i_list(&a,2,lf[97],C_fix(0));
t12=C_a_i_list(&a,3,lf[447],((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=C_a_i_list(&a,2,lf[451],t12);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t11=C_eqp(t2,lf[403]);
if(C_truep(t11)){
t12=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t13=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=C_a_i_list(&a,3,lf[452],((C_word*)t0)[3],t12);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t12=C_eqp(t2,lf[404]);
if(C_truep(t12)){
t13=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t14=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_a_i_list(&a,3,lf[453],((C_word*)t0)[3],t13);
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
else{
if(C_truep(C_i_listp(t2))){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13856,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t14=C_i_car(t2);
t15=C_eqp(t14,lf[392]);
if(C_truep(t15)){
t16=C_i_length(t2);
t17=C_eqp(C_fix(2),t16);
if(C_truep(t17)){
t18=C_i_cadr(t2);
t19=C_u_i_memq(t18,lf[458]);
t20=t13;
f_13856(t20,t19);}
else{
t18=t13;
f_13856(t18,C_SCHEME_FALSE);}}
else{
t16=t13;
f_13856(t16,C_SCHEME_FALSE);}}
else{
t13=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}}}}}}}}}

/* a12757 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_12758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_12758,2,av);}
/* support.scm:1140: quit */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[433];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* ##sys#user-read-hook in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_15871,4,av);}
a=C_alloc(4);
if(C_truep(C_i_char_equalp(C_make_character(62),t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15881,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t5=*((C_word*)lf[537]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
/* support.scm:1583: old-hook */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* loop in a10855 in load-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_10862,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10866,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:821: read */
t3=*((C_word*)lf[117]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1938 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10206(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_10206,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10231,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:742: g1944 */
t5=((C_word*)t0)[4];
f_10046(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6327 in initialize-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6329(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6329,2,av);}
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8580 in map-loop1401 in k8595 in k8591 in a8531 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8582(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8582,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8557(t6,((C_word*)t0)[5],t5);}

/* ##compiler#initialize-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6325(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_6325,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6329,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=*((C_word*)lf[138]+1);
t4=C_i_check_list_2(*((C_word*)lf[138]+1),lf[35]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6378,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6499,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_6499(t9,t5,*((C_word*)lf[138]+1));}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k14760 in walk in scan-free-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14762(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,5))){
C_save_and_reclaim_args((void *)trf_14762,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[221]);
if(C_truep(t2)){
t3=C_i_car(((C_word*)t0)[4]);
t4=t3;
if(C_truep(C_i_memq(t4,((C_word*)t0)[5]))){
t5=C_SCHEME_UNDEFINED;
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14781,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1356: lset-adjoin */
t6=*((C_word*)lf[482]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=*((C_word*)lf[13]+1);
av2[3]=((C_word*)((C_word*)t0)[6])[1];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}
else{
t3=C_eqp(((C_word*)t0)[3],lf[246]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
if(C_truep(C_i_memq(t4,((C_word*)t0)[5]))){
t5=C_i_car(((C_word*)t0)[8]);
/* support.scm:1362: walk */
t6=((C_word*)((C_word*)t0)[9])[1];
f_14728(t6,((C_word*)t0)[2],t5,((C_word*)t0)[5]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14817,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* support.scm:1361: lset-adjoin */
t6=*((C_word*)lf[482]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=*((C_word*)lf[13]+1);
av2[3]=((C_word*)((C_word*)t0)[6])[1];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[109]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14826,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(((C_word*)t0)[8]);
/* support.scm:1364: walk */
t7=((C_word*)((C_word*)t0)[9])[1];
f_14728(t7,t5,t6,((C_word*)t0)[5]);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[133]);
if(C_truep(t5)){
t6=C_i_caddr(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14856,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1367: decompose-lambda-list */
t8=*((C_word*)lf[124]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=((C_word*)t0)[2];
av2[2]=t6;
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
/* support.scm:1371: walkeach */
t6=((C_word*)((C_word*)t0)[10])[1];
f_14912(t6,((C_word*)t0)[2],((C_word*)t0)[8],((C_word*)t0)[5]);}}}}}}

/* k12806 in foreign-type-convert-argument in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_12808(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_12808,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
if(C_truep(C_i_vectorp(t1))){
t2=C_i_vector_ref(t1,C_fix(1));
t3=C_a_i_list2(&a,2,t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5412 in stringify in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5414(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_5414,2,av);}
a=C_alloc(4);
t2=t1;
t3=C_i_check_port_2(t2,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[52]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5420,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:165: ##sys#print */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
av2[3]=C_SCHEME_FALSE;
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k8512 in map-loop1355 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8514(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8514,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8489(t6,((C_word*)t0)[5],t5);}

/* a8525 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_8526,2,av);}
/* support.scm:604: get-line-2 */
t2=*((C_word*)lf[159]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k11904 in k11889 in k11821 in k11806 in repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_11906(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(27,0,1))){
C_save_and_reclaim_args((void *)trf_11906,2,t0,t1);}
a=C_alloc(27);
t2=C_a_i_list(&a,2,lf[97],C_SCHEME_FALSE);
t3=C_a_i_list(&a,4,lf[225],((C_word*)t0)[2],t1,t2);
t4=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[109],((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* ##compiler#compute-database-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11501(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,4))){C_save_and_reclaim((void *)f_11501,3,av);}
a=C_alloc(25);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11505,a[2]=t1,a[3]=t6,a[4]=t4,a[5]=t8,a[6]=t12,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11510,a[2]=t10,a[3]=t8,a[4]=t6,a[5]=t4,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
/* support.scm:961: ##sys#hash-table-for-each */
t15=*((C_word*)lf[162]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t15;
av2[1]=t13;
av2[2]=t14;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}

/* k11503 in compute-database-statistics in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,8))){C_save_and_reclaim((void *)f_11505,2,av);}
/* support.scm:975: values */{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[332]+1);
av2[3]=*((C_word*)lf[333]+1);
av2[4]=((C_word*)((C_word*)t0)[3])[1];
av2[5]=((C_word*)((C_word*)t0)[4])[1];
av2[6]=((C_word*)((C_word*)t0)[5])[1];
av2[7]=((C_word*)((C_word*)t0)[6])[1];
av2[8]=((C_word*)((C_word*)t0)[7])[1];
C_values(9,av2);}}

/* k14030 in k14006 in foreign-type->scrutiny-type in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14032(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_14032,2,t0,t1);}
a=C_alloc(7);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=lf[230];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[356]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[3],lf[424]));
if(C_truep(t3)){
t4=((C_word*)t0)[4];
t5=C_eqp(t4,lf[461]);
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(t5)?lf[425]:lf[356]);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[359]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[3],lf[361]));
if(C_truep(t5)){
t6=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t6;
av2[1]=lf[240];
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(((C_word*)t0)[3],lf[358]);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
t8=C_eqp(t7,lf[461]);
t9=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t9;
av2[1]=(C_truep(t8)?lf[462]:lf[358]);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t7=C_eqp(((C_word*)t0)[3],lf[362]);
if(C_truep(t7)){
t8=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t8;
av2[1]=lf[358];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_eqp(((C_word*)t0)[3],lf[363]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
t10=C_eqp(t9,lf[461]);
t11=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t11;
av2[1]=(C_truep(t10)?lf[463]:lf[363]);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
t9=C_eqp(((C_word*)t0)[3],lf[365]);
if(C_truep(t9)){
t10=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t10;
av2[1]=lf[363];
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=C_eqp(((C_word*)t0)[3],lf[366]);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14107,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t10)){
t12=t11;
f_14107(t12,t10);}
else{
t12=C_eqp(((C_word*)t0)[3],lf[417]);
if(C_truep(t12)){
t13=t11;
f_14107(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[3],lf[418]);
if(C_truep(t13)){
t14=t11;
f_14107(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[3],lf[419]);
if(C_truep(t14)){
t15=t11;
f_14107(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[3],lf[420]);
if(C_truep(t15)){
t16=t11;
f_14107(t16,t15);}
else{
t16=C_eqp(((C_word*)t0)[3],lf[421]);
if(C_truep(t16)){
t17=t11;
f_14107(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[3],lf[422]);
t18=t11;
f_14107(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[3],lf[423])));}}}}}}}}}}}}}}

/* walk in node->sexpr in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10437(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_10437,3,av);}
a=C_alloc(18);
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t7;
t9=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t11)[1];
t13=((C_word*)((C_word*)t0)[2])[1];
t14=t2;
t15=C_slot(t14,C_fix(3));
t16=C_i_check_list_2(t15,lf[161]);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10481,a[2]=t8,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10483,a[2]=t11,a[3]=t19,a[4]=t13,a[5]=t12,tmp=(C_word)a,a+=6,tmp));
t21=((C_word*)t19)[1];
f_10483(t21,t17,t15);}

/* ##compiler#node->sexpr in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10431(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_10431,3,av);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10437,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
f_10437(3,av2);}}

/* map-loop1630 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_9252(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_9252,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9277,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:662: g1636 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10734 in k10846 in k10710 in a10704 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10736(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_10736,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
if(C_truep(C_i_assq(lf[199],((C_word*)t0)[2]))){
t2=C_i_cdr(((C_word*)t0)[3]);
t3=C_slot(t2,C_fix(2));
t4=t3;
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10815,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* support.scm:792: get */
t6=*((C_word*)lf[148]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)t0)[5];
av2[4]=lf[206];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t5=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k6395 in for-each-loop583 in k6376 in initialize-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6397(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_6397,2,av);}
a=C_alloc(3);
if(C_truep(C_i_memq(((C_word*)t0)[2],*((C_word*)lf[144]+1)))){
t2=C_a_i_list(&a,1,C_SCHEME_TRUE);
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:54: ##sys#put! */
t3=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
av2[3]=lf[145];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t3=C_i_car(t2);
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[2];
av2[3]=lf[145];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a9712 in a9706 in inline-lambda-bindings in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9713(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_9713,2,av);}
/* support.scm:689: split-at */
t2=*((C_word*)lf[282]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k8824 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8826(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_8826,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* map-loop1489 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_8828(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8828,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8853,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:629: g1495 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a9718 in a9706 in inline-lambda-bindings in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9719(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,3))){C_save_and_reclaim((void *)f_9719,4,av);}
a=C_alloc(25);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9723,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=*((C_word*)lf[110]+1);
t10=((C_word*)t0)[6];
t11=C_i_check_list_2(t10,lf[161]);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9820,a[2]=t7,a[3]=t13,a[4]=t9,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_9820(t15,t4,t10);}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[6];
f_9723(2,av2);}}}

/* map-loop2005 in k10133 in k10125 in k10060 in k10057 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10091(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_10091,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10116,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:753: g2011 */
t5=((C_word*)t0)[4];
f_10079(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9275 in map-loop1630 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9277(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_9277,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9252(t6,((C_word*)t0)[5],t5);}

/* g2011 in k10133 in k10125 in k10060 in k10057 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10079(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_10079,3,t0,t1,t2);}
/* support.scm:753: g2028 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9875(t3,t1,t2,((C_word*)t0)[3]);}

/* ##compiler#foreign-type-convert-argument in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_12795(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_12795,4,av);}
a=C_alloc(4);
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12808,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1154: ##sys#hash-table-ref */
t5=*((C_word*)lf[149]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[397]+1);
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t4=t2;
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k10087 in k10133 in k10125 in k10060 in k10057 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10089(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_10089,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[133],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k9571 in map-loop1754 in k9415 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_9573,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9548(t6,((C_word*)t0)[5],t5);}

/* k8595 in k8591 in a8531 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8597(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,3))){C_save_and_reclaim((void *)f_8597,2,av);}
a=C_alloc(23);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=((C_word*)((C_word*)t0)[3])[1];
t9=((C_word*)t0)[4];
t10=C_i_check_list_2(t9,lf[161]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8555,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8557,a[2]=t6,a[3]=t13,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_8557(t15,t11,t9);}

/* k8591 in a8531 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_8593(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,2))){
C_save_and_reclaim_args((void *)trf_8593,2,t0,t1);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8597,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8600,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* support.scm:612: real-name */
t5=*((C_word*)lf[47]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
/* support.scm:615: ##sys#symbol->qualified-string */
t4=*((C_word*)lf[254]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k12775 in foreign-type-convert-result in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_12777(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_12777,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
if(C_truep(C_i_vectorp(t1))){
t2=C_i_vector_ref(t1,C_fix(2));
t3=C_a_i_list2(&a,2,t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8779(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_8779,3,av);}
a=C_alloc(8);
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t4;
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t7;
t9=t2;
t10=C_slot(t9,C_fix(1));
t11=t10;
t12=t11;
t13=C_eqp(t12,lf[225]);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8813,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,a[5]=t11,a[6]=t12,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t13)){
t15=t14;
f_8813(t15,t13);}
else{
t15=C_eqp(t12,lf[277]);
t16=t14;
f_8813(t16,(C_truep(t15)?t15:C_eqp(t12,lf[278])));}}

/* ##compiler#build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8773(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_8773,3,av);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8779,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
f_8779(3,av2);}}

/* k8719 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8721(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_8721,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[253],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1432 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_8723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8723,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8748,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:617: g1438 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k14606 in walk in scan-used-variables in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14608(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_14608,2,t0,t1);}
a=C_alloc(6);
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_i_check_list_2(((C_word*)t0)[3],lf[35]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14616,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_14616(t7,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k7630 in map-loop1062 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7632(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_7632,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7607(t6,((C_word*)t0)[5],t5);}

/* ##compiler#big-fixnum? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_15965,3,av);}
if(C_truep(C_fixnump(t2))){
if(C_truep(C_fudge(C_fix(3)))){
t3=C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=(C_truep(t3)?t3:C_fixnum_lessp(t2,C_fix(-1073741824)));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k15958 in k15907 in loop in k15898 in scan-sharp-greater-string in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15960(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_15960,2,av);}
/* support.scm:1603: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_15905(t2,((C_word*)t0)[3]);}

/* k10016 in k9996 in k9990 in k9987 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10018(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,1))){C_save_and_reclaim((void *)f_10018,2,av);}
a=C_alloc(11);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[109],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k15950 in k15947 in k15935 in k15907 in loop in k15898 in scan-sharp-greater-string in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15952(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_15952,2,av);}
/* support.scm:1600: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_15905(t2,((C_word*)t0)[3]);}

/* k15404 in k15384 in k15381 in k15514 in k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_15406,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1502: debugging */
t3=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[261];
av2[3]=lf[516];
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=C_u_i_length(((C_word*)t0)[2]);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
/* support.scm:1505: k */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=C_SCHEME_FALSE;
av2[3]=((C_word*)t0)[5];
av2[4]=C_SCHEME_FALSE;
av2[5]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}
else{
/* support.scm:1507: bomb */
t4=*((C_word*)lf[3]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[517];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}}

/* k15407 in k15404 in k15384 in k15381 in k15514 in k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15409(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_15409,2,av);}
t2=C_i_car(((C_word*)t0)[2]);
/* support.scm:1503: k */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=C_SCHEME_TRUE;
av2[3]=((C_word*)t0)[5];
av2[4]=t2;
av2[5]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k8002 in k8014 in loop in k8051 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8004(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8004,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:572: reverse */
t3=*((C_word*)lf[91]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7656 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_7658(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_7658,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:536: warning */
t3=*((C_word*)lf[228]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[229];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
/* support.scm:532: qnode */
t2=*((C_word*)lf[222]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k5531 in c-ify-string in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5533,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=*((C_word*)lf[67]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* loop in k5535 in c-ify-string in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5539(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_5539,3,t0,t1,t2);}
a=C_alloc(7);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[68];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=t3;
t5=C_fix(C_character_code(t4));
t6=t5;
t7=C_fixnum_lessp(t6,C_fix(32));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5561,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t6,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_5561(t9,t7);}
else{
t9=C_fixnum_greater_or_equal_p(t6,C_fix(127));
if(C_truep(t9)){
t10=t8;
f_5561(t10,t9);}
else{
t10=C_u_i_memq(t4,lf[75]);
t11=t8;
f_5561(t11,t10);}}}}

/* k5535 in c-ify-string in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5537(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5537,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5539,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5539(t5,((C_word*)t0)[2],t1);}

/* k8763 in k8760 in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_8765,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k15947 in k15935 in k15907 in loop in k15898 in scan-sharp-greater-string in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_15949,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[526]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k8006 in k8014 in loop in k8051 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8008(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_8008,2,av);}
/* support.scm:572: walk */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
f_7538(3,av2);}}

/* k8760 in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8762(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_8762,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8765,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_positivep(((C_word*)((C_word*)t0)[3])[1]))){
/* support.scm:620: debugging */
t4=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[261];
av2[3]=lf[262];
av2[4]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* ##compiler#c-ify-string in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5521(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5521,3,av);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5533,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5537,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=*((C_word*)lf[71]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k15935 in k15907 in loop in k15898 in scan-sharp-greater-string in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15937(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_15937,2,av);}
a=C_alloc(6);
t2=t1;
t3=C_eqp(C_make_character(35),t2);
if(C_truep(t3)){
/* support.scm:1596: get-output-string */
t4=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15949,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t5=*((C_word*)lf[526]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_make_character(60);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k15466 in a15459 in a15453 in a15447 in k15514 in k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15468(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_15468,2,av);}
/* support.scm:1495: k */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_FALSE;
av2[3]=((C_word*)t0)[4];
av2[4]=C_SCHEME_FALSE;
av2[5]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* a15459 in a15453 in a15447 in k15514 in k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15460(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_15460,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15468,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1496: get-condition-property */
t3=*((C_word*)lf[519]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[520];
av2[4]=lf[521];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* a15453 in a15447 in k15514 in k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15454(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_15454,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1494: k3696 */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k10051 in k10048 in g1944 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10053(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_10053,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7793 in map-loop1126 in k7732 in k7729 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7795(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_7795,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7770(t6,((C_word*)t0)[5],t5);}

/* k10057 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10059(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,4))){C_save_and_reclaim((void *)f_10059,2,av);}
a=C_alloc(25);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=((C_word*)t0)[8];
t9=C_i_check_list_2(t2,lf[161]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10156,a[2]=t3,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10158,a[2]=t6,a[3]=t12,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_10158(t14,t10,t8,t2);}

/* k10048 in g1944 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10050(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,5))){C_save_and_reclaim((void *)f_10050,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10053,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:744: put! */
t4=*((C_word*)lf[152]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=lf[288];
av2[5]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}

/* a15447 in k15514 in k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15448(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_15448,3,av);}
a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15470,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1494: with-exception-handler */
t5=*((C_word*)lf[122]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k8014 in loop in k8051 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8016(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_8016,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7996,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8004,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8008,a[2]=((C_word*)t0)[5],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm:572: cadar */
t7=*((C_word*)lf[239]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* map-loop1560 in k8984 in k8981 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_9005(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_9005,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list2(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k9001 in k8993 in k8984 in k8981 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9003,2,av);}
/* support.scm:640: walk */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
f_8779(3,av2);}}

/* k10060 in k10057 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10062(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_10062,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* support.scm:750: gensym */
t4=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[289];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7766 in k7758 in k7732 in k7729 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7768(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_7768,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* support.scm:551: append */
t3=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k7758 in k7732 in k7729 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7760(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_7760,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7768,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:552: walk */
t4=((C_word*)((C_word*)t0)[3])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
f_7538(3,av2);}}

/* k8039 in loop in k8051 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8041(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_8041,2,av);}
/* support.scm:575: walk */
t2=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
f_7538(3,av2);}}

/* ##compiler#hide-variable in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15989(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_15989,3,av);}
a=C_alloc(3);
t3=C_a_i_list(&a,1,lf[539]);
if(C_truep(C_i_nullp(t3))){
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[540];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=C_i_car(t3);
/* tweaks.scm:54: ##sys#put! */
t5=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[540];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* k7732 in k7729 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7734(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,3))){C_save_and_reclaim((void *)f_7734,2,av);}
a=C_alloc(25);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7738,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7743,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t9=C_i_cadr(((C_word*)t0)[4]);
t10=C_i_check_list_2(t9,lf[161]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7760,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7770,a[2]=t6,a[3]=t13,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_7770(t15,t11,t9);}

/* k7736 in k7732 in k7729 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7738(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_7738,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[109],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k7729 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7731(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_7731,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7804,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7804(t6,t2,t1);}

/* k5566 in k5559 in loop in k5535 in c-ify-string in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5568(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_5568,2,t0,t1);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5572,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5582,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:197: number->string */
t5=*((C_word*)lf[72]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=C_fix(8);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k5559 in loop in k5535 in c-ify-string in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_5561,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[5],C_fix(8)))){
t3=t2;
f_5568(t3,lf[73]);}
else{
t3=C_fixnum_lessp(((C_word*)t0)[5],C_fix(64));
t4=t2;
f_5568(t4,(C_truep(t3)?lf[74]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* support.scm:199: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5539(t5,t2,t4);}}

/* k8035 in loop in k8051 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_8037,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:573: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7930(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* g1944 in a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10046(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_10046,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10050,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:743: gensym */
t4=*((C_word*)lf[110]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a10040 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10041(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,3))){C_save_and_reclaim((void *)f_10041,5,av);}
a=C_alloc(26);
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=t2;
t11=C_i_check_list_2(t10,lf[161]);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,a[7]=t4,a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10206,a[2]=t7,a[3]=t14,a[4]=t9,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_10206(t16,t12,t10);}

/* k16035 in variable-hidden? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_16037,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_eqp(t1,lf[539]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* ##compiler#variable-visible? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16039(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_16039,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16043,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1627: ##sys#get */
t4=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=lf[540];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5091 in k5067 in with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5093(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5093,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5100,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:102: with-output-to-string */
t3=*((C_word*)lf[23]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* map-loop1126 in k7732 in k7729 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_7770(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_7770,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7795,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:551: g1132 */
t5=((C_word*)t0)[4];
f_7743(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* ##compiler#emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10588(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,4))){C_save_and_reclaim((void *)f_10588,4,av);}
a=C_alloc(15);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10592,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10705,a[2]=t5,a[3]=t7,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:782: ##sys#hash-table-for-each */
t10=*((C_word*)lf[162]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=t8;
av2[2]=t9;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}

/* ##compiler#variable-hidden? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16029(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_16029,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16037,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1624: ##sys#get */
t4=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=lf[540];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k9332 in map-loop1656 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9334(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_9334,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9309(t6,((C_word*)t0)[5],t5);}

/* k5082 in k5076 in k5073 in k5070 in k5067 in with-debugging-output in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5084(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5084,2,av);}
if(C_truep(t1)){
/* support.scm:100: collect */
t2=((C_word*)t0)[2];
f_5008(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k15924 in k15907 in loop in k15898 in scan-sharp-greater-string in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_15926,2,av);}
/* support.scm:1592: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_15905(t2,((C_word*)t0)[3]);}

/* ##compiler#variable-mark in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_16079,4,av);}
/* support.scm:1637: ##sys#get */
t4=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k10593 in k10590 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10595(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_10595,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
/* support.scm:814: debugging */
t3=*((C_word*)lf[14]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[297];
av2[3]=lf[298];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_10601(2,av2);}}}

/* k10590 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10592(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_10592,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[4])[1]))){
/* support.scm:802: delete-file* */
t3=*((C_word*)lf[299]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10655,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm:803: with-output-to-file */
t4=*((C_word*)lf[307]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k5507 in loop in build-lambda-list in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5509(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_5509,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_7039(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
if(!C_demand(C_calculate_demand(17,0,2))){
C_save_and_reclaim_args((void *)trf_7039,3,t0,t1,t2);}
a=C_alloc(17);
if(C_truep(C_i_pairp(t2))){
t3=C_i_caar(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7052,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_eqp(t4,lf[170]);
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7063,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t6)){
t8=t7;
f_7063(t8,t6);}
else{
t8=C_eqp(t4,lf[187]);
if(C_truep(t8)){
t9=t7;
f_7063(t9,t8);}
else{
t9=C_eqp(t4,lf[188]);
if(C_truep(t9)){
t10=t7;
f_7063(t10,t9);}
else{
t10=C_eqp(t4,lf[189]);
if(C_truep(t10)){
t11=t7;
f_7063(t11,t10);}
else{
t11=C_eqp(t4,lf[190]);
if(C_truep(t11)){
t12=t7;
f_7063(t12,t11);}
else{
t12=C_eqp(t4,lf[191]);
if(C_truep(t12)){
t13=t7;
f_7063(t13,t12);}
else{
t13=C_eqp(t4,lf[192]);
if(C_truep(t13)){
t14=t7;
f_7063(t14,t13);}
else{
t14=C_eqp(t4,lf[193]);
if(C_truep(t14)){
t15=t7;
f_7063(t15,t14);}
else{
t15=C_eqp(t4,lf[194]);
if(C_truep(t15)){
t16=t7;
f_7063(t16,t15);}
else{
t16=C_eqp(t4,lf[195]);
if(C_truep(t16)){
t17=t7;
f_7063(t17,t16);}
else{
t17=C_eqp(t4,lf[196]);
if(C_truep(t17)){
t18=t7;
f_7063(t18,t17);}
else{
t18=C_eqp(t4,lf[197]);
if(C_truep(t18)){
t19=t7;
f_7063(t19,t18);}
else{
t19=C_eqp(t4,lf[198]);
if(C_truep(t19)){
t20=t7;
f_7063(t20,t19);}
else{
t20=C_eqp(t4,lf[199]);
if(C_truep(t20)){
t21=t7;
f_7063(t21,t20);}
else{
t21=C_eqp(t4,lf[200]);
if(C_truep(t21)){
t22=t7;
f_7063(t22,t21);}
else{
t22=C_eqp(t4,lf[201]);
if(C_truep(t22)){
t23=t7;
f_7063(t23,t22);}
else{
t23=C_eqp(t4,lf[202]);
if(C_truep(t23)){
t24=t7;
f_7063(t24,t23);}
else{
t24=C_eqp(t4,lf[203]);
if(C_truep(t24)){
t25=t7;
f_7063(t25,t24);}
else{
t25=C_eqp(t4,lf[204]);
if(C_truep(t25)){
t26=t7;
f_7063(t26,t25);}
else{
t26=C_eqp(t4,lf[205]);
t27=t7;
f_7063(t27,(C_truep(t26)?t26:C_eqp(t4,lf[206])));}}}}}}}}}}}}}}}}}}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* ##compiler#export-variable in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16009(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_16009,3,av);}
a=C_alloc(3);
t3=C_a_i_list(&a,1,lf[542]);
if(C_truep(C_i_nullp(t3))){
/* tweaks.scm:54: ##sys#put! */
t4=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[540];
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=C_i_car(t3);
/* tweaks.scm:54: ##sys#put! */
t5=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[540];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* loop in k15898 in scan-sharp-greater-string in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_15905(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_15905,2,t0,t1);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15909,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=*((C_word*)lf[537]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k15907 in loop in k15898 in scan-sharp-greater-string in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15909(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_15909,2,av);}
a=C_alloc(5);
if(C_truep(C_eofp(t1))){
/* support.scm:1589: quit */
t2=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[538];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
if(C_truep(C_u_i_char_equalp(t1,C_make_character(10)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1591: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
if(C_truep(C_u_i_char_equalp(t1,C_make_character(60)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=*((C_word*)lf[537]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15960,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[526]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}}}

/* k10577 in map-loop2152 in walk in sexpr->node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10579(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_10579,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10554(t6,((C_word*)t0)[5],t5);}

/* k15898 in scan-sharp-greater-string in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15900(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_15900,2,av);}
a=C_alloc(7);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15905,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_15905(t6,((C_word*)t0)[3]);}

/* k7050 in loop in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7052(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7052,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* support.scm:488: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7039(t4,((C_word*)t0)[4],t3);}

/* k9934 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9936(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9936,2,av);}
if(C_truep(t1)){
/* support.scm:723: cfk */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_9926(2,av2);}}}

/* ##compiler#mark-variable in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16064(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +0,c,4))){
C_save_and_reclaim((void*)f_16064,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+0);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* support.scm:1634: ##sys#put! */
t5=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t5=C_i_car(t4);
/* support.scm:1634: ##sys#put! */
t6=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}

/* k9931 in k9924 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9933(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9933,2,av);}
/* support.scm:724: varnode */
t2=*((C_word*)lf[220]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop2152 in walk in sexpr->node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10554(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_10554,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10579,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:777: g2158 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10550 in walk in sexpr->node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10552(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_10552,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k9305 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9307(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9307,2,av);}
/* support.scm:663: cons* */
t2=*((C_word*)lf[270]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[243];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop1656 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_9309(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_9309,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9334,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:663: g1662 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* walk in sexpr->node in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10523(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_10523,3,av);}
a=C_alloc(18);
t3=C_i_car(t2);
t4=t3;
t5=C_i_cadr(t2);
t6=t5;
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=((C_word*)((C_word*)t0)[2])[1];
t12=t2;
t13=C_u_i_cdr(t12);
t14=C_u_i_cdr(t13);
t15=C_i_check_list_2(t14,lf[161]);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10552,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10554,a[2]=t9,a[3]=t18,a[4]=t11,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_10554(t20,t16,t14);}

/* k16041 in variable-visible? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16043(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_16043,2,av);}
t2=C_eqp(t1,lf[539]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(t1,lf[542]);
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=(C_truep(t3)?C_SCHEME_TRUE:C_i_not(*((C_word*)lf[544]+1)));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k11703 in k11697 in k11694 in k11691 in k11685 in k11682 in k11679 in k11673 in k11670 in k11667 in k11661 in k11658 in k11655 in k11649 in k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in k7495 in ... */
static void C_ccall f_11705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11705,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:992: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k11706 in k11703 in k11697 in k11694 in k11691 in k11685 in k11682 in k11679 in k11673 in k11670 in k11667 in k11661 in k11658 in k11655 in k11649 in k11646 in k11643 in k11640 in k11637 in k11631 in a11625 in print-program-statistics in ... */
static void C_ccall f_11708(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_11708,2,av);}
/* support.scm:992: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k9963 in k9971 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,1))){C_save_and_reclaim((void *)f_9965,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,t1);
t3=((C_word*)t0)[2];
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[246],((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k9971 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9973(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_9973,2,av);}
a=C_alloc(7);
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9965,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(((C_word*)t0)[3]);
/* support.scm:728: walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9875(t6,t4,t5,((C_word*)t0)[5]);}

/* k9987 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9989(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_9989,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm:732: gensym */
t4=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k9804 in k9724 in k9721 in a9718 in a9706 in inline-lambda-bindings in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9806(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(34,c,2))){C_save_and_reclaim((void *)f_9806,2,av);}
a=C_alloc(34);
t2=C_a_i_list1(&a,1,t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
/* support.scm:700: qnode */
t5=*((C_word*)lf[222]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=C_i_length(((C_word*)t0)[4]);
t6=C_a_i_times(&a,2,C_fix(3),t5);
t7=C_a_i_list2(&a,2,lf[285],t6);
t8=((C_word*)t0)[4];
t9=C_a_i_record4(&a,4,lf[211],lf[251],t7,t8);
t10=C_a_i_list2(&a,2,t9,((C_word*)t0)[2]);
t11=((C_word*)t0)[3];
f_9752(t11,C_a_i_record4(&a,4,lf[211],lf[109],t3,t10));}}

/* k9990 in k9987 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,5))){C_save_and_reclaim((void *)f_9992,2,av);}
a=C_alloc(14);
t2=t1;
t3=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t2),((C_word*)t0)[3]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9998,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* support.scm:734: put! */
t6=*((C_word*)lf[152]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[8];
av2[3]=t2;
av2[4]=lf[288];
av2[5]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(6,av2);}}

/* k9996 in k9990 in k9987 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9998(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_9998,2,av);}
a=C_alloc(8);
t2=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_i_cadr(((C_word*)t0)[5]);
/* support.scm:737: walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_9875(t6,t4,t5,((C_word*)t0)[7]);}

/* map-loop1805 in a9718 in a9706 in inline-lambda-bindings in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_9820(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_9820,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9845,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:690: g1811 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* ##compiler#source-info->string in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15255(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_15255,3,av);}
a=C_alloc(12);
if(C_truep(C_i_listp(t2))){
t3=C_i_car(t2);
t4=t3;
t5=C_i_cadr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15275,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15279,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=C_i_string_length(t4);
t10=C_a_i_minus(&a,2,C_fix(4),t9);
/* support.scm:1469: max */
t11=*((C_word*)lf[510]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t11;
av2[1]=t8;
av2[2]=C_fix(0);
av2[3]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}
else{
t3=t2;
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k8746 in map-loop1432 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8748(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8748,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8723(t6,((C_word*)t0)[5],t5);}

/* k15248 in k15245 in k15242 in a15236 in display-real-name-table in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15250(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_15250,2,av);}
/* support.scm:1461: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k8051 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8053(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_8053,2,av);}
a=C_alloc(10);
t2=C_a_i_list1(&a,1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7930(t6,((C_word*)t0)[4],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,t2);}

/* k11732 in for-each-loop2552 in a11727 in k11715 in pprint-expressions-to-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11734(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_11734,2,av);}
/* support.scm:1004: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* repeat in a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_11783(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_11783,3,t0,t1,t2);}
a=C_alloc(8);
t3=t2;
t4=C_eqp(t3,lf[350]);
t5=(C_truep(t4)?t4:C_eqp(t3,lf[351]));
if(C_truep(t5)){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=(C_truep(*((C_word*)lf[352]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[353],((C_word*)t0)[2]));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(t3,lf[354]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11808,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_11808(t8,t6);}
else{
t8=C_eqp(t3,lf[426]);
if(C_truep(t8)){
t9=t7;
f_11808(t9,t8);}
else{
t9=C_eqp(t3,lf[427]);
if(C_truep(t9)){
t10=t7;
f_11808(t10,t9);}
else{
t10=C_eqp(t3,lf[428]);
if(C_truep(t10)){
t11=t7;
f_11808(t11,t10);}
else{
t11=C_eqp(t3,lf[429]);
if(C_truep(t11)){
t12=t7;
f_11808(t12,t11);}
else{
t12=C_eqp(t3,lf[430]);
if(C_truep(t12)){
t13=t7;
f_11808(t13,t12);}
else{
t13=C_eqp(t3,lf[431]);
t14=t7;
f_11808(t14,(C_truep(t13)?t13:C_eqp(t3,lf[432])));}}}}}}}}

/* k8078 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_8080(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(18,0,3))){
C_save_and_reclaim_args((void *)trf_8080,2,t0,t1);}
a=C_alloc(18);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)((C_word*)t0)[2])[1];
t8=((C_word*)t0)[3];
t9=C_u_i_cdr(t8);
t10=C_u_i_cdr(t9);
t11=C_i_check_list_2(t10,lf[161]);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8092,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8094,a[2]=t5,a[3]=t14,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_8094(t16,t12,t10);}

/* k11753 in for-each-loop2552 in a11727 in k11715 in pprint-expressions-to-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11755,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11745(t3,((C_word*)t0)[4],t2);}

/* walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_9875(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(10,0,5))){
C_save_and_reclaim_args((void *)trf_9875,4,t0,t1,t2,t3);}
a=C_alloc(10);
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t5;
t7=t2;
t8=C_slot(t7,C_fix(2));
t9=t8;
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=t11;
t13=C_eqp(t12,lf[97]);
if(C_truep(t13)){
t14=t1;
t15=t14;{
C_word av2[2];
av2[0]=t15;
av2[1]=C_a_i_record4(&a,4,lf[211],t12,t9,C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t14=C_eqp(t12,lf[221]);
if(C_truep(t14)){
t15=C_i_car(t9);
t16=t15;
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9926,a[2]=t1,a[3]=t3,a[4]=t16,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9936,a[2]=((C_word*)t0)[2],a[3]=t17,a[4]=t16,tmp=(C_word)a,a+=5,tmp);
/* support.scm:722: get */
t19=*((C_word*)lf[148]+1);{
C_word av2[5];
av2[0]=t19;
av2[1]=t18;
av2[2]=((C_word*)t0)[3];
av2[3]=t16;
av2[4]=lf[190];
((C_proc)(void*)(*((C_word*)t19+1)))(5,av2);}}
else{
t15=C_eqp(t12,lf[246]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9973,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t17=C_i_car(t9);
t18=t3;
/* support.scm:712: alist-ref */
t19=*((C_word*)lf[287]+1);{
C_word av2[6];
av2[0]=t19;
av2[1]=t16;
av2[2]=t17;
av2[3]=t18;
av2[4]=*((C_word*)lf[13]+1);
av2[5]=t17;
((C_proc)(void*)(*((C_word*)t19+1)))(6,av2);}}
else{
t16=C_eqp(t12,lf[109]);
if(C_truep(t16)){
t17=C_i_car(t9);
t18=t17;
t19=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9989,a[2]=t18,a[3]=t3,a[4]=t1,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t20=C_i_car(t6);
/* support.scm:731: walk */
t22=t19;
t23=t20;
t24=t3;
t1=t22;
t2=t23;
t3=t24;
goto loop;}
else{
t17=C_eqp(t12,lf[133]);
if(C_truep(t17)){
t18=C_i_caddr(t9);
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10041,a[2]=((C_word*)t0)[3],a[3]=t9,a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:739: decompose-lambda-list */
t20=*((C_word*)lf[124]+1);{
C_word av2[4];
av2[0]=t20;
av2[1]=t1;
av2[2]=t18;
av2[3]=t19;
((C_proc)(void*)(*((C_word*)t20+1)))(4,av2);}}
else{
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10250,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t6,a[5]=t1,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
/* support.scm:754: tree-copy */
t19=*((C_word*)lf[290]+1);{
C_word av2[3];
av2[0]=t19;
av2[1]=t18;
av2[2]=t9;
((C_proc)(void*)(*((C_word*)t19+1)))(3,av2);}}}}}}}

/* a11727 in k11715 in pprint-expressions-to-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11728(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_11728,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=C_i_check_list_2(t2,lf[35]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11745,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_11745(t7,t1,t2);}

/* k11718 in k11715 in pprint-expressions-to-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11720(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11720,2,av);}
if(C_truep(((C_word*)t0)[2])){
/* support.scm:1006: close-output-port */
t2=*((C_word*)lf[345]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* map-loop1197 in k8078 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_8094(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8094,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8119,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:581: g1203 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8090 in k8078 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8092(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_8092,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* for-each-loop2552 in a11727 in k11715 in pprint-expressions-to-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_11745(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_11745,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11755,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11734,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1003: pretty-print */
t7=*((C_word*)lf[346]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k11715 in pprint-expressions-to-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11717(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_11717,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11728,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm:999: with-output-to-port */
t5=*((C_word*)lf[347]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t2;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* ##compiler#pprint-expressions-to-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11713(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_11713,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11717,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm:998: open-output-file */
t5=*((C_word*)lf[348]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=*((C_word*)lf[16]+1);
f_11717(2,av2);}}}

/* map-loop745 in k6788 in k6785 in a6776 in display-line-number-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_6808(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_6808,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6804 in k6788 in k6785 in a6776 in display-line-number-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6806(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6806,2,av);}
/* support.scm:431: ##sys#print */
t2=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k9843 in map-loop1805 in a9718 in a9706 in inline-lambda-bindings in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_9845,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9820(t6,((C_word*)t0)[5],t5);}

/* ##compiler#copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5=av[5];
C_word t6=av[6];
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,4))){C_save_and_reclaim((void *)f_9854,7,av);}
a=C_alloc(18);
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=C_i_check_list_2(t3,lf[161]);
t12=C_i_check_list_2(t4,lf[161]);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9867,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10314,a[2]=t9,a[3]=t15,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_10314(t17,t13,t3,t4);}

/* k7061 in loop in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_7063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_7063,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:471: ##sys#write-char-0 */
t6=*((C_word*)lf[18]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t5;
av2[2]=C_make_character(9);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[169]);
if(C_truep(t2)){
t3=C_mutate2(((C_word *)((C_word*)t0)[5])+1,lf[169]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
/* support.scm:488: loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_7039(t6,((C_word*)t0)[7],t5);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[172]);
if(C_truep(t3)){
t4=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[169]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* support.scm:488: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7039(t7,((C_word*)t0)[7],t6);}
else{
t5=C_i_cdar(((C_word*)t0)[2]);
t6=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t5);
t7=((C_word*)t0)[2];
t8=C_u_i_cdr(t7);
/* support.scm:488: loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_7039(t9,((C_word*)t0)[7],t8);}}
else{
t4=C_eqp(((C_word*)t0)[4],lf[173]);
if(C_truep(t4)){
t5=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[169]);
if(C_truep(t5)){
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
/* support.scm:488: loop */
t8=((C_word*)((C_word*)t0)[6])[1];
f_7039(t8,((C_word*)t0)[7],t7);}
else{
t6=C_i_cdar(((C_word*)t0)[2]);
t7=C_mutate2(((C_word *)((C_word*)t0)[8])+1,t6);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
/* support.scm:488: loop */
t10=((C_word*)((C_word*)t0)[6])[1];
f_7039(t10,((C_word*)t0)[7],t9);}}
else{
t5=C_eqp(((C_word*)t0)[4],lf[174]);
if(C_truep(t5)){
t6=C_i_cdar(((C_word*)t0)[2]);
t7=C_mutate2(((C_word *)((C_word*)t0)[9])+1,t6);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
/* support.scm:488: loop */
t10=((C_word*)((C_word*)t0)[6])[1];
f_7039(t10,((C_word*)t0)[7],t9);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[175]);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t6)){
t8=t7;
f_7142(t8,t6);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[179]);
if(C_truep(t8)){
t9=t7;
f_7142(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[180]);
if(C_truep(t9)){
t10=t7;
f_7142(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[181]);
if(C_truep(t10)){
t11=t7;
f_7142(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[182]);
if(C_truep(t11)){
t12=t7;
f_7142(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[183]);
if(C_truep(t12)){
t13=t7;
f_7142(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[184]);
if(C_truep(t13)){
t14=t7;
f_7142(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[185]);
t15=t7;
f_7142(t15,(C_truep(t14)?t14:C_eqp(((C_word*)t0)[4],lf[186])));}}}}}}}}}}}}}

/* k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9867(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_9867,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
/* support.scm:755: walk */
t5=((C_word*)t3)[1];
f_9875(t5,((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k9198 in loop in k9162 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9200(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_9200,2,av);}
a=C_alloc(9);
t2=C_a_i_list(&a,2,lf[238],t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,1,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k7067 in k7061 in loop in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7069(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_7069,2,av);}
t2=C_i_caar(((C_word*)t0)[2]);
t3=C_i_assq(t2,lf[171]);
t4=C_i_cdr(t3);
/* support.scm:471: ##sys#print */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k9213 in k9225 in loop in k9162 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9215(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_9215,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* for-each-loop2235 in k10607 in k10599 in k10593 in k10590 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10617(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_10617,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10627,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:815: g2251 */
t5=*((C_word*)lf[295]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[296];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* g1132 in k7732 in k7729 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_7743(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_7743,3,t0,t1,t2);}
t3=C_i_cadr(t2);
/* support.scm:551: walk */
t4=((C_word*)((C_word*)t0)[2])[1];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
f_7538(3,av2);}}

/* k7149 in k7146 in k7140 in k7061 in loop in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7151(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_7151,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:482: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(61);
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k7152 in k7149 in k7146 in k7140 in k7061 in loop in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_7154,2,av);}
t2=C_i_cdar(((C_word*)t0)[2]);
/* support.scm:482: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k9225 in loop in k9162 in k8811 in walk in build-expression-tree in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9227(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_9227,2,av);}
a=C_alloc(10);
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9215,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[4];
t6=C_u_i_cdr(t5);
t7=((C_word*)t0)[5];
t8=C_u_i_cdr(t7);
/* support.scm:660: loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_9176(t9,t4,t6,t8);}

/* k10599 in k10593 in k10590 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10601(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_10601,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10609,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:815: sort-symbols */
t3=*((C_word*)lf[93]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a6206 in tmp24364 in a6157 in a6126 in string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6207(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6207,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* tmp24364 in a6157 in a6126 in string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_6201(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_6201,3,t0,t1,t2);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6207,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:302: k484 */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k10607 in k10599 in k10593 in k10590 in emit-global-inline-file in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10609(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_10609,2,av);}
a=C_alloc(5);
t2=C_i_check_list_2(t1,lf[35]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10617,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10617(t6,((C_word*)t0)[2],t1);}

/* k6198 in a6185 in tmp14363 in a6157 in a6126 in string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6200(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_6200,2,av);}
/* support.scm:313: unfold */
t2=*((C_word*)lf[118]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[119]+1);
av2[3]=*((C_word*)lf[120]+1);
av2[4]=((C_word*)t0)[3];
av2[5]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k7146 in k7140 in k7061 in loop in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7148(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_7148,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_caar(((C_word*)t0)[2]);
/* support.scm:482: ##sys#print */
t4=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k7140 in k7061 in loop in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_7142(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_7142,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:482: ##sys#write-char-0 */
t6=*((C_word*)lf[18]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t5;
av2[2]=C_make_character(9);
av2[3]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[176]);
if(C_truep(t2)){
t3=C_i_cdar(((C_word*)t0)[2]);
t4=C_mutate2(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* support.scm:488: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_7039(t7,((C_word*)t0)[7],t6);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[177]);
if(C_truep(t3)){
t4=C_i_cdar(((C_word*)t0)[2]);
t5=C_mutate2(((C_word *)((C_word*)t0)[8])+1,t4);
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
/* support.scm:488: loop */
t8=((C_word*)((C_word*)t0)[6])[1];
f_7039(t8,((C_word*)t0)[7],t7);}
else{
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
/* support.scm:487: bomb */
t6=*((C_word*)lf[3]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[178];
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}}}

/* a11776 in foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11777(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_11777,4,av);}
a=C_alloc(7);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11783,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_11783(t7,t1,t2);}

/* ##compiler#foreign-type-check in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11771(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_11771,4,av);}
a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11777,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12758,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1017: follow-without-loop */
t6=*((C_word*)lf[92]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_support_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_support_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(4471)){
C_save(t1);
C_rereclaim2(4471*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,568);
lf[0]=C_h_intern(&lf[0],30,"\010compilercompiler-cleanup-hook");
lf[1]=C_h_intern(&lf[1],26,"\010compilerdebugging-chicken");
lf[2]=C_h_intern(&lf[2],26,"\010compilerdisabled-warnings");
lf[3]=C_h_intern(&lf[3],13,"\010compilerbomb");
lf[4]=C_h_intern(&lf[4],5,"error");
lf[5]=C_h_intern(&lf[5],13,"string-append");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[8]=C_h_intern(&lf[8],35,"\010compilercollected-debugging-output");
lf[9]=C_h_intern(&lf[9],24,"+logged-debugging-modes+");
lf[10]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001o\376\003\000\000\002\376\001\000\000\001x\376\003\000\000\002\376\001\000\000\001S\376\377\016");
lf[11]=C_h_intern(&lf[11],19,"test-debugging-mode");
lf[12]=C_h_intern(&lf[12],17,"lset-intersection");
lf[13]=C_h_intern(&lf[13],3,"eq\077");
lf[14]=C_h_intern(&lf[14],18,"\010compilerdebugging");
lf[15]=C_h_intern(&lf[15],7,"newline");
lf[16]=C_h_intern(&lf[16],19,"\003sysstandard-output");
lf[17]=C_h_intern(&lf[17],6,"printf");
lf[18]=C_h_intern(&lf[18],16,"\003syswrite-char-0");
lf[19]=C_h_intern(&lf[19],9,"\003sysprint");
lf[20]=C_h_intern(&lf[20],5,"force");
lf[21]=C_h_intern(&lf[21],7,"display");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[23]=C_h_intern(&lf[23],21,"with-output-to-string");
lf[24]=C_h_intern(&lf[24],7,"fprintf");
lf[25]=C_h_intern(&lf[25],12,"flush-output");
lf[26]=C_h_intern(&lf[26],30,"\010compilerwith-debugging-output");
lf[27]=C_h_intern(&lf[27],12,"string-split");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[29]=C_h_intern(&lf[29],13,"\010compilerquit");
lf[30]=C_h_intern(&lf[30],18,"\003sysstandard-error");
lf[31]=C_h_intern(&lf[31],4,"exit");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\010\012Error: ");
lf[33]=C_h_intern(&lf[33],21,"\003syssyntax-error-hook");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[35]=C_h_intern(&lf[35],8,"for-each");
lf[36]=C_h_intern(&lf[36],16,"print-call-chain");
lf[37]=C_h_intern(&lf[37],18,"\003syscurrent-thread");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\003): ");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\017\012Syntax error (");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\017\012Syntax error: ");
lf[42]=C_h_intern(&lf[42],12,"syntax-error");
lf[43]=C_h_intern(&lf[43],31,"\010compileremit-syntax-trace-info");
lf[44]=C_h_intern(&lf[44],9,"map-llist");
lf[45]=C_h_intern(&lf[45],24,"\010compilercheck-signature");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[47]=C_h_intern(&lf[47],18,"\010compilerreal-name");
lf[48]=C_h_intern(&lf[48],13,"\010compilerposq");
lf[49]=C_h_intern(&lf[49],13,"\010compilerposv");
lf[50]=C_h_intern(&lf[50],18,"\010compilerstringify");
lf[51]=C_h_intern(&lf[51],14,"symbol->string");
lf[52]=C_h_intern(&lf[52],7,"sprintf");
lf[53]=C_h_intern(&lf[53],17,"get-output-string");
lf[54]=C_h_intern(&lf[54],18,"open-output-string");
lf[55]=C_h_intern(&lf[55],18,"\010compilersymbolify");
lf[56]=C_h_intern(&lf[56],14,"string->symbol");
lf[57]=C_h_intern(&lf[57],21,"\010compilerbackslashify");
lf[58]=C_h_intern(&lf[58],17,"string-translate\052");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\134\376B\000\000\002\134\134\376\377\016");
lf[60]=C_h_intern(&lf[60],8,"->string");
lf[61]=C_h_intern(&lf[61],21,"\010compileruncommentify");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002\052/\376B\000\000\003\052_/\376\377\016");
lf[63]=C_h_intern(&lf[63],26,"\010compilerbuild-lambda-list");
lf[64]=C_h_intern(&lf[64],29,"\010compilerstring->c-identifier");
lf[65]=C_h_intern(&lf[65],24,"\003sysstring->c-identifier");
lf[66]=C_h_intern(&lf[66],21,"\010compilerc-ify-string");
lf[67]=C_h_intern(&lf[67],16,"\003syslist->string");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[69]=C_h_intern(&lf[69],6,"append");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[71]=C_h_intern(&lf[71],16,"\003sysstring->list");
lf[72]=C_h_intern(&lf[72],14,"number->string");
lf[73]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[74]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\003\000\000\002\376\377\012\000\000\052\376\377\016");
lf[76]=C_h_intern(&lf[76],28,"\010compilervalid-c-identifier\077");
lf[77]=C_h_intern(&lf[77],3,"any");
lf[78]=C_h_intern(&lf[78],14,"\010compilerwords");
lf[79]=C_h_intern(&lf[79],21,"\010compilerwords->bytes");
lf[80]=C_h_intern(&lf[80],34,"\010compilercheck-and-open-input-file");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[82]=C_h_intern(&lf[82],18,"\003sysstandard-input");
lf[83]=C_h_intern(&lf[83],15,"open-input-file");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\031(~a) can not open file ~s");
lf[86]=C_h_intern(&lf[86],12,"file-exists\077");
lf[87]=C_h_intern(&lf[87],33,"\010compilerclose-checked-input-file");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[89]=C_h_intern(&lf[89],16,"close-input-port");
lf[90]=C_h_intern(&lf[90],19,"\010compilerfold-inner");
lf[91]=C_h_intern(&lf[91],7,"reverse");
lf[92]=C_h_intern(&lf[92],28,"\010compilerfollow-without-loop");
lf[93]=C_h_intern(&lf[93],21,"\010compilersort-symbols");
lf[94]=C_h_intern(&lf[94],8,"string<\077");
lf[95]=C_h_intern(&lf[95],4,"sort");
lf[96]=C_h_intern(&lf[96],18,"\010compilerconstant\077");
lf[97]=C_h_intern(&lf[97],5,"quote");
lf[98]=C_h_intern(&lf[98],18,"\003syssrfi-4-vector\077");
lf[99]=C_h_intern(&lf[99],5,"blob\077");
lf[100]=C_h_intern(&lf[100],29,"\010compilercollapsable-literal\077");
lf[101]=C_h_intern(&lf[101],19,"\010compilerimmediate\077");
lf[102]=C_h_intern(&lf[102],20,"\010compilerbig-fixnum\077");
lf[103]=C_h_intern(&lf[103],23,"\010compilerbasic-literal\077");
lf[104]=C_h_intern(&lf[104],5,"every");
lf[105]=C_h_intern(&lf[105],12,"vector->list");
lf[106]=C_h_intern(&lf[106],32,"\010compilercanonicalize-begin-body");
lf[107]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[108]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[109]=C_h_intern(&lf[109],3,"let");
lf[110]=C_h_intern(&lf[110],6,"gensym");
lf[111]=C_h_intern(&lf[111],1,"t");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[113]=C_h_intern(&lf[113],21,"\010compilerstring->expr");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot parse expression: ~s [~a]~%");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[116]=C_h_intern(&lf[116],5,"begin");
lf[117]=C_h_intern(&lf[117],4,"read");
lf[118]=C_h_intern(&lf[118],6,"unfold");
lf[119]=C_h_intern(&lf[119],11,"eof-object\077");
lf[120]=C_h_intern(&lf[120],6,"values");
lf[121]=C_h_intern(&lf[121],22,"with-input-from-string");
lf[122]=C_h_intern(&lf[122],22,"with-exception-handler");
lf[123]=C_h_intern(&lf[123],30,"call-with-current-continuation");
lf[124]=C_h_intern(&lf[124],30,"\010compilerdecompose-lambda-list");
lf[125]=C_h_intern(&lf[125],25,"\003sysdecompose-lambda-list");
lf[126]=C_h_intern(&lf[126],21,"\010compilerllist-length");
lf[127]=C_h_intern(&lf[127],21,"\010compilerllist-match\077");
lf[128]=C_h_intern(&lf[128],30,"\010compilerexpand-profile-lambda");
lf[129]=C_h_intern(&lf[129],29,"\010compilerprofile-lambda-index");
lf[130]=C_h_intern(&lf[130],28,"\010compilerprofile-lambda-list");
lf[131]=C_h_intern(&lf[131],17,"\003sysprofile-entry");
lf[132]=C_h_intern(&lf[132],33,"\010compilerprofile-info-vector-name");
lf[133]=C_h_intern(&lf[133],11,"\004corelambda");
lf[134]=C_h_intern(&lf[134],9,"\003sysapply");
lf[135]=C_h_intern(&lf[135],16,"\003sysprofile-exit");
lf[136]=C_h_intern(&lf[136],16,"\003sysdynamic-wind");
lf[137]=C_h_intern(&lf[137],37,"\010compilerinitialize-analysis-database");
lf[138]=C_h_intern(&lf[138],17,"standard-bindings");
lf[139]=C_h_intern(&lf[139],17,"extended-bindings");
lf[140]=C_h_intern(&lf[140],26,"\010compilerinternal-bindings");
lf[141]=C_h_intern(&lf[141],8,"internal");
lf[142]=C_h_intern(&lf[142],8,"\003sysput!");
lf[143]=C_h_intern(&lf[143],18,"\010compilerintrinsic");
lf[144]=C_h_intern(&lf[144],26,"\010compilerfoldable-bindings");
lf[145]=C_h_intern(&lf[145],17,"\010compilerfoldable");
lf[146]=C_h_intern(&lf[146],8,"extended");
lf[147]=C_h_intern(&lf[147],8,"standard");
lf[148]=C_h_intern(&lf[148],12,"\010compilerget");
lf[149]=C_h_intern(&lf[149],18,"\003syshash-table-ref");
lf[150]=C_h_intern(&lf[150],16,"\010compilerget-all");
lf[151]=C_h_intern(&lf[151],10,"filter-map");
lf[152]=C_h_intern(&lf[152],13,"\010compilerput!");
lf[153]=C_h_intern(&lf[153],19,"\003syshash-table-set!");
lf[154]=C_h_intern(&lf[154],17,"\010compilercollect!");
lf[155]=C_h_intern(&lf[155],15,"\010compilercount!");
lf[156]=C_h_intern(&lf[156],17,"\010compilerget-list");
lf[157]=C_h_intern(&lf[157],17,"\010compilerget-line");
lf[158]=C_h_intern(&lf[158],24,"\003sysline-number-database");
lf[159]=C_h_intern(&lf[159],19,"\010compilerget-line-2");
lf[160]=C_h_intern(&lf[160],37,"\010compilerdisplay-line-number-database");
lf[161]=C_h_intern(&lf[161],3,"map");
lf[162]=C_h_intern(&lf[162],23,"\003syshash-table-for-each");
lf[163]=C_h_intern(&lf[163],34,"\010compilerdisplay-analysis-database");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\005\011css=");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\006\011refs=");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\005\011val=");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\006\011lval=");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\006\011pval=");
lf[169]=C_h_intern(&lf[169],7,"unknown");
lf[170]=C_h_intern(&lf[170],8,"captured");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376"
"\001\000\000\003col\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\015inline-target\376\001\000\000\003ilt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020inline-transient\376\001\000\000\003itr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"undefined\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\013hidden-refs\376\001\000\000\003hrf\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011value-ref\376\001\000\000\003vvf\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014custom"
"izable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012boxed-r"
"est\376\001\000\000\003bxr\376\377\016");
lf[172]=C_h_intern(&lf[172],5,"value");
lf[173]=C_h_intern(&lf[173],11,"local-value");
lf[174]=C_h_intern(&lf[174],15,"potential-value");
lf[175]=C_h_intern(&lf[175],10,"replacable");
lf[176]=C_h_intern(&lf[176],10,"references");
lf[177]=C_h_intern(&lf[177],10,"call-sites");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[179]=C_h_intern(&lf[179],4,"home");
lf[180]=C_h_intern(&lf[180],8,"contains");
lf[181]=C_h_intern(&lf[181],12,"contained-in");
lf[182]=C_h_intern(&lf[182],8,"use-expr");
lf[183]=C_h_intern(&lf[183],12,"closure-size");
lf[184]=C_h_intern(&lf[184],14,"rest-parameter");
lf[185]=C_h_intern(&lf[185],18,"captured-variables");
lf[186]=C_h_intern(&lf[186],13,"explicit-rest");
lf[187]=C_h_intern(&lf[187],8,"assigned");
lf[188]=C_h_intern(&lf[188],5,"boxed");
lf[189]=C_h_intern(&lf[189],6,"global");
lf[190]=C_h_intern(&lf[190],12,"contractable");
lf[191]=C_h_intern(&lf[191],16,"standard-binding");
lf[192]=C_h_intern(&lf[192],16,"assigned-locally");
lf[193]=C_h_intern(&lf[193],11,"collapsable");
lf[194]=C_h_intern(&lf[194],9,"removable");
lf[195]=C_h_intern(&lf[195],9,"undefined");
lf[196]=C_h_intern(&lf[196],9,"replacing");
lf[197]=C_h_intern(&lf[197],6,"unused");
lf[198]=C_h_intern(&lf[198],6,"simple");
lf[199]=C_h_intern(&lf[199],9,"inlinable");
lf[200]=C_h_intern(&lf[200],13,"inline-export");
lf[201]=C_h_intern(&lf[201],21,"has-unused-parameters");
lf[202]=C_h_intern(&lf[202],16,"extended-binding");
lf[203]=C_h_intern(&lf[203],12,"customizable");
lf[204]=C_h_intern(&lf[204],8,"constant");
lf[205]=C_h_intern(&lf[205],10,"boxed-rest");
lf[206]=C_h_intern(&lf[206],11,"hidden-refs");
lf[207]=C_h_intern(&lf[207],5,"write");
lf[208]=C_h_intern(&lf[208],34,"\010compilerdefault-standard-bindings");
lf[209]=C_h_intern(&lf[209],34,"\010compilerdefault-extended-bindings");
lf[210]=C_h_intern(&lf[210],9,"make-node");
lf[211]=C_h_intern(&lf[211],4,"node");
lf[212]=C_h_intern(&lf[212],5,"node\077");
lf[213]=C_h_intern(&lf[213],10,"node-class");
lf[214]=C_h_intern(&lf[214],15,"node-class-set!");
lf[215]=C_h_intern(&lf[215],14,"\003sysblock-set!");
lf[216]=C_h_intern(&lf[216],15,"node-parameters");
lf[217]=C_h_intern(&lf[217],20,"node-parameters-set!");
lf[218]=C_h_intern(&lf[218],19,"node-subexpressions");
lf[219]=C_h_intern(&lf[219],24,"node-subexpressions-set!");
lf[220]=C_h_intern(&lf[220],16,"\010compilervarnode");
lf[221]=C_h_intern(&lf[221],13,"\004corevariable");
lf[222]=C_h_intern(&lf[222],14,"\010compilerqnode");
lf[223]=C_h_intern(&lf[223],25,"\010compilerbuild-node-graph");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[225]=C_h_intern(&lf[225],2,"if");
lf[226]=C_h_intern(&lf[226],14,"\004coreundefined");
lf[227]=C_h_intern(&lf[227],8,"truncate");
lf[228]=C_h_intern(&lf[228],7,"warning");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\0006literal is out of range - will be truncated to integer");
lf[230]=C_h_intern(&lf[230],6,"fixnum");
lf[231]=C_h_intern(&lf[231],11,"number-type");
lf[232]=C_h_intern(&lf[232],4,"\000tmp");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\021SHOULD NOT HAPPEN");
lf[234]=C_h_intern(&lf[234],6,"unzip1");
lf[235]=C_h_intern(&lf[235],6,"lambda");
lf[236]=C_h_intern(&lf[236],8,"\004corethe");
lf[237]=C_h_intern(&lf[237],13,"\004coretypecase");
lf[238]=C_h_intern(&lf[238],4,"else");
lf[239]=C_h_intern(&lf[239],5,"cadar");
lf[240]=C_h_intern(&lf[240],1,"\052");
lf[241]=C_h_intern(&lf[241],14,"\004coreprimitive");
lf[242]=C_h_intern(&lf[242],11,"\004coreinline");
lf[243]=C_h_intern(&lf[243],13,"\004corecallunit");
lf[244]=C_h_intern(&lf[244],16,"\004coredebug-event");
lf[245]=C_h_intern(&lf[245],9,"\004coreproc");
lf[246]=C_h_intern(&lf[246],4,"set!");
lf[247]=C_h_intern(&lf[247],9,"\004coreset!");
lf[248]=C_h_intern(&lf[248],29,"\004coreforeign-callback-wrapper");
lf[249]=C_h_intern(&lf[249],5,"sixth");
lf[250]=C_h_intern(&lf[250],5,"fifth");
lf[251]=C_h_intern(&lf[251],20,"\004coreinline_allocate");
lf[252]=C_h_intern(&lf[252],8,"\004coreapp");
lf[253]=C_h_intern(&lf[253],9,"\004corecall");
lf[254]=C_h_intern(&lf[254],28,"\003syssymbol->qualified-string");
lf[255]=C_h_intern(&lf[255],7,"\003sysget");
lf[256]=C_h_intern(&lf[256],34,"\010compileralways-bound-to-procedure");
lf[257]=C_h_intern(&lf[257],15,"\004coreinline_ref");
lf[258]=C_h_intern(&lf[258],18,"\004coreinline_update");
lf[259]=C_h_intern(&lf[259],19,"\004coreinline_loc_ref");
lf[260]=C_h_intern(&lf[260],22,"\004coreinline_loc_update");
lf[261]=C_h_intern(&lf[261],1,"o");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[263]=C_h_intern(&lf[263],30,"\010compilerbuild-expression-tree");
lf[264]=C_h_intern(&lf[264],12,"\004coreclosure");
lf[265]=C_h_intern(&lf[265],4,"last");
lf[266]=C_h_intern(&lf[266],7,"butlast");
lf[267]=C_h_intern(&lf[267],3,"the");
lf[268]=C_h_intern(&lf[268],15,"\004corethe/result");
lf[269]=C_h_intern(&lf[269],17,"compiler-typecase");
lf[270]=C_h_intern(&lf[270],5,"cons\052");
lf[271]=C_h_intern(&lf[271],9,"\004corebind");
lf[272]=C_h_intern(&lf[272],10,"\004coreunbox");
lf[273]=C_h_intern(&lf[273],16,"\004corelet_unboxed");
lf[274]=C_h_intern(&lf[274],8,"\004coreref");
lf[275]=C_h_intern(&lf[275],11,"\004coreupdate");
lf[276]=C_h_intern(&lf[276],13,"\004coreupdate_i");
lf[277]=C_h_intern(&lf[277],8,"\004corebox");
lf[278]=C_h_intern(&lf[278],9,"\004corecond");
lf[279]=C_h_intern(&lf[279],21,"\010compilerfold-boolean");
lf[280]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[281]=C_h_intern(&lf[281],31,"\010compilerinline-lambda-bindings");
lf[282]=C_h_intern(&lf[282],8,"split-at");
lf[283]=C_h_intern(&lf[283],10,"fold-right");
lf[284]=C_h_intern(&lf[284],4,"take");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[286]=C_h_intern(&lf[286],34,"\010compilercopy-node-tree-and-rename");
lf[287]=C_h_intern(&lf[287],9,"alist-ref");
lf[288]=C_h_intern(&lf[288],16,"inline-transient");
lf[289]=C_h_intern(&lf[289],1,"f");
lf[290]=C_h_intern(&lf[290],18,"\010compilertree-copy");
lf[291]=C_h_intern(&lf[291],19,"\010compilercopy-node!");
lf[292]=C_h_intern(&lf[292],20,"\010compilernode->sexpr");
lf[293]=C_h_intern(&lf[293],20,"\010compilersexpr->node");
lf[294]=C_h_intern(&lf[294],32,"\010compileremit-global-inline-file");
lf[295]=C_h_intern(&lf[295],5,"print");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[297]=C_h_intern(&lf[297],1,"i");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\0001the following procedures can be globally inlined:");
lf[299]=C_h_intern(&lf[299],12,"delete-file\052");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\015; END OF FILE");
lf[301]=C_h_intern(&lf[301],2,"pp");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\027; GENERATED BY CHICKEN ");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\006 FROM ");
lf[304]=C_h_intern(&lf[304],24,"\010compilersource-filename");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[306]=C_h_intern(&lf[306],15,"chicken-version");
lf[307]=C_h_intern(&lf[307],19,"with-output-to-file");
lf[308]=C_h_intern(&lf[308],3,"yes");
lf[309]=C_h_intern(&lf[309],2,"no");
lf[310]=C_h_intern(&lf[310],24,"\010compilerinline-max-size");
lf[311]=C_h_intern(&lf[311],15,"\010compilerinline");
lf[312]=C_h_intern(&lf[312],22,"\010compilerinline-global");
lf[313]=C_h_intern(&lf[313],26,"\010compilervariable-visible\077");
lf[314]=C_h_intern(&lf[314],25,"\010compilerload-inline-file");
lf[315]=C_h_intern(&lf[315],20,"with-input-from-file");
lf[316]=C_h_intern(&lf[316],19,"\010compilermatch-node");
lf[317]=C_h_intern(&lf[317],1,"a");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[319]=C_h_intern(&lf[319],37,"\010compilerexpression-has-side-effects\077");
lf[320]=C_h_intern(&lf[320],24,"foreign-callback-stub-id");
lf[321]=C_h_intern(&lf[321],4,"find");
lf[322]=C_h_intern(&lf[322],22,"foreign-callback-stubs");
lf[323]=C_h_intern(&lf[323],28,"\010compilersimple-lambda-node\077");
lf[324]=C_h_intern(&lf[324],31,"\010compilerdump-undefined-globals");
lf[325]=C_h_intern(&lf[325],8,"keyword\077");
lf[326]=C_h_intern(&lf[326],29,"\010compilerdump-defined-globals");
lf[327]=C_h_intern(&lf[327],25,"\010compilerdump-global-refs");
lf[328]=C_h_intern(&lf[328],28,"\003systoplevel-definition-hook");
lf[329]=C_h_intern(&lf[329],22,"\010compilerhide-variable");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[331]=C_h_intern(&lf[331],36,"\010compilercompute-database-statistics");
lf[332]=C_h_intern(&lf[332],29,"\010compilercurrent-program-size");
lf[333]=C_h_intern(&lf[333],30,"\010compileroriginal-program-size");
lf[334]=C_h_intern(&lf[334],33,"\010compilerprint-program-statistics");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\027;   database entries: \011");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known call sites: \011");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\027;   global variables: \011");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known procedures: \011");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\042;   variables with known values: \011");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\032 \011original program size: \011");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\023;   program size: \011");
lf[342]=C_h_intern(&lf[342],1,"s");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[344]=C_h_intern(&lf[344],35,"\010compilerpprint-expressions-to-file");
lf[345]=C_h_intern(&lf[345],17,"close-output-port");
lf[346]=C_h_intern(&lf[346],12,"pretty-print");
lf[347]=C_h_intern(&lf[347],19,"with-output-to-port");
lf[348]=C_h_intern(&lf[348],16,"open-output-file");
lf[349]=C_h_intern(&lf[349],27,"\010compilerforeign-type-check");
lf[350]=C_h_intern(&lf[350],4,"char");
lf[351]=C_h_intern(&lf[351],13,"unsigned-char");
lf[352]=C_h_intern(&lf[352],6,"unsafe");
lf[353]=C_h_intern(&lf[353],25,"\003sysforeign-char-argument");
lf[354]=C_h_intern(&lf[354],3,"int");
lf[355]=C_h_intern(&lf[355],27,"\003sysforeign-fixnum-argument");
lf[356]=C_h_intern(&lf[356],5,"float");
lf[357]=C_h_intern(&lf[357],27,"\003sysforeign-flonum-argument");
lf[358]=C_h_intern(&lf[358],4,"blob");
lf[359]=C_h_intern(&lf[359],14,"scheme-pointer");
lf[360]=C_h_intern(&lf[360],26,"\003sysforeign-block-argument");
lf[361]=C_h_intern(&lf[361],22,"nonnull-scheme-pointer");
lf[362]=C_h_intern(&lf[362],12,"nonnull-blob");
lf[363]=C_h_intern(&lf[363],14,"pointer-vector");
lf[364]=C_h_intern(&lf[364],35,"\003sysforeign-struct-wrapper-argument");
lf[365]=C_h_intern(&lf[365],22,"nonnull-pointer-vector");
lf[366]=C_h_intern(&lf[366],8,"u8vector");
lf[367]=C_h_intern(&lf[367],16,"nonnull-u8vector");
lf[368]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[369]=C_h_intern(&lf[369],7,"integer");
lf[370]=C_h_intern(&lf[370],28,"\003sysforeign-integer-argument");
lf[371]=C_h_intern(&lf[371],9,"integer64");
lf[372]=C_h_intern(&lf[372],30,"\003sysforeign-integer64-argument");
lf[373]=C_h_intern(&lf[373],16,"unsigned-integer");
lf[374]=C_h_intern(&lf[374],37,"\003sysforeign-unsigned-integer-argument");
lf[375]=C_h_intern(&lf[375],18,"unsigned-integer64");
lf[376]=C_h_intern(&lf[376],39,"\003sysforeign-unsigned-integer64-argument");
lf[377]=C_h_intern(&lf[377],9,"c-pointer");
lf[378]=C_h_intern(&lf[378],28,"\003sysforeign-pointer-argument");
lf[379]=C_h_intern(&lf[379],17,"nonnull-c-pointer");
lf[380]=C_h_intern(&lf[380],8,"c-string");
lf[381]=C_h_intern(&lf[381],17,"\003sysmake-c-string");
lf[382]=C_h_intern(&lf[382],27,"\003sysforeign-string-argument");
lf[383]=C_h_intern(&lf[383],16,"nonnull-c-string");
lf[384]=C_h_intern(&lf[384],6,"symbol");
lf[385]=C_h_intern(&lf[385],18,"\003syssymbol->string");
lf[386]=C_h_intern(&lf[386],3,"ref");
lf[387]=C_h_intern(&lf[387],8,"instance");
lf[388]=C_h_intern(&lf[388],12,"instance-ref");
lf[389]=C_h_intern(&lf[389],4,"this");
lf[390]=C_h_intern(&lf[390],8,"slot-ref");
lf[391]=C_h_intern(&lf[391],16,"nonnull-instance");
lf[392]=C_h_intern(&lf[392],5,"const");
lf[393]=C_h_intern(&lf[393],4,"enum");
lf[394]=C_h_intern(&lf[394],15,"nonnull-pointer");
lf[395]=C_h_intern(&lf[395],7,"pointer");
lf[396]=C_h_intern(&lf[396],8,"function");
lf[397]=C_h_intern(&lf[397],27,"\010compilerforeign-type-table");
lf[398]=C_h_intern(&lf[398],17,"nonnull-c-string\052");
lf[399]=C_h_intern(&lf[399],26,"nonnull-unsigned-c-string\052");
lf[400]=C_h_intern(&lf[400],9,"c-string\052");
lf[401]=C_h_intern(&lf[401],17,"unsigned-c-string");
lf[402]=C_h_intern(&lf[402],18,"unsigned-c-string\052");
lf[403]=C_h_intern(&lf[403],13,"c-string-list");
lf[404]=C_h_intern(&lf[404],14,"c-string-list\052");
lf[405]=C_h_intern(&lf[405],18,"unsigned-integer32");
lf[406]=C_h_intern(&lf[406],13,"unsigned-long");
lf[407]=C_h_intern(&lf[407],4,"long");
lf[408]=C_h_intern(&lf[408],6,"size_t");
lf[409]=C_h_intern(&lf[409],9,"integer32");
lf[410]=C_h_intern(&lf[410],17,"nonnull-u16vector");
lf[411]=C_h_intern(&lf[411],16,"nonnull-s8vector");
lf[412]=C_h_intern(&lf[412],17,"nonnull-s16vector");
lf[413]=C_h_intern(&lf[413],17,"nonnull-u32vector");
lf[414]=C_h_intern(&lf[414],17,"nonnull-s32vector");
lf[415]=C_h_intern(&lf[415],17,"nonnull-f32vector");
lf[416]=C_h_intern(&lf[416],17,"nonnull-f64vector");
lf[417]=C_h_intern(&lf[417],9,"u16vector");
lf[418]=C_h_intern(&lf[418],8,"s8vector");
lf[419]=C_h_intern(&lf[419],9,"s16vector");
lf[420]=C_h_intern(&lf[420],9,"u32vector");
lf[421]=C_h_intern(&lf[421],9,"s32vector");
lf[422]=C_h_intern(&lf[422],9,"f32vector");
lf[423]=C_h_intern(&lf[423],9,"f64vector");
lf[424]=C_h_intern(&lf[424],6,"double");
lf[425]=C_h_intern(&lf[425],6,"number");
lf[426]=C_h_intern(&lf[426],12,"unsigned-int");
lf[427]=C_h_intern(&lf[427],5,"short");
lf[428]=C_h_intern(&lf[428],14,"unsigned-short");
lf[429]=C_h_intern(&lf[429],4,"byte");
lf[430]=C_h_intern(&lf[430],13,"unsigned-byte");
lf[431]=C_h_intern(&lf[431],5,"int32");
lf[432]=C_h_intern(&lf[432],14,"unsigned-int32");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[434]=C_h_intern(&lf[434],36,"\010compilerforeign-type-convert-result");
lf[435]=C_h_intern(&lf[435],38,"\010compilerforeign-type-convert-argument");
lf[436]=C_h_intern(&lf[436],27,"\010compilerfinal-foreign-type");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[438]=C_h_intern(&lf[438],37,"\010compilerestimate-foreign-result-size");
lf[439]=C_h_intern(&lf[439],4,"bool");
lf[440]=C_h_intern(&lf[440],4,"void");
lf[441]=C_h_intern(&lf[441],13,"scheme-object");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[443]=C_h_intern(&lf[443],46,"\010compilerestimate-foreign-result-location-size");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\0005cannot compute size of location for foreign type `~S\047");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[446]=C_h_intern(&lf[446],30,"\010compilerfinish-foreign-result");
lf[447]=C_h_intern(&lf[447],17,"\003syspeek-c-string");
lf[448]=C_h_intern(&lf[448],25,"\003syspeek-nonnull-c-string");
lf[449]=C_h_intern(&lf[449],26,"\003syspeek-and-free-c-string");
lf[450]=C_h_intern(&lf[450],34,"\003syspeek-and-free-nonnull-c-string");
lf[451]=C_h_intern(&lf[451],17,"\003sysintern-symbol");
lf[452]=C_h_intern(&lf[452],22,"\003syspeek-c-string-list");
lf[453]=C_h_intern(&lf[453],31,"\003syspeek-and-free-c-string-list");
lf[454]=C_h_intern(&lf[454],17,"\003sysnull-pointer\077");
lf[455]=C_h_intern(&lf[455],3,"not");
lf[456]=C_h_intern(&lf[456],4,"make");
lf[457]=C_h_intern(&lf[457],3,"and");
lf[458]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010c-string\376\003\000\000\002\376\001\000\000\011c-string\052\376\003\000\000\002\376\001\000\000\021unsigned-c-string\376\003\000\000\002\376\001\000\000\022unsign"
"ed-c-string\052\376\003\000\000\002\376\001\000\000\020nonnull-c-string\376\003\000\000\002\376\001\000\000\021nonnull-c-string\052\376\003\000\000\002\376\001\000\000\030nonnu"
"ll-unsigned-string\052\376\377\016");
lf[459]=C_h_intern(&lf[459],16,"\003sysstrip-syntax");
lf[460]=C_h_intern(&lf[460],36,"\010compilerforeign-type->scrutiny-type");
lf[461]=C_h_intern(&lf[461],3,"arg");
lf[462]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\004blob\376\377\016");
lf[463]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\016pointer-vector\376\377\016");
lf[464]=C_h_intern(&lf[464],6,"struct");
lf[465]=C_h_intern(&lf[465],2,"or");
lf[466]=C_h_intern(&lf[466],7,"boolean");
lf[467]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\010u8vector\376\377\016");
lf[468]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\010s8vector\376\377\016");
lf[469]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011u16vector\376\377\016");
lf[470]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011s16vector\376\377\016");
lf[471]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011u32vector\376\377\016");
lf[472]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011s32vector\376\377\016");
lf[473]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011f32vector\376\377\016");
lf[474]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011f64vector\376\377\016");
lf[475]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\010locative\376\377\016");
lf[476]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[477]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007list-of\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[478]=C_h_intern(&lf[478],6,"string");
lf[479]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\010locative\376\377\016");
lf[480]=C_h_intern(&lf[480],28,"\010compilerscan-used-variables");
lf[481]=C_h_intern(&lf[481],28,"\010compilerscan-free-variables");
lf[482]=C_h_intern(&lf[482],11,"lset-adjoin");
lf[483]=C_h_intern(&lf[483],23,"\010compilerchop-separator");
lf[484]=C_h_intern(&lf[484],9,"substring");
lf[485]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[486]=C_h_intern(&lf[486],23,"\010compilerchop-extension");
lf[487]=C_h_intern(&lf[487],36,"\010compilermake-block-variable-literal");
lf[488]=C_h_intern(&lf[488],22,"block-variable-literal");
lf[489]=C_h_intern(&lf[489],32,"\010compilerblock-variable-literal\077");
lf[490]=C_h_intern(&lf[490],36,"\010compilerblock-variable-literal-name");
lf[491]=C_h_intern(&lf[491],27,"block-variable-literal-name");
lf[492]=C_h_intern(&lf[492],25,"\010compilermake-random-name");
lf[493]=C_h_intern(&lf[493],6,"random");
lf[494]=C_h_intern(&lf[494],15,"current-seconds");
lf[495]=C_h_intern(&lf[495],23,"\010compilerset-real-name!");
lf[496]=C_h_intern(&lf[496],24,"\010compilerreal-name-table");
lf[497]=C_h_intern(&lf[497],19,"real-name-max-depth");
lf[498]=C_h_intern(&lf[498],18,"string-intersperse");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[503]=C_h_intern(&lf[503],19,"\010compilerreal-name2");
lf[504]=C_h_intern(&lf[504],32,"\010compilerdisplay-real-name-table");
lf[505]=C_h_intern(&lf[505],28,"\010compilersource-info->string");
lf[506]=C_h_intern(&lf[506],4,"conc");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[509]=C_h_intern(&lf[509],11,"make-string");
lf[510]=C_h_intern(&lf[510],3,"max");
lf[511]=C_h_intern(&lf[511],26,"\010compilersource-info->line");
lf[512]=C_h_intern(&lf[512],18,"\010compilercall-info");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[515]=C_h_intern(&lf[515],27,"\010compilerconstant-form-eval");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\032folded constant expression");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000Dattempt to constant-fold call to procedure that has multiple results");
lf[518]=C_h_intern(&lf[518],28,"\010compilerencodeable-literal\077");
lf[519]=C_h_intern(&lf[519],22,"get-condition-property");
lf[520]=C_h_intern(&lf[520],3,"exn");
lf[521]=C_h_intern(&lf[521],7,"message");
lf[522]=C_h_intern(&lf[522],8,"\003syslist");
lf[523]=C_decode_literal(C_heaptop,"\376B\000\000.attempt to constant-fold call to non-procedure");
lf[524]=C_h_intern(&lf[524],13,"list-tabulate");
lf[525]=C_h_intern(&lf[525],19,"\010compilerdump-nodes");
lf[526]=C_h_intern(&lf[526],19,"\003syswrite-char/port");
lf[527]=C_h_intern(&lf[527],23,"\010compilerread-info-hook");
lf[528]=C_h_intern(&lf[528],27,"\003syscurrent-source-filename");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[530]=C_h_intern(&lf[530],9,"list-info");
lf[531]=C_h_intern(&lf[531],25,"\010compilerread/source-info");
lf[532]=C_h_intern(&lf[532],8,"\003sysread");
lf[533]=C_h_intern(&lf[533],18,"\003sysuser-read-hook");
lf[534]=C_h_intern(&lf[534],15,"foreign-declare");
lf[535]=C_h_intern(&lf[535],7,"declare");
lf[536]=C_h_intern(&lf[536],34,"\010compilerscan-sharp-greater-string");
lf[537]=C_h_intern(&lf[537],18,"\003sysread-char/port");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[539]=C_h_intern(&lf[539],6,"hidden");
lf[540]=C_h_intern(&lf[540],19,"\010compilervisibility");
lf[541]=C_h_intern(&lf[541],24,"\010compilerexport-variable");
lf[542]=C_h_intern(&lf[542],8,"exported");
lf[543]=C_h_intern(&lf[543],25,"\010compilervariable-hidden\077");
lf[544]=C_h_intern(&lf[544],26,"\010compilerblock-compilation");
lf[545]=C_h_intern(&lf[545],22,"\010compilermark-variable");
lf[546]=C_h_intern(&lf[546],22,"\010compilervariable-mark");
lf[547]=C_h_intern(&lf[547],19,"\010compilerintrinsic\077");
lf[548]=C_h_intern(&lf[548],9,"foldable\077");
lf[549]=C_h_intern(&lf[549],33,"\010compilerload-identifier-database");
lf[550]=C_h_intern(&lf[550],7,"\004coredb");
lf[551]=C_h_intern(&lf[551],9,"read-file");
lf[552]=C_h_intern(&lf[552],1,"p");
lf[553]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[554]=C_decode_literal(C_heaptop,"\376B\000\000\034loading identifier database ");
lf[555]=C_h_intern(&lf[555],13,"make-pathname");
lf[556]=C_h_intern(&lf[556],15,"repository-path");
lf[557]=C_h_intern(&lf[557],22,"\010compilerprint-version");
lf[558]=C_h_intern(&lf[558],6,"print\052");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000C(c) 2008-2016, The CHICKEN Team\012(c) 2000-2007, Felix L. Winkelmann\012");
lf[560]=C_h_intern(&lf[560],20,"\010compilerprint-usage");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\030\252Usage: chicken FILENAME OPTION ...\012\012  `chicken\047 is the CHICKEN compiler.\012  "
"\012  FILENAME should be a complete source file name with extension, or \042-\042 for\012  s"
"tandard input. OPTION may be one of the following:\012\012  General options:\012\012    -hel"
"p                        display this text and exit\012    -version                "
"     display compiler version and exit\012    -release                     print re"
"lease number and exit\012    -verbose                     display information on co"
"mpilation progress\012\012  File and pathname options:\012\012    -output-file FILENAME     "
"   specifies output-filename, default is \047out.c\047\012    -include-path PATHNAME     "
"  specifies alternative path for included files\012    -to-stdout                  "
" write compiled file to stdout instead of file\012\012  Language options:\012\012    -featur"
"e SYMBOL              register feature identifier\012    -no-feature SYMBOL        "
"   disable built-in feature identifier\012\012  Syntax related options:\012\012    -case-ins"
"ensitive            don\047t preserve case of read symbols\012    -keyword-style STYLE"
"         allow alternative keyword syntax\012                                  (pre"
"fix, suffix or none)\012    -no-parentheses-synonyms     disables list delimiter sy"
"nonyms\012    -no-symbol-escape            disables support for escaped symbols\012   "
" -r5rs-syntax                 disables the CHICKEN extensions to\012               "
"                   R5RS syntax\012    -compile-syntax              macros are made "
"available at run-time\012    -emit-import-library MODULE  write compile-time module"
" information into\012                                  separate file\012    -emit-all-"
"import-libraries   emit import-libraries for all defined modules\012    -no-module-"
"registration      do not generate module registration code\012    -no-compiler-synt"
"ax          disable expansion of compiler-macros\012    -module                    "
"  wrap compiled code into implicit module\012\012  Translation options:\012\012    -explicit"
"-use                do not use units \047library\047 and \047eval\047 by\012                   "
"               default\012    -check-syntax                stop compilation after m"
"acro-expansion\012    -analyze-only                stop compilation after first ana"
"lysis pass\012\012  Debugging options:\012\012    -no-warnings                 disable warni"
"ngs\012    -debug-level NUMBER          set level of available debugging informatio"
"n\012    -no-trace                    disable tracing information\012    -debug-info  "
"                enable debug-information in compiled code for use\012              "
"                    with an external debugger\012    -profile                     e"
"xecutable emits profiling information \012    -profile-name FILENAME       name of "
"the generated profile information file\012    -accumulate-profile          executab"
"le emits profiling information in\012                                  append mode\012"
"    -no-lambda-info              omit additional procedure-information\012    -type"
"s FILENAME              load additional type database\012    -emit-type-file FILENA"
"ME     write type-declaration information into file\012\012  Optimization options:\012\012  "
"  -optimize-level NUMBER       enable certain sets of optimization options\012    -"
"optimize-leaf-routines      enable leaf routine optimization\012    -no-usual-integ"
"rations       standard procedures may be redefined\012    -unsafe                  "
"    disable all safety checks\012    -local                       assume globals ar"
"e only modified in current\012                                  file\012    -block    "
"                   enable block-compilation\012    -disable-interrupts          dis"
"able interrupts in compiled code\012    -fixnum-arithmetic           assume all num"
"bers are fixnums\012    -disable-stack-overflow-checks  disables detection of stack"
"-overflows\012    -inline                      enable inlining\012    -inline-limit LI"
"MIT          set inlining threshold\012    -inline-global               enable cros"
"s-module inlining\012    -specialize                  perform type-based specializa"
"tion of primitive calls\012    -emit-inline-file FILENAME   generate file with glob"
"ally inlinable\012                                  procedures (implies -inline -lo"
"cal)\012    -consult-inline-file FILENAME  explicitly load inline file\012    -no-argc"
"-checks              disable argument count checks\012    -no-bound-checks         "
"    disable bound variable checks\012    -no-procedure-checks         disable proce"
"dure call checks\012    -no-procedure-checks-for-usual-bindings\012                   "
"                disable procedure call checks only for usual\012                   "
"                bindings\012    -no-procedure-checks-for-toplevel-bindings\012        "
"                           disable procedure call checks for toplevel\012          "
"                         bindings\012    -strict-types                assume variab"
"le do not change their type\012    -clustering                  combine groups of l"
"ocal procedures into dispatch\012                                   loop\012    -lfa2 "
"                       perform additional lightweight flow-analysis pass\012\012  Conf"
"iguration options:\012\012    -unit NAME                   compile file as a library u"
"nit\012    -uses NAME                   declare library unit as used.\012    -heap-siz"
"e NUMBER            specifies heap-size of compiled executable\012    -nursery NUMB"
"ER  -stack-size NUMBER\012                                 specifies nursery size o"
"f compiled executable\012    -extend FILENAME             load file before compilat"
"ion commences\012    -prelude EXPRESSION          add expression to front of source"
" file\012    -postlude EXPRESSION         add expression to end of source file\012    "
"-prologue FILENAME           include file before main source file\012    -epilogue "
"FILENAME           include file after main source file\012    -dynamic             "
"        compile as dynamically loadable code\012    -require-extension NAME      re"
"quire and import extension NAME\012\012  Obscure options:\012\012    -debug MODES           "
"      display debugging output for the given modes\012    -raw                     "
"    do not generate implicit init- and exit code                           \012    "
"-emit-external-prototypes-first\012                                 emit prototypes"
" for callbacks before foreign\012                                  declarations\012   "
" -ignore-repository           do not refer to repository for extensions\012    -set"
"up-mode                  prefer the current directory when locating extensions\012");
lf[562]=C_h_intern(&lf[562],28,"\010compilerprint-debug-options");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\007\026\012Available debugging options:\012\012     a          show node-matching during si"
"mplification\012     b          show breakdown of time needed for each compiler pas"
"s\012     c          print every expression before macro-expansion\012     d          "
"lists all assigned global variables\012     e          show information about speci"
"alizations\012     h          you already figured that out\012     i          show inf"
"ormation about inlining\012     m          show GC statistics during compilation\012  "
"   n          print the line-number database \012     o          show performed opt"
"imizations\012     p          display information about what the compiler is curren"
"tly doing\012     r          show invocation parameters\012     s          show progra"
"m-size information and other statistics\012     t          show time needed for com"
"pilation\012     u          lists all unassigned global variable references\012     x "
"         display information about experimental features\012     D          when pr"
"inting nodes, use node-tree output\012     I          show inferred type informatio"
"n for unexported globals\012     M          show syntax-/runtime-requirements\012     "
"N          show the real-name mapping table\012     P          show expressions aft"
"er specialization\012     S          show applications of compiler syntax\012     T   "
"       show expressions after converting to node tree\012     1          show sourc"
"e expressions\012     2          show canonicalized expressions\012     3          sho"
"w expressions converted into CPS\012     4          show database after each analys"
"is pass\012     5          show expressions after each optimization pass\012     6    "
"      show expressions after each inlining pass\012     7          show expressions"
" after complete optimization\012     8          show database after final analysis\012"
"     9          show expressions after closure conversion\012\012");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000\007#<node ");
lf[565]=C_h_intern(&lf[565],27,"\003sysregister-record-printer");
lf[566]=C_h_intern(&lf[566],27,"condition-property-accessor");
lf[567]=C_h_intern(&lf[567],19,"condition-predicate");
C_register_lf2(lf,568,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4823,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* ##compiler#expand-profile-lambda in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6268(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_6268,5,av);}
a=C_alloc(7);
t5=*((C_word*)lf[129]+1);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6272,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm:335: gensym */
t7=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* map-loop3666 in k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_15518(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_15518,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,2,lf[97],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k15514 in k15366 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15516(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_15516,2,av);}
a=C_alloc(14);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=C_slot(((C_word*)t0)[2],C_fix(0));
t5=t4;
if(C_truep(C_i_closurep(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15383,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15448,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1494: call-with-current-continuation */
t8=*((C_word*)lf[123]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
/* support.scm:1508: bomb */
t6=*((C_word*)lf[3]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[523];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}

/* loop in llist-match? in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static C_word C_fcall f_6230(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_overflow_check;
loop:{}
if(C_truep(C_i_nullp(t1))){
return(C_i_nullp(t2));}
else{
t3=C_i_symbolp(t1);
if(C_truep(t3)){
return(t3);}
else{
if(C_truep(C_i_nullp(t2))){
return(C_i_not_pair_p(t1));}
else{
t4=C_i_cdr(t1);
t5=C_i_cdr(t2);
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}}}

/* k6883 in k6868 in k6865 in k6862 in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6885(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6885,2,av);}
t2=C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm:496: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* ##compiler#build-lambda-list in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5479(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_5479,5,av);}
a=C_alloc(6);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5485,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5485(t8,t1,t2,t3);}

/* k5475 in uncommentify in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5477(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5477,2,av);}
/* support.scm:174: string-translate* */
t2=*((C_word*)lf[58]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[62];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k8449 in map-loop1324 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8451(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8451,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8426(t6,((C_word*)t0)[5],t5);}

/* k10397 in k10394 in copy-node! in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10399(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_10399,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(3));
/* support.scm:766: node-subexpressions-set! */
t5=*((C_word*)lf[219]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k10394 in copy-node! in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10396(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_10396,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(2));
/* support.scm:765: node-parameters-set! */
t5=*((C_word*)lf[217]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* ##compiler#copy-node! in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10392(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_10392,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10396,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=C_slot(t5,C_fix(1));
/* support.scm:764: node-class-set! */
t7=*((C_word*)lf[214]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t4;
av2[2]=t3;
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k6865 in k6862 in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6867(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_6867,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[4])[1]))){
t3=*((C_word*)lf[16]+1);
t4=*((C_word*)lf[16]+1);
t5=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6901,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:495: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[165];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6870(2,av2);}}}

/* k6862 in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6864(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_6864,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6911,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t4=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[169]);
t5=t3;
f_6911(t5,C_i_not(t4));}
else{
t4=t3;
f_6911(t4,C_SCHEME_FALSE);}}

/* k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6861(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_6861,2,av);}
a=C_alloc(18);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7039,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_7039(t6,t2,((C_word*)t0)[8]);}

/* rec in tree-copy in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_10368(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_10368,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10382,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* support.scm:760: rec */
t7=t3;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* ##compiler#tree-copy in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10362(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_10362,3,av);}
a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10368,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10368(t6,t1,t2);}

/* k5181 in k5178 in k5175 in k5172 in k5169 in k5120 in syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5183(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5183,2,av);}
/* support.scm:119: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5178 in k5175 in k5172 in k5169 in k5120 in syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5180(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_5180,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:119: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6270 in expand-profile-lambda in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6272(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(106,c,1))){C_save_and_reclaim((void *)f_6272,2,av);}
a=C_alloc(106);
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]),*((C_word*)lf[130]+1));
t3=C_mutate2((C_word*)lf[130]+1 /* (set! ##compiler#profile-lambda-list ...) */,t2);
t4=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t5=C_mutate2((C_word*)lf[129]+1 /* (set! ##compiler#profile-lambda-index ...) */,t4);
t6=C_a_i_list(&a,2,lf[97],((C_word*)t0)[2]);
t7=C_a_i_list(&a,3,lf[131],t6,*((C_word*)lf[132]+1));
t8=C_a_i_list(&a,3,lf[133],C_SCHEME_END_OF_LIST,t7);
t9=C_a_i_list(&a,3,lf[133],((C_word*)t0)[4],((C_word*)t0)[5]);
t10=C_a_i_list(&a,3,lf[134],t9,t1);
t11=C_a_i_list(&a,3,lf[133],C_SCHEME_END_OF_LIST,t10);
t12=C_a_i_list(&a,2,lf[97],((C_word*)t0)[2]);
t13=C_a_i_list(&a,3,lf[135],t12,*((C_word*)lf[132]+1));
t14=C_a_i_list(&a,3,lf[133],C_SCHEME_END_OF_LIST,t13);
t15=C_a_i_list(&a,4,lf[136],t8,t11,t14);
t16=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t16;
av2[1]=C_a_i_list(&a,3,lf[133],t1,t15);
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}

/* map-loop3635 in constant-form-eval in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_15552(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_15552,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(2));
t5=C_i_car(t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t6);
t9=C_slot(t2,C_fix(1));
t11=t1;
t12=t9;
t1=t11;
t2=t12;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* loop in build-lambda-list in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5485(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_5485,4,t0,t1,t2,t3);}
a=C_alloc(8);
t4=C_i_zerop(t3);
t5=(C_truep(t4)?t4:C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[2];
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=(C_truep(t6)?t6:C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t6=C_i_car(t2);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5509,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=t2;
t10=C_u_i_cdr(t9);
t11=C_a_i_minus(&a,2,t3,C_fix(1));
/* support.scm:179: loop */
t13=t8;
t14=t10;
t15=t11;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}

/* k6871 in k6868 in k6865 in k6862 in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6873(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6873,2,av);}
/* support.scm:497: newline */
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6868 in k6865 in k6862 in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_6870,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6873,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t3=*((C_word*)lf[16]+1);
t4=*((C_word*)lf[16]+1);
t5=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6885,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:496: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[164];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
/* support.scm:497: newline */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* ##compiler#encodeable-literal? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_15586,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15600,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1518: immediate? */
t4=*((C_word*)lf[101]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* ##compiler#simple-lambda-node? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11232(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_11232,3,av);}
a=C_alloc(6);
t3=t2;
t4=C_slot(t3,C_fix(2));
t5=C_i_caddr(t4);
t6=C_i_pairp(t5);
t7=(C_truep(t6)?C_u_i_car(t5):C_SCHEME_FALSE);
t8=t7;
if(C_truep(t8)){
t9=C_u_i_cdr(t4);
if(C_truep(C_u_i_car(t9))){
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11260,a[2]=t8,a[3]=t11,tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t13;
av2[1]=t1;
av2[2]=t2;
f_11260(3,av2);}}
else{
t10=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t10;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}}
else{
t9=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}

/* k5190 in k5120 in syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5192(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_5192,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:120: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5193 in k5190 in k5120 in syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5195(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_5195,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:120: ##sys#write-char-0 */
t3=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5196 in k5193 in k5190 in k5120 in syntax-error-hook in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5198(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5198,2,av);}
/* support.scm:120: ##sys#write-char-0 */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6216 in a6157 in a6126 in string->expr in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6218,2,av);}
a=C_alloc(3);
/* tmp24364 */
t2=((C_word*)t0)[2];
f_6201(t2,((C_word*)t0)[3],C_a_i_list(&a,1,t1));}

/* k8485 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8487(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_8487,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],lf[253],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1355 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_8489(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8489,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8514,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:602: g1361 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* ##compiler#llist-match? in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6224(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(2,c,3))){C_save_and_reclaim((void *)f_6224,4,av);}
a=C_alloc(2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6230,tmp=(C_word)a,a+=2,tmp);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=f_6230(t2,t3);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* ##compiler#llist-length in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6221(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6221,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_u_i_length(t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8422 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_8424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,1))){C_save_and_reclaim((void *)f_8424,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_record4(&a,4,lf[211],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop1324 in k8396 in walk in build-node-graph in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_8426(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8426,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8451,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:600: g1330 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_6846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,4))){
C_save_and_reclaim_args((void *)trf_6846,2,t0,t1);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6851,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:455: ##sys#hash-table-for-each */
t3=*((C_word*)lf[162]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* ##compiler#display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6842(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_6842,3,av);}
a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6846,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_6846(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7428,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:452: append */
t5=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[208]+1);
av2[3]=*((C_word*)lf[209]+1);
av2[4]=*((C_word*)lf[140]+1);
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}

/* ##compiler#intrinsic? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_16085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_16085,3,av);}
/* tweaks.scm:57: ##sys#get */
t3=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=t2;
av2[3]=lf[143];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,2))){C_save_and_reclaim((void *)f_6851,4,av);}
a=C_alloc(19);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=C_SCHEME_UNDEFINED;
t15=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t15;
av2[1]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(2,av2);}}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6861,a[2]=t1,a[3]=t11,a[4]=t13,a[5]=t5,a[6]=t7,a[7]=t9,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* support.scm:463: write */
t15=*((C_word*)lf[207]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t15;
av2[1]=t14;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t15+1)))(3,av2);}}}

/* rec in simple-lambda-node? in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_11260(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_11260,3,av);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(t4,lf[253]);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(3));
t8=C_i_car(t7);
t9=C_slot(t8,C_fix(1));
t10=C_eqp(lf[221],t9);
if(C_truep(t10)){
t11=C_slot(t8,C_fix(2));
t12=C_i_car(t11);
t13=C_eqp(((C_word*)t0)[2],t12);
if(C_truep(t13)){
t14=C_u_i_cdr(t7);
/* support.scm:896: every */
t15=*((C_word*)lf[104]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t15;
av2[1]=t1;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}
else{
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}}
else{
t11=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}}
else{
t6=C_eqp(t4,lf[243]);
if(C_truep(t6)){
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=t2;
t8=C_slot(t7,C_fix(3));
/* support.scm:898: every */
t9=*((C_word*)lf[104]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t1;
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}}}

/* k10384 in k10380 in rec in tree-copy in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10386(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_10386,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k10380 in rec in tree-copy in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_10382(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_10382,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10386,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:760: rec */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10368(t6,t3,t5);}

/* node-subexpressions in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7478(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_7478,3,av);}
t3=C_i_check_structure_2(t2,lf[211],lf[218]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_i_block_ref(t2,C_fix(3));
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6899 in k6865 in k6862 in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6901(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6901,2,av);}
t2=C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm:495: ##sys#print */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* node-subexpressions-set! in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_7487(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_7487,4,av);}
t4=C_i_check_structure_2(t2,lf[211],C_SCHEME_FALSE);
/* support.scm:505: ##sys#block-set! */
t5=*((C_word*)lf[215]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=C_fix(3);
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k5705 in k5693 in check-and-open-input-file in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5707(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_5707,2,t0,t1);}
if(C_truep(t1)){
/* support.scm:223: quit */
t2=*((C_word*)lf[29]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[84];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=C_i_car(((C_word*)t0)[4]);
/* support.scm:224: quit */
t3=*((C_word*)lf[29]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[85];
av2[3]=t2;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k6909 in k6862 in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_6911(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_6911,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:490: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[166];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6948,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[169]);
t4=t2;
f_6948(t4,C_i_not(t3));}
else{
t3=t2;
f_6948(t3,C_SCHEME_FALSE);}}}

/* k6915 in k6909 in k6862 in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_6917(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_6917,2,av);}
a=C_alloc(3);
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
t5=C_slot(t4,C_fix(2));
t6=C_a_i_cons(&a,2,t3,t5);
/* support.scm:490: ##sys#print */
t7=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[3];
av2[2]=t6;
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k12894 in k12885 in a12876 in estimate-foreign-result-size in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_12896(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_12896,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
/* support.scm:1183: words->bytes */
t2=*((C_word*)lf[79]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(3);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=C_eqp(((C_word*)t0)[3],lf[373]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_12908(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[407]);
if(C_truep(t4)){
t5=t3;
f_12908(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[369]);
if(C_truep(t5)){
t6=t3;
f_12908(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[408]);
if(C_truep(t6)){
t7=t3;
f_12908(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[406]);
if(C_truep(t7)){
t8=t3;
f_12908(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[3],lf[409]);
t9=t3;
f_12908(t9,(C_truep(t8)?t8:C_eqp(((C_word*)t0)[3],lf[405])));}}}}}}}

/* k9924 in walk in k9865 in copy-node-tree-and-rename in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_9926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_9926,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9933,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
/* support.scm:712: alist-ref */
t4=*((C_word*)lf[287]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=t3;
av2[4]=*((C_word*)lf[13]+1);
av2[5]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}

/* fold in k5750 in fold-inner in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5754(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_5754,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_i_cddr(t2);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=C_u_i_cdr(t4);
t6=C_u_i_car(t5);
t7=t2;
t8=C_u_i_car(t7);
t9=C_a_i_list2(&a,2,t6,t8);{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=t9;
C_apply(4,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5780,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=C_u_i_cdr(t5);
/* support.scm:237: fold */
t11=t4;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}

/* k5750 in fold-inner in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5752(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5752,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5754,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5754(t5,((C_word*)t0)[3],t1);}

/* k14105 in k14030 in k14006 in foreign-type->scrutiny-type in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_14107(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,2))){
C_save_and_reclaim_args((void *)trf_14107,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_eqp(t2,lf[461]);
if(C_truep(t3)){
t4=C_a_i_list(&a,2,lf[464],((C_word*)t0)[3]);
t5=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_a_i_list(&a,3,lf[465],lf[466],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,lf[464],((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[367]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t3;
av2[1]=lf[467];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(((C_word*)t0)[5],lf[411]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[468];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_eqp(((C_word*)t0)[5],lf[410]);
if(C_truep(t4)){
t5=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t5;
av2[1]=lf[469];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=C_eqp(((C_word*)t0)[5],lf[412]);
if(C_truep(t5)){
t6=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t6;
av2[1]=lf[470];
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_eqp(((C_word*)t0)[5],lf[413]);
if(C_truep(t6)){
t7=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t7;
av2[1]=lf[471];
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=C_eqp(((C_word*)t0)[5],lf[414]);
if(C_truep(t7)){
t8=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t8;
av2[1]=lf[472];
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t8=C_eqp(((C_word*)t0)[5],lf[415]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t9;
av2[1]=lf[473];
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t9=C_eqp(((C_word*)t0)[5],lf[416]);
if(C_truep(t9)){
t10=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t10;
av2[1]=lf[474];
((C_proc)(void*)(*((C_word*)t10+1)))(2,av2);}}
else{
t10=C_eqp(((C_word*)t0)[5],lf[369]);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14182,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t10)){
t12=t11;
f_14182(t12,t10);}
else{
t12=C_eqp(((C_word*)t0)[5],lf[407]);
if(C_truep(t12)){
t13=t11;
f_14182(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[5],lf[408]);
if(C_truep(t13)){
t14=t11;
f_14182(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[5],lf[409]);
if(C_truep(t14)){
t15=t11;
f_14182(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[5],lf[405]);
if(C_truep(t15)){
t16=t11;
f_14182(t16,t15);}
else{
t16=C_eqp(((C_word*)t0)[5],lf[371]);
if(C_truep(t16)){
t17=t11;
f_14182(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[5],lf[375]);
t18=t11;
f_14182(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[5],lf[406])));}}}}}}}}}}}}}}}}

/* ##compiler#fold-inner in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5738(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5738,4,av);}
a=C_alloc(4);
t4=C_i_cdr(t3);
if(C_truep(C_i_nullp(t4))){
t5=t3;
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5752,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:232: reverse */
t6=*((C_word*)lf[91]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* k5249 in k5245 in loop in map-llist in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5251(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_5251,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in k15143 in k15212 in k15116 in real-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_15147(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_15147,5,t0,t1,t2,t3,t4);}
a=C_alloc(8);
if(C_truep(C_i_greaterp(t3,*((C_word*)lf[497]+1)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15161,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_a_i_cons(&a,2,lf[500],t2);
/* support.scm:1444: reverse */
t7=*((C_word*)lf[91]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15171,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* support.scm:1446: resolve */
f_15102(t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15210,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1452: reverse */
t6=*((C_word*)lf[91]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}}

/* k15143 in k15212 in k15116 in real-name in k7495 in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_15145(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,5))){C_save_and_reclaim((void *)f_15145,2,av);}
a=C_alloc(7);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15147,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_15147(t5,((C_word*)t0)[4],((C_word*)t0)[5],C_fix(0),t1);}

/* err in check-signature in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_5262(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_5262,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5270,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:139: real-name */
t3=*((C_word*)lf[47]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6983 in k6946 in k6909 in k6862 in k6859 in a6850 in k6844 in display-analysis-database in k6115 in k6112 in k4861 in k4827 in k4824 in k4821 */
static void C_fcall f_6985(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_6985,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=*((C_word*)lf[16]+1);
t3=*((C_word*)lf[16]+1);
t4=C_i_check_port_2(*((C_word*)lf[16]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[17]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:494: ##sys#print */
t6=*((C_word*)lf[19]+1);{
C_word av2[5];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[168];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[16]+1);
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_6867(2,av2);}}}

/* ##compiler#follow-without-loop in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5794(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_5794,5,av);}
a=C_alloc(7);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5800,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5800(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* ##compiler#check-signature in k4861 in k4827 in k4824 in k4821 */
static void C_ccall f_5259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_5259,5,av);}
a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5262,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5283,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5283(t9,t1,t3,t4);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[760] = {
{"f_6991:support_2escm",(void*)f_6991},
{"f_5780:support_2escm",(void*)f_5780},
{"f_7499:support_2escm",(void*)f_7499},
{"f_7497:support_2escm",(void*)f_7497},
{"f_14574:support_2escm",(void*)f_14574},
{"f_14576:support_2escm",(void*)f_14576},
{"f_14570:support_2escm",(void*)f_14570},
{"f_12826:support_2escm",(void*)f_12826},
{"f_15118:support_2escm",(void*)f_15118},
{"f_15112:support_2escm",(void*)f_15112},
{"f_15184:support_2escm",(void*)f_15184},
{"f_6948:support_2escm",(void*)f_6948},
{"f_12840:support_2escm",(void*)f_12840},
{"f_8607:support_2escm",(void*)f_8607},
{"f_8600:support_2escm",(void*)f_8600},
{"f_15171:support_2escm",(void*)f_15171},
{"f_6954:support_2escm",(void*)f_6954},
{"f_12832:support_2escm",(void*)f_12832},
{"f_12836:support_2escm",(void*)f_12836},
{"f_7899:support_2escm",(void*)f_7899},
{"f_5247:support_2escm",(void*)f_5247},
{"f_12865:support_2escm",(void*)f_12865},
{"f_7865:support_2escm",(void*)f_7865},
{"f_8317:support_2escm",(void*)f_8317},
{"f_5726:support_2escm",(void*)f_5726},
{"f_7535:support_2escm",(void*)f_7535},
{"f_7538:support_2escm",(void*)f_7538},
{"f_12887:support_2escm",(void*)f_12887},
{"f_12311:support_2escm",(void*)f_12311},
{"f_10231:support_2escm",(void*)f_10231},
{"f_12871:support_2escm",(void*)f_12871},
{"f_9424:support_2escm",(void*)f_9424},
{"f_12877:support_2escm",(void*)f_12877},
{"f_4833:support_2escm",(void*)f_4833},
{"f_9437:support_2escm",(void*)f_9437},
{"f_9435:support_2escm",(void*)f_9435},
{"f_4838:support_2escm",(void*)f_4838},
{"f_8361:support_2escm",(void*)f_8361},
{"f_8357:support_2escm",(void*)f_8357},
{"f_7605:support_2escm",(void*)f_7605},
{"f_7607:support_2escm",(void*)f_7607},
{"f_15102:support_2escm",(void*)f_15102},
{"f_15106:support_2escm",(void*)f_15106},
{"f_5224:support_2escm",(void*)f_5224},
{"f_5218:support_2escm",(void*)f_5218},
{"f_5215:support_2escm",(void*)f_5215},
{"f_14868:support_2escm",(void*)f_14868},
{"f_8398:support_2escm",(void*)f_8398},
{"f_9406:support_2escm",(void*)f_9406},
{"f_10265:support_2escm",(void*)f_10265},
{"f_10267:support_2escm",(void*)f_10267},
{"f_9417:support_2escm",(void*)f_9417},
{"f_16096:support_2escm",(void*)f_16096},
{"f_4894:support_2escm",(void*)f_4894},
{"f_14856:support_2escm",(void*)f_14856},
{"f_4898:support_2escm",(void*)f_4898},
{"f_11400:support_2escm",(void*)f_11400},
{"f_11407:support_2escm",(void*)f_11407},
{"f_4863:support_2escm",(void*)f_4863},
{"f_14826:support_2escm",(void*)f_14826},
{"f_4866:support_2escm",(void*)f_4866},
{"f_14837:support_2escm",(void*)f_14837},
{"f_5582:support_2escm",(void*)f_5582},
{"f_10292:support_2escm",(void*)f_10292},
{"f_4885:support_2escm",(void*)f_4885},
{"f_4883:support_2escm",(void*)f_4883},
{"f_4888:support_2escm",(void*)f_4888},
{"f_5576:support_2escm",(void*)f_5576},
{"f_5572:support_2escm",(void*)f_5572},
{"f_4852:support_2escm",(void*)f_4852},
{"f_14817:support_2escm",(void*)f_14817},
{"f_15743:support_2escm",(void*)f_15743},
{"f_9365:support_2escm",(void*)f_9365},
{"f_15844:support_2escm",(void*)f_15844},
{"f_15848:support_2escm",(void*)f_15848},
{"f_15755:support_2escm",(void*)f_15755},
{"f_15758:support_2escm",(void*)f_15758},
{"f_4823:support_2escm",(void*)f_4823},
{"f_9379:support_2escm",(void*)f_9379},
{"f_4829:support_2escm",(void*)f_4829},
{"f_4826:support_2escm",(void*)f_4826},
{"f_5815:support_2escm",(void*)f_5815},
{"f_8621:support_2escm",(void*)f_8621},
{"f_11429:support_2escm",(void*)f_11429},
{"f_9383:support_2escm",(void*)f_9383},
{"f_10255:support_2escm",(void*)f_10255},
{"f_10250:support_2escm",(void*)f_10250},
{"f_5800:support_2escm",(void*)f_5800},
{"f_11478:support_2escm",(void*)f_11478},
{"f_9053:support_2escm",(void*)f_9053},
{"f_11480:support_2escm",(void*)f_11480},
{"f_11450:support_2escm",(void*)f_11450},
{"f_10943:support_2escm",(void*)f_10943},
{"f_11437:support_2escm",(void*)f_11437},
{"f_11431:support_2escm",(void*)f_11431},
{"f_5907:support_2escm",(void*)f_5907},
{"f_10712:support_2escm",(void*)f_10712},
{"f_5879:support_2escm",(void*)f_5879},
{"f_8377:support_2escm",(void*)f_8377},
{"f_5891:support_2escm",(void*)f_5891},
{"f_11410:support_2escm",(void*)f_11410},
{"f_10889:support_2escm",(void*)f_10889},
{"f_5839:support_2escm",(void*)f_5839},
{"f_5831:support_2escm",(void*)f_5831},
{"f_6711:support_2escm",(void*)f_6711},
{"f_6715:support_2escm",(void*)f_6715},
{"f_5825:support_2escm",(void*)f_5825},
{"f_7520:support_2escm",(void*)f_7520},
{"f_10705:support_2escm",(void*)f_10705},
{"f_10703:support_2escm",(void*)f_10703},
{"f_10773:support_2escm",(void*)f_10773},
{"f_6164:support_2escm",(void*)f_6164},
{"f_10770:support_2escm",(void*)f_10770},
{"f_6160:support_2escm",(void*)f_6160},
{"f_5843:support_2escm",(void*)f_5843},
{"f_5845:support_2escm",(void*)f_5845},
{"f_7829:support_2escm",(void*)f_7829},
{"f_7505:support_2escm",(void*)f_7505},
{"f_5981:support_2escm",(void*)f_5981},
{"f_6020:support_2escm",(void*)f_6020},
{"f_5983:support_2escm",(void*)f_5983},
{"f_15600:support_2escm",(void*)f_15600},
{"f_6100:support_2escm",(void*)f_6100},
{"f_7953:support_2escm",(void*)f_7953},
{"f_6037:support_2escm",(void*)f_6037},
{"f_6039:support_2escm",(void*)f_6039},
{"f_5937:support_2escm",(void*)f_5937},
{"f_10815:support_2escm",(void*)f_10815},
{"f_6720:support_2escm",(void*)f_6720},
{"f_6118:support_2escm",(void*)f_6118},
{"f_6117:support_2escm",(void*)f_6117},
{"f_6114:support_2escm",(void*)f_6114},
{"f_6005:support_2escm",(void*)f_6005},
{"f_11490:support_2escm",(void*)f_11490},
{"f_15669:support_2escm",(void*)f_15669},
{"f_6777:support_2escm",(void*)f_6777},
{"f_6771:support_2escm",(void*)f_6771},
{"f_15665:support_2escm",(void*)f_15665},
{"f_6127:support_2escm",(void*)f_6127},
{"f_6122:support_2escm",(void*)f_6122},
{"f_5999:support_2escm",(void*)f_5999},
{"f_7974:support_2escm",(void*)f_7974},
{"f_15657:support_2escm",(void*)f_15657},
{"f_6740:support_2escm",(void*)f_6740},
{"f_15659:support_2escm",(void*)f_15659},
{"f_6744:support_2escm",(void*)f_6744},
{"f_6139:support_2escm",(void*)f_6139},
{"f_6133:support_2escm",(void*)f_6133},
{"f_10850:support_2escm",(void*)f_10850},
{"f_6069:support_2escm",(void*)f_6069},
{"f_10866:support_2escm",(void*)f_10866},
{"f_6793:support_2escm",(void*)f_6793},
{"f_6790:support_2escm",(void*)f_6790},
{"f_7996:support_2escm",(void*)f_7996},
{"f_10856:support_2escm",(void*)f_10856},
{"f_10789:support_2escm",(void*)f_10789},
{"f_6045:support_2escm",(void*)f_6045},
{"f_10848:support_2escm",(void*)f_10848},
{"f_6787:support_2escm",(void*)f_6787},
{"f_11392:support_2escm",(void*)f_11392},
{"f_11394:support_2escm",(void*)f_11394},
{"f_6186:support_2escm",(void*)f_6186},
{"f_15674:support_2escm",(void*)f_15674},
{"f_6192:support_2escm",(void*)f_6192},
{"f_6085:support_2escm",(void*)f_6085},
{"f_7451:support_2escm",(void*)f_7451},
{"f_6095:support_2escm",(void*)f_6095},
{"f_11359:support_2escm",(void*)f_11359},
{"f_11353:support_2escm",(void*)f_11353},
{"f_10402:support_2escm",(void*)f_10402},
{"f_5941:support_2escm",(void*)f_5941},
{"f_6147:support_2escm",(void*)f_6147},
{"f_13315:support_2escm",(void*)f_13315},
{"f_7428:support_2escm",(void*)f_7428},
{"f_6158:support_2escm",(void*)f_6158},
{"f_6150:support_2escm",(void*)f_6150},
{"f_6737:support_2escm",(void*)f_6737},
{"f_6730:support_2escm",(void*)f_6730},
{"f_7442:support_2escm",(void*)f_7442},
{"f_14243:support_2escm",(void*)f_14243},
{"f_7436:support_2escm",(void*)f_7436},
{"f_7430:support_2escm",(void*)f_7430},
{"f_7469:support_2escm",(void*)f_7469},
{"f_7460:support_2escm",(void*)f_7460},
{"f_14221:support_2escm",(void*)f_14221},
{"f_15383:support_2escm",(void*)f_15383},
{"f_15494:support_2escm",(void*)f_15494},
{"f_15386:support_2escm",(void*)f_15386},
{"f_11369:support_2escm",(void*)f_11369},
{"f_11366:support_2escm",(void*)f_11366},
{"f_15488:support_2escm",(void*)f_15488},
{"f_4972:support_2escm",(void*)f_4972},
{"f_15482:support_2escm",(void*)f_15482},
{"f_15476:support_2escm",(void*)f_15476},
{"f_6562:support_2escm",(void*)f_6562},
{"f_15470:support_2escm",(void*)f_15470},
{"f_4978:support_2escm",(void*)f_4978},
{"f_4975:support_2escm",(void*)f_4975},
{"f_14004:support_2escm",(void*)f_14004},
{"f_14008:support_2escm",(void*)f_14008},
{"f_4930:support_2escm",(void*)f_4930},
{"f_6526:support_2escm",(void*)f_6526},
{"f_6522:support_2escm",(void*)f_6522},
{"f_8983:support_2escm",(void*)f_8983},
{"f_4981:support_2escm",(void*)f_4981},
{"f_4984:support_2escm",(void*)f_4984},
{"f_8999:support_2escm",(void*)f_8999},
{"f_8995:support_2escm",(void*)f_8995},
{"f_4993:support_2escm",(void*)f_4993},
{"f_8986:support_2escm",(void*)f_8986},
{"f_4987:support_2escm",(void*)f_4987},
{"f_15247:support_2escm",(void*)f_15247},
{"f_15244:support_2escm",(void*)f_15244},
{"f_6540:support_2escm",(void*)f_6540},
{"f_6544:support_2escm",(void*)f_6544},
{"f_4963:support_2escm",(void*)f_4963},
{"f_4960:support_2escm",(void*)f_4960},
{"f_4996:support_2escm",(void*)f_4996},
{"f_15237:support_2escm",(void*)f_15237},
{"f_6558:support_2escm",(void*)f_6558},
{"f_11004:support_2escm",(void*)f_11004},
{"f_7930:support_2escm",(void*)f_7930},
{"f_6552:support_2escm",(void*)f_6552},
{"f_15231:support_2escm",(void*)f_15231},
{"f_15223:support_2escm",(void*)f_15223},
{"f_12237:support_2escm",(void*)f_12237},
{"f_15219:support_2escm",(void*)f_15219},
{"f_15717:support_2escm",(void*)f_15717},
{"f_15214:support_2escm",(void*)f_15214},
{"f_15711:support_2escm",(void*)f_15711},
{"f_15714:support_2escm",(void*)f_15714},
{"f_15210:support_2escm",(void*)f_15210},
{"f_15702:support_2escm",(void*)f_15702},
{"f_15289:support_2escm",(void*)f_15289},
{"f_15275:support_2escm",(void*)f_15275},
{"f_15279:support_2escm",(void*)f_15279},
{"f_8910:support_2escm",(void*)f_8910},
{"f_6426:support_2escm",(void*)f_6426},
{"f_12240:support_2escm",(void*)f_12240},
{"f_4901:support_2escm",(void*)f_4901},
{"f_9522:support_2escm",(void*)f_9522},
{"f_4910:support_2escm",(void*)f_4910},
{"f_9536:support_2escm",(void*)f_9536},
{"f_9548:support_2escm",(void*)f_9548},
{"f_15723:support_2escm",(void*)f_15723},
{"f_15720:support_2escm",(void*)f_15720},
{"f_9546:support_2escm",(void*)f_9546},
{"f_6453:support_2escm",(void*)f_6453},
{"f_15737:support_2escm",(void*)f_15737},
{"f_10143:support_2escm",(void*)f_10143},
{"f_4918:support_2escm",(void*)f_4918},
{"f_12204:support_2escm",(void*)f_12204},
{"f_12200:support_2escm",(void*)f_12200},
{"f_5283:support_2escm",(void*)f_5283},
{"f_6463:support_2escm",(void*)f_6463},
{"f_15727:support_2escm",(void*)f_15727},
{"f_15726:support_2escm",(void*)f_15726},
{"f_15782:support_2escm",(void*)f_15782},
{"f_5274:support_2escm",(void*)f_5274},
{"f_5270:support_2escm",(void*)f_5270},
{"f_10127:support_2escm",(void*)f_10127},
{"f_15799:support_2escm",(void*)f_15799},
{"f_11891:support_2escm",(void*)f_11891},
{"f_10135:support_2escm",(void*)f_10135},
{"f_14982:support_2escm",(void*)f_14982},
{"f_14690:support_2escm",(void*)f_14690},
{"f_15203:support_2escm",(void*)f_15203},
{"f_13297:support_2escm",(void*)f_13297},
{"f_15761:support_2escm",(void*)f_15761},
{"f_6499:support_2escm",(void*)f_6499},
{"f_15779:support_2escm",(void*)f_15779},
{"f_14991:support_2escm",(void*)f_14991},
{"f_15766:support_2escm",(void*)f_15766},
{"f_14965:support_2escm",(void*)f_14965},
{"f_11841:support_2escm",(void*)f_11841},
{"f_6476:support_2escm",(void*)f_6476},
{"f_12275:support_2escm",(void*)f_12275},
{"f_8290:support_2escm",(void*)f_8290},
{"f_8292:support_2escm",(void*)f_8292},
{"f_11823:support_2escm",(void*)f_11823},
{"f_14955:support_2escm",(void*)f_14955},
{"f_14950:support_2escm",(void*)f_14950},
{"f_10156:support_2escm",(void*)f_10156},
{"f_14926:support_2escm",(void*)f_14926},
{"f_10158:support_2escm",(void*)f_10158},
{"f_11808:support_2escm",(void*)f_11808},
{"f_4940:support_2escm",(void*)f_4940},
{"f_14626:support_2escm",(void*)f_14626},
{"f_14936:support_2escm",(void*)f_14936},
{"f_13884:support_2escm",(void*)f_13884},
{"f_4953:support_2escm",(void*)f_4953},
{"f_14616:support_2escm",(void*)f_14616},
{"f_6509:support_2escm",(void*)f_6509},
{"f_4925:support_2escm",(void*)f_4925},
{"f_14914:support_2escm",(void*)f_14914},
{"f_14680:support_2escm",(void*)f_14680},
{"f_8206:support_2escm",(void*)f_8206},
{"f_14182:support_2escm",(void*)f_14182},
{"f_14912:support_2escm",(void*)f_14912},
{"f_14672:support_2escm",(void*)f_14672},
{"f_10116:support_2escm",(void*)f_10116},
{"f_16234:support_2escm",(void*)f_16234},
{"f_16230:support_2escm",(void*)f_16230},
{"f_16237:support_2escm",(void*)f_16237},
{"f_12115:support_2escm",(void*)f_12115},
{"f_12112:support_2escm",(void*)f_12112},
{"f_16242:support_2escm",(void*)f_16242},
{"f_16248:support_2escm",(void*)f_16248},
{"f_6486:support_2escm",(void*)f_6486},
{"f_9497:support_2escm",(void*)f_9497},
{"f_13856:support_2escm",(void*)f_13856},
{"f_16212:support_2escm",(void*)f_16212},
{"f_9495:support_2escm",(void*)f_9495},
{"f_9168:support_2escm",(void*)f_9168},
{"f_16219:support_2escm",(void*)f_16219},
{"f_9164:support_2escm",(void*)f_9164},
{"f_9176:support_2escm",(void*)f_9176},
{"f_9462:support_2escm",(void*)f_9462},
{"f_13337:support_2escm",(void*)f_13337},
{"f_15092:support_2escm",(void*)f_15092},
{"f_5602:support_2escm",(void*)f_5602},
{"f_15099:support_2escm",(void*)f_15099},
{"f_5618:support_2escm",(void*)f_5618},
{"f_13347:support_2escm",(void*)f_13347},
{"f_15314:support_2escm",(void*)f_15314},
{"f_5075:support_2escm",(void*)f_5075},
{"f_5078:support_2escm",(void*)f_5078},
{"f_5072:support_2escm",(void*)f_5072},
{"f_13343:support_2escm",(void*)f_13343},
{"f_14640:support_2escm",(void*)f_14640},
{"f_5367:support_2escm",(void*)f_5367},
{"f_5361:support_2escm",(void*)f_5361},
{"f_15307:support_2escm",(void*)f_15307},
{"f_5069:support_2escm",(void*)f_5069},
{"f_5017:support_2escm",(void*)f_5017},
{"f_13325:support_2escm",(void*)f_13325},
{"f_5010:support_2escm",(void*)f_5010},
{"f_8119:support_2escm",(void*)f_8119},
{"f_16205:support_2escm",(void*)f_16205},
{"f_16203:support_2escm",(void*)f_16203},
{"f_15368:support_2escm",(void*)f_15368},
{"f_5643:support_2escm",(void*)f_5643},
{"f_5005:support_2escm",(void*)f_5005},
{"f_5003:support_2escm",(void*)f_5003},
{"f_5008:support_2escm",(void*)f_5008},
{"f_6608:support_2escm",(void*)f_6608},
{"f_6604:support_2escm",(void*)f_6604},
{"f_5333:support_2escm",(void*)f_5333},
{"f_5675:support_2escm",(void*)f_5675},
{"f_5037:support_2escm",(void*)f_5037},
{"f_13380:support_2escm",(void*)f_13380},
{"f_6656:support_2escm",(void*)f_6656},
{"f_15344:support_2escm",(void*)f_15344},
{"f_5666:support_2escm",(void*)f_5666},
{"f_5668:support_2escm",(void*)f_5668},
{"f_5023:support_2escm",(void*)f_5023},
{"f_5020:support_2escm",(void*)f_5020},
{"f_6663:support_2escm",(void*)f_6663},
{"f_6660:support_2escm",(void*)f_6660},
{"f_12930:support_2escm",(void*)f_12930},
{"f_5695:support_2escm",(void*)f_5695},
{"f_12920:support_2escm",(void*)f_12920},
{"f_12926:support_2escm",(void*)f_12926},
{"f_5682:support_2escm",(void*)f_5682},
{"f_12908:support_2escm",(void*)f_12908},
{"f_10688:support_2escm",(void*)f_10688},
{"f_16255:support_2escm",(void*)f_16255},
{"f_13303:support_2escm",(void*)f_13303},
{"f_11129:support_2escm",(void*)f_11129},
{"f_16258:support_2escm",(void*)f_16258},
{"f_11123:support_2escm",(void*)f_11123},
{"f_10664:support_2escm",(void*)f_10664},
{"f_16261:support_2escm",(void*)f_16261},
{"f_16264:support_2escm",(void*)f_16264},
{"f_5327:support_2escm",(void*)f_5327},
{"f_10678:support_2escm",(void*)f_10678},
{"f_10673:support_2escm",(void*)f_10673},
{"f_11053:support_2escm",(void*)f_11053},
{"f_10670:support_2escm",(void*)f_10670},
{"f_5052:support_2escm",(void*)f_5052},
{"f_11022:support_2escm",(void*)f_11022},
{"f_11155:support_2escm",(void*)f_11155},
{"f_5042:support_2escm",(void*)f_5042},
{"f_16199:support_2escm",(void*)f_16199},
{"f_10655:support_2escm",(void*)f_10655},
{"f_10659:support_2escm",(void*)f_10659},
{"f_16196:support_2escm",(void*)f_16196},
{"f_7804:support_2escm",(void*)f_7804},
{"f_16193:support_2escm",(void*)f_16193},
{"f_16190:support_2escm",(void*)f_16190},
{"f_11169:support_2escm",(void*)f_11169},
{"f_10627:support_2escm",(void*)f_10627},
{"f_11177:support_2escm",(void*)f_11177},
{"f_5622:support_2escm",(void*)f_5622},
{"f_15028:support_2escm",(void*)f_15028},
{"f_12014:support_2escm",(void*)f_12014},
{"f_15022:support_2escm",(void*)f_15022},
{"f_9701:support_2escm",(void*)f_9701},
{"f_9707:support_2escm",(void*)f_9707},
{"f_9687:support_2escm",(void*)f_9687},
{"f_9683:support_2escm",(void*)f_9683},
{"f_9723:support_2escm",(void*)f_9723},
{"f_9130:support_2escm",(void*)f_9130},
{"f_15034:support_2escm",(void*)f_15034},
{"f_9726:support_2escm",(void*)f_9726},
{"f_15069:support_2escm",(void*)f_15069},
{"f_15066:support_2escm",(void*)f_15066},
{"f_15063:support_2escm",(void*)f_15063},
{"f_15060:support_2escm",(void*)f_15060},
{"f_16135:support_2escm",(void*)f_16135},
{"f_16139:support_2escm",(void*)f_16139},
{"f_15161:support_2escm",(void*)f_15161},
{"f_11669:support_2escm",(void*)f_11669},
{"f_11660:support_2escm",(void*)f_11660},
{"f_11663:support_2escm",(void*)f_11663},
{"f_5395:support_2escm",(void*)f_5395},
{"f_15043:support_2escm",(void*)f_15043},
{"f_16111:support_2escm",(void*)f_16111},
{"f_11672:support_2escm",(void*)f_11672},
{"f_11675:support_2escm",(void*)f_11675},
{"f_16117:support_2escm",(void*)f_16117},
{"f_8179:support_2escm",(void*)f_8179},
{"f_5467:support_2escm",(void*)f_5467},
{"f_15077:support_2escm",(void*)f_15077},
{"f_5469:support_2escm",(void*)f_5469},
{"f_15073:support_2escm",(void*)f_15073},
{"f_16123:support_2escm",(void*)f_16123},
{"f_11645:support_2escm",(void*)f_11645},
{"f_11648:support_2escm",(void*)f_11648},
{"f_11642:support_2escm",(void*)f_11642},
{"f_11097:support_2escm",(void*)f_11097},
{"f_11103:support_2escm",(void*)f_11103},
{"f_11657:support_2escm",(void*)f_11657},
{"f_8181:support_2escm",(void*)f_8181},
{"f_11651:support_2escm",(void*)f_11651},
{"f_15057:support_2escm",(void*)f_15057},
{"f_15051:support_2escm",(void*)f_15051},
{"f_16181:support_2escm",(void*)f_16181},
{"f_16187:support_2escm",(void*)f_16187},
{"f_11626:support_2escm",(void*)f_11626},
{"f_11620:support_2escm",(void*)f_11620},
{"f_15199:support_2escm",(void*)f_15199},
{"f_15081:support_2escm",(void*)f_15081},
{"f_11639:support_2escm",(void*)f_11639},
{"f_11633:support_2escm",(void*)f_11633},
{"f_10965:support_2escm",(void*)f_10965},
{"f_8853:support_2escm",(void*)f_8853},
{"f_5425:support_2escm",(void*)f_5425},
{"f_5420:support_2escm",(void*)f_5420},
{"f_8883:support_2escm",(void*)f_8883},
{"f_10917:support_2escm",(void*)f_10917},
{"f_9776:support_2escm",(void*)f_9776},
{"f_5454:support_2escm",(void*)f_5454},
{"f_5457:support_2escm",(void*)f_5457},
{"f_5459:support_2escm",(void*)f_5459},
{"f_8885:support_2escm",(void*)f_8885},
{"f_11614:support_2escm",(void*)f_11614},
{"f_10909:support_2escm",(void*)f_10909},
{"f_10906:support_2escm",(void*)f_10906},
{"f_5448:support_2escm",(void*)f_5448},
{"f_10900:support_2escm",(void*)f_10900},
{"f_14781:support_2escm",(void*)f_14781},
{"f_5122:support_2escm",(void*)f_5122},
{"f_5125:support_2escm",(void*)f_5125},
{"f_5126:support_2escm",(void*)f_5126},
{"f_15809:support_2escm",(void*)f_15809},
{"f_14203:support_2escm",(void*)f_14203},
{"f_9731:support_2escm",(void*)f_9731},
{"f_9106:support_2escm",(void*)f_9106},
{"f_12157:support_2escm",(void*)f_12157},
{"f_14787:support_2escm",(void*)f_14787},
{"f_5102:support_2escm",(void*)f_5102},
{"f_16107:support_2escm",(void*)f_16107},
{"f_12041:support_2escm",(void*)f_12041},
{"f_5109:support_2escm",(void*)f_5109},
{"f_5106:support_2escm",(void*)f_5106},
{"f_5100:support_2escm",(void*)f_5100},
{"f_9752:support_2escm",(void*)f_9752},
{"f_9756:support_2escm",(void*)f_9756},
{"f_12130:support_2escm",(void*)f_12130},
{"f_14725:support_2escm",(void*)f_14725},
{"f_14728:support_2escm",(void*)f_14728},
{"f_5136:support_2escm",(void*)f_5136},
{"f_5139:support_2escm",(void*)f_5139},
{"f_11591:support_2escm",(void*)f_11591},
{"f_10314:support_2escm",(void*)f_10314},
{"f_12068:support_2escm",(void*)f_12068},
{"f_11687:support_2escm",(void*)f_11687},
{"f_11681:support_2escm",(void*)f_11681},
{"f_11684:support_2escm",(void*)f_11684},
{"f_11696:support_2escm",(void*)f_11696},
{"f_11693:support_2escm",(void*)f_11693},
{"f_5118:support_2escm",(void*)f_5118},
{"f_5116:support_2escm",(void*)f_5116},
{"f_11699:support_2escm",(void*)f_11699},
{"f_10982:support_2escm",(void*)f_10982},
{"f_8555:support_2escm",(void*)f_8555},
{"f_10517:support_2escm",(void*)f_10517},
{"f_11946:support_2escm",(void*)f_11946},
{"f_5144:support_2escm",(void*)f_5144},
{"f_9657:support_2escm",(void*)f_9657},
{"f_15826:support_2escm",(void*)f_15826},
{"f_15829:support_2escm",(void*)f_15829},
{"f_9651:support_2escm",(void*)f_9651},
{"f_15822:support_2escm",(void*)f_15822},
{"f_10508:support_2escm",(void*)f_10508},
{"f_8557:support_2escm",(void*)f_8557},
{"f_12071:support_2escm",(void*)f_12071},
{"f_5177:support_2escm",(void*)f_5177},
{"f_5171:support_2escm",(void*)f_5171},
{"f_5174:support_2escm",(void*)f_5174},
{"f_11949:support_2escm",(void*)f_11949},
{"f_8813:support_2escm",(void*)f_8813},
{"f_11964:support_2escm",(void*)f_11964},
{"f_15884:support_2escm",(void*)f_15884},
{"f_6349:support_2escm",(void*)f_6349},
{"f_15881:support_2escm",(void*)f_15881},
{"f_10481:support_2escm",(void*)f_10481},
{"f_10483:support_2escm",(void*)f_10483},
{"f_5154:support_2escm",(void*)f_5154},
{"f_7668:support_2escm",(void*)f_7668},
{"f_7661:support_2escm",(void*)f_7661},
{"f_9078:support_2escm",(void*)f_9078},
{"f_14791:support_2escm",(void*)f_14791},
{"f_15865:support_2escm",(void*)f_15865},
{"f_16151:support_2escm",(void*)f_16151},
{"f_13736:support_2escm",(void*)f_13736},
{"f_16156:support_2escm",(void*)f_16156},
{"f_11988:support_2escm",(void*)f_11988},
{"f_11512:support_2escm",(void*)f_11512},
{"f_15896:support_2escm",(void*)f_15896},
{"f17604:support_2escm",(void*)f17604},
{"f_11510:support_2escm",(void*)f_11510},
{"f_8532:support_2escm",(void*)f_8532},
{"f_13730:support_2escm",(void*)f_13730},
{"f_6378:support_2escm",(void*)f_6378},
{"f_12764:support_2escm",(void*)f_12764},
{"f_16166:support_2escm",(void*)f_16166},
{"f_13740:support_2escm",(void*)f_13740},
{"f_12758:support_2escm",(void*)f_12758},
{"f_15871:support_2escm",(void*)f_15871},
{"f_10862:support_2escm",(void*)f_10862},
{"f_10206:support_2escm",(void*)f_10206},
{"f_6329:support_2escm",(void*)f_6329},
{"f_8582:support_2escm",(void*)f_8582},
{"f_6325:support_2escm",(void*)f_6325},
{"f_14762:support_2escm",(void*)f_14762},
{"f_12808:support_2escm",(void*)f_12808},
{"f_5414:support_2escm",(void*)f_5414},
{"f_8514:support_2escm",(void*)f_8514},
{"f_8526:support_2escm",(void*)f_8526},
{"f_11906:support_2escm",(void*)f_11906},
{"f_11501:support_2escm",(void*)f_11501},
{"f_11505:support_2escm",(void*)f_11505},
{"f_14032:support_2escm",(void*)f_14032},
{"f_10437:support_2escm",(void*)f_10437},
{"f_10431:support_2escm",(void*)f_10431},
{"f_9252:support_2escm",(void*)f_9252},
{"f_10736:support_2escm",(void*)f_10736},
{"f_6397:support_2escm",(void*)f_6397},
{"f_9713:support_2escm",(void*)f_9713},
{"f_8826:support_2escm",(void*)f_8826},
{"f_8828:support_2escm",(void*)f_8828},
{"f_9719:support_2escm",(void*)f_9719},
{"f_10091:support_2escm",(void*)f_10091},
{"f_9277:support_2escm",(void*)f_9277},
{"f_10079:support_2escm",(void*)f_10079},
{"f_12795:support_2escm",(void*)f_12795},
{"f_10089:support_2escm",(void*)f_10089},
{"f_9573:support_2escm",(void*)f_9573},
{"f_8597:support_2escm",(void*)f_8597},
{"f_8593:support_2escm",(void*)f_8593},
{"f_12777:support_2escm",(void*)f_12777},
{"f_8779:support_2escm",(void*)f_8779},
{"f_8773:support_2escm",(void*)f_8773},
{"f_8721:support_2escm",(void*)f_8721},
{"f_8723:support_2escm",(void*)f_8723},
{"f_14608:support_2escm",(void*)f_14608},
{"f_7632:support_2escm",(void*)f_7632},
{"f_15965:support_2escm",(void*)f_15965},
{"f_15960:support_2escm",(void*)f_15960},
{"f_10018:support_2escm",(void*)f_10018},
{"f_15952:support_2escm",(void*)f_15952},
{"f_15406:support_2escm",(void*)f_15406},
{"f_15409:support_2escm",(void*)f_15409},
{"f_8004:support_2escm",(void*)f_8004},
{"f_7658:support_2escm",(void*)f_7658},
{"f_5533:support_2escm",(void*)f_5533},
{"f_5539:support_2escm",(void*)f_5539},
{"f_5537:support_2escm",(void*)f_5537},
{"f_8765:support_2escm",(void*)f_8765},
{"f_15949:support_2escm",(void*)f_15949},
{"f_8008:support_2escm",(void*)f_8008},
{"f_8762:support_2escm",(void*)f_8762},
{"f_5521:support_2escm",(void*)f_5521},
{"f_15937:support_2escm",(void*)f_15937},
{"f_15468:support_2escm",(void*)f_15468},
{"f_15460:support_2escm",(void*)f_15460},
{"f_15454:support_2escm",(void*)f_15454},
{"f_10053:support_2escm",(void*)f_10053},
{"f_7795:support_2escm",(void*)f_7795},
{"f_10059:support_2escm",(void*)f_10059},
{"f_10050:support_2escm",(void*)f_10050},
{"f_15448:support_2escm",(void*)f_15448},
{"f_8016:support_2escm",(void*)f_8016},
{"f_9005:support_2escm",(void*)f_9005},
{"f_9003:support_2escm",(void*)f_9003},
{"f_10062:support_2escm",(void*)f_10062},
{"f_7768:support_2escm",(void*)f_7768},
{"f_7760:support_2escm",(void*)f_7760},
{"f_8041:support_2escm",(void*)f_8041},
{"f_15989:support_2escm",(void*)f_15989},
{"f_7734:support_2escm",(void*)f_7734},
{"f_7738:support_2escm",(void*)f_7738},
{"f_7731:support_2escm",(void*)f_7731},
{"f_5568:support_2escm",(void*)f_5568},
{"f_5561:support_2escm",(void*)f_5561},
{"f_8037:support_2escm",(void*)f_8037},
{"f_10046:support_2escm",(void*)f_10046},
{"f_10041:support_2escm",(void*)f_10041},
{"f_16037:support_2escm",(void*)f_16037},
{"f_16039:support_2escm",(void*)f_16039},
{"f_5093:support_2escm",(void*)f_5093},
{"f_7770:support_2escm",(void*)f_7770},
{"f_10588:support_2escm",(void*)f_10588},
{"f_16029:support_2escm",(void*)f_16029},
{"f_9334:support_2escm",(void*)f_9334},
{"f_5084:support_2escm",(void*)f_5084},
{"f_15926:support_2escm",(void*)f_15926},
{"f_16079:support_2escm",(void*)f_16079},
{"f_10595:support_2escm",(void*)f_10595},
{"f_10592:support_2escm",(void*)f_10592},
{"f_5509:support_2escm",(void*)f_5509},
{"f_7039:support_2escm",(void*)f_7039},
{"f_16009:support_2escm",(void*)f_16009},
{"f_15905:support_2escm",(void*)f_15905},
{"f_15909:support_2escm",(void*)f_15909},
{"f_10579:support_2escm",(void*)f_10579},
{"f_15900:support_2escm",(void*)f_15900},
{"f_7052:support_2escm",(void*)f_7052},
{"f_9936:support_2escm",(void*)f_9936},
{"f_16064:support_2escm",(void*)f_16064},
{"f_9933:support_2escm",(void*)f_9933},
{"f_10554:support_2escm",(void*)f_10554},
{"f_10552:support_2escm",(void*)f_10552},
{"f_9307:support_2escm",(void*)f_9307},
{"f_9309:support_2escm",(void*)f_9309},
{"f_10523:support_2escm",(void*)f_10523},
{"f_16043:support_2escm",(void*)f_16043},
{"f_11705:support_2escm",(void*)f_11705},
{"f_11708:support_2escm",(void*)f_11708},
{"f_9965:support_2escm",(void*)f_9965},
{"f_9973:support_2escm",(void*)f_9973},
{"f_9989:support_2escm",(void*)f_9989},
{"f_9806:support_2escm",(void*)f_9806},
{"f_9992:support_2escm",(void*)f_9992},
{"f_9998:support_2escm",(void*)f_9998},
{"f_9820:support_2escm",(void*)f_9820},
{"f_15255:support_2escm",(void*)f_15255},
{"f_8748:support_2escm",(void*)f_8748},
{"f_15250:support_2escm",(void*)f_15250},
{"f_8053:support_2escm",(void*)f_8053},
{"f_11734:support_2escm",(void*)f_11734},
{"f_11783:support_2escm",(void*)f_11783},
{"f_8080:support_2escm",(void*)f_8080},
{"f_11755:support_2escm",(void*)f_11755},
{"f_9875:support_2escm",(void*)f_9875},
{"f_11728:support_2escm",(void*)f_11728},
{"f_11720:support_2escm",(void*)f_11720},
{"f_8094:support_2escm",(void*)f_8094},
{"f_8092:support_2escm",(void*)f_8092},
{"f_11745:support_2escm",(void*)f_11745},
{"f_11717:support_2escm",(void*)f_11717},
{"f_11713:support_2escm",(void*)f_11713},
{"f_6808:support_2escm",(void*)f_6808},
{"f_6806:support_2escm",(void*)f_6806},
{"f_9845:support_2escm",(void*)f_9845},
{"f_9854:support_2escm",(void*)f_9854},
{"f_7063:support_2escm",(void*)f_7063},
{"f_9867:support_2escm",(void*)f_9867},
{"f_9200:support_2escm",(void*)f_9200},
{"f_7069:support_2escm",(void*)f_7069},
{"f_9215:support_2escm",(void*)f_9215},
{"f_10617:support_2escm",(void*)f_10617},
{"f_7743:support_2escm",(void*)f_7743},
{"f_7151:support_2escm",(void*)f_7151},
{"f_7154:support_2escm",(void*)f_7154},
{"f_9227:support_2escm",(void*)f_9227},
{"f_10601:support_2escm",(void*)f_10601},
{"f_6207:support_2escm",(void*)f_6207},
{"f_6201:support_2escm",(void*)f_6201},
{"f_10609:support_2escm",(void*)f_10609},
{"f_6200:support_2escm",(void*)f_6200},
{"f_7148:support_2escm",(void*)f_7148},
{"f_7142:support_2escm",(void*)f_7142},
{"f_11777:support_2escm",(void*)f_11777},
{"f_11771:support_2escm",(void*)f_11771},
{"toplevel:support_2escm",(void*)C_support_toplevel},
{"f_6268:support_2escm",(void*)f_6268},
{"f_15518:support_2escm",(void*)f_15518},
{"f_15516:support_2escm",(void*)f_15516},
{"f_6230:support_2escm",(void*)f_6230},
{"f_6885:support_2escm",(void*)f_6885},
{"f_5479:support_2escm",(void*)f_5479},
{"f_5477:support_2escm",(void*)f_5477},
{"f_8451:support_2escm",(void*)f_8451},
{"f_10399:support_2escm",(void*)f_10399},
{"f_10396:support_2escm",(void*)f_10396},
{"f_10392:support_2escm",(void*)f_10392},
{"f_6867:support_2escm",(void*)f_6867},
{"f_6864:support_2escm",(void*)f_6864},
{"f_6861:support_2escm",(void*)f_6861},
{"f_10368:support_2escm",(void*)f_10368},
{"f_10362:support_2escm",(void*)f_10362},
{"f_5183:support_2escm",(void*)f_5183},
{"f_5180:support_2escm",(void*)f_5180},
{"f_6272:support_2escm",(void*)f_6272},
{"f_15552:support_2escm",(void*)f_15552},
{"f_5485:support_2escm",(void*)f_5485},
{"f_6873:support_2escm",(void*)f_6873},
{"f_6870:support_2escm",(void*)f_6870},
{"f_15586:support_2escm",(void*)f_15586},
{"f_11232:support_2escm",(void*)f_11232},
{"f_5192:support_2escm",(void*)f_5192},
{"f_5195:support_2escm",(void*)f_5195},
{"f_5198:support_2escm",(void*)f_5198},
{"f_6218:support_2escm",(void*)f_6218},
{"f_8487:support_2escm",(void*)f_8487},
{"f_8489:support_2escm",(void*)f_8489},
{"f_6224:support_2escm",(void*)f_6224},
{"f_6221:support_2escm",(void*)f_6221},
{"f_8424:support_2escm",(void*)f_8424},
{"f_8426:support_2escm",(void*)f_8426},
{"f_6846:support_2escm",(void*)f_6846},
{"f_6842:support_2escm",(void*)f_6842},
{"f_16085:support_2escm",(void*)f_16085},
{"f_6851:support_2escm",(void*)f_6851},
{"f_11260:support_2escm",(void*)f_11260},
{"f_10386:support_2escm",(void*)f_10386},
{"f_10382:support_2escm",(void*)f_10382},
{"f_7478:support_2escm",(void*)f_7478},
{"f_6901:support_2escm",(void*)f_6901},
{"f_7487:support_2escm",(void*)f_7487},
{"f_5707:support_2escm",(void*)f_5707},
{"f_6911:support_2escm",(void*)f_6911},
{"f_6917:support_2escm",(void*)f_6917},
{"f_12896:support_2escm",(void*)f_12896},
{"f_9926:support_2escm",(void*)f_9926},
{"f_5754:support_2escm",(void*)f_5754},
{"f_5752:support_2escm",(void*)f_5752},
{"f_14107:support_2escm",(void*)f_14107},
{"f_5738:support_2escm",(void*)f_5738},
{"f_5251:support_2escm",(void*)f_5251},
{"f_15147:support_2escm",(void*)f_15147},
{"f_15145:support_2escm",(void*)f_15145},
{"f_5262:support_2escm",(void*)f_5262},
{"f_6985:support_2escm",(void*)f_6985},
{"f_5794:support_2escm",(void*)f_5794},
{"f_5259:support_2escm",(void*)f_5259},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  map		30
S|  sprintf		4
S|  fprintf		5
S|  printf		19
S|  for-each		15
o|eliminated procedure checks: 435 
o|specializations:
o|  1 (eqv? (not float) *)
o|  1 (zero? number)
o|  1 (length list)
o|  4 (= fixnum fixnum)
o|  1 (assq * (list-of pair))
o|  1 (current-output-port)
o|  1 (second (pair * pair))
o|  3 (first pair)
o|  5 (cddr (pair * pair))
o|  1 (caddr (pair * (pair * pair)))
o|  354 (eqv? * (not float))
o|  1 (##sys#call-with-values (procedure () *) *)
o|  1 (cadr (pair * pair))
o|  1 (current-input-port)
o|  5 (char=? char char)
o|  3 (memq * list)
o|  1 (>= fixnum fixnum)
o|  3 (< fixnum fixnum)
o|  2 (current-error-port)
o|  8 (##sys#check-list (or pair list) *)
o|  28 (##sys#check-output-port * * *)
o|  32 (cdr pair)
o|  28 (car pair)
(o e)|safe calls: 1524 
o|safe globals: (##compiler#bomb ##compiler#disabled-warnings ##compiler#debugging-chicken ##compiler#compiler-cleanup-hook constant25 constant22) 
o|Removed `not' forms: 7 
o|removed side-effect free assignment to unused variable: constant22 
o|inlining procedure: k4840 
o|inlining procedure: k4840 
o|inlining procedure: k4868 
o|inlining procedure: k4868 
o|inlining procedure: k4899 
o|inlining procedure: k4932 
o|contracted procedure: "(support.scm:69) g5158" 
o|propagated global variable: out6165 ##sys#standard-output 
o|substituted constant variable: a4914 
o|substituted constant variable: a4915 
o|inlining procedure: k4932 
o|inlining procedure: k4899 
o|propagated global variable: out7781 ##compiler#collected-debugging-output 
o|substituted constant variable: a4956 
o|substituted constant variable: a4957 
o|propagated global variable: out7781 ##compiler#collected-debugging-output 
o|inlining procedure: k4967 
o|inlining procedure: k4967 
o|propagated global variable: out114118 ##compiler#collected-debugging-output 
o|substituted constant variable: a5013 
o|substituted constant variable: a5014 
o|inlining procedure: k5028 
o|inlining procedure: k5028 
o|inlining procedure: k5044 
o|inlining procedure: k5044 
o|inlining procedure: k5064 
o|inlining procedure: k5064 
o|inlining procedure: k5146 
o|inlining procedure: k5146 
o|substituted constant variable: a5167 
o|substituted constant variable: a5168 
o|substituted constant variable: a5188 
o|substituted constant variable: a5189 
o|inlining procedure: k5226 
o|inlining procedure: k5226 
o|inlining procedure: k5285 
o|inlining procedure: k5285 
o|inlining procedure: k5306 
o|inlining procedure: k5306 
o|inlining procedure: k5335 
o|inlining procedure: k5335 
o|inlining procedure: k5369 
o|inlining procedure: k5369 
o|inlining procedure: k5397 
o|inlining procedure: k5397 
o|substituted constant variable: a5416 
o|substituted constant variable: a5417 
o|inlining procedure: k5427 
o|inlining procedure: k5427 
o|substituted constant variable: a5450 
o|substituted constant variable: a5451 
o|inlining procedure: k5487 
o|inlining procedure: k5487 
o|inlining procedure: k5541 
o|inlining procedure: k5541 
o|inlining procedure: k5586 
o|inlining procedure: k5586 
o|substituted constant variable: a5593 
o|substituted constant variable: a5595 
o|inlining procedure: k5608 
o|inlining procedure: k5608 
o|substituted constant variable: a5612 
o|substituted constant variable: a5614 
o|substituted constant variable: a5616 
o|inlining procedure: k5623 
o|inlining procedure: k5648 
o|inlining procedure: k5648 
o|substituted constant variable: a5657 
o|substituted constant variable: a5661 
o|inlining procedure: k5623 
o|inlining procedure: k5684 
o|propagated global variable: r568516340 ##sys#standard-input 
o|inlining procedure: k5684 
o|inlining procedure: k5699 
o|inlining procedure: k5699 
o|inlining procedure: k5728 
o|inlining procedure: k5728 
o|inlining procedure: k5740 
o|inlining procedure: k5740 
o|inlining procedure: k5760 
o|inlining procedure: k5760 
o|inlining procedure: k5802 
o|inlining procedure: k5802 
o|inlining procedure: k5850 
o|inlining procedure: k5850 
o|inlining procedure: k5862 
o|inlining procedure: k5862 
o|inlining procedure: k5874 
o|inlining procedure: k5874 
o|inlining procedure: k5886 
o|inlining procedure: k5886 
o|inlining procedure: k5895 
o|inlining procedure: k5895 
o|inlining procedure: k5912 
o|inlining procedure: k5912 
o|inlining procedure: k5924 
o|inlining procedure: k5924 
o|inlining procedure: k5942 
o|inlining procedure: k5942 
o|inlining procedure: k5954 
o|inlining procedure: k5954 
o|inlining procedure: k5966 
o|inlining procedure: k5966 
o|inlining procedure: k5988 
o|inlining procedure: k5988 
o|inlining procedure: k6000 
o|inlining procedure: k6000 
o|inlining procedure: k6009 
o|inlining procedure: k6009 
o|inlining procedure: k6047 
o|inlining procedure: k6047 
o|inlining procedure: k6060 
o|inlining procedure: k6060 
o|inlining procedure: k6101 
o|inlining procedure: k6101 
o|inlining procedure: k6145 
o|inlining procedure: k6145 
o|inlining procedure: k6165 
o|inlining procedure: k6165 
o|merged explicitly consed rest parameter: args485501 
o|consed rest parameter at call site: tmp24364 1 
o|inlining procedure: k6232 
o|inlining procedure: k6232 
o|inlining procedure: k6247 
o|inlining procedure: k6247 
o|inlining procedure: k6327 
o|inlining procedure: k6455 
o|contracted procedure: "(support.scm:368) g633640" 
o|contracted procedure: "(support.scm:370) g643644" 
o|inlining procedure: k6455 
o|propagated global variable: g639641 ##compiler#internal-bindings 
o|inlining procedure: k6478 
o|contracted procedure: "(support.scm:362) g584591" 
o|inlining procedure: k6398 
o|contracted procedure: "(support.scm:366) g609610" 
o|inlining procedure: k6398 
o|contracted procedure: "(support.scm:364) g594595" 
o|inlining procedure: k6478 
o|propagated global variable: g590592 extended-bindings 
o|inlining procedure: k6501 
o|contracted procedure: "(support.scm:356) g535542" 
o|inlining procedure: k6350 
o|contracted procedure: "(support.scm:360) g560561" 
o|inlining procedure: k6350 
o|contracted procedure: "(support.scm:358) g545546" 
o|inlining procedure: k6501 
o|propagated global variable: g541543 standard-bindings 
o|inlining procedure: k6327 
o|inlining procedure: k6527 
o|inlining procedure: k6527 
o|inlining procedure: k6545 
o|inlining procedure: k6545 
o|inlining procedure: k6563 
o|inlining procedure: k6575 
o|inlining procedure: k6575 
o|inlining procedure: k6563 
o|inlining procedure: k6609 
o|inlining procedure: k6609 
o|inlining procedure: k6664 
o|inlining procedure: k6664 
o|inlining procedure: k6716 
o|inlining procedure: k6716 
o|inlining procedure: k6741 
o|inlining procedure: k6741 
o|propagated global variable: out738742 ##sys#standard-output 
o|substituted constant variable: a6783 
o|substituted constant variable: a6784 
o|inlining procedure: k6779 
o|inlining procedure: k6810 
o|inlining procedure: k6810 
o|propagated global variable: out738742 ##sys#standard-output 
o|inlining procedure: k6779 
o|inlining procedure: k6853 
o|inlining procedure: k6853 
o|propagated global variable: out947951 ##sys#standard-output 
o|substituted constant variable: a6881 
o|substituted constant variable: a6882 
o|propagated global variable: out947951 ##sys#standard-output 
o|propagated global variable: out940944 ##sys#standard-output 
o|substituted constant variable: a6897 
o|substituted constant variable: a6898 
o|propagated global variable: out940944 ##sys#standard-output 
o|propagated global variable: out899903 ##sys#standard-output 
o|substituted constant variable: a6913 
o|substituted constant variable: a6914 
o|contracted procedure: "(support.scm:490) g907908" 
o|contracted procedure: "(support.scm:490) g904905" 
o|propagated global variable: out899903 ##sys#standard-output 
o|propagated global variable: out913917 ##sys#standard-output 
o|substituted constant variable: a6950 
o|substituted constant variable: a6951 
o|inlining procedure: k6943 
o|contracted procedure: "(support.scm:492) g921922" 
o|contracted procedure: "(support.scm:492) g918919" 
o|propagated global variable: out913917 ##sys#standard-output 
o|inlining procedure: k6943 
o|propagated global variable: out927931 ##sys#standard-output 
o|substituted constant variable: a6987 
o|substituted constant variable: a6988 
o|contracted procedure: "(support.scm:494) g935936" 
o|contracted procedure: "(support.scm:494) g932933" 
o|propagated global variable: out927931 ##sys#standard-output 
o|inlining procedure: k7041 
o|propagated global variable: out852856 ##sys#standard-output 
o|substituted constant variable: a7065 
o|substituted constant variable: a7066 
o|substituted constant variable: names774 
o|propagated global variable: out852856 ##sys#standard-output 
o|inlining procedure: k7085 
o|inlining procedure: k7085 
o|inlining procedure: k7098 
o|inlining procedure: k7098 
o|inlining procedure: k7108 
o|inlining procedure: k7108 
o|propagated global variable: out883887 ##sys#standard-output 
o|substituted constant variable: a7144 
o|substituted constant variable: a7145 
o|inlining procedure: k7134 
o|propagated global variable: out883887 ##sys#standard-output 
o|inlining procedure: k7134 
o|inlining procedure: k7176 
o|inlining procedure: k7176 
o|substituted constant variable: a7192 
o|substituted constant variable: a7194 
o|inlining procedure: k7198 
o|inlining procedure: k7198 
o|inlining procedure: k7210 
o|inlining procedure: k7210 
o|inlining procedure: k7222 
o|inlining procedure: k7222 
o|inlining procedure: k7234 
o|inlining procedure: k7234 
o|substituted constant variable: a7241 
o|substituted constant variable: a7243 
o|substituted constant variable: a7245 
o|substituted constant variable: a7247 
o|substituted constant variable: a7249 
o|substituted constant variable: a7251 
o|substituted constant variable: a7253 
o|substituted constant variable: a7255 
o|substituted constant variable: a7257 
o|substituted constant variable: a7259 
o|substituted constant variable: a7261 
o|substituted constant variable: a7263 
o|substituted constant variable: a7265 
o|inlining procedure: k7269 
o|inlining procedure: k7269 
o|inlining procedure: k7281 
o|inlining procedure: k7281 
o|inlining procedure: k7293 
o|inlining procedure: k7293 
o|inlining procedure: k7305 
o|inlining procedure: k7305 
o|inlining procedure: k7317 
o|inlining procedure: k7317 
o|inlining procedure: k7329 
o|inlining procedure: k7329 
o|inlining procedure: k7341 
o|inlining procedure: k7341 
o|inlining procedure: k7353 
o|inlining procedure: k7353 
o|inlining procedure: k7365 
o|inlining procedure: k7365 
o|inlining procedure: k7377 
o|inlining procedure: k7377 
o|substituted constant variable: a7384 
o|substituted constant variable: a7386 
o|substituted constant variable: a7388 
o|substituted constant variable: a7390 
o|substituted constant variable: a7392 
o|substituted constant variable: a7394 
o|substituted constant variable: a7396 
o|substituted constant variable: a7398 
o|substituted constant variable: a7400 
o|substituted constant variable: a7402 
o|substituted constant variable: a7404 
o|substituted constant variable: a7406 
o|substituted constant variable: a7408 
o|substituted constant variable: a7410 
o|substituted constant variable: a7412 
o|substituted constant variable: a7414 
o|substituted constant variable: a7416 
o|substituted constant variable: a7418 
o|substituted constant variable: a7420 
o|substituted constant variable: a7422 
o|substituted constant variable: a7424 
o|inlining procedure: k7041 
o|contracted procedure: "(support.scm:518) g10221023" 
o|contracted procedure: "(support.scm:519) g10291030" 
o|inlining procedure: k7540 
o|inlining procedure: k7540 
o|inlining procedure: k7560 
o|inlining procedure: k7560 
o|inlining procedure: k7576 
o|contracted procedure: "(support.scm:529) g10551056" 
o|inlining procedure: k7609 
o|inlining procedure: k7609 
o|inlining procedure: k7576 
o|inlining procedure: k7653 
o|inlining procedure: k7653 
o|inlining procedure: k7672 
o|inlining procedure: k7672 
o|inlining procedure: k7685 
o|contracted procedure: "(support.scm:545) g10921093" 
o|inlining procedure: k7772 
o|inlining procedure: k7772 
o|inlining procedure: k7806 
o|contracted procedure: "(support.scm:547) g11051114" 
o|inlining procedure: k7720 
o|inlining procedure: k7720 
o|inlining procedure: k7806 
o|inlining procedure: k7685 
o|contracted procedure: "(support.scm:554) g11541155" 
o|inlining procedure: k7874 
o|contracted procedure: "(support.scm:556) g11591160" 
o|inlining procedure: k7874 
o|inlining procedure: k7932 
o|contracted procedure: "(support.scm:563) g11721173" 
o|contracted procedure: "(support.scm:567) g11771178" 
o|inlining procedure: k7932 
o|contracted procedure: "(support.scm:569) g11821183" 
o|inlining procedure: k8058 
o|contracted procedure: "(support.scm:578) g11891190" 
o|inlining procedure: k8096 
o|inlining procedure: k8096 
o|inlining procedure: k8128 
o|inlining procedure: k8128 
o|inlining procedure: k8058 
o|contracted procedure: "(support.scm:583) g12241225" 
o|inlining procedure: k8183 
o|inlining procedure: k8183 
o|inlining procedure: k8218 
o|contracted procedure: "(support.scm:585) g12551256" 
o|inlining procedure: k8218 
o|contracted procedure: "(support.scm:587) g12601261" 
o|inlining procedure: k8258 
o|contracted procedure: "(support.scm:589) g12681269" 
o|inlining procedure: k8294 
o|inlining procedure: k8294 
o|inlining procedure: k8258 
o|contracted procedure: "(support.scm:594) g13001301" 
o|inlining procedure: k8390 
o|contracted procedure: "(support.scm:600) g13171318" 
o|inlining procedure: k8428 
o|inlining procedure: k8428 
o|inlining procedure: k8390 
o|contracted procedure: "(support.scm:602) g13481349" 
o|inlining procedure: k8491 
o|inlining procedure: k8491 
o|contracted procedure: "(support.scm:605) g13811382" 
o|inlining procedure: k8559 
o|inlining procedure: k8559 
o|inlining procedure: k8595 
o|inlining procedure: k8605 
o|inlining procedure: k8605 
o|inlining procedure: k8595 
o|contracted procedure: "(support.scm:607) g13901391" 
o|substituted constant variable: a8627 
o|inlining procedure: k8631 
o|inlining procedure: k8631 
o|inlining procedure: k8643 
o|inlining procedure: k8643 
o|substituted constant variable: a8650 
o|substituted constant variable: a8652 
o|substituted constant variable: a8654 
o|substituted constant variable: a8656 
o|substituted constant variable: a8658 
o|substituted constant variable: a8660 
o|substituted constant variable: a8665 
o|substituted constant variable: a8667 
o|substituted constant variable: a8669 
o|substituted constant variable: a8671 
o|substituted constant variable: a8676 
o|substituted constant variable: a8678 
o|substituted constant variable: a8680 
o|substituted constant variable: a8682 
o|substituted constant variable: a8684 
o|substituted constant variable: a8689 
o|substituted constant variable: a8691 
o|substituted constant variable: a8693 
o|substituted constant variable: a8695 
o|substituted constant variable: a8700 
o|substituted constant variable: a8702 
o|contracted procedure: "(support.scm:617) g14251426" 
o|inlining procedure: k8725 
o|inlining procedure: k8725 
o|contracted procedure: "(support.scm:525) g10431044" 
o|inlining procedure: k8763 
o|inlining procedure: k8763 
o|inlining procedure: k8805 
o|inlining procedure: k8830 
o|inlining procedure: k8830 
o|inlining procedure: k8805 
o|inlining procedure: k8887 
o|inlining procedure: k8887 
o|inlining procedure: k8918 
o|inlining procedure: k8918 
o|inlining procedure: k8936 
o|inlining procedure: k8936 
o|inlining procedure: k8953 
o|inlining procedure: k8953 
o|inlining procedure: k8965 
o|inlining procedure: k9007 
o|inlining procedure: k9007 
o|inlining procedure: k9055 
o|inlining procedure: k9055 
o|inlining procedure: k8965 
o|inlining procedure: k9114 
o|inlining procedure: k9114 
o|inlining procedure: k9148 
o|inlining procedure: k9178 
o|inlining procedure: k9178 
o|inlining procedure: k9148 
o|inlining procedure: k9254 
o|inlining procedure: k9254 
o|inlining procedure: k9285 
o|inlining procedure: k9311 
o|inlining procedure: k9311 
o|inlining procedure: k9285 
o|inlining procedure: k9351 
o|inlining procedure: k9367 
o|inlining procedure: k9367 
o|inlining procedure: k9351 
o|inlining procedure: k9439 
o|inlining procedure: k9439 
o|inlining procedure: k9474 
o|inlining procedure: k9499 
o|inlining procedure: k9499 
o|inlining procedure: k9474 
o|inlining procedure: k9550 
o|inlining procedure: k9550 
o|substituted constant variable: a9585 
o|substituted constant variable: a9587 
o|inlining procedure: k9591 
o|inlining procedure: k9591 
o|substituted constant variable: a9604 
o|substituted constant variable: a9606 
o|substituted constant variable: a9608 
o|substituted constant variable: a9610 
o|substituted constant variable: a9612 
o|substituted constant variable: a9614 
o|substituted constant variable: a9616 
o|substituted constant variable: a9618 
o|substituted constant variable: a9620 
o|substituted constant variable: a9622 
o|substituted constant variable: a9624 
o|substituted constant variable: a9626 
o|substituted constant variable: a9628 
o|substituted constant variable: a9630 
o|substituted constant variable: a9632 
o|substituted constant variable: a9634 
o|inlining procedure: k9638 
o|inlining procedure: k9638 
o|substituted constant variable: a9645 
o|substituted constant variable: a9647 
o|substituted constant variable: a9649 
o|contracted procedure: "(support.scm:627) g14721473" 
o|contracted procedure: "(support.scm:626) g14691470" 
o|contracted procedure: "(support.scm:625) g14661467" 
o|inlining procedure: k9659 
o|inlining procedure: k9659 
o|contracted procedure: "(support.scm:680) g17841785" 
o|contracted procedure: "(support.scm:695) g18331834" 
o|contracted procedure: "(support.scm:697) g18381839" 
o|inlining procedure: k9774 
o|inlining procedure: k9774 
o|contracted procedure: "(support.scm:701) g18431844" 
o|inlining procedure: k9822 
o|inlining procedure: k9822 
o|inlining procedure: k9901 
o|contracted procedure: "(support.scm:719) g19101911" 
o|inlining procedure: k9901 
o|inlining procedure: "(support.scm:724) rename1886" 
o|inlining procedure: k9940 
o|contracted procedure: "(support.scm:726) g19171918" 
o|inlining procedure: "(support.scm:727) rename1886" 
o|inlining procedure: k9940 
o|contracted procedure: "(support.scm:735) g19261927" 
o|inlining procedure: k10027 
o|contracted procedure: "(support.scm:748) g19971998" 
o|inlining procedure: k10093 
o|inlining procedure: k10093 
o|inlining procedure: k10141 
o|inlining procedure: "(support.scm:751) rename1886" 
o|inlining procedure: k10141 
o|inlining procedure: k10160 
o|inlining procedure: k10160 
o|inlining procedure: k10208 
o|inlining procedure: k10208 
o|inlining procedure: k10027 
o|contracted procedure: "(support.scm:754) g20372038" 
o|inlining procedure: k10269 
o|inlining procedure: k10269 
o|substituted constant variable: a10301 
o|substituted constant variable: a10303 
o|substituted constant variable: a10305 
o|substituted constant variable: a10307 
o|substituted constant variable: a10309 
o|contracted procedure: "(support.scm:716) g19011902" 
o|contracted procedure: "(support.scm:715) g18981899" 
o|contracted procedure: "(support.scm:714) g18951896" 
o|inlining procedure: k10316 
o|inlining procedure: k10316 
o|inlining procedure: k10370 
o|inlining procedure: k10370 
o|contracted procedure: "(support.scm:766) g20922093" 
o|contracted procedure: "(support.scm:765) g20892090" 
o|contracted procedure: "(support.scm:764) g20862087" 
o|inlining procedure: k10485 
o|inlining procedure: k10485 
o|contracted procedure: "(support.scm:773) g21302131" 
o|contracted procedure: "(support.scm:772) g21082109" 
o|contracted procedure: "(support.scm:771) g21052106" 
o|contracted procedure: "(support.scm:777) g21452146" 
o|inlining procedure: k10556 
o|inlining procedure: k10556 
o|inlining procedure: k10596 
o|inlining procedure: k10619 
o|contracted procedure: "(support.scm:815) g22362243" 
o|inlining procedure: k10619 
o|inlining procedure: k10596 
o|inlining procedure: k10680 
o|contracted procedure: "(support.scm:807) g22142221" 
o|inlining procedure: k10680 
o|inlining procedure: k10707 
o|contracted procedure: k10722 
o|inlining procedure: k10719 
o|inlining procedure: k10719 
o|inlining procedure: k10737 
o|contracted procedure: k10757 
o|inlining procedure: k10754 
o|inlining procedure: k10754 
o|inlining procedure: k10795 
o|inlining procedure: k10795 
o|substituted constant variable: a10809 
o|substituted constant variable: a10811 
o|contracted procedure: "(support.scm:793) g22062207" 
o|contracted procedure: "(support.scm:791) g21972198" 
o|inlining procedure: k10737 
o|contracted procedure: "(support.scm:786) g21852186" 
o|contracted procedure: "(support.scm:786) g21882189" 
o|inlining procedure: k10707 
o|inlining procedure: k10867 
o|inlining procedure: k10867 
o|contracted procedure: "(support.scm:823) g22642265" 
o|inlining procedure: k10914 
o|inlining procedure: k10914 
o|inlining procedure: k10945 
o|inlining procedure: k10945 
o|inlining procedure: k10960 
o|inlining procedure: k10960 
o|inlining procedure: k10984 
o|inlining procedure: k10984 
o|inlining procedure: k10999 
o|inlining procedure: k11024 
o|inlining procedure: k11024 
o|inlining procedure: k11042 
o|inlining procedure: k11042 
o|contracted procedure: "(support.scm:853) g23262327" 
o|inlining procedure: k10999 
o|contracted procedure: "(support.scm:852) g23142315" 
o|contracted procedure: "(support.scm:851) g23102311" 
o|inlining procedure: k11098 
o|contracted procedure: "(support.scm:864) g23342335" 
o|contracted procedure: "(support.scm:864) g23312332" 
o|inlining procedure: k11098 
o|inlining procedure: k11147 
o|inlining procedure: k11147 
o|contracted procedure: "(support.scm:876) g23692370" 
o|inlining procedure: k11187 
o|inlining procedure: k11187 
o|substituted constant variable: a11203 
o|substituted constant variable: a11205 
o|substituted constant variable: a11207 
o|inlining procedure: k11211 
o|inlining procedure: k11211 
o|substituted constant variable: a11224 
o|substituted constant variable: a11226 
o|substituted constant variable: a11228 
o|substituted constant variable: a11230 
o|contracted procedure: "(support.scm:873) g23562357" 
o|contracted procedure: "(support.scm:872) g23472348" 
o|inlining procedure: k11248 
o|inlining procedure: k11270 
o|inlining procedure: k11293 
o|inlining procedure: k11293 
o|contracted procedure: "(support.scm:895) g24092410" 
o|contracted procedure: "(support.scm:894) g24052406" 
o|contracted procedure: "(support.scm:892) g24002401" 
o|inlining procedure: k11270 
o|contracted procedure: "(support.scm:898) g24122413" 
o|substituted constant variable: a11345 
o|substituted constant variable: a11347 
o|contracted procedure: "(support.scm:890) g23962397" 
o|inlining procedure: k11248 
o|contracted procedure: "(support.scm:884) g23802381" 
o|inlining procedure: k11361 
o|inlining procedure: k11361 
o|contracted procedure: k11373 
o|inlining procedure: k11376 
o|inlining procedure: k11376 
o|inlining procedure: k11402 
o|inlining procedure: k11402 
o|contracted procedure: k11414 
o|inlining procedure: k11417 
o|inlining procedure: k11417 
o|inlining procedure: k11439 
o|inlining procedure: k11459 
o|inlining procedure: k11459 
o|inlining procedure: k11439 
o|contracted procedure: k11469 
o|inlining procedure: k11482 
o|inlining procedure: k11482 
o|contracted procedure: k11494 
o|inlining procedure: k11521 
o|inlining procedure: k11521 
o|inlining procedure: k11541 
o|inlining procedure: k11541 
o|contracted procedure: "(support.scm:970) g24712472" 
o|inlining procedure: k11562 
o|inlining procedure: k11562 
o|substituted constant variable: a11579 
o|substituted constant variable: a11581 
o|substituted constant variable: a11583 
o|inlining procedure: k11593 
o|inlining procedure: k11593 
o|propagated global variable: out24912495 ##sys#standard-output 
o|substituted constant variable: a11635 
o|substituted constant variable: a11636 
o|propagated global variable: out25012505 ##sys#standard-output 
o|substituted constant variable: a11653 
o|substituted constant variable: a11654 
o|propagated global variable: out25092513 ##sys#standard-output 
o|substituted constant variable: a11665 
o|substituted constant variable: a11666 
o|propagated global variable: out25172521 ##sys#standard-output 
o|substituted constant variable: a11677 
o|substituted constant variable: a11678 
o|propagated global variable: out25252529 ##sys#standard-output 
o|substituted constant variable: a11689 
o|substituted constant variable: a11690 
o|propagated global variable: out25332537 ##sys#standard-output 
o|substituted constant variable: a11701 
o|substituted constant variable: a11702 
o|inlining procedure: k11628 
o|propagated global variable: out25332537 ##sys#standard-output 
o|propagated global variable: out25252529 ##sys#standard-output 
o|propagated global variable: out25172521 ##sys#standard-output 
o|propagated global variable: out25092513 ##sys#standard-output 
o|propagated global variable: out25012505 ##sys#standard-output 
o|propagated global variable: out24912495 ##sys#standard-output 
o|inlining procedure: k11628 
o|inlining procedure: k11721 
o|inlining procedure: k11721 
o|inlining procedure: k11747 
o|contracted procedure: "(support.scm:1000) g25532560" 
o|inlining procedure: k11747 
o|inlining procedure: k11785 
o|inlining procedure: k11785 
o|inlining procedure: k11809 
o|inlining procedure: k11809 
o|inlining procedure: k11815 
o|inlining procedure: k11815 
o|inlining procedure: k11868 
o|inlining procedure: k11868 
o|inlining procedure: k11922 
o|inlining procedure: k11922 
o|inlining procedure: k11980 
o|substituted constant variable: tmap2571 
o|substituted constant variable: tmap2571 
o|inlining procedure: k11980 
o|inlining procedure: k12015 
o|inlining procedure: k12015 
o|inlining procedure: k12021 
o|inlining procedure: k12021 
o|inlining procedure: k12042 
o|inlining procedure: k12042 
o|inlining procedure: k12048 
o|inlining procedure: k12048 
o|inlining procedure: k12095 
o|inlining procedure: k12095 
o|inlining procedure: k12149 
o|inlining procedure: k12149 
o|inlining procedure: k12177 
o|inlining procedure: k12177 
o|inlining procedure: k12210 
o|inlining procedure: k12210 
o|inlining procedure: k12201 
o|inlining procedure: k12201 
o|inlining procedure: k12229 
o|inlining procedure: k12229 
o|inlining procedure: k12303 
o|inlining procedure: k12303 
o|inlining procedure: k12344 
o|inlining procedure: k12344 
o|inlining procedure: k12350 
o|inlining procedure: k12350 
o|inlining procedure: k12376 
o|inlining procedure: k12376 
o|substituted constant variable: a12404 
o|substituted constant variable: a12406 
o|substituted constant variable: a12408 
o|substituted constant variable: a12410 
o|substituted constant variable: a12412 
o|substituted constant variable: a12414 
o|substituted constant variable: a12416 
o|substituted constant variable: a12421 
o|substituted constant variable: a12423 
o|inlining procedure: k12427 
o|inlining procedure: k12427 
o|substituted constant variable: a12440 
o|substituted constant variable: a12442 
o|substituted constant variable: a12444 
o|substituted constant variable: a12446 
o|substituted constant variable: a12454 
o|inlining procedure: k12458 
o|inlining procedure: k12458 
o|substituted constant variable: a12465 
o|substituted constant variable: a12467 
o|substituted constant variable: a12469 
o|inlining procedure: k12473 
o|inlining procedure: k12473 
o|substituted constant variable: a12486 
o|substituted constant variable: a12488 
o|substituted constant variable: a12490 
o|substituted constant variable: a12492 
o|substituted constant variable: a12494 
o|inlining procedure: k12498 
o|inlining procedure: k12498 
o|substituted constant variable: a12505 
o|substituted constant variable: a12507 
o|substituted constant variable: a12509 
o|substituted constant variable: a12511 
o|inlining procedure: k12515 
o|inlining procedure: k12515 
o|substituted constant variable: a12522 
o|substituted constant variable: a12524 
o|substituted constant variable: a12526 
o|substituted constant variable: a12528 
o|inlining procedure: k12532 
o|inlining procedure: k12532 
o|substituted constant variable: a12545 
o|substituted constant variable: a12547 
o|substituted constant variable: a12549 
o|substituted constant variable: a12551 
o|inlining procedure: k12555 
o|inlining procedure: k12555 
o|inlining procedure: k12567 
o|inlining procedure: k12567 
o|inlining procedure: k12579 
o|inlining procedure: k12579 
o|substituted constant variable: a12592 
o|substituted constant variable: a12594 
o|substituted constant variable: a12596 
o|substituted constant variable: a12598 
o|substituted constant variable: a12600 
o|substituted constant variable: a12602 
o|substituted constant variable: a12604 
o|substituted constant variable: a12606 
o|inlining procedure: k12610 
o|inlining procedure: k12610 
o|inlining procedure: k12622 
o|inlining procedure: k12622 
o|inlining procedure: k12634 
o|inlining procedure: k12634 
o|substituted constant variable: a12647 
o|substituted constant variable: a12649 
o|substituted constant variable: a12651 
o|substituted constant variable: a12653 
o|substituted constant variable: a12655 
o|substituted constant variable: a12657 
o|substituted constant variable: a12659 
o|substituted constant variable: a12661 
o|substituted constant variable: a12663 
o|substituted constant variable: a12665 
o|substituted constant variable: a12670 
o|substituted constant variable: a12672 
o|substituted constant variable: a12677 
o|substituted constant variable: a12679 
o|inlining procedure: k12683 
o|inlining procedure: k12683 
o|substituted constant variable: a12690 
o|substituted constant variable: a12692 
o|substituted constant variable: a12694 
o|inlining procedure: k12698 
o|inlining procedure: k12698 
o|inlining procedure: k12710 
o|inlining procedure: k12710 
o|inlining procedure: k12722 
o|inlining procedure: k12722 
o|substituted constant variable: a12735 
o|substituted constant variable: a12737 
o|substituted constant variable: a12739 
o|substituted constant variable: a12741 
o|substituted constant variable: a12743 
o|substituted constant variable: a12745 
o|substituted constant variable: a12747 
o|substituted constant variable: a12749 
o|substituted constant variable: a12754 
o|substituted constant variable: a12756 
o|inlining procedure: k12769 
o|inlining procedure: k12769 
o|inlining procedure: k12778 
o|inlining procedure: k12778 
o|inlining procedure: k12800 
o|inlining procedure: k12800 
o|inlining procedure: k12809 
o|inlining procedure: k12809 
o|inlining procedure: k12846 
o|inlining procedure: k12846 
o|inlining procedure: k12837 
o|inlining procedure: k12837 
o|inlining procedure: k12879 
o|inlining procedure: k12879 
o|inlining procedure: k12900 
o|inlining procedure: k12900 
o|inlining procedure: k12936 
o|inlining procedure: k12936 
o|inlining procedure: k12927 
o|inlining procedure: k12927 
o|inlining procedure: k12955 
o|inlining procedure: k12955 
o|inlining procedure: k12970 
o|inlining procedure: k12970 
o|inlining procedure: k12982 
o|inlining procedure: k12982 
o|inlining procedure: k12994 
o|inlining procedure: k12994 
o|inlining procedure: k13006 
o|inlining procedure: k13006 
o|substituted constant variable: a13013 
o|substituted constant variable: a13015 
o|substituted constant variable: a13017 
o|substituted constant variable: a13019 
o|substituted constant variable: a13021 
o|substituted constant variable: a13023 
o|substituted constant variable: a13025 
o|substituted constant variable: a13027 
o|substituted constant variable: a13029 
o|inlining procedure: k13039 
o|inlining procedure: k13039 
o|inlining procedure: k13051 
o|inlining procedure: k13051 
o|substituted constant variable: a13058 
o|substituted constant variable: a13060 
o|substituted constant variable: a13062 
o|substituted constant variable: a13064 
o|substituted constant variable: a13066 
o|inlining procedure: k13070 
o|inlining procedure: k13070 
o|inlining procedure: k13082 
o|inlining procedure: k13082 
o|inlining procedure: k13094 
o|inlining procedure: k13094 
o|substituted constant variable: a13101 
o|substituted constant variable: a13103 
o|substituted constant variable: a13105 
o|substituted constant variable: a13107 
o|substituted constant variable: a13109 
o|substituted constant variable: a13111 
o|substituted constant variable: a13113 
o|inlining procedure: k13117 
o|inlining procedure: k13117 
o|inlining procedure: k13129 
o|inlining procedure: k13129 
o|inlining procedure: k13141 
o|inlining procedure: k13141 
o|inlining procedure: k13153 
o|inlining procedure: k13153 
o|inlining procedure: k13165 
o|inlining procedure: k13165 
o|substituted constant variable: a13178 
o|substituted constant variable: a13180 
o|substituted constant variable: a13182 
o|substituted constant variable: a13184 
o|substituted constant variable: a13186 
o|substituted constant variable: a13188 
o|substituted constant variable: a13190 
o|substituted constant variable: a13192 
o|substituted constant variable: a13194 
o|substituted constant variable: a13196 
o|substituted constant variable: a13198 
o|substituted constant variable: a13200 
o|inlining procedure: k13204 
o|inlining procedure: k13204 
o|inlining procedure: k13216 
o|inlining procedure: k13216 
o|inlining procedure: k13228 
o|inlining procedure: k13228 
o|inlining procedure: k13240 
o|inlining procedure: k13240 
o|inlining procedure: k13252 
o|inlining procedure: k13252 
o|inlining procedure: k13264 
o|inlining procedure: k13264 
o|substituted constant variable: a13271 
o|substituted constant variable: a13273 
o|substituted constant variable: a13275 
o|substituted constant variable: a13277 
o|substituted constant variable: a13279 
o|substituted constant variable: a13281 
o|substituted constant variable: a13283 
o|substituted constant variable: a13285 
o|substituted constant variable: a13287 
o|substituted constant variable: a13289 
o|substituted constant variable: a13291 
o|substituted constant variable: a13293 
o|substituted constant variable: a13295 
o|inlining procedure: k13317 
o|inlining procedure: k13317 
o|inlining procedure: k13353 
o|inlining procedure: k13353 
o|inlining procedure: k13344 
o|inlining procedure: k13344 
o|inlining procedure: k13372 
o|inlining procedure: k13372 
o|inlining procedure: "(support.scm:1224) err3016" 
o|inlining procedure: k13390 
o|inlining procedure: k13390 
o|inlining procedure: k13402 
o|inlining procedure: k13402 
o|inlining procedure: k13414 
o|inlining procedure: k13414 
o|substituted constant variable: a13427 
o|substituted constant variable: a13429 
o|substituted constant variable: a13431 
o|substituted constant variable: a13433 
o|substituted constant variable: a13435 
o|substituted constant variable: a13437 
o|substituted constant variable: a13439 
o|substituted constant variable: a13441 
o|inlining procedure: "(support.scm:1225) err3016" 
o|inlining procedure: k13454 
o|inlining procedure: k13454 
o|substituted constant variable: a13467 
o|substituted constant variable: a13469 
o|substituted constant variable: a13471 
o|substituted constant variable: a13473 
o|inlining procedure: k13477 
o|inlining procedure: k13477 
o|inlining procedure: k13489 
o|inlining procedure: k13489 
o|inlining procedure: k13501 
o|inlining procedure: k13501 
o|inlining procedure: k13513 
o|inlining procedure: k13513 
o|inlining procedure: k13525 
o|inlining procedure: k13525 
o|inlining procedure: k13537 
o|inlining procedure: k13537 
o|inlining procedure: k13549 
o|inlining procedure: k13549 
o|inlining procedure: k13561 
o|inlining procedure: k13561 
o|inlining procedure: k13573 
o|inlining procedure: k13573 
o|inlining procedure: k13585 
o|inlining procedure: k13585 
o|inlining procedure: k13597 
o|inlining procedure: k13597 
o|inlining procedure: k13609 
o|inlining procedure: k13609 
o|inlining procedure: k13621 
o|inlining procedure: k13621 
o|inlining procedure: k13633 
o|inlining procedure: k13633 
o|inlining procedure: k13645 
o|inlining procedure: k13645 
o|inlining procedure: k13657 
o|inlining procedure: k13657 
o|substituted constant variable: a13664 
o|substituted constant variable: a13666 
o|substituted constant variable: a13668 
o|substituted constant variable: a13670 
o|substituted constant variable: a13672 
o|substituted constant variable: a13674 
o|substituted constant variable: a13676 
o|substituted constant variable: a13678 
o|substituted constant variable: a13680 
o|substituted constant variable: a13682 
o|substituted constant variable: a13684 
o|substituted constant variable: a13686 
o|substituted constant variable: a13688 
o|substituted constant variable: a13690 
o|substituted constant variable: a13692 
o|substituted constant variable: a13694 
o|substituted constant variable: a13696 
o|substituted constant variable: a13698 
o|substituted constant variable: a13700 
o|substituted constant variable: a13702 
o|substituted constant variable: a13704 
o|substituted constant variable: a13706 
o|substituted constant variable: a13708 
o|substituted constant variable: a13710 
o|substituted constant variable: a13712 
o|substituted constant variable: a13714 
o|substituted constant variable: a13716 
o|substituted constant variable: a13718 
o|substituted constant variable: a13720 
o|substituted constant variable: a13722 
o|substituted constant variable: a13724 
o|substituted constant variable: a13726 
o|substituted constant variable: a13728 
o|inlining procedure: k13741 
o|inlining procedure: k13741 
o|inlining procedure: k13770 
o|inlining procedure: k13770 
o|inlining procedure: k13802 
o|inlining procedure: k13802 
o|inlining procedure: k13832 
o|inlining procedure: k13832 
o|inlining procedure: k13851 
o|inlining procedure: k13851 
o|inlining procedure: k13873 
o|inlining procedure: k13873 
o|substituted constant variable: a13938 
o|substituted constant variable: a13943 
o|substituted constant variable: a13945 
o|substituted constant variable: a13946 
o|inlining procedure: k13954 
o|substituted constant variable: a13964 
o|inlining procedure: k13954 
o|substituted constant variable: a13965 
o|substituted constant variable: a13975 
o|substituted constant variable: a13977 
o|substituted constant variable: a13979 
o|substituted constant variable: a13984 
o|substituted constant variable: a13986 
o|substituted constant variable: a13991 
o|substituted constant variable: a13993 
o|substituted constant variable: a13995 
o|substituted constant variable: a14000 
o|substituted constant variable: a14002 
o|inlining procedure: k14009 
o|inlining procedure: k14009 
o|inlining procedure: k14024 
o|inlining procedure: k14024 
o|inlining procedure: k14042 
o|inlining procedure: k14042 
o|substituted constant variable: a14049 
o|inlining procedure: k14050 
o|inlining procedure: k14050 
o|inlining procedure: k14065 
o|inlining procedure: k14065 
o|substituted constant variable: a14072 
o|inlining procedure: k14073 
o|inlining procedure: k14073 
o|inlining procedure: k14085 
o|inlining procedure: k14085 
o|substituted constant variable: a14092 
o|inlining procedure: k14093 
o|inlining procedure: k14093 
o|inlining procedure: k14108 
o|inlining procedure: k14108 
o|substituted constant variable: a14125 
o|inlining procedure: k14126 
o|inlining procedure: k14126 
o|inlining procedure: k14138 
o|inlining procedure: k14138 
o|inlining procedure: k14150 
o|inlining procedure: k14150 
o|inlining procedure: k14162 
o|inlining procedure: k14162 
o|inlining procedure: k14174 
o|inlining procedure: k14174 
o|inlining procedure: k14189 
o|inlining procedure: k14189 
o|inlining procedure: k14204 
o|inlining procedure: k14204 
o|inlining procedure: k14222 
o|inlining procedure: k14222 
o|inlining procedure: k14235 
o|inlining procedure: k14235 
o|inlining procedure: k14257 
o|inlining procedure: k14257 
o|inlining procedure: k14269 
o|inlining procedure: k14269 
o|substituted constant variable: a14276 
o|substituted constant variable: a14278 
o|substituted constant variable: a14280 
o|substituted constant variable: a14282 
o|inlining procedure: k14286 
o|inlining procedure: k14286 
o|substituted constant variable: a14299 
o|substituted constant variable: a14301 
o|substituted constant variable: a14303 
o|substituted constant variable: a14305 
o|substituted constant variable: a14307 
o|inlining procedure: k14311 
o|inlining procedure: k14311 
o|substituted constant variable: a14318 
o|substituted constant variable: a14320 
o|substituted constant variable: a14322 
o|substituted constant variable: a14327 
o|substituted constant variable: a14329 
o|inlining procedure: k14333 
o|inlining procedure: k14333 
o|substituted constant variable: a14346 
o|substituted constant variable: a14348 
o|substituted constant variable: a14350 
o|substituted constant variable: a14352 
o|substituted constant variable: a14354 
o|substituted constant variable: a14356 
o|inlining procedure: k14360 
o|inlining procedure: k14360 
o|inlining procedure: k14372 
o|inlining procedure: k14372 
o|inlining procedure: k14384 
o|inlining procedure: k14384 
o|substituted constant variable: a14397 
o|substituted constant variable: a14399 
o|substituted constant variable: a14401 
o|substituted constant variable: a14403 
o|substituted constant variable: a14405 
o|substituted constant variable: a14407 
o|substituted constant variable: a14409 
o|substituted constant variable: a14411 
o|substituted constant variable: a14413 
o|substituted constant variable: a14415 
o|substituted constant variable: a14417 
o|substituted constant variable: a14419 
o|substituted constant variable: a14421 
o|substituted constant variable: a14423 
o|substituted constant variable: a14425 
o|substituted constant variable: a14427 
o|inlining procedure: k14431 
o|inlining procedure: k14431 
o|inlining procedure: k14443 
o|inlining procedure: k14443 
o|inlining procedure: k14455 
o|inlining procedure: k14455 
o|substituted constant variable: a14468 
o|substituted constant variable: a14470 
o|substituted constant variable: a14472 
o|substituted constant variable: a14474 
o|substituted constant variable: a14476 
o|substituted constant variable: a14478 
o|substituted constant variable: a14480 
o|substituted constant variable: a14482 
o|substituted constant variable: a14484 
o|substituted constant variable: a14486 
o|substituted constant variable: a14488 
o|substituted constant variable: a14490 
o|substituted constant variable: a14495 
o|substituted constant variable: a14497 
o|substituted constant variable: a14502 
o|substituted constant variable: a14504 
o|inlining procedure: k14508 
o|inlining procedure: k14508 
o|inlining procedure: k14520 
o|inlining procedure: k14520 
o|inlining procedure: k14532 
o|inlining procedure: k14532 
o|substituted constant variable: a14545 
o|substituted constant variable: a14547 
o|substituted constant variable: a14549 
o|substituted constant variable: a14551 
o|substituted constant variable: a14553 
o|substituted constant variable: a14555 
o|substituted constant variable: a14557 
o|substituted constant variable: a14559 
o|substituted constant variable: a14564 
o|substituted constant variable: a14566 
o|substituted constant variable: a14568 
o|inlining procedure: k14594 
o|inlining procedure: k14618 
o|inlining procedure: k14618 
o|contracted procedure: "(support.scm:1333) g34023403" 
o|inlining procedure: k14594 
o|inlining procedure: k14682 
o|inlining procedure: k14682 
o|inlining procedure: k14705 
o|inlining procedure: k14705 
o|substituted constant variable: a14712 
o|substituted constant variable: a14714 
o|substituted constant variable: a14716 
o|substituted constant variable: a14721 
o|substituted constant variable: a14723 
o|contracted procedure: "(support.scm:1331) g33953396" 
o|contracted procedure: "(support.scm:1330) g33863387" 
o|inlining procedure: k14754 
o|inlining procedure: k14754 
o|inlining procedure: k14772 
o|inlining procedure: k14772 
o|inlining procedure: k14792 
o|inlining procedure: k14792 
o|inlining procedure: k14842 
o|inlining procedure: k14842 
o|substituted constant variable: a14873 
o|substituted constant variable: a14875 
o|substituted constant variable: a14877 
o|substituted constant variable: a14879 
o|inlining procedure: k14883 
o|inlining procedure: k14883 
o|inlining procedure: k14895 
o|inlining procedure: k14895 
o|substituted constant variable: a14902 
o|substituted constant variable: a14904 
o|substituted constant variable: a14906 
o|substituted constant variable: a14908 
o|substituted constant variable: a14910 
o|contracted procedure: "(support.scm:1351) g34713472" 
o|contracted procedure: "(support.scm:1350) g34623463" 
o|contracted procedure: "(support.scm:1349) g34593460" 
o|inlining procedure: k14928 
o|inlining procedure: k14928 
o|inlining procedure: k14960 
o|inlining procedure: k14960 
o|substituted constant variable: a14976 
o|inlining procedure: k14993 
o|inlining procedure: k14993 
o|substituted constant variable: a15002 
o|substituted constant variable: a15053 
o|substituted constant variable: a15054 
o|inlining procedure: k15079 
o|inlining procedure: k15079 
o|inlining procedure: k15107 
o|inlining procedure: k15107 
o|contracted procedure: k15122 
o|inlining procedure: k15119 
o|inlining procedure: k15149 
o|inlining procedure: k15149 
o|inlining procedure: k15172 
o|inlining procedure: k15172 
o|inlining procedure: k15119 
o|inlining procedure: k15224 
o|inlining procedure: k15224 
o|propagated global variable: out36013605 ##sys#standard-output 
o|substituted constant variable: a15240 
o|substituted constant variable: a15241 
o|propagated global variable: out36013605 ##sys#standard-output 
o|inlining procedure: k15257 
o|inlining procedure: k15257 
o|inlining procedure: k15291 
o|inlining procedure: k15291 
o|inlining procedure: k15315 
o|inlining procedure: k15315 
o|inlining procedure: k15318 
o|inlining procedure: k15318 
o|inlining procedure: k15375 
o|inlining procedure: k15401 
o|inlining procedure: k15401 
o|substituted constant variable: a15429 
o|substituted constant variable: a15442 
o|contracted procedure: "(support.scm:1498) g37093710" 
o|inlining procedure: k15375 
o|inlining procedure: k15520 
o|contracted procedure: "(support.scm:1490) g36723681" 
o|inlining procedure: k15520 
o|inlining procedure: k15554 
o|contracted procedure: "(support.scm:1489) g36413650" 
o|contracted procedure: "(support.scm:1489) g36533654" 
o|inlining procedure: k15554 
o|inlining procedure: k15601 
o|inlining procedure: k15601 
o|inlining procedure: k15613 
o|inlining procedure: k15613 
o|inlining procedure: "(support.scm:1523) fits?3723" 
o|inlining procedure: k15632 
o|inlining procedure: "(support.scm:1525) fits?3723" 
o|inlining procedure: "(support.scm:1525) getsize3722" 
o|inlining procedure: k15632 
o|inlining procedure: "(support.scm:1528) fits?3723" 
o|inlining procedure: "(support.scm:1527) getsize3722" 
o|propagated global variable: out37613765 ##sys#standard-output 
o|substituted constant variable: a15707 
o|substituted constant variable: a15708 
o|propagated global variable: out37983802 ##sys#standard-output 
o|substituted constant variable: a15751 
o|substituted constant variable: a15752 
o|inlining procedure: k15741 
o|inlining procedure: k15768 
o|propagated global variable: out38083812 ##sys#standard-output 
o|substituted constant variable: a15775 
o|substituted constant variable: a15776 
o|inlining procedure: k15768 
o|propagated global variable: out38083812 ##sys#standard-output 
o|propagated global variable: out37983802 ##sys#standard-output 
o|inlining procedure: k15741 
o|inlining procedure: k15801 
o|inlining procedure: k15801 
o|propagated global variable: out37613765 ##sys#standard-output 
o|contracted procedure: "(support.scm:1541) g37583759" 
o|contracted procedure: "(support.scm:1540) g37553756" 
o|contracted procedure: "(support.scm:1539) g37523753" 
o|inlining procedure: k15824 
o|inlining procedure: k15849 
o|inlining procedure: k15849 
o|inlining procedure: k15824 
o|inlining procedure: k15873 
o|inlining procedure: k15873 
o|inlining procedure: k15910 
o|inlining procedure: k15910 
o|substituted constant variable: a15923 
o|substituted constant variable: a15934 
o|inlining procedure: k15930 
o|substituted constant variable: a15956 
o|inlining procedure: k15930 
o|inlining procedure: k15967 
o|inlining procedure: k15982 
o|inlining procedure: k15982 
o|inlining procedure: k15967 
o|contracted procedure: "(support.scm:1618) g38673868" 
o|contracted procedure: "(support.scm:1621) g38843885" 
o|inlining procedure: k16044 
o|inlining procedure: k16044 
o|substituted constant variable: a16060 
o|substituted constant variable: a16062 
o|contracted procedure: "(support.scm:1639) g39343935" 
o|contracted procedure: "(support.scm:1640) g39453946" 
o|inlining procedure: k16112 
o|inlining procedure: k16158 
o|contracted procedure: "(support.scm:1649) g39703977" 
o|inlining procedure: k16158 
o|substituted constant variable: a16183 
o|substituted constant variable: a16184 
o|inlining procedure: k16112 
o|substituted constant variable: constant25 
o|substituted constant variable: a16251 
o|substituted constant variable: a16252 
o|contracted procedure: "(support.scm:513) g10081009" 
o|contracted procedure: "(support.scm:513) g10051006" 
o|replaced variables: 2931 
o|removed binding forms: 624 
o|removed side-effect free assignment to unused variable: constant25 
o|propagated global variable: out6165 ##sys#standard-output 
o|propagated global variable: out7781 ##compiler#collected-debugging-output 
o|substituted constant variable: r496816302 
o|inlining procedure: k4982 
o|substituted constant variable: r496816303 
o|inlining procedure: k4991 
o|propagated global variable: out114118 ##compiler#collected-debugging-output 
o|converted assignments to bindings: (collect99) 
o|substituted constant variable: r522716314 
o|converted assignments to bindings: (err211) 
o|substituted constant variable: r533616320 
o|substituted constant variable: r537016322 
o|substituted constant variable: r554216330 
o|substituted constant variable: r558716332 
o|substituted constant variable: r558716333 
o|substituted constant variable: r562416339 
o|substituted constant variable: r589616363 
o|substituted constant variable: r601016379 
o|substituted constant variable: r604816380 
o|substituted constant variable: r616616390 
o|substituted constant variable: mark651 
o|substituted constant variable: mark617 
o|substituted constant variable: mark602 
o|substituted constant variable: mark568 
o|substituted constant variable: mark553 
o|substituted constant variable: r652816413 
o|substituted constant variable: r654616415 
o|substituted constant variable: r671716425 
o|propagated global variable: out738742 ##sys#standard-output 
o|propagated global variable: out947951 ##sys#standard-output 
o|inlining procedure: k6871 
o|propagated global variable: out940944 ##sys#standard-output 
o|propagated global variable: out899903 ##sys#standard-output 
o|propagated global variable: out913917 ##sys#standard-output 
o|propagated global variable: out927931 ##sys#standard-output 
o|propagated global variable: out852856 ##sys#standard-output 
o|propagated global variable: out883887 ##sys#standard-output 
o|substituted constant variable: c1024 
o|substituted constant variable: s1026 
o|substituted constant variable: c1031 
o|substituted constant variable: s1033 
o|substituted constant variable: p1058 
o|substituted constant variable: r767316489 
o|substituted constant variable: c1094 
o|substituted constant variable: c1156 
o|substituted constant variable: c1161 
o|substituted constant variable: c1174 
o|substituted constant variable: c1179 
o|substituted constant variable: p1180 
o|substituted constant variable: s1181 
o|substituted constant variable: c1184 
o|substituted constant variable: s1259 
o|substituted constant variable: c1262 
o|substituted constant variable: s1264 
o|substituted constant variable: c1270 
o|substituted constant variable: c1302 
o|substituted constant variable: c1350 
o|substituted constant variable: c1383 
o|substituted constant variable: mark1393 
o|substituted constant variable: c1427 
o|substituted constant variable: c1786 
o|substituted constant variable: p1787 
o|substituted constant variable: c1835 
o|substituted constant variable: c1840 
o|substituted constant variable: c1845 
o|removed side-effect free assignment to unused variable: rename1886 
o|substituted constant variable: s1914 
o|substituted constant variable: c1919 
o|substituted constant variable: c1928 
o|substituted constant variable: c1999 
o|substituted constant variable: r1014216625 
o|substituted constant variable: r1014216625 
o|substituted constant variable: r1072016649 
o|substituted constant variable: r1075516652 
o|substituted constant variable: r1079616654 
o|substituted constant variable: mark2209 
o|substituted constant variable: r1073816656 
o|substituted constant variable: mark2191 
o|substituted constant variable: mark2272 
o|substituted constant variable: r1096116665 
o|substituted constant variable: r1104316671 
o|substituted constant variable: r1100016673 
o|substituted constant variable: r1109916675 
o|substituted constant variable: r1114816676 
o|substituted constant variable: r1118816679 
o|substituted constant variable: r1129416685 
o|substituted constant variable: r1124916687 
o|substituted constant variable: r1137716691 
o|substituted constant variable: r1141816695 
o|substituted constant variable: r1146016699 
o|substituted constant variable: r1146016699 
o|propagated global variable: out24912495 ##sys#standard-output 
o|propagated global variable: out25012505 ##sys#standard-output 
o|propagated global variable: out25092513 ##sys#standard-output 
o|propagated global variable: out25172521 ##sys#standard-output 
o|propagated global variable: out25252529 ##sys#standard-output 
o|propagated global variable: out25332537 ##sys#standard-output 
o|substituted constant variable: r1277916795 
o|substituted constant variable: r1281016799 
o|substituted constant variable: r1288016806 
o|substituted constant variable: r1295616817 
o|removed side-effect free assignment to unused variable: err3016 
o|substituted constant variable: r1395516931 
o|substituted constant variable: r1401016932 
o|substituted constant variable: r1402516934 
o|substituted constant variable: r1404316936 
o|substituted constant variable: r1404316937 
o|substituted constant variable: r1405116938 
o|substituted constant variable: r1406616940 
o|substituted constant variable: r1406616941 
o|substituted constant variable: r1407416942 
o|substituted constant variable: r1408616944 
o|substituted constant variable: r1408616945 
o|substituted constant variable: r1409416946 
o|substituted constant variable: r1412716950 
o|substituted constant variable: r1413916952 
o|substituted constant variable: r1415116954 
o|substituted constant variable: r1416316956 
o|substituted constant variable: r1417516958 
o|substituted constant variable: r1419016960 
o|substituted constant variable: r1420516962 
o|substituted constant variable: r1422316964 
o|substituted constant variable: r1423616966 
o|substituted constant variable: r1425816968 
o|substituted constant variable: r1475517004 
o|converted assignments to bindings: (resolve3571) 
o|substituted constant variable: r1522517035 
o|propagated global variable: out36013605 ##sys#standard-output 
o|substituted constant variable: r1531917043 
o|removed side-effect free assignment to unused variable: getsize3722 
o|removed side-effect free assignment to unused variable: fits?3723 
o|propagated global variable: out37613765 ##sys#standard-output 
o|propagated global variable: out37983802 ##sys#standard-output 
o|propagated global variable: out38083812 ##sys#standard-output 
o|substituted constant variable: r1585017098 
o|substituted constant variable: r1585017098 
o|substituted constant variable: r1596817111 
o|substituted constant variable: mark3875 
o|substituted constant variable: mark3892 
o|substituted constant variable: r1604517112 
o|substituted constant variable: mark3937 
o|substituted constant variable: mark3948 
o|substituted constant variable: r1611317117 
o|simplifications: ((let . 3)) 
o|replaced variables: 76 
o|removed binding forms: 2855 
o|substituted constant variable: r49681630217123 
o|substituted constant variable: r49681630317125 
o|inlining procedure: k6431 
o|inlining procedure: k6406 
o|inlining procedure: k6383 
o|inlining procedure: k6358 
o|inlining procedure: k6335 
o|inlining procedure: k7050 
o|inlining procedure: k7050 
o|inlining procedure: k7050 
o|inlining procedure: k7050 
o|inlining procedure: k7050 
o|inlining procedure: k7050 
o|inlining procedure: k7050 
o|inlining procedure: k7050 
o|inlining procedure: k10875 
o|inlining procedure: k11193 
o|inlining procedure: k12394 
o|inlining procedure: k12766 
o|inlining procedure: k12766 
o|inlining procedure: k12766 
o|inlining procedure: k12797 
o|inlining procedure: k12797 
o|inlining procedure: k12797 
o|inlining procedure: k12961 
o|inlining procedure: k12961 
o|inlining procedure: k12961 
o|inlining procedure: k12961 
o|inlining procedure: k12961 
o|inlining procedure: k12961 
o|inlining procedure: k12961 
o|inlining procedure: k12961 
o|inlining procedure: k14801 
o|inlining procedure: k14801 
o|inlining procedure: k15312 
o|inlining procedure: k15312 
o|inlining procedure: k15993 
o|inlining procedure: k16013 
o|inlining procedure: k16066 
o|inlining procedure: k16210 
o|replaced variables: 104 
o|removed binding forms: 205 
o|substituted constant variable: r643217388 
o|substituted constant variable: r640717391 
o|substituted constant variable: r638417392 
o|substituted constant variable: r635917395 
o|substituted constant variable: r633617396 
o|inlining procedure: k8131 
o|substituted constant variable: r1087617507 
o|substituted constant variable: r1276717525 
o|substituted constant variable: r1276717525 
o|substituted constant variable: r1276717525 
o|substituted constant variable: r1276717528 
o|substituted constant variable: r1276717528 
o|substituted constant variable: r1276717528 
o|substituted constant variable: r1276717531 
o|substituted constant variable: r1276717531 
o|substituted constant variable: r1276717531 
o|substituted constant variable: r1279817534 
o|substituted constant variable: r1279817534 
o|substituted constant variable: r1279817534 
o|substituted constant variable: r1279817537 
o|substituted constant variable: r1279817537 
o|substituted constant variable: r1279817537 
o|substituted constant variable: r1279817540 
o|substituted constant variable: r1279817540 
o|substituted constant variable: r1279817540 
o|substituted constant variable: r1531317579 
o|substituted constant variable: r1531317579 
o|substituted constant variable: r1531317579 
o|substituted constant variable: r1531317582 
o|substituted constant variable: r1531317582 
o|substituted constant variable: r1531317582 
o|contracted procedure: k15639 
o|contracted procedure: k15642 
o|substituted constant variable: r1599417597 
o|substituted constant variable: r1601417598 
o|substituted constant variable: r1606717599 
o|replaced variables: 7 
o|removed binding forms: 128 
o|removed conditional forms: 8 
o|substituted constant variable: r813217652 
o|removed binding forms: 25 
o|removed conditional forms: 1 
o|removed binding forms: 1 
o|simplifications: ((if . 70) (##core#call . 1447)) 
o|  call simplifications:
o|    ##sys#fudge
o|    char=?
o|    read-char	3
o|    ##sys#size
o|    fx>	2
o|    write-char	6
o|    flonum?
o|    arithmetic-shift	3
o|    procedure?
o|    fx+	2
o|    string-length	4
o|    >	2
o|    string-ref	2
o|    list?	4
o|    vector-ref	6
o|    <
o|    *
o|    -	2
o|    first	19
o|    positive?
o|    not-pair?	5
o|    ##sys#call-with-values	5
o|    cdddr
o|    second	10
o|    third	6
o|    fourth	4
o|    caddr	4
o|    cadr	24
o|    integer?
o|    inexact->exact
o|    ##sys#check-structure	7
o|    ##sys#block-ref	4
o|    ##sys#structure?	5
o|    ##sys#make-structure	32
o|    cdar	6
o|    caar	5
o|    length	8
o|    values	4
o|    +	7
o|    ##sys#setslot	36
o|    assq	17
o|    alist-cons	8
o|    atom?
o|    ##sys#apply	2
o|    ##sys#cons	7
o|    equal?	3
o|    ##sys#list	131
o|    fixnum?	3
o|    number?	4
o|    char?	4
o|    boolean?	4
o|    eof-object?	5
o|    vector?	8
o|    member
o|    cddr	3
o|    list	50
o|    string=?	2
o|    not	12
o|    ##sys#foreign-fixnum-argument	2
o|    char-alphabetic?	2
o|    char-numeric?
o|    char->integer
o|    fx>=	2
o|    fx<	4
o|    string->list	3
o|    list->string
o|    zero?	3
o|    sub1	4
o|    string?	4
o|    eqv?
o|    eq?	382
o|    add1	4
o|    null?	41
o|    cons	91
o|    car	52
o|    cdr	20
o|    ##sys#check-list	40
o|    ##sys#slot	184
o|    symbol?	19
o|    memq	9
o|    pair?	69
o|    apply	5
o|contracted procedure: k4843 
o|contracted procedure: k4871 
o|contracted procedure: k4905 
o|contracted procedure: k4935 
o|contracted procedure: k4945 
o|contracted procedure: k4949 
o|contracted procedure: k5031 
o|propagated global variable: out114118 ##compiler#collected-debugging-output 
o|contracted procedure: k5047 
o|contracted procedure: k5057 
o|contracted procedure: k5061 
o|contracted procedure: k5131 
o|contracted procedure: k5149 
o|contracted procedure: k5159 
o|contracted procedure: k5163 
o|contracted procedure: k5202 
o|contracted procedure: k5206 
o|contracted procedure: k5210 
o|contracted procedure: k5229 
o|contracted procedure: k5235 
o|contracted procedure: k5255 
o|contracted procedure: k5276 
o|contracted procedure: k5288 
o|contracted procedure: k5294 
o|contracted procedure: k5300 
o|contracted procedure: k5309 
o|contracted procedure: k5319 
o|contracted procedure: k5323 
o|contracted procedure: k5338 
o|contracted procedure: k5357 
o|contracted procedure: k5344 
o|contracted procedure: k5353 
o|contracted procedure: k5372 
o|contracted procedure: k5391 
o|contracted procedure: k5378 
o|contracted procedure: k5387 
o|contracted procedure: k5400 
o|contracted procedure: k5406 
o|contracted procedure: k5430 
o|contracted procedure: k5436 
o|contracted procedure: k5490 
o|contracted procedure: k5493 
o|contracted procedure: k5503 
o|contracted procedure: k5513 
o|contracted procedure: k5527 
o|contracted procedure: k5544 
o|contracted procedure: k5547 
o|contracted procedure: k5550 
o|contracted procedure: k5556 
o|contracted procedure: k5583 
o|contracted procedure: k5589 
o|contracted procedure: k5605 
o|contracted procedure: k5626 
o|contracted procedure: k5633 
o|contracted procedure: k5636 
o|contracted procedure: k5645 
o|contracted procedure: k5651 
o|contracted procedure: k5671 
o|contracted procedure: k5678 
o|contracted procedure: k5687 
o|contracted procedure: k5702 
o|contracted procedure: k5715 
o|contracted procedure: k5722 
o|contracted procedure: k5731 
o|contracted procedure: k5790 
o|contracted procedure: k5743 
o|contracted procedure: k5786 
o|contracted procedure: k5763 
o|inlining procedure: k5760 
o|inlining procedure: k5760 
o|contracted procedure: k5805 
o|contracted procedure: k5821 
o|contracted procedure: k5847 
o|contracted procedure: k5853 
o|contracted procedure: k5859 
o|contracted procedure: k5865 
o|contracted procedure: k5871 
o|contracted procedure: k5883 
o|contracted procedure: k5898 
o|contracted procedure: k5909 
o|contracted procedure: k5915 
o|contracted procedure: k5921 
o|contracted procedure: k5927 
o|contracted procedure: k5945 
o|contracted procedure: k5951 
o|contracted procedure: k5957 
o|contracted procedure: k5963 
o|contracted procedure: k5972 
o|contracted procedure: k5985 
o|contracted procedure: k5991 
o|contracted procedure: k6012 
o|contracted procedure: k6028 
o|contracted procedure: k6050 
o|contracted procedure: k6108 
o|contracted procedure: k6056 
o|contracted procedure: k6064 
o|contracted procedure: k6089 
o|contracted procedure: k6079 
o|contracted procedure: k6168 
o|contracted procedure: k6182 
o|contracted procedure: k6174 
o|contracted procedure: k6235 
o|contracted procedure: k6241 
o|contracted procedure: k6250 
o|contracted procedure: k6260 
o|contracted procedure: k6264 
o|contracted procedure: k6274 
o|contracted procedure: k6278 
o|contracted procedure: k6321 
o|contracted procedure: k6317 
o|contracted procedure: k6289 
o|contracted procedure: k6313 
o|contracted procedure: k6309 
o|contracted procedure: k6293 
o|contracted procedure: k6305 
o|contracted procedure: k6301 
o|contracted procedure: k6297 
o|contracted procedure: k6285 
o|contracted procedure: k6373 
o|contracted procedure: k6421 
o|contracted procedure: k6446 
o|contracted procedure: k6458 
o|contracted procedure: k6468 
o|contracted procedure: k6472 
o|contracted procedure: k6437 
o|contracted procedure: k6431 
o|propagated global variable: g639641 ##compiler#internal-bindings 
o|contracted procedure: k6481 
o|contracted procedure: k6491 
o|contracted procedure: k6495 
o|contracted procedure: k6401 
o|contracted procedure: k6412 
o|contracted procedure: k6406 
o|contracted procedure: k6389 
o|contracted procedure: k6383 
o|propagated global variable: g590592 extended-bindings 
o|contracted procedure: k6504 
o|contracted procedure: k6514 
o|contracted procedure: k6518 
o|contracted procedure: k6353 
o|contracted procedure: k6364 
o|contracted procedure: k6358 
o|contracted procedure: k6341 
o|contracted procedure: k6335 
o|propagated global variable: g541543 standard-bindings 
o|contracted procedure: k6530 
o|contracted procedure: k6566 
o|contracted procedure: k6586 
o|contracted procedure: k6582 
o|contracted procedure: k6600 
o|contracted procedure: k6596 
o|contracted procedure: k6612 
o|contracted procedure: k6626 
o|contracted procedure: k6622 
o|contracted procedure: k6637 
o|contracted procedure: k6641 
o|contracted procedure: k6633 
o|contracted procedure: k6652 
o|contracted procedure: k6648 
o|contracted procedure: k6667 
o|contracted procedure: k6681 
o|contracted procedure: k6677 
o|contracted procedure: k6692 
o|contracted procedure: k6688 
o|contracted procedure: k6703 
o|contracted procedure: k6699 
o|contracted procedure: k6706 
o|contracted procedure: k6726 
o|contracted procedure: k6732 
o|contracted procedure: k6750 
o|contracted procedure: k6754 
o|contracted procedure: k6767 
o|contracted procedure: k6798 
o|contracted procedure: k6801 
o|contracted procedure: k6813 
o|contracted procedure: k6835 
o|contracted procedure: k6831 
o|contracted procedure: k6816 
o|contracted procedure: k6819 
o|contracted procedure: k6827 
o|contracted procedure: k6856 
o|contracted procedure: k6877 
o|contracted procedure: k6890 
o|contracted procedure: k6893 
o|contracted procedure: k6906 
o|contracted procedure: k6931 
o|contracted procedure: k6940 
o|contracted procedure: k6922 
o|contracted procedure: k6968 
o|contracted procedure: k6977 
o|contracted procedure: k6959 
o|contracted procedure: k7005 
o|contracted procedure: k7014 
o|contracted procedure: k6996 
o|contracted procedure: k7021 
o|contracted procedure: k7028 
o|contracted procedure: k7035 
o|contracted procedure: k7044 
o|contracted procedure: k7047 
o|contracted procedure: k7058 
o|contracted procedure: k7082 
o|contracted procedure: k7078 
o|contracted procedure: k7074 
o|contracted procedure: k7088 
o|contracted procedure: k7095 
o|contracted procedure: k7101 
o|contracted procedure: k7105 
o|contracted procedure: k7111 
o|contracted procedure: k7117 
o|contracted procedure: k7121 
o|contracted procedure: k7127 
o|contracted procedure: k7131 
o|contracted procedure: k7137 
o|contracted procedure: k7159 
o|contracted procedure: k7163 
o|contracted procedure: k7169 
o|contracted procedure: k7173 
o|contracted procedure: k7179 
o|contracted procedure: k7183 
o|contracted procedure: k7195 
o|contracted procedure: k7201 
o|contracted procedure: k7207 
o|contracted procedure: k7213 
o|contracted procedure: k7219 
o|contracted procedure: k7225 
o|contracted procedure: k7231 
o|contracted procedure: k7266 
o|contracted procedure: k7272 
o|contracted procedure: k7278 
o|contracted procedure: k7284 
o|contracted procedure: k7290 
o|contracted procedure: k7296 
o|contracted procedure: k7302 
o|contracted procedure: k7308 
o|contracted procedure: k7314 
o|contracted procedure: k7320 
o|contracted procedure: k7326 
o|contracted procedure: k7332 
o|contracted procedure: k7338 
o|contracted procedure: k7344 
o|contracted procedure: k7350 
o|contracted procedure: k7356 
o|contracted procedure: k7362 
o|contracted procedure: k7368 
o|contracted procedure: k7374 
o|contracted procedure: k7444 
o|contracted procedure: k7453 
o|contracted procedure: k7462 
o|contracted procedure: k7471 
o|contracted procedure: k7480 
o|contracted procedure: k7489 
o|contracted procedure: k7516 
o|contracted procedure: k7531 
o|contracted procedure: k7543 
o|contracted procedure: k7557 
o|contracted procedure: k7563 
o|contracted procedure: k8757 
o|contracted procedure: k7572 
o|contracted procedure: k7579 
o|contracted procedure: k7582 
o|contracted procedure: k7596 
o|contracted procedure: k7600 
o|contracted procedure: k7612 
o|contracted procedure: k7615 
o|contracted procedure: k7618 
o|contracted procedure: k7626 
o|contracted procedure: k7634 
o|contracted procedure: k7643 
o|contracted procedure: k7646 
o|contracted procedure: k7653 
o|contracted procedure: k7669 
o|contracted procedure: k7675 
o|contracted procedure: k7682 
o|contracted procedure: k7688 
o|contracted procedure: k7691 
o|contracted procedure: k7694 
o|contracted procedure: k7700 
o|contracted procedure: k7715 
o|contracted procedure: k7740 
o|contracted procedure: k7749 
o|contracted procedure: k7752 
o|contracted procedure: k7755 
o|contracted procedure: k7762 
o|contracted procedure: k7775 
o|contracted procedure: k7778 
o|contracted procedure: k7781 
o|contracted procedure: k7789 
o|contracted procedure: k7797 
o|contracted procedure: k7809 
o|contracted procedure: k7812 
o|contracted procedure: k7815 
o|contracted procedure: k7823 
o|contracted procedure: k7831 
o|contracted procedure: k7723 
o|contracted procedure: k7840 
o|contracted procedure: k7843 
o|contracted procedure: k7871 
o|contracted procedure: k7855 
o|contracted procedure: k7859 
o|contracted procedure: k7867 
o|contracted procedure: k7877 
o|contracted procedure: k7905 
o|contracted procedure: k7909 
o|contracted procedure: k7889 
o|contracted procedure: k7893 
o|contracted procedure: k7901 
o|contracted procedure: k7915 
o|contracted procedure: k7922 
o|contracted procedure: k7926 
o|contracted procedure: k7935 
o|contracted procedure: k7968 
o|contracted procedure: k7947 
o|contracted procedure: k7964 
o|contracted procedure: k7955 
o|contracted procedure: k8047 
o|contracted procedure: k7978 
o|contracted procedure: k8010 
o|contracted procedure: k7990 
o|contracted procedure: k7998 
o|contracted procedure: k8018 
o|contracted procedure: k8043 
o|contracted procedure: k8027 
o|contracted procedure: k8031 
o|contracted procedure: k8061 
o|contracted procedure: k8064 
o|contracted procedure: k8082 
o|contracted procedure: k8087 
o|contracted procedure: k8099 
o|contracted procedure: k8102 
o|contracted procedure: k8105 
o|contracted procedure: k8113 
o|contracted procedure: k8121 
o|contracted procedure: k8137 
o|contracted procedure: k8131 
o|contracted procedure: k8128 
o|contracted procedure: k8148 
o|contracted procedure: k8151 
o|contracted procedure: k8215 
o|contracted procedure: k8165 
o|contracted procedure: k8169 
o|contracted procedure: k8174 
o|contracted procedure: k8186 
o|contracted procedure: k8189 
o|contracted procedure: k8192 
o|contracted procedure: k8200 
o|contracted procedure: k8208 
o|contracted procedure: k8221 
o|contracted procedure: k8239 
o|contracted procedure: k8255 
o|contracted procedure: k8251 
o|contracted procedure: k8261 
o|contracted procedure: k8264 
o|contracted procedure: k8326 
o|contracted procedure: k8276 
o|contracted procedure: k8280 
o|contracted procedure: k8285 
o|contracted procedure: k8297 
o|contracted procedure: k8300 
o|contracted procedure: k8303 
o|contracted procedure: k8311 
o|contracted procedure: k8319 
o|contracted procedure: k8332 
o|contracted procedure: k8387 
o|contracted procedure: k8335 
o|contracted procedure: k8383 
o|contracted procedure: k8363 
o|contracted procedure: k8379 
o|contracted procedure: k8367 
o|contracted procedure: k8371 
o|contracted procedure: k8347 
o|contracted procedure: k8351 
o|contracted procedure: k8393 
o|contracted procedure: k8410 
o|contracted procedure: k8414 
o|contracted procedure: k8419 
o|contracted procedure: k8431 
o|contracted procedure: k8434 
o|contracted procedure: k8437 
o|contracted procedure: k8445 
o|contracted procedure: k8453 
o|contracted procedure: k8462 
o|contracted procedure: k8474 
o|contracted procedure: k8478 
o|contracted procedure: k8482 
o|contracted procedure: k8494 
o|contracted procedure: k8497 
o|contracted procedure: k8500 
o|contracted procedure: k8508 
o|contracted procedure: k8516 
o|contracted procedure: k8543 
o|contracted procedure: k8547 
o|contracted procedure: k8550 
o|contracted procedure: k8562 
o|contracted procedure: k8565 
o|contracted procedure: k8568 
o|contracted procedure: k8576 
o|contracted procedure: k8584 
o|contracted procedure: k8623 
o|contracted procedure: k8628 
o|contracted procedure: k8634 
o|contracted procedure: k8640 
o|contracted procedure: k8712 
o|contracted procedure: k8716 
o|contracted procedure: k8728 
o|contracted procedure: k8731 
o|contracted procedure: k8734 
o|contracted procedure: k8742 
o|contracted procedure: k8750 
o|contracted procedure: k8766 
o|contracted procedure: k8786 
o|contracted procedure: k8794 
o|contracted procedure: k8802 
o|contracted procedure: k8808 
o|contracted procedure: k8818 
o|contracted procedure: k8821 
o|contracted procedure: k8833 
o|contracted procedure: k8836 
o|contracted procedure: k8839 
o|contracted procedure: k8847 
o|contracted procedure: k8855 
o|contracted procedure: k8864 
o|contracted procedure: k8875 
o|contracted procedure: k8878 
o|contracted procedure: k8871 
o|contracted procedure: k8890 
o|contracted procedure: k8893 
o|contracted procedure: k8896 
o|contracted procedure: k8904 
o|contracted procedure: k8912 
o|contracted procedure: k8921 
o|contracted procedure: k8930 
o|contracted procedure: k8933 
o|contracted procedure: k8939 
o|inlining procedure: k8942 
o|contracted procedure: k8950 
o|inlining procedure: k8942 
o|contracted procedure: k8956 
o|inlining procedure: k8942 
o|contracted procedure: k8968 
o|contracted procedure: k8975 
o|contracted procedure: k8978 
o|contracted procedure: k8987 
o|contracted procedure: k8990 
o|contracted procedure: k9046 
o|contracted procedure: k9010 
o|contracted procedure: k9036 
o|contracted procedure: k9040 
o|contracted procedure: k9032 
o|contracted procedure: k9013 
o|contracted procedure: k9016 
o|contracted procedure: k9024 
o|contracted procedure: k9028 
o|contracted procedure: k9058 
o|contracted procedure: k9061 
o|contracted procedure: k9064 
o|contracted procedure: k9072 
o|contracted procedure: k9080 
o|contracted procedure: k9089 
o|contracted procedure: k9111 
o|contracted procedure: k9096 
o|contracted procedure: k9100 
o|contracted procedure: k9108 
o|contracted procedure: k9117 
o|contracted procedure: k9124 
o|contracted procedure: k9132 
o|contracted procedure: k9138 
o|contracted procedure: k9145 
o|contracted procedure: k9151 
o|contracted procedure: k9158 
o|contracted procedure: k9170 
o|contracted procedure: k9181 
o|contracted procedure: k9187 
o|contracted procedure: k9194 
o|contracted procedure: k9202 
o|contracted procedure: k9221 
o|contracted procedure: k9209 
o|contracted procedure: k9229 
o|contracted procedure: k9233 
o|contracted procedure: k9239 
o|contracted procedure: k9242 
o|contracted procedure: k9245 
o|contracted procedure: k9257 
o|contracted procedure: k9260 
o|contracted procedure: k9263 
o|contracted procedure: k9271 
o|contracted procedure: k9279 
o|contracted procedure: k9288 
o|contracted procedure: k9295 
o|contracted procedure: k9299 
o|contracted procedure: k9302 
o|contracted procedure: k9314 
o|contracted procedure: k9317 
o|contracted procedure: k9320 
o|contracted procedure: k9328 
o|contracted procedure: k9336 
o|contracted procedure: k9345 
o|contracted procedure: k9354 
o|contracted procedure: k9361 
o|contracted procedure: k9370 
o|contracted procedure: k9385 
o|contracted procedure: k9392 
o|contracted procedure: k9396 
o|contracted procedure: k9400 
o|contracted procedure: k9412 
o|contracted procedure: k9426 
o|contracted procedure: k9430 
o|contracted procedure: k9442 
o|contracted procedure: k9445 
o|contracted procedure: k9448 
o|contracted procedure: k9456 
o|contracted procedure: k9464 
o|contracted procedure: k9471 
o|contracted procedure: k9477 
o|contracted procedure: k9480 
o|contracted procedure: k9487 
o|contracted procedure: k9490 
o|contracted procedure: k9502 
o|contracted procedure: k9505 
o|contracted procedure: k9508 
o|contracted procedure: k9516 
o|contracted procedure: k9524 
o|contracted procedure: k9538 
o|contracted procedure: k9541 
o|contracted procedure: k9553 
o|contracted procedure: k9556 
o|contracted procedure: k9559 
o|contracted procedure: k9567 
o|contracted procedure: k9575 
o|contracted procedure: k9588 
o|contracted procedure: k9594 
o|contracted procedure: k9635 
o|contracted procedure: k9697 
o|contracted procedure: k9662 
o|contracted procedure: k9677 
o|contracted procedure: k9693 
o|contracted procedure: k9742 
o|contracted procedure: k9746 
o|contracted procedure: k9766 
o|contracted procedure: k9770 
o|contracted procedure: k9777 
o|contracted procedure: k9800 
o|contracted procedure: k9796 
o|contracted procedure: k9792 
o|contracted procedure: k9810 
o|contracted procedure: k9813 
o|contracted procedure: k9825 
o|contracted procedure: k9828 
o|contracted procedure: k9831 
o|contracted procedure: k9839 
o|contracted procedure: k9847 
o|contracted procedure: k9856 
o|contracted procedure: k9859 
o|contracted procedure: k9862 
o|contracted procedure: k9882 
o|contracted procedure: k9890 
o|contracted procedure: k9898 
o|contracted procedure: k9904 
o|contracted procedure: k9918 
o|contracted procedure: k9921 
o|contracted procedure: k9943 
o|contracted procedure: k9955 
o|contracted procedure: k9959 
o|contracted procedure: k9967 
o|contracted procedure: k9975 
o|contracted procedure: k9981 
o|contracted procedure: k9984 
o|contracted procedure: k9993 
o|contracted procedure: k10008 
o|contracted procedure: k10012 
o|contracted procedure: k10020 
o|contracted procedure: k10024 
o|contracted procedure: k10030 
o|contracted procedure: k10037 
o|contracted procedure: k10043 
o|contracted procedure: k10054 
o|contracted procedure: k10129 
o|contracted procedure: k10137 
o|contracted procedure: k10072 
o|contracted procedure: k10076 
o|contracted procedure: k10084 
o|contracted procedure: k10096 
o|contracted procedure: k10099 
o|contracted procedure: k10102 
o|contracted procedure: k10110 
o|contracted procedure: k10118 
o|contracted procedure: k10148 
o|contracted procedure: k10151 
o|contracted procedure: k10199 
o|contracted procedure: k10163 
o|contracted procedure: k10189 
o|contracted procedure: k10193 
o|contracted procedure: k10185 
o|contracted procedure: k10166 
o|contracted procedure: k10169 
o|contracted procedure: k10177 
o|contracted procedure: k10181 
o|contracted procedure: k10211 
o|contracted procedure: k10214 
o|contracted procedure: k10217 
o|contracted procedure: k10225 
o|contracted procedure: k10233 
o|contracted procedure: k10252 
o|contracted procedure: k10260 
o|contracted procedure: k10272 
o|contracted procedure: k10275 
o|contracted procedure: k10278 
o|contracted procedure: k10286 
o|contracted procedure: k10294 
o|contracted procedure: k10355 
o|contracted procedure: k10319 
o|contracted procedure: k10345 
o|contracted procedure: k10349 
o|contracted procedure: k10341 
o|contracted procedure: k10322 
o|contracted procedure: k10325 
o|contracted procedure: k10333 
o|contracted procedure: k10337 
o|contracted procedure: k10373 
o|contracted procedure: k10409 
o|contracted procedure: k10418 
o|contracted procedure: k10427 
o|contracted procedure: k10448 
o|contracted procedure: k10461 
o|contracted procedure: k10465 
o|contracted procedure: k10473 
o|contracted procedure: k10476 
o|contracted procedure: k10452 
o|contracted procedure: k10488 
o|contracted procedure: k10491 
o|contracted procedure: k10494 
o|contracted procedure: k10502 
o|contracted procedure: k10510 
o|contracted procedure: k10534 
o|contracted procedure: k10538 
o|contracted procedure: k10542 
o|contracted procedure: k10547 
o|contracted procedure: k10559 
o|contracted procedure: k10562 
o|contracted procedure: k10565 
o|contracted procedure: k10573 
o|contracted procedure: k10581 
o|contracted procedure: k10610 
o|contracted procedure: k10622 
o|contracted procedure: k10632 
o|contracted procedure: k10636 
o|contracted procedure: k10639 
o|contracted procedure: k10645 
o|contracted procedure: k10683 
o|contracted procedure: k10693 
o|contracted procedure: k10697 
o|contracted procedure: k10713 
o|contracted procedure: k10837 
o|contracted procedure: k10728 
o|contracted procedure: k10731 
o|contracted procedure: k10740 
o|contracted procedure: k10817 
o|contracted procedure: k10748 
o|contracted procedure: k10775 
o|contracted procedure: k10783 
o|contracted procedure: k10779 
o|contracted procedure: k10792 
o|contracted procedure: k10798 
o|contracted procedure: k10805 
o|contracted procedure: k10828 
o|contracted procedure: k10824 
o|contracted procedure: k10870 
o|contracted procedure: k10894 
o|contracted procedure: k10881 
o|contracted procedure: k10875 
o|contracted procedure: k10902 
o|contracted procedure: k10911 
o|contracted procedure: k10923 
o|contracted procedure: k10932 
o|contracted procedure: k10936 
o|contracted procedure: k10948 
o|contracted procedure: k10957 
o|contracted procedure: k10974 
o|contracted procedure: k10978 
o|contracted procedure: k10987 
o|contracted procedure: k11088 
o|contracted procedure: k11092 
o|contracted procedure: k10996 
o|contracted procedure: k11014 
o|contracted procedure: k11018 
o|contracted procedure: k11027 
o|contracted procedure: k11036 
o|contracted procedure: k11045 
o|contracted procedure: k11062 
o|contracted procedure: k11066 
o|contracted procedure: k11075 
o|contracted procedure: k11079 
o|contracted procedure: k11110 
o|contracted procedure: k11119 
o|contracted procedure: k11136 
o|contracted procedure: k11144 
o|contracted procedure: k11150 
o|contracted procedure: k11159 
o|contracted procedure: k11184 
o|contracted procedure: k11162 
o|contracted procedure: k11190 
o|contracted procedure: k11193 
o|contracted procedure: k11208 
o|contracted procedure: k11214 
o|contracted procedure: k11239 
o|contracted procedure: k11242 
o|contracted procedure: k11348 
o|contracted procedure: k11245 
o|contracted procedure: k11267 
o|contracted procedure: k11273 
o|contracted procedure: k11281 
o|contracted procedure: k11284 
o|contracted procedure: k11323 
o|contracted procedure: k11290 
o|contracted procedure: k11314 
o|contracted procedure: k11305 
o|contracted procedure: k11296 
o|contracted procedure: k11329 
o|contracted procedure: k11341 
o|contracted procedure: k11379 
o|contracted procedure: k11386 
o|contracted procedure: k11420 
o|contracted procedure: k11442 
o|contracted procedure: k11445 
o|contracted procedure: k11466 
o|contracted procedure: k11459 
o|inlining procedure: k11455 
o|inlining procedure: k11455 
o|contracted procedure: k11485 
o|contracted procedure: k11515 
o|contracted procedure: k11518 
o|contracted procedure: k11524 
o|contracted procedure: k11528 
o|contracted procedure: k11534 
o|contracted procedure: k11538 
o|contracted procedure: k11557 
o|contracted procedure: k11544 
o|contracted procedure: k11548 
o|contracted procedure: k11565 
o|contracted procedure: k11573 
o|contracted procedure: k11569 
o|contracted procedure: k11584 
o|contracted procedure: k11596 
o|contracted procedure: k11606 
o|contracted procedure: k11610 
o|contracted procedure: k11738 
o|contracted procedure: k11750 
o|contracted procedure: k11760 
o|contracted procedure: k11764 
o|contracted procedure: k11788 
o|contracted procedure: k11791 
o|contracted procedure: k11803 
o|contracted procedure: k11818 
o|contracted procedure: k11833 
o|contracted procedure: k11836 
o|contracted procedure: k11865 
o|contracted procedure: k11846 
o|contracted procedure: k11854 
o|contracted procedure: k11858 
o|contracted procedure: k11850 
o|contracted procedure: k11871 
o|contracted procedure: k11874 
o|contracted procedure: k11886 
o|contracted procedure: k11919 
o|contracted procedure: k11896 
o|contracted procedure: k11908 
o|contracted procedure: k11900 
o|contracted procedure: k11915 
o|contracted procedure: k11925 
o|contracted procedure: k11935 
o|contracted procedure: k11941 
o|contracted procedure: k11977 
o|contracted procedure: k11954 
o|contracted procedure: k11966 
o|contracted procedure: k11958 
o|contracted procedure: k11973 
o|contracted procedure: k11983 
o|contracted procedure: k12000 
o|contracted procedure: k11996 
o|contracted procedure: k12009 
o|contracted procedure: k12024 
o|contracted procedure: k12036 
o|contracted procedure: k12051 
o|contracted procedure: k12063 
o|contracted procedure: k12092 
o|contracted procedure: k12076 
o|contracted procedure: k12084 
o|contracted procedure: k12088 
o|contracted procedure: k12080 
o|contracted procedure: k12098 
o|contracted procedure: k12107 
o|contracted procedure: k12146 
o|contracted procedure: k12120 
o|contracted procedure: k12132 
o|contracted procedure: k12124 
o|contracted procedure: k12142 
o|contracted procedure: k12152 
o|contracted procedure: k12168 
o|contracted procedure: k12174 
o|contracted procedure: k12184 
o|contracted procedure: k12195 
o|contracted procedure: k12191 
o|contracted procedure: k12213 
o|contracted procedure: k12210 
o|contracted procedure: k12225 
o|contracted procedure: k12232 
o|contracted procedure: k12261 
o|contracted procedure: k12245 
o|contracted procedure: k12253 
o|contracted procedure: k12257 
o|contracted procedure: k12249 
o|contracted procedure: k12267 
o|contracted procedure: k12270 
o|contracted procedure: k12300 
o|contracted procedure: k12280 
o|contracted procedure: k12296 
o|contracted procedure: k12288 
o|contracted procedure: k12292 
o|contracted procedure: k12284 
o|contracted procedure: k12306 
o|contracted procedure: k12335 
o|contracted procedure: k12316 
o|contracted procedure: k12324 
o|contracted procedure: k12328 
o|contracted procedure: k12320 
o|contracted procedure: k12341 
o|contracted procedure: k12353 
o|contracted procedure: k12360 
o|contracted procedure: k12366 
o|contracted procedure: k12373 
o|contracted procedure: k12379 
o|contracted procedure: k12391 
o|contracted procedure: k12394 
o|contracted procedure: k12424 
o|contracted procedure: k12430 
o|contracted procedure: k12447 
o|contracted procedure: k12455 
o|contracted procedure: k12470 
o|contracted procedure: k12476 
o|contracted procedure: k12495 
o|contracted procedure: k12512 
o|contracted procedure: k12529 
o|contracted procedure: k12535 
o|contracted procedure: k12552 
o|contracted procedure: k12558 
o|contracted procedure: k12564 
o|contracted procedure: k12570 
o|contracted procedure: k12576 
o|contracted procedure: k12582 
o|contracted procedure: k12607 
o|contracted procedure: k12613 
o|contracted procedure: k12619 
o|contracted procedure: k12625 
o|contracted procedure: k12631 
o|contracted procedure: k12637 
o|contracted procedure: k12680 
o|contracted procedure: k12695 
o|contracted procedure: k12701 
o|contracted procedure: k12707 
o|contracted procedure: k12713 
o|contracted procedure: k12719 
o|contracted procedure: k12725 
o|contracted procedure: k12772 
o|contracted procedure: k12784 
o|contracted procedure: k12791 
o|contracted procedure: k12766 
o|contracted procedure: k12803 
o|contracted procedure: k12815 
o|contracted procedure: k12822 
o|contracted procedure: k12797 
o|contracted procedure: k12849 
o|contracted procedure: k12846 
o|contracted procedure: k12858 
o|contracted procedure: k12882 
o|contracted procedure: k12891 
o|contracted procedure: k12903 
o|contracted procedure: k12915 
o|contracted procedure: k12939 
o|contracted procedure: k12936 
o|contracted procedure: k12951 
o|contracted procedure: k12958 
o|contracted procedure: k12967 
o|contracted procedure: k12973 
o|contracted procedure: k12979 
o|contracted procedure: k12985 
o|contracted procedure: k12991 
o|contracted procedure: k12997 
o|contracted procedure: k13003 
o|contracted procedure: k12961 
o|contracted procedure: k13030 
o|contracted procedure: k13036 
o|contracted procedure: k13042 
o|contracted procedure: k13048 
o|contracted procedure: k13067 
o|contracted procedure: k13073 
o|contracted procedure: k13079 
o|contracted procedure: k13085 
o|contracted procedure: k13091 
o|contracted procedure: k13114 
o|contracted procedure: k13120 
o|contracted procedure: k13126 
o|contracted procedure: k13132 
o|contracted procedure: k13138 
o|contracted procedure: k13144 
o|contracted procedure: k13150 
o|contracted procedure: k13156 
o|contracted procedure: k13162 
o|contracted procedure: k13168 
o|contracted procedure: k13201 
o|contracted procedure: k13207 
o|contracted procedure: k13213 
o|contracted procedure: k13219 
o|contracted procedure: k13225 
o|contracted procedure: k13231 
o|contracted procedure: k13237 
o|contracted procedure: k13243 
o|contracted procedure: k13249 
o|contracted procedure: k13255 
o|contracted procedure: k13261 
o|contracted procedure: k13320 
o|contracted procedure: k13332 
o|contracted procedure: k13356 
o|contracted procedure: k13353 
o|contracted procedure: k13368 
o|contracted procedure: k13375 
o|contracted procedure: k13387 
o|contracted procedure: k13393 
o|contracted procedure: k13399 
o|contracted procedure: k13405 
o|contracted procedure: k13411 
o|contracted procedure: k13417 
o|contracted procedure: k13445 
o|contracted procedure: k13451 
o|contracted procedure: k13457 
o|contracted procedure: k13474 
o|contracted procedure: k13480 
o|contracted procedure: k13486 
o|contracted procedure: k13492 
o|contracted procedure: k13498 
o|contracted procedure: k13504 
o|contracted procedure: k13510 
o|contracted procedure: k13516 
o|contracted procedure: k13522 
o|contracted procedure: k13528 
o|contracted procedure: k13534 
o|contracted procedure: k13540 
o|contracted procedure: k13546 
o|contracted procedure: k13552 
o|contracted procedure: k13558 
o|contracted procedure: k13564 
o|contracted procedure: k13570 
o|contracted procedure: k13576 
o|contracted procedure: k13582 
o|contracted procedure: k13588 
o|contracted procedure: k13594 
o|contracted procedure: k13600 
o|contracted procedure: k13606 
o|contracted procedure: k13612 
o|contracted procedure: k13618 
o|contracted procedure: k13624 
o|contracted procedure: k13630 
o|contracted procedure: k13636 
o|contracted procedure: k13642 
o|contracted procedure: k13648 
o|contracted procedure: k13654 
o|contracted procedure: k13744 
o|contracted procedure: k13747 
o|contracted procedure: k13754 
o|contracted procedure: k13760 
o|contracted procedure: k13767 
o|contracted procedure: k13773 
o|contracted procedure: k13776 
o|contracted procedure: k13783 
o|contracted procedure: k13789 
o|contracted procedure: k13792 
o|contracted procedure: k13799 
o|contracted procedure: k13805 
o|contracted procedure: k13816 
o|contracted procedure: k13812 
o|contracted procedure: k13822 
o|contracted procedure: k13829 
o|contracted procedure: k13835 
o|contracted procedure: k13842 
o|contracted procedure: k13848 
o|contracted procedure: k13861 
o|contracted procedure: k13948 
o|contracted procedure: k13867 
o|contracted procedure: k13870 
o|contracted procedure: k13876 
o|contracted procedure: k13879 
o|contracted procedure: k13917 
o|contracted procedure: k13889 
o|contracted procedure: k13913 
o|contracted procedure: k13897 
o|contracted procedure: k13905 
o|contracted procedure: k13909 
o|contracted procedure: k13901 
o|contracted procedure: k13893 
o|contracted procedure: k13923 
o|contracted procedure: k13930 
o|contracted procedure: k13934 
o|contracted procedure: k13971 
o|contracted procedure: k13951 
o|contracted procedure: k13967 
o|contracted procedure: k13957 
o|contracted procedure: k13961 
o|contracted procedure: k14012 
o|contracted procedure: k14018 
o|contracted procedure: k14021 
o|contracted procedure: k14027 
o|contracted procedure: k14036 
o|contracted procedure: k14039 
o|contracted procedure: k14045 
o|contracted procedure: k14053 
o|contracted procedure: k14056 
o|contracted procedure: k14062 
o|contracted procedure: k14068 
o|contracted procedure: k14076 
o|contracted procedure: k14082 
o|contracted procedure: k14088 
o|contracted procedure: k14096 
o|contracted procedure: k14102 
o|contracted procedure: k14111 
o|contracted procedure: k14118 
o|contracted procedure: k14129 
o|contracted procedure: k14135 
o|contracted procedure: k14141 
o|contracted procedure: k14147 
o|contracted procedure: k14153 
o|contracted procedure: k14159 
o|contracted procedure: k14165 
o|contracted procedure: k14171 
o|contracted procedure: k14177 
o|contracted procedure: k14186 
o|contracted procedure: k14192 
o|contracted procedure: k14198 
o|contracted procedure: k14207 
o|contracted procedure: k14210 
o|contracted procedure: k14216 
o|contracted procedure: k14225 
o|contracted procedure: k14231 
o|contracted procedure: k14238 
o|contracted procedure: k14247 
o|contracted procedure: k14254 
o|contracted procedure: k14260 
o|contracted procedure: k14266 
o|contracted procedure: k14269 
o|contracted procedure: k14283 
o|contracted procedure: k14289 
o|contracted procedure: k14308 
o|contracted procedure: k14330 
o|contracted procedure: k14336 
o|contracted procedure: k14357 
o|contracted procedure: k14363 
o|contracted procedure: k14369 
o|contracted procedure: k14375 
o|contracted procedure: k14381 
o|contracted procedure: k14387 
o|contracted procedure: k14428 
o|contracted procedure: k14434 
o|contracted procedure: k14440 
o|contracted procedure: k14446 
o|contracted procedure: k14452 
o|contracted procedure: k14458 
o|contracted procedure: k14505 
o|contracted procedure: k14511 
o|contracted procedure: k14517 
o|contracted procedure: k14523 
o|contracted procedure: k14529 
o|contracted procedure: k14535 
o|contracted procedure: k14583 
o|contracted procedure: k14591 
o|contracted procedure: k14597 
o|contracted procedure: k14600 
o|contracted procedure: k14661 
o|contracted procedure: k14603 
o|contracted procedure: k14609 
o|contracted procedure: k14621 
o|contracted procedure: k14631 
o|contracted procedure: k14635 
o|contracted procedure: k14642 
o|contracted procedure: k14645 
o|contracted procedure: k14652 
o|contracted procedure: k14667 
o|contracted procedure: k14673 
o|contracted procedure: k14685 
o|contracted procedure: k14695 
o|contracted procedure: k14699 
o|contracted procedure: k14702 
o|contracted procedure: k14735 
o|contracted procedure: k14743 
o|contracted procedure: k14751 
o|contracted procedure: k14757 
o|contracted procedure: k14766 
o|contracted procedure: k14769 
o|contracted procedure: k14775 
o|contracted procedure: k14795 
o|contracted procedure: k14798 
o|contracted procedure: k14811 
o|contracted procedure: k1480817568 
o|contracted procedure: k1480817572 
o|contracted procedure: k14821 
o|contracted procedure: k14831 
o|contracted procedure: k14839 
o|contracted procedure: k14845 
o|contracted procedure: k14852 
o|contracted procedure: k14862 
o|contracted procedure: k14880 
o|contracted procedure: k14886 
o|contracted procedure: k14892 
o|contracted procedure: k14919 
o|contracted procedure: k14931 
o|contracted procedure: k14941 
o|contracted procedure: k14945 
o|contracted procedure: k14978 
o|contracted procedure: k14957 
o|contracted procedure: k14969 
o|contracted procedure: k14973 
o|contracted procedure: k15018 
o|contracted procedure: k14984 
o|contracted procedure: k14996 
o|contracted procedure: k15004 
o|contracted procedure: k15014 
o|contracted procedure: k15036 
o|contracted procedure: k15082 
o|inlining procedure: k15079 
o|contracted procedure: k15131 
o|contracted procedure: k15139 
o|contracted procedure: k15152 
o|contracted procedure: k15163 
o|contracted procedure: k15175 
o|contracted procedure: k15189 
o|contracted procedure: k15193 
o|contracted procedure: k15260 
o|contracted procedure: k15263 
o|contracted procedure: k15266 
o|contracted procedure: k15285 
o|contracted procedure: k15281 
o|contracted procedure: k15294 
o|contracted procedure: k15340 
o|contracted procedure: k15333 
o|contracted procedure: k15309 
o|contracted procedure: k15321 
o|contracted procedure: k15324 
o|contracted procedure: k15327 
o|contracted procedure: k15346 
o|contracted procedure: k15363 
o|contracted procedure: k15503 
o|contracted procedure: k15511 
o|contracted procedure: k15369 
o|contracted procedure: k15372 
o|contracted procedure: k15378 
o|contracted procedure: k15395 
o|contracted procedure: k15414 
o|contracted procedure: k15420 
o|contracted procedure: k15444 
o|contracted procedure: k15432 
o|contracted procedure: k15439 
o|contracted procedure: k15523 
o|contracted procedure: k15545 
o|contracted procedure: k15541 
o|contracted procedure: k15526 
o|contracted procedure: k15529 
o|contracted procedure: k15537 
o|contracted procedure: k15557 
o|contracted procedure: k15560 
o|contracted procedure: k15563 
o|contracted procedure: k15571 
o|contracted procedure: k15579 
o|contracted procedure: k15360 
o|contracted procedure: k15604 
o|contracted procedure: k15610 
o|contracted procedure: k15619 
o|contracted procedure: k15622 
o|contracted procedure: k15629 
o|contracted procedure: k1559517061 
o|contracted procedure: k1559517068 
o|contracted procedure: k1559517077 
o|contracted procedure: k15681 
o|contracted procedure: k15689 
o|contracted procedure: k15697 
o|contracted procedure: k15703 
o|contracted procedure: k15732 
o|contracted procedure: k15738 
o|contracted procedure: k15747 
o|contracted procedure: k15771 
o|contracted procedure: k15787 
o|contracted procedure: k15791 
o|contracted procedure: k15795 
o|contracted procedure: k15804 
o|contracted procedure: k15814 
o|contracted procedure: k15818 
o|contracted procedure: k15834 
o|inlining procedure: k15838 
o|inlining procedure: k15838 
o|contracted procedure: k15854 
o|contracted procedure: k15861 
o|contracted procedure: k15876 
o|contracted procedure: k15889 
o|contracted procedure: k15913 
o|contracted procedure: k15941 
o|contracted procedure: k15970 
o|contracted procedure: k15976 
o|contracted procedure: k15979 
o|contracted procedure: k15999 
o|contracted procedure: k15993 
o|contracted procedure: k16019 
o|contracted procedure: k16013 
o|contracted procedure: k16047 
o|contracted procedure: k16053 
o|contracted procedure: k16072 
o|contracted procedure: k16066 
o|contracted procedure: k16161 
o|contracted procedure: k16171 
o|contracted procedure: k16175 
o|contracted procedure: k16126 
o|contracted procedure: k16140 
o|contracted procedure: k16144 
o|contracted procedure: k16223 
o|contracted procedure: k16207 
o|contracted procedure: k16274 
o|contracted procedure: k16283 
o|simplifications: ((let . 157)) 
o|removed binding forms: 1207 
o|inlining procedure: k9774 
o|replaced variables: 441 
o|removed binding forms: 4 
o|simplifications: ((if . 17)) 
o|replaced variables: 7 
o|removed binding forms: 280 
o|contracted procedure: k15575 
o|contracted procedure: k15648 
o|simplifications: ((let . 1)) 
o|removed binding forms: 3 
o|replaced variables: 2 
o|removed binding forms: 1 
o|direct leaf routine/allocation: loop508 0 
o|direct leaf routine/allocation: g22972298 0 
o|direct leaf routine/allocation: g24552462 20 
o|converted assignments to bindings: (loop508) 
o|contracted procedure: "(support.scm:962) k11599" 
o|simplifications: ((let . 1)) 
o|removed binding forms: 1 
o|customizable procedures: (for-each-loop39693984 loop3846 k15827 g37753782 for-each-loop37743792 doloop38053806 loop3744 map-loop36353656 map-loop36663687 resolve3571 loop3583 loop3524 k14963 g34993506 for-each-loop34983509 k14760 walkeach3454 walk3453 k14670 for-each-loop34323442 k14638 k14606 for-each-loop34083418 k14030 k14105 k14180 k14201 k14219 k14241 k13854 k13323 k13335 k13378 g31383139 k12885 k12894 k12906 k12918 g29812982 g28622863 k11806 k11821 k11944 k11986 k12012 k12039 k12066 k12110 k12155 k12235 repeat2576 g27852786 k12128 k11962 k11904 for-each-loop25522564 for-each-loop24542476 k11405 k11364 k11153 matchn2288 loop2317 match12287 resolve2286 loop2262 k10734 k10771 for-each-loop22132225 for-each-loop22352253 map-loop21522169 map-loop21132133 rec2080 map-loop18571876 g20502059 map-loop20442069 g19441953 map-loop19381958 map-loop19681987 g20112020 map-loop20052030 walk1887 map-loop18051822 k9750 fold1782 k8811 k9415 map-loop17541771 map-loop17281745 map-loop16991716 loop1680 map-loop16561673 map-loop16301647 loop1621 map-loop15811598 map-loop15601605 map-loop15181535 map-loop14891506 map-loop14321449 k8396 k8591 map-loop14011418 map-loop13551372 map-loop13241341 map-loop12751292 map-loop12311248 k8078 map-loop11971214 loop1164 map-loop10991117 g11321141 map-loop11261144 k7656 map-loop10621079 k6844 k7061 k7140 loop784 k6909 k6946 k6983 map-loop745762 k6738 g732733 k6661 for-each-loop534576 for-each-loop583625 for-each-loop632658 tmp14363 tmp24364 k6067 loop463 k5939 loop376 fold369 k5705 k5559 k5566 loop305 loop288 loop238 loop227 loop212 err211 loop200 k5120 g169176 for-each-loop168186 collect99 g104111 for-each-loop103123 text46 dump47 for-each-loop5068) 
o|calls to known targets: 490 
o|identified direct recursive calls: f_5283 1 
o|identified direct recursive calls: f_5333 1 
o|identified direct recursive calls: f_5367 1 
o|identified direct recursive calls: f_5485 1 
o|identified direct recursive calls: f_5754 1 
o|identified direct recursive calls: f_6230 1 
o|identified direct recursive calls: f_6808 1 
o|identified direct recursive calls: f_7538 4 
o|identified direct recursive calls: f_9005 1 
o|identified direct recursive calls: f_10158 1 
o|identified direct recursive calls: f_9875 1 
o|identified direct recursive calls: f_10314 1 
o|identified direct recursive calls: f_10368 1 
o|identified direct recursive calls: f_10943 1 
o|identified direct recursive calls: f_11591 1 
o|identified direct recursive calls: f_14991 1 
o|identified direct recursive calls: f_15518 1 
o|identified direct recursive calls: f_15552 1 
o|fast box initializations: 85 
o|dropping unused closure argument: f_15102 
o|dropping unused closure argument: f_6230 
*/
/* end of file */
