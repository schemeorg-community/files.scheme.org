/* Generated from chicken-profile.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:51
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: chicken-profile.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -local -no-trace -output-file chicken-profile.c
   used units: library eval chicken_2dsyntax srfi_2d1 srfi_2d13 srfi_2d69 posix utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_srfi_2d1_toplevel)
C_externimport void C_ccall C_srfi_2d1_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_srfi_2d13_toplevel)
C_externimport void C_ccall C_srfi_2d13_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_srfi_2d69_toplevel)
C_externimport void C_ccall C_srfi_2d69_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[95];
static double C_possibly_force_alignment;


C_noret_decl(f_788)
static void C_fcall f_788(C_word t0,C_word t1) C_noret;
C_noret_decl(f_782)
static void C_ccall f_782(C_word c,C_word *av) C_noret;
C_noret_decl(f_1349)
static void C_ccall f_1349(C_word c,C_word *av) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word *av) C_noret;
C_noret_decl(f_848)
static void C_ccall f_848(C_word c,C_word *av) C_noret;
C_noret_decl(f_855)
static void C_ccall f_855(C_word c,C_word *av) C_noret;
C_noret_decl(f_768)
static void C_ccall f_768(C_word c,C_word *av) C_noret;
C_noret_decl(f_830)
static void C_ccall f_830(C_word c,C_word *av) C_noret;
C_noret_decl(f_1193)
static void C_ccall f_1193(C_word c,C_word *av) C_noret;
C_noret_decl(f_827)
static void C_ccall f_827(C_word c,C_word *av) C_noret;
C_noret_decl(f_885)
static void C_ccall f_885(C_word c,C_word *av) C_noret;
C_noret_decl(f_870)
static void C_ccall f_870(C_word c,C_word *av) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863(C_word c,C_word *av) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word *av) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word *av) C_noret;
C_noret_decl(f_952)
static void C_ccall f_952(C_word c,C_word *av) C_noret;
C_noret_decl(f_1148)
static void C_ccall f_1148(C_word c,C_word *av) C_noret;
C_noret_decl(f_1141)
static void C_ccall f_1141(C_word c,C_word *av) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word *av) C_noret;
C_noret_decl(f_927)
static void C_fcall f_927(C_word t0,C_word t1) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921(C_word c,C_word *av) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word *av) C_noret;
C_noret_decl(f_1447)
static void C_ccall f_1447(C_word c,C_word *av) C_noret;
C_noret_decl(f_1813)
static void C_fcall f_1813(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word *av) C_noret;
C_noret_decl(f_807)
static void C_fcall f_807(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1703)
static void C_fcall f_1703(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word *av) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word *av) C_noret;
C_noret_decl(f_1543)
static void C_ccall f_1543(C_word c,C_word *av) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word *av) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word *av) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word *av) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word *av) C_noret;
C_noret_decl(f_1655)
static void C_fcall f_1655(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word *av) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word *av) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word *av) C_noret;
C_noret_decl(f_1439)
static void C_ccall f_1439(C_word c,C_word *av) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428(C_word c,C_word *av) C_noret;
C_noret_decl(f_1831)
static void C_fcall f_1831(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1205)
static void C_fcall f_1205(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1838)
static void C_fcall f_1838(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word *av) C_noret;
C_noret_decl(f_1410)
static void C_fcall f_1410(C_word t0,C_word t1) C_noret;
C_noret_decl(f_699)
static void C_ccall f_699(C_word c,C_word *av) C_noret;
C_noret_decl(f_1865)
static void C_fcall f_1865(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word *av) C_noret;
C_noret_decl(f_1215)
static void C_fcall f_1215(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1407)
static void C_ccall f_1407(C_word c,C_word *av) C_noret;
C_noret_decl(f_692)
static void C_ccall f_692(C_word c,C_word *av) C_noret;
C_noret_decl(f_1404)
static void C_ccall f_1404(C_word c,C_word *av) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word *av) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word *av) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word *av) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word *av) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word *av) C_noret;
C_noret_decl(f_1899)
static void C_fcall f_1899(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1517)
static void C_fcall f_1517(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1510)
static void C_fcall f_1510(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word *av) C_noret;
C_noret_decl(f_1152)
static void C_ccall f_1152(C_word c,C_word *av) C_noret;
C_noret_decl(f_1154)
static void C_fcall f_1154(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word *av) C_noret;
C_noret_decl(f_662)
static void C_ccall f_662(C_word c,C_word *av) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word *av) C_noret;
C_noret_decl(f_665)
static void C_ccall f_665(C_word c,C_word *av) C_noret;
C_noret_decl(f_668)
static void C_ccall f_668(C_word c,C_word *av) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word *av) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word *av) C_noret;
C_noret_decl(f_674)
static void C_ccall f_674(C_word c,C_word *av) C_noret;
C_noret_decl(f_677)
static void C_ccall f_677(C_word c,C_word *av) C_noret;
C_noret_decl(f_671)
static void C_ccall f_671(C_word c,C_word *av) C_noret;
C_noret_decl(f_987)
static void C_ccall f_987(C_word c,C_word *av) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word *av) C_noret;
C_noret_decl(f_752)
static void C_ccall f_752(C_word c,C_word *av) C_noret;
C_noret_decl(f_755)
static void C_ccall f_755(C_word c,C_word *av) C_noret;
C_noret_decl(f_1391)
static void C_ccall f_1391(C_word c,C_word *av) C_noret;
C_noret_decl(f_1394)
static void C_ccall f_1394(C_word c,C_word *av) C_noret;
C_noret_decl(f_659)
static void C_ccall f_659(C_word c,C_word *av) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word *av) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word *av) C_noret;
C_noret_decl(f_735)
static void C_fcall f_735(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1118)
static void C_ccall f_1118(C_word c,C_word *av) C_noret;
C_noret_decl(f_1110)
static void C_ccall f_1110(C_word c,C_word *av) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377(C_word c,C_word *av) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word *av) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word *av) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word *av) C_noret;
C_noret_decl(f_1482)
static void C_ccall f_1482(C_word c,C_word *av) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word *av) C_noret;
C_noret_decl(f_745)
static void C_fcall f_745(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word *av) C_noret;
C_noret_decl(f_1164)
static void C_ccall f_1164(C_word c,C_word *av) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word *av) C_noret;
C_noret_decl(f_1283)
static void C_ccall f_1283(C_word c,C_word *av) C_noret;
C_noret_decl(f_1473)
static void C_ccall f_1473(C_word c,C_word *av) C_noret;
C_noret_decl(f_1470)
static void C_ccall f_1470(C_word c,C_word *av) C_noret;
C_noret_decl(f_1171)
static void C_ccall f_1171(C_word c,C_word *av) C_noret;
C_noret_decl(f_1747)
static void C_fcall f_1747(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1584)
static void C_fcall f_1584(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1075)
static void C_fcall f_1075(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1353)
static void C_ccall f_1353(C_word c,C_word *av) C_noret;
C_noret_decl(f_688)
static void C_fcall f_688(C_word t0) C_noret;
C_noret_decl(f_680)
static void C_ccall f_680(C_word c,C_word *av) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word *av) C_noret;
C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word *av) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word *av) C_noret;
C_noret_decl(f_1365)
static void C_ccall f_1365(C_word c,C_word *av) C_noret;
C_noret_decl(f_1264)
static void C_ccall f_1264(C_word c,C_word *av) C_noret;
C_noret_decl(f_778)
static void C_ccall f_778(C_word c,C_word *av) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word *av) C_noret;
C_noret_decl(f_770)
static void C_ccall f_770(C_word c,C_word *av) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word *av) C_noret;
C_noret_decl(f_1330)
static void C_fcall f_1330(C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_788)
static void C_ccall trf_788(C_word c,C_word *av) C_noret;
static void C_ccall trf_788(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_788(t0,t1);}

C_noret_decl(trf_927)
static void C_ccall trf_927(C_word c,C_word *av) C_noret;
static void C_ccall trf_927(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_927(t0,t1);}

C_noret_decl(trf_1813)
static void C_ccall trf_1813(C_word c,C_word *av) C_noret;
static void C_ccall trf_1813(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1813(t0,t1,t2);}

C_noret_decl(trf_807)
static void C_ccall trf_807(C_word c,C_word *av) C_noret;
static void C_ccall trf_807(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_807(t0,t1);}

C_noret_decl(trf_1703)
static void C_ccall trf_1703(C_word c,C_word *av) C_noret;
static void C_ccall trf_1703(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1703(t0,t1,t2);}

C_noret_decl(trf_1655)
static void C_ccall trf_1655(C_word c,C_word *av) C_noret;
static void C_ccall trf_1655(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_1655(t0,t1,t2,t3);}

C_noret_decl(trf_1831)
static void C_ccall trf_1831(C_word c,C_word *av) C_noret;
static void C_ccall trf_1831(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1831(t0,t1);}

C_noret_decl(trf_1205)
static void C_ccall trf_1205(C_word c,C_word *av) C_noret;
static void C_ccall trf_1205(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_1205(t0,t1,t2,t3);}

C_noret_decl(trf_1838)
static void C_ccall trf_1838(C_word c,C_word *av) C_noret;
static void C_ccall trf_1838(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1838(t0,t1);}

C_noret_decl(trf_1410)
static void C_ccall trf_1410(C_word c,C_word *av) C_noret;
static void C_ccall trf_1410(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1410(t0,t1);}

C_noret_decl(trf_1865)
static void C_ccall trf_1865(C_word c,C_word *av) C_noret;
static void C_ccall trf_1865(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1865(t0,t1,t2);}

C_noret_decl(trf_1215)
static void C_ccall trf_1215(C_word c,C_word *av) C_noret;
static void C_ccall trf_1215(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1215(t0,t1);}

C_noret_decl(trf_1899)
static void C_ccall trf_1899(C_word c,C_word *av) C_noret;
static void C_ccall trf_1899(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_1899(t0,t1,t2,t3);}

C_noret_decl(trf_1517)
static void C_ccall trf_1517(C_word c,C_word *av) C_noret;
static void C_ccall trf_1517(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1517(t0,t1);}

C_noret_decl(trf_1510)
static void C_ccall trf_1510(C_word c,C_word *av) C_noret;
static void C_ccall trf_1510(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_1510(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1154)
static void C_ccall trf_1154(C_word c,C_word *av) C_noret;
static void C_ccall trf_1154(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1154(t0,t1,t2);}

C_noret_decl(trf_735)
static void C_ccall trf_735(C_word c,C_word *av) C_noret;
static void C_ccall trf_735(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_735(t0,t1,t2);}

C_noret_decl(trf_745)
static void C_ccall trf_745(C_word c,C_word *av) C_noret;
static void C_ccall trf_745(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_745(t0,t1);}

C_noret_decl(trf_1747)
static void C_ccall trf_1747(C_word c,C_word *av) C_noret;
static void C_ccall trf_1747(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1747(t0,t1,t2);}

C_noret_decl(trf_1584)
static void C_ccall trf_1584(C_word c,C_word *av) C_noret;
static void C_ccall trf_1584(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1584(t0,t1,t2);}

C_noret_decl(trf_1075)
static void C_ccall trf_1075(C_word c,C_word *av) C_noret;
static void C_ccall trf_1075(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1075(t0,t1,t2);}

C_noret_decl(trf_688)
static void C_ccall trf_688(C_word c,C_word *av) C_noret;
static void C_ccall trf_688(C_word c,C_word *av){
C_word t0=av[0];
f_688(t0);}

C_noret_decl(trf_1330)
static void C_ccall trf_1330(C_word c,C_word *av) C_noret;
static void C_ccall trf_1330(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1330(t0,t1,t2);}

/* next-arg in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_788(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_788,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
/* chicken-profile.scm:86: error */
t2=*((C_word*)lf[69]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[74];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k780 in k776 in a769 in k750 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_782(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_782,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_greaterp(((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1347 in k1339 in k1383 in format-real in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1349(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1349,2,av);}
/* chicken-profile.scm:176: string-append */
t2=*((C_word*)lf[37]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1339 in k1383 in format-real in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1341(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,4))){C_save_and_reclaim((void *)f_1341,2,av);}
a=C_alloc(16);
t2=t1;
t3=C_i_greaterp(((C_word*)t0)[2],C_fix(0));
t4=(C_truep(t3)?lf[35]:lf[36]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1349,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1353,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1365,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1373,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:183: - */
t10=*((C_word*)lf[42]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=((C_word*)t0)[4];
av2[3]=((C_word*)t0)[5];
av2[4]=C_fix(-1);
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}

/* k846 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_848,2,av);}
/* chicken-profile.scm:97: exit */
t2=C_fast_retrieve(lf[7]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k853 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_855(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_855,2,av);}
/* chicken-profile.scm:96: print */
t2=*((C_word*)lf[50]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[80];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k766 in k750 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_768(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_768,2,av);}
t2=C_i_car(t1);
t3=C_mutate2(&lf[0] /* (set! file ...) */,t2);
t4=((C_word*)t0)[2];
f_745(t4,t3);}

/* k828 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_830(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_830,2,av);}
/* chicken-profile.scm:112: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_735(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k1191 in doloop66 in k1150 in k1133 in k1130 in read-profile in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1193(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_1193,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_i_check_list_2(t1,lf[25]);
t5=C_i_check_list_2(t3,lf[25]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1205,a[2]=((C_word*)t0)[6],a[3]=t8,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_1205(t10,t6,t1,t3);}

/* k825 in next-number in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_827,2,av);}
a=C_alloc(4);
t2=C_a_i_string_to_number(&a,2,t1,C_fix(10));
if(C_truep(t2)){
if(C_truep(C_i_greaterp(t2,C_fix(0)))){
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* chicken-profile.scm:92: error */
t3=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[75];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}
else{
/* chicken-profile.scm:92: error */
t3=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[75];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k883 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_885(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_885,2,av);}
t2=C_mutate2(&lf[5] /* (set! top ...) */,t1);
/* chicken-profile.scm:112: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_735(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k868 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_870,2,av);}
/* chicken-profile.scm:99: print */
t2=*((C_word*)lf[50]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k861 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_863,2,av);}
/* chicken-profile.scm:100: exit */
t2=C_fast_retrieve(lf[7]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1802 in k1798 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1804(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1804,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_1410(t3,t2);}

/* k1798 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1800,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:213: take */
t3=C_fast_retrieve(lf[63]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=lf[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=((C_word*)t0)[3];
f_1410(t2,C_SCHEME_UNDEFINED);}}

/* sort-by-calls in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_952(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_952,4,av);}
t4=C_i_cadr(t2);
t5=C_i_cadr(t3);
if(C_truep(C_i_eqvp(t4,t5))){
t6=C_i_caddr(t2);
t7=C_i_caddr(t3);
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_i_greaterp(t6,t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=(C_truep(t4)?(C_truep(t5)?C_i_greaterp(t4,t5):C_SCHEME_TRUE):C_SCHEME_TRUE);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k1146 in k1139 in k1133 in k1130 in read-profile in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1148(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_1148,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1139 in k1133 in k1130 in read-profile in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1141(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1141,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:165: hash-table->alist */
t3=C_fast_retrieve(lf[23]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k1449 in k1445 in k1441 in k1437 in k1433 in k1426 in map-loop198 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in ... */
static void C_ccall f_1451(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,c,1))){C_save_and_reclaim((void *)f_1451,2,av);}
a=C_alloc(15);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list5(&a,5,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k925 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_927(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_927,2,t0,t1);}
if(C_truep(t1)){
/* chicken-profile.scm:109: error */
t2=*((C_word*)lf[69]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[93];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
if(C_truep(lf[0])){
/* chicken-profile.scm:110: print-usage */
f_688(((C_word*)t0)[2]);}
else{
t2=C_mutate2(&lf[0] /* (set! file ...) */,((C_word*)t0)[3]);
/* chicken-profile.scm:112: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_735(t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1]);}}}

/* k919 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_921(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_921,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
t3=t1;
t4=C_i_string_length(t3);
t5=C_eqp(t4,C_fix(3));
if(C_truep(t5)){
t6=C_mutate2(&lf[90] /* (set! arg-digit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1075,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1110,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:149: arg-digit */
t8=C_retrieve2(lf[90],"arg-digit");
f_1075(t8,t7,C_fix(0));}
else{
/* chicken-profile.scm:152: error */
t6=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=lf[92];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}

/* k1441 in k1437 in k1433 in k1426 in map-loop198 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 in ... */
static void C_ccall f_1443(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_1443,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_a_i_divide(&a,2,((C_word*)t0)[6],C_fix(1000));
/* chicken-profile.scm:222: format-real */
f_1330(t3,t4,lf[3]);}

/* k1445 in k1441 in k1437 in k1433 in k1426 in map-loop198 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in ... */
static void C_ccall f_1447(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_1447,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-profile.scm:223: format-real */
f_1330(t3,((C_word*)t0)[6],lf[4]);}

/* g166 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_1813(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,2))){
C_save_and_reclaim_args((void *)trf_1813,3,t0,t1,t2);}
a=C_alloc(10);
t3=C_i_cadr(t2);
t4=C_i_caddr(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1831,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t7=C_i_greaterp(t3,C_fix(0));
t8=t6;
f_1831(t8,(C_truep(t7)?C_a_i_divide(&a,2,t5,t3):C_SCHEME_FALSE));}
else{
t7=t6;
f_1831(t7,C_SCHEME_FALSE);}}

/* read-profile in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1128(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1128,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1132,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:155: make-hash-table */
t3=C_fast_retrieve(lf[29]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[30]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* next-number in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_807,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_827,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:91: next-arg */
t3=((C_word*)((C_word*)t0)[3])[1];
f_788(t3,t2);}

/* map-loop259 in a1630 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_1703(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_1703,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_string_length(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1133 in k1130 in read-profile in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1135(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_1135,2,av);}
a=C_alloc(9);
t2=C_i_symbolp(t1);
t3=(C_truep(t2)?t1:lf[22]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1141,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1152,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_symbolp(t1))){
/* chicken-profile.scm:158: read */
t7=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t7=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t1;
f_1152(2,av2);}}}

/* k1130 in read-profile in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1132(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1132,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:156: read */
t4=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1541 in k1515 in map-loop297 in print-row in k1483 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in ... */
static void C_ccall f_1543(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_1543,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=C_slot(((C_word*)t0)[4],C_fix(1));
t7=C_slot(((C_word*)t0)[5],C_fix(1));
t8=((C_word*)((C_word*)t0)[6])[1];
f_1510(t8,((C_word*)t0)[7],t5,t6,t7);}

/* k1770 in map-loop198 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1772(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1772,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1747(t6,((C_word*)t0)[5],t5);}

/* k1607 in k1571 in k1483 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 in ... */
static void C_ccall f_1609(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1609,2,av);}
/* chicken-profile.scm:241: print */
t2=*((C_word*)lf[50]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* sort-by-name in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1043(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1043,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1051,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(t2);
/* chicken-profile.scm:136: symbol->string */
t6=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k1433 in k1426 in map-loop198 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1435(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_1435,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1439,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[6])){
/* chicken-profile.scm:220: number->string */
t4=*((C_word*)lf[58]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=lf[59];
f_1439(2,av2);}}}

/* map-loop238 in k1642 in a1630 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 in ... */
static void C_fcall f_1655(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_1655,4,t0,t1,t2,t3);}
a=C_alloc(7);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* chicken-profile.scm:234: g244 */
t9=*((C_word*)lf[55]+1);{
C_word av2[4];
av2[0]=t9;
av2[1]=t6;
av2[2]=t7;
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* f_1928 in foldl142 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1928(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1928,4,av);}
t4=C_i_caddr(t3);
/* chicken-profile.scm:196: max */
t5=*((C_word*)lf[55]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t2;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* sort-by-avg in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1014(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1014,4,av);}
t4=C_i_cadddr(t2);
t5=C_i_cadddr(t3);
if(C_truep(C_i_eqvp(t4,t5))){
t6=t2;
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_u_i_car(t8);
t10=t3;
t11=C_u_i_cdr(t10);
t12=C_u_i_cdr(t11);
t13=C_u_i_car(t12);
t14=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t14;
av2[1]=C_i_greaterp(t9,t13);
((C_proc)(void*)(*((C_word*)t14+1)))(2,av2);}}
else{
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_i_greaterp(t4,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k1918 in foldl142 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1920(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1920,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
f_1899(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k1437 in k1433 in k1426 in map-loop198 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1439(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_1439,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_a_i_divide(&a,2,((C_word*)t0)[6],C_fix(1000));
/* chicken-profile.scm:221: format-real */
f_1330(t3,t4,lf[2]);}

/* k1426 in map-loop198 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1428(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_1428,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1435,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_u_i_car(((C_word*)t0)[6]);
/* chicken-profile.scm:219: ##sys#symbol->qualified-string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[60]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[60]+1);
av2[1]=t3;
av2[2]=t4;
tp(3,av2);}}

/* k1829 in g166 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_1831(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,0,2))){
C_save_and_reclaim_args((void *)trf_1831,2,t0,t1);}
a=C_alloc(13);
t2=(C_truep(t1)?t1:C_fix(0));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1838,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_greaterp(((C_word*)t0)[4],C_fix(0)))){
t5=C_a_i_divide(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t6=t4;
f_1838(t6,C_a_i_times(&a,2,t5,C_fix(100)));}
else{
t5=t4;
f_1838(t5,C_SCHEME_FALSE);}}

/* map-loop71 in k1191 in doloop66 in k1150 in k1133 in k1130 in read-profile in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_1205(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,0,2))){
C_save_and_reclaim_args((void *)trf_1205,4,t0,t1,t2,t3);}
a=C_alloc(14);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1215,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
if(C_truep(t7)){
if(C_truep(t8)){
t9=C_a_i_plus(&a,2,t7,t8);
t10=t6;
f_1215(t10,C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}
else{
t9=t6;
f_1215(t9,C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST));}}
else{
t9=t6;
f_1215(t9,C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST));}}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k1836 in k1829 in g166 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_1838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_1838,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=t1;
t3=C_a_i_list2(&a,2,((C_word*)t0)[2],t2);
/* chicken-profile.scm:201: append */
t4=*((C_word*)lf[64]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],C_fix(0));
/* chicken-profile.scm:201: append */
t3=*((C_word*)lf[64]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k1201 in k1191 in doloop66 in k1150 in k1133 in k1130 in read-profile in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1203(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1203,2,av);}
/* chicken-profile.scm:160: hash-table-set! */
t2=C_fast_retrieve(lf[26]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_1410(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,0,3))){
C_save_and_reclaim_args((void *)trf_1410,2,t0,t1);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1781,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm:224: remove */
t8=C_fast_retrieve(lf[62]);{
C_word av2[4];
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=((C_word*)((C_word*)t0)[2])[1];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k697 in print-usage in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_699(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_699,2,av);}
/* chicken-profile.scm:45: display */
t2=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop160 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_1865(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_1865,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1890,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-profile.scm:199: g166 */
t5=((C_word*)t0)[4];
f_1813(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1861 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1863,2,av);}
/* chicken-profile.scm:199: sort */
t2=C_fast_retrieve(lf[65]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[20];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1213 in map-loop71 in k1191 in doloop66 in k1150 in k1133 in k1130 in read-profile in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_1215(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_1215,2,t0,t1);}
t2=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t1);
t3=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t4=C_slot(((C_word*)t0)[3],C_fix(1));
t5=C_slot(((C_word*)t0)[4],C_fix(1));
t6=((C_word*)((C_word*)t0)[5])[1];
f_1205(t6,((C_word*)t0)[6],t4,t5);}

/* k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1407(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_1407,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1410,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1800,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_length(((C_word*)t3)[1]);
/* chicken-profile.scm:212: < */{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t5;
av2[2]=C_fix(0);
av2[3]=lf[5];
av2[4]=t6;
C_lessp(5,av2);}}

/* k690 in print-usage in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_692(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_692,2,av);}
/* chicken-profile.scm:66: exit */
t2=C_fast_retrieve(lf[7]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(64);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1404(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(22,c,3))){C_save_and_reclaim((void *)f_1404,2,av);}
a=C_alloc(22);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1407,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1813,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1863,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1865,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_1865(t13,t9,((C_word*)t0)[3]);}

/* k1952 in k1946 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1954(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1954,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* k1949 in k1946 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1951(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1951,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1958(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_1958,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_735,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_735(t5,((C_word*)t0)[2],t1);}

/* a1630 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1631(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(23,c,3))){C_save_and_reclaim((void *)f_1631,4,av);}
a=C_alloc(23);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t9=t8;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=((C_word*)t10)[1];
t12=C_i_check_list_2(t2,lf[25]);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1644,a[2]=t3,a[3]=t6,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1703,a[2]=t10,a[3]=t15,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_1703(t17,t13,t2);}

/* k1888 in map-loop160 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1890,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1865(t6,((C_word*)t0)[5],t5);}

/* foldl142 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_1899(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,4))){
C_save_and_reclaim_args((void *)trf_1899,4,t0,t1,t2,t3);}
a=C_alloc(7);
if(C_truep(C_i_pairp(t2))){
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=C_eqp(((C_word*)t0)[2],lf[22]);
t7=(C_truep(t6)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1928,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1937,tmp=(C_word)a,a+=2,tmp));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1920,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t9=C_slot(t2,C_fix(0));
/* chicken-profile.scm:195: g149 */
t10=t7;{
C_word av2[4];
av2[0]=t10;
av2[1]=t8;
av2[2]=t3;
av2[3]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}
else{
t4=t3;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k1515 in map-loop297 in print-row in k1483 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in ... */
static void C_fcall f_1517(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_1517,2,t0,t1);}
a=C_alloc(8);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(0));
t4=C_slot(((C_word*)t0)[4],C_fix(0));
t5=C_slot(((C_word*)t0)[5],C_fix(0));
/* chicken-profile.scm:239: g303 */
t6=((C_word*)t0)[8];{
C_word av2[5];
av2[0]=t6;
av2[1]=t2;
av2[2]=t3;
av2[3]=t4;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t2=((C_word*)t0)[7];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_slot(((C_word*)t0)[9],C_fix(1));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* map-loop297 in print-row in k1483 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 in ... */
static void C_fcall f_1510(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,2))){
C_save_and_reclaim_args((void *)trf_1510,5,t0,t1,t2,t3,t4);}
a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1517,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_pairp(t2))){
t6=C_i_pairp(t3);
t7=t5;
f_1517(t7,(C_truep(t6)?C_i_pairp(t4):C_SCHEME_FALSE));}
else{
t6=t5;
f_1517(t6,C_SCHEME_FALSE);}}

/* k1946 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1948(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_1948,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1954,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[43]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[43]+1);
av2[1]=t3;
tp(2,av2);}}

/* k1150 in k1133 in k1130 in read-profile in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1152(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1152,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1154,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1154(t5,((C_word*)t0)[3],t1);}

/* doloop66 in k1150 in k1133 in k1130 in read-profile in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_1154(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(17,0,4))){
C_save_and_reclaim_args((void *)trf_1154,3,t0,t1,t2);}
a=C_alloc(17);
if(C_truep(C_eofp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1164,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(t2);
t5=t4;
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1193,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t8,a[7]=t9,tmp=(C_word)a,a+=8,tmp);
t11=t2;
t12=C_u_i_car(t11);
/* chicken-profile.scm:163: hash-table-ref/default */
t13=C_fast_retrieve(lf[27]);{
C_word av2[5];
av2[0]=t13;
av2[1]=t10;
av2[2]=((C_word*)t0)[3];
av2[3]=t12;
av2[4]=lf[28];
((C_proc)(void*)(*((C_word*)t13+1)))(5,av2);}}}

/* k1682 in map-loop238 in k1642 in a1630 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in ... */
static void C_ccall f_1684(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_1684,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=C_slot(((C_word*)t0)[4],C_fix(1));
t7=((C_word*)((C_word*)t0)[5])[1];
f_1655(t7,((C_word*)t0)[6],t5,t6);}

/* k660 in k657 */
static void C_ccall f_662(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_662,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_665,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_chicken_2dsyntax_toplevel(2,av2);}}

/* k1506 in print-row in k1483 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 in ... */
static void C_ccall f_1508(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1508,2,av);}
/* chicken-profile.scm:239: string-join */
t2=C_fast_retrieve(lf[51]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k663 in k660 in k657 */
static void C_ccall f_665(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_665,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_668,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_srfi_2d1_toplevel(2,av2);}}

/* k666 in k663 in k660 in k657 */
static void C_ccall f_668(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_668,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_671,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_srfi_2d13_toplevel(2,av2);}}

/* f_1937 in foldl142 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1937(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,1))){C_save_and_reclaim((void *)f_1937,4,av);}
a=C_alloc(4);
t4=C_i_caddr(t3);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_plus(&a,2,t2,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k1615 in k1571 in k1483 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 in ... */
static void C_ccall f_1617(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_1617,2,av);}
a=C_alloc(12);
t2=C_i_length(((C_word*)t0)[2]);
t3=C_a_i_minus(&a,2,t2,C_fix(1));
t4=C_a_i_times(&a,2,C_fix(2),t3);
t5=C_a_i_plus(&a,2,t1,t4);
/* chicken-profile.scm:241: make-string */
t6=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=((C_word*)t0)[3];
av2[2]=t5;
av2[3]=C_make_character(45);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_674(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_674,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_677,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_posix_toplevel(2,av2);}}

/* k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_677(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_677,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_680,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_utils_toplevel(2,av2);}}

/* k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_671,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_674,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_srfi_2d69_toplevel(2,av2);}}

/* sort-by-time in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_987(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_987,4,av);}
t4=C_i_caddr(t2);
t5=C_i_caddr(t3);
if(C_truep(C_i_nequalp(t4,t5))){
t6=t2;
t7=C_u_i_cdr(t6);
t8=C_u_i_car(t7);
t9=t3;
t10=C_u_i_cdr(t9);
t11=C_u_i_car(t10);
t12=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t12;
av2[1]=C_i_greaterp(t8,t11);
((C_proc)(void*)(*((C_word*)t12+1)))(2,av2);}}
else{
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_i_greaterp(t4,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* a1780 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1781(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1781,3,av);}
if(C_truep(C_i_cadr(t2))){
t3=t2;
t4=C_u_i_cdr(t3);
t5=C_u_i_car(t4);
t6=C_i_zerop(t5);
t7=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=(C_truep(t6)?lf[1]:C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k750 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_752(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_752,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_755,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t1))){
/* chicken-profile.scm:76: error */
t3=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[70];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_768,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_770,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm:77: sort */
t5=C_fast_retrieve(lf[65]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t1;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k753 in k750 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_755,2,av);}
t2=C_mutate2(&lf[0] /* (set! file ...) */,t1);
t3=((C_word*)t0)[2];
f_745(t3,t2);}

/* k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1391(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_1391,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:188: with-input-from-file */
t3=C_fast_retrieve(lf[66]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[0];
av2[3]=lf[21];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1394(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_1394,2,av);}
a=C_alloc(10);
t2=C_i_car(t1);
t3=t2;
t4=C_u_i_cdr(t1);
t5=C_i_check_list_2(t4,lf[44]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1404,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1899,a[2]=t3,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_1899(t10,t6,t4,C_fix(0));}

/* k657 */
static void C_ccall f_659(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_659,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_662,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k1493 in print-row in k1483 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 in ... */
static void C_ccall f_1495(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1495,2,av);}
/* chicken-profile.scm:239: print */
t2=*((C_word*)lf[50]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1112 in k1108 in k919 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1114(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1114,2,av);}
a=C_alloc(3);
t2=C_mutate2(&lf[3] /* (set! average-digits ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1118,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:151: arg-digit */
t4=C_retrieve2(lf[90],"arg-digit");
f_1075(t4,t3,C_fix(2));}

/* loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_735(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(24,0,2))){
C_save_and_reclaim_args((void *)trf_735,3,t0,t1,t2);}
a=C_alloc(24);
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_745,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(lf[0])){
t4=t3;
f_745(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_752,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:74: glob */
t5=C_fast_retrieve(lf[72]);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[73];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}
else{
t3=C_i_car(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_788,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t12=t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_807,a[2]=t4,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_830,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_truep(C_i_equalp(t4,lf[76]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[77]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[78]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
/* chicken-profile.scm:94: print-usage */
f_688(t13);}
else{
if(C_truep(C_i_string_equal_p(t4,lf[79]))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_848,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_855,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:96: chicken-version */
t16=C_fast_retrieve(lf[81]);{
C_word av2[2];
av2[0]=t16;
av2[1]=t15;
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}
else{
if(C_truep(C_u_i_string_equal_p(t4,lf[82]))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_863,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_870,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:99: chicken-version */
t16=C_fast_retrieve(lf[81]);{
C_word av2[2];
av2[0]=t16;
av2[1]=t15;
((C_proc)(void*)(*((C_word*)t16+1)))(2,av2);}}
else{
if(C_truep(C_u_i_string_equal_p(t4,lf[83]))){
t14=lf[1] /* no-unused */ =C_SCHEME_TRUE;;
/* chicken-profile.scm:112: loop */
t18=t1;
t19=((C_word*)t7)[1];
t1=t18;
t2=t19;
goto loop;}
else{
if(C_truep(C_u_i_string_equal_p(t4,lf[84]))){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_885,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm:102: next-number */
t15=t10;
f_807(t15,t14);}
else{
if(C_truep(C_u_i_string_equal_p(t4,lf[85]))){
t14=C_mutate2(&lf[20] /* (set! sort-by ...) */,lf[14]);
/* chicken-profile.scm:112: loop */
t18=t1;
t19=((C_word*)t7)[1];
t1=t18;
t2=t19;
goto loop;}
else{
if(C_truep(C_u_i_string_equal_p(t4,lf[86]))){
t14=C_mutate2(&lf[20] /* (set! sort-by ...) */,lf[15]);
/* chicken-profile.scm:112: loop */
t18=t1;
t19=((C_word*)t7)[1];
t1=t18;
t2=t19;
goto loop;}
else{
if(C_truep(C_u_i_string_equal_p(t4,lf[87]))){
t14=C_mutate2(&lf[20] /* (set! sort-by ...) */,lf[16]);
/* chicken-profile.scm:112: loop */
t18=t1;
t19=((C_word*)t7)[1];
t1=t18;
t2=t19;
goto loop;}
else{
if(C_truep(C_u_i_string_equal_p(t4,lf[88]))){
t14=C_mutate2(&lf[20] /* (set! sort-by ...) */,lf[17]);
/* chicken-profile.scm:112: loop */
t18=t1;
t19=((C_word*)t7)[1];
t1=t18;
t2=t19;
goto loop;}
else{
if(C_truep(C_u_i_string_equal_p(t4,lf[89]))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_921,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:107: next-arg */
t15=((C_word*)t9)[1];
f_788(t15,t14);}
else{
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_927,a[2]=t13,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t15=C_block_size(t4);
if(C_truep(C_fixnum_greaterp(t15,C_fix(1)))){
t16=C_i_string_ref(t4,C_fix(0));
t17=t14;
f_927(t17,C_u_i_char_equalp(C_make_character(45),t16));}
else{
t16=t14;
f_927(t16,C_SCHEME_FALSE);}}}}}}}}}}}}}

/* k1116 in k1112 in k1108 in k919 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1118(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1118,2,av);}
t2=C_mutate2(&lf[4] /* (set! percent-digits ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1108 in k919 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1110(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1110,2,av);}
a=C_alloc(3);
t2=C_mutate2(&lf[2] /* (set! seconds-digits ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:150: arg-digit */
t4=C_retrieve2(lf[90],"arg-digit");
f_1075(t4,t3,C_fix(1));}

/* k1375 in k1371 in k1339 in k1383 in format-real in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1377(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1377,2,av);}
a=C_alloc(4);
t2=C_a_i_times(&a,2,((C_word*)t0)[2],t1);
/* chicken-profile.scm:182: truncate */
t3=*((C_word*)lf[40]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k1371 in k1339 in k1383 in format-real in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1373,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1377,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:183: expt */
t4=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_fix(10);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k1642 in a1630 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1644(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_1644,2,av);}
a=C_alloc(7);
t2=((C_word*)t0)[2];
t3=C_i_check_list_2(t1,lf[25]);
t4=C_i_check_list_2(t2,lf[25]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1655,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_1655(t8,((C_word*)t0)[5],t1,t2);}

/* k1483 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1485(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_1485,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1487,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1573,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-profile.scm:240: print-row */
t5=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
f_1487(3,av2);}}

/* k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1482(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(27,c,4))){C_save_and_reclaim((void *)f_1482,2,av);}
a=C_alloc(27);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1485,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1631,tmp=(C_word)a,a+=2,tmp);
t5=C_a_i_list5(&a,5,C_fix(0),C_fix(0),C_fix(0),C_fix(0),C_fix(0));
t6=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);
/* chicken-profile.scm:233: fold */
t7=C_fast_retrieve(lf[56]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=t4;
av2[3]=t5;
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* print-row in k1483 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1487(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(20,c,5))){C_save_and_reclaim((void *)f_1487,3,av);}
a=C_alloc(20);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1495,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=lf[31];
t9=C_i_check_list_2(t2,lf[25]);
t10=C_i_check_list_2(((C_word*)t0)[2],lf[25]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1508,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1510,a[2]=t6,a[3]=t13,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_1510(t15,t11,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_745(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,4))){
C_save_and_reclaim_args((void *)trf_745,2,t0,t1);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1391,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:187: print */
t4=*((C_word*)lf[50]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[67];
av2[3]=lf[0];
av2[4]=lf[68];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k1592 in for-each-loop333 in k1574 in k1571 in k1483 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in ... */
static void C_ccall f_1594(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1594,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1584(t3,((C_word*)t0)[4],t2);}

/* k1162 in doloop66 in k1150 in k1133 in k1130 in read-profile in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1164(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1164,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:158: read */
t3=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k1383 in format-real in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1385(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_1385,2,av);}
a=C_alloc(6);
t2=C_i_inexact_to_exact(t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* ##sys#fixnum->string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[39]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[39]+1);
av2[1]=t4;
av2[2]=t3;
tp(3,av2);}}

/* k1281 in format-string in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1283(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1283,2,av);}
if(C_truep(((C_word*)t0)[2])){
t2=((C_word*)t0)[3];
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[32]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[32]+1);
av2[1]=((C_word*)t0)[4];
av2[2]=t1;
av2[3]=t2;
tp(4,av2);}}
else{
t2=((C_word*)t0)[3];
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[32]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[32]+1);
av2[1]=((C_word*)t0)[4];
av2[2]=t2;
av2[3]=t1;
tp(4,av2);}}}

/* k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1473(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(36,c,3))){C_save_and_reclaim((void *)f_1473,2,av);}
a=C_alloc(36);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_a_i_list5(&a,5,lf[45],lf[46],lf[47],lf[48],lf[49]);
t4=t3;
t5=C_a_i_list5(&a,5,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1482,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[57]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[57]+1);
av2[1]=t7;
av2[2]=C_fix(2);
av2[3]=C_make_character(32);
tp(4,av2);}}

/* k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1470(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_1470,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1747,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1747(t6,t2,t1);}

/* k1169 in k1162 in doloop66 in k1150 in k1133 in k1130 in read-profile in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1171,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
f_1154(t2,((C_word*)t0)[3],t1);}

/* map-loop198 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_1747(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,0,2))){
C_save_and_reclaim_args((void *)trf_1747,3,t0,t1,t2);}
a=C_alloc(13);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1772,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=C_i_cadr(t6);
t8=t7;
t9=C_i_caddr(t6);
t10=t9;
t11=C_i_cadddr(t6);
t12=t11;
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1428,a[2]=t5,a[3]=t12,a[4]=t10,a[5]=t8,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* chicken-profile.scm:218: fifth */
t14=C_fast_retrieve(lf[61]);{
C_word av2[3];
av2[0]=t14;
av2[1]=t13;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t14+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* for-each-loop333 in k1574 in k1571 in k1483 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in ... */
static void C_fcall f_1584(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1584,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1594,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-profile.scm:244: g334 */
t5=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* arg-digit in k919 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_1075(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,4))){
C_save_and_reclaim_args((void *)trf_1075,3,t0,t1,t2);}
a=C_alloc(9);
t3=C_i_string_ref(((C_word*)t0)[2],t2);
t4=C_fix(C_character_code(t3));
t5=C_a_i_minus(&a,2,t4,C_fix(48));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1085,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm:146: <= */{
C_word av2[5];
av2[0]=0;
av2[1]=t7;
av2[2]=C_fix(0);
av2[3]=t6;
av2[4]=C_fix(9);
C_less_or_equal_p(5,av2);}}

/* k1351 in k1339 in k1383 in format-real in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1353(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1353,2,av);}
a=C_alloc(4);
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* chicken-profile.scm:179: substring */
t3=*((C_word*)lf[38]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=C_fix(1);
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* print-usage in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_688(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(27,0,2))){
C_save_and_reclaim_args((void *)trf_688,1,t1);}
a=C_alloc(27);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_692,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_699,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,lf[9],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[4],t4);
t6=C_a_i_cons(&a,2,lf[10],t5);
t7=C_a_i_cons(&a,2,lf[3],t6);
t8=C_a_i_cons(&a,2,lf[11],t7);
t9=C_a_i_cons(&a,2,lf[2],t8);
t10=C_a_i_cons(&a,2,lf[12],t9);
/* chicken-profile.scm:44: ##sys#print-to-string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[13]);
C_word av2[3];
av2[0]=*((C_word*)lf[13]+1);
av2[1]=t3;
av2[2]=t10;
tp(3,av2);}}

/* k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_680(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(22,c,4))){C_save_and_reclaim((void *)f_680,2,av);}
a=C_alloc(22);
t2=lf[0] /* file */ =C_SCHEME_FALSE;;
t3=lf[1] /* no-unused */ =C_SCHEME_FALSE;;
t4=lf[2] /* seconds-digits */ =C_fix(3);;
t5=lf[3] /* average-digits */ =C_fix(3);;
t6=lf[4] /* percent-digits */ =C_fix(3);;
t7=lf[5] /* top */ =C_fix(0);;
t8=C_mutate2(&lf[6] /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_688,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate2(&lf[14] /* (set! sort-by-calls ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_952,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate2(&lf[15] /* (set! sort-by-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_987,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate2(&lf[16] /* (set! sort-by-avg ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1014,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate2(&lf[17] /* (set! sort-by-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1043,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2(&lf[20] /* (set! sort-by ...) */,lf[15]);
t14=C_mutate2(&lf[21] /* (set! read-profile ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1128,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2(&lf[31] /* (set! format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1264,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate2(&lf[34] /* (set! format-real ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1330,tmp=(C_word)a,a+=2,tmp));
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1958,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:246: command-line-arguments */
t19=C_fast_retrieve(lf[94]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t19;
av2[1]=t18;
((C_proc)(void*)(*((C_word*)t19+1)))(2,av2);}}

/* k1571 in k1483 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_1573,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1609,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:241: reduce */
t5=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=*((C_word*)lf[54]+1);
av2[3]=C_fix(0);
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point

void C_ccall C_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(314)){
C_save(t1);
C_rereclaim2(314*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,95);
lf[7]=C_h_intern(&lf[7],4,"exit");
lf[8]=C_h_intern(&lf[8],7,"display");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\001\242)\012 -no-unused                remove procedures that are never called\012 -top "
"N                    display only the top N entries\012 -help                     s"
"how this text and exit\012 -version                  show version and exit\012 -releas"
"e                  show release number and exit\012\012 FILENAME defaults to the `PROF"
"ILE.<number>\047, selecting the one with\012 the highest modification time, in case mu"
"ltiple profiles exist.\012");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\001\315Usage: chicken-profile [FILENAME | OPTION] ...\012\012 -sort-by-calls            "
"sort output by call frequency\012 -sort-by-time             sort output by procedur"
"e execution time\012 -sort-by-avg              sort output by average procedure exe"
"cution time\012 -sort-by-name             sort output alphabetically by procedure n"
"ame\012 -decimals DDD             set number of decimals for seconds, average and\012 "
"                          percent columns (three digits, default: ");
lf[13]=C_h_intern(&lf[13],19,"\003sysprint-to-string");
lf[18]=C_h_intern(&lf[18],8,"string<\077");
lf[19]=C_h_intern(&lf[19],14,"symbol->string");
lf[22]=C_h_intern(&lf[22],12,"instrumented");
lf[23]=C_h_intern(&lf[23],17,"hash-table->alist");
lf[24]=C_h_intern(&lf[24],4,"read");
lf[25]=C_h_intern(&lf[25],3,"map");
lf[26]=C_h_intern(&lf[26],15,"hash-table-set!");
lf[27]=C_h_intern(&lf[27],22,"hash-table-ref/default");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\000\376\003\000\000\002\376\377\001\000\000\000\000\376\377\016");
lf[29]=C_h_intern(&lf[29],15,"make-hash-table");
lf[30]=C_h_intern(&lf[30],3,"eq\077");
lf[32]=C_h_intern(&lf[32],17,"\003sysstring-append");
lf[33]=C_h_intern(&lf[33],11,"make-string");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[37]=C_h_intern(&lf[37],13,"string-append");
lf[38]=C_h_intern(&lf[38],9,"substring");
lf[39]=C_h_intern(&lf[39],18,"\003sysfixnum->string");
lf[40]=C_h_intern(&lf[40],8,"truncate");
lf[41]=C_h_intern(&lf[41],4,"expt");
lf[42]=C_h_intern(&lf[42],1,"-");
lf[43]=C_h_intern(&lf[43],25,"\003sysimplicit-exit-handler");
lf[44]=C_h_intern(&lf[44],5,"foldl");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\011procedure");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\005calls");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\007seconds");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\007average");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\007percent");
lf[50]=C_h_intern(&lf[50],5,"print");
lf[51]=C_h_intern(&lf[51],11,"string-join");
lf[52]=C_h_intern(&lf[52],8,"for-each");
lf[53]=C_h_intern(&lf[53],6,"reduce");
lf[54]=C_h_intern(&lf[54],1,"+");
lf[55]=C_h_intern(&lf[55],3,"max");
lf[56]=C_h_intern(&lf[56],4,"fold");
lf[57]=C_h_intern(&lf[57],15,"\003sysmake-string");
lf[58]=C_h_intern(&lf[58],14,"number->string");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\010overflow");
lf[60]=C_h_intern(&lf[60],28,"\003syssymbol->qualified-string");
lf[61]=C_h_intern(&lf[61],5,"fifth");
lf[62]=C_h_intern(&lf[62],6,"remove");
lf[63]=C_h_intern(&lf[63],4,"take");
lf[64]=C_h_intern(&lf[64],6,"append");
lf[65]=C_h_intern(&lf[65],4,"sort");
lf[66]=C_h_intern(&lf[66],20,"with-input-from-file");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\011reading `");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\006\047 ...\012");
lf[69]=C_h_intern(&lf[69],5,"error");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\021no PROFILEs found");
lf[71]=C_h_intern(&lf[71],22,"file-modification-time");
lf[72]=C_h_intern(&lf[72],4,"glob");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\011PROFILE.\052");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\032missing argument to option");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid argument to option");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\032chicken-profile - Version ");
lf[81]=C_h_intern(&lf[81],15,"chicken-version");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\012-no-unused");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\004-top");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\016-sort-by-calls");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-time");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\014-sort-by-avg");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-name");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\011-decimals");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[94]=C_h_intern(&lf[94],22,"command-line-arguments");
C_register_lf2(lf,95,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_659,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* k1574 in k1571 in k1483 in k1480 in k1471 in k1468 in k1408 in k1405 in k1402 in k1392 in k1389 in k743 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 in ... */
static void C_ccall f_1576(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1576,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_i_check_list_2(t3,lf[52]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1584,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_1584(t8,((C_word*)t0)[4],t3);}

/* k1083 in arg-digit in k919 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1085(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1085,2,av);}
if(C_truep(t1)){
t2=C_i_nequalp(((C_word*)t0)[2],C_fix(9));
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=(C_truep(t2)?C_fix(8):((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* chicken-profile.scm:148: error */
t2=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[91];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* k1363 in k1339 in k1383 in format-real in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1365(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1365,2,av);}
t2=C_i_inexact_to_exact(t1);
/* ##sys#fixnum->string */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[39]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[39]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
tp(3,av2);}}

/* format-string in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1264(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +5,c,3))){
C_save_and_reclaim((void*)f_1264,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+5);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_make_character(32):C_i_car(t9));
t12=C_i_nullp(t9);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t14=C_i_string_length(t2);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1283,a[2]=t7,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t16=C_fixnum_difference(t3,t14);
t17=C_i_fixnum_max(C_fix(0),t16);
/* chicken-profile.scm:169: make-string */
t18=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t18;
av2[1]=t15;
av2[2]=t17;
av2[3]=t11;
((C_proc)(void*)(*((C_word*)t18+1)))(4,av2);}}

/* k776 in a769 in k750 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_778(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_778,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_782,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:80: file-modification-time */
t4=C_fast_retrieve(lf[71]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1049 in sort-by-name in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1051(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1051,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1055,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[3]);
/* chicken-profile.scm:136: symbol->string */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* a769 in k750 in loop in k1956 in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_770(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_770,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_778,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:79: file-modification-time */
t5=C_fast_retrieve(lf[71]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k1053 in k1049 in sort-by-name in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_ccall f_1055(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1055,2,av);}
/* chicken-profile.scm:136: string<? */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* format-real in k678 in k675 in k672 in k669 in k666 in k663 in k660 in k657 */
static void C_fcall f_1330(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1330,3,t1,t2,t3);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1385,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm:175: truncate */
t5=*((C_word*)lf[40]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[117] = {
{"f_788:chicken_2dprofile_2escm",(void*)f_788},
{"f_782:chicken_2dprofile_2escm",(void*)f_782},
{"f_1349:chicken_2dprofile_2escm",(void*)f_1349},
{"f_1341:chicken_2dprofile_2escm",(void*)f_1341},
{"f_848:chicken_2dprofile_2escm",(void*)f_848},
{"f_855:chicken_2dprofile_2escm",(void*)f_855},
{"f_768:chicken_2dprofile_2escm",(void*)f_768},
{"f_830:chicken_2dprofile_2escm",(void*)f_830},
{"f_1193:chicken_2dprofile_2escm",(void*)f_1193},
{"f_827:chicken_2dprofile_2escm",(void*)f_827},
{"f_885:chicken_2dprofile_2escm",(void*)f_885},
{"f_870:chicken_2dprofile_2escm",(void*)f_870},
{"f_863:chicken_2dprofile_2escm",(void*)f_863},
{"f_1804:chicken_2dprofile_2escm",(void*)f_1804},
{"f_1800:chicken_2dprofile_2escm",(void*)f_1800},
{"f_952:chicken_2dprofile_2escm",(void*)f_952},
{"f_1148:chicken_2dprofile_2escm",(void*)f_1148},
{"f_1141:chicken_2dprofile_2escm",(void*)f_1141},
{"f_1451:chicken_2dprofile_2escm",(void*)f_1451},
{"f_927:chicken_2dprofile_2escm",(void*)f_927},
{"f_921:chicken_2dprofile_2escm",(void*)f_921},
{"f_1443:chicken_2dprofile_2escm",(void*)f_1443},
{"f_1447:chicken_2dprofile_2escm",(void*)f_1447},
{"f_1813:chicken_2dprofile_2escm",(void*)f_1813},
{"f_1128:chicken_2dprofile_2escm",(void*)f_1128},
{"f_807:chicken_2dprofile_2escm",(void*)f_807},
{"f_1703:chicken_2dprofile_2escm",(void*)f_1703},
{"f_1135:chicken_2dprofile_2escm",(void*)f_1135},
{"f_1132:chicken_2dprofile_2escm",(void*)f_1132},
{"f_1543:chicken_2dprofile_2escm",(void*)f_1543},
{"f_1772:chicken_2dprofile_2escm",(void*)f_1772},
{"f_1609:chicken_2dprofile_2escm",(void*)f_1609},
{"f_1043:chicken_2dprofile_2escm",(void*)f_1043},
{"f_1435:chicken_2dprofile_2escm",(void*)f_1435},
{"f_1655:chicken_2dprofile_2escm",(void*)f_1655},
{"f_1928:chicken_2dprofile_2escm",(void*)f_1928},
{"f_1014:chicken_2dprofile_2escm",(void*)f_1014},
{"f_1920:chicken_2dprofile_2escm",(void*)f_1920},
{"f_1439:chicken_2dprofile_2escm",(void*)f_1439},
{"f_1428:chicken_2dprofile_2escm",(void*)f_1428},
{"f_1831:chicken_2dprofile_2escm",(void*)f_1831},
{"f_1205:chicken_2dprofile_2escm",(void*)f_1205},
{"f_1838:chicken_2dprofile_2escm",(void*)f_1838},
{"f_1203:chicken_2dprofile_2escm",(void*)f_1203},
{"f_1410:chicken_2dprofile_2escm",(void*)f_1410},
{"f_699:chicken_2dprofile_2escm",(void*)f_699},
{"f_1865:chicken_2dprofile_2escm",(void*)f_1865},
{"f_1863:chicken_2dprofile_2escm",(void*)f_1863},
{"f_1215:chicken_2dprofile_2escm",(void*)f_1215},
{"f_1407:chicken_2dprofile_2escm",(void*)f_1407},
{"f_692:chicken_2dprofile_2escm",(void*)f_692},
{"f_1404:chicken_2dprofile_2escm",(void*)f_1404},
{"f_1954:chicken_2dprofile_2escm",(void*)f_1954},
{"f_1951:chicken_2dprofile_2escm",(void*)f_1951},
{"f_1958:chicken_2dprofile_2escm",(void*)f_1958},
{"f_1631:chicken_2dprofile_2escm",(void*)f_1631},
{"f_1890:chicken_2dprofile_2escm",(void*)f_1890},
{"f_1899:chicken_2dprofile_2escm",(void*)f_1899},
{"f_1517:chicken_2dprofile_2escm",(void*)f_1517},
{"f_1510:chicken_2dprofile_2escm",(void*)f_1510},
{"f_1948:chicken_2dprofile_2escm",(void*)f_1948},
{"f_1152:chicken_2dprofile_2escm",(void*)f_1152},
{"f_1154:chicken_2dprofile_2escm",(void*)f_1154},
{"f_1684:chicken_2dprofile_2escm",(void*)f_1684},
{"f_662:chicken_2dprofile_2escm",(void*)f_662},
{"f_1508:chicken_2dprofile_2escm",(void*)f_1508},
{"f_665:chicken_2dprofile_2escm",(void*)f_665},
{"f_668:chicken_2dprofile_2escm",(void*)f_668},
{"f_1937:chicken_2dprofile_2escm",(void*)f_1937},
{"f_1617:chicken_2dprofile_2escm",(void*)f_1617},
{"f_674:chicken_2dprofile_2escm",(void*)f_674},
{"f_677:chicken_2dprofile_2escm",(void*)f_677},
{"f_671:chicken_2dprofile_2escm",(void*)f_671},
{"f_987:chicken_2dprofile_2escm",(void*)f_987},
{"f_1781:chicken_2dprofile_2escm",(void*)f_1781},
{"f_752:chicken_2dprofile_2escm",(void*)f_752},
{"f_755:chicken_2dprofile_2escm",(void*)f_755},
{"f_1391:chicken_2dprofile_2escm",(void*)f_1391},
{"f_1394:chicken_2dprofile_2escm",(void*)f_1394},
{"f_659:chicken_2dprofile_2escm",(void*)f_659},
{"f_1495:chicken_2dprofile_2escm",(void*)f_1495},
{"f_1114:chicken_2dprofile_2escm",(void*)f_1114},
{"f_735:chicken_2dprofile_2escm",(void*)f_735},
{"f_1118:chicken_2dprofile_2escm",(void*)f_1118},
{"f_1110:chicken_2dprofile_2escm",(void*)f_1110},
{"f_1377:chicken_2dprofile_2escm",(void*)f_1377},
{"f_1373:chicken_2dprofile_2escm",(void*)f_1373},
{"f_1644:chicken_2dprofile_2escm",(void*)f_1644},
{"f_1485:chicken_2dprofile_2escm",(void*)f_1485},
{"f_1482:chicken_2dprofile_2escm",(void*)f_1482},
{"f_1487:chicken_2dprofile_2escm",(void*)f_1487},
{"f_745:chicken_2dprofile_2escm",(void*)f_745},
{"f_1594:chicken_2dprofile_2escm",(void*)f_1594},
{"f_1164:chicken_2dprofile_2escm",(void*)f_1164},
{"f_1385:chicken_2dprofile_2escm",(void*)f_1385},
{"f_1283:chicken_2dprofile_2escm",(void*)f_1283},
{"f_1473:chicken_2dprofile_2escm",(void*)f_1473},
{"f_1470:chicken_2dprofile_2escm",(void*)f_1470},
{"f_1171:chicken_2dprofile_2escm",(void*)f_1171},
{"f_1747:chicken_2dprofile_2escm",(void*)f_1747},
{"f_1584:chicken_2dprofile_2escm",(void*)f_1584},
{"f_1075:chicken_2dprofile_2escm",(void*)f_1075},
{"f_1353:chicken_2dprofile_2escm",(void*)f_1353},
{"f_688:chicken_2dprofile_2escm",(void*)f_688},
{"f_680:chicken_2dprofile_2escm",(void*)f_680},
{"f_1573:chicken_2dprofile_2escm",(void*)f_1573},
{"toplevel:chicken_2dprofile_2escm",(void*)C_toplevel},
{"f_1576:chicken_2dprofile_2escm",(void*)f_1576},
{"f_1085:chicken_2dprofile_2escm",(void*)f_1085},
{"f_1365:chicken_2dprofile_2escm",(void*)f_1365},
{"f_1264:chicken_2dprofile_2escm",(void*)f_1264},
{"f_778:chicken_2dprofile_2escm",(void*)f_778},
{"f_1051:chicken_2dprofile_2escm",(void*)f_1051},
{"f_770:chicken_2dprofile_2escm",(void*)f_770},
{"f_1055:chicken_2dprofile_2escm",(void*)f_1055},
{"f_1330:chicken_2dprofile_2escm",(void*)f_1330},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  for-each		1
S|  foldl		1
S|  map		6
o|eliminated procedure checks: 36 
o|specializations:
o|  1 (make-string fixnum char)
o|  3 (##sys#check-list (or pair list) *)
o|  2 (number->string fixnum)
o|  2 (string-append string string)
o|  2 (first pair)
o|  1 (= fixnum fixnum)
o|  2 (third (pair * (pair * pair)))
o|  3 (second (pair * pair))
o|  1 (char=? char char)
o|  1 (string-ref string fixnum)
o|  1 (> fixnum fixnum)
o|  1 (string-length string)
o|  8 (string=? string string)
o|  3 (cdr pair)
(o e)|safe calls: 211 
o|dropping redundant toplevel assignment: sort-by 
o|safe globals: (write-profile format-real format-string read-profile set-decimals sort-by sort-by-name sort-by-avg sort-by-time sort-by-calls run print-usage top percent-digits average-digits seconds-digits no-unused file) 
o|Removed `not' forms: 1 
o|inlining procedure: k960 
o|inlining procedure: k960 
o|inlining procedure: k980 
o|inlining procedure: k980 
o|inlining procedure: k995 
o|inlining procedure: k995 
o|inlining procedure: k1022 
o|inlining procedure: k1022 
o|inlining procedure: k1156 
o|inlining procedure: k1156 
o|inlining procedure: k1207 
o|contracted procedure: "(chicken-profile.scm:162) g7787" 
o|inlining procedure: k1182 
o|inlining procedure: k1182 
o|inlining procedure: k1207 
o|inlining procedure: k1284 
o|inlining procedure: k1284 
o|contracted procedure: "(chicken-profile.scm:246) run" 
o|inlining procedure: k737 
o|contracted procedure: "(chicken-profile.scm:81) write-profile" 
o|inlining procedure: k1512 
o|inlining procedure: k1512 
o|inlining procedure: k1562 
o|inlining procedure: k1562 
o|inlining procedure: k1586 
o|inlining procedure: k1586 
o|substituted constant variable: spacing231 
o|inlining procedure: k1657 
o|inlining procedure: k1657 
o|inlining procedure: k1705 
o|inlining procedure: k1705 
o|substituted constant variable: spacing231 
o|substituted constant variable: spacing231 
o|substituted constant variable: a1745 
o|inlining procedure: k1749 
o|contracted procedure: "(chicken-profile.scm:214) g204213" 
o|contracted procedure: k1460 
o|inlining procedure: k1749 
o|inlining procedure: k1783 
o|inlining procedure: k1783 
o|inlining procedure: k1839 
o|inlining procedure: k1839 
o|inlining procedure: k1852 
o|inlining procedure: k1852 
o|inlining procedure: k1867 
o|inlining procedure: k1867 
o|inlining procedure: k1901 
o|inlining procedure: k1901 
o|substituted constant variable: g141144 
o|inlining procedure: k753 
o|inlining procedure: k753 
o|inlining procedure: k790 
o|inlining procedure: k790 
o|inlining procedure: k812 
o|inlining procedure: k812 
o|inlining procedure: k737 
o|inlining procedure: k840 
o|inlining procedure: k840 
o|substituted constant variable: a860 
o|substituted constant variable: a875 
o|inlining procedure: k871 
o|inlining procedure: k871 
o|substituted constant variable: a881 
o|substituted constant variable: a890 
o|inlining procedure: k886 
o|inlining procedure: k886 
o|substituted constant variable: a896 
o|substituted constant variable: a902 
o|inlining procedure: k898 
o|inlining procedure: k898 
o|substituted constant variable: a908 
o|substituted constant variable: a914 
o|inlining procedure: k910 
o|contracted procedure: "(chicken-profile.scm:107) set-decimals" 
o|inlining procedure: k1080 
o|inlining procedure: k1080 
o|folded constant expression: (char->integer (quote #\0)) 
o|inlining procedure: k1068 
o|inlining procedure: k1068 
o|substituted constant variable: a1126 
o|inlining procedure: k910 
o|inlining procedure: k931 
o|inlining procedure: k931 
o|substituted constant variable: a944 
o|substituted constant variable: a941 
o|substituted constant variable: a949 
o|replaced variables: 192 
o|removed binding forms: 90 
o|substituted constant variable: r9811962 
o|substituted constant variable: r11831971 
o|substituted constant variable: r15631979 
o|converted assignments to bindings: (print-row293) 
o|substituted constant variable: r17841989 
o|substituted constant variable: r18401992 
o|substituted constant variable: r18401992 
o|substituted constant variable: r18531995 
o|inlining procedure: k828 
o|inlining procedure: k828 
o|inlining procedure: k828 
o|inlining procedure: k828 
o|inlining procedure: k828 
o|inlining procedure: k828 
o|contracted procedure: k1100 
o|inlining procedure: k828 
o|simplifications: ((let . 1)) 
o|replaced variables: 12 
o|removed binding forms: 219 
o|substituted constant variable: r1101 
o|replaced variables: 8 
o|removed binding forms: 32 
o|inlining procedure: k1232 
o|inlining procedure: k1232 
o|inlining procedure: k815 
o|removed binding forms: 6 
o|substituted constant variable: r12332109 
o|substituted constant variable: r12332110 
o|substituted constant variable: r8162129 
o|removed conditional forms: 1 
o|removed binding forms: 3 
o|simplifications: ((if . 16) (##core#call . 173)) 
o|  call simplifications:
o|    member
o|    string=?
o|    ##sys#size
o|    fx>
o|    string-ref
o|    char->integer
o|    <=
o|    string->number
o|    eq?	2
o|    <
o|    zero?
o|    fourth
o|    /	4
o|    list	6
o|    length	2
o|    -	2
o|    *	3
o|    inexact->exact	2
o|    car	5
o|    null?	7
o|    cdr	3
o|    string-length	3
o|    fx-
o|    fxmax
o|    symbol?	2
o|    eof-object?
o|    ##sys#check-list	9
o|    pair?	12
o|    +	4
o|    ##sys#setslot	6
o|    ##sys#slot	30
o|    first	4
o|    cadddr	2
o|    =	2
o|    second	5
o|    eqv?	2
o|    third	8
o|    >	11
o|    cons	23
o|contracted procedure: k725 
o|contracted procedure: k721 
o|contracted procedure: k717 
o|contracted procedure: k713 
o|contracted procedure: k709 
o|contracted procedure: k705 
o|contracted procedure: k701 
o|contracted procedure: k954 
o|contracted procedure: k957 
o|contracted procedure: k963 
o|contracted procedure: k970 
o|contracted procedure: k974 
o|contracted procedure: k989 
o|contracted procedure: k992 
o|contracted procedure: k998 
o|contracted procedure: k1016 
o|contracted procedure: k1019 
o|contracted procedure: k1025 
o|contracted procedure: k1057 
o|contracted procedure: k1061 
o|contracted procedure: k1260 
o|contracted procedure: k1136 
o|contracted procedure: k1159 
o|contracted procedure: k1173 
o|contracted procedure: k1177 
o|contracted procedure: k1195 
o|contracted procedure: k1198 
o|contracted procedure: k1246 
o|contracted procedure: k1210 
o|contracted procedure: k1216 
o|contracted procedure: k1224 
o|contracted procedure: k1228 
o|contracted procedure: k1236 
o|contracted procedure: k1240 
o|contracted procedure: k1232 
o|contracted procedure: k1254 
o|contracted procedure: k1323 
o|contracted procedure: k1266 
o|contracted procedure: k1317 
o|contracted procedure: k1269 
o|contracted procedure: k1311 
o|contracted procedure: k1272 
o|contracted procedure: k1305 
o|contracted procedure: k1275 
o|contracted procedure: k1278 
o|contracted procedure: k1302 
o|contracted procedure: k1298 
o|contracted procedure: k1332 
o|contracted procedure: k1378 
o|contracted procedure: k1343 
o|contracted procedure: k1355 
o|contracted procedure: k1359 
o|contracted procedure: k1367 
o|contracted procedure: k740 
o|contracted procedure: k1395 
o|contracted procedure: k1399 
o|contracted procedure: k1412 
o|contracted procedure: k1474 
o|contracted procedure: k1477 
o|contracted procedure: k1497 
o|contracted procedure: k1500 
o|contracted procedure: k1503 
o|contracted procedure: k1518 
o|contracted procedure: k1521 
o|contracted procedure: k1529 
o|contracted procedure: k1533 
o|contracted procedure: k1537 
o|contracted procedure: k1545 
o|contracted procedure: k1549 
o|contracted procedure: k1553 
o|contracted procedure: k1559 
o|contracted procedure: k1565 
o|contracted procedure: k1577 
o|contracted procedure: k1589 
o|contracted procedure: k1599 
o|contracted procedure: k1603 
o|contracted procedure: k1627 
o|contracted procedure: k1623 
o|contracted procedure: k1619 
o|contracted procedure: k1611 
o|contracted procedure: k1633 
o|contracted procedure: k1636 
o|contracted procedure: k1639 
o|contracted procedure: k1645 
o|contracted procedure: k1648 
o|contracted procedure: k1696 
o|contracted procedure: k1660 
o|contracted procedure: k1663 
o|contracted procedure: k1666 
o|contracted procedure: k1674 
o|contracted procedure: k1678 
o|contracted procedure: k1686 
o|contracted procedure: k1690 
o|contracted procedure: k1708 
o|contracted procedure: k1730 
o|contracted procedure: k1726 
o|contracted procedure: k1711 
o|contracted procedure: k1714 
o|contracted procedure: k1722 
o|contracted procedure: k1737 
o|contracted procedure: k1741 
o|contracted procedure: k1752 
o|contracted procedure: k1755 
o|contracted procedure: k1758 
o|contracted procedure: k1766 
o|contracted procedure: k1774 
o|contracted procedure: k1417 
o|contracted procedure: k1420 
o|contracted procedure: k1423 
o|contracted procedure: k1453 
o|contracted procedure: k1457 
o|contracted procedure: k1786 
o|contracted procedure: k1792 
o|contracted procedure: k1806 
o|contracted procedure: k1810 
o|contracted procedure: k1819 
o|contracted procedure: k1822 
o|contracted procedure: k1832 
o|inlining procedure: k1825 
o|inlining procedure: k1825 
o|contracted procedure: k1842 
o|contracted procedure: k1849 
o|contracted procedure: k1855 
o|contracted procedure: k1870 
o|contracted procedure: k1873 
o|contracted procedure: k1876 
o|contracted procedure: k1884 
o|contracted procedure: k1892 
o|contracted procedure: k1904 
o|contracted procedure: k1911 
o|contracted procedure: k1925 
o|contracted procedure: k1915 
o|contracted procedure: k1934 
o|contracted procedure: k1943 
o|contracted procedure: k1922 
o|contracted procedure: k756 
o|inlining procedure: k753 
o|contracted procedure: k783 
o|contracted procedure: k793 
o|contracted procedure: k799 
o|contracted procedure: k803 
o|contracted procedure: k809 
o|contracted procedure: k815 
o|contracted procedure: k834 
o|contracted procedure: k843 
o|contracted procedure: k1123 
o|contracted procedure: k1071 
o|contracted procedure: k1104 
o|contracted procedure: k1096 
o|contracted procedure: k1077 
o|contracted procedure: k1089 
o|contracted procedure: k946 
o|contracted procedure: k938 
o|simplifications: ((if . 1) (let . 20)) 
o|removed binding forms: 150 
o|replaced variables: 80 
o|removed binding forms: 1 
o|removed binding forms: 42 
o|customizable procedures: (k925 arg-digit next-number24 print-usage loop11 next-arg23 k743 foldl142146 g166175 map-loop160189 k1829 k1836 k1408 format-real map-loop198222 map-loop259276 map-loop238283 for-each-loop333343 k1515 map-loop297318 k1213 map-loop7194 doloop6667) 
o|calls to known targets: 58 
o|identified direct recursive calls: f_1703 1 
o|identified direct recursive calls: f_735 5 
o|fast box initializations: 11 
o|fast global references: 29 
o|fast global assignments: 28 
o|dropping unused closure argument: f_688 
o|dropping unused closure argument: f_1330 
*/
/* end of file */
