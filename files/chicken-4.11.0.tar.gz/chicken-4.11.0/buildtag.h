#define C_BUILD_TAG "compiled 2016-05-28 on yves.more-magic.net (Linux)"
