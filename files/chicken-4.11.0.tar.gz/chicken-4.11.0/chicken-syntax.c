/* Generated from chicken-syntax.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:49
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: chicken-syntax.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file chicken-syntax.c
   unit: chicken_2dsyntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[296];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,25),40,97,51,54,57,48,32,120,50,53,52,52,32,114,50,53,52,53,32,99,50,53,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,18),40,103,50,53,50,48,32,99,108,97,117,115,101,50,53,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,53,49,52,32,103,50,53,50,54,50,53,51,55,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,25),40,97,51,55,53,48,32,120,50,53,48,51,32,114,50,53,48,52,32,99,50,53,48,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,34),40,109,97,112,45,108,111,111,112,50,52,53,57,32,103,50,52,55,49,50,52,56,52,32,103,50,52,55,50,50,52,56,53,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,52,50,50,32,103,50,52,51,52,50,52,52,56,41};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,50,32,97,110,97,109,101,115,50,52,49,54,32,105,50,52,49,55,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,37),40,108,111,111,112,32,97,114,103,115,50,52,48,50,32,97,110,97,109,101,115,50,52,48,51,32,97,116,121,112,101,115,50,52,48,52,41,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,25),40,97,51,56,55,51,32,120,50,51,56,52,32,114,50,51,56,53,32,99,50,51,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,24),40,97,52,51,48,56,32,116,121,112,101,50,51,56,50,32,118,97,114,50,51,56,51,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,51,53,54,32,103,50,51,54,56,50,51,55,53,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,51,50,56,32,103,50,51,52,48,50,51,52,55,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,50,50,56,48,32,108,50,50,55,53,50,51,49,56,32,108,101,110,50,50,55,54,50,51,49,57,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,50,50,56,48,32,108,50,50,55,53,50,51,48,50,32,108,101,110,50,50,55,54,50,51,48,51,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,52),40,97,52,50,52,48,32,105,110,112,117,116,50,50,55,52,50,50,56,55,32,114,101,110,97,109,101,50,50,56,51,50,50,56,56,32,99,111,109,112,97,114,101,50,50,55,49,50,50,56,57,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,97,52,53,52,57,32,120,50,50,54,51,32,114,50,50,54,52,32,99,50,50,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,7),40,97,52,54,48,56,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,58),40,97,52,54,49,56,32,116,121,112,101,50,50,51,55,50,50,51,56,50,50,52,51,32,112,114,101,100,50,50,51,57,50,50,52,48,50,50,52,52,32,112,117,114,101,50,50,52,49,50,50,52,50,50,50,52,53,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,25),40,97,52,53,56,55,32,120,50,50,51,50,32,114,50,50,51,51,32,99,50,50,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,15),40,103,50,50,48,48,32,97,114,103,50,50,49,49,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,49,57,52,32,103,50,50,48,54,50,50,50,50,41};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,25),40,97,52,54,57,53,32,120,50,49,55,57,32,114,50,49,56,48,32,99,50,49,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,25),40,97,52,56,53,56,32,120,50,49,54,49,32,114,50,49,54,50,32,99,50,49,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,50,49,49,57,32,108,50,49,49,52,50,49,53,50,32,108,101,110,50,49,49,53,50,49,53,51,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,50,49,49,57,32,108,50,49,49,52,50,49,52,49,32,108,101,110,50,49,49,53,50,49,52,50,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,52),40,97,52,57,52,53,32,105,110,112,117,116,50,49,49,51,50,49,50,54,32,114,101,110,97,109,101,50,49,50,50,50,49,50,55,32,99,111,109,112,97,114,101,50,49,49,48,50,49,50,56,41,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,52),40,97,53,48,57,51,32,105,110,112,117,116,50,48,55,57,50,48,57,50,32,114,101,110,97,109,101,50,48,56,56,50,48,57,51,32,99,111,109,112,97,114,101,50,48,55,54,50,48,57,52,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,25),40,97,53,49,57,48,32,120,50,48,54,56,32,114,50,48,54,57,32,99,50,48,55,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,25),40,97,53,50,49,49,32,120,50,48,54,49,32,114,50,48,54,50,32,99,50,48,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,28),40,97,53,50,50,56,32,102,111,114,109,50,48,53,52,32,114,50,48,53,53,32,99,50,48,53,54,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,28),40,97,53,50,53,55,32,102,111,114,109,50,48,52,51,32,114,50,48,52,52,32,99,50,48,52,53,41,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,47),40,108,111,111,112,32,120,115,50,48,50,49,32,118,97,114,115,50,48,50,50,32,98,115,50,48,50,51,32,118,97,108,115,50,48,50,52,32,114,101,115,116,50,48,50,53,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,28),40,97,53,51,50,50,32,102,111,114,109,50,48,49,52,32,114,50,48,49,53,32,99,50,48,49,54,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,40),40,108,111,111,112,32,120,115,49,57,57,49,32,118,97,114,115,49,57,57,50,32,118,97,108,115,49,57,57,51,32,114,101,115,116,49,57,57,52,41};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,28),40,97,53,53,50,49,32,102,111,114,109,49,57,56,52,32,114,49,57,56,53,32,99,49,57,56,54,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,7),40,103,49,57,50,55,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,108,111,116,115,49,57,52,55,32,105,49,57,52,56,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,57,50,49,32,103,49,57,51,51,49,57,52,48,41};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,56,57,50,32,103,49,57,48,52,49,57,49,48,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,28),40,97,53,55,48,49,32,102,111,114,109,49,56,55,55,32,114,49,56,55,56,32,99,49,56,55,57,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,7),40,103,49,56,49,52,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,56,48,56,32,103,49,56,50,48,49,56,51,48,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,20),40,112,97,114,115,101,45,99,108,97,117,115,101,32,99,49,55,56,57,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,56,51,57,32,103,49,56,53,49,49,56,53,55,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,28),40,97,54,48,56,50,32,102,111,114,109,49,55,55,55,32,114,49,55,55,56,32,99,49,55,55,57,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,28),40,97,54,51,54,55,32,102,111,114,109,49,55,54,53,32,114,49,55,54,54,32,99,49,55,54,55,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,28),40,97,54,52,56,54,32,102,111,114,109,49,55,52,52,32,114,49,55,52,53,32,99,49,55,52,54,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,54,50,54,41,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,15),40,103,101,110,118,97,114,115,32,110,49,54,50,52,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,54,54,55,56,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,34),40,109,97,112,45,108,111,111,112,49,55,49,49,32,103,49,55,50,51,49,55,51,49,32,103,49,55,50,52,49,55,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,27),40,98,117,105,108,100,32,118,97,114,115,50,49,54,56,57,32,118,114,101,115,116,49,54,57,48,41,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,27),40,97,54,54,56,56,32,118,97,114,115,49,49,54,56,53,32,118,97,114,115,50,49,54,56,54,41,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,34),40,97,54,54,53,56,32,118,97,114,115,49,54,55,50,32,97,114,103,99,49,54,55,51,32,114,101,115,116,49,54,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,22),40,97,54,54,52,56,32,99,49,54,55,48,32,98,111,100,121,49,54,55,49,41,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,34),40,97,54,57,48,55,32,118,97,114,115,49,54,52,57,32,97,114,103,99,49,54,53,48,32,114,101,115,116,49,54,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,54,51,49,32,103,49,54,52,51,49,54,53,51,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,28),40,97,54,53,53,57,32,102,111,114,109,49,54,50,48,32,114,49,54,50,49,32,99,49,54,50,50,41,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,27),40,108,111,111,112,32,97,114,103,115,49,54,48,50,32,118,97,114,100,101,102,115,49,54,48,51,41,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,28),40,97,55,48,48,49,32,102,111,114,109,49,53,56,56,32,114,49,53,56,57,32,99,49,53,57,48,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,28),40,97,55,49,53,55,32,102,111,114,109,49,53,55,51,32,114,49,53,55,52,32,99,49,53,55,53,41,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,48),40,114,101,99,117,114,32,118,97,114,115,49,52,51,52,32,100,101,102,97,117,108,116,101,114,115,49,52,51,53,32,110,111,110,45,100,101,102,97,117,108,116,115,49,52,51,54,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,61),40,109,97,107,101,45,105,102,45,116,114,101,101,32,118,97,114,115,49,52,50,56,32,100,101,102,97,117,108,116,101,114,115,49,52,50,57,32,98,111,100,121,45,112,114,111,99,49,52,51,48,32,114,101,115,116,49,52,51,49,41,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,31),40,112,114,101,102,105,120,45,115,121,109,32,112,114,101,102,105,120,49,52,55,51,32,115,121,109,49,52,55,52,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,13),40,103,49,52,56,52,32,118,49,52,57,53,41,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,15),40,103,49,53,52,49,32,118,97,114,49,53,53,50,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,58),40,114,101,99,117,114,32,118,97,114,115,49,52,49,57,32,100,101,102,97,117,108,116,101,114,45,110,97,109,101,115,49,52,50,48,32,100,101,102,115,49,52,50,49,32,110,101,120,116,45,103,117,121,49,52,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,53,51,53,32,103,49,53,52,55,49,53,53,52,41};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,53,48,54,32,103,49,53,49,56,49,53,50,52,41};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,52,55,56,32,103,49,52,57,48,49,52,57,55,41};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,52,52,56,32,103,49,52,54,48,49,52,54,54,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,28),40,97,55,50,52,54,32,102,111,114,109,49,52,48,53,32,114,49,52,48,54,32,99,49,52,48,55,41,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,7),40,103,49,51,55,55,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,51,55,49,32,103,49,51,56,51,49,51,57,51,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,30),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,51,52,56,32,101,108,115,101,63,49,51,52,57,41,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,28),40,97,55,54,57,52,32,102,111,114,109,49,51,51,54,32,114,49,51,51,55,32,99,49,51,51,56,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,13),40,102,111,108,100,32,98,115,49,51,49,51,41,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,28),40,97,55,56,54,50,32,102,111,114,109,49,51,48,55,32,114,49,51,48,56,32,99,49,51,48,57,41,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,32),40,113,117,111,116,105,102,121,45,112,114,111,99,49,50,56,54,32,120,115,49,50,56,57,32,105,100,49,50,57,48,41};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,28),40,97,55,57,53,57,32,102,111,114,109,49,50,56,51,32,114,49,50,56,52,32,99,49,50,56,53,41,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,28),40,97,56,48,54,51,32,102,111,114,109,49,50,55,53,32,114,49,50,55,54,32,99,49,50,55,55,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,34),40,109,97,112,45,108,111,111,112,49,50,52,50,32,103,49,50,53,52,49,50,54,50,32,103,49,50,53,53,49,50,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,49,57,52,32,103,49,50,48,54,49,50,51,52,41};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,25),40,97,56,50,56,55,32,97,49,50,50,56,32,95,49,50,50,57,32,95,49,50,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,31),40,102,111,108,100,108,49,50,49,55,32,103,49,50,49,56,49,50,50,50,32,103,49,50,49,54,49,50,50,51,41,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,49,54,53,32,103,49,49,55,55,49,49,56,51,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,49,51,57,32,103,49,49,53,49,49,49,53,55,41};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,28),40,97,56,49,49,49,32,102,111,114,109,49,49,51,48,32,114,49,49,51,49,32,99,49,49,51,50,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,20),40,102,111,108,100,32,118,98,105,110,100,105,110,103,115,49,49,50,49,41,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,28),40,97,56,51,54,57,32,102,111,114,109,49,49,49,52,32,114,49,49,49,53,32,99,49,49,49,54,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,23),40,97,112,112,101,110,100,42,57,52,53,32,105,108,57,53,49,32,108,57,53,50,41,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,22),40,109,97,112,42,57,52,54,32,112,114,111,99,57,53,51,32,108,57,53,52,41,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,13),40,103,49,48,48,54,32,118,49,48,49,55,41,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,14),40,108,111,111,107,117,112,32,118,49,48,50,54,41,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,13),40,103,49,48,53,55,32,118,49,48,54,56,41,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,48,53,49,32,103,49,48,54,51,49,48,55,48,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,38),40,102,111,108,100,32,108,108,105,115,116,115,49,48,51,57,32,101,120,112,115,49,48,52,48,32,108,108,105,115,116,115,50,49,48,52,49,41,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,48,56,54,32,103,49,48,57,56,49,49,48,53,41};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,108,108,105,115,116,115,49,48,50,57,32,97,99,99,49,48,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,48,48,48,32,103,49,48,49,50,49,48,49,57,41};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,57,56,56,32,97,99,99,57,56,57,41,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,57,54,50,32,103,57,55,52,57,56,48,41,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,25),40,97,56,52,50,51,32,102,111,114,109,57,52,48,32,114,57,52,49,32,99,57,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,57,49,56,32,103,57,50,53,57,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,31),40,97,56,57,50,50,32,118,97,114,115,57,49,51,32,97,114,103,99,57,49,52,32,114,101,115,116,57,49,53,41,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,25),40,97,56,57,48,48,32,102,111,114,109,57,49,48,32,114,57,49,49,32,99,57,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,25),40,97,56,57,55,48,32,102,111,114,109,57,48,54,32,114,57,48,55,32,99,57,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,25),40,97,56,57,57,49,32,102,111,114,109,56,57,57,32,114,57,48,48,32,99,57,48,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,25),40,97,57,48,49,57,32,102,111,114,109,56,57,50,32,114,56,57,51,32,99,56,57,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,11),40,103,54,48,48,32,122,54,49,49,41,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,6),40,103,54,50,56,41,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,6),40,103,54,53,54,41,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,19),40,103,55,52,56,32,115,55,54,52,32,116,101,109,112,55,54,53,41,0,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,56,53,54,32,103,56,54,56,56,56,49,32,103,56,54,57,56,56,50,41,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,56,50,48,32,103,56,51,50,56,52,53,32,103,56,51,51,56,52,54,41,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,55,56,52,32,103,55,57,54,56,48,57,32,103,55,57,55,56,49,48,41,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,37),40,109,97,112,45,108,111,111,112,55,52,50,32,103,55,53,52,55,55,48,32,103,55,53,53,55,55,49,32,103,55,53,54,55,55,50,41,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,55,49,49,32,103,55,50,51,55,51,49,32,103,55,50,52,55,51,50,41,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,54,56,48,32,103,54,57,50,55,48,48,32,103,54,57,51,55,48,49,41,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,54,53,48,32,103,54,54,50,54,54,57,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,54,50,50,32,103,54,51,52,54,52,49,41,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,53,57,52,32,103,54,48,54,54,49,51,41,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,53,54,55,32,103,53,55,57,53,56,53,41,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,53,52,48,32,103,53,53,50,53,53,56,41,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,25),40,97,57,48,52,51,32,102,111,114,109,53,50,55,32,114,53,50,56,32,99,53,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,115,115,53,48,54,41,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,25),40,97,57,55,55,52,32,102,111,114,109,52,57,49,32,114,52,57,50,32,99,52,57,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,6),40,103,50,48,53,41,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,6),40,103,50,51,51,41,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,52,53,54,32,103,52,54,56,52,56,49,32,103,52,54,57,52,56,50,41,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,52,50,48,32,103,52,51,50,52,52,53,32,103,52,51,51,52,52,54,41,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,51,56,52,32,103,51,57,54,52,48,57,32,103,51,57,55,52,49,48,41,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,51,52,56,32,103,51,54,48,51,55,51,32,103,51,54,49,51,55,52,41,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,51,49,52,32,103,51,50,54,51,51,55,32,103,51,50,55,51,51,56,41,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,110,51,51,52,41,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,50,53,55,32,103,50,54,57,51,48,51,32,103,50,55,48,51,48,52,41,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,50,55,56,32,103,50,57,48,50,57,54,41,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,50,50,55,32,103,50,51,57,50,52,54,41,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,49,57,57,32,103,50,49,49,50,49,56,41,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,49,55,50,32,103,49,56,52,49,57,48,41,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,25),40,97,57,56,55,53,32,102,111,114,109,49,54,52,32,114,49,54,53,32,99,49,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,26),40,97,49,48,53,50,56,32,102,111,114,109,49,53,48,32,114,49,53,49,32,99,49,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,26),40,97,49,48,54,48,51,32,102,111,114,109,49,51,48,32,114,49,51,49,32,99,49,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,26),40,97,49,48,54,57,50,32,102,111,114,109,49,50,50,32,114,49,50,51,32,99,49,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,26),40,97,49,48,55,48,57,32,102,111,114,109,49,49,54,32,114,49,49,55,32,99,49,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,26),40,97,49,48,55,50,51,32,102,111,114,109,49,48,57,32,114,49,49,48,32,99,49,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,23),40,97,49,48,55,55,50,32,102,111,114,109,56,55,32,114,56,56,32,99,56,57,41,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,12),40,103,51,49,32,115,108,111,116,52,50,41,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,22),40,109,97,112,115,108,111,116,115,32,115,108,111,116,115,54,50,32,105,54,51,41,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,50,53,32,103,51,55,53,50,41,0,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,20),40,97,49,48,56,54,53,32,120,49,51,32,114,49,52,32,99,49,53,41,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,20),40,97,49,49,50,50,55,32,102,111,114,109,54,32,114,55,32,99,56,41,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word *av) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word *av) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240(C_word c,C_word *av) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word *av) C_noret;
C_noret_decl(f_5256)
static void C_ccall f_5256(C_word c,C_word *av) C_noret;
C_noret_decl(f_7274)
static void C_ccall f_7274(C_word c,C_word *av) C_noret;
C_noret_decl(f_7270)
static void C_ccall f_7270(C_word c,C_word *av) C_noret;
C_noret_decl(f_5248)
static void C_ccall f_5248(C_word c,C_word *av) C_noret;
C_noret_decl(f_7278)
static void C_ccall f_7278(C_word c,C_word *av) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word *av) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word *av) C_noret;
C_noret_decl(f_4648)
static void C_fcall f_4648(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4335)
static void C_fcall f_4335(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7280)
static void C_fcall f_7280(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word *av) C_noret;
C_noret_decl(f_4696)
static void C_ccall f_4696(C_word c,C_word *av) C_noret;
C_noret_decl(f_9096)
static void C_fcall f_9096(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9092)
static void C_ccall f_9092(C_word c,C_word *av) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086(C_word c,C_word *av) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word *av) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word *av) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word *av) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word *av) C_noret;
C_noret_decl(f_9387)
static void C_fcall f_9387(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9077)
static void C_ccall f_9077(C_word c,C_word *av) C_noret;
C_noret_decl(f_9074)
static void C_ccall f_9074(C_word c,C_word *av) C_noret;
C_noret_decl(f_9071)
static void C_ccall f_9071(C_word c,C_word *av) C_noret;
C_noret_decl(f_5227)
static void C_ccall f_5227(C_word c,C_word *av) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word *av) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word *av) C_noret;
C_noret_decl(f_5233)
static void C_ccall f_5233(C_word c,C_word *av) C_noret;
C_noret_decl(f_9063)
static void C_ccall f_9063(C_word c,C_word *av) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229(C_word c,C_word *av) C_noret;
C_noret_decl(f_10681)
static void C_ccall f_10681(C_word c,C_word *av) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655(C_word c,C_word *av) C_noret;
C_noret_decl(f_10674)
static void C_ccall f_10674(C_word c,C_word *av) C_noret;
C_noret_decl(f_3658)
static void C_ccall f_3658(C_word c,C_word *av) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word *av) C_noret;
C_noret_decl(f_8825)
static void C_fcall f_8825(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10664)
static void C_ccall f_10664(C_word c,C_word *av) C_noret;
C_noret_decl(f_8838)
static void C_ccall f_8838(C_word c,C_word *av) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word *av) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word *av) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word *av) C_noret;
C_noret_decl(f_8816)
static void C_ccall f_8816(C_word c,C_word *av) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695(C_word c,C_word *av) C_noret;
C_noret_decl(f_4762)
static void C_ccall f_4762(C_word c,C_word *av) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765(C_word c,C_word *av) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word *av) C_noret;
C_noret_decl(f_10448)
static void C_ccall f_10448(C_word c,C_word *av) C_noret;
C_noret_decl(f_4774)
static void C_fcall f_4774(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10697)
static void C_ccall f_10697(C_word c,C_word *av) C_noret;
C_noret_decl(f_10691)
static void C_ccall f_10691(C_word c,C_word *av) C_noret;
C_noret_decl(f_10693)
static void C_ccall f_10693(C_word c,C_word *av) C_noret;
C_noret_decl(f_9898)
static void C_fcall f_9898(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9894)
static void C_ccall f_9894(C_word c,C_word *av) C_noret;
C_noret_decl(f_10608)
static void C_ccall f_10608(C_word c,C_word *av) C_noret;
C_noret_decl(f_10604)
static void C_ccall f_10604(C_word c,C_word *av) C_noret;
C_noret_decl(f_10602)
static void C_ccall f_10602(C_word c,C_word *av) C_noret;
C_noret_decl(f_7539)
static void C_fcall f_7539(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9880)
static void C_ccall f_9880(C_word c,C_word *av) C_noret;
C_noret_decl(f_10457)
static void C_fcall f_10457(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9874)
static void C_ccall f_9874(C_word c,C_word *av) C_noret;
C_noret_decl(f_9876)
static void C_ccall f_9876(C_word c,C_word *av) C_noret;
C_noret_decl(f_3667)
static void C_ccall f_3667(C_word c,C_word *av) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word *av) C_noret;
C_noret_decl(f_10482)
static void C_ccall f_10482(C_word c,C_word *av) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word *av) C_noret;
C_noret_decl(f_9861)
static void C_ccall f_9861(C_word c,C_word *av) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word *av) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word *av) C_noret;
C_noret_decl(f_8996)
static void C_ccall f_8996(C_word c,C_word *av) C_noret;
C_noret_decl(f_9854)
static void C_ccall f_9854(C_word c,C_word *av) C_noret;
C_noret_decl(f_8992)
static void C_ccall f_8992(C_word c,C_word *av) C_noret;
C_noret_decl(f_8990)
static void C_ccall f_8990(C_word c,C_word *av) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word *av) C_noret;
C_noret_decl(f_8791)
static void C_fcall f_8791(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word *av) C_noret;
C_noret_decl(f_7503)
static void C_ccall f_7503(C_word c,C_word *av) C_noret;
C_noret_decl(f_7506)
static void C_ccall f_7506(C_word c,C_word *av) C_noret;
C_noret_decl(f_7500)
static void C_ccall f_7500(C_word c,C_word *av) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word *av) C_noret;
C_noret_decl(f_3689)
static void C_ccall f_3689(C_word c,C_word *av) C_noret;
C_noret_decl(f_10645)
static void C_fcall f_10645(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9847)
static void C_ccall f_9847(C_word c,C_word *av) C_noret;
C_noret_decl(f_8969)
static void C_ccall f_8969(C_word c,C_word *av) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word *av) C_noret;
C_noret_decl(f_10491)
static void C_fcall f_10491(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9837)
static void C_ccall f_9837(C_word c,C_word *av) C_noret;
C_noret_decl(f_8975)
static void C_ccall f_8975(C_word c,C_word *av) C_noret;
C_noret_decl(f_8971)
static void C_ccall f_8971(C_word c,C_word *av) C_noret;
C_noret_decl(f_8863)
static void C_fcall f_8863(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9826)
static void C_fcall f_9826(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8944)
static void C_fcall f_8944(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10622)
static void C_fcall f_10622(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10619)
static void C_ccall f_10619(C_word c,C_word *av) C_noret;
C_noret_decl(f_8954)
static void C_ccall f_8954(C_word c,C_word *av) C_noret;
C_noret_decl(f_10423)
static void C_fcall f_10423(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8368)
static void C_ccall f_8368(C_word c,C_word *av) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word *av) C_noret;
C_noret_decl(f_8923)
static void C_ccall f_8923(C_word c,C_word *av) C_noret;
C_noret_decl(f_8929)
static void C_ccall f_8929(C_word c,C_word *av) C_noret;
C_noret_decl(f_8370)
static void C_ccall f_8370(C_word c,C_word *av) C_noret;
C_noret_decl(f_8374)
static void C_ccall f_8374(C_word c,C_word *av) C_noret;
C_noret_decl(f_8936)
static void C_ccall f_8936(C_word c,C_word *av) C_noret;
C_noret_decl(f_7564)
static void C_ccall f_7564(C_word c,C_word *av) C_noret;
C_noret_decl(f_5620)
static void C_ccall f_5620(C_word c,C_word *av) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word *av) C_noret;
C_noret_decl(f_7573)
static void C_fcall f_7573(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6155)
static void C_fcall f_6155(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8332)
static void C_fcall f_8332(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6153)
static void C_ccall f_6153(C_word c,C_word *av) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word *av) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word *av) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word *av) C_noret;
C_noret_decl(f_7513)
static void C_ccall f_7513(C_word c,C_word *av) C_noret;
C_noret_decl(f_8485)
static void C_ccall f_8485(C_word c,C_word *av) C_noret;
C_noret_decl(f_8489)
static void C_ccall f_8489(C_word c,C_word *av) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word *av) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634(C_word c,C_word *av) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word *av) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word *av) C_noret;
C_noret_decl(f_3646)
static void C_ccall f_3646(C_word c,C_word *av) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word *av) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word *av) C_noret;
C_noret_decl(f_5637)
static void C_ccall f_5637(C_word c,C_word *av) C_noret;
C_noret_decl(f_6087)
static void C_ccall f_6087(C_word c,C_word *av) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word *av) C_noret;
C_noret_decl(f_6083)
static void C_ccall f_6083(C_word c,C_word *av) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643(C_word c,C_word *av) C_noret;
C_noret_decl(f_8455)
static void C_ccall f_8455(C_word c,C_word *av) C_noret;
C_noret_decl(f_6073)
static void C_ccall f_6073(C_word c,C_word *av) C_noret;
C_noret_decl(f_6090)
static void C_ccall f_6090(C_word c,C_word *av) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word *av) C_noret;
C_noret_decl(f_4755)
static void C_fcall f_4755(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189(C_word c,C_word *av) C_noret;
C_noret_decl(f_5191)
static void C_ccall f_5191(C_word c,C_word *av) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195(C_word c,C_word *av) C_noret;
C_noret_decl(f_6099)
static void C_ccall f_6099(C_word c,C_word *av) C_noret;
C_noret_decl(f_6096)
static void C_ccall f_6096(C_word c,C_word *av) C_noret;
C_noret_decl(f_6093)
static void C_ccall f_6093(C_word c,C_word *av) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word *av) C_noret;
C_noret_decl(f_5009)
static void C_fcall f_5009(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word *av) C_noret;
C_noret_decl(f_5059)
static void C_fcall f_5059(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10919)
static void C_ccall f_10919(C_word c,C_word *av) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word *av) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word *av) C_noret;
C_noret_decl(f_10976)
static void C_fcall f_10976(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10974)
static void C_ccall f_10974(C_word c,C_word *av) C_noret;
C_noret_decl(f_7156)
static void C_ccall f_7156(C_word c,C_word *av) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word *av) C_noret;
C_noret_decl(f_7158)
static void C_ccall f_7158(C_word c,C_word *av) C_noret;
C_noret_decl(f_5041)
static void C_ccall f_5041(C_word c,C_word *av) C_noret;
C_noret_decl(f_7148)
static void C_ccall f_7148(C_word c,C_word *av) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word *av) C_noret;
C_noret_decl(f_10951)
static void C_ccall f_10951(C_word c,C_word *av) C_noret;
C_noret_decl(f_7233)
static void C_ccall f_7233(C_word c,C_word *av) C_noret;
C_noret_decl(f_7237)
static void C_ccall f_7237(C_word c,C_word *av) C_noret;
C_noret_decl(f_4944)
static void C_ccall f_4944(C_word c,C_word *av) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word *av) C_noret;
C_noret_decl(f_4956)
static void C_ccall f_4956(C_word c,C_word *av) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word *av) C_noret;
C_noret_decl(f_7251)
static void C_ccall f_7251(C_word c,C_word *av) C_noret;
C_noret_decl(f_4969)
static void C_ccall f_4969(C_word c,C_word *av) C_noret;
C_noret_decl(f_10995)
static void C_ccall f_10995(C_word c,C_word *av) C_noret;
C_noret_decl(f_10998)
static void C_ccall f_10998(C_word c,C_word *av) C_noret;
C_noret_decl(f_7245)
static void C_ccall f_7245(C_word c,C_word *av) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word *av) C_noret;
C_noret_decl(f_7247)
static void C_ccall f_7247(C_word c,C_word *av) C_noret;
C_noret_decl(f_10992)
static void C_ccall f_10992(C_word c,C_word *av) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word *av) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word *av) C_noret;
C_noret_decl(f_9339)
static void C_fcall f_9339(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word *av) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word *av) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word *av) C_noret;
C_noret_decl(f_4413)
static void C_ccall f_4413(C_word c,C_word *av) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word *av) C_noret;
C_noret_decl(f_5425)
static void C_ccall f_5425(C_word c,C_word *av) C_noret;
C_noret_decl(f_9313)
static void C_ccall f_9313(C_word c,C_word *av) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word *av) C_noret;
C_noret_decl(f_9317)
static void C_ccall f_9317(C_word c,C_word *av) C_noret;
C_noret_decl(f_4422)
static void C_ccall f_4422(C_word c,C_word *av) C_noret;
C_noret_decl(f_7006)
static void C_ccall f_7006(C_word c,C_word *av) C_noret;
C_noret_decl(f_7002)
static void C_ccall f_7002(C_word c,C_word *av) C_noret;
C_noret_decl(f_7205)
static void C_ccall f_7205(C_word c,C_word *av) C_noret;
C_noret_decl(f_7000)
static void C_ccall f_7000(C_word c,C_word *av) C_noret;
C_noret_decl(f_5488)
static void C_ccall f_5488(C_word c,C_word *av) C_noret;
C_noret_decl(f_9044)
static void C_ccall f_9044(C_word c,C_word *av) C_noret;
C_noret_decl(f_9042)
static void C_ccall f_9042(C_word c,C_word *av) C_noret;
C_noret_decl(f_7077)
static void C_ccall f_7077(C_word c,C_word *av) C_noret;
C_noret_decl(f_8599)
static void C_fcall f_8599(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8597)
static void C_ccall f_8597(C_word c,C_word *av) C_noret;
C_noret_decl(f_8591)
static void C_ccall f_8591(C_word c,C_word *av) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692(C_word c,C_word *av) C_noret;
C_noret_decl(f_9329)
static void C_ccall f_9329(C_word c,C_word *av) C_noret;
C_noret_decl(f_5465)
static void C_ccall f_5465(C_word c,C_word *av) C_noret;
C_noret_decl(f_9020)
static void C_ccall f_9020(C_word c,C_word *av) C_noret;
C_noret_decl(f_9024)
static void C_ccall f_9024(C_word c,C_word *av) C_noret;
C_noret_decl(f_9018)
static void C_ccall f_9018(C_word c,C_word *av) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word *av) C_noret;
C_noret_decl(f_9553)
static void C_fcall f_9553(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4494)
static void C_ccall f_4494(C_word c,C_word *av) C_noret;
C_noret_decl(f_9293)
static void C_ccall f_9293(C_word c,C_word *av) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word *av) C_noret;
C_noret_decl(f_9505)
static void C_fcall f_9505(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word *av) C_noret;
C_noret_decl(f_9297)
static void C_ccall f_9297(C_word c,C_word *av) C_noret;
C_noret_decl(f_4487)
static void C_fcall f_4487(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9275)
static C_word C_fcall f_9275(C_word *a,C_word t0,C_word t1,C_word t2,C_word t3);
C_noret_decl(f_10188)
static void C_fcall f_10188(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7699)
static void C_ccall f_7699(C_word c,C_word *av) C_noret;
C_noret_decl(f_7695)
static void C_ccall f_7695(C_word c,C_word *av) C_noret;
C_noret_decl(f_7693)
static void C_ccall f_7693(C_word c,C_word *av) C_noret;
C_noret_decl(f_3914)
static void C_fcall f_3914(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word *av) C_noret;
C_noret_decl(f_8637)
static void C_fcall f_8637(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word *av) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word *av) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819(C_word c,C_word *av) C_noret;
C_noret_decl(f_8648)
static void C_ccall f_8648(C_word c,C_word *av) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word *av) C_noret;
C_noret_decl(f_7811)
static void C_ccall f_7811(C_word c,C_word *av) C_noret;
C_noret_decl(f_4821)
static void C_fcall f_4821(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7813)
static void C_fcall f_7813(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4872)
static void C_ccall f_4872(C_word c,C_word *av) C_noret;
C_noret_decl(f_7497)
static void C_ccall f_7497(C_word c,C_word *av) C_noret;
C_noret_decl(f_3970)
static void C_fcall f_3970(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8713)
static void C_fcall f_8713(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word *av) C_noret;
C_noret_decl(f_7489)
static void C_fcall f_7489(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4857)
static void C_ccall f_4857(C_word c,C_word *av) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word *av) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word *av) C_noret;
C_noret_decl(f_7485)
static void C_ccall f_7485(C_word c,C_word *av) C_noret;
C_noret_decl(f_7482)
static void C_ccall f_7482(C_word c,C_word *av) C_noret;
C_noret_decl(f_10114)
static void C_ccall f_10114(C_word c,C_word *av) C_noret;
C_noret_decl(f_10118)
static void C_ccall f_10118(C_word c,C_word *av) C_noret;
C_noret_decl(f_4869)
static void C_ccall f_4869(C_word c,C_word *av) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word *av) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word *av) C_noret;
C_noret_decl(f_4437)
static void C_fcall f_4437(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7800)
static C_word C_fcall f_7800(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_7455)
static void C_ccall f_7455(C_word c,C_word *av) C_noret;
C_noret_decl(f_7451)
static void C_ccall f_7451(C_word c,C_word *av) C_noret;
C_noret_decl(f_7459)
static void C_fcall f_7459(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10341)
static void C_fcall f_10341(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word *av) C_noret;
C_noret_decl(f_7877)
static void C_fcall f_7877(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4898)
static void C_ccall f_4898(C_word c,C_word *av) C_noret;
C_noret_decl(f_7443)
static void C_fcall f_7443(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7442)
static void C_ccall f_7442(C_word c,C_word *av) C_noret;
C_noret_decl(f_9170)
static void C_ccall f_9170(C_word c,C_word *av) C_noret;
C_noret_decl(f_7632)
static void C_ccall f_7632(C_word c,C_word *av) C_noret;
C_noret_decl(f_3704)
static void C_ccall f_3704(C_word c,C_word *av) C_noret;
C_noret_decl(f_3707)
static void C_ccall f_3707(C_word c,C_word *av) C_noret;
C_noret_decl(f_4895)
static void C_ccall f_4895(C_word c,C_word *av) C_noret;
C_noret_decl(f_6114)
static void C_fcall f_6114(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10140)
static void C_fcall f_10140(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6111)
static void C_fcall f_6111(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8624)
static void C_ccall f_8624(C_word c,C_word *av) C_noret;
C_noret_decl(f_6104)
static void C_ccall f_6104(C_word c,C_word *av) C_noret;
C_noret_decl(f_10130)
static void C_ccall f_10130(C_word c,C_word *av) C_noret;
C_noret_decl(f_6619)
static void C_ccall f_6619(C_word c,C_word *av) C_noret;
C_noret_decl(f_6108)
static void C_fcall f_6108(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6992)
static void C_ccall f_6992(C_word c,C_word *av) C_noret;
C_noret_decl(f_7641)
static void C_fcall f_7641(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6102)
static void C_ccall f_6102(C_word c,C_word *av) C_noret;
C_noret_decl(f_6616)
static void C_ccall f_6616(C_word c,C_word *av) C_noret;
C_noret_decl(f_6613)
static void C_ccall f_6613(C_word c,C_word *av) C_noret;
C_noret_decl(f_6610)
static void C_ccall f_6610(C_word c,C_word *av) C_noret;
C_noret_decl(f_6984)
static void C_ccall f_6984(C_word c,C_word *av) C_noret;
C_noret_decl(f_6607)
static void C_ccall f_6607(C_word c,C_word *av) C_noret;
C_noret_decl(f_6980)
static void C_ccall f_6980(C_word c,C_word *av) C_noret;
C_noret_decl(f_3749)
static void C_ccall f_3749(C_word c,C_word *av) C_noret;
C_noret_decl(f_6988)
static void C_ccall f_6988(C_word c,C_word *av) C_noret;
C_noret_decl(f_8685)
static void C_ccall f_8685(C_word c,C_word *av) C_noret;
C_noret_decl(f_6601)
static void C_ccall f_6601(C_word c,C_word *av) C_noret;
C_noret_decl(f_7863)
static void C_ccall f_7863(C_word c,C_word *av) C_noret;
C_noret_decl(f_7861)
static void C_ccall f_7861(C_word c,C_word *av) C_noret;
C_noret_decl(f_6604)
static void C_ccall f_6604(C_word c,C_word *av) C_noret;
C_noret_decl(f_7867)
static void C_ccall f_7867(C_word c,C_word *av) C_noret;
C_noret_decl(f_6976)
static void C_ccall f_6976(C_word c,C_word *av) C_noret;
C_noret_decl(f_8778)
static void C_ccall f_8778(C_word c,C_word *av) C_noret;
C_noret_decl(f_10389)
static void C_fcall f_10389(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3710)
static void C_ccall f_3710(C_word c,C_word *av) C_noret;
C_noret_decl(f_6635)
static void C_ccall f_6635(C_word c,C_word *av) C_noret;
C_noret_decl(f_6628)
static void C_ccall f_6628(C_word c,C_word *av) C_noret;
C_noret_decl(f_8785)
static void C_ccall f_8785(C_word c,C_word *av) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625(C_word c,C_word *av) C_noret;
C_noret_decl(f_6622)
static void C_ccall f_6622(C_word c,C_word *av) C_noret;
C_noret_decl(f_6033)
static void C_fcall f_6033(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7607)
static void C_fcall f_7607(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6139)
static C_word C_fcall f_6139(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_6945)
static void C_ccall f_6945(C_word c,C_word *av) C_noret;
C_noret_decl(f_3788)
static void C_fcall f_3788(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8412)
static void C_ccall f_8412(C_word c,C_word *av) C_noret;
C_noret_decl(f_10321)
static void C_fcall f_10321(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8462)
static void C_ccall f_8462(C_word c,C_word *av) C_noret;
C_noret_decl(f_6920)
static void C_fcall f_6920(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10335)
static void C_ccall f_10335(C_word c,C_word *av) C_noret;
C_noret_decl(f_8747)
static void C_fcall f_8747(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841(C_word c,C_word *av) C_noret;
C_noret_decl(f_5542)
static void C_fcall f_5542(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6689)
static void C_ccall f_6689(C_word c,C_word *av) C_noret;
C_noret_decl(f_5555)
static void C_ccall f_5555(C_word c,C_word *av) C_noret;
C_noret_decl(f_5811)
static void C_ccall f_5811(C_word c,C_word *av) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552(C_word c,C_word *av) C_noret;
C_noret_decl(f_6687)
static void C_ccall f_6687(C_word c,C_word *av) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word *av) C_noret;
C_noret_decl(f_3799)
static void C_ccall f_3799(C_word c,C_word *av) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word *av) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word *av) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word *av) C_noret;
C_noret_decl(f_8422)
static void C_ccall f_8422(C_word c,C_word *av) C_noret;
C_noret_decl(f_8424)
static void C_ccall f_8424(C_word c,C_word *av) C_noret;
C_noret_decl(f_8428)
static void C_ccall f_8428(C_word c,C_word *av) C_noret;
C_noret_decl(f_5561)
static void C_ccall f_5561(C_word c,C_word *av) C_noret;
C_noret_decl(f_6598)
static void C_ccall f_6598(C_word c,C_word *av) C_noret;
C_noret_decl(f_6590)
static void C_ccall f_6590(C_word c,C_word *av) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word *av) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word *av) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word *av) C_noret;
C_noret_decl(f_8434)
static void C_ccall f_8434(C_word c,C_word *av) C_noret;
C_noret_decl(f_6659)
static void C_ccall f_6659(C_word c,C_word *av) C_noret;
C_noret_decl(f_7685)
static void C_ccall f_7685(C_word c,C_word *av) C_noret;
C_noret_decl(f_7689)
static void C_ccall f_7689(C_word c,C_word *av) C_noret;
C_noret_decl(f_6647)
static void C_ccall f_6647(C_word c,C_word *av) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word *av) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word *av) C_noret;
C_noret_decl(f_6679)
static void C_ccall f_6679(C_word c,C_word *av) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word *av) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word *av) C_noret;
C_noret_decl(f_5522)
static void C_ccall f_5522(C_word c,C_word *av) C_noret;
C_noret_decl(f_6673)
static void C_fcall f_6673(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5520)
static void C_ccall f_5520(C_word c,C_word *av) C_noret;
C_noret_decl(f_6677)
static void C_ccall f_6677(C_word c,C_word *av) C_noret;
C_noret_decl(f_5786)
static void C_fcall f_5786(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5094)
static void C_ccall f_5094(C_word c,C_word *av) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word *av) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word *av) C_noret;
C_noret_decl(f_6663)
static void C_ccall f_6663(C_word c,C_word *av) C_noret;
C_noret_decl(f_5532)
static void C_ccall f_5532(C_word c,C_word *av) C_noret;
C_noret_decl(f_10708)
static void C_ccall f_10708(C_word c,C_word *av) C_noret;
C_noret_decl(f_8180)
static void C_fcall f_8180(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4165)
static void C_fcall f_4165(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11186)
static void C_ccall f_11186(C_word c,C_word *av) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word *av) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word *av) C_noret;
C_noret_decl(f_5721)
static void C_ccall f_5721(C_word c,C_word *av) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080(C_word c,C_word *av) C_noret;
C_noret_decl(f_8168)
static void C_ccall f_8168(C_word c,C_word *av) C_noret;
C_noret_decl(f_8164)
static void C_ccall f_8164(C_word c,C_word *av) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109(C_word c,C_word *av) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word *av) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word *av) C_noret;
C_noret_decl(f_8178)
static void C_ccall f_8178(C_word c,C_word *av) C_noret;
C_noret_decl(f_8908)
static void C_ccall f_8908(C_word c,C_word *av) C_noret;
C_noret_decl(f_8905)
static void C_ccall f_8905(C_word c,C_word *av) C_noret;
C_noret_decl(f_8901)
static void C_ccall f_8901(C_word c,C_word *av) C_noret;
C_noret_decl(f_10722)
static void C_ccall f_10722(C_word c,C_word *av) C_noret;
C_noret_decl(f_5803)
static void C_ccall f_5803(C_word c,C_word *av) C_noret;
C_noret_decl(f_5807)
static void C_fcall f_5807(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5584)
static void C_ccall f_5584(C_word c,C_word *av) C_noret;
C_noret_decl(f_8915)
static void C_ccall f_8915(C_word c,C_word *av) C_noret;
C_noret_decl(f_10710)
static void C_ccall f_10710(C_word c,C_word *av) C_noret;
C_noret_decl(f_5594)
static void C_ccall f_5594(C_word c,C_word *av) C_noret;
C_noret_decl(f_10728)
static void C_ccall f_10728(C_word c,C_word *av) C_noret;
C_noret_decl(f_10724)
static void C_ccall f_10724(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externexport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_11121)
static void C_ccall f_11121(C_word c,C_word *av) C_noret;
C_noret_decl(f_11125)
static void C_ccall f_11125(C_word c,C_word *av) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word *av) C_noret;
C_noret_decl(f_10771)
static void C_ccall f_10771(C_word c,C_word *av) C_noret;
C_noret_decl(f_5706)
static void C_ccall f_5706(C_word c,C_word *av) C_noret;
C_noret_decl(f_10773)
static void C_ccall f_10773(C_word c,C_word *av) C_noret;
C_noret_decl(f_5700)
static void C_ccall f_5700(C_word c,C_word *av) C_noret;
C_noret_decl(f_8090)
static void C_ccall f_8090(C_word c,C_word *av) C_noret;
C_noret_decl(f_10777)
static void C_ccall f_10777(C_word c,C_word *av) C_noret;
C_noret_decl(f_8071)
static void C_ccall f_8071(C_word c,C_word *av) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word *av) C_noret;
C_noret_decl(f_11166)
static void C_ccall f_11166(C_word c,C_word *av) C_noret;
C_noret_decl(f_11160)
static void C_ccall f_11160(C_word c,C_word *av) C_noret;
C_noret_decl(f_6290)
static void C_fcall f_6290(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4111)
static void C_fcall f_4111(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7038)
static void C_ccall f_7038(C_word c,C_word *av) C_noret;
C_noret_decl(f_6389)
static void C_ccall f_6389(C_word c,C_word *av) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word *av) C_noret;
C_noret_decl(f_11140)
static void C_ccall f_11140(C_word c,C_word *av) C_noret;
C_noret_decl(f_6378)
static void C_ccall f_6378(C_word c,C_word *av) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word *av) C_noret;
C_noret_decl(f_7066)
static void C_ccall f_7066(C_word c,C_word *av) C_noret;
C_noret_decl(f_6372)
static void C_ccall f_6372(C_word c,C_word *av) C_noret;
C_noret_decl(f_11190)
static void C_fcall f_11190(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6368)
static void C_ccall f_6368(C_word c,C_word *av) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366(C_word c,C_word *av) C_noret;
C_noret_decl(f_10799)
static void C_ccall f_10799(C_word c,C_word *av) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word *av) C_noret;
C_noret_decl(f_6259)
static void C_ccall f_6259(C_word c,C_word *av) C_noret;
C_noret_decl(f_8286)
static void C_ccall f_8286(C_word c,C_word *av) C_noret;
C_noret_decl(f_8288)
static void C_ccall f_8288(C_word c,C_word *av) C_noret;
C_noret_decl(f_6358)
static void C_ccall f_6358(C_word c,C_word *av) C_noret;
C_noret_decl(f_6354)
static void C_ccall f_6354(C_word c,C_word *av) C_noret;
C_noret_decl(f_8292)
static void C_ccall f_8292(C_word c,C_word *av) C_noret;
C_noret_decl(f_8298)
static void C_fcall f_8298(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8262)
static void C_fcall f_8262(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7024)
static void C_ccall f_7024(C_word c,C_word *av) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word *av) C_noret;
C_noret_decl(f_7027)
static void C_ccall f_7027(C_word c,C_word *av) C_noret;
C_noret_decl(f_7018)
static void C_ccall f_7018(C_word c,C_word *av) C_noret;
C_noret_decl(f_5333)
static void C_ccall f_5333(C_word c,C_word *av) C_noret;
C_noret_decl(f_5330)
static void C_ccall f_5330(C_word c,C_word *av) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word *av) C_noret;
C_noret_decl(f_7040)
static void C_fcall f_7040(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5353)
static void C_ccall f_5353(C_word c,C_word *av) C_noret;
C_noret_decl(f_5356)
static void C_ccall f_5356(C_word c,C_word *av) C_noret;
C_noret_decl(f_5765)
static void C_ccall f_5765(C_word c,C_word *av) C_noret;
C_noret_decl(f_5767)
static void C_fcall f_5767(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5323)
static void C_ccall f_5323(C_word c,C_word *av) C_noret;
C_noret_decl(f_5321)
static void C_ccall f_5321(C_word c,C_word *av) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word *av) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word *av) C_noret;
C_noret_decl(f_5373)
static void C_ccall f_5373(C_word c,C_word *av) C_noret;
C_noret_decl(f_7387)
static void C_ccall f_7387(C_word c,C_word *av) C_noret;
C_noret_decl(f_9210)
static void C_ccall f_9210(C_word c,C_word *av) C_noret;
C_noret_decl(f_9212)
static void C_fcall f_9212(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5343)
static void C_fcall f_5343(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5792)
static void C_fcall f_5792(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5799)
static void C_fcall f_5799(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word *av) C_noret;
C_noret_decl(f_4506)
static void C_fcall f_4506(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_fcall f_4067(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word *av) C_noret;
C_noret_decl(f_5362)
static void C_ccall f_5362(C_word c,C_word *av) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word *av) C_noret;
C_noret_decl(f_7341)
static void C_fcall f_7341(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7347)
static void C_fcall f_7347(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word *av) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word *av) C_noret;
C_noret_decl(f_7473)
static void C_ccall f_7473(C_word c,C_word *av) C_noret;
C_noret_decl(f_11012)
static void C_ccall f_11012(C_word c,C_word *av) C_noret;
C_noret_decl(f_7479)
static void C_ccall f_7479(C_word c,C_word *av) C_noret;
C_noret_decl(f_11024)
static void C_ccall f_11024(C_word c,C_word *av) C_noret;
C_noret_decl(f_9153)
static void C_ccall f_9153(C_word c,C_word *av) C_noret;
C_noret_decl(f_11028)
static void C_fcall f_11028(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7467)
static void C_ccall f_7467(C_word c,C_word *av) C_noret;
C_noret_decl(f_7411)
static void C_ccall f_7411(C_word c,C_word *av) C_noret;
C_noret_decl(f_7419)
static void C_ccall f_7419(C_word c,C_word *av) C_noret;
C_noret_decl(f_9140)
static void C_ccall f_9140(C_word c,C_word *av) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word *av) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word *av) C_noret;
C_noret_decl(f_9137)
static void C_ccall f_9137(C_word c,C_word *av) C_noret;
C_noret_decl(f_7430)
static void C_ccall f_7430(C_word c,C_word *av) C_noret;
C_noret_decl(f_7433)
static void C_ccall f_7433(C_word c,C_word *av) C_noret;
C_noret_decl(f_9122)
static void C_ccall f_9122(C_word c,C_word *av) C_noret;
C_noret_decl(f_9125)
static void C_ccall f_9125(C_word c,C_word *av) C_noret;
C_noret_decl(f_9129)
static void C_fcall f_9129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7427)
static void C_ccall f_7427(C_word c,C_word *av) C_noret;
C_noret_decl(f_9110)
static void C_ccall f_9110(C_word c,C_word *av) C_noret;
C_noret_decl(f_9114)
static void C_fcall f_9114(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8547)
static void C_ccall f_8547(C_word c,C_word *av) C_noret;
C_noret_decl(f_9104)
static void C_ccall f_9104(C_word c,C_word *av) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word *av) C_noret;
C_noret_decl(f_3826)
static void C_ccall f_3826(C_word c,C_word *av) C_noret;
C_noret_decl(f_3828)
static void C_fcall f_3828(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8525)
static void C_ccall f_8525(C_word c,C_word *av) C_noret;
C_noret_decl(f_8529)
static void C_ccall f_8529(C_word c,C_word *av) C_noret;
C_noret_decl(f_8535)
static void C_ccall f_8535(C_word c,C_word *av) C_noret;
C_noret_decl(f_10099)
static void C_ccall f_10099(C_word c,C_word *av) C_noret;
C_noret_decl(f_8536)
static void C_ccall f_8536(C_word c,C_word *av) C_noret;
C_noret_decl(f_10568)
static void C_fcall f_10568(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_ccall f_3853(C_word c,C_word *av) C_noret;
C_noret_decl(f_7960)
static void C_ccall f_7960(C_word c,C_word *av) C_noret;
C_noret_decl(f_7962)
static void C_fcall f_7962(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7966)
static void C_ccall f_7966(C_word c,C_word *av) C_noret;
C_noret_decl(f_9797)
static void C_ccall f_9797(C_word c,C_word *av) C_noret;
C_noret_decl(f_9794)
static void C_ccall f_9794(C_word c,C_word *av) C_noret;
C_noret_decl(f_9791)
static void C_ccall f_9791(C_word c,C_word *av) C_noret;
C_noret_decl(f_10545)
static void C_ccall f_10545(C_word c,C_word *av) C_noret;
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word *av) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550(C_word c,C_word *av) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word *av) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word *av) C_noret;
C_noret_decl(f_9788)
static void C_ccall f_9788(C_word c,C_word *av) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word *av) C_noret;
C_noret_decl(f_7987)
static void C_fcall f_7987(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9779)
static void C_ccall f_9779(C_word c,C_word *av) C_noret;
C_noret_decl(f_9775)
static void C_ccall f_9775(C_word c,C_word *av) C_noret;
C_noret_decl(f_9773)
static void C_ccall f_9773(C_word c,C_word *av) C_noret;
C_noret_decl(f_10041)
static void C_fcall f_10041(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word *av) C_noret;
C_noret_decl(f_3893)
static void C_ccall f_3893(C_word c,C_word *av) C_noret;
C_noret_decl(f_6818)
static void C_ccall f_6818(C_word c,C_word *av) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word *av) C_noret;
C_noret_decl(f_7922)
static void C_ccall f_7922(C_word c,C_word *av) C_noret;
C_noret_decl(f_10271)
static void C_fcall f_10271(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word *av) C_noret;
C_noret_decl(f_7710)
static void C_ccall f_7710(C_word c,C_word *av) C_noret;
C_noret_decl(f_7713)
static void C_ccall f_7713(C_word c,C_word *av) C_noret;
C_noret_decl(f_7958)
static void C_ccall f_7958(C_word c,C_word *av) C_noret;
C_noret_decl(f_9694)
static void C_ccall f_9694(C_word c,C_word *av) C_noret;
C_noret_decl(f_7707)
static void C_ccall f_7707(C_word c,C_word *av) C_noret;
C_noret_decl(f_8899)
static void C_ccall f_8899(C_word c,C_word *av) C_noret;
C_noret_decl(f_9737)
static void C_fcall f_9737(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9660)
static void C_ccall f_9660(C_word c,C_word *av) C_noret;
C_noret_decl(f_8583)
static void C_fcall f_8583(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7978)
static void C_ccall f_7978(C_word c,C_word *av) C_noret;
C_noret_decl(f_7975)
static void C_fcall f_7975(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7726)
static void C_fcall f_7726(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7724)
static void C_ccall f_7724(C_word c,C_word *av) C_noret;
C_noret_decl(f_8513)
static void C_ccall f_8513(C_word c,C_word *av) C_noret;
C_noret_decl(f_8510)
static void C_ccall f_8510(C_word c,C_word *av) C_noret;
C_noret_decl(f_8517)
static void C_fcall f_8517(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9669)
static void C_fcall f_9669(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6693)
static void C_ccall f_6693(C_word c,C_word *av) C_noret;
C_noret_decl(f_8562)
static void C_ccall f_8562(C_word c,C_word *av) C_noret;
C_noret_decl(f_8564)
static void C_fcall f_8564(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9993)
static void C_fcall f_9993(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word *av) C_noret;
C_noret_decl(f_9983)
static void C_ccall f_9983(C_word c,C_word *av) C_noret;
C_noret_decl(f_3570)
static void C_ccall f_3570(C_word c,C_word *av) C_noret;
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word *av) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word *av) C_noret;
C_noret_decl(f_10529)
static void C_ccall f_10529(C_word c,C_word *av) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word *av) C_noret;
C_noret_decl(f_10527)
static void C_ccall f_10527(C_word c,C_word *av) C_noret;
C_noret_decl(f_3582)
static void C_ccall f_3582(C_word c,C_word *av) C_noret;
C_noret_decl(f_7938)
static void C_ccall f_7938(C_word c,C_word *av) C_noret;
C_noret_decl(f_9635)
static void C_fcall f_9635(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9971)
static void C_ccall f_9971(C_word c,C_word *av) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word *av) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word *av) C_noret;
C_noret_decl(f_9967)
static void C_ccall f_9967(C_word c,C_word *av) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word *av) C_noret;
C_noret_decl(f_9626)
static void C_ccall f_9626(C_word c,C_word *av) C_noret;
C_noret_decl(f_3586)
static void C_ccall f_3586(C_word c,C_word *av) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word *av) C_noret;
C_noret_decl(f_7793)
static void C_ccall f_7793(C_word c,C_word *av) C_noret;
C_noret_decl(f_9955)
static void C_ccall f_9955(C_word c,C_word *av) C_noret;
C_noret_decl(f_6505)
static void C_ccall f_6505(C_word c,C_word *av) C_noret;
C_noret_decl(f_8158)
static void C_ccall f_8158(C_word c,C_word *av) C_noret;
C_noret_decl(f_10269)
static void C_ccall f_10269(C_word c,C_word *av) C_noret;
C_noret_decl(f_10260)
static void C_ccall f_10260(C_word c,C_word *av) C_noret;
C_noret_decl(f_6866)
static void C_ccall f_6866(C_word c,C_word *av) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word *av) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word *av) C_noret;
C_noret_decl(f_10533)
static void C_ccall f_10533(C_word c,C_word *av) C_noret;
C_noret_decl(f_10253)
static void C_ccall f_10253(C_word c,C_word *av) C_noret;
C_noret_decl(f_6477)
static void C_ccall f_6477(C_word c,C_word *av) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word *av) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word *av) C_noret;
C_noret_decl(f_8130)
static void C_ccall f_8130(C_word c,C_word *av) C_noret;
C_noret_decl(f_8136)
static void C_ccall f_8136(C_word c,C_word *av) C_noret;
C_noret_decl(f_10244)
static void C_ccall f_10244(C_word c,C_word *av) C_noret;
C_noret_decl(f_9931)
static void C_ccall f_9931(C_word c,C_word *av) C_noret;
C_noret_decl(f_6481)
static void C_ccall f_6481(C_word c,C_word *av) C_noret;
C_noret_decl(f_9924)
static void C_ccall f_9924(C_word c,C_word *av) C_noret;
C_noret_decl(f_8106)
static void C_ccall f_8106(C_word c,C_word *av) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word *av) C_noret;
C_noret_decl(f_9921)
static void C_ccall f_9921(C_word c,C_word *av) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word *av) C_noret;
C_noret_decl(f_5984)
static C_word C_fcall f_5984(C_word t0,C_word t1);
C_noret_decl(f_7751)
static void C_ccall f_7751(C_word c,C_word *av) C_noret;
C_noret_decl(f_7757)
static void C_ccall f_7757(C_word c,C_word *av) C_noret;
C_noret_decl(f_8062)
static void C_ccall f_8062(C_word c,C_word *av) C_noret;
C_noret_decl(f_8064)
static void C_ccall f_8064(C_word c,C_word *av) C_noret;
C_noret_decl(f_8068)
static void C_ccall f_8068(C_word c,C_word *av) C_noret;
C_noret_decl(f_8110)
static void C_ccall f_8110(C_word c,C_word *av) C_noret;
C_noret_decl(f_8112)
static void C_ccall f_8112(C_word c,C_word *av) C_noret;
C_noret_decl(f_8116)
static void C_ccall f_8116(C_word c,C_word *av) C_noret;
C_noret_decl(f_6485)
static void C_ccall f_6485(C_word c,C_word *av) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word *av) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word *av) C_noret;
C_noret_decl(f_5999)
static void C_fcall f_5999(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6572)
static void C_fcall f_6572(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6315)
static void C_ccall f_6315(C_word c,C_word *av) C_noret;
C_noret_decl(f_7771)
static void C_ccall f_7771(C_word c,C_word *av) C_noret;
C_noret_decl(f_6829)
static void C_ccall f_6829(C_word c,C_word *av) C_noret;
C_noret_decl(f_7774)
static void C_ccall f_7774(C_word c,C_word *av) C_noret;
C_noret_decl(f_7778)
static void C_ccall f_7778(C_word c,C_word *av) C_noret;
C_noret_decl(f_7760)
static void C_ccall f_7760(C_word c,C_word *av) C_noret;
C_noret_decl(f_8050)
static void C_ccall f_8050(C_word c,C_word *av) C_noret;
C_noret_decl(f_6558)
static void C_ccall f_6558(C_word c,C_word *av) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word *av) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word *av) C_noret;
C_noret_decl(f_8007)
static void C_ccall f_8007(C_word c,C_word *av) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word *av) C_noret;
C_noret_decl(f_8003)
static void C_ccall f_8003(C_word c,C_word *av) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word *av) C_noret;
C_noret_decl(f_8382)
static void C_ccall f_8382(C_word c,C_word *av) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word *av) C_noret;
C_noret_decl(f_8387)
static void C_fcall f_8387(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6560)
static void C_ccall f_6560(C_word c,C_word *av) C_noret;
C_noret_decl(f_6566)
static void C_fcall f_6566(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6564)
static void C_ccall f_6564(C_word c,C_word *av) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715(C_word c,C_word *av) C_noret;
C_noret_decl(f_6717)
static void C_fcall f_6717(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3536)
static void C_ccall f_3536(C_word c,C_word *av) C_noret;
C_noret_decl(f_6270)
static void C_ccall f_6270(C_word c,C_word *av) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word *av) C_noret;
C_noret_decl(f_3546)
static void C_ccall f_3546(C_word c,C_word *av) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word *av) C_noret;
C_noret_decl(f_6266)
static void C_ccall f_6266(C_word c,C_word *av) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word *av) C_noret;
C_noret_decl(f_9703)
static void C_fcall f_9703(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word *av) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word *av) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word *av) C_noret;
C_noret_decl(f_7919)
static void C_ccall f_7919(C_word c,C_word *av) C_noret;
C_noret_decl(f_7904)
static void C_ccall f_7904(C_word c,C_word *av) C_noret;
C_noret_decl(f_6765)
static void C_fcall f_6765(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6918)
static void C_ccall f_6918(C_word c,C_word *av) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word *av) C_noret;
C_noret_decl(f_6234)
static void C_ccall f_6234(C_word c,C_word *av) C_noret;
C_noret_decl(f_8228)
static void C_fcall f_8228(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6908)
static void C_ccall f_6908(C_word c,C_word *av) C_noret;
C_noret_decl(f_11215)
static void C_ccall f_11215(C_word c,C_word *av) C_noret;
C_noret_decl(f_5104)
static void C_fcall f_5104(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word *av) C_noret;
C_noret_decl(f_10814)
static void C_fcall f_10814(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8209)
static void C_ccall f_8209(C_word c,C_word *av) C_noret;
C_noret_decl(f_9601)
static void C_fcall f_9601(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11226)
static void C_ccall f_11226(C_word c,C_word *av) C_noret;
C_noret_decl(f_11228)
static void C_ccall f_11228(C_word c,C_word *av) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word *av) C_noret;
C_noret_decl(f_10884)
static void C_ccall f_10884(C_word c,C_word *av) C_noret;
C_noret_decl(f_10887)
static void C_ccall f_10887(C_word c,C_word *av) C_noret;
C_noret_decl(f_10881)
static void C_ccall f_10881(C_word c,C_word *av) C_noret;
C_noret_decl(f_5128)
static void C_fcall f_5128(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10878)
static void C_ccall f_10878(C_word c,C_word *av) C_noret;
C_noret_decl(f_10870)
static void C_ccall f_10870(C_word c,C_word *av) C_noret;
C_noret_decl(f_10866)
static void C_ccall f_10866(C_word c,C_word *av) C_noret;
C_noret_decl(f_10864)
static void C_ccall f_10864(C_word c,C_word *av) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word *av) C_noret;
C_noret_decl(f_9913)
static void C_fcall f_9913(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9909)
static void C_ccall f_9909(C_word c,C_word *av) C_noret;
C_noret_decl(f_9906)
static void C_ccall f_9906(C_word c,C_word *av) C_noret;
C_noret_decl(f_5389)
static void C_ccall f_5389(C_word c,C_word *av) C_noret;
C_noret_decl(f_11232)
static void C_ccall f_11232(C_word c,C_word *av) C_noret;
C_noret_decl(f_7361)
static void C_ccall f_7361(C_word c,C_word *av) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word *av) C_noret;
C_noret_decl(f_7319)
static void C_ccall f_7319(C_word c,C_word *av) C_noret;
C_noret_decl(f_9435)
static void C_fcall f_9435(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10891)
static void C_fcall f_10891(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7301)
static void C_ccall f_7301(C_word c,C_word *av) C_noret;
C_noret_decl(f_4309)
static void C_ccall f_4309(C_word c,C_word *av) C_noret;
C_noret_decl(f_4307)
static void C_ccall f_4307(C_word c,C_word *av) C_noret;
C_noret_decl(f_7331)
static void C_ccall f_7331(C_word c,C_word *av) C_noret;
C_noret_decl(f_7327)
static void C_ccall f_7327(C_word c,C_word *av) C_noret;
C_noret_decl(f_9442)
static void C_fcall f_9442(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word *av) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word *av) C_noret;
C_noret_decl(f_5212)
static void C_ccall f_5212(C_word c,C_word *av) C_noret;
C_noret_decl(f_5210)
static void C_ccall f_5210(C_word c,C_word *av) C_noret;
C_noret_decl(f_5216)
static void C_ccall f_5216(C_word c,C_word *av) C_noret;
C_noret_decl(f_7165)
static void C_ccall f_7165(C_word c,C_word *av) C_noret;
C_noret_decl(f_7162)
static void C_ccall f_7162(C_word c,C_word *av) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word *av) C_noret;
C_noret_decl(f_4609)
static void C_ccall f_4609(C_word c,C_word *av) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word *av) C_noret;
C_noret_decl(f_4369)
static void C_fcall f_4369(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7195)
static void C_ccall f_7195(C_word c,C_word *av) C_noret;

C_noret_decl(trf_4648)
static void C_ccall trf_4648(C_word c,C_word *av) C_noret;
static void C_ccall trf_4648(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4648(t0,t1);}

C_noret_decl(trf_4335)
static void C_ccall trf_4335(C_word c,C_word *av) C_noret;
static void C_ccall trf_4335(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4335(t0,t1,t2);}

C_noret_decl(trf_7280)
static void C_ccall trf_7280(C_word c,C_word *av) C_noret;
static void C_ccall trf_7280(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_7280(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_9096)
static void C_ccall trf_9096(C_word c,C_word *av) C_noret;
static void C_ccall trf_9096(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9096(t0,t1,t2);}

C_noret_decl(trf_9387)
static void C_ccall trf_9387(C_word c,C_word *av) C_noret;
static void C_ccall trf_9387(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9387(t0,t1,t2,t3);}

C_noret_decl(trf_8825)
static void C_ccall trf_8825(C_word c,C_word *av) C_noret;
static void C_ccall trf_8825(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_8825(t0,t1,t2,t3);}

C_noret_decl(trf_4774)
static void C_ccall trf_4774(C_word c,C_word *av) C_noret;
static void C_ccall trf_4774(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4774(t0,t1);}

C_noret_decl(trf_9898)
static void C_ccall trf_9898(C_word c,C_word *av) C_noret;
static void C_ccall trf_9898(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9898(t0,t1);}

C_noret_decl(trf_7539)
static void C_ccall trf_7539(C_word c,C_word *av) C_noret;
static void C_ccall trf_7539(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7539(t0,t1,t2);}

C_noret_decl(trf_10457)
static void C_ccall trf_10457(C_word c,C_word *av) C_noret;
static void C_ccall trf_10457(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10457(t0,t1,t2);}

C_noret_decl(trf_8791)
static void C_ccall trf_8791(C_word c,C_word *av) C_noret;
static void C_ccall trf_8791(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8791(t0,t1,t2);}

C_noret_decl(trf_10645)
static void C_ccall trf_10645(C_word c,C_word *av) C_noret;
static void C_ccall trf_10645(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10645(t0,t1);}

C_noret_decl(trf_10491)
static void C_ccall trf_10491(C_word c,C_word *av) C_noret;
static void C_ccall trf_10491(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10491(t0,t1,t2);}

C_noret_decl(trf_8863)
static void C_ccall trf_8863(C_word c,C_word *av) C_noret;
static void C_ccall trf_8863(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8863(t0,t1,t2);}

C_noret_decl(trf_9826)
static void C_ccall trf_9826(C_word c,C_word *av) C_noret;
static void C_ccall trf_9826(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9826(t0,t1,t2);}

C_noret_decl(trf_8944)
static void C_ccall trf_8944(C_word c,C_word *av) C_noret;
static void C_ccall trf_8944(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8944(t0,t1,t2);}

C_noret_decl(trf_10622)
static void C_ccall trf_10622(C_word c,C_word *av) C_noret;
static void C_ccall trf_10622(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10622(t0,t1);}

C_noret_decl(trf_10423)
static void C_ccall trf_10423(C_word c,C_word *av) C_noret;
static void C_ccall trf_10423(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10423(t0,t1,t2);}

C_noret_decl(trf_7573)
static void C_ccall trf_7573(C_word c,C_word *av) C_noret;
static void C_ccall trf_7573(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7573(t0,t1,t2);}

C_noret_decl(trf_6155)
static void C_ccall trf_6155(C_word c,C_word *av) C_noret;
static void C_ccall trf_6155(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6155(t0,t1,t2);}

C_noret_decl(trf_8332)
static void C_ccall trf_8332(C_word c,C_word *av) C_noret;
static void C_ccall trf_8332(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8332(t0,t1,t2);}

C_noret_decl(trf_4755)
static void C_ccall trf_4755(C_word c,C_word *av) C_noret;
static void C_ccall trf_4755(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4755(t0,t1,t2);}

C_noret_decl(trf_5009)
static void C_ccall trf_5009(C_word c,C_word *av) C_noret;
static void C_ccall trf_5009(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5009(t0,t1,t2,t3);}

C_noret_decl(trf_5059)
static void C_ccall trf_5059(C_word c,C_word *av) C_noret;
static void C_ccall trf_5059(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5059(t0,t1,t2,t3);}

C_noret_decl(trf_10976)
static void C_ccall trf_10976(C_word c,C_word *av) C_noret;
static void C_ccall trf_10976(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10976(t0,t1,t2,t3);}

C_noret_decl(trf_9339)
static void C_ccall trf_9339(C_word c,C_word *av) C_noret;
static void C_ccall trf_9339(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9339(t0,t1,t2,t3);}

C_noret_decl(trf_8599)
static void C_ccall trf_8599(C_word c,C_word *av) C_noret;
static void C_ccall trf_8599(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8599(t0,t1,t2);}

C_noret_decl(trf_9553)
static void C_ccall trf_9553(C_word c,C_word *av) C_noret;
static void C_ccall trf_9553(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9553(t0,t1,t2,t3);}

C_noret_decl(trf_9505)
static void C_ccall trf_9505(C_word c,C_word *av) C_noret;
static void C_ccall trf_9505(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9505(t0,t1,t2,t3);}

C_noret_decl(trf_4487)
static void C_ccall trf_4487(C_word c,C_word *av) C_noret;
static void C_ccall trf_4487(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4487(t0,t1,t2,t3);}

C_noret_decl(trf_10188)
static void C_ccall trf_10188(C_word c,C_word *av) C_noret;
static void C_ccall trf_10188(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10188(t0,t1,t2,t3);}

C_noret_decl(trf_3914)
static void C_ccall trf_3914(C_word c,C_word *av) C_noret;
static void C_ccall trf_3914(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_3914(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8637)
static void C_ccall trf_8637(C_word c,C_word *av) C_noret;
static void C_ccall trf_8637(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_8637(t0,t1);}

C_noret_decl(trf_4821)
static void C_ccall trf_4821(C_word c,C_word *av) C_noret;
static void C_ccall trf_4821(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4821(t0,t1,t2);}

C_noret_decl(trf_7813)
static void C_ccall trf_7813(C_word c,C_word *av) C_noret;
static void C_ccall trf_7813(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7813(t0,t1,t2);}

C_noret_decl(trf_3970)
static void C_ccall trf_3970(C_word c,C_word *av) C_noret;
static void C_ccall trf_3970(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_3970(t0,t1,t2,t3);}

C_noret_decl(trf_8713)
static void C_ccall trf_8713(C_word c,C_word *av) C_noret;
static void C_ccall trf_8713(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8713(t0,t1,t2);}

C_noret_decl(trf_7489)
static void C_ccall trf_7489(C_word c,C_word *av) C_noret;
static void C_ccall trf_7489(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7489(t0,t1,t2);}

C_noret_decl(trf_4437)
static void C_ccall trf_4437(C_word c,C_word *av) C_noret;
static void C_ccall trf_4437(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4437(t0,t1,t2,t3);}

C_noret_decl(trf_7459)
static void C_ccall trf_7459(C_word c,C_word *av) C_noret;
static void C_ccall trf_7459(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7459(t0,t1,t2);}

C_noret_decl(trf_10341)
static void C_ccall trf_10341(C_word c,C_word *av) C_noret;
static void C_ccall trf_10341(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10341(t0,t1,t2,t3);}

C_noret_decl(trf_7877)
static void C_ccall trf_7877(C_word c,C_word *av) C_noret;
static void C_ccall trf_7877(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7877(t0,t1,t2);}

C_noret_decl(trf_7443)
static void C_ccall trf_7443(C_word c,C_word *av) C_noret;
static void C_ccall trf_7443(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7443(t0,t1,t2);}

C_noret_decl(trf_6114)
static void C_ccall trf_6114(C_word c,C_word *av) C_noret;
static void C_ccall trf_6114(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6114(t0,t1);}

C_noret_decl(trf_10140)
static void C_ccall trf_10140(C_word c,C_word *av) C_noret;
static void C_ccall trf_10140(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10140(t0,t1,t2,t3);}

C_noret_decl(trf_6111)
static void C_ccall trf_6111(C_word c,C_word *av) C_noret;
static void C_ccall trf_6111(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6111(t0,t1);}

C_noret_decl(trf_6108)
static void C_ccall trf_6108(C_word c,C_word *av) C_noret;
static void C_ccall trf_6108(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6108(t0,t1);}

C_noret_decl(trf_7641)
static void C_ccall trf_7641(C_word c,C_word *av) C_noret;
static void C_ccall trf_7641(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7641(t0,t1,t2);}

C_noret_decl(trf_10389)
static void C_ccall trf_10389(C_word c,C_word *av) C_noret;
static void C_ccall trf_10389(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10389(t0,t1,t2);}

C_noret_decl(trf_6033)
static void C_ccall trf_6033(C_word c,C_word *av) C_noret;
static void C_ccall trf_6033(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6033(t0,t1,t2);}

C_noret_decl(trf_7607)
static void C_ccall trf_7607(C_word c,C_word *av) C_noret;
static void C_ccall trf_7607(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7607(t0,t1,t2);}

C_noret_decl(trf_3788)
static void C_ccall trf_3788(C_word c,C_word *av) C_noret;
static void C_ccall trf_3788(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3788(t0,t1,t2);}

C_noret_decl(trf_10321)
static void C_ccall trf_10321(C_word c,C_word *av) C_noret;
static void C_ccall trf_10321(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10321(t0,t1,t2);}

C_noret_decl(trf_6920)
static void C_ccall trf_6920(C_word c,C_word *av) C_noret;
static void C_ccall trf_6920(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6920(t0,t1,t2);}

C_noret_decl(trf_8747)
static void C_ccall trf_8747(C_word c,C_word *av) C_noret;
static void C_ccall trf_8747(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_8747(t0,t1,t2,t3);}

C_noret_decl(trf_5542)
static void C_ccall trf_5542(C_word c,C_word *av) C_noret;
static void C_ccall trf_5542(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_5542(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6673)
static void C_ccall trf_6673(C_word c,C_word *av) C_noret;
static void C_ccall trf_6673(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6673(t0,t1);}

C_noret_decl(trf_5786)
static void C_ccall trf_5786(C_word c,C_word *av) C_noret;
static void C_ccall trf_5786(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5786(t0,t1);}

C_noret_decl(trf_8180)
static void C_ccall trf_8180(C_word c,C_word *av) C_noret;
static void C_ccall trf_8180(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_8180(t0,t1,t2,t3);}

C_noret_decl(trf_4165)
static void C_ccall trf_4165(C_word c,C_word *av) C_noret;
static void C_ccall trf_4165(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4165(t0,t1);}

C_noret_decl(trf_5807)
static void C_ccall trf_5807(C_word c,C_word *av) C_noret;
static void C_ccall trf_5807(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5807(t0,t1);}

C_noret_decl(trf_6290)
static void C_ccall trf_6290(C_word c,C_word *av) C_noret;
static void C_ccall trf_6290(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6290(t0,t1,t2);}

C_noret_decl(trf_4111)
static void C_ccall trf_4111(C_word c,C_word *av) C_noret;
static void C_ccall trf_4111(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_4111(t0,t1,t2,t3);}

C_noret_decl(trf_11190)
static void C_ccall trf_11190(C_word c,C_word *av) C_noret;
static void C_ccall trf_11190(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_11190(t0,t1,t2);}

C_noret_decl(trf_8298)
static void C_ccall trf_8298(C_word c,C_word *av) C_noret;
static void C_ccall trf_8298(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8298(t0,t1,t2);}

C_noret_decl(trf_8262)
static void C_ccall trf_8262(C_word c,C_word *av) C_noret;
static void C_ccall trf_8262(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_8262(t0,t1,t2,t3);}

C_noret_decl(trf_7040)
static void C_ccall trf_7040(C_word c,C_word *av) C_noret;
static void C_ccall trf_7040(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7040(t0,t1,t2,t3);}

C_noret_decl(trf_5767)
static void C_ccall trf_5767(C_word c,C_word *av) C_noret;
static void C_ccall trf_5767(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5767(t0,t1,t2,t3);}

C_noret_decl(trf_9212)
static void C_ccall trf_9212(C_word c,C_word *av) C_noret;
static void C_ccall trf_9212(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9212(t0,t1,t2,t3);}

C_noret_decl(trf_5343)
static void C_ccall trf_5343(C_word c,C_word *av) C_noret;
static void C_ccall trf_5343(C_word c,C_word *av){
C_word t0=av[6];
C_word t1=av[5];
C_word t2=av[4];
C_word t3=av[3];
C_word t4=av[2];
C_word t5=av[1];
C_word t6=av[0];
f_5343(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5792)
static void C_ccall trf_5792(C_word c,C_word *av) C_noret;
static void C_ccall trf_5792(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5792(t0,t1);}

C_noret_decl(trf_5799)
static void C_ccall trf_5799(C_word c,C_word *av) C_noret;
static void C_ccall trf_5799(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5799(t0,t1);}

C_noret_decl(trf_4506)
static void C_ccall trf_4506(C_word c,C_word *av) C_noret;
static void C_ccall trf_4506(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4506(t0,t1);}

C_noret_decl(trf_4067)
static void C_ccall trf_4067(C_word c,C_word *av) C_noret;
static void C_ccall trf_4067(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4067(t0,t1,t2);}

C_noret_decl(trf_7341)
static void C_ccall trf_7341(C_word c,C_word *av) C_noret;
static void C_ccall trf_7341(C_word c,C_word *av){
C_word t0=av[5];
C_word t1=av[4];
C_word t2=av[3];
C_word t3=av[2];
C_word t4=av[1];
C_word t5=av[0];
f_7341(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7347)
static void C_ccall trf_7347(C_word c,C_word *av) C_noret;
static void C_ccall trf_7347(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_7347(t0,t1,t2,t3,t4);}

C_noret_decl(trf_11028)
static void C_ccall trf_11028(C_word c,C_word *av) C_noret;
static void C_ccall trf_11028(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_11028(t0,t1);}

C_noret_decl(trf_9129)
static void C_ccall trf_9129(C_word c,C_word *av) C_noret;
static void C_ccall trf_9129(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9129(t0,t1);}

C_noret_decl(trf_9114)
static void C_ccall trf_9114(C_word c,C_word *av) C_noret;
static void C_ccall trf_9114(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9114(t0,t1);}

C_noret_decl(trf_3828)
static void C_ccall trf_3828(C_word c,C_word *av) C_noret;
static void C_ccall trf_3828(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3828(t0,t1,t2);}

C_noret_decl(trf_10568)
static void C_ccall trf_10568(C_word c,C_word *av) C_noret;
static void C_ccall trf_10568(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10568(t0,t1);}

C_noret_decl(trf_7962)
static void C_ccall trf_7962(C_word c,C_word *av) C_noret;
static void C_ccall trf_7962(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7962(t0,t1,t2,t3);}

C_noret_decl(trf_7987)
static void C_ccall trf_7987(C_word c,C_word *av) C_noret;
static void C_ccall trf_7987(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7987(t0,t1);}

C_noret_decl(trf_10041)
static void C_ccall trf_10041(C_word c,C_word *av) C_noret;
static void C_ccall trf_10041(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10041(t0,t1,t2,t3);}

C_noret_decl(trf_10271)
static void C_ccall trf_10271(C_word c,C_word *av) C_noret;
static void C_ccall trf_10271(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_10271(t0,t1,t2,t3);}

C_noret_decl(trf_9737)
static void C_ccall trf_9737(C_word c,C_word *av) C_noret;
static void C_ccall trf_9737(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9737(t0,t1,t2);}

C_noret_decl(trf_8583)
static void C_ccall trf_8583(C_word c,C_word *av) C_noret;
static void C_ccall trf_8583(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8583(t0,t1,t2);}

C_noret_decl(trf_7975)
static void C_ccall trf_7975(C_word c,C_word *av) C_noret;
static void C_ccall trf_7975(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7975(t0,t1);}

C_noret_decl(trf_7726)
static void C_ccall trf_7726(C_word c,C_word *av) C_noret;
static void C_ccall trf_7726(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_7726(t0,t1,t2,t3);}

C_noret_decl(trf_8517)
static void C_ccall trf_8517(C_word c,C_word *av) C_noret;
static void C_ccall trf_8517(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8517(t0,t1,t2);}

C_noret_decl(trf_9669)
static void C_ccall trf_9669(C_word c,C_word *av) C_noret;
static void C_ccall trf_9669(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9669(t0,t1,t2);}

C_noret_decl(trf_8564)
static void C_ccall trf_8564(C_word c,C_word *av) C_noret;
static void C_ccall trf_8564(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_8564(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9993)
static void C_ccall trf_9993(C_word c,C_word *av) C_noret;
static void C_ccall trf_9993(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_9993(t0,t1,t2,t3);}

C_noret_decl(trf_9635)
static void C_ccall trf_9635(C_word c,C_word *av) C_noret;
static void C_ccall trf_9635(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9635(t0,t1,t2);}

C_noret_decl(trf_5999)
static void C_ccall trf_5999(C_word c,C_word *av) C_noret;
static void C_ccall trf_5999(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5999(t0,t1,t2);}

C_noret_decl(trf_6572)
static void C_ccall trf_6572(C_word c,C_word *av) C_noret;
static void C_ccall trf_6572(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6572(t0,t1,t2);}

C_noret_decl(trf_8387)
static void C_ccall trf_8387(C_word c,C_word *av) C_noret;
static void C_ccall trf_8387(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8387(t0,t1,t2);}

C_noret_decl(trf_6566)
static void C_ccall trf_6566(C_word c,C_word *av) C_noret;
static void C_ccall trf_6566(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6566(t0,t1,t2);}

C_noret_decl(trf_6717)
static void C_ccall trf_6717(C_word c,C_word *av) C_noret;
static void C_ccall trf_6717(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6717(t0,t1,t2,t3);}

C_noret_decl(trf_9703)
static void C_ccall trf_9703(C_word c,C_word *av) C_noret;
static void C_ccall trf_9703(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9703(t0,t1,t2);}

C_noret_decl(trf_6765)
static void C_ccall trf_6765(C_word c,C_word *av) C_noret;
static void C_ccall trf_6765(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6765(t0,t1,t2,t3);}

C_noret_decl(trf_8228)
static void C_ccall trf_8228(C_word c,C_word *av) C_noret;
static void C_ccall trf_8228(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_8228(t0,t1,t2);}

C_noret_decl(trf_5104)
static void C_ccall trf_5104(C_word c,C_word *av) C_noret;
static void C_ccall trf_5104(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5104(t0,t1);}

C_noret_decl(trf_10814)
static void C_ccall trf_10814(C_word c,C_word *av) C_noret;
static void C_ccall trf_10814(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_10814(t0,t1);}

C_noret_decl(trf_9601)
static void C_ccall trf_9601(C_word c,C_word *av) C_noret;
static void C_ccall trf_9601(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_9601(t0,t1,t2);}

C_noret_decl(trf_5128)
static void C_ccall trf_5128(C_word c,C_word *av) C_noret;
static void C_ccall trf_5128(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5128(t0,t1);}

C_noret_decl(trf_9913)
static void C_ccall trf_9913(C_word c,C_word *av) C_noret;
static void C_ccall trf_9913(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9913(t0,t1);}

C_noret_decl(trf_9435)
static void C_ccall trf_9435(C_word c,C_word *av) C_noret;
static void C_ccall trf_9435(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_9435(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10891)
static void C_ccall trf_10891(C_word c,C_word *av) C_noret;
static void C_ccall trf_10891(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_10891(t0,t1,t2);}

C_noret_decl(trf_9442)
static void C_ccall trf_9442(C_word c,C_word *av) C_noret;
static void C_ccall trf_9442(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_9442(t0,t1);}

C_noret_decl(trf_4369)
static void C_ccall trf_4369(C_word c,C_word *av) C_noret;
static void C_ccall trf_4369(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4369(t0,t1,t2);}

/* k4615 in a4608 in k4599 in k4590 in a4587 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_ccall f_4617(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4617,2,av);}
/* chicken-syntax.scm:1188: ##compiler#validate-type */
t2=*((C_word*)lf[63]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a4618 in k4599 in k4590 in a4587 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_4619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(30,c,5))){C_save_and_reclaim((void *)f_4619,5,av);}
a=C_alloc(30);
t5=t3;
if(C_truep(t2)){
t6=C_i_cdddr(((C_word*)t0)[2]);
t7=C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=C_a_i_list(&a,2,lf[64],t8);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4644,a[2]=t10,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4648,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t13=C_a_i_list(&a,2,lf[66],((C_word*)t0)[4]);
t14=t12;
f_4648(t14,C_a_i_list(&a,1,t13));}
else{
t13=t12;
f_4648(t13,C_SCHEME_END_OF_LIST);}}
else{
/* chicken-syntax.scm:1190: syntax-error */
t6=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=lf[62];
av2[3]=lf[67];
av2[4]=((C_word*)t0)[4];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(6,av2);}}}

/* k5238 in k5231 in a5228 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in ... */
static void C_ccall f_5240(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5240,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1075: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[47];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4642 in a4618 in k4599 in k4590 in a4587 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_ccall f_4644(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_4644,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[37],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5254 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in ... */
static void C_ccall f_5256(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5256,2,av);}
/* chicken-syntax.scm:1053: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[100];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7272 in k7268 in k7498 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in ... */
static void C_ccall f_7274(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_7274,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:625: reverse */
t4=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7268 in k7498 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_7270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_7270,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7274,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:624: reverse */
t4=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5246 in k5238 in k5231 in a5228 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in ... */
static void C_ccall f_5248(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_5248,2,av);}
a=C_alloc(9);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,((C_word*)t0)[4],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k7276 in k7272 in k7268 in k7498 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in ... */
static void C_ccall f_7278(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,6))){C_save_and_reclaim((void *)f_7278,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7280,a[2]=t3,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7280(t5,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5]);}

/* a5257 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in ... */
static void C_ccall f_5258(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_5258,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5262,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1057: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[100];
av2[3]=t2;
av2[4]=lf[103];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4323 in a4308 in k4297 in k4287 in k4266 in k4249 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in ... */
static void C_ccall f_4325(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,1))){C_save_and_reclaim((void *)f_4325,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k4646 in a4618 in k4599 in k4590 in a4587 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_fcall f_4648(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,3))){
C_save_and_reclaim_args((void *)trf_4648,2,t0,t1);}
a=C_alloc(15);
if(C_truep(((C_word*)t0)[2])){
t2=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,lf[65],t2);
t4=C_a_i_list(&a,1,t3);
/* chicken-syntax.scm:43: ##sys#append */
t5=*((C_word*)lf[41]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=((C_word*)t0)[4];
av2[2]=t1;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
/* chicken-syntax.scm:43: ##sys#append */
t2=*((C_word*)lf[41]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
av2[2]=t1;
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* map-loop2356 in k4266 in k4249 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in ... */
static void C_fcall f_4335(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_4335,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_i_car(t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t6);
t9=C_slot(t2,C_fix(1));
t11=t1;
t12=t9;
t1=t11;
t2=t12;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* recur in k7276 in k7272 in k7268 in k7498 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_fcall f_7280(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_7280,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t2))){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=C_i_cdr(t2);
t7=t6;
t8=C_i_car(t3);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7319,a[2]=t5,a[3]=t9,a[4]=t1,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[2],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:630: reverse */
t11=*((C_word*)lf[43]+1);{
C_word av2[3];
av2[0]=t11;
av2[1]=t10;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}}

/* k4692 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_4694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4694,2,av);}
/* chicken-syntax.scm:1141: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[70];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a4695 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_4696(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_4696,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4700,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1145: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[70];
av2[3]=t2;
av2[4]=lf[80];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* g600 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_9096(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_9096,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9104,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_symbolp(t2))){
/* chicken-syntax.scm:277: gensym */
t4=*((C_word*)lf[32]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
/* chicken-syntax.scm:278: gensym */
t4=*((C_word*)lf[32]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[236];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9092(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(28,c,3))){C_save_and_reclaim((void *)f_9092,2,av);}
a=C_alloc(28);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9096,a[2]=((C_word*)t0)[2],a[3]=((C_word)li109),tmp=(C_word)a,a+=4,tmp);
t8=C_i_check_list_2(((C_word*)t0)[3],lf[28]);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9110,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9669,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,a[6]=((C_word)li121),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_9669(t13,t9,((C_word*)t0)[3]);}

/* k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9086(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,3))){C_save_and_reclaim((void *)f_9086,2,av);}
a=C_alloc(22);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9092,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9703,a[2]=t5,a[3]=t9,a[4]=t6,a[5]=((C_word)li122),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_9703(t11,t7,((C_word*)t0)[8]);}

/* k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_ccall f_3613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3613,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7148,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:726: ##sys#primitive-alias */
t4=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[173];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_ccall f_3616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3616,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6992,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:759: ##sys#primitive-alias */
t4=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[153];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in ... */
static void C_ccall f_3619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3619,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6485,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6487,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:828: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in ... */
static void C_ccall f_3610(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3610,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7237,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:698: ##sys#primitive-alias */
t4=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[173];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* map-loop784 in k9291 in k9168 in k9151 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_fcall f_9387(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(15,0,3))){
C_save_and_reclaim_args((void *)trf_9387,4,t0,t1,t2,t3);}
a=C_alloc(15);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,1,t6);
t9=C_a_i_list(&a,3,lf[239],t7,t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10);
t12=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t10);
t13=C_slot(t2,C_fix(1));
t14=C_slot(t3,C_fix(1));
t16=t1;
t17=t13;
t18=t14;
t1=t16;
t2=t17;
t3=t18;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,3))){C_save_and_reclaim((void *)f_9077,2,av);}
a=C_alloc(22);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9737,a[2]=t5,a[3]=t10,a[4]=t6,a[5]=((C_word)li123),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_9737(t12,t8,((C_word*)t0)[2]);}

/* k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9074(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_9074,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:284: r */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[240];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9071(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_9071,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:283: r */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[241];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5225 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_ccall f_5227(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5227,2,av);}
/* chicken-syntax.scm:1069: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[98];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4698 in a4695 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_4700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4700,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4703,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1146: ##sys#strip-syntax */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4701 in k4698 in a4695 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_ccall f_4703(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
if(!C_demand(C_calculate_demand(31,c,3))){C_save_and_reclaim((void *)f_4703,2,av);}
a=C_alloc(31);
t2=C_i_cadr(t1);
t3=C_i_car(t2);
t4=t3;
t5=C_u_i_cdr(t2);
t6=C_i_caddr(t1);
t7=t6;
t8=C_u_i_cdr(t1);
t9=C_u_i_cdr(t8);
t10=C_u_i_cdr(t9);
t11=C_a_i_list(&a,2,lf[20],t4);
t12=t11;
t13=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t14=t13;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=((C_word*)t15)[1];
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4755,a[2]=t4,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
t18=C_i_check_list_2(t5,lf[28]);
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4819,a[2]=t10,a[3]=t12,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4821,a[2]=t15,a[3]=t21,a[4]=t17,a[5]=t16,a[6]=((C_word)li20),tmp=(C_word)a,a+=7,tmp));
t23=((C_word*)t21)[1];
f_4821(t23,t19,t5);}

/* k5231 in a5228 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_5233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5233,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1074: r */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[78];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9063(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_9063,2,av);}
a=C_alloc(6);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9071,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:282: r */
t8=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[52];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* a5228 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_ccall f_5229(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_5229,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5233,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1073: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[98];
av2[3]=t2;
av2[4]=lf[99];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10679 in k10672 in k10617 in k10606 in a10603 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10681(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_10681,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_10622(t3,t2);}

/* k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_ccall f_3655(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3655,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4857,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4859,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1116: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10672 in k10617 in k10606 in a10603 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10674(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,5))){C_save_and_reclaim((void *)f_10674,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:178: string-append */
t3=*((C_word*)lf[182]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[264];
av2[3]=t1;
av2[4]=lf[265];
av2[5]=((C_word*)((C_word*)t0)[2])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}
else{
t2=((C_word*)t0)[3];
f_10622(t2,C_SCHEME_FALSE);}}

/* k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_3658(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3658,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4694,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4696,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1143: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in ... */
static void C_ccall f_3652(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3652,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4944,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4946,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1107: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* loop in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_8825(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_8825,4,t0,t1,t2,t3);}
a=C_alloc(8);
if(C_truep(C_i_nullp(t2))){
t4=t3;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8838,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t4))){
/* chicken-syntax.scm:377: append */
t6=*((C_word*)lf[166]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
if(C_truep(C_i_pairp(t4))){
/* chicken-syntax.scm:378: append* */
t6=((C_word*)((C_word*)t0)[3])[1];{
C_word av2[4];
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t6=C_a_i_cons(&a,2,t4,t3);
t7=t2;
t8=C_u_i_cdr(t7);
/* chicken-syntax.scm:380: loop */
t10=t1;
t11=t8;
t12=t6;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}}}

/* k10662 in k10620 in k10617 in k10606 in a10603 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10664(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_10664,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,2,lf[116],t1);
t3=C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[2];
f_10645(t4,C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t3));}

/* k8836 in loop in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_ccall f_8838(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8838,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* chicken-syntax.scm:380: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8825(t4,((C_word*)t0)[4],t3,t1);}

/* k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_ccall f_3604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3604,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7693,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7695,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:497: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in ... */
static void C_ccall f_3607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3607,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7689,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:610: ##sys#primitive-alias */
t4=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[154];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_ccall f_3601(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3601,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7861,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7863,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:477: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8814 in map-loop1000 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_ccall f_8816(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8816,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8791(t6,((C_word*)t0)[5],t5);}

/* k3693 in a3690 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in ... */
static void C_ccall f_3695(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3695,2,av);}
a=C_alloc(5);
if(C_truep(C_i_memq(lf[13],*((C_word*)lf[14]+1)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* chicken-syntax.scm:1310: ##sys#strip-syntax */
t4=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[21];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k4760 in g2200 in k4701 in k4698 in a4695 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_4762(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_4762,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_i_symbolp(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_4774(t6,t4);}
else{
if(C_truep(C_i_listp(((C_word*)t0)[3]))){
t6=C_u_i_length(((C_word*)t0)[3]);
t7=C_eqp(C_fix(2),t6);
if(C_truep(t7)){
t8=C_i_car(((C_word*)t0)[3]);
if(C_truep(C_i_symbolp(t8))){
t9=C_i_cadr(((C_word*)t0)[3]);
t10=t5;
f_4774(t10,C_i_symbolp(t9));}
else{
t9=t5;
f_4774(t9,C_SCHEME_FALSE);}}
else{
t8=t5;
f_4774(t8,C_SCHEME_FALSE);}}
else{
t6=t5;
f_4774(t6,C_SCHEME_FALSE);}}}

/* k4763 in k4760 in g2200 in k4701 in k4698 in a4695 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_ccall f_4765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_4765,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a3690 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in ... */
static void C_ccall f_3691(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_3691,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3695,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1307: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[12];
av2[3]=t2;
av2[4]=lf[23];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10446 in map-loop227 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10448(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_10448,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10423(t6,((C_word*)t0)[5],t5);}

/* k4772 in k4760 in g2200 in k4701 in k4698 in a4695 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_fcall f_4774(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,0,4))){
C_save_and_reclaim_args((void *)trf_4774,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
/* chicken-syntax.scm:1163: ##sys#syntax-error-hook */
t2=*((C_word*)lf[71]+1);{
C_word av2[5];
av2[0]=t2;
av2[1]=((C_word*)t0)[5];
av2[2]=lf[72];
av2[3]=((C_word*)t0)[6];
av2[4]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}}

/* k10695 in a10692 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10697(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_10697,2,av);}
a=C_alloc(6);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,lf[268],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k10689 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10691(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10691,2,av);}
/* chicken-syntax.scm:159: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[267];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a10692 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_10693,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10697,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:163: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[267];
av2[3]=t2;
av2[4]=lf[269];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* g205 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_9898(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_9898,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9906,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:217: gensym */
t3=*((C_word*)lf[32]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9894(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,3))){C_save_and_reclaim((void *)f_9894,2,av);}
a=C_alloc(25);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9898,a[2]=((C_word*)t0)[2],a[3]=((C_word)li127),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10457,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=t6,a[6]=((C_word)li138),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_10457(t12,t8,((C_word*)t0)[5]);}

/* k10606 in a10603 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10608(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_10608,2,av);}
a=C_alloc(9);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_i_nullp(t6);
t8=(C_truep(t7)?lf[263]:C_i_car(t6));
t9=t8;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10619,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t10,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:175: r */
t12=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t12;
av2[1]=t11;
av2[2]=lf[176];
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}

/* a10603 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10604,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10608,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:171: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[262];
av2[3]=t2;
av2[4]=lf[266];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10600 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10602(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10602,2,av);}
/* chicken-syntax.scm:166: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[262];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop1535 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_fcall f_7539(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_7539,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7564,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:671: g1541 */
t5=((C_word*)t0)[4];
f_7489(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9880(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,3))){C_save_and_reclaim((void *)f_9880,2,av);}
a=C_alloc(19);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=C_i_check_list_2(t3,lf[28]);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9894,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10491,a[2]=t9,a[3]=t14,a[4]=t10,a[5]=((C_word)li139),tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_10491(t16,t12,t3);}

/* map-loop199 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_10457(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_10457,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10482,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:217: g205 */
t4=((C_word*)t0)[4];
f_9898(t4,t3);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9872 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9874,2,av);}
/* chicken-syntax.scm:209: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[254];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9876(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_9876,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9880,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:213: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[254];
av2[3]=t2;
av2[4]=lf[255];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_ccall f_3667(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3667,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4239,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4241,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1210: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_3664(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3664,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4548,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4550,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1199: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10480 in map-loop199 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10482(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_10482,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_10457(t6,((C_word*)t0)[5],t5);}

/* k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_3661(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3661,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4586,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4588,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1179: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k9859 in k9852 in k9845 in loop in k9792 in k9789 in k9786 in k9777 in a9774 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9861(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_9861,2,av);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=C_slot(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm:261: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9826(t4,((C_word*)t0)[5],t3);}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
/* chicken-syntax.scm:260: ##sys#error */
t4=*((C_word*)lf[248]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[6];
av2[2]=lf[249];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_ccall f_3676(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3676,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3689,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3691,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1305: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in ... */
static void C_ccall f_3679(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3679,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3682,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1322: ##sys#macro-subset */
t3=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=*((C_word*)lf[10]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k8994 in a8991 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8996(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,1))){C_save_and_reclaim((void *)f_8996,2,av);}
a=C_alloc(18);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,lf[231]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,lf[26],t6);
t8=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_a_i_list(&a,4,lf[159],t2,t3,t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* k9852 in k9845 in loop in k9792 in k9789 in k9786 in k9777 in a9774 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9854(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_9854,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=C_slot(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm:261: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9826(t4,((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9861,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:259: c */
t3=((C_word*)t0)[8];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[9];
av2[3]=((C_word*)t0)[10];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* a8991 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_8992,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8996,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:328: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[230];
av2[3]=t2;
av2[4]=lf[232];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k8988 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8990(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8990,2,av);}
/* chicken-syntax.scm:324: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[230];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_3673(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3673,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3749,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3751,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1280: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* map-loop1000 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_fcall f_8791(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8791,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8816,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:381: g1006 */
t5=((C_word*)t0)[4];
f_8517(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_ccall f_3670(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3670,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3872,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3874,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1216: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7501 in k7498 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_7503(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_7503,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:676: make-if-tree */
t4=((C_word*)t0)[9];
f_7341(t4,t3,((C_word*)t0)[10],((C_word*)t0)[11],((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k7504 in k7501 in k7498 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in ... */
static void C_ccall f_7506(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_7506,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:679: r */
t4=((C_word*)t0)[9];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[186];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7498 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_ccall f_7500(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,2))){C_save_and_reclaim((void *)f_7500,2,av);}
a=C_alloc(18);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=t3;
t5=((C_word*)t0)[6];
t6=t2;
t7=((C_word*)t0)[11];
t8=*((C_word*)lf[32]+1);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7270,a[2]=t4,a[3]=t5,a[4]=t7,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:623: reverse */
t10=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=((C_word*)t0)[10];
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k3683 in k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in ... */
static void C_ccall f_3685(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3685,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3687 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in ... */
static void C_ccall f_3689(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3689,2,av);}
/* chicken-syntax.scm:1303: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[12];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k10643 in k10620 in k10617 in k10606 in a10603 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_10645(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(24,0,1))){
C_save_and_reclaim_args((void *)trf_10645,2,t0,t1);}
a=C_alloc(24);
t2=C_a_i_cons(&a,2,lf[248],t1);
t3=C_a_i_list(&a,4,lf[159],((C_word*)t0)[2],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k9845 in loop in k9792 in k9789 in k9786 in k9777 in a9774 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9847(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_9847,2,av);}
a=C_alloc(11);
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=C_slot(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm:261: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9826(t4,((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9854,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:258: c */
t3=((C_word*)t0)[9];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[10];
av2[3]=((C_word*)t0)[12];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k8967 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8969(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8969,2,av);}
/* chicken-syntax.scm:333: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[223];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3680 in k3677 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in ... */
static void C_ccall f_3682(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,7))){C_save_and_reclaim((void *)f_3682,2,av);}
a=C_alloc(3);
t2=C_mutate2((C_word*)lf[1]+1 /* (set! ##sys#chicken-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1328: register-feature! */
t4=*((C_word*)lf[2]+1);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[3];
av2[3]=lf[4];
av2[4]=lf[5];
av2[5]=lf[6];
av2[6]=lf[7];
av2[7]=lf[8];
((C_proc)(void*)(*((C_word*)t4+1)))(8,av2);}}

/* map-loop172 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_10491(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_10491,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9835 in loop in k9792 in k9789 in k9786 in k9777 in a9774 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9837(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9837,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
/* chicken-syntax.scm:261: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9826(t3,((C_word*)t0)[4],t2);}

/* k8973 in a8970 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8975(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8975,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_caddr(((C_word*)t0)[2]);
/* chicken-syntax.scm:338: ##sys#expand-multiple-values-assignment */
t4=*((C_word*)lf[215]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* a8970 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8971(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_8971,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8975,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:337: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[223];
av2[3]=t2;
av2[4]=lf[229];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* map-loop962 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_8863(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_8863,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* loop in k9792 in k9789 in k9786 in k9777 in a9774 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_9826(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(18,0,3))){
C_save_and_reclaim_args((void *)trf_9826,3,t0,t1,t2);}
a=C_alloc(18);
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9837,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9847,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=t4,a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm:257: c */
t7=((C_word*)t0)[6];{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
av2[3]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* for-each-loop918 in a8922 in k8903 in a8900 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_8944(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,4))){
C_save_and_reclaim_args((void *)trf_8944,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8954,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8929,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:350: ##sys#get */
t7=*((C_word*)lf[42]+1);{
C_word av2[5];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
av2[3]=lf[227];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k10620 in k10617 in k10606 in a10603 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_10622(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(25,0,2))){
C_save_and_reclaim_args((void *)trf_10622,2,t0,t1);}
a=C_alloc(25);
t2=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=C_a_i_list(&a,2,lf[121],((C_word*)t0)[2]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10645,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t8=C_u_i_cdr(((C_word*)t0)[5]);
t9=t7;
f_10645(t9,C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[6])[1],t8));}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10664,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:186: ##sys#strip-syntax */
t9=*((C_word*)lf[19]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t8;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}

/* k10617 in k10606 in a10603 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_10619,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10622,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_stringp(((C_word*)((C_word*)t0)[5])[1]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10674,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:177: get-line-number */
t5=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=t3;
f_10622(t4,C_SCHEME_UNDEFINED);}}

/* k8952 in for-each-loop918 in a8922 in k8903 in a8900 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8954(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_8954,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8944(t3,((C_word*)t0)[4],t2);}

/* map-loop227 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_10423(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_10423,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10448,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:218: g233 */
t4=((C_word*)t0)[4];
f_9913(t4,t3);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8366 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8368(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8368,2,av);}
/* chicken-syntax.scm:409: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[218];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6403 in k6387 in k6376 in k6373 in k6370 in a6367 in k6475 in k6479 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_6405(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
if(!C_demand(C_calculate_demand(111,c,1))){C_save_and_reclaim((void *)f_6405,2,av);}
a=C_alloc(111);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_i_caddr(((C_word*)t0)[2]);
t5=C_a_i_list(&a,3,lf[101],C_SCHEME_END_OF_LIST,t4);
t6=C_a_i_list(&a,2,((C_word*)t0)[3],t5);
t7=C_a_i_list(&a,3,lf[101],t3,t6);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
t10=C_u_i_cdr(t9);
t11=C_u_i_cdr(t10);
t12=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t11);
t13=C_a_i_cons(&a,2,lf[101],t12);
t14=C_a_i_list(&a,3,lf[142],lf[143],((C_word*)t0)[4]);
t15=C_a_i_list(&a,3,lf[101],C_SCHEME_END_OF_LIST,t14);
t16=C_a_i_list(&a,2,((C_word*)t0)[3],t15);
t17=C_a_i_list(&a,3,lf[101],((C_word*)t0)[4],t16);
t18=C_a_i_list(&a,3,lf[144],t13,t17);
t19=C_a_i_list(&a,3,lf[101],C_SCHEME_END_OF_LIST,t18);
t20=C_a_i_list(&a,3,t1,t7,t19);
t21=C_a_i_list(&a,3,lf[101],((C_word*)t0)[5],t20);
t22=C_a_i_list(&a,2,((C_word*)t0)[6],t21);
t23=((C_word*)t0)[7];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t23;
av2[1]=C_a_i_list(&a,1,t22);
((C_proc)(void*)(*((C_word*)t23+1)))(2,av2);}}

/* a8922 in k8903 in a8900 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8923(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_8923,5,av);}
a=C_alloc(6);
t5=C_i_check_list_2(t2,lf[224]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8944,a[2]=t7,a[3]=((C_word)li103),tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_8944(t9,t1,t2);}

/* k8927 in for-each-loop918 in a8922 in k8903 in a8900 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8929(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_8929,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8936,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:351: ##sys#current-module */
t4=*((C_word*)lf[226]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a8369 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8370(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_8370,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8374,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:413: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[218];
av2[3]=t2;
av2[4]=lf[220];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k8372 in a8369 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8374(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_8374,2,av);}
a=C_alloc(5);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8382,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:416: r */
t8=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[219];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k8934 in k8927 in for-each-loop918 in a8922 in k8903 in a8900 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_ccall f_8936(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8936,2,av);}
/* chicken-syntax.scm:351: ##sys#register-export */
t2=*((C_word*)lf[225]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k7562 in map-loop1535 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_7564(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_7564,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7539(t6,((C_word*)t0)[5],t5);}

/* k5618 in k5615 in loop in k5533 in k5530 in k5527 in k5524 in a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_5620(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_5620,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken-syntax.scm:1003: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5542(t6,((C_word*)t0)[6],t3,t4,t5,C_SCHEME_FALSE);}

/* k5615 in loop in k5533 in k5530 in k5527 in k5524 in a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_ccall f_5617(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_5617,2,av);}
a=C_alloc(11);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5637,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1002: gensym */
t4=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
/* chicken-syntax.scm:1004: c */
t5=((C_word*)t0)[9];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[10];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* map-loop1506 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_fcall f_7573(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_7573,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* map-loop1808 in k6112 in k6109 in k6106 in parse-clause in k6100 in k6097 in k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_fcall f_6155(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(18,0,2))){
C_save_and_reclaim_args((void *)trf_6155,3,t0,t1,t2);}
a=C_alloc(18);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_6139(C_a_i(&a,15),((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* map-loop1139 in k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_fcall f_8332(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_8332,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6151 in k6112 in k6109 in k6106 in parse-clause in k6100 in k6097 in k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_ccall f_6153(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_6153,2,av);}
a=C_alloc(12);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,t3,((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in ... */
static void C_ccall f_3628(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3628,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6073,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:909: ##sys#primitive-alias */
t4=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[114];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in ... */
static void C_ccall f_3625(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3625,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6358,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:871: ##sys#primitive-alias */
t4=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[27];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in ... */
static void C_ccall f_3622(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3622,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6481,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:849: ##sys#primitive-alias */
t4=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[140];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7511 in k7504 in k7501 in k7498 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in ... */
static void C_ccall f_7513(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,1))){C_save_and_reclaim((void *)f_7513,2,av);}
a=C_alloc(33);
t2=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[5]);
t4=C_a_i_cons(&a,2,lf[101],t3);
t5=C_a_i_list(&a,2,((C_word*)t0)[6],t4);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
t7=C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[8];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_a_i_list(&a,3,t1,t7,((C_word*)t0)[9]);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* k8483 in map*946 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8485(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_8485,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8489,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* chicken-syntax.scm:370: map* */
t6=((C_word*)((C_word*)t0)[4])[1];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k8487 in k8483 in map*946 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_ccall f_8489(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_8489,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in ... */
static void C_ccall f_3637(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3637,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5256,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5258,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1055: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_3634(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3634,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5512,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1014: ##sys#primitive-alias */
t4=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[104];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_ccall f_3631(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3631,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5692,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:982: ##sys#primitive-alias */
t4=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[104];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in ... */
static void C_ccall f_3649(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3649,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5092,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5094,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1099: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_3646(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3646,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5189,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5191,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1089: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_ccall f_3643(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3643,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5210,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5212,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1082: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in ... */
static void C_ccall f_3640(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3640,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5227,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5229,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1071: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5635 in k5615 in loop in k5533 in k5530 in k5527 in k5524 in a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_5637(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5637,2,av);}
/* chicken-syntax.scm:1002: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in ... */
static void C_ccall f_6087(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_6087,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6090,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:876: r */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[138];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6079 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_6081(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6081,2,av);}
/* chicken-syntax.scm:869: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[130];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_6083(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_6083,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6087,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:875: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[130];
av2[3]=t2;
av2[4]=lf[139];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k5641 in k5615 in loop in k5533 in k5530 in k5527 in k5524 in a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_5643(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_5643,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
/* chicken-syntax.scm:1006: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5542(t4,((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[5],((C_word*)t0)[6],C_SCHEME_TRUE);}
else{
/* chicken-syntax.scm:1007: syntax-error */
t4=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[111];
av2[3]=lf[112];
av2[4]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[6]);
/* chicken-syntax.scm:1010: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_5542(t7,((C_word*)t0)[4],t3,((C_word*)t0)[5],t6,C_SCHEME_FALSE);}}

/* k8453 in append*945 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8455(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_8455,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_ccall f_6073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,5))){C_save_and_reclaim((void *)f_6073,2,av);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,lf[114],t1);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5700,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5702,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:910: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in ... */
static void C_ccall f_6090(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6090,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6093,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:877: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[137];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4748 in k4817 in k4701 in k4698 in a4695 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_4750(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(57,c,1))){C_save_and_reclaim((void *)f_4750,2,av);}
a=C_alloc(57);
t2=C_a_i_list(&a,2,lf[20],t1);
t3=C_a_i_list(&a,2,lf[20],((C_word*)t0)[2]);
t4=C_a_i_list(&a,5,lf[74],((C_word*)t0)[3],((C_word*)t0)[4],t2,t3);
t5=C_a_i_list(&a,3,lf[75],lf[76],lf[77]);
t6=C_a_i_list(&a,2,lf[78],t4);
t7=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list(&a,5,lf[79],((C_word*)t0)[6],C_SCHEME_TRUE,t5,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* g2200 in k4701 in k4698 in a4695 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_fcall f_4755(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_4755,3,t0,t1,t2);}
a=C_alloc(6);
t3=C_i_car(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4762,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=C_i_cadr(t2);
/* chicken-syntax.scm:1157: ##sys#validate-exports */
t7=*((C_word*)lf[73]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
av2[3]=lf[70];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k5187 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in ... */
static void C_ccall f_5189(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5189,2,av);}
/* chicken-syntax.scm:1087: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[92];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a5190 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in ... */
static void C_ccall f_5191(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_5191,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5195,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1091: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[92];
av2[3]=t2;
av2[4]=lf[94];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k5193 in a5190 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in ... */
static void C_ccall f_5195(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5195,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1092: r */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[93];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6097 in k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in ... */
static void C_ccall f_6099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_6099,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6102,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:880: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[27];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_6096(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_6096,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6099,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:879: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[129];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_ccall f_6093(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_6093,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6096,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:878: r */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[136];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5014 in loop2119 in k4998 in k4992 in k4989 in k4983 in a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_5016(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5016,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_eqp(((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1107: ##sys#+ */
t5=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=C_fix(-1);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* loop2119 in k4998 in k4992 in k4989 in k4983 in a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_fcall f_5009(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_5009,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5016,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1107: ##sys#= */
t5=*((C_word*)lf[57]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k4998 in k4992 in k4989 in k4983 in a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_ccall f_5000(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_5000,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5009,a[2]=t4,a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5009(t6,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_4956(2,av2);}}}

/* loop2119 in k5048 in k5042 in k5039 in a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_fcall f_5059(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_5059,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5066,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1107: ##sys#= */
t5=*((C_word*)lf[57]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k10917 in g31 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_10919(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10919,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_pairp(t3))){
t4=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_i_symbolp(t4))){
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
if(C_truep(C_i_nullp(t7))){
t8=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_i_cadr(((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
/* chicken-syntax.scm:75: syntax-error */
t8=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[280];
av2[3]=lf[281];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}}
else{
/* chicken-syntax.scm:75: syntax-error */
t5=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[280];
av2[3]=lf[281];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}
else{
/* chicken-syntax.scm:75: syntax-error */
t4=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[280];
av2[3]=lf[281];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}
else{
/* chicken-syntax.scm:75: syntax-error */
t2=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[280];
av2[3]=lf[281];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}}

/* k5048 in k5042 in k5039 in a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_5050(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_5050,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5059,a[2]=t4,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5059(t6,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_4985(2,av2);}}}

/* k5064 in loop2119 in k5048 in k5042 in k5039 in a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_ccall f_5066(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5066,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_eqp(((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5080,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1107: ##sys#+ */
t5=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=C_fix(-1);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* mapslots in k11138 in k11164 in k10949 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_fcall f_10976(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,2))){
C_save_and_reclaim_args((void *)trf_10976,4,t0,t1,t2,t3);}
a=C_alloc(11);
t4=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t2;
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t5=C_i_car(t2);
t6=C_i_symbolp(t5);
t7=C_i_not(t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10992,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t8,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t8)){
t10=C_i_cadr(t5);
/* chicken-syntax.scm:92: symbol->string */
t11=*((C_word*)lf[183]+1);{
C_word av2[3];
av2[0]=t11;
av2[1]=t9;
av2[2]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
/* chicken-syntax.scm:92: symbol->string */
t10=*((C_word*)lf[183]+1);{
C_word av2[3];
av2[0]=t10;
av2[1]=t9;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}}}

/* k10972 in k11138 in k11164 in k10949 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_10974(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_10974,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[26],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k7154 in k7227 in k7231 in k7235 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in ... */
static void C_ccall f_7156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_7156,2,av);}
/* chicken-syntax.scm:696: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[178];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5028 in k5014 in loop2119 in k4998 in k4992 in k4989 in k4983 in a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_ccall f_5030(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5030,2,av);}
/* chicken-syntax.scm:1107: loop2119 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5009(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* a7157 in k7227 in k7231 in k7235 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in ... */
static void C_ccall f_7158(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_7158,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7162,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:703: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[178];
av2[3]=t2;
av2[4]=lf[179];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k5039 in a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_5041(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5041,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* chicken-syntax.scm:1107: ##sys#length */
t4=*((C_word*)lf[59]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_4985(2,av2);}}}

/* k7146 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_ccall f_7148(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,5))){C_save_and_reclaim((void *)f_7148,2,av);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,lf[173],t1);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7000,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7002,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:727: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k5042 in k5039 in a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_5044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5044,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1107: ##sys#>= */
t4=*((C_word*)lf[58]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k10949 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_10951(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_10951,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11166,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11186,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#string-append */
t5=*((C_word*)lf[286]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[288];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k7231 in k7235 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_ccall f_7233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_7233,2,av);}
a=C_alloc(8);
t2=C_a_i_cons(&a,2,lf[154],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7229,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:700: ##sys#primitive-alias */
t5=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[155];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7235 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_ccall f_7237(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_7237,2,av);}
a=C_alloc(7);
t2=C_a_i_cons(&a,2,lf[173],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7233,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:699: ##sys#primitive-alias */
t5=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[154];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k4942 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_ccall f_4944(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4944,2,av);}
/* chicken-syntax.scm:1105: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[88];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_ccall f_4946(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_4946,5,av);}
a=C_alloc(14);
t5=C_i_cdr(t2);
t6=t5;
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4956,a[2]=t6,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t7))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4985,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5041,a[2]=t7,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=C_i_car(t7);
/* chicken-syntax.scm:1107: ##sys#list? */
t12=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t12;
av2[1]=t10;
av2[2]=t11;
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
t9=t8;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_SCHEME_FALSE;
f_4956(2,av2);}}}

/* k4954 in a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_4956(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4956,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_i_cdr(((C_word*)t0)[2]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4969,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1107: rename2122 */
t7=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[89];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
/* chicken-syntax.scm:1107: ##sys#syntax-rules-mismatch */
t2=*((C_word*)lf[55]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k7227 in k7231 in k7235 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in ... */
static void C_ccall f_7229(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,5))){C_save_and_reclaim((void *)f_7229,2,av);}
a=C_alloc(19);
t2=C_a_i_cons(&a,2,lf[155],t1);
t3=C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7156,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7158,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:701: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in ... */
static void C_ccall f_7251(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,6))){C_save_and_reclaim((void *)f_7251,2,av);}
a=C_alloc(12);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7341,a[2]=((C_word*)t0)[3],a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7430,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t9,a[6]=((C_word*)t0)[4],a[7]=t10,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:653: ##sys#check-syntax */
t12=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t12;
av2[1]=t11;
av2[2]=lf[180];
av2[3]=t5;
av2[4]=lf[190];
((C_proc)(void*)(*((C_word*)t12+1)))(5,av2);}}

/* k4967 in k4954 in a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_4969(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_4969,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,t1,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k10993 in k10990 in mapslots in k11138 in k11164 in k10949 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_10995(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,4))){C_save_and_reclaim((void *)f_10995,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11121,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:94: string-append */
t5=*((C_word*)lf[182]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[10];
av2[3]=lf[283];
av2[4]=((C_word*)t0)[11];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k10996 in k10993 in k10990 in mapslots in k11138 in k11164 in k10949 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_10998(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(79,c,2))){C_save_and_reclaim((void *)f_10998,2,av);}
a=C_alloc(79);
t2=t1;
t3=C_a_i_list(&a,2,lf[127],lf[282]);
t4=C_a_i_list(&a,2,lf[116],((C_word*)t0)[2]);
t5=C_a_i_list(&a,3,lf[120],lf[127],t4);
t6=C_a_i_list(&a,2,lf[121],t5);
t7=C_a_i_list(&a,4,lf[124],lf[127],((C_word*)t0)[3],lf[282]);
t8=C_a_i_list(&a,4,lf[101],t3,t6,t7);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11024,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11028,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=t9,a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=t10,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
t12=t11;
f_11028(t12,C_SCHEME_END_OF_LIST);}
else{
t12=C_a_i_list(&a,3,((C_word*)t0)[9],((C_word*)t0)[10],t9);
t13=t11;
f_11028(t13,C_a_i_list(&a,1,t12));}}

/* k7243 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_ccall f_7245(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_7245,2,av);}
/* chicken-syntax.scm:608: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[180];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5446 in k5420 in loop in k5334 in k5331 in k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_5448(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,6))){C_save_and_reclaim((void *)f_5448,2,av);}
a=C_alloc(12);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
/* chicken-syntax.scm:1039: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5343(t4,((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],C_SCHEME_TRUE);}
else{
/* chicken-syntax.scm:1040: syntax-error */
t4=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[105];
av2[3]=lf[106];
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5488,a[2]=((C_word*)t0)[9],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1044: gensym */
t4=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_ccall f_7247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_7247,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7251,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:614: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[180];
av2[3]=t2;
av2[4]=lf[191];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10990 in mapslots in k11138 in k11164 in k10949 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_10992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,5))){C_save_and_reclaim((void *)f_10992,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11125,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:93: string-append */
t5=*((C_word*)lf[182]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[10];
av2[3]=lf[284];
av2[4]=t2;
av2[5]=lf[285];
((C_proc)(void*)(*((C_word*)t5+1)))(6,av2);}}

/* k5440 in k5420 in loop in k5334 in k5331 in k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_5442(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5442,2,av);}
/* chicken-syntax.scm:1035: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4983 in a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_4985(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4985,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1107: ##sys#list? */
t4=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_4956(2,av2);}}}

/* map-loop820 in k9311 in k9291 in k9168 in k9151 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_fcall f_9339(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(15,0,3))){
C_save_and_reclaim_args((void *)trf_9339,4,t0,t1,t2,t3);}
a=C_alloc(15);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,4,t6,t7,C_SCHEME_FALSE,C_SCHEME_TRUE);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k4989 in k4983 in a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_4991(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4991,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1107: ##sys#length */
t4=*((C_word*)lf[59]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_4956(2,av2);}}}

/* k4417 in k4411 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_ccall f_4419(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4419,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1210: ##sys#length */
t4=*((C_word*)lf[59]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_4251(2,av2);}}}

/* k4992 in k4989 in k4983 in a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_4994(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4994,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1107: ##sys#>= */
t4=*((C_word*)lf[58]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k4411 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_4413(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4413,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1210: ##sys#list? */
t4=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_4251(2,av2);}}}

/* k5420 in loop in k5334 in k5331 in k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_5422(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_5422,2,av);}
a=C_alloc(12);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5425,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[8],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1035: gensym */
t4=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
/* chicken-syntax.scm:1037: c */
t5=((C_word*)t0)[10];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=((C_word*)t0)[11];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k5423 in k5420 in loop in k5334 in k5331 in k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_5425(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,6))){C_save_and_reclaim((void *)f_5425,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken-syntax.scm:1036: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5343(t6,((C_word*)t0)[6],t3,t4,((C_word*)t0)[7],t5,C_SCHEME_FALSE);}

/* k9311 in k9291 in k9168 in k9151 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_ccall f_9313(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,4))){C_save_and_reclaim((void *)f_9313,2,av);}
a=C_alloc(21);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9317,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9329,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9339,a[2]=t6,a[3]=t10,a[4]=t7,a[5]=((C_word)li114),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_9339(t12,t8,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k4426 in k4420 in k4417 in k4411 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in ... */
static void C_ccall f_4428(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4428,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4437,a[2]=t4,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4437(t6,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_4251(2,av2);}}}

/* k9315 in k9311 in k9291 in k9168 in k9151 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_ccall f_9317(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_9317,2,av);}
/* chicken-syntax.scm:280: ##sys#append */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4420 in k4417 in k4411 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in ... */
static void C_ccall f_4422(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4422,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1210: ##sys#>= */
t4=*((C_word*)lf[58]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k7004 in a7001 in k7146 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in ... */
static void C_ccall f_7006(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_7006,2,av);}
a=C_alloc(7);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7018,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t9,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:733: r */
t11=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[173];
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}

/* a7001 in k7146 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in ... */
static void C_ccall f_7002(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_7002,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7006,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:729: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[174];
av2[3]=t2;
av2[4]=lf[177];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k7203 in k7163 in k7160 in a7157 in k7227 in k7231 in k7235 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_ccall f_7205(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_7205,2,av);}
a=C_alloc(13);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=t2;
t4=C_i_cddr(((C_word*)t0)[3]);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7195,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t7,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:708: r */
t9=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[154];
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}

/* k6998 in k7146 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in ... */
static void C_ccall f_7000(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_7000,2,av);}
/* chicken-syntax.scm:724: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[174];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5486 in k5446 in k5420 in loop in k5334 in k5331 in k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_5488(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5488,2,av);}
/* chicken-syntax.scm:1044: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_9044,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9063,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:279: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[235];
av2[3]=t2;
av2[4]=lf[242];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k9040 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9042(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9042,2,av);}
/* chicken-syntax.scm:271: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[235];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7075 in k7064 in loop in k7025 in k7022 in k7019 in k7016 in k7004 in a7001 in k7146 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_ccall f_7077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_7077,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* map-loop1051 in fold in k8560 in k8545 in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_fcall f_8599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_8599,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8624,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:396: g1057 */
t5=((C_word*)t0)[4];
f_8583(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8595 in fold in k8560 in k8545 in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_ccall f_8597(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_8597,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[30],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8589 in g1057 in fold in k8560 in k8545 in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_ccall f_8591(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_8591,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_5692(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,5))){C_save_and_reclaim((void *)f_5692,2,av);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,lf[104],t1);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5520,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5522,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:983: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k9327 in k9311 in k9291 in k9168 in k9151 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_ccall f_9329(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_9329,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,3,lf[239],((C_word*)t0)[2],C_SCHEME_FALSE);
t3=C_a_i_list(&a,1,t2);
/* chicken-syntax.scm:280: ##sys#append */
t4=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5463 in k5446 in k5420 in loop in k5334 in k5331 in k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_5465(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,6))){C_save_and_reclaim((void *)f_5465,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
t6=C_a_i_list2(&a,2,t1,t5);
t7=C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken-syntax.scm:1045: loop */
t9=((C_word*)((C_word*)t0)[5])[1];
f_5343(t9,((C_word*)t0)[6],t3,((C_word*)t0)[7],t7,t8,C_SCHEME_FALSE);}

/* a9019 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9020(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_9020,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9024,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:320: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[233];
av2[3]=t2;
av2[4]=lf[234];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k9022 in a9019 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_9024,2,av);}
a=C_alloc(12);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_a_i_cons(&a,2,lf[26],t5);
t7=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[159],t2,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k9016 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9018(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9018,2,av);}
/* chicken-syntax.scm:316: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[233];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4467 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_4469(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4469,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* chicken-syntax.scm:1210: ##sys#length */
t4=*((C_word*)lf[59]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_4413(2,av2);}}}

/* map-loop680 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_fcall f_9553(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_9553,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k4492 in loop2280 in k4476 in k4470 in k4467 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in ... */
static void C_ccall f_4494(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_4494,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_eqp(((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_i_car(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4506,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t2))){
t4=C_i_cdr(t2);
if(C_truep(C_i_pairp(t4))){
t5=C_i_cdr(t4);
t6=t3;
f_4506(t6,C_eqp(t5,C_SCHEME_END_OF_LIST));}
else{
t5=t3;
f_4506(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_4506(t4,C_SCHEME_FALSE);}}}

/* k9291 in k9168 in k9151 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in ... */
static void C_ccall f_9293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(29,c,4))){C_save_and_reclaim((void *)f_9293,2,av);}
a=C_alloc(29);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9297,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9313,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9387,a[2]=t6,a[3]=t10,a[4]=t7,a[5]=((C_word)li115),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_9387(t12,t8,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k4476 in k4470 in k4467 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in ... */
static void C_ccall f_4478(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4478,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4487,a[2]=t4,a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4487(t6,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_4413(2,av2);}}}

/* map-loop711 in k9151 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in ... */
static void C_fcall f_9505(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_9505,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k4470 in k4467 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_ccall f_4472(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4472,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1210: ##sys#>= */
t4=*((C_word*)lf[58]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k9295 in k9291 in k9168 in k9151 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_ccall f_9297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(42,c,4))){C_save_and_reclaim((void *)f_9297,2,av);}
a=C_alloc(42);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[30],t2);
t4=C_a_i_list(&a,3,lf[101],C_SCHEME_END_OF_LIST,t3);
t5=t4;
t6=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t7=C_a_i_cons(&a,2,lf[101],t6);
t8=t7;
t9=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t11)[1];
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9210,a[2]=t5,a[3]=t8,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9212,a[2]=t11,a[3]=t15,a[4]=t12,a[5]=((C_word)li113),tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_9212(t17,t13,((C_word*)t0)[8],((C_word*)t0)[9]);}

/* loop2280 in k4476 in k4470 in k4467 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in ... */
static void C_fcall f_4487(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_4487,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4494,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1210: ##sys#= */
t5=*((C_word*)lf[57]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* g748 in k9168 in k9151 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in ... */
static C_word C_fcall f_9275(C_word *a,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;{}
t4=C_a_i_list(&a,4,t1,t2,C_SCHEME_TRUE,C_SCHEME_FALSE);
t5=C_a_i_list(&a,4,lf[159],((C_word*)t0)[2],t4,t2);
return(C_a_i_list(&a,2,t3,t5));}

/* map-loop348 in k9929 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_10188(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_10188,4,t0,t1,t2,t3);}
a=C_alloc(12);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,3,lf[239],t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in ... */
static void C_ccall f_7699(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_7699,2,av);}
a=C_alloc(7);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7707,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:502: r */
t8=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[176];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in ... */
static void C_ccall f_7695(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_7695,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7699,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:499: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[192];
av2[3]=t2;
av2[4]=lf[201];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k7691 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in ... */
static void C_ccall f_7693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_7693,2,av);}
/* chicken-syntax.scm:495: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[192];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in ... */
static void C_fcall f_3914(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(11,0,4))){
C_save_and_reclaim_args((void *)trf_3914,5,t0,t1,t2,t3,t4);}
a=C_alloc(11);
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:1232: reverse */
t6=*((C_word*)lf[43]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=C_i_car(t2);
t6=t5;
if(C_truep(C_i_symbolp(t6))){
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_a_i_cons(&a,2,t6,t3);
t10=C_a_i_cons(&a,2,lf[44],t4);
/* chicken-syntax.scm:1264: loop */
t12=t1;
t13=t8;
t14=t9;
t15=t10;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4165,a[2]=t2,a[3]=t6,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_listp(t6))){
t8=C_u_i_length(t6);
t9=C_eqp(C_fix(2),t8);
if(C_truep(t9)){
t10=C_i_car(t6);
t11=t7;
f_4165(t11,C_i_symbolp(t10));}
else{
t10=t7;
f_4165(t10,C_SCHEME_FALSE);}}
else{
t8=t7;
f_4165(t8,C_SCHEME_FALSE);}}}}

/* k4844 in map-loop2194 in k4701 in k4698 in a4695 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_4846(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4846,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4821(t6,((C_word*)t0)[5],t5);}

/* k8635 in fold in k8560 in k8545 in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_fcall f_8637(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,4))){
C_save_and_reclaim_args((void *)trf_8637,2,t0,t1);}
a=C_alloc(14);
if(C_truep(t1)){
t2=C_i_caar(((C_word*)t0)[2]);
t3=C_i_car(((C_word*)t0)[3]);
t4=C_a_i_list(&a,2,t2,t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8648,a[2]=((C_word*)t0)[4],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_i_cdr(((C_word*)t0)[5]);
t9=((C_word*)t0)[3];
t10=C_u_i_cdr(t9);
t11=((C_word*)t0)[2];
t12=C_u_i_cdr(t11);
/* chicken-syntax.scm:401: fold */
t13=((C_word*)((C_word*)t0)[6])[1];
f_8564(t13,t7,t8,t10,t12);}
else{
t2=C_i_car(((C_word*)t0)[3]);
t3=C_a_i_list(&a,3,lf[101],C_SCHEME_END_OF_LIST,t2);
t4=t3;
t5=((C_word*)t0)[2];
t6=C_u_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8685,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t8=C_i_cdr(((C_word*)t0)[5]);
t9=((C_word*)t0)[3];
t10=C_u_i_cdr(t9);
t11=((C_word*)t0)[2];
t12=C_u_i_cdr(t11);
/* chicken-syntax.scm:407: fold */
t13=((C_word*)((C_word*)t0)[6])[1];
f_8564(t13,t7,t8,t10,t12);}}

/* k3922 in loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in ... */
static void C_ccall f_3924(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_3924,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:1233: reverse */
t4=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[10];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3925 in k3922 in loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in ... */
static void C_ccall f_3927(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,4))){C_save_and_reclaim((void *)f_3927,2,av);}
a=C_alloc(17);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4111,a[2]=t5,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4111(t7,t3,((C_word*)t0)[10],C_fix(1));}

/* k4817 in k4701 in k4698 in a4695 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_ccall f_4819(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_4819,2,av);}
a=C_alloc(13);
t2=C_a_i_list(&a,2,lf[20],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1166: ##sys#validate-exports */
t5=*((C_word*)lf[73]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
av2[3]=lf[70];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k8646 in k8635 in fold in k8560 in k8545 in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_ccall f_8648(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_8648,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3931 in k4107 in k3925 in k3922 in loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in ... */
static void C_ccall f_3933(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(44,c,4))){C_save_and_reclaim((void *)f_3933,2,av);}
a=C_alloc(44);
t2=C_a_i_list(&a,2,lf[35],((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,lf[36],((C_word*)t0)[2]);
t4=C_a_i_list(&a,3,lf[37],t2,t3);
t5=t4;
t6=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t7=t6;
t8=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t9=t8;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=((C_word*)t10)[1];
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3968,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3970,a[2]=t10,a[3]=t14,a[4]=t11,a[5]=((C_word)li4),tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_3970(t16,t12,((C_word*)t0)[3],((C_word*)t0)[7]);}

/* k7809 in k7755 in k7749 in expand in k7711 in k7708 in k7705 in k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_ccall f_7811(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_7811,2,av);}
a=C_alloc(11);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=C_u_i_cdr(((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,lf[26],t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7793,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:530: expand */
t8=((C_word*)((C_word*)t0)[5])[1];
f_7726(t8,t7,((C_word*)t0)[6],C_SCHEME_FALSE);}

/* map-loop2194 in k4701 in k4698 in a4695 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_fcall f_4821(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4821,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4846,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:1155: g2200 */
t5=((C_word*)t0)[4];
f_4755(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* map-loop1371 in k7755 in k7749 in expand in k7711 in k7708 in k7705 in k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_fcall f_7813(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(12,0,2))){
C_save_and_reclaim_args((void *)trf_7813,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_7800(C_a_i(&a,9),((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4870 in k4867 in k4864 in k4861 in a4858 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_ccall f_4872(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,2))){C_save_and_reclaim((void *)f_4872,2,av);}
a=C_alloc(19);
t2=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=t2;
t4=C_a_i_list(&a,2,((C_word*)t0)[2],lf[82]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4895,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=C_i_caddr(((C_word*)t0)[5]);
/* chicken-syntax.scm:1129: ##sys#strip-syntax */
t8=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k7495 in g1541 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_7497(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7497,2,av);}
/* chicken-syntax.scm:671: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop2459 in k3931 in k4107 in k3925 in k3922 in loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in ... */
static void C_fcall f_3970(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(21,0,3))){
C_save_and_reclaim_args((void *)trf_3970,4,t0,t1,t2,t3);}
a=C_alloc(21);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,4,lf[38],t7,C_SCHEME_TRUE,t6);
t9=C_a_i_list2(&a,2,t6,t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t10);
t12=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t10);
t13=C_slot(t2,C_fix(1));
t14=C_slot(t3,C_fix(1));
t16=t1;
t17=t13;
t18=t14;
t1=t16;
t2=t17;
t3=t18;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* map-loop1086 in k8545 in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in ... */
static void C_fcall f_8713(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_8713,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3966 in k3931 in k4107 in k3925 in k3922 in loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in ... */
static void C_ccall f_3968(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,1))){C_save_and_reclaim((void *)f_3968,2,av);}
a=C_alloc(27);
t2=C_a_i_list(&a,3,lf[30],t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[26],((C_word*)t0)[6],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* g1541 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_fcall f_7489(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_7489,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7497,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:671: prefix-sym */
f_7443(t3,lf[185],t2);}

/* k4855 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_4857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4857,2,av);}
/* chicken-syntax.scm:1114: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[81];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a4858 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_4859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4859,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4863,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1118: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[81];
av2[3]=t2;
av2[4]=lf[87];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4456 in k4442 in loop2280 in k4426 in k4420 in k4417 in k4411 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in ... */
static void C_ccall f_4458(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4458,2,av);}
/* chicken-syntax.scm:1210: loop2280 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4437(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in ... */
static void C_ccall f_7485(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(31,c,3))){C_save_and_reclaim((void *)f_7485,2,av);}
a=C_alloc(31);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7500,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7539,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=t6,a[6]=((C_word)li67),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_7539(t12,t8,((C_word*)t0)[5]);}

/* k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in ... */
static void C_ccall f_7482(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_7482,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:669: r */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[187];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k10112 in k9929 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10114(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,4))){C_save_and_reclaim((void *)f_10114,2,av);}
a=C_alloc(20);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10118,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10130,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10140,a[2]=t6,a[3]=t10,a[4]=t7,a[5]=((C_word)li131),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_10140(t12,t8,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k10116 in k10112 in k9929 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10118(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_10118,2,av);}
/* chicken-syntax.scm:214: ##sys#append */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4867 in k4864 in k4861 in a4858 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_ccall f_4869(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_4869,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4872,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_eqp(lf[44],((C_word*)t0)[2]);
if(C_truep(t4)){
/* chicken-syntax.scm:1122: syntax-error-hook */
t5=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[81];
av2[3]=lf[86];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_4872(2,av2);}}}

/* k4861 in a4858 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_4863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4863,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* chicken-syntax.scm:1119: ##sys#strip-syntax */
t4=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4864 in k4861 in a4858 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_4866(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4866,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4869,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1120: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[20];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* loop2280 in k4426 in k4420 in k4417 in k4411 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in ... */
static void C_fcall f_4437(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_4437,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4444,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1210: ##sys#= */
t5=*((C_word*)lf[57]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* g1377 in k7755 in k7749 in expand in k7711 in k7708 in k7705 in k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static C_word C_fcall f_7800(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_stack_overflow_check;{}
return(C_a_i_list(&a,3,lf[197],((C_word*)t0)[2],t1));}

/* k7453 in prefix-sym in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_7455(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7455,2,av);}
/* chicken-syntax.scm:657: string-append */
t2=*((C_word*)lf[182]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k7449 in prefix-sym in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_7451(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7451,2,av);}
/* chicken-syntax.scm:657: string->symbol */
t2=*((C_word*)lf[181]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* g1484 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_fcall f_7459(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_7459,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7467,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:662: prefix-sym */
f_7443(t3,lf[184],t2);}

/* map-loop257 in k10242 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_10341(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_10341,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k4442 in loop2280 in k4426 in k4420 in k4417 in k4411 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in ... */
static void C_ccall f_4444(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4444,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_eqp(((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4458,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1210: ##sys#+ */
t5=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=C_fix(-1);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* fold in k7865 in a7862 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in ... */
static void C_fcall f_7877(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_7877,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[26],((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=t3;
t5=t2;
t6=C_u_i_cdr(t5);
if(C_truep(C_i_pairp(t4))){
t7=C_i_cdr(t4);
if(C_truep(C_i_nullp(t7))){
t8=C_u_i_car(t4);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7919,a[2]=t1,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:488: fold */
t11=t9;
t12=t6;
t1=t11;
t2=t12;
goto loop;}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7922,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:490: ##sys#check-syntax */
t9=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[202];
av2[3]=t4;
av2[4]=lf[203];
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7904,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:487: fold */
t11=t7;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k4896 in k4893 in k4870 in k4867 in k4864 in k4861 in a4858 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_ccall f_4898(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,1))){C_save_and_reclaim((void *)f_4898,2,av);}
a=C_alloc(24);
t2=C_a_i_list(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list(&a,4,lf[16],((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,lf[17],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* prefix-sym in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_fcall f_7443(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_7443,3,t1,t2,t3);}
a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7451,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7455,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:657: symbol->string */
t6=*((C_word*)lf[183]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in ... */
static void C_ccall f_7442(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(32,c,4))){C_save_and_reclaim((void *)f_7442,2,av);}
a=C_alloc(32);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7443,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7459,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp);
t9=C_i_check_list_2(t2,lf[28]);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7473,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7607,a[2]=t6,a[3]=t12,a[4]=t8,a[5]=t7,a[6]=((C_word)li69),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_7607(t14,t10,t2);}

/* k9168 in k9151 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in ... */
static void C_ccall f_9170(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(47,c,5))){C_save_and_reclaim((void *)f_9170,2,av);}
a=C_alloc(47);
t2=t1;
t3=C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_TRUE);
t4=C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9275,a[2]=((C_word*)t0)[4],a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp);
t12=C_i_check_list_2(((C_word*)t0)[5],lf[28]);
t13=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9293,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9435,a[2]=t11,a[3]=t9,a[4]=t15,a[5]=t10,a[6]=((C_word)li116),tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_9435(t17,t13,((C_word*)t0)[9],((C_word*)t0)[10],((C_word*)t0)[5]);}

/* k7630 in map-loop1478 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_7632(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_7632,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7607(t6,((C_word*)t0)[5],t5);}

/* k3702 in k3693 in a3690 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in ... */
static void C_ccall f_3704(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3704,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3707,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1311: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[20];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3705 in k3702 in k3693 in a3690 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in ... */
static void C_ccall f_3707(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3707,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3710,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_i_caddr(((C_word*)t0)[4]);
/* chicken-syntax.scm:1312: ##sys#strip-syntax */
t5=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k4893 in k4870 in k4867 in k4864 in k4861 in a4858 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_4895(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(36,c,4))){C_save_and_reclaim((void *)f_4895,2,av);}
a=C_alloc(36);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_eqp(lf[44],t1);
if(C_truep(t3)){
t4=C_a_i_list(&a,2,((C_word*)t0)[2],lf[44]);
t5=C_a_i_list(&a,4,lf[16],((C_word*)t0)[3],((C_word*)t0)[4],t4);
t6=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_list(&a,2,lf[17],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
if(C_truep(C_i_symbolp(t1))){
t4=C_a_i_list(&a,2,lf[83],t1);
t5=C_a_i_list(&a,2,((C_word*)t0)[2],t4);
t6=C_a_i_list(&a,4,lf[16],((C_word*)t0)[3],((C_word*)t0)[4],t5);
t7=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list(&a,2,lf[17],t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
if(C_truep(C_i_listp(t1))){
/* chicken-syntax.scm:1133: ##sys#validate-exports */
t4=*((C_word*)lf[73]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t1;
av2[3]=lf[81];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=C_i_caddr(((C_word*)t0)[6]);
/* chicken-syntax.scm:1135: syntax-error-hook */
t5=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=lf[81];
av2[3]=lf[85];
av2[4]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}}}

/* k6112 in k6109 in k6106 in parse-clause in k6100 in k6097 in k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_fcall f_6114(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(25,0,3))){
C_save_and_reclaim_args((void *)trf_6114,2,t0,t1);}
a=C_alloc(25);
t2=t1;
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t3;
av2[1]=C_a_i_list(&a,2,((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6139,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li40),tmp=(C_word)a,a+=5,tmp);
t8=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6153,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6155,a[2]=t7,a[3]=t5,a[4]=t11,a[5]=t6,a[6]=((C_word)li41),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_6155(t13,t9,((C_word*)t0)[2]);}}

/* map-loop384 in k10112 in k9929 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_10140(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_10140,4,t0,t1,t2,t3);}
a=C_alloc(12);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,3,lf[239],t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k6109 in k6106 in parse-clause in k6100 in k6097 in k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_fcall f_6111(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(23,0,2))){
C_save_and_reclaim_args((void *)trf_6111,2,t0,t1);}
a=C_alloc(23);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6114,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
t4=C_a_i_list(&a,2,((C_word*)t0)[7],((C_word*)t0)[8]);
t5=C_a_i_list(&a,1,t4);
t6=C_i_cddr(((C_word*)t0)[9]);
t7=C_a_i_cons(&a,2,t5,t6);
t8=t3;
f_6114(t8,C_a_i_cons(&a,2,lf[30],t7));}
else{
t4=((C_word*)t0)[9];
t5=C_u_i_cdr(t4);
t6=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=t3;
f_6114(t7,C_a_i_cons(&a,2,lf[30],t6));}}

/* k8622 in map-loop1051 in fold in k8560 in k8545 in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_ccall f_8624(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_8624,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8599(t6,((C_word*)t0)[5],t5);}

/* parse-clause in k6100 in k6097 in k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_ccall f_6104(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_6104,3,av);}
a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6108,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=C_i_car(t2);
if(C_truep(C_i_symbolp(t4))){
t5=t2;
t6=t3;
f_6108(t6,C_u_i_car(t5));}
else{
t5=t3;
f_6108(t5,C_SCHEME_FALSE);}}

/* k10128 in k10112 in k9929 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_10130,2,av);}
a=C_alloc(6);
t2=C_a_i_list(&a,1,lf[231]);
t3=C_a_i_list(&a,1,t2);
/* chicken-syntax.scm:214: ##sys#append */
t4=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_6619(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_6619,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:783: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[154];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6106 in parse-clause in k6100 in k6097 in k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_fcall f_6108(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,2))){
C_save_and_reclaim_args((void *)trf_6108,2,t0,t1);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t4=t3;
f_6111(t4,C_i_cadr(((C_word*)t0)[8]));}
else{
t4=((C_word*)t0)[8];
t5=t3;
f_6111(t5,C_u_i_car(t4));}}

/* k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in ... */
static void C_ccall f_6992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_6992,2,av);}
a=C_alloc(7);
t2=C_a_i_cons(&a,2,lf[153],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6988,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:760: ##sys#primitive-alias */
t5=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[154];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* map-loop1448 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in ... */
static void C_fcall f_7641(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_7641,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6100 in k6097 in k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in ... */
static void C_ccall f_6102(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_6102,2,av);}
a=C_alloc(18);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6104,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li42),tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6234,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:892: r */
t5=((C_word*)t0)[8];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[135];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_ccall f_6616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_6616,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:782: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[156];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in ... */
static void C_ccall f_6613(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_6613,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6616,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:781: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[153];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in ... */
static void C_ccall f_6610(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_6610,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6613,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:780: r */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[167];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in ... */
static void C_ccall f_6984(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_6984,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,lf[155],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:762: ##sys#primitive-alias */
t5=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[156];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_6607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_6607,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:779: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[168];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in ... */
static void C_ccall f_6980(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_6980,2,av);}
a=C_alloc(10);
t2=C_a_i_cons(&a,2,lf[156],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:763: ##sys#primitive-alias */
t5=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[157];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3747 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_ccall f_3749(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3749,2,av);}
/* chicken-syntax.scm:1278: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[25];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in ... */
static void C_ccall f_6988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_6988,2,av);}
a=C_alloc(8);
t2=C_a_i_cons(&a,2,lf[154],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6984,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:761: ##sys#primitive-alias */
t5=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[155];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8683 in k8635 in fold in k8560 in k8545 in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_ccall f_8685(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,1))){C_save_and_reclaim((void *)f_8685,2,av);}
a=C_alloc(18);
t2=C_a_i_list(&a,3,lf[101],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[144],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in ... */
static void C_ccall f_6601(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,3))){C_save_and_reclaim((void *)f_6601,2,av);}
a=C_alloc(22);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_cdr(((C_word*)t0)[4]);
t8=C_i_check_list_2(t7,lf[28]);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6918,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6920,a[2]=t5,a[3]=t11,a[4]=t6,a[5]=((C_word)li56),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_6920(t13,t9,t7);}

/* a7862 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_ccall f_7863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_7863,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7867,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:479: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[202];
av2[3]=t2;
av2[4]=lf[204];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k7859 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_ccall f_7861(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_7861,2,av);}
/* chicken-syntax.scm:475: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[202];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_ccall f_6604(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6604,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6607,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:778: genvars */
t4=((C_word*)t0)[5];
f_6566(t4,t3,t2);}

/* k7865 in a7862 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in ... */
static void C_ccall f_7867(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_7867,2,av);}
a=C_alloc(7);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7877,a[2]=t5,a[3]=t7,a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_7877(t9,((C_word*)t0)[3],t2);}

/* k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_ccall f_6976(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,5))){C_save_and_reclaim((void *)f_6976,2,av);}
a=C_alloc(25);
t2=C_a_i_cons(&a,2,lf[157],t1);
t3=C_a_i_list(&a,5,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6558,a[2]=((C_word*)t0)[6],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6560,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:764: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k8776 in loop in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in ... */
static void C_ccall f_8778(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_8778,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* chicken-syntax.scm:390: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_8747(t5,((C_word*)t0)[5],t4,t2);}

/* map-loop278 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_10389(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_10389,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3708 in k3705 in k3702 in k3693 in a3690 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in ... */
static void C_ccall f_3710(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,4))){C_save_and_reclaim((void *)f_3710,2,av);}
a=C_alloc(18);
t2=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=t2;
t4=C_a_i_list(&a,2,((C_word*)t0)[2],lf[15]);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3733,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1317: ##compiler#check-and-validate-type */
t7=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t1;
av2[3]=lf[12];
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_ccall f_6635(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(32,c,4))){C_save_and_reclaim((void *)f_6635,2,av);}
a=C_alloc(32);
t2=t1;
t3=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6647,a[2]=t6,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6649,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[12],a[11]=((C_word)li54),tmp=(C_word)a,a+=12,tmp);
t9=((C_word*)t0)[13];
t10=C_u_i_cdr(t9);
/* chicken-syntax.scm:790: fold-right */
t11=*((C_word*)lf[164]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t11;
av2[1]=t7;
av2[2]=t8;
av2[3]=lf[165];
av2[4]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(5,av2);}}

/* k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_ccall f_6628(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_6628,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6635,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm:787: append */
t4=*((C_word*)lf[166]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k8783 in loop in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in ... */
static void C_ccall f_8785(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_8785,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* chicken-syntax.scm:390: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_8747(t5,((C_word*)t0)[5],t4,t2);}

/* k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_6625(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_6625,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm:785: r */
t4=((C_word*)t0)[8];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[157];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_6622(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_6622,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:784: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[155];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* map-loop1892 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in ... */
static void C_fcall f_6033(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_6033,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* map-loop1478 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_fcall f_7607(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_7607,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7632,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:662: g1484 */
t5=((C_word*)t0)[4];
f_7459(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* g1814 in k6112 in k6109 in k6106 in parse-clause in k6100 in k6097 in k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static C_word C_fcall f_6139(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_a_i_list(&a,2,lf[116],t1);
return(C_a_i_list(&a,3,((C_word*)t0)[2],t2,((C_word*)t0)[3]));}

/* k6943 in map-loop1631 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_6945(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6945,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6920(t6,((C_word*)t0)[5],t5);}

/* g2520 in k3762 in k3759 in k3753 in a3750 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in ... */
static void C_fcall f_3788(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_3788,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3792,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* chicken-syntax.scm:1291: ##sys#strip-syntax */
t5=*((C_word*)lf[19]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k8410 in fold in k8380 in k8372 in a8369 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_ccall f_8412(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_8412,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in k10251 in k10242 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_10321(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_10321,3,t0,t1,t2);}
a=C_alloc(3);
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10335,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_fixnum_difference(t2,C_fix(1));
/* chicken-syntax.scm:225: loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* map*946 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8462(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_8462,4,av);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t3))){
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8485,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
/* chicken-syntax.scm:370: proc */
t6=t2;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
/* chicken-syntax.scm:369: proc */
t4=t2;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}}

/* map-loop1631 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_fcall f_6920(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,5))){
C_save_and_reclaim_args((void *)trf_6920,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6945,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6908,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:774: ##sys#decompose-lambda-list */
t7=*((C_word*)lf[163]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t3;
av2[2]=t5;
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k10333 in loop in k10251 in k10242 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10335(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_10335,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,C_SCHEME_FALSE,t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* loop in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_fcall f_8747(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_8747,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
/* chicken-syntax.scm:385: reverse */
t4=*((C_word*)lf[43]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t4=C_i_car(t2);
if(C_truep(C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8785,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:389: map* */
t6=((C_word*)((C_word*)t0)[3])[1];{
C_word av2[4];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[4];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8778,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:388: lookup */
t6=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
f_8536(3,av2);}}}}

/* k5839 in k5797 in k5790 in k5784 in loop in k5995 in k5740 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_ccall f_5841(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,1))){C_save_and_reclaim((void *)f_5841,2,av);}
a=C_alloc(18);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_5807(t2,C_SCHEME_END_OF_LIST);}
else{
t2=C_a_i_list(&a,2,lf[123],lf[123]);
t3=C_a_i_list(&a,3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);
t4=((C_word*)t0)[2];
f_5807(t4,C_a_i_list(&a,1,t3));}}

/* loop in k5533 in k5530 in k5527 in k5524 in a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in ... */
static void C_fcall f_5542(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,3))){
C_save_and_reclaim_args((void *)trf_5542,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(11);
if(C_truep(C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5552,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:992: reverse */
t7=*((C_word*)lf[43]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5617,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=C_i_car(t2);
/* chicken-syntax.scm:1001: c */
t8=((C_word*)t0)[6];{
C_word av2[4];
av2[0]=t8;
av2[1]=t6;
av2[2]=((C_word*)t0)[8];
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}}

/* a6688 in k6671 in k6661 in a6658 in a6648 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in ... */
static void C_ccall f_6689(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(16,c,4))){C_save_and_reclaim((void *)f_6689,4,av);}
a=C_alloc(16);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6693,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6765,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t6,a[7]=((C_word*)t0)[7],a[8]=((C_word)li51),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_6765(t8,t4,t3,((C_word*)t0)[8]);}

/* k5553 in k5550 in loop in k5533 in k5530 in k5527 in k5524 in a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_5555(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,2))){C_save_and_reclaim((void *)f_5555,2,av);}
a=C_alloc(18);
t2=t1;
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5561,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5594,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:995: gensym */
t5=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=C_a_i_list(&a,2,lf[26],t3);
t5=C_u_i_cdr(t2);
t6=C_a_i_cons(&a,2,t4,t5);
t7=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[101],((C_word*)t0)[5],t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k5809 in k5805 in k5797 in k5790 in k5784 in loop in k5995 in k5740 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_5811(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5811,2,av);}
/* chicken-syntax.scm:939: ##sys#append */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5550 in loop in k5533 in k5530 in k5527 in k5524 in a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_ccall f_5552(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5552,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:993: reverse */
t4=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6685 in a6678 in k6671 in k6661 in a6658 in a6648 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in ... */
static void C_ccall f_6687(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6687,2,av);}
/* chicken-syntax.scm:803: split-at! */
t2=*((C_word*)lf[160]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in ... */
static void C_ccall f_5733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,3))){C_save_and_reclaim((void *)f_5733,2,av);}
a=C_alloc(26);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5742,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t2,a[12]=((C_word*)t0)[2],tmp=(C_word)a,a+=13,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6033,a[2]=t5,a[3]=t10,a[4]=t6,a[5]=((C_word)li38),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_6033(t12,t8,((C_word*)t0)[2]);}

/* k3797 in k3790 in g2520 in k3762 in k3759 in k3753 in a3750 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in ... */
static void C_ccall f_3799(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_3799,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,lf[26],t3);
t5=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_list2(&a,2,t1,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_5730(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_5730,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:924: r */
t4=((C_word*)t0)[11];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[126];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5566 in k5559 in k5553 in k5550 in loop in k5533 in k5530 in k5527 in k5524 in a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_5568(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_5568,2,av);}
a=C_alloc(9);
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5584,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=C_u_i_cdr(((C_word*)t0)[2]);
t7=C_a_i_list(&a,1,((C_word*)t0)[5]);
/* chicken-syntax.scm:995: ##sys#append */
t8=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t5;
av2[2]=t6;
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k3790 in g2520 in k3762 in k3759 in k3753 in a3750 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in ... */
static void C_ccall f_3792(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_3792,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_eqp(t1,lf[27]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_a_i_cons(&a,2,lf[26],t5);
t7=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list2(&a,2,lf[27],t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
if(C_truep(((C_word*)t0)[4])){
/* chicken-syntax.scm:1296: ##compiler#check-and-validate-type */
t4=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t1;
av2[3]=lf[25];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=t1;
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,lf[26],t6);
t8=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_a_i_list2(&a,2,t4,t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}}

/* k8420 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8422(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8422,2,av);}
/* chicken-syntax.scm:355: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[219];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_8424,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8428,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:359: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[219];
av2[3]=t2;
av2[4]=lf[221];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8428(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,4))){C_save_and_reclaim((void *)f_8428,2,av);}
a=C_alloc(33);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8434,a[2]=t8,a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8462,a[2]=t10,a[3]=((C_word)li91),tmp=(C_word)a,a+=4,tmp);
t13=C_set_block_item(t8,0,t11);
t14=C_set_block_item(t10,0,t12);
t15=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t16=t15;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=((C_word*)t17)[1];
t19=C_i_check_list_2(t3,lf[28]);
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8510,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t10,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8863,a[2]=t17,a[3]=t22,a[4]=t18,a[5]=((C_word)li101),tmp=(C_word)a,a+=6,tmp));
t24=((C_word*)t22)[1];
f_8863(t24,t20,t3);}

/* k5559 in k5553 in k5550 in loop in k5533 in k5530 in k5527 in k5524 in a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_5561(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5561,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:995: ##sys#append */
t4=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k6596 in loop in genvars in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_6598(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6598,2,av);}
/* chicken-syntax.scm:771: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6588 in k6584 in loop in genvars in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in ... */
static void C_ccall f_6590(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_6590,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3762 in k3759 in k3753 in a3750 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in ... */
static void C_ccall f_3764(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,3))){C_save_and_reclaim((void *)f_3764,2,av);}
a=C_alloc(33);
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3788,a[2]=((C_word*)t0)[4],a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp);
t12=((C_word*)t0)[2];
t13=C_u_i_cdr(t12);
t14=C_u_i_cdr(t13);
t15=C_i_check_list_2(t14,lf[28]);
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3826,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3828,a[2]=t9,a[3]=t18,a[4]=t11,a[5]=t10,a[6]=((C_word)li2),tmp=(C_word)a,a+=7,tmp));
t20=((C_word*)t18)[1];
f_3828(t20,t16,t14);}

/* k5740 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in ... */
static void C_ccall f_5742(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(37,c,3))){C_save_and_reclaim((void *)f_5742,2,av);}
a=C_alloc(37);
t2=C_a_i_list(&a,2,lf[116],((C_word*)t0)[2]);
t3=t2;
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5984,a[2]=((C_word*)t0)[3],a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
t9=C_i_check_list_2(t1,lf[28]);
t10=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5997,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5999,a[2]=t8,a[3]=t6,a[4]=t12,a[5]=t7,a[6]=((C_word)li37),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_5999(t14,t10,t1);}

/* k3759 in k3753 in a3750 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in ... */
static void C_ccall f_3761(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3761,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3764,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1285: get-line-number */
t4=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* append*945 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8434(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_8434,4,av);}
a=C_alloc(4);
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8455,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=t2;
t8=C_u_i_cdr(t7);
/* chicken-syntax.scm:366: append* */
t9=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t6;
av2[2]=t8;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a6658 in a6648 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in ... */
static void C_ccall f_6659(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(17,c,4))){C_save_and_reclaim((void *)f_6659,5,av);}
a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6663,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],tmp=(C_word)a,a+=17,tmp);
t6=C_i_car(((C_word*)t0)[5]);
/* chicken-syntax.scm:795: ##sys#check-syntax */
t7=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=lf[158];
av2[3]=t6;
av2[4]=lf[162];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_ccall f_7685(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,5))){C_save_and_reclaim((void *)f_7685,2,av);}
a=C_alloc(16);
t2=C_a_i_cons(&a,2,lf[155],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7245,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7247,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:612: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in ... */
static void C_ccall f_7689(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_7689,2,av);}
a=C_alloc(7);
t2=C_a_i_cons(&a,2,lf[154],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7685,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:611: ##sys#primitive-alias */
t5=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[155];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6645 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_6647(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,1))){C_save_and_reclaim((void *)f_6647,2,av);}
a=C_alloc(18);
t2=C_a_i_list(&a,3,lf[30],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[101],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a6648 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_6649(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(14,c,5))){C_save_and_reclaim((void *)f_6649,4,av);}
a=C_alloc(14);
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6659,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word)li53),tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm:792: ##sys#decompose-lambda-list */
t6=*((C_word*)lf[163]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t4;
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in ... */
static void C_ccall f_5512(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,5))){C_save_and_reclaim((void *)f_5512,2,av);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,lf[104],t1);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5321,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5323,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1015: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* a6678 in k6671 in k6661 in a6658 in a6648 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in ... */
static void C_ccall f_6679(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_6679,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6687,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:803: take */
t3=*((C_word*)lf[161]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k5527 in k5524 in a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_ccall f_5529(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_5529,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:987: r */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[104];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5524 in a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in ... */
static void C_ccall f_5526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5526,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5529,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:986: r */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[108];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in ... */
static void C_ccall f_5522(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5522,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5526,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:985: r */
t6=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[109];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k6671 in k6661 in a6658 in a6648 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in ... */
static void C_fcall f_6673(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(21,0,4))){
C_save_and_reclaim_args((void *)trf_6673,2,t0,t1);}
a=C_alloc(21);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6677,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6679,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word)li49),tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6689,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word)li52),tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:802: ##sys#call-with-values */{
C_word av2[4];
av2[0]=0;
av2[1]=t3;
av2[2]=t4;
av2[3]=t5;
C_call_with_values(4,av2);}}

/* k5518 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in ... */
static void C_ccall f_5520(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5520,2,av);}
/* chicken-syntax.scm:980: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[111];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6675 in k6671 in k6661 in a6658 in a6648 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in ... */
static void C_ccall f_6677(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_6677,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,4,lf[159],((C_word*)t0)[3],t1,((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5784 in loop in k5995 in k5740 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_fcall f_5786(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(!C_demand(C_calculate_demand(128,0,2))){
C_save_and_reclaim_args((void *)trf_5786,2,t0,t1);}
a=C_alloc(128);
t2=t1;
t3=C_a_i_list(&a,1,((C_word*)t0)[2]);
t4=C_a_i_list(&a,2,lf[116],((C_word*)t0)[3]);
t5=C_i_cadr(((C_word*)t0)[4]);
t6=C_a_i_list(&a,2,lf[116],t5);
t7=C_a_i_list(&a,4,lf[120],((C_word*)t0)[2],t4,t6);
t8=C_a_i_list(&a,2,lf[121],t7);
t9=C_a_i_list(&a,3,lf[122],((C_word*)t0)[2],((C_word*)t0)[5]);
t10=C_a_i_list(&a,4,lf[101],t3,t8,t9);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5792,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t11,tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[9])){
t13=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[14]);
t14=C_a_i_list(&a,2,lf[116],((C_word*)t0)[3]);
t15=C_a_i_list(&a,2,lf[116],t2);
t16=C_a_i_list(&a,4,lf[120],((C_word*)t0)[2],t14,t15);
t17=C_a_i_list(&a,2,lf[121],t16);
t18=C_a_i_list(&a,4,lf[124],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[14]);
t19=t12;
f_5792(t19,C_a_i_list(&a,4,lf[101],t13,t17,t18));}
else{
t13=t12;
f_5792(t13,C_SCHEME_FALSE);}}

/* a5093 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in ... */
static void C_ccall f_5094(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5094,5,av);}
a=C_alloc(6);
t5=C_i_cdr(t2);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5104,a[2]=t6,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t6))){
t8=C_i_cdr(t6);
t9=t7;
f_5104(t9,C_eqp(t8,C_SCHEME_END_OF_LIST));}
else{
t8=t7;
f_5104(t8,C_SCHEME_FALSE);}}

/* k5090 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in ... */
static void C_ccall f_5092(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5092,2,av);}
/* chicken-syntax.scm:1097: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[90];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5533 in k5530 in k5527 in k5524 in a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in ... */
static void C_ccall f_5535(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,6))){C_save_and_reclaim((void *)f_5535,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5542,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word)li33),tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_5542(t7,((C_word*)t0)[8],t3,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k6661 in a6658 in a6648 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in ... */
static void C_ccall f_6663(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,2))){C_save_and_reclaim((void *)f_6663,2,av);}
a=C_alloc(23);
t2=C_fixnum_difference(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6673,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[8])){
t4=C_eqp(t2,C_fix(0));
t5=t3;
f_6673(t5,(C_truep(t4)?C_SCHEME_TRUE:C_a_i_list(&a,3,((C_word*)t0)[14],((C_word*)t0)[15],t2)));}
else{
t4=t3;
f_6673(t4,C_a_i_list(&a,3,((C_word*)t0)[16],((C_word*)t0)[15],t2));}}

/* k5530 in k5527 in k5524 in a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_5532(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_5532,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5535,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=C_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t4))){
/* chicken-syntax.scm:989: syntax-error */
t5=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[111];
av2[3]=lf[113];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t5=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_5535(2,av2);}}}

/* k10706 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10708(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10708,2,av);}
/* chicken-syntax.scm:153: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[270];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop1242 in k8162 in k8156 in k8134 in k8128 in k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_fcall f_8180(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_8180,4,t0,t1,t2,t3);}
a=C_alloc(7);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8209,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* chicken-syntax.scm:440: g1248 */
t9=((C_word*)t0)[4];{
C_word av2[4];
av2[0]=t9;
av2[1]=t6;
av2[2]=t7;
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k4163 in loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in ... */
static void C_fcall f_4165(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,5))){
C_save_and_reclaim_args((void *)trf_4165,2,t0,t1);}
a=C_alloc(10);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_i_car(((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[4]);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4182,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t3,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=C_i_cadr(((C_word*)t0)[3]);
/* chicken-syntax.scm:1270: ##compiler#check-and-validate-type */
t9=*((C_word*)lf[18]+1);{
C_word av2[4];
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
av2[3]=lf[34];
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
/* chicken-syntax.scm:1274: syntax-error */
t2=*((C_word*)lf[45]+1);{
C_word av2[6];
av2[0]=t2;
av2[1]=((C_word*)t0)[7];
av2[2]=lf[34];
av2[3]=lf[46];
av2[4]=((C_word*)t0)[3];
av2[5]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}}

/* k11184 in k10949 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_11186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11186,2,av);}
/* chicken-syntax.scm:80: string->symbol */
t2=*((C_word*)lf[181]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in ... */
static void C_ccall f_3900(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_3900,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3903,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=C_i_cdddr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t4))){
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=C_u_i_car(t7);
/* chicken-syntax.scm:1227: ##sys#strip-syntax */
t9=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t3;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t5=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_3903(2,av2);}}}

/* k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_ccall f_5724(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_5724,2,av);}
a=C_alloc(12);
t2=t1;
t3=C_i_cdr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5730,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t2,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:923: r */
t6=((C_word*)t0)[9];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[127];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in ... */
static void C_ccall f_5721(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_5721,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:921: r */
t4=((C_word*)t0)[8];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[114];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5078 in k5064 in loop2119 in k5048 in k5042 in k5039 in a4945 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_5080(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5080,2,av);}
/* chicken-syntax.scm:1107: loop2119 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_5059(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k8166 in k8162 in k8156 in k8134 in k8128 in k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_ccall f_8168(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_8168,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[30],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8162 in k8156 in k8134 in k8128 in k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in ... */
static void C_ccall f_8164(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,4))){C_save_and_reclaim((void *)f_8164,2,av);}
a=C_alloc(22);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8168,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=*((C_word*)lf[215]+1);
t9=C_i_check_list_2(((C_word*)t0)[3],lf[28]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8178,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8180,a[2]=t6,a[3]=t12,a[4]=t8,a[5]=t7,a[6]=((C_word)li81),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_8180(t14,t10,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* k4107 in k3925 in k3922 in loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in ... */
static void C_ccall f_4109(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,4))){C_save_and_reclaim((void *)f_4109,2,av);}
a=C_alloc(21);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4028,a[2]=t4,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4032,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1243: ##sys#get */
t7=*((C_word*)lf[42]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[9];
av2[3]=lf[40];
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in ... */
static void C_ccall f_3906(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,5))){C_save_and_reclaim((void *)f_3906,2,av);}
a=C_alloc(13);
t2=t1;
t3=(C_truep(((C_word*)t0)[2])?C_i_cadddr(((C_word*)t0)[3]):C_i_caddr(((C_word*)t0)[3]));
t4=t3;
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3914,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[2],a[8]=t6,a[9]=((C_word*)t0)[7],a[10]=((C_word)li7),tmp=(C_word)a,a+=11,tmp));
t8=((C_word*)t6)[1];
f_3914(t8,((C_word*)t0)[8],((C_word*)t0)[9],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in ... */
static void C_ccall f_3903(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_3903,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3906,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:1228: r */
t4=((C_word*)t0)[9];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[47];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k8176 in k8162 in k8156 in k8134 in k8128 in k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_ccall f_8178(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8178,2,av);}
/* chicken-syntax.scm:429: ##sys#append */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k8906 in k8903 in a8900 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_8908,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:353: r */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[223];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8903 in a8900 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8905(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,5))){C_save_and_reclaim((void *)f_8905,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8923,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:346: ##sys#decompose-lambda-list */
t5=*((C_word*)lf[163]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* a8900 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8901(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_8901,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8905,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:345: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[222];
av2[3]=t2;
av2[4]=lf[228];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10720 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10722(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10722,2,av);}
/* chicken-syntax.scm:139: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[271];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5801 in k5797 in k5790 in k5784 in loop in k5995 in k5740 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_ccall f_5803(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_5803,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5805 in k5797 in k5790 in k5784 in loop in k5995 in k5740 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_fcall f_5807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_5807,2,t0,t1);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5811,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
t6=C_fixnum_increase(((C_word*)t0)[4]);
/* chicken-syntax.scm:975: loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_5767(t7,t3,t5,t6);}

/* k5582 in k5566 in k5559 in k5553 in k5550 in loop in k5533 in k5530 in k5527 in k5524 in a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_ccall f_5584(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,1))){C_save_and_reclaim((void *)f_5584,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[101],((C_word*)t0)[5],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k8913 in k8906 in k8903 in a8900 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8915(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_8915,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,t1,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a10709 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10710(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_10710,5,av);}
a=C_alloc(3);
t5=C_i_cdr(t2);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_a_i_cons(&a,2,lf[37],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k5592 in k5553 in k5550 in loop in k5533 in k5530 in k5527 in k5524 in a5521 in k5690 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_5594(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5594,2,av);}
/* chicken-syntax.scm:995: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k10726 in a10723 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10728(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(57,c,1))){C_save_and_reclaim((void *)f_10728,2,av);}
a=C_alloc(57);
t2=C_a_i_list(&a,1,lf[272]);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=C_a_i_cons(&a,2,lf[101],t4);
t6=C_a_i_list(&a,1,lf[273]);
t7=C_a_i_list(&a,2,lf[274],t6);
t8=C_a_i_list(&a,3,lf[142],lf[143],t1);
t9=C_a_i_list(&a,4,lf[101],t1,t7,t8);
t10=C_a_i_list(&a,3,lf[144],t5,t9);
t11=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t11;
av2[1]=C_a_i_list(&a,3,lf[26],t2,t10);
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}

/* a10723 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10724(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_10724,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10728,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:143: r */
t6=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[275];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("chicken_2dsyntax_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_chicken_2dsyntax_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(2901)){
C_save(t1);
C_rereclaim2(2901*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,296);
lf[0]=C_h_intern(&lf[0],28,"\003sysdefine-values-definition");
lf[1]=C_h_intern(&lf[1],29,"\003syschicken-macro-environment");
lf[2]=C_h_intern(&lf[2],17,"register-feature!");
lf[3]=C_h_intern(&lf[3],6,"srfi-8");
lf[4]=C_h_intern(&lf[4],7,"srfi-11");
lf[5]=C_h_intern(&lf[5],7,"srfi-15");
lf[6]=C_h_intern(&lf[6],7,"srfi-16");
lf[7]=C_h_intern(&lf[7],7,"srfi-26");
lf[8]=C_h_intern(&lf[8],7,"srfi-31");
lf[9]=C_h_intern(&lf[9],16,"\003sysmacro-subset");
lf[10]=C_h_intern(&lf[10],29,"\003sysdefault-macro-environment");
lf[11]=C_h_intern(&lf[11],28,"\003sysextend-macro-environment");
lf[12]=C_h_intern(&lf[12],11,"define-type");
lf[13]=C_h_intern(&lf[13],10,"\000compiling");
lf[14]=C_h_intern(&lf[14],12,"\003sysfeatures");
lf[15]=C_h_intern(&lf[15],26,"\010compilertype-abbreviation");
lf[16]=C_h_intern(&lf[16],16,"\003sysput/restore!");
lf[17]=C_h_intern(&lf[17],24,"\004coreelaborationtimeonly");
lf[18]=C_h_intern(&lf[18],32,"\010compilercheck-and-validate-type");
lf[19]=C_h_intern(&lf[19],16,"\003sysstrip-syntax");
lf[20]=C_h_intern(&lf[20],5,"quote");
lf[21]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[22]=C_h_intern(&lf[22],16,"\003syscheck-syntax");
lf[23]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[24]=C_h_intern(&lf[24],18,"\003syser-transformer");
lf[25]=C_h_intern(&lf[25],17,"compiler-typecase");
lf[26]=C_h_intern(&lf[26],10,"\004corebegin");
lf[27]=C_h_intern(&lf[27],4,"else");
lf[28]=C_h_intern(&lf[28],3,"map");
lf[29]=C_h_intern(&lf[29],13,"\004coretypecase");
lf[30]=C_h_intern(&lf[30],8,"\004corelet");
lf[31]=C_h_intern(&lf[31],15,"get-line-number");
lf[32]=C_h_intern(&lf[32],6,"gensym");
lf[33]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\001\000\000\000\001");
lf[34]=C_h_intern(&lf[34],21,"define-specialization");
lf[35]=C_h_intern(&lf[35],6,"inline");
lf[36]=C_h_intern(&lf[36],4,"hide");
lf[37]=C_h_intern(&lf[37],12,"\004coredeclare");
lf[38]=C_h_intern(&lf[38],8,"\004corethe");
lf[39]=C_h_intern(&lf[39],8,"\003sysput!");
lf[40]=C_h_intern(&lf[40],30,"\010compilerlocal-specializations");
lf[41]=C_h_intern(&lf[41],10,"\003sysappend");
lf[42]=C_h_intern(&lf[42],7,"\003sysget");
lf[43]=C_h_intern(&lf[43],7,"reverse");
lf[44]=C_h_intern(&lf[44],1,"\052");
lf[45]=C_h_intern(&lf[45],12,"syntax-error");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\027invalid argument syntax");
lf[47]=C_h_intern(&lf[47],6,"define");
lf[48]=C_h_intern(&lf[48],13,"\003sysglobalize");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000"
"\000\376\377\001\000\000\000\001");
lf[50]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[51]=C_h_intern(&lf[51],6,"assume");
lf[52]=C_h_intern(&lf[52],3,"the");
lf[53]=C_h_intern(&lf[53],9,"\003sysmap-n");
lf[54]=C_h_intern(&lf[54],3,"let");
lf[55]=C_h_intern(&lf[55],25,"\003syssyntax-rules-mismatch");
lf[56]=C_h_intern(&lf[56],5,"\003sys+");
lf[57]=C_h_intern(&lf[57],5,"\003sys=");
lf[58]=C_h_intern(&lf[58],6,"\003sys>=");
lf[59]=C_h_intern(&lf[59],10,"\003syslength");
lf[60]=C_h_intern(&lf[60],9,"\003syslist\077");
lf[61]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[62]=C_h_intern(&lf[62],1,":");
lf[63]=C_h_intern(&lf[63],22,"\010compilervalidate-type");
lf[64]=C_h_intern(&lf[64],4,"type");
lf[65]=C_h_intern(&lf[65],9,"predicate");
lf[66]=C_h_intern(&lf[66],4,"pure");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid type syntax");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[69]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[70]=C_h_intern(&lf[70],7,"functor");
lf[71]=C_h_intern(&lf[71],21,"\003syssyntax-error-hook");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid functor argument");
lf[73]=C_h_intern(&lf[73],20,"\003sysvalidate-exports");
lf[74]=C_h_intern(&lf[74],20,"\003sysregister-functor");
lf[75]=C_h_intern(&lf[75],6,"import");
lf[76]=C_h_intern(&lf[76],6,"scheme");
lf[77]=C_h_intern(&lf[77],7,"chicken");
lf[78]=C_h_intern(&lf[78],16,"begin-for-syntax");
lf[79]=C_h_intern(&lf[79],11,"\004coremodule");
lf[80]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_"
"\376\001\000\000\001_");
lf[81]=C_h_intern(&lf[81],16,"define-interface");
lf[82]=C_h_intern(&lf[82],14,"\004coreinterface");
lf[83]=C_h_intern(&lf[83],10,"\000interface");
lf[84]=C_h_intern(&lf[84],17,"syntax-error-hook");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\017invalid exports");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000-`\052\047 is not allowed as a name for an interface");
lf[87]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[88]=C_h_intern(&lf[88],19,"let-compiler-syntax");
lf[89]=C_h_intern(&lf[89],24,"\004corelet-compiler-syntax");
lf[90]=C_h_intern(&lf[90],22,"define-compiler-syntax");
lf[91]=C_h_intern(&lf[91],27,"\004coredefine-compiler-syntax");
lf[92]=C_h_intern(&lf[92],14,"use-for-syntax");
lf[93]=C_h_intern(&lf[93],28,"require-extension-for-syntax");
lf[94]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[95]=C_h_intern(&lf[95],3,"use");
lf[96]=C_h_intern(&lf[96],22,"\004corerequire-extension");
lf[97]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[98]=C_h_intern(&lf[98],17,"define-for-syntax");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[100]=C_h_intern(&lf[100],3,"rec");
lf[101]=C_h_intern(&lf[101],11,"\004corelambda");
lf[102]=C_h_intern(&lf[102],12,"\004coreletrec\052");
lf[103]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[104]=C_h_intern(&lf[104],5,"apply");
lf[105]=C_h_intern(&lf[105],4,"cute");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000+tail patterns after <...> are not supported");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\047you need to supply at least a procedure");
lf[108]=C_h_intern(&lf[108],5,"<...>");
lf[109]=C_h_intern(&lf[109],2,"<>");
lf[110]=C_h_intern(&lf[110],19,"\003sysprimitive-alias");
lf[111]=C_h_intern(&lf[111],3,"cut");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000+tail patterns after <...> are not supported");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\047you need to supply at least a procedure");
lf[114]=C_h_intern(&lf[114],18,"getter-with-setter");
lf[115]=C_h_intern(&lf[115],18,"define-record-type");
lf[116]=C_h_intern(&lf[116],10,"\004corequote");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[118]=C_h_intern(&lf[118],18,"\003sysmake-structure");
lf[119]=C_h_intern(&lf[119],14,"\003sysstructure\077");
lf[120]=C_h_intern(&lf[120],19,"\003syscheck-structure");
lf[121]=C_h_intern(&lf[121],10,"\004corecheck");
lf[122]=C_h_intern(&lf[122],13,"\003sysblock-ref");
lf[123]=C_h_intern(&lf[123],10,"\003syssetter");
lf[124]=C_h_intern(&lf[124],14,"\003sysblock-set!");
lf[125]=C_h_intern(&lf[125],6,"setter");
lf[126]=C_h_intern(&lf[126],1,"y");
lf[127]=C_h_intern(&lf[127],1,"x");
lf[128]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\010variable\376\001\000"
"\000\001_");
lf[129]=C_h_intern(&lf[129],4,"memv");
lf[130]=C_h_intern(&lf[130],14,"condition-case");
lf[131]=C_h_intern(&lf[131],9,"condition");
lf[132]=C_h_intern(&lf[132],8,"\003sysslot");
lf[133]=C_h_intern(&lf[133],10,"\003syssignal");
lf[134]=C_h_intern(&lf[134],4,"cond");
lf[135]=C_h_intern(&lf[135],17,"handle-exceptions");
lf[136]=C_h_intern(&lf[136],3,"and");
lf[137]=C_h_intern(&lf[137],4,"kvar");
lf[138]=C_h_intern(&lf[138],5,"exvar");
lf[139]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[140]=C_h_intern(&lf[140],30,"call-with-current-continuation");
lf[141]=C_h_intern(&lf[141],22,"with-exception-handler");
lf[142]=C_h_intern(&lf[142],9,"\003sysapply");
lf[143]=C_h_intern(&lf[143],10,"\003sysvalues");
lf[144]=C_h_intern(&lf[144],20,"\003syscall-with-values");
lf[145]=C_h_intern(&lf[145],4,"args");
lf[146]=C_h_intern(&lf[146],1,"k");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[148]=C_h_intern(&lf[148],21,"define-record-printer");
lf[149]=C_h_intern(&lf[149],27,"\003sysregister-record-printer");
lf[150]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[151]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[152]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[153]=C_h_intern(&lf[153],2,">=");
lf[154]=C_h_intern(&lf[154],3,"car");
lf[155]=C_h_intern(&lf[155],3,"cdr");
lf[156]=C_h_intern(&lf[156],3,"eq\077");
lf[157]=C_h_intern(&lf[157],6,"length");
lf[158]=C_h_intern(&lf[158],11,"case-lambda");
lf[159]=C_h_intern(&lf[159],7,"\004coreif");
lf[160]=C_h_intern(&lf[160],9,"split-at!");
lf[161]=C_h_intern(&lf[161],4,"take");
lf[162]=C_h_intern(&lf[162],11,"lambda-list");
lf[163]=C_h_intern(&lf[163],25,"\003sysdecompose-lambda-list");
lf[164]=C_h_intern(&lf[164],10,"fold-right");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\012\004corequote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376"
"\377\016\376\377\016\376\377\016");
lf[166]=C_h_intern(&lf[166],6,"append");
lf[167]=C_h_intern(&lf[167],4,"lvar");
lf[168]=C_h_intern(&lf[168],4,"rvar");
lf[169]=C_h_intern(&lf[169],3,"min");
lf[170]=C_h_intern(&lf[170],7,"require");
lf[171]=C_h_intern(&lf[171],6,"srfi-1");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[173]=C_h_intern(&lf[173],5,"null\077");
lf[174]=C_h_intern(&lf[174],14,"let-optionals\052");
lf[175]=C_h_intern(&lf[175],4,"tmp2");
lf[176]=C_h_intern(&lf[176],3,"tmp");
lf[177]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[178]=C_h_intern(&lf[178],8,"optional");
lf[179]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[180]=C_h_intern(&lf[180],13,"let-optionals");
lf[181]=C_h_intern(&lf[181],14,"string->symbol");
lf[182]=C_h_intern(&lf[182],13,"string-append");
lf[183]=C_h_intern(&lf[183],14,"symbol->string");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[186]=C_h_intern(&lf[186],4,"let\052");
lf[187]=C_h_intern(&lf[187],6,"_%rest");
lf[188]=C_h_intern(&lf[188],4,"body");
lf[189]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[190]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[191]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[192]=C_h_intern(&lf[192],6,"select");
lf[193]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[194]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corebegin\376\377\016");
lf[195]=C_h_intern(&lf[195],10,"\003sysnotice");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\0005non-`else\047 clause following `else\047 clause in `select\047");
lf[197]=C_h_intern(&lf[197],8,"\003syseqv\077");
lf[198]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid syntax");
lf[200]=C_h_intern(&lf[200],2,"or");
lf[201]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[202]=C_h_intern(&lf[202],8,"and-let\052");
lf[203]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[204]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[205]=C_h_intern(&lf[205],13,"define-inline");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\052invalid substitution form - must be lambda");
lf[207]=C_h_intern(&lf[207],6,"lambda");
lf[208]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[209]=C_h_intern(&lf[209],18,"\004coredefine-inline");
lf[210]=C_h_intern(&lf[210],8,"list-ref");
lf[211]=C_h_intern(&lf[211],9,"nth-value");
lf[212]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[213]=C_h_intern(&lf[213],13,"letrec-values");
lf[214]=C_h_intern(&lf[214],5,"foldl");
lf[215]=C_h_intern(&lf[215],37,"\003sysexpand-multiple-values-assignment");
lf[216]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[217]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\013lambda-list\376\001\000\000\001_\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[218]=C_h_intern(&lf[218],11,"let\052-values");
lf[219]=C_h_intern(&lf[219],10,"let-values");
lf[220]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[221]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[222]=C_h_intern(&lf[222],13,"define-values");
lf[223]=C_h_intern(&lf[223],11,"set!-values");
lf[224]=C_h_intern(&lf[224],8,"for-each");
lf[225]=C_h_intern(&lf[225],19,"\003sysregister-export");
lf[226]=C_h_intern(&lf[226],18,"\003syscurrent-module");
lf[227]=C_h_intern(&lf[227],16,"\004coremacro-alias");
lf[228]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[229]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[230]=C_h_intern(&lf[230],6,"unless");
lf[231]=C_h_intern(&lf[231],14,"\004coreundefined");
lf[232]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[233]=C_h_intern(&lf[233],4,"when");
lf[234]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[235]=C_h_intern(&lf[235],12,"parameterize");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\011parameter");
lf[237]=C_h_intern(&lf[237],5,"saved");
lf[238]=C_h_intern(&lf[238],16,"\003sysdynamic-wind");
lf[239]=C_h_intern(&lf[239],9,"\004coreset!");
lf[240]=C_h_intern(&lf[240],8,"convert\077");
lf[241]=C_h_intern(&lf[241],7,"boolean");
lf[242]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[243]=C_h_intern(&lf[243],9,"eval-when");
lf[244]=C_h_intern(&lf[244],19,"\004corecompiletimetoo");
lf[245]=C_h_intern(&lf[245],20,"\004corecompiletimeonly");
lf[246]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[247]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[248]=C_h_intern(&lf[248],9,"\003syserror");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[250]=C_h_intern(&lf[250],4,"load");
lf[251]=C_h_intern(&lf[251],7,"compile");
lf[252]=C_h_intern(&lf[252],4,"eval");
lf[253]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[254]=C_h_intern(&lf[254],9,"fluid-let");
lf[255]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[256]=C_h_intern(&lf[256],6,"ensure");
lf[257]=C_h_intern(&lf[257],15,"\003syssignal-hook");
lf[258]=C_h_intern(&lf[258],11,"\000type-error");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[260]=C_h_intern(&lf[260],14,"\004coreimmutable");
lf[261]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\003");
lf[262]=C_h_intern(&lf[262],6,"assert");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[266]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[267]=C_h_intern(&lf[267],7,"include");
lf[268]=C_h_intern(&lf[268],12,"\004coreinclude");
lf[269]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[270]=C_h_intern(&lf[270],7,"declare");
lf[271]=C_h_intern(&lf[271],4,"time");
lf[272]=C_h_intern(&lf[272],15,"\003sysstart-timer");
lf[273]=C_h_intern(&lf[273],14,"\003sysstop-timer");
lf[274]=C_h_intern(&lf[274],17,"\003sysdisplay-times");
lf[275]=C_h_intern(&lf[275],1,"t");
lf[276]=C_h_intern(&lf[276],7,"receive");
lf[277]=C_h_intern(&lf[277],8,"\003syslist");
lf[278]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[279]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[280]=C_h_intern(&lf[280],13,"define-record");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid slot specification");
lf[282]=C_h_intern(&lf[282],3,"val");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[286]=C_h_intern(&lf[286],17,"\003sysstring-append");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[289]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\001_");
lf[290]=C_h_intern(&lf[290],15,"define-constant");
lf[291]=C_h_intern(&lf[291],20,"\004coredefine-constant");
lf[292]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[293]=C_h_intern(&lf[293],21,"\003sysmacro-environment");
lf[294]=C_h_intern(&lf[294],11,"\003sysprovide");
lf[295]=C_h_intern(&lf[295],14,"chicken-syntax");
C_register_lf2(lf,296,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3536,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:38: ##sys#provide */
t3=*((C_word*)lf[294]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[295];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k11119 in k10993 in k10990 in mapslots in k11138 in k11164 in k10949 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_11121(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11121,2,av);}
/* chicken-syntax.scm:94: string->symbol */
t2=*((C_word*)lf[181]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k11123 in k10990 in mapslots in k11138 in k11164 in k10949 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_11125(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11125,2,av);}
/* chicken-syntax.scm:93: string->symbol */
t2=*((C_word*)lf[181]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_5702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_5702,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5706,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:912: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[115];
av2[3]=t2;
av2[4]=lf[128];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10769 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10771(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10771,2,av);}
/* chicken-syntax.scm:120: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[276];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in ... */
static void C_ccall f_5706(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_5706,2,av);}
a=C_alloc(9);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=C_i_cadddr(((C_word*)t0)[2]);
t7=t6;
t8=C_i_cddddr(((C_word*)t0)[2]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5721,a[2]=t5,a[3]=t9,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:920: r */
t11=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[47];
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}

/* a10772 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10773(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_10773,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10777,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:125: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[276];
av2[3]=t2;
av2[4]=lf[279];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k5698 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_5700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5700,2,av);}
/* chicken-syntax.scm:907: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[115];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k8088 in k8069 in k8066 in a8063 in k8104 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in ... */
static void C_ccall f_8090(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,1))){C_save_and_reclaim((void *)f_8090,2,av);}
a=C_alloc(27);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,t1,((C_word*)t0)[3],t2);
t4=C_a_i_list(&a,3,lf[101],((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_list(&a,3,lf[144],((C_word*)t0)[5],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k10775 in a10772 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10777(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,4))){C_save_and_reclaim((void *)f_10777,2,av);}
a=C_alloc(15);
t2=C_i_cddr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t2))){
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=C_a_i_cons(&a,2,lf[101],t5);
t7=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[144],t6,lf[277]);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:129: ##sys#check-syntax */
t4=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[276];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[278];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}

/* k8069 in k8066 in a8063 in k8104 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in ... */
static void C_ccall f_8071(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_8071,2,av);}
a=C_alloc(15);
t2=t1;
t3=C_i_caddr(((C_word*)t0)[2]);
t4=C_a_i_list(&a,3,lf[101],C_SCHEME_END_OF_LIST,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8090,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:452: r */
t7=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[210];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k4180 in k4163 in loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in ... */
static void C_ccall f_4182(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_4182,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* chicken-syntax.scm:1266: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3914(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* k11164 in k10949 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_11166(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(42,c,3))){C_save_and_reclaim((void *)f_11166,2,av);}
a=C_alloc(42);
t2=C_a_i_list(&a,2,lf[116],((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_a_i_cons(&a,2,lf[118],t3);
t5=C_a_i_list(&a,3,lf[101],((C_word*)t0)[3],t4);
t6=C_a_i_list(&a,3,((C_word*)t0)[4],t1,t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11160,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* ##sys#string-append */
t10=*((C_word*)lf[286]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=((C_word*)t0)[7];
av2[3]=lf[287];
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}

/* k11158 in k11164 in k10949 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_11160(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_11160,2,av);}
/* chicken-syntax.scm:85: string->symbol */
t2=*((C_word*)lf[181]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop1839 in k6232 in k6100 in k6097 in k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_fcall f_6290(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_6290,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6315,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:896: g1845 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* loop2 in k3925 in k3922 in loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in ... */
static void C_fcall f_4111(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_4111,4,t0,t1,t2,t3);}
a=C_alloc(6);
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_a_i_vector1(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4129,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cdr(t2);
t8=C_fixnum_plus(t3,C_fix(1));
/* chicken-syntax.scm:1239: loop2 */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k7036 in k7025 in k7022 in k7019 in k7016 in k7004 in a7001 in k7146 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in ... */
static void C_ccall f_7038(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_7038,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6387 in k6376 in k6373 in k6370 in a6367 in k6475 in k6479 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_ccall f_6389(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_6389,2,av);}
a=C_alloc(11);
t2=t1;
t3=C_a_i_list(&a,1,((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:859: r */
t6=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[141];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k4127 in loop2 in k3925 in k3922 in loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in ... */
static void C_ccall f_4129(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_4129,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k11138 in k11164 in k10949 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_11140(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(51,c,4))){C_save_and_reclaim((void *)f_11140,2,av);}
a=C_alloc(51);
t2=C_a_i_list(&a,1,lf[127]);
t3=C_a_i_list(&a,2,lf[20],((C_word*)t0)[2]);
t4=C_a_i_list(&a,3,lf[119],lf[127],t3);
t5=C_a_i_list(&a,3,lf[101],t2,t4);
t6=C_a_i_list(&a,3,((C_word*)t0)[3],t1,t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10974,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10976,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word)li148),tmp=(C_word)a,a+=8,tmp));
t12=((C_word*)t10)[1];
f_10976(t12,t8,((C_word*)t0)[8],C_fix(1));}

/* k6376 in k6373 in k6370 in a6367 in k6475 in k6479 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in ... */
static void C_ccall f_6378(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_6378,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:856: r */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[140];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6373 in k6370 in a6367 in k6475 in k6479 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in ... */
static void C_ccall f_6375(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6375,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6378,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:855: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[145];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7064 in loop in k7025 in k7022 in k7019 in k7016 in k7004 in a7001 in k7146 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in ... */
static void C_ccall f_7066(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_demand(C_calculate_demand(76,c,3))){C_save_and_reclaim((void *)f_7066,2,av);}
a=C_alloc(76);
t2=C_u_i_car(((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t6=C_a_i_list(&a,4,lf[159],t3,t4,t5);
t7=C_a_i_list(&a,2,t2,t6);
t8=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t9=C_a_i_list(&a,2,lf[20],C_SCHEME_END_OF_LIST);
t10=C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t11=C_a_i_list(&a,4,lf[159],t8,t9,t10);
t12=C_a_i_list(&a,2,t1,t11);
t13=C_a_i_list(&a,2,t7,t12);
t14=t13;
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7077,a[2]=((C_word*)t0)[7],a[3]=t14,tmp=(C_word)a,a+=4,tmp);
t16=((C_word*)t0)[8];
t17=C_u_i_cdr(t16);
/* chicken-syntax.scm:751: loop */
t18=((C_word*)((C_word*)t0)[9])[1];
f_7040(t18,t15,t1,t17);}

/* k6370 in a6367 in k6475 in k6479 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_6372(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_6372,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:854: r */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[146];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* map-loop25 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_fcall f_11190(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_11190,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11215,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:66: g31 */
t5=((C_word*)t0)[4];
f_10891(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a6367 in k6475 in k6479 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_ccall f_6368(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_6368,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6372,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:853: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[135];
av2[3]=t2;
av2[4]=lf[147];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k6364 in k6475 in k6479 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_ccall f_6366(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6366,2,av);}
/* chicken-syntax.scm:847: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[135];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k10797 in k10775 in a10772 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10799(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_10799,2,av);}
a=C_alloc(6);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10814,a[2]=t3,a[3]=t5,a[4]=t9,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t3))){
t11=C_u_i_cdr(t3);
t12=t10;
f_10814(t12,C_i_nullp(t11));}
else{
t11=t10;
f_10814(t11,C_SCHEME_FALSE);}}

/* k5860 in k5790 in k5784 in loop in k5995 in k5740 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_ccall f_5862(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,1))){C_save_and_reclaim((void *)f_5862,2,av);}
a=C_alloc(18);
if(C_truep(t1)){
t2=C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);
t3=((C_word*)t0)[5];
f_5799(t3,C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[7],t2));}
else{
t2=((C_word*)t0)[5];
f_5799(t2,C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[3]));}}

/* k6257 in k6232 in k6100 in k6097 in k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_6259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_6259,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:897: r */
t4=((C_word*)t0)[8];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[134];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k8284 in foldl1217 in k8134 in k8128 in k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in ... */
static void C_ccall f_8286(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8286,2,av);}
/* chicken-syntax.scm:436: ##sys#append */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a8287 in foldl1217 in k8134 in k8128 in k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in ... */
static void C_ccall f_8288(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_8288,5,av);}
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in ... */
static void C_ccall f_6358(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_6358,2,av);}
a=C_alloc(7);
t2=C_a_i_cons(&a,2,lf[27],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6354,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:872: ##sys#primitive-alias */
t5=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[129];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_ccall f_6354(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,5))){C_save_and_reclaim((void *)f_6354,2,av);}
a=C_alloc(16);
t2=C_a_i_cons(&a,2,lf[129],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6081,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6083,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:873: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k8290 in foldl1217 in k8134 in k8128 in k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in ... */
static void C_ccall f_8292(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8292,2,av);}
t2=((C_word*)((C_word*)t0)[2])[1];
f_8262(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* map-loop1165 in k8128 in k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_fcall f_8298(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_8298,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* foldl1217 in k8134 in k8128 in k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in ... */
static void C_fcall f_8262(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,5))){
C_save_and_reclaim_args((void *)trf_8262,4,t0,t1,t2,t3);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t4=C_slot(t2,C_fix(1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8292,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t2,C_fix(0));
t8=t6;
t9=t3;
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8286,a[2]=t8,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8288,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:436: ##sys#decompose-lambda-list */
t12=*((C_word*)lf[163]+1);{
C_word av2[4];
av2[0]=t12;
av2[1]=t10;
av2[2]=t7;
av2[3]=t11;
((C_proc)(void*)(*((C_word*)t12+1)))(4,av2);}}
else{
t4=t3;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k7022 in k7019 in k7016 in k7004 in a7001 in k7146 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_ccall f_7024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_7024,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:736: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[176];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7019 in k7016 in k7004 in a7001 in k7146 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in ... */
static void C_ccall f_7021(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_7021,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:735: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[155];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7025 in k7022 in k7019 in k7016 in k7004 in a7001 in k7146 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_7027(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,4))){C_save_and_reclaim((void *)f_7027,2,av);}
a=C_alloc(24);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7038,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7040,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t7,a[7]=((C_word*)t0)[8],a[8]=((C_word)li58),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_7040(t9,t5,t1,((C_word*)t0)[9]);}

/* k7016 in k7004 in a7001 in k7146 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in ... */
static void C_ccall f_7018(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_7018,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:734: r */
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[154];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5331 in k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in ... */
static void C_ccall f_5333(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_5333,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=C_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t4))){
/* chicken-syntax.scm:1021: syntax-error */
t5=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[105];
av2[3]=lf[107];
av2[4]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t5=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_5336(2,av2);}}}

/* k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_5330(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_5330,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:1019: r */
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[108];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5334 in k5331 in k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in ... */
static void C_ccall f_5336(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,7))){C_save_and_reclaim((void *)f_5336,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5343,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word)li31),tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_5343(t7,((C_word*)t0)[8],t3,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k7025 in k7022 in k7019 in k7016 in k7004 in a7001 in k7146 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in ... */
static void C_fcall f_7040(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,2))){
C_save_and_reclaim_args((void *)trf_7040,4,t0,t1,t2,t3);}
a=C_alloc(15);
if(C_truep(C_i_nullp(t3))){
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_a_i_cons(&a,2,lf[30],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=C_i_car(t3);
t5=t4;
if(C_truep(C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7066,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=t3,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:744: r */
t7=((C_word*)t0)[7];{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[175];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t6=C_a_i_list(&a,2,t5,t2);
t7=C_a_i_list(&a,1,t6);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[2]);
t9=t1;{
C_word av2[2];
av2[0]=t9;
av2[1]=C_a_i_cons(&a,2,lf[30],t8);
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}}}

/* k5351 in loop in k5334 in k5331 in k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_5353(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_5353,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:1025: reverse */
t4=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5354 in k5351 in loop in k5334 in k5331 in k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_5356(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,2))){C_save_and_reclaim((void *)f_5356,2,av);}
a=C_alloc(21);
t2=t1;
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5362,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5399,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1027: gensym */
t5=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=C_u_i_cdr(t2);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_a_i_list(&a,3,lf[101],((C_word*)t0)[6],t5);
t7=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k5763 in k5995 in k5740 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_5765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_5765,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[26],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* loop in k5995 in k5740 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_fcall f_5767(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(19,0,3))){
C_save_and_reclaim_args((void *)trf_5767,4,t0,t1,t2,t3);}
a=C_alloc(19);
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t4=C_i_car(t2);
t5=t4;
t6=C_i_cddr(t5);
t7=C_i_pairp(t6);
t8=t7;
t9=(C_truep(t8)?C_i_caddr(t5):C_SCHEME_FALSE);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=t8,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t10,a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_i_pairp(t10))){
t12=C_u_i_cdr(t10);
if(C_truep(C_i_pairp(t12))){
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5941,a[2]=t11,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t14=C_u_i_car(t10);
/* chicken-syntax.scm:944: c */
t15=((C_word*)t0)[5];{
C_word av2[4];
av2[0]=t15;
av2[1]=t13;
av2[2]=lf[125];
av2[3]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}
else{
t13=t11;
f_5786(t13,C_SCHEME_FALSE);}}
else{
t12=t11;
f_5786(t12,C_SCHEME_FALSE);}}}

/* a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in ... */
static void C_ccall f_5323(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5323,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5327,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1017: r */
t6=t3;{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[104];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k5319 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in ... */
static void C_ccall f_5321(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5321,2,av);}
/* chicken-syntax.scm:1012: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[105];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_ccall f_5327(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5327,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5330,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1018: r */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[109];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4515 in k4504 in k4492 in loop2280 in k4476 in k4470 in k4467 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in ... */
static void C_ccall f_4517(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4517,2,av);}
/* chicken-syntax.scm:1210: loop2280 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4487(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k5371 in k5360 in k5354 in k5351 in loop in k5334 in k5331 in k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_ccall f_5373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_5373,2,av);}
a=C_alloc(10);
t2=t1;
t3=C_i_car(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5389,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=C_u_i_cdr(((C_word*)t0)[2]);
t7=C_a_i_list(&a,1,((C_word*)t0)[6]);
/* chicken-syntax.scm:1027: ##sys#append */
t8=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t5;
av2[2]=t6;
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}

/* k7385 in k7409 in k7417 in k7425 in recur in make-if-tree in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in ... */
static void C_ccall f_7387(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,1))){C_save_and_reclaim((void *)f_7387,2,av);}
a=C_alloc(21);
t2=C_a_i_list(&a,3,lf[30],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,4,lf[159],((C_word*)t0)[4],((C_word*)t0)[5],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k9208 in k9295 in k9291 in k9168 in k9151 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_ccall f_9210(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(45,c,1))){C_save_and_reclaim((void *)f_9210,2,av);}
a=C_alloc(45);
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[101],t2);
t4=C_a_i_list(&a,4,lf[238],((C_word*)t0)[2],((C_word*)t0)[3],t3);
t5=C_a_i_list(&a,3,lf[30],((C_word*)t0)[4],t4);
t6=C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t5);
t7=((C_word*)t0)[6];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[30],((C_word*)t0)[7],t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* map-loop856 in k9295 in k9291 in k9168 in k9151 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_fcall f_9212(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(15,0,3))){
C_save_and_reclaim_args((void *)trf_9212,4,t0,t1,t2,t3);}
a=C_alloc(15);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,4,t6,t7,C_SCHEME_FALSE,C_SCHEME_TRUE);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* loop in k5334 in k5331 in k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_fcall f_5343(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_5343,7,t0,t1,t2,t3,t4,t5,t6);}
a=C_alloc(12);
if(C_truep(C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5353,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:1024: reverse */
t8=*((C_word*)lf[43]+1);{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5422,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t4,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t8=C_i_car(t2);
/* chicken-syntax.scm:1034: c */
t9=((C_word*)t0)[6];{
C_word av2[4];
av2[0]=t9;
av2[1]=t7;
av2[2]=((C_word*)t0)[8];
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}}

/* k5790 in k5784 in loop in k5995 in k5740 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_fcall f_5792(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(21,0,3))){
C_save_and_reclaim_args((void *)trf_5792,2,t0,t1);}
a=C_alloc(21);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t4=C_u_i_cdr(((C_word*)t0)[8]);
t5=C_u_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5862,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[10],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
t7=C_u_i_cdr(((C_word*)t0)[8]);
t8=C_u_i_car(t7);
/* chicken-syntax.scm:965: c */
t9=((C_word*)t0)[9];{
C_word av2[4];
av2[0]=t9;
av2[1]=t6;
av2[2]=((C_word*)t0)[7];
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
t7=t6;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
f_5862(2,av2);}}}

/* k5797 in k5790 in k5784 in loop in k5995 in k5740 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_fcall f_5799(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(22,0,3))){
C_save_and_reclaim_args((void *)trf_5799,2,t0,t1);}
a=C_alloc(22);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5803,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5807,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
if(C_truep(((C_word*)t0)[7])){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5841,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t6=C_i_cadr(((C_word*)t0)[9]);
/* chicken-syntax.scm:970: c */
t7=((C_word*)t0)[10];{
C_word av2[4];
av2[0]=t7;
av2[1]=t5;
av2[2]=((C_word*)t0)[7];
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t5=C_a_i_list(&a,3,((C_word*)t0)[11],((C_word*)t0)[12],((C_word*)t0)[8]);
t6=t4;
f_5807(t6,C_a_i_list(&a,1,t5));}}
else{
t5=t4;
f_5807(t5,C_SCHEME_END_OF_LIST);}}

/* k5397 in k5354 in k5351 in loop in k5334 in k5331 in k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_5399(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5399,2,av);}
/* chicken-syntax.scm:1027: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4504 in k4492 in loop2280 in k4476 in k4470 in k4467 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in ... */
static void C_fcall f_4506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_4506,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1210: ##sys#+ */
t5=*((C_word*)lf[56]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=C_fix(-1);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* map-loop2422 in k4030 in k4107 in k3925 in k3922 in loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in ... */
static void C_fcall f_4067(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_4067,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4092,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[18]+1);
/* chicken-syntax.scm:1248: g2445 */
t6=*((C_word*)lf[18]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[34];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4063 in k4030 in k4107 in k3925 in k3922 in loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in ... */
static void C_ccall f_4065(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_4065,2,av);}
a=C_alloc(12);
t2=C_a_i_list2(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_list1(&a,1,t3);
/* chicken-syntax.scm:1242: ##sys#append */
t5=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[5];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k5360 in k5354 in k5351 in loop in k5334 in k5331 in k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_5362(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_5362,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1027: ##sys#append */
t4=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k4030 in k4107 in k3925 in k3922 in loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in ... */
static void C_ccall f_4032(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,3))){C_save_and_reclaim((void *)f_4032,2,av);}
a=C_alloc(19);
t2=t1;
t3=(C_truep(((C_word*)t0)[2])?C_i_pairp(((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4065,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4067,a[2]=t6,a[3]=t11,a[4]=t7,a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_4067(t13,t9,((C_word*)t0)[2]);}
else{
t4=C_a_i_list1(&a,1,((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=C_a_i_list1(&a,1,t5);
/* chicken-syntax.scm:1242: ##sys#append */
t7=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[5];
av2[2]=t2;
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}

/* make-if-tree in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in ... */
static void C_fcall f_7341(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,5))){
C_save_and_reclaim_args((void *)trf_7341,6,t0,t1,t2,t3,t4,t5);}
a=C_alloc(9);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7347,a[2]=t4,a[3]=t5,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=((C_word)li61),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_7347(t9,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* recur in make-if-tree in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in ... */
static void C_fcall f_7347(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(18,0,2))){
C_save_and_reclaim_args((void *)trf_7347,5,t0,t1,t2,t3,t4);}
a=C_alloc(18);
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7361,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:643: reverse */
t6=*((C_word*)lf[43]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=C_i_car(t2);
t6=t5;
t7=C_a_i_list(&a,2,lf[173],((C_word*)t0)[3]);
t8=t7;
t9=C_i_car(t3);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7427,a[2]=t10,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t1,a[6]=t8,a[7]=t2,a[8]=t3,a[9]=t4,a[10]=((C_word*)t0)[4],a[11]=((C_word*)t0)[5],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:646: reverse */
t12=*((C_word*)lf[43]+1);{
C_word av2[3];
av2[0]=t12;
av2[1]=t11;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}}

/* k4568 in k4552 in a4549 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_4570(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_4570,2,av);}
a=C_alloc(12);
t2=C_i_caddr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,4,lf[38],t1,C_SCHEME_TRUE,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4590 in a4587 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_ccall f_4592(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4592,2,av);}
a=C_alloc(4);
if(C_truep(C_i_memq(lf[13],*((C_word*)lf[14]+1)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_caddr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1184: ##sys#strip-syntax */
t4=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[68];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_ccall f_7473(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,3))){C_save_and_reclaim((void *)f_7473,2,av);}
a=C_alloc(23);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7573,a[2]=t5,a[3]=t9,a[4]=t6,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_7573(t11,t7,((C_word*)t0)[9]);}

/* k11010 in k11022 in k10996 in k10993 in k10990 in mapslots in k11138 in k11164 in k10949 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_11012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_11012,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_7479(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_7479,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:666: r */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[188];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k11022 in k10996 in k10993 in k10990 in mapslots in k11138 in k11164 in k10949 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_11024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_11024,2,av);}
a=C_alloc(7);
t2=C_a_i_cons(&a,2,lf[26],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11012,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* chicken-syntax.scm:118: mapslots */
t7=((C_word*)((C_word*)t0)[5])[1];
f_10976(t7,t4,t5,t6);}

/* k9151 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_ccall f_9153(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,4))){C_save_and_reclaim((void *)f_9153,2,av);}
a=C_alloc(24);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t8=C_i_check_list_2(((C_word*)t0)[3],lf[28]);
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9170,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[2],tmp=(C_word)a,a+=11,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9505,a[2]=t5,a[3]=t11,a[4]=t6,a[5]=((C_word)li117),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_9505(t13,t9,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k11026 in k10996 in k10993 in k10990 in mapslots in k11138 in k11164 in k10949 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_fcall f_11028(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(66,0,3))){
C_save_and_reclaim_args((void *)trf_11028,2,t0,t1);}
a=C_alloc(66);
if(C_truep(((C_word*)t0)[2])){
t2=C_a_i_list(&a,1,lf[127]);
t3=C_a_i_list(&a,2,lf[116],((C_word*)t0)[3]);
t4=C_a_i_list(&a,3,lf[120],lf[127],t3);
t5=C_a_i_list(&a,2,lf[121],t4);
t6=C_a_i_list(&a,3,lf[122],lf[127],((C_word*)t0)[4]);
t7=C_a_i_list(&a,4,lf[101],t2,t5,t6);
t8=C_a_i_list(&a,3,((C_word*)t0)[5],t7,((C_word*)t0)[6]);
t9=C_a_i_list(&a,3,((C_word*)t0)[7],((C_word*)t0)[8],t8);
t10=C_a_i_list(&a,1,t9);
/* chicken-syntax.scm:43: ##sys#append */
t11=*((C_word*)lf[41]+1);{
C_word av2[4];
av2[0]=t11;
av2[1]=((C_word*)t0)[9];
av2[2]=t1;
av2[3]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}
else{
t2=C_a_i_list(&a,1,lf[127]);
t3=C_a_i_list(&a,2,lf[116],((C_word*)t0)[3]);
t4=C_a_i_list(&a,3,lf[120],lf[127],t3);
t5=C_a_i_list(&a,2,lf[121],t4);
t6=C_a_i_list(&a,3,lf[122],lf[127],((C_word*)t0)[4]);
t7=C_a_i_list(&a,4,lf[101],t2,t5,t6);
t8=C_a_i_list(&a,3,((C_word*)t0)[7],((C_word*)t0)[8],t7);
t9=C_a_i_list(&a,1,t8);
/* chicken-syntax.scm:43: ##sys#append */
t10=*((C_word*)lf[41]+1);{
C_word av2[4];
av2[0]=t10;
av2[1]=((C_word*)t0)[9];
av2[2]=t1;
av2[3]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}}

/* k7465 in g1484 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_7467(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7467,2,av);}
/* chicken-syntax.scm:662: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7409 in k7417 in k7425 in recur in make-if-tree in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_7411(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,4))){C_save_and_reclaim((void *)f_7411,2,av);}
a=C_alloc(27);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
t4=C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7387,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=((C_word*)t0)[7];
t8=C_u_i_cdr(t7);
t9=((C_word*)t0)[8];
t10=C_u_i_cdr(t9);
t11=C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[10]);
/* chicken-syntax.scm:649: recur */
t12=((C_word*)((C_word*)t0)[11])[1];
f_7347(t12,t6,t8,t10,t11);}

/* k7417 in k7425 in recur in make-if-tree in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_ccall f_7419(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,2))){C_save_and_reclaim((void *)f_7419,2,av);}
a=C_alloc(24);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7411,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:648: r */
t6=((C_word*)t0)[11];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[155];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_ccall f_9140(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,4))){C_save_and_reclaim((void *)f_9140,2,av);}
a=C_alloc(24);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9153,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[2],tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9553,a[2]=t5,a[3]=t10,a[4]=t6,a[5]=((C_word)li118),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_9553(t12,t8,((C_word*)t0)[2],((C_word*)t0)[10]);}

/* k4584 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_4586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4586,2,av);}
/* chicken-syntax.scm:1177: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[62];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a4587 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_4588(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_4588,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4592,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1181: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[62];
av2[3]=t2;
av2[4]=lf[69];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k9135 in g656 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_ccall f_9137(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9137,2,av);}
/* chicken-syntax.scm:289: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in ... */
static void C_ccall f_7430(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_7430,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:654: ##sys#check-syntax */
t3=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[180];
av2[3]=((C_word*)t0)[5];
av2[4]=lf[189];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in ... */
static void C_ccall f_7433(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,3))){C_save_and_reclaim((void *)f_7433,2,av);}
a=C_alloc(21);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7442,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7641,a[2]=t4,a[3]=t9,a[4]=t5,a[5]=((C_word)li70),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_7641(t11,t7,((C_word*)t0)[2]);}

/* k9120 in g628 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_ccall f_9122(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9122,2,av);}
/* chicken-syntax.scm:288: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9125(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(29,c,3))){C_save_and_reclaim((void *)f_9125,2,av);}
a=C_alloc(29);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9129,a[2]=((C_word*)t0)[2],a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9140,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9601,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=t6,a[6]=((C_word)li119),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_9601(t12,t8,((C_word*)t0)[10]);}

/* g656 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_fcall f_9129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_9129,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9137,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:289: gensym */
t3=*((C_word*)lf[32]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[176];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7425 in recur in make-if-tree in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in ... */
static void C_ccall f_7427(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_7427,2,av);}
a=C_alloc(15);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7419,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:647: r */
t5=((C_word*)t0)[11];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[154];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9110(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(29,c,3))){C_save_and_reclaim((void *)f_9110,2,av);}
a=C_alloc(29);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9114,a[2]=((C_word*)t0)[2],a[3]=((C_word)li110),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9125,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9635,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=t6,a[6]=((C_word)li120),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_9635(t12,t8,((C_word*)t0)[9]);}

/* g628 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_9114(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_9114,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9122,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:288: gensym */
t3=*((C_word*)lf[32]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[237];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8545 in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_ccall f_8547(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,3))){C_save_and_reclaim((void *)f_8547,2,av);}
a=C_alloc(21);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8713,a[2]=t5,a[3]=t9,a[4]=t6,a[5]=((C_word)li97),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_8713(t11,t7,((C_word*)t0)[7]);}

/* k9102 in g600 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9104(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9104,2,av);}
/* chicken-syntax.scm:287: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4026 in k4107 in k3925 in k3922 in loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in ... */
static void C_ccall f_4028(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4028,2,av);}
/* chicken-syntax.scm:1240: ##sys#put! */
t2=*((C_word*)lf[39]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[40];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3824 in k3762 in k3759 in k3753 in a3750 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in ... */
static void C_ccall f_3826(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,1))){C_save_and_reclaim((void *)f_3826,2,av);}
a=C_alloc(18);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,lf[29],t3);
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* map-loop2514 in k3762 in k3759 in k3753 in a3750 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in ... */
static void C_fcall f_3828(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3828,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3853,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:1290: g2520 */
t5=((C_word*)t0)[4];
f_3788(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k8523 in g1006 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_ccall f_8525(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_8525,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k8527 in g1006 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_ccall f_8529(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_8529,2,av);}
/* chicken-syntax.scm:381: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_ccall f_8535(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,4))){C_save_and_reclaim((void *)f_8535,2,av);}
a=C_alloc(20);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8536,a[2]=t2,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8547,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8747,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=t3,a[5]=((C_word)li98),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_8747(t8,t4,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k10097 in k9929 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(36,c,4))){C_save_and_reclaim((void *)f_10099,2,av);}
a=C_alloc(36);
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[101],t2);
t4=t3;
t5=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t6=C_a_i_cons(&a,2,lf[101],t5);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9955,a[2]=t4,a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t9=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t11)[1];
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9967,a[2]=t8,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10041,a[2]=t11,a[3]=t15,a[4]=t12,a[5]=((C_word)li130),tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_10041(t17,t13,((C_word*)t0)[7],((C_word*)t0)[5]);}

/* lookup in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_ccall f_8536(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_8536,3,av);}
t3=C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_i_cdr(t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k10566 in k10543 in k10531 in a10528 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_10568(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(24,0,1))){
C_save_and_reclaim_args((void *)trf_10568,2,t0,t1);}
a=C_alloc(24);
t2=C_a_i_cons(&a,2,lf[257],t1);
t3=C_a_i_list(&a,4,lf[159],((C_word*)t0)[2],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k3851 in map-loop2514 in k3762 in k3759 in k3753 in a3750 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in ... */
static void C_ccall f_3853(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3853,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3828(t6,((C_word*)t0)[5],t5);}

/* a7959 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_ccall f_7960(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_7960,5,av);}
a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7962,a[2]=t4,a[3]=t3,a[4]=((C_word)li78),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8050,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_i_cdr(t2);
/* chicken-syntax.scm:473: quotify-proc */
t8=t5;
f_7962(t8,t6,t7,lf[205]);}

/* quotify-proc1286 in a7959 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_fcall f_7962(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,4))){
C_save_and_reclaim_args((void *)trf_7962,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7966,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:460: ##sys#check-syntax */
t5=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
av2[3]=t2;
av2[4]=lf[208];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k7964 in quotify-proc1286 in a7959 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in ... */
static void C_ccall f_7966(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_7966,2,av);}
a=C_alloc(12);
t2=C_i_car(((C_word*)t0)[2]);
t3=C_i_pairp(t2);
t4=(C_truep(t3)?C_u_i_car(t2):t2);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7975,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t2))){
t7=C_u_i_cdr(t2);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
t10=C_a_i_cons(&a,2,t7,t9);
t11=t6;
f_7975(t11,C_a_i_cons(&a,2,lf[101],t10));}
else{
t7=t6;
f_7975(t7,C_i_cadr(((C_word*)t0)[2]));}}

/* k9795 in k9792 in k9789 in k9786 in k9777 in a9774 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9797(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_9797,2,av);}
a=C_alloc(6);
if(C_truep(C_i_memq(lf[13],*((C_word*)lf[14]+1)))){
t2=(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)((C_word*)t0)[3])[1]:C_SCHEME_FALSE);
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=(C_truep(t2)?C_a_i_list(&a,2,lf[244],((C_word*)t0)[5]):(C_truep(((C_word*)((C_word*)t0)[2])[1])?C_a_i_list(&a,2,lf[245],((C_word*)t0)[5]):(C_truep(((C_word*)((C_word*)t0)[3])[1])?((C_word*)t0)[5]:lf[246])));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)t0)[5]:lf[247]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k9792 in k9789 in k9786 in k9777 in a9774 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9794(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,3))){C_save_and_reclaim((void *)f_9794,2,av);}
a=C_alloc(26);
t2=t1;
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9797,a[2]=t6,a[3]=t8,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9826,a[2]=t11,a[3]=t4,a[4]=t8,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=((C_word*)t0)[6],a[10]=((C_word)li125),tmp=(C_word)a,a+=11,tmp));
t13=((C_word*)t11)[1];
f_9826(t13,t9,((C_word*)t0)[7]);}

/* k9789 in k9786 in k9777 in a9774 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9791(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_9791,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:250: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[250];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k10543 in k10531 in a10528 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10545(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(57,c,2))){C_save_and_reclaim((void *)f_10545,2,av);}
a=C_alloc(57);
t2=t1;
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[2]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t7=C_a_i_list(&a,2,lf[121],t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10568,a[2]=t8,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t10=t9;
f_10568(t10,C_a_i_cons(&a,2,lf[258],((C_word*)t0)[5]));}
else{
t10=C_a_i_list(&a,2,lf[116],lf[259]);
t11=C_a_i_list(&a,2,lf[260],t10);
t12=C_a_i_list(&a,2,lf[116],((C_word*)t0)[3]);
t13=C_a_i_list(&a,3,t11,t2,t12);
t14=t9;
f_10568(t14,C_a_i_cons(&a,2,lf[258],t13));}}

/* k4552 in a4549 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_ccall f_4554(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_4554,2,av);}
a=C_alloc(4);
if(C_truep(C_i_memq(lf[13],*((C_word*)lf[14]+1)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1204: ##compiler#check-and-validate-type */
t4=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=lf[52];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_caddr(((C_word*)t0)[2]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a4549 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_ccall f_4550(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_4550,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4554,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1201: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[52];
av2[3]=t2;
av2[4]=lf[61];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_3874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_3874,5,av);}
a=C_alloc(5);
if(C_truep(C_i_memq(lf[13],*((C_word*)lf[14]+1)))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3884,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1220: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[34];
av2[3]=t2;
av2[4]=lf[49];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=lf[50];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k3870 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_3872(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3872,2,av);}
/* chicken-syntax.scm:1214: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[34];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k9786 in k9777 in a9774 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9788(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_9788,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:249: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[251];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_ccall f_3884(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_3884,2,av);}
a=C_alloc(7);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_car(t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3893,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1223: ##sys#globalize */
t7=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t5;
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k7985 in k7973 in k7964 in quotify-proc1286 in a7959 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_fcall f_7987(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,5))){
C_save_and_reclaim_args((void *)trf_7987,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
/* chicken-syntax.scm:469: syntax-error */
t2=*((C_word*)lf[45]+1);{
C_word av2[6];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[205];
av2[3]=lf[206];
av2[4]=((C_word*)t0)[3];
av2[5]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_a_i_list2(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k9777 in a9774 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9779(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_9779,2,av);}
a=C_alloc(10);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,lf[26],t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9788,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:248: r */
t10=((C_word*)t0)[5];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[252];
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* a9774 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9775(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_9775,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9779,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:245: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[243];
av2[3]=t2;
av2[4]=lf[253];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k9771 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9773(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_9773,2,av);}
/* chicken-syntax.scm:241: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[243];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop420 in k10097 in k9929 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_10041(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_10041,4,t0,t1,t2,t3);}
a=C_alloc(12);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,3,lf[239],t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in ... */
static void C_ccall f_3897(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_3897,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3900,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:1226: ##sys#globalize */
t4=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in ... */
static void C_ccall f_3893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_3893,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3897,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:1225: gensym */
t5=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6816 in build in a6688 in k6671 in k6661 in a6658 in a6648 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in ... */
static void C_ccall f_6818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(34,c,3))){C_save_and_reclaim((void *)f_6818,2,av);}
a=C_alloc(34);
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t4=C_a_i_list(&a,2,t2,t3);
t5=C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t6=C_a_i_list(&a,2,t1,t5);
t7=C_a_i_list(&a,2,t4,t6);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6829,a[2]=((C_word*)t0)[6],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
if(C_truep(C_i_pairp(t11))){
t12=((C_word*)t0)[2];
t13=C_u_i_cdr(t12);
/* chicken-syntax.scm:814: build */
t14=((C_word*)((C_word*)t0)[7])[1];
f_6765(t14,t9,t13,t1);}
else{
/* chicken-syntax.scm:815: build */
t12=((C_word*)((C_word*)t0)[7])[1];
f_6765(t12,t9,C_SCHEME_END_OF_LIST,t1);}}

/* k4090 in map-loop2422 in k4030 in k4107 in k3925 in k3922 in loop in k3904 in k3901 in k3898 in k3895 in k3891 in k3882 in a3873 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in ... */
static void C_ccall f_4092(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4092,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4067(t6,((C_word*)t0)[5],t5);}

/* k7920 in fold in k7865 in a7862 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_ccall f_7922(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_7922,2,av);}
a=C_alloc(14);
t2=C_u_i_car(((C_word*)t0)[2]);
t3=C_i_cadr(((C_word*)t0)[2]);
t4=C_a_i_list(&a,2,t2,t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7938,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:493: fold */
t8=((C_word*)((C_word*)t0)[4])[1];
f_7877(t8,t7,((C_word*)t0)[5]);}

/* map-loop314 in k10258 in k10251 in k10242 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_10271(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_10271,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k4546 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in ... */
static void C_ccall f_4548(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4548,2,av);}
/* chicken-syntax.scm:1197: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[52];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7708 in k7705 in k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_ccall f_7710(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_7710,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:504: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[200];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7711 in k7708 in k7705 in k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in ... */
static void C_ccall f_7713(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,4))){C_save_and_reclaim((void *)f_7713,2,av);}
a=C_alloc(23);
t2=t1;
t3=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7724,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7726,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li74),tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_7726(t10,t6,((C_word*)t0)[7],C_SCHEME_FALSE);}

/* k7956 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_ccall f_7958(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_7958,2,av);}
/* chicken-syntax.scm:454: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[205];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k9692 in map-loop594 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_9694,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9669(t6,((C_word*)t0)[5],t5);}

/* k7705 in k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_ccall f_7707(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_7707,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7710,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:503: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[27];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k8897 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8899(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8899,2,av);}
/* chicken-syntax.scm:341: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[222];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* map-loop540 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_9737(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_9737,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9658 in map-loop622 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_ccall f_9660(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_9660,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9635(t6,((C_word*)t0)[5],t5);}

/* g1057 in fold in k8560 in k8545 in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_fcall f_8583(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_8583,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8591,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:396: lookup */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
f_8536(3,av2);}}

/* k7976 in k7973 in k7964 in quotify-proc1286 in a7959 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_ccall f_7978(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_7978,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list2(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7973 in k7964 in quotify-proc1286 in a7959 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in ... */
static void C_fcall f_7975(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(19,0,2))){
C_save_and_reclaim_args((void *)trf_7975,2,t0,t1);}
a=C_alloc(19);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_i_pairp(t2);
t5=C_i_not(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7987,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_7987(t7,t5);}
else{
t7=C_i_car(t2);
t8=C_eqp(lf[101],t7);
if(C_truep(t8)){
t9=t6;
f_7987(t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8003,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8007,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:468: r */
t11=((C_word*)t0)[5];{
C_word av2[3];
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[207];
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}}}

/* expand in k7711 in k7708 in k7705 in k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in ... */
static void C_fcall f_7726(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(11,0,4))){
C_save_and_reclaim_args((void *)trf_7726,4,t0,t1,t2,t3);}
a=C_alloc(11);
if(C_truep(C_i_nullp(t2))){
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=lf[193];
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_slot(t2,C_fix(0));
t5=t4;
t6=C_slot(t2,C_fix(1));
t7=t6;
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7751,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t3,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:515: ##sys#check-syntax */
t9=*((C_word*)lf[22]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=t8;
av2[2]=lf[192];
av2[3]=t5;
av2[4]=lf[198];
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
/* chicken-syntax.scm:511: syntax-error */
t4=*((C_word*)lf[45]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[192];
av2[3]=lf[199];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}}

/* k7722 in k7711 in k7708 in k7705 in k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in ... */
static void C_ccall f_7724(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_7724,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8513(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,3))){C_save_and_reclaim((void *)f_8513,2,av);}
a=C_alloc(26);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8517,a[2]=((C_word*)t0)[2],a[3]=((C_word)li92),tmp=(C_word)a,a+=4,tmp);
t8=C_i_check_list_2(t2,lf[28]);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8535,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8791,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,a[6]=((C_word)li99),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_8791(t13,t9,t2);}

/* k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8510(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,4))){C_save_and_reclaim((void *)f_8510,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8825,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word)li100),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_8825(t7,t3,t2,C_SCHEME_END_OF_LIST);}

/* g1006 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_fcall f_8517(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_8517,3,t0,t1,t2);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8525,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8529,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:381: gensym */
t5=*((C_word*)lf[32]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* map-loop594 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_9669(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_9669,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9694,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:287: g600 */
t5=((C_word*)t0)[4];
f_9096(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6691 in a6688 in k6671 in k6661 in a6658 in a6648 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in ... */
static void C_ccall f_6693(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,4))){C_save_and_reclaim((void *)f_6693,2,av);}
a=C_alloc(17);
t2=t1;
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)t0)[2];
t8=C_i_check_list_2(t7,lf[28]);
t9=C_i_check_list_2(((C_word*)t0)[4],lf[28]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6715,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6717,a[2]=t5,a[3]=t12,a[4]=t6,a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_6717(t14,t10,t7,((C_word*)t0)[4]);}}

/* k8560 in k8545 in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in ... */
static void C_ccall f_8562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,5))){C_save_and_reclaim((void *)f_8562,2,av);}
a=C_alloc(9);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word)li96),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_8564(t5,((C_word*)t0)[5],((C_word*)t0)[6],t1,((C_word*)t0)[7]);}

/* fold in k8560 in k8545 in k8533 in k8511 in k8508 in k8426 in a8423 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in ... */
static void C_fcall f_8564(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(22,0,3))){
C_save_and_reclaim_args((void *)trf_8564,5,t0,t1,t2,t3,t4);}
a=C_alloc(22);
if(C_truep(C_i_nullp(t2))){
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8583,a[2]=((C_word*)t0)[2],a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp);
t10=C_i_check_list_2(((C_word*)t0)[3],lf[28]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8597,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8599,a[2]=t7,a[3]=t13,a[4]=t9,a[5]=t8,a[6]=((C_word)li95),tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_8599(t15,t11,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8637,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(t4);
if(C_truep(C_i_pairp(t6))){
t7=C_i_cdar(t4);
t8=t5;
f_8637(t8,C_i_nullp(t7));}
else{
t7=t5;
f_8637(t7,C_SCHEME_FALSE);}}}

/* map-loop456 in k9965 in k10097 in k9929 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_9993(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_9993,4,t0,t1,t2,t3);}
a=C_alloc(12);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,3,lf[239],t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3561(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3561,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10527,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10529,a[2]=((C_word)li141),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:191: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k9981 in k9965 in k10097 in k9929 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_9983,2,av);}
a=C_alloc(6);
t2=C_a_i_list(&a,1,lf[231]);
t3=C_a_i_list(&a,1,t2);
/* chicken-syntax.scm:214: ##sys#append */
t4=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3570(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3570,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9042,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9044,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:273: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3573,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9018,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9020,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:318: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3564(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3564,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9874,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9876,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:211: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* a10528 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10529(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_10529,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10533,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:193: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[256];
av2[3]=t2;
av2[4]=lf[261];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3567(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3567,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9773,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9775,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:243: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10525 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10527,2,av);}
/* chicken-syntax.scm:188: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[256];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3582(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3582,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8899,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8901,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:343: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7936 in k7920 in fold in k7865 in a7862 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_ccall f_7938(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,1))){C_save_and_reclaim((void *)f_7938,2,av);}
a=C_alloc(21);
t2=C_a_i_list(&a,4,lf[159],((C_word*)t0)[2],t1,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[30],((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* map-loop622 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_9635(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_9635,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9660,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:288: g628 */
t4=((C_word*)t0)[4];
f_9114(t4,t3);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k9969 in k9965 in k10097 in k9929 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9971(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_9971,2,av);}
/* chicken-syntax.scm:214: ##sys#append */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3576(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3576,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8990,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8992,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:326: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3579(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3579,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8969,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8971,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:335: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k9965 in k10097 in k9929 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9967(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(20,c,4))){C_save_and_reclaim((void *)f_9967,2,av);}
a=C_alloc(20);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9971,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9983,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9993,a[2]=t6,a[3]=t10,a[4]=t7,a[5]=((C_word)li129),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_9993(t12,t8,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3592(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3592,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8110,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8112,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:426: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k9624 in map-loop650 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_ccall f_9626(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_9626,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9601(t6,((C_word*)t0)[5],t5);}

/* k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3586,2,av);}
a=C_alloc(10);
t2=C_mutate2((C_word*)lf[0]+1 /* (set! ##sys#define-values-definition ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8422,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8424,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:357: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3589(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3589,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8368,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8370,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:411: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7791 in k7809 in k7755 in k7749 in expand in k7711 in k7708 in k7705 in k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_7793(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_7793,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,4,lf[159],((C_word*)t0)[3],((C_word*)t0)[4],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k9953 in k10097 in k9929 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9955(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,1))){C_save_and_reclaim((void *)f_9955,2,av);}
a=C_alloc(27);
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[101],t2);
t4=C_a_i_list(&a,4,lf[238],((C_word*)t0)[2],((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k6503 in k6489 in a6486 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in ... */
static void C_ccall f_6505(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(21,c,1))){C_save_and_reclaim((void *)f_6505,2,av);}
a=C_alloc(21);
t2=C_slot(((C_word*)t0)[2],C_fix(0));
t3=C_a_i_list(&a,2,lf[20],t2);
t4=C_slot(((C_word*)t0)[2],C_fix(1));
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=C_a_i_cons(&a,2,lf[101],t5);
t7=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_a_i_list(&a,3,lf[149],t3,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k8156 in k8134 in k8128 in k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in ... */
static void C_ccall f_8158(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_8158,2,av);}
a=C_alloc(14);
t2=C_i_check_list_2(t1,lf[28]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8228,a[2]=((C_word*)t0)[6],a[3]=t5,a[4]=((C_word*)t0)[7],a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_8228(t7,t3,t1);}

/* k10267 in k10258 in k10251 in k10242 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10269(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_10269,2,av);}
/* chicken-syntax.scm:214: ##sys#append */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k10258 in k10251 in k10242 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10260(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_10260,2,av);}
a=C_alloc(12);
t2=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t3=C_i_check_list_2(t1,lf[28]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10269,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10271,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=((C_word*)t0)[6],a[5]=((C_word)li133),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_10271(t8,t4,((C_word*)t0)[2],t1);}

/* k6864 in build in a6688 in k6671 in k6661 in a6658 in a6648 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in ... */
static void C_ccall f_6866(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6866,2,av);}
/* chicken-syntax.scm:810: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3595(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3595,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8106,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:445: ##sys#primitive-alias */
t4=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[210];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3598(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3598,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7958,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7960,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:456: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k10531 in a10528 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_10533,2,av);}
a=C_alloc(6);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=C_i_caddr(((C_word*)t0)[2]);
t5=t4;
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_u_i_cdr(t8);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10545,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:197: r */
t11=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=lf[176];
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}

/* k10251 in k10242 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10253(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_10253,2,av);}
a=C_alloc(18);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=((C_word*)t0)[2];
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10260,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t5,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t9=C_u_i_length(((C_word*)t0)[4]);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10321,a[2]=t11,a[3]=((C_word)li134),tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_10321(t13,t8,t9);}

/* k6475 in k6479 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in ... */
static void C_ccall f_6477(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,5))){C_save_and_reclaim((void *)f_6477,2,av);}
a=C_alloc(16);
t2=C_a_i_cons(&a,2,lf[141],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6366,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6368,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:851: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k3731 in k3708 in k3705 in k3702 in k3693 in a3690 in k3674 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in ... */
static void C_ccall f_3733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,1))){C_save_and_reclaim((void *)f_3733,2,av);}
a=C_alloc(24);
t2=C_a_i_list(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list(&a,4,lf[16],((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,2,lf[17],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k6489 in a6486 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in ... */
static void C_ccall f_6491(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_6491,2,av);}
a=C_alloc(8);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
if(C_truep(C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6505,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=C_a_i_cons(&a,2,t3,t6);
/* chicken-syntax.scm:834: ##sys#check-syntax */
t9=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t9;
av2[1]=t7;
av2[2]=lf[148];
av2[3]=t8;
av2[4]=lf[150];
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6535,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=C_a_i_cons(&a,2,t3,t6);
/* chicken-syntax.scm:841: ##sys#check-syntax */
t9=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t9;
av2[1]=t7;
av2[2]=lf[148];
av2[3]=t8;
av2[4]=lf[151];
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}}

/* k8128 in k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_ccall f_8130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_8130,2,av);}
a=C_alloc(18);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8136,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8298,a[2]=t5,a[3]=t9,a[4]=t6,a[5]=((C_word)li85),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_8298(t11,t7,((C_word*)t0)[4]);}

/* k8134 in k8128 in k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_ccall f_8136(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,4))){C_save_and_reclaim((void *)f_8136,2,av);}
a=C_alloc(19);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_check_list_2(((C_word*)t0)[2],lf[214]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8158,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8262,a[2]=t10,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_8262(t12,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10242 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_10244(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,4))){C_save_and_reclaim((void *)f_10244,2,av);}
a=C_alloc(13);
t2=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t3=C_i_check_list_2(t1,lf[28]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10253,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10341,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[7],a[5]=((C_word)li135),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_10341(t8,t4,((C_word*)t0)[2],t1);}

/* k9929 in k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9931(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(26,c,4))){C_save_and_reclaim((void *)f_9931,2,av);}
a=C_alloc(26);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_i_check_list_2(((C_word*)t0)[4],lf[28]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10114,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10188,a[2]=t6,a[3]=t11,a[4]=t7,a[5]=((C_word)li132),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_10188(t13,t9,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k6479 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in ... */
static void C_ccall f_6481(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_6481,2,av);}
a=C_alloc(7);
t2=C_a_i_cons(&a,2,lf[140],t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6477,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:850: ##sys#primitive-alias */
t5=*((C_word*)lf[110]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[141];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k9922 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9924(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(33,c,3))){C_save_and_reclaim((void *)f_9924,2,av);}
a=C_alloc(33);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=((C_word*)t0)[5];
t9=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=((C_word*)t11)[1];
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10244,a[2]=t8,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=t6,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10389,a[2]=t11,a[3]=t15,a[4]=t12,a[5]=((C_word)li136),tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_10389(t17,t13,((C_word*)t0)[6]);}

/* k8104 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8106(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,5))){C_save_and_reclaim((void *)f_8106,2,av);}
a=C_alloc(13);
t2=C_a_i_cons(&a,2,lf[210],t1);
t3=C_a_i_list(&a,1,t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8062,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8064,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:446: ##sys#er-transformer */
t7=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k3753 in a3750 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in ... */
static void C_ccall f_3755(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3755,2,av);}
a=C_alloc(5);
t2=C_i_memq(lf[13],*((C_word*)lf[14]+1));
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3761,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1284: gensym */
t5=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k9919 in g233 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9921(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9921,2,av);}
/* chicken-syntax.scm:218: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a3750 in k3671 in k3668 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_ccall f_3751(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_3751,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3755,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1282: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[25];
av2[3]=t2;
av2[4]=lf[33];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* g1927 in k5740 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static C_word C_fcall f_5984(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
if(C_truep(C_i_memq(t1,((C_word*)t0)[2]))){
t2=t1;
return(t2);}
else{
return(lf[117]);}}

/* k7749 in expand in k7711 in k7708 in k7705 in k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in ... */
static void C_ccall f_7751(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_7751,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* chicken-syntax.scm:516: c */
t4=((C_word*)t0)[9];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[10];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k7755 in k7749 in expand in k7711 in k7708 in k7705 in k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in ... */
static void C_ccall f_7757(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,3))){C_save_and_reclaim((void *)f_7757,2,av);}
a=C_alloc(25);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:517: expand */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7726(t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
if(C_truep(((C_word*)t0)[6])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7778,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:522: ##sys#strip-syntax */
t4=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7800,a[2]=((C_word*)t0)[7],a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
t7=C_u_i_car(((C_word*)t0)[2]);
t8=C_i_check_list_2(t7,lf[28]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7811,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7813,a[2]=t6,a[3]=t4,a[4]=t11,a[5]=t5,a[6]=((C_word)li73),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_7813(t13,t9,t7);}}}

/* k8060 in k8104 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_ccall f_8062(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8062,2,av);}
/* chicken-syntax.scm:443: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[211];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a8063 in k8104 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_ccall f_8064(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_8064,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8068,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:448: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[211];
av2[3]=t2;
av2[4]=lf[212];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k8066 in a8063 in k8104 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_ccall f_8068(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_8068,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:449: r */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[176];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k8108 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8110(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_8110,2,av);}
/* chicken-syntax.scm:424: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[213];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8112(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_8112,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8116,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:428: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[213];
av2[3]=t2;
av2[4]=lf[217];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8116(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_8116,2,av);}
a=C_alloc(18);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=C_i_check_list_2(t3,lf[28]);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8130,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8332,a[2]=t9,a[3]=t14,a[4]=t10,a[5]=((C_word)li86),tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_8332(t16,t12,t3);}

/* k6483 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in ... */
static void C_ccall f_6485(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6485,2,av);}
/* chicken-syntax.scm:826: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[148];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a6486 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in ... */
static void C_ccall f_6487(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_6487,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6491,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:830: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[148];
av2[3]=t2;
av2[4]=lf[152];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k5995 in k5740 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_ccall f_5997(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(!C_demand(C_calculate_demand(62,c,4))){C_save_and_reclaim((void *)f_5997,2,av);}
a=C_alloc(62);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[118],t2);
t4=C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t3);
t5=t4;
t6=C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t7=C_a_i_list(&a,2,lf[116],((C_word*)t0)[7]);
t8=C_a_i_list(&a,3,lf[119],((C_word*)t0)[6],t7);
t9=C_a_i_list(&a,3,((C_word*)t0)[3],t6,t8);
t10=t9;
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5765,a[2]=t10,a[3]=t5,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5767,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t13,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word)li36),tmp=(C_word)a,a+=10,tmp));
t15=((C_word*)t13)[1];
f_5767(t15,t11,((C_word*)t0)[12],C_fix(1));}

/* map-loop1921 in k5740 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_fcall f_5999(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_5999,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_5984(((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* loop in genvars in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_fcall f_6572(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_6572,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6586,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6598,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:771: gensym */
t5=*((C_word*)lf[32]+1);{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k6313 in map-loop1839 in k6232 in k6100 in k6097 in k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_6315(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6315,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6290(t6,((C_word*)t0)[5],t5);}

/* k7769 in k7755 in k7749 in expand in k7711 in k7708 in k7705 in k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_ccall f_7771(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_7771,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7774,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:523: expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7726(t3,t2,((C_word*)t0)[4],C_SCHEME_TRUE);}

/* k6827 in k6816 in build in a6688 in k6671 in k6661 in a6658 in a6648 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in ... */
static void C_ccall f_6829(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_6829,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7772 in k7769 in k7755 in k7749 in expand in k7711 in k7708 in k7705 in k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_7774(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_7774,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[194];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7776 in k7755 in k7749 in expand in k7711 in k7708 in k7705 in k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_ccall f_7778(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7778,2,av);}
/* chicken-syntax.scm:520: ##sys#notice */
t2=*((C_word*)lf[195]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[196];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k7758 in k7755 in k7749 in expand in k7711 in k7708 in k7705 in k7697 in a7694 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in ... */
static void C_ccall f_7760(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_7760,2,av);}
a=C_alloc(3);
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[26],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k8048 in a7959 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in ... */
static void C_ccall f_8050(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_8050,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,lf[209],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6556 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_6558(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6558,2,av);}
/* chicken-syntax.scm:757: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[158];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6584 in loop in genvars in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_6586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6586,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6590,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm:771: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6572(t5,t3,t4);}

/* k6533 in k6489 in a6486 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in ... */
static void C_ccall f_6535(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_6535,2,av);}
a=C_alloc(12);
t2=C_a_i_list(&a,2,lf[20],((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[149],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k8005 in k7973 in k7964 in quotify-proc1286 in a7959 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_ccall f_8007(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_8007,2,av);}
t2=C_u_i_car(((C_word*)t0)[2]);
/* chicken-syntax.scm:468: c */
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[4];
av2[2]=t1;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_ccall f_4241(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_4241,5,av);}
a=C_alloc(14);
t5=C_i_cdr(t2);
t6=t5;
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4251,a[2]=t6,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t7))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4413,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4469,a[2]=t7,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=C_i_car(t7);
/* chicken-syntax.scm:1210: ##sys#list? */
t12=*((C_word*)lf[60]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t12;
av2[1]=t10;
av2[2]=t11;
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
t9=t8;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t9;
av2[1]=C_SCHEME_FALSE;
f_4251(2,av2);}}}

/* k8001 in k7973 in k7964 in quotify-proc1286 in a7959 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_ccall f_8003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_8003,2,av);}
t2=((C_word*)t0)[2];
f_7987(t2,C_i_not(t1));}

/* k3538 in k3534 */
static void C_ccall f_3540(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3540,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3543,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11226,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11228,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:49: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k8380 in k8372 in a8369 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_8382(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_8382,2,av);}
a=C_alloc(8);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8387,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=((C_word)li88),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_8387(t6,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k4237 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_ccall f_4239(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4239,2,av);}
/* chicken-syntax.scm:1208: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[51];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* fold in k8380 in k8372 in a8369 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_fcall f_8387(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_8387,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,lf[30],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=C_i_car(t2);
t4=C_a_i_list(&a,1,t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8412,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=C_u_i_cdr(t7);
/* chicken-syntax.scm:421: fold */
t10=t6;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_6560(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_6560,5,av);}
a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6564,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:766: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[158];
av2[3]=t2;
av2[4]=lf[172];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* genvars in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in ... */
static void C_fcall f_6566(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_6566,3,t0,t1,t2);}
a=C_alloc(8);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6572,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li47),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_6572(t6,t1,C_fix(0));}

/* k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in ... */
static void C_ccall f_6564(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_6564,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6566,a[2]=((C_word*)t0)[2],a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:772: require */
t4=*((C_word*)lf[170]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[171];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6713 in k6691 in a6688 in k6671 in k6661 in a6658 in a6648 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in ... */
static void C_ccall f_6715(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_6715,2,av);}
a=C_alloc(9);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,3,lf[30],t1,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* map-loop1711 in k6691 in a6688 in k6671 in k6661 in a6658 in a6648 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in ... */
static void C_fcall f_6717(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_6717,4,t0,t1,t2,t3);}
a=C_alloc(9);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list2(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9);
t11=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t9);
t12=C_slot(t2,C_fix(1));
t13=C_slot(t3,C_fix(1));
t15=t1;
t16=t12;
t17=t13;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k3534 */
static void C_ccall f_3536(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3536,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3540,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:44: ##sys#macro-environment */
t3=*((C_word*)lf[293]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6268 in k6264 in k6257 in k6232 in k6100 in k6097 in k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_6270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,1))){C_save_and_reclaim((void *)f_6270,2,av);}
a=C_alloc(24);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t2);
t4=C_i_cadr(((C_word*)t0)[4]);
t5=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[7],t3,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3549(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3549,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10722,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10724,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:141: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3546(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3546,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10771,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10773,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:123: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3541 in k3538 in k3534 */
static void C_ccall f_3543(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3543,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10864,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10866,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:56: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6264 in k6257 in k6232 in k6100 in k6097 in k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_6266(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(23,c,3))){C_save_and_reclaim((void *)f_6266,2,av);}
a=C_alloc(23);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6270,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_assq(((C_word*)t0)[7],((C_word*)t0)[8]))){
/* chicken-syntax.scm:896: ##sys#append */
t4=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[8];
av2[3]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=C_a_i_list(&a,2,lf[133],((C_word*)t0)[6]);
t5=C_a_i_list(&a,2,((C_word*)t0)[7],t4);
t6=C_a_i_list(&a,1,t5);
/* chicken-syntax.scm:896: ##sys#append */
t7=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t3;
av2[2]=((C_word*)t0)[8];
av2[3]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}

/* k5139 in k5126 in k5102 in a5093 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_5141(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_5141,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,t1,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* map-loop567 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_9703(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_9703,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3558(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3558,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10602,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10604,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:168: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3555(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3555,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10691,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10693,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:161: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_3552(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,5))){C_save_and_reclaim((void *)f_3552,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10708,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10710,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:155: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k7917 in fold in k7865 in a7862 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_ccall f_7919(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_7919,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,4,lf[159],((C_word*)t0)[3],t1,C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7902 in fold in k7865 in a7862 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_ccall f_7904(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_7904,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list(&a,4,lf[159],((C_word*)t0)[3],t1,C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* build in a6688 in k6671 in k6661 in a6658 in a6648 in k6633 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6608 in k6605 in k6602 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in ... */
static void C_fcall f_6765(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(15,0,2))){
C_save_and_reclaim_args((void *)trf_6765,4,t0,t1,t2,t3);}
a=C_alloc(15);
if(C_truep(C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[2])){
t4=C_a_i_list(&a,2,((C_word*)t0)[2],t3);
t5=C_a_i_list(&a,1,t4);
t6=C_i_cdr(((C_word*)t0)[3]);
t7=C_a_i_cons(&a,2,t5,t6);
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=C_a_i_cons(&a,2,lf[30],t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t4=C_i_cddr(((C_word*)t0)[3]);
if(C_truep(C_i_nullp(t4))){
t5=((C_word*)t0)[3];
t6=C_u_i_cdr(t5);
t7=C_u_i_car(t6);
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t5=((C_word*)t0)[3];
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t6);
t8=t1;{
C_word av2[2];
av2[0]=t8;
av2[1]=C_a_i_cons(&a,2,lf[30],t7);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6818,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6866,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:810: gensym */
t6=*((C_word*)lf[32]+1);{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k6916 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_ccall f_6918(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6918,2,av);}{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=*((C_word*)lf[169]+1);
av2[3]=t1;
C_apply(4,av2);}}

/* k4249 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_4251(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_4251,2,av);}
a=C_alloc(18);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=C_i_car(((C_word*)t0)[2]);
t7=C_i_check_list_2(t6,lf[28]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4369,a[2]=t4,a[3]=t10,a[4]=t5,a[5]=((C_word)li11),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_4369(t12,t8,t6);}
else{
/* chicken-syntax.scm:1210: ##sys#syntax-rules-mismatch */
t2=*((C_word*)lf[55]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k6232 in k6100 in k6097 in k6094 in k6091 in k6088 in k6085 in a6082 in k6352 in k6356 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_ccall f_6234(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
if(!C_demand(C_calculate_demand(65,c,3))){C_save_and_reclaim((void *)f_6234,2,av);}
a=C_alloc(65);
t2=t1;
t3=C_a_i_list(&a,2,lf[116],lf[131]);
t4=C_a_i_list(&a,3,lf[119],((C_word*)t0)[2],t3);
t5=C_a_i_list(&a,3,lf[132],((C_word*)t0)[2],C_fix(1));
t6=C_a_i_list(&a,3,((C_word*)t0)[3],t4,t5);
t7=C_a_i_list(&a,2,((C_word*)t0)[4],t6);
t8=C_a_i_list(&a,1,t7);
t9=t8;
t10=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=((C_word*)t12)[1];
t14=((C_word*)t0)[5];
t15=C_i_cddr(((C_word*)t0)[6]);
t16=C_i_check_list_2(t15,lf[28]);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6259,a[2]=t9,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6290,a[2]=t12,a[3]=t19,a[4]=t14,a[5]=t13,a[6]=((C_word)li43),tmp=(C_word)a,a+=7,tmp));
t21=((C_word*)t19)[1];
f_6290(t21,t17,t15);}

/* map-loop1194 in k8156 in k8134 in k8128 in k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in ... */
static void C_fcall f_8228(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_8228,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,2,t3,lf[216]);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a6907 in map-loop1631 in k6599 in k6562 in a6559 in k6974 in k6978 in k6982 in k6986 in k6990 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_6908(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6908,5,av);}
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k11213 in map-loop25 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_11215(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_11215,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_11190(t6,((C_word*)t0)[5],t5);}

/* k5102 in a5093 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_fcall f_5104(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_5104,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5114,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1099: rename2088 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[91];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=C_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t3))){
t4=C_i_cdr(t3);
t5=t2;
f_5128(t5,C_eqp(t4,C_SCHEME_END_OF_LIST));}
else{
t4=t2;
f_5128(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5128(t3,C_SCHEME_FALSE);}}}

/* k4266 in k4249 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_ccall f_4268(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,3))){C_save_and_reclaim((void *)f_4268,2,av);}
a=C_alloc(19);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=C_i_car(((C_word*)t0)[2]);
t8=C_i_check_list_2(t7,lf[28]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4335,a[2]=t5,a[3]=t11,a[4]=t6,a[5]=((C_word)li10),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_4335(t13,t9,t7);}

/* k10812 in k10797 in k10775 in a10772 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_10814(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(24,0,1))){
C_save_and_reclaim_args((void *)trf_10814,2,t0,t1);}
a=C_alloc(24);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=C_a_i_list(&a,1,t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[4]);
t6=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t6;
av2[1]=C_a_i_cons(&a,2,lf[30],t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t2=C_a_i_list(&a,3,lf[101],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
t4=C_a_i_cons(&a,2,lf[101],t3);
t5=((C_word*)t0)[5];{
C_word av2[2];
av2[0]=t5;
av2[1]=C_a_i_list(&a,3,lf[144],t2,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k8207 in map-loop1242 in k8162 in k8156 in k8134 in k8128 in k8114 in a8111 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in ... */
static void C_ccall f_8209(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_8209,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=C_slot(((C_word*)t0)[4],C_fix(1));
t7=((C_word*)((C_word*)t0)[5])[1];
f_8180(t7,((C_word*)t0)[6],t5,t6);}

/* map-loop650 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 in ... */
static void C_fcall f_9601(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_9601,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9626,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:289: g656 */
t4=((C_word*)t0)[4];
f_9129(t4,t3);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k11224 in k3538 in k3534 */
static void C_ccall f_11226(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_11226,2,av);}
/* chicken-syntax.scm:46: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[290];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a11227 in k3538 in k3534 */
static void C_ccall f_11228(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_11228,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11232,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:51: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[290];
av2[3]=t2;
av2[4]=lf[292];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k5112 in k5102 in a5093 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_5114(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_5114,2,av);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,t1,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_10884(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_10884,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10887,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:64: r */
t4=((C_word*)t0)[8];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[114];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_10887(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,3))){C_save_and_reclaim((void *)f_10887,2,av);}
a=C_alloc(27);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li147),tmp=(C_word)a,a+=5,tmp);
t8=C_i_check_list_2(((C_word*)t0)[4],lf[28]);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10951,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11190,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=t6,a[6]=((C_word)li149),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_11190(t13,t9,((C_word*)t0)[4]);}

/* k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_10881(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_10881,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:63: r */
t4=((C_word*)t0)[7];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[125];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k5126 in k5102 in a5093 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_fcall f_5128(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_5128,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=t2;
t4=C_i_cdr(((C_word*)t0)[2]);
t5=C_i_car(t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5141,a[2]=t6,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1099: rename2088 */
t8=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[91];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
/* chicken-syntax.scm:1099: ##sys#syntax-rules-mismatch */
t2=*((C_word*)lf[55]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_10878(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_10878,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:62: r */
t4=((C_word*)t0)[6];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[47];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_10870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_10870,2,av);}
a=C_alloc(7);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10878,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:61: symbol->string */
t8=*((C_word*)lf[183]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* a10865 in k3541 in k3538 in k3534 */
static void C_ccall f_10866(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_10866,5,av);}
a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10870,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:58: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[280];
av2[3]=t2;
av2[4]=lf[289];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k10862 in k3541 in k3538 in k3534 */
static void C_ccall f_10864(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_10864,2,av);}
/* chicken-syntax.scm:54: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[280];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4297 in k4287 in k4266 in k4249 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in ... */
static void C_ccall f_4299(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_4299,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4309,a[2]=((C_word*)t0)[4],a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1210: ##sys#map-n */
t5=*((C_word*)lf[53]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=((C_word*)t0)[5];
av2[4]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* g233 in k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_fcall f_9913(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_9913,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9921,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:218: gensym */
t3=*((C_word*)lf[32]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k9907 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9909(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(25,c,3))){C_save_and_reclaim((void *)f_9909,2,av);}
a=C_alloc(25);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9913,a[2]=((C_word*)t0)[2],a[3]=((C_word)li128),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9924,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10423,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=t6,a[6]=((C_word)li137),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_10423(t12,t8,((C_word*)t0)[6]);}

/* k9904 in g205 in k9892 in k9878 in a9875 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in k3541 in k3538 in k3534 */
static void C_ccall f_9906(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_9906,2,av);}
/* chicken-syntax.scm:217: r */
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5387 in k5371 in k5360 in k5354 in k5351 in loop in k5334 in k5331 in k5328 in k5325 in a5322 in k5510 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_ccall f_5389(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,1))){C_save_and_reclaim((void *)f_5389,2,av);}
a=C_alloc(24);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_list(&a,3,lf[101],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_list(&a,3,lf[30],((C_word*)t0)[6],t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k11230 in a11227 in k3538 in k3534 */
static void C_ccall f_11232(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_11232,2,av);}
a=C_alloc(3);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,lf[291],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k7359 in recur in make-if-tree in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in ... */
static void C_ccall f_7361(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_7361,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k5939 in loop in k5995 in k5740 in k5731 in k5728 in k5722 in k5719 in k5704 in a5701 in k6071 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_5941(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5941,2,av);}
t2=((C_word*)t0)[2];
f_5786(t2,(C_truep(t1)?C_i_cadr(((C_word*)t0)[3]):C_SCHEME_FALSE));}

/* k7317 in recur in k7276 in k7272 in k7268 in k7498 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in k3593 in ... */
static void C_ccall f_7319(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_7319,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7327,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7331,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:631: reverse */
t5=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* map-loop742 in k9168 in k9151 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in k3544 in ... */
static void C_fcall f_9435(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(10,0,2))){
C_save_and_reclaim_args((void *)trf_9435,5,t0,t1,t2,t3,t4);}
a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9442,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t1,a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_pairp(t2))){
t6=C_i_pairp(t3);
t7=t5;
f_9442(t7,(C_truep(t6)?C_i_pairp(t4):C_SCHEME_FALSE));}
else{
t6=t5;
f_9442(t6,C_SCHEME_FALSE);}}

/* g31 in k10885 in k10882 in k10879 in k10876 in k10868 in a10865 in k3541 in k3538 in k3534 */
static void C_fcall f_10891(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,4))){
C_save_and_reclaim_args((void *)trf_10891,3,t0,t1,t2);}
a=C_alloc(4);
if(C_truep(C_i_symbolp(t2))){
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10919,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* chicken-syntax.scm:69: c */
t6=((C_word*)t0)[2];{
C_word av2[4];
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
/* chicken-syntax.scm:75: syntax-error */
t3=*((C_word*)lf[45]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[280];
av2[3]=lf[281];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}}

/* k7299 in k7325 in k7317 in recur in k7276 in k7272 in k7268 in k7498 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in ... */
static void C_ccall f_7301(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_7301,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a4308 in k4297 in k4287 in k4266 in k4249 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in ... */
static void C_ccall f_4309(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4309,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4325,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1210: rename2283 */
t5=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[52];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k4305 in k4297 in k4287 in k4266 in k4249 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in ... */
static void C_ccall f_4307(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_4307,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k7329 in k7317 in recur in k7276 in k7272 in k7268 in k7498 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_7331(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_7331,2,av);}
a=C_alloc(3);
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
/* chicken-syntax.scm:628: ##sys#append */
t4=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k7325 in k7317 in recur in k7276 in k7272 in k7268 in k7498 in k7483 in k7480 in k7477 in k7471 in k7440 in k7431 in k7428 in k7249 in a7246 in k7683 in k7687 in k3605 in k3602 in k3599 in k3596 in ... */
static void C_ccall f_7327(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(22,c,5))){C_save_and_reclaim((void *)f_7327,2,av);}
a=C_alloc(22);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list(&a,3,lf[101],((C_word*)t0)[3],t2);
t4=C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7301,a[2]=((C_word*)t0)[5],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[6];
t8=C_u_i_cdr(t7);
t9=((C_word*)t0)[7];
t10=C_u_i_cdr(t9);
t11=((C_word*)t0)[6];
t12=C_u_i_car(t11);
/* chicken-syntax.scm:632: recur */
t13=((C_word*)((C_word*)t0)[8])[1];
f_7280(t13,t6,((C_word*)t0)[9],t8,t10,t12);}

/* k9440 in map-loop742 in k9168 in k9151 in k9138 in k9123 in k9108 in k9090 in k9084 in k9075 in k9072 in k9069 in k9061 in a9043 in k3568 in k3565 in k3562 in k3559 in k3556 in k3553 in k3550 in k3547 in ... */
static void C_fcall f_9442(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_demand(C_calculate_demand(33,0,4))){
C_save_and_reclaim_args((void *)trf_9442,2,t0,t1);}
a=C_alloc(33);
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[2],C_fix(0));
t3=C_slot(((C_word*)t0)[3],C_fix(0));
t4=C_slot(((C_word*)t0)[4],C_fix(0));
t5=f_9275(C_a_i(&a,30),((C_word*)t0)[5],t2,t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t6);
t8=C_mutate2(((C_word *)((C_word*)t0)[6])+1,t6);
t9=C_slot(((C_word*)t0)[2],C_fix(1));
t10=C_slot(((C_word*)t0)[3],C_fix(1));
t11=C_slot(((C_word*)t0)[4],C_fix(1));
t12=((C_word*)((C_word*)t0)[7])[1];
f_9435(t12,((C_word*)t0)[8],t9,t10,t11);}
else{
t2=((C_word*)t0)[8];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_slot(((C_word*)t0)[9],C_fix(1));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k5200 in k5193 in a5190 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in ... */
static void C_ccall f_5202(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_5202,2,av);}
a=C_alloc(3);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,t1,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4599 in k4590 in a4587 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in ... */
static void C_ccall f_4601(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,5))){C_save_and_reclaim((void *)f_4601,2,av);}
a=C_alloc(11);
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4609,a[2]=t2,a[3]=t4,a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4619,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=((C_word)li17),tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1184: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=t5;
av2[3]=t6;
C_call_with_values(4,av2);}}

/* a5211 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_5212(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_5212,5,av);}
a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5216,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1084: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[95];
av2[3]=t2;
av2[4]=lf[97];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k5208 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in ... */
static void C_ccall f_5210(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5210,2,av);}
/* chicken-syntax.scm:1080: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[95];
av2[3]=C_SCHEME_END_OF_LIST;
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5214 in a5211 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in ... */
static void C_ccall f_5216(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_5216,2,av);}
a=C_alloc(9);
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_list(&a,3,lf[96],t2,C_SCHEME_TRUE);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k7163 in k7160 in a7157 in k7227 in k7231 in k7235 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in ... */
static void C_ccall f_7165(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_7165,2,av);}
a=C_alloc(16);
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=C_a_i_list(&a,2,t2,t3);
t5=C_a_i_list(&a,1,t4);
t6=t5;
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7205,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:706: r */
t8=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[173];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* k7160 in a7157 in k7227 in k7231 in k7235 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in k3565 in k3562 in k3559 in ... */
static void C_ccall f_7162(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_7162,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:704: r */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[176];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5260 in a5257 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in ... */
static void C_ccall f_5262(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,1))){C_save_and_reclaim((void *)f_5262,2,av);}
a=C_alloc(24);
t2=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t2))){
t3=C_u_i_car(t2);
t4=C_u_i_cdr(t2);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=C_a_i_cons(&a,2,t4,t7);
t9=C_a_i_cons(&a,2,lf[101],t8);
t10=C_a_i_list(&a,2,t3,t9);
t11=C_a_i_list(&a,1,t10);
t12=C_u_i_car(t2);
t13=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t13;
av2[1]=C_a_i_list(&a,3,lf[102],t11,t12);
((C_proc)(void*)(*((C_word*)t13+1)))(2,av2);}}
else{
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_a_i_cons(&a,2,t2,t5);
t7=C_a_i_list(&a,1,t6);
t8=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_a_i_list(&a,3,lf[102],t7,t2);
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}

/* a4608 in k4599 in k4590 in a4587 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in k3608 in ... */
static void C_ccall f_4609(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4609,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4617,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1188: ##sys#strip-syntax */
t3=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4287 in k4266 in k4249 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in ... */
static void C_ccall f_4289(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_4289,2,av);}
a=C_alloc(7);
t2=t1;
t3=C_i_cdr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4299,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1210: rename2283 */
t6=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[54];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* map-loop2328 in k4249 in a4240 in k3665 in k3662 in k3659 in k3656 in k3653 in k3650 in k3647 in k3644 in k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in ... */
static void C_fcall f_4369(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_4369,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7193 in k7203 in k7163 in k7160 in a7157 in k7227 in k7231 in k7235 in k3608 in k3605 in k3602 in k3599 in k3596 in k3593 in k3590 in k3587 in k3584 in k3580 in k3577 in k3574 in k3571 in k3568 in ... */
static void C_ccall f_7195(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(27,c,1))){C_save_and_reclaim((void *)f_7195,2,av);}
a=C_alloc(27);
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,4,lf[159],((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_list(&a,3,lf[30],((C_word*)t0)[6],t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[664] = {
{"f_4617:chicken_2dsyntax_2escm",(void*)f_4617},
{"f_4619:chicken_2dsyntax_2escm",(void*)f_4619},
{"f_5240:chicken_2dsyntax_2escm",(void*)f_5240},
{"f_4644:chicken_2dsyntax_2escm",(void*)f_4644},
{"f_5256:chicken_2dsyntax_2escm",(void*)f_5256},
{"f_7274:chicken_2dsyntax_2escm",(void*)f_7274},
{"f_7270:chicken_2dsyntax_2escm",(void*)f_7270},
{"f_5248:chicken_2dsyntax_2escm",(void*)f_5248},
{"f_7278:chicken_2dsyntax_2escm",(void*)f_7278},
{"f_5258:chicken_2dsyntax_2escm",(void*)f_5258},
{"f_4325:chicken_2dsyntax_2escm",(void*)f_4325},
{"f_4648:chicken_2dsyntax_2escm",(void*)f_4648},
{"f_4335:chicken_2dsyntax_2escm",(void*)f_4335},
{"f_7280:chicken_2dsyntax_2escm",(void*)f_7280},
{"f_4694:chicken_2dsyntax_2escm",(void*)f_4694},
{"f_4696:chicken_2dsyntax_2escm",(void*)f_4696},
{"f_9096:chicken_2dsyntax_2escm",(void*)f_9096},
{"f_9092:chicken_2dsyntax_2escm",(void*)f_9092},
{"f_9086:chicken_2dsyntax_2escm",(void*)f_9086},
{"f_3613:chicken_2dsyntax_2escm",(void*)f_3613},
{"f_3616:chicken_2dsyntax_2escm",(void*)f_3616},
{"f_3619:chicken_2dsyntax_2escm",(void*)f_3619},
{"f_3610:chicken_2dsyntax_2escm",(void*)f_3610},
{"f_9387:chicken_2dsyntax_2escm",(void*)f_9387},
{"f_9077:chicken_2dsyntax_2escm",(void*)f_9077},
{"f_9074:chicken_2dsyntax_2escm",(void*)f_9074},
{"f_9071:chicken_2dsyntax_2escm",(void*)f_9071},
{"f_5227:chicken_2dsyntax_2escm",(void*)f_5227},
{"f_4700:chicken_2dsyntax_2escm",(void*)f_4700},
{"f_4703:chicken_2dsyntax_2escm",(void*)f_4703},
{"f_5233:chicken_2dsyntax_2escm",(void*)f_5233},
{"f_9063:chicken_2dsyntax_2escm",(void*)f_9063},
{"f_5229:chicken_2dsyntax_2escm",(void*)f_5229},
{"f_10681:chicken_2dsyntax_2escm",(void*)f_10681},
{"f_3655:chicken_2dsyntax_2escm",(void*)f_3655},
{"f_10674:chicken_2dsyntax_2escm",(void*)f_10674},
{"f_3658:chicken_2dsyntax_2escm",(void*)f_3658},
{"f_3652:chicken_2dsyntax_2escm",(void*)f_3652},
{"f_8825:chicken_2dsyntax_2escm",(void*)f_8825},
{"f_10664:chicken_2dsyntax_2escm",(void*)f_10664},
{"f_8838:chicken_2dsyntax_2escm",(void*)f_8838},
{"f_3604:chicken_2dsyntax_2escm",(void*)f_3604},
{"f_3607:chicken_2dsyntax_2escm",(void*)f_3607},
{"f_3601:chicken_2dsyntax_2escm",(void*)f_3601},
{"f_8816:chicken_2dsyntax_2escm",(void*)f_8816},
{"f_3695:chicken_2dsyntax_2escm",(void*)f_3695},
{"f_4762:chicken_2dsyntax_2escm",(void*)f_4762},
{"f_4765:chicken_2dsyntax_2escm",(void*)f_4765},
{"f_3691:chicken_2dsyntax_2escm",(void*)f_3691},
{"f_10448:chicken_2dsyntax_2escm",(void*)f_10448},
{"f_4774:chicken_2dsyntax_2escm",(void*)f_4774},
{"f_10697:chicken_2dsyntax_2escm",(void*)f_10697},
{"f_10691:chicken_2dsyntax_2escm",(void*)f_10691},
{"f_10693:chicken_2dsyntax_2escm",(void*)f_10693},
{"f_9898:chicken_2dsyntax_2escm",(void*)f_9898},
{"f_9894:chicken_2dsyntax_2escm",(void*)f_9894},
{"f_10608:chicken_2dsyntax_2escm",(void*)f_10608},
{"f_10604:chicken_2dsyntax_2escm",(void*)f_10604},
{"f_10602:chicken_2dsyntax_2escm",(void*)f_10602},
{"f_7539:chicken_2dsyntax_2escm",(void*)f_7539},
{"f_9880:chicken_2dsyntax_2escm",(void*)f_9880},
{"f_10457:chicken_2dsyntax_2escm",(void*)f_10457},
{"f_9874:chicken_2dsyntax_2escm",(void*)f_9874},
{"f_9876:chicken_2dsyntax_2escm",(void*)f_9876},
{"f_3667:chicken_2dsyntax_2escm",(void*)f_3667},
{"f_3664:chicken_2dsyntax_2escm",(void*)f_3664},
{"f_10482:chicken_2dsyntax_2escm",(void*)f_10482},
{"f_3661:chicken_2dsyntax_2escm",(void*)f_3661},
{"f_9861:chicken_2dsyntax_2escm",(void*)f_9861},
{"f_3676:chicken_2dsyntax_2escm",(void*)f_3676},
{"f_3679:chicken_2dsyntax_2escm",(void*)f_3679},
{"f_8996:chicken_2dsyntax_2escm",(void*)f_8996},
{"f_9854:chicken_2dsyntax_2escm",(void*)f_9854},
{"f_8992:chicken_2dsyntax_2escm",(void*)f_8992},
{"f_8990:chicken_2dsyntax_2escm",(void*)f_8990},
{"f_3673:chicken_2dsyntax_2escm",(void*)f_3673},
{"f_8791:chicken_2dsyntax_2escm",(void*)f_8791},
{"f_3670:chicken_2dsyntax_2escm",(void*)f_3670},
{"f_7503:chicken_2dsyntax_2escm",(void*)f_7503},
{"f_7506:chicken_2dsyntax_2escm",(void*)f_7506},
{"f_7500:chicken_2dsyntax_2escm",(void*)f_7500},
{"f_3685:chicken_2dsyntax_2escm",(void*)f_3685},
{"f_3689:chicken_2dsyntax_2escm",(void*)f_3689},
{"f_10645:chicken_2dsyntax_2escm",(void*)f_10645},
{"f_9847:chicken_2dsyntax_2escm",(void*)f_9847},
{"f_8969:chicken_2dsyntax_2escm",(void*)f_8969},
{"f_3682:chicken_2dsyntax_2escm",(void*)f_3682},
{"f_10491:chicken_2dsyntax_2escm",(void*)f_10491},
{"f_9837:chicken_2dsyntax_2escm",(void*)f_9837},
{"f_8975:chicken_2dsyntax_2escm",(void*)f_8975},
{"f_8971:chicken_2dsyntax_2escm",(void*)f_8971},
{"f_8863:chicken_2dsyntax_2escm",(void*)f_8863},
{"f_9826:chicken_2dsyntax_2escm",(void*)f_9826},
{"f_8944:chicken_2dsyntax_2escm",(void*)f_8944},
{"f_10622:chicken_2dsyntax_2escm",(void*)f_10622},
{"f_10619:chicken_2dsyntax_2escm",(void*)f_10619},
{"f_8954:chicken_2dsyntax_2escm",(void*)f_8954},
{"f_10423:chicken_2dsyntax_2escm",(void*)f_10423},
{"f_8368:chicken_2dsyntax_2escm",(void*)f_8368},
{"f_6405:chicken_2dsyntax_2escm",(void*)f_6405},
{"f_8923:chicken_2dsyntax_2escm",(void*)f_8923},
{"f_8929:chicken_2dsyntax_2escm",(void*)f_8929},
{"f_8370:chicken_2dsyntax_2escm",(void*)f_8370},
{"f_8374:chicken_2dsyntax_2escm",(void*)f_8374},
{"f_8936:chicken_2dsyntax_2escm",(void*)f_8936},
{"f_7564:chicken_2dsyntax_2escm",(void*)f_7564},
{"f_5620:chicken_2dsyntax_2escm",(void*)f_5620},
{"f_5617:chicken_2dsyntax_2escm",(void*)f_5617},
{"f_7573:chicken_2dsyntax_2escm",(void*)f_7573},
{"f_6155:chicken_2dsyntax_2escm",(void*)f_6155},
{"f_8332:chicken_2dsyntax_2escm",(void*)f_8332},
{"f_6153:chicken_2dsyntax_2escm",(void*)f_6153},
{"f_3628:chicken_2dsyntax_2escm",(void*)f_3628},
{"f_3625:chicken_2dsyntax_2escm",(void*)f_3625},
{"f_3622:chicken_2dsyntax_2escm",(void*)f_3622},
{"f_7513:chicken_2dsyntax_2escm",(void*)f_7513},
{"f_8485:chicken_2dsyntax_2escm",(void*)f_8485},
{"f_8489:chicken_2dsyntax_2escm",(void*)f_8489},
{"f_3637:chicken_2dsyntax_2escm",(void*)f_3637},
{"f_3634:chicken_2dsyntax_2escm",(void*)f_3634},
{"f_3631:chicken_2dsyntax_2escm",(void*)f_3631},
{"f_3649:chicken_2dsyntax_2escm",(void*)f_3649},
{"f_3646:chicken_2dsyntax_2escm",(void*)f_3646},
{"f_3643:chicken_2dsyntax_2escm",(void*)f_3643},
{"f_3640:chicken_2dsyntax_2escm",(void*)f_3640},
{"f_5637:chicken_2dsyntax_2escm",(void*)f_5637},
{"f_6087:chicken_2dsyntax_2escm",(void*)f_6087},
{"f_6081:chicken_2dsyntax_2escm",(void*)f_6081},
{"f_6083:chicken_2dsyntax_2escm",(void*)f_6083},
{"f_5643:chicken_2dsyntax_2escm",(void*)f_5643},
{"f_8455:chicken_2dsyntax_2escm",(void*)f_8455},
{"f_6073:chicken_2dsyntax_2escm",(void*)f_6073},
{"f_6090:chicken_2dsyntax_2escm",(void*)f_6090},
{"f_4750:chicken_2dsyntax_2escm",(void*)f_4750},
{"f_4755:chicken_2dsyntax_2escm",(void*)f_4755},
{"f_5189:chicken_2dsyntax_2escm",(void*)f_5189},
{"f_5191:chicken_2dsyntax_2escm",(void*)f_5191},
{"f_5195:chicken_2dsyntax_2escm",(void*)f_5195},
{"f_6099:chicken_2dsyntax_2escm",(void*)f_6099},
{"f_6096:chicken_2dsyntax_2escm",(void*)f_6096},
{"f_6093:chicken_2dsyntax_2escm",(void*)f_6093},
{"f_5016:chicken_2dsyntax_2escm",(void*)f_5016},
{"f_5009:chicken_2dsyntax_2escm",(void*)f_5009},
{"f_5000:chicken_2dsyntax_2escm",(void*)f_5000},
{"f_5059:chicken_2dsyntax_2escm",(void*)f_5059},
{"f_10919:chicken_2dsyntax_2escm",(void*)f_10919},
{"f_5050:chicken_2dsyntax_2escm",(void*)f_5050},
{"f_5066:chicken_2dsyntax_2escm",(void*)f_5066},
{"f_10976:chicken_2dsyntax_2escm",(void*)f_10976},
{"f_10974:chicken_2dsyntax_2escm",(void*)f_10974},
{"f_7156:chicken_2dsyntax_2escm",(void*)f_7156},
{"f_5030:chicken_2dsyntax_2escm",(void*)f_5030},
{"f_7158:chicken_2dsyntax_2escm",(void*)f_7158},
{"f_5041:chicken_2dsyntax_2escm",(void*)f_5041},
{"f_7148:chicken_2dsyntax_2escm",(void*)f_7148},
{"f_5044:chicken_2dsyntax_2escm",(void*)f_5044},
{"f_10951:chicken_2dsyntax_2escm",(void*)f_10951},
{"f_7233:chicken_2dsyntax_2escm",(void*)f_7233},
{"f_7237:chicken_2dsyntax_2escm",(void*)f_7237},
{"f_4944:chicken_2dsyntax_2escm",(void*)f_4944},
{"f_4946:chicken_2dsyntax_2escm",(void*)f_4946},
{"f_4956:chicken_2dsyntax_2escm",(void*)f_4956},
{"f_7229:chicken_2dsyntax_2escm",(void*)f_7229},
{"f_7251:chicken_2dsyntax_2escm",(void*)f_7251},
{"f_4969:chicken_2dsyntax_2escm",(void*)f_4969},
{"f_10995:chicken_2dsyntax_2escm",(void*)f_10995},
{"f_10998:chicken_2dsyntax_2escm",(void*)f_10998},
{"f_7245:chicken_2dsyntax_2escm",(void*)f_7245},
{"f_5448:chicken_2dsyntax_2escm",(void*)f_5448},
{"f_7247:chicken_2dsyntax_2escm",(void*)f_7247},
{"f_10992:chicken_2dsyntax_2escm",(void*)f_10992},
{"f_5442:chicken_2dsyntax_2escm",(void*)f_5442},
{"f_4985:chicken_2dsyntax_2escm",(void*)f_4985},
{"f_9339:chicken_2dsyntax_2escm",(void*)f_9339},
{"f_4991:chicken_2dsyntax_2escm",(void*)f_4991},
{"f_4419:chicken_2dsyntax_2escm",(void*)f_4419},
{"f_4994:chicken_2dsyntax_2escm",(void*)f_4994},
{"f_4413:chicken_2dsyntax_2escm",(void*)f_4413},
{"f_5422:chicken_2dsyntax_2escm",(void*)f_5422},
{"f_5425:chicken_2dsyntax_2escm",(void*)f_5425},
{"f_9313:chicken_2dsyntax_2escm",(void*)f_9313},
{"f_4428:chicken_2dsyntax_2escm",(void*)f_4428},
{"f_9317:chicken_2dsyntax_2escm",(void*)f_9317},
{"f_4422:chicken_2dsyntax_2escm",(void*)f_4422},
{"f_7006:chicken_2dsyntax_2escm",(void*)f_7006},
{"f_7002:chicken_2dsyntax_2escm",(void*)f_7002},
{"f_7205:chicken_2dsyntax_2escm",(void*)f_7205},
{"f_7000:chicken_2dsyntax_2escm",(void*)f_7000},
{"f_5488:chicken_2dsyntax_2escm",(void*)f_5488},
{"f_9044:chicken_2dsyntax_2escm",(void*)f_9044},
{"f_9042:chicken_2dsyntax_2escm",(void*)f_9042},
{"f_7077:chicken_2dsyntax_2escm",(void*)f_7077},
{"f_8599:chicken_2dsyntax_2escm",(void*)f_8599},
{"f_8597:chicken_2dsyntax_2escm",(void*)f_8597},
{"f_8591:chicken_2dsyntax_2escm",(void*)f_8591},
{"f_5692:chicken_2dsyntax_2escm",(void*)f_5692},
{"f_9329:chicken_2dsyntax_2escm",(void*)f_9329},
{"f_5465:chicken_2dsyntax_2escm",(void*)f_5465},
{"f_9020:chicken_2dsyntax_2escm",(void*)f_9020},
{"f_9024:chicken_2dsyntax_2escm",(void*)f_9024},
{"f_9018:chicken_2dsyntax_2escm",(void*)f_9018},
{"f_4469:chicken_2dsyntax_2escm",(void*)f_4469},
{"f_9553:chicken_2dsyntax_2escm",(void*)f_9553},
{"f_4494:chicken_2dsyntax_2escm",(void*)f_4494},
{"f_9293:chicken_2dsyntax_2escm",(void*)f_9293},
{"f_4478:chicken_2dsyntax_2escm",(void*)f_4478},
{"f_9505:chicken_2dsyntax_2escm",(void*)f_9505},
{"f_4472:chicken_2dsyntax_2escm",(void*)f_4472},
{"f_9297:chicken_2dsyntax_2escm",(void*)f_9297},
{"f_4487:chicken_2dsyntax_2escm",(void*)f_4487},
{"f_9275:chicken_2dsyntax_2escm",(void*)f_9275},
{"f_10188:chicken_2dsyntax_2escm",(void*)f_10188},
{"f_7699:chicken_2dsyntax_2escm",(void*)f_7699},
{"f_7695:chicken_2dsyntax_2escm",(void*)f_7695},
{"f_7693:chicken_2dsyntax_2escm",(void*)f_7693},
{"f_3914:chicken_2dsyntax_2escm",(void*)f_3914},
{"f_4846:chicken_2dsyntax_2escm",(void*)f_4846},
{"f_8637:chicken_2dsyntax_2escm",(void*)f_8637},
{"f_3924:chicken_2dsyntax_2escm",(void*)f_3924},
{"f_3927:chicken_2dsyntax_2escm",(void*)f_3927},
{"f_4819:chicken_2dsyntax_2escm",(void*)f_4819},
{"f_8648:chicken_2dsyntax_2escm",(void*)f_8648},
{"f_3933:chicken_2dsyntax_2escm",(void*)f_3933},
{"f_7811:chicken_2dsyntax_2escm",(void*)f_7811},
{"f_4821:chicken_2dsyntax_2escm",(void*)f_4821},
{"f_7813:chicken_2dsyntax_2escm",(void*)f_7813},
{"f_4872:chicken_2dsyntax_2escm",(void*)f_4872},
{"f_7497:chicken_2dsyntax_2escm",(void*)f_7497},
{"f_3970:chicken_2dsyntax_2escm",(void*)f_3970},
{"f_8713:chicken_2dsyntax_2escm",(void*)f_8713},
{"f_3968:chicken_2dsyntax_2escm",(void*)f_3968},
{"f_7489:chicken_2dsyntax_2escm",(void*)f_7489},
{"f_4857:chicken_2dsyntax_2escm",(void*)f_4857},
{"f_4859:chicken_2dsyntax_2escm",(void*)f_4859},
{"f_4458:chicken_2dsyntax_2escm",(void*)f_4458},
{"f_7485:chicken_2dsyntax_2escm",(void*)f_7485},
{"f_7482:chicken_2dsyntax_2escm",(void*)f_7482},
{"f_10114:chicken_2dsyntax_2escm",(void*)f_10114},
{"f_10118:chicken_2dsyntax_2escm",(void*)f_10118},
{"f_4869:chicken_2dsyntax_2escm",(void*)f_4869},
{"f_4863:chicken_2dsyntax_2escm",(void*)f_4863},
{"f_4866:chicken_2dsyntax_2escm",(void*)f_4866},
{"f_4437:chicken_2dsyntax_2escm",(void*)f_4437},
{"f_7800:chicken_2dsyntax_2escm",(void*)f_7800},
{"f_7455:chicken_2dsyntax_2escm",(void*)f_7455},
{"f_7451:chicken_2dsyntax_2escm",(void*)f_7451},
{"f_7459:chicken_2dsyntax_2escm",(void*)f_7459},
{"f_10341:chicken_2dsyntax_2escm",(void*)f_10341},
{"f_4444:chicken_2dsyntax_2escm",(void*)f_4444},
{"f_7877:chicken_2dsyntax_2escm",(void*)f_7877},
{"f_4898:chicken_2dsyntax_2escm",(void*)f_4898},
{"f_7443:chicken_2dsyntax_2escm",(void*)f_7443},
{"f_7442:chicken_2dsyntax_2escm",(void*)f_7442},
{"f_9170:chicken_2dsyntax_2escm",(void*)f_9170},
{"f_7632:chicken_2dsyntax_2escm",(void*)f_7632},
{"f_3704:chicken_2dsyntax_2escm",(void*)f_3704},
{"f_3707:chicken_2dsyntax_2escm",(void*)f_3707},
{"f_4895:chicken_2dsyntax_2escm",(void*)f_4895},
{"f_6114:chicken_2dsyntax_2escm",(void*)f_6114},
{"f_10140:chicken_2dsyntax_2escm",(void*)f_10140},
{"f_6111:chicken_2dsyntax_2escm",(void*)f_6111},
{"f_8624:chicken_2dsyntax_2escm",(void*)f_8624},
{"f_6104:chicken_2dsyntax_2escm",(void*)f_6104},
{"f_10130:chicken_2dsyntax_2escm",(void*)f_10130},
{"f_6619:chicken_2dsyntax_2escm",(void*)f_6619},
{"f_6108:chicken_2dsyntax_2escm",(void*)f_6108},
{"f_6992:chicken_2dsyntax_2escm",(void*)f_6992},
{"f_7641:chicken_2dsyntax_2escm",(void*)f_7641},
{"f_6102:chicken_2dsyntax_2escm",(void*)f_6102},
{"f_6616:chicken_2dsyntax_2escm",(void*)f_6616},
{"f_6613:chicken_2dsyntax_2escm",(void*)f_6613},
{"f_6610:chicken_2dsyntax_2escm",(void*)f_6610},
{"f_6984:chicken_2dsyntax_2escm",(void*)f_6984},
{"f_6607:chicken_2dsyntax_2escm",(void*)f_6607},
{"f_6980:chicken_2dsyntax_2escm",(void*)f_6980},
{"f_3749:chicken_2dsyntax_2escm",(void*)f_3749},
{"f_6988:chicken_2dsyntax_2escm",(void*)f_6988},
{"f_8685:chicken_2dsyntax_2escm",(void*)f_8685},
{"f_6601:chicken_2dsyntax_2escm",(void*)f_6601},
{"f_7863:chicken_2dsyntax_2escm",(void*)f_7863},
{"f_7861:chicken_2dsyntax_2escm",(void*)f_7861},
{"f_6604:chicken_2dsyntax_2escm",(void*)f_6604},
{"f_7867:chicken_2dsyntax_2escm",(void*)f_7867},
{"f_6976:chicken_2dsyntax_2escm",(void*)f_6976},
{"f_8778:chicken_2dsyntax_2escm",(void*)f_8778},
{"f_10389:chicken_2dsyntax_2escm",(void*)f_10389},
{"f_3710:chicken_2dsyntax_2escm",(void*)f_3710},
{"f_6635:chicken_2dsyntax_2escm",(void*)f_6635},
{"f_6628:chicken_2dsyntax_2escm",(void*)f_6628},
{"f_8785:chicken_2dsyntax_2escm",(void*)f_8785},
{"f_6625:chicken_2dsyntax_2escm",(void*)f_6625},
{"f_6622:chicken_2dsyntax_2escm",(void*)f_6622},
{"f_6033:chicken_2dsyntax_2escm",(void*)f_6033},
{"f_7607:chicken_2dsyntax_2escm",(void*)f_7607},
{"f_6139:chicken_2dsyntax_2escm",(void*)f_6139},
{"f_6945:chicken_2dsyntax_2escm",(void*)f_6945},
{"f_3788:chicken_2dsyntax_2escm",(void*)f_3788},
{"f_8412:chicken_2dsyntax_2escm",(void*)f_8412},
{"f_10321:chicken_2dsyntax_2escm",(void*)f_10321},
{"f_8462:chicken_2dsyntax_2escm",(void*)f_8462},
{"f_6920:chicken_2dsyntax_2escm",(void*)f_6920},
{"f_10335:chicken_2dsyntax_2escm",(void*)f_10335},
{"f_8747:chicken_2dsyntax_2escm",(void*)f_8747},
{"f_5841:chicken_2dsyntax_2escm",(void*)f_5841},
{"f_5542:chicken_2dsyntax_2escm",(void*)f_5542},
{"f_6689:chicken_2dsyntax_2escm",(void*)f_6689},
{"f_5555:chicken_2dsyntax_2escm",(void*)f_5555},
{"f_5811:chicken_2dsyntax_2escm",(void*)f_5811},
{"f_5552:chicken_2dsyntax_2escm",(void*)f_5552},
{"f_6687:chicken_2dsyntax_2escm",(void*)f_6687},
{"f_5733:chicken_2dsyntax_2escm",(void*)f_5733},
{"f_3799:chicken_2dsyntax_2escm",(void*)f_3799},
{"f_5730:chicken_2dsyntax_2escm",(void*)f_5730},
{"f_5568:chicken_2dsyntax_2escm",(void*)f_5568},
{"f_3792:chicken_2dsyntax_2escm",(void*)f_3792},
{"f_8422:chicken_2dsyntax_2escm",(void*)f_8422},
{"f_8424:chicken_2dsyntax_2escm",(void*)f_8424},
{"f_8428:chicken_2dsyntax_2escm",(void*)f_8428},
{"f_5561:chicken_2dsyntax_2escm",(void*)f_5561},
{"f_6598:chicken_2dsyntax_2escm",(void*)f_6598},
{"f_6590:chicken_2dsyntax_2escm",(void*)f_6590},
{"f_3764:chicken_2dsyntax_2escm",(void*)f_3764},
{"f_5742:chicken_2dsyntax_2escm",(void*)f_5742},
{"f_3761:chicken_2dsyntax_2escm",(void*)f_3761},
{"f_8434:chicken_2dsyntax_2escm",(void*)f_8434},
{"f_6659:chicken_2dsyntax_2escm",(void*)f_6659},
{"f_7685:chicken_2dsyntax_2escm",(void*)f_7685},
{"f_7689:chicken_2dsyntax_2escm",(void*)f_7689},
{"f_6647:chicken_2dsyntax_2escm",(void*)f_6647},
{"f_6649:chicken_2dsyntax_2escm",(void*)f_6649},
{"f_5512:chicken_2dsyntax_2escm",(void*)f_5512},
{"f_6679:chicken_2dsyntax_2escm",(void*)f_6679},
{"f_5529:chicken_2dsyntax_2escm",(void*)f_5529},
{"f_5526:chicken_2dsyntax_2escm",(void*)f_5526},
{"f_5522:chicken_2dsyntax_2escm",(void*)f_5522},
{"f_6673:chicken_2dsyntax_2escm",(void*)f_6673},
{"f_5520:chicken_2dsyntax_2escm",(void*)f_5520},
{"f_6677:chicken_2dsyntax_2escm",(void*)f_6677},
{"f_5786:chicken_2dsyntax_2escm",(void*)f_5786},
{"f_5094:chicken_2dsyntax_2escm",(void*)f_5094},
{"f_5092:chicken_2dsyntax_2escm",(void*)f_5092},
{"f_5535:chicken_2dsyntax_2escm",(void*)f_5535},
{"f_6663:chicken_2dsyntax_2escm",(void*)f_6663},
{"f_5532:chicken_2dsyntax_2escm",(void*)f_5532},
{"f_10708:chicken_2dsyntax_2escm",(void*)f_10708},
{"f_8180:chicken_2dsyntax_2escm",(void*)f_8180},
{"f_4165:chicken_2dsyntax_2escm",(void*)f_4165},
{"f_11186:chicken_2dsyntax_2escm",(void*)f_11186},
{"f_3900:chicken_2dsyntax_2escm",(void*)f_3900},
{"f_5724:chicken_2dsyntax_2escm",(void*)f_5724},
{"f_5721:chicken_2dsyntax_2escm",(void*)f_5721},
{"f_5080:chicken_2dsyntax_2escm",(void*)f_5080},
{"f_8168:chicken_2dsyntax_2escm",(void*)f_8168},
{"f_8164:chicken_2dsyntax_2escm",(void*)f_8164},
{"f_4109:chicken_2dsyntax_2escm",(void*)f_4109},
{"f_3906:chicken_2dsyntax_2escm",(void*)f_3906},
{"f_3903:chicken_2dsyntax_2escm",(void*)f_3903},
{"f_8178:chicken_2dsyntax_2escm",(void*)f_8178},
{"f_8908:chicken_2dsyntax_2escm",(void*)f_8908},
{"f_8905:chicken_2dsyntax_2escm",(void*)f_8905},
{"f_8901:chicken_2dsyntax_2escm",(void*)f_8901},
{"f_10722:chicken_2dsyntax_2escm",(void*)f_10722},
{"f_5803:chicken_2dsyntax_2escm",(void*)f_5803},
{"f_5807:chicken_2dsyntax_2escm",(void*)f_5807},
{"f_5584:chicken_2dsyntax_2escm",(void*)f_5584},
{"f_8915:chicken_2dsyntax_2escm",(void*)f_8915},
{"f_10710:chicken_2dsyntax_2escm",(void*)f_10710},
{"f_5594:chicken_2dsyntax_2escm",(void*)f_5594},
{"f_10728:chicken_2dsyntax_2escm",(void*)f_10728},
{"f_10724:chicken_2dsyntax_2escm",(void*)f_10724},
{"toplevel:chicken_2dsyntax_2escm",(void*)C_chicken_2dsyntax_toplevel},
{"f_11121:chicken_2dsyntax_2escm",(void*)f_11121},
{"f_11125:chicken_2dsyntax_2escm",(void*)f_11125},
{"f_5702:chicken_2dsyntax_2escm",(void*)f_5702},
{"f_10771:chicken_2dsyntax_2escm",(void*)f_10771},
{"f_5706:chicken_2dsyntax_2escm",(void*)f_5706},
{"f_10773:chicken_2dsyntax_2escm",(void*)f_10773},
{"f_5700:chicken_2dsyntax_2escm",(void*)f_5700},
{"f_8090:chicken_2dsyntax_2escm",(void*)f_8090},
{"f_10777:chicken_2dsyntax_2escm",(void*)f_10777},
{"f_8071:chicken_2dsyntax_2escm",(void*)f_8071},
{"f_4182:chicken_2dsyntax_2escm",(void*)f_4182},
{"f_11166:chicken_2dsyntax_2escm",(void*)f_11166},
{"f_11160:chicken_2dsyntax_2escm",(void*)f_11160},
{"f_6290:chicken_2dsyntax_2escm",(void*)f_6290},
{"f_4111:chicken_2dsyntax_2escm",(void*)f_4111},
{"f_7038:chicken_2dsyntax_2escm",(void*)f_7038},
{"f_6389:chicken_2dsyntax_2escm",(void*)f_6389},
{"f_4129:chicken_2dsyntax_2escm",(void*)f_4129},
{"f_11140:chicken_2dsyntax_2escm",(void*)f_11140},
{"f_6378:chicken_2dsyntax_2escm",(void*)f_6378},
{"f_6375:chicken_2dsyntax_2escm",(void*)f_6375},
{"f_7066:chicken_2dsyntax_2escm",(void*)f_7066},
{"f_6372:chicken_2dsyntax_2escm",(void*)f_6372},
{"f_11190:chicken_2dsyntax_2escm",(void*)f_11190},
{"f_6368:chicken_2dsyntax_2escm",(void*)f_6368},
{"f_6366:chicken_2dsyntax_2escm",(void*)f_6366},
{"f_10799:chicken_2dsyntax_2escm",(void*)f_10799},
{"f_5862:chicken_2dsyntax_2escm",(void*)f_5862},
{"f_6259:chicken_2dsyntax_2escm",(void*)f_6259},
{"f_8286:chicken_2dsyntax_2escm",(void*)f_8286},
{"f_8288:chicken_2dsyntax_2escm",(void*)f_8288},
{"f_6358:chicken_2dsyntax_2escm",(void*)f_6358},
{"f_6354:chicken_2dsyntax_2escm",(void*)f_6354},
{"f_8292:chicken_2dsyntax_2escm",(void*)f_8292},
{"f_8298:chicken_2dsyntax_2escm",(void*)f_8298},
{"f_8262:chicken_2dsyntax_2escm",(void*)f_8262},
{"f_7024:chicken_2dsyntax_2escm",(void*)f_7024},
{"f_7021:chicken_2dsyntax_2escm",(void*)f_7021},
{"f_7027:chicken_2dsyntax_2escm",(void*)f_7027},
{"f_7018:chicken_2dsyntax_2escm",(void*)f_7018},
{"f_5333:chicken_2dsyntax_2escm",(void*)f_5333},
{"f_5330:chicken_2dsyntax_2escm",(void*)f_5330},
{"f_5336:chicken_2dsyntax_2escm",(void*)f_5336},
{"f_7040:chicken_2dsyntax_2escm",(void*)f_7040},
{"f_5353:chicken_2dsyntax_2escm",(void*)f_5353},
{"f_5356:chicken_2dsyntax_2escm",(void*)f_5356},
{"f_5765:chicken_2dsyntax_2escm",(void*)f_5765},
{"f_5767:chicken_2dsyntax_2escm",(void*)f_5767},
{"f_5323:chicken_2dsyntax_2escm",(void*)f_5323},
{"f_5321:chicken_2dsyntax_2escm",(void*)f_5321},
{"f_5327:chicken_2dsyntax_2escm",(void*)f_5327},
{"f_4517:chicken_2dsyntax_2escm",(void*)f_4517},
{"f_5373:chicken_2dsyntax_2escm",(void*)f_5373},
{"f_7387:chicken_2dsyntax_2escm",(void*)f_7387},
{"f_9210:chicken_2dsyntax_2escm",(void*)f_9210},
{"f_9212:chicken_2dsyntax_2escm",(void*)f_9212},
{"f_5343:chicken_2dsyntax_2escm",(void*)f_5343},
{"f_5792:chicken_2dsyntax_2escm",(void*)f_5792},
{"f_5799:chicken_2dsyntax_2escm",(void*)f_5799},
{"f_5399:chicken_2dsyntax_2escm",(void*)f_5399},
{"f_4506:chicken_2dsyntax_2escm",(void*)f_4506},
{"f_4067:chicken_2dsyntax_2escm",(void*)f_4067},
{"f_4065:chicken_2dsyntax_2escm",(void*)f_4065},
{"f_5362:chicken_2dsyntax_2escm",(void*)f_5362},
{"f_4032:chicken_2dsyntax_2escm",(void*)f_4032},
{"f_7341:chicken_2dsyntax_2escm",(void*)f_7341},
{"f_7347:chicken_2dsyntax_2escm",(void*)f_7347},
{"f_4570:chicken_2dsyntax_2escm",(void*)f_4570},
{"f_4592:chicken_2dsyntax_2escm",(void*)f_4592},
{"f_7473:chicken_2dsyntax_2escm",(void*)f_7473},
{"f_11012:chicken_2dsyntax_2escm",(void*)f_11012},
{"f_7479:chicken_2dsyntax_2escm",(void*)f_7479},
{"f_11024:chicken_2dsyntax_2escm",(void*)f_11024},
{"f_9153:chicken_2dsyntax_2escm",(void*)f_9153},
{"f_11028:chicken_2dsyntax_2escm",(void*)f_11028},
{"f_7467:chicken_2dsyntax_2escm",(void*)f_7467},
{"f_7411:chicken_2dsyntax_2escm",(void*)f_7411},
{"f_7419:chicken_2dsyntax_2escm",(void*)f_7419},
{"f_9140:chicken_2dsyntax_2escm",(void*)f_9140},
{"f_4586:chicken_2dsyntax_2escm",(void*)f_4586},
{"f_4588:chicken_2dsyntax_2escm",(void*)f_4588},
{"f_9137:chicken_2dsyntax_2escm",(void*)f_9137},
{"f_7430:chicken_2dsyntax_2escm",(void*)f_7430},
{"f_7433:chicken_2dsyntax_2escm",(void*)f_7433},
{"f_9122:chicken_2dsyntax_2escm",(void*)f_9122},
{"f_9125:chicken_2dsyntax_2escm",(void*)f_9125},
{"f_9129:chicken_2dsyntax_2escm",(void*)f_9129},
{"f_7427:chicken_2dsyntax_2escm",(void*)f_7427},
{"f_9110:chicken_2dsyntax_2escm",(void*)f_9110},
{"f_9114:chicken_2dsyntax_2escm",(void*)f_9114},
{"f_8547:chicken_2dsyntax_2escm",(void*)f_8547},
{"f_9104:chicken_2dsyntax_2escm",(void*)f_9104},
{"f_4028:chicken_2dsyntax_2escm",(void*)f_4028},
{"f_3826:chicken_2dsyntax_2escm",(void*)f_3826},
{"f_3828:chicken_2dsyntax_2escm",(void*)f_3828},
{"f_8525:chicken_2dsyntax_2escm",(void*)f_8525},
{"f_8529:chicken_2dsyntax_2escm",(void*)f_8529},
{"f_8535:chicken_2dsyntax_2escm",(void*)f_8535},
{"f_10099:chicken_2dsyntax_2escm",(void*)f_10099},
{"f_8536:chicken_2dsyntax_2escm",(void*)f_8536},
{"f_10568:chicken_2dsyntax_2escm",(void*)f_10568},
{"f_3853:chicken_2dsyntax_2escm",(void*)f_3853},
{"f_7960:chicken_2dsyntax_2escm",(void*)f_7960},
{"f_7962:chicken_2dsyntax_2escm",(void*)f_7962},
{"f_7966:chicken_2dsyntax_2escm",(void*)f_7966},
{"f_9797:chicken_2dsyntax_2escm",(void*)f_9797},
{"f_9794:chicken_2dsyntax_2escm",(void*)f_9794},
{"f_9791:chicken_2dsyntax_2escm",(void*)f_9791},
{"f_10545:chicken_2dsyntax_2escm",(void*)f_10545},
{"f_4554:chicken_2dsyntax_2escm",(void*)f_4554},
{"f_4550:chicken_2dsyntax_2escm",(void*)f_4550},
{"f_3874:chicken_2dsyntax_2escm",(void*)f_3874},
{"f_3872:chicken_2dsyntax_2escm",(void*)f_3872},
{"f_9788:chicken_2dsyntax_2escm",(void*)f_9788},
{"f_3884:chicken_2dsyntax_2escm",(void*)f_3884},
{"f_7987:chicken_2dsyntax_2escm",(void*)f_7987},
{"f_9779:chicken_2dsyntax_2escm",(void*)f_9779},
{"f_9775:chicken_2dsyntax_2escm",(void*)f_9775},
{"f_9773:chicken_2dsyntax_2escm",(void*)f_9773},
{"f_10041:chicken_2dsyntax_2escm",(void*)f_10041},
{"f_3897:chicken_2dsyntax_2escm",(void*)f_3897},
{"f_3893:chicken_2dsyntax_2escm",(void*)f_3893},
{"f_6818:chicken_2dsyntax_2escm",(void*)f_6818},
{"f_4092:chicken_2dsyntax_2escm",(void*)f_4092},
{"f_7922:chicken_2dsyntax_2escm",(void*)f_7922},
{"f_10271:chicken_2dsyntax_2escm",(void*)f_10271},
{"f_4548:chicken_2dsyntax_2escm",(void*)f_4548},
{"f_7710:chicken_2dsyntax_2escm",(void*)f_7710},
{"f_7713:chicken_2dsyntax_2escm",(void*)f_7713},
{"f_7958:chicken_2dsyntax_2escm",(void*)f_7958},
{"f_9694:chicken_2dsyntax_2escm",(void*)f_9694},
{"f_7707:chicken_2dsyntax_2escm",(void*)f_7707},
{"f_8899:chicken_2dsyntax_2escm",(void*)f_8899},
{"f_9737:chicken_2dsyntax_2escm",(void*)f_9737},
{"f_9660:chicken_2dsyntax_2escm",(void*)f_9660},
{"f_8583:chicken_2dsyntax_2escm",(void*)f_8583},
{"f_7978:chicken_2dsyntax_2escm",(void*)f_7978},
{"f_7975:chicken_2dsyntax_2escm",(void*)f_7975},
{"f_7726:chicken_2dsyntax_2escm",(void*)f_7726},
{"f_7724:chicken_2dsyntax_2escm",(void*)f_7724},
{"f_8513:chicken_2dsyntax_2escm",(void*)f_8513},
{"f_8510:chicken_2dsyntax_2escm",(void*)f_8510},
{"f_8517:chicken_2dsyntax_2escm",(void*)f_8517},
{"f_9669:chicken_2dsyntax_2escm",(void*)f_9669},
{"f_6693:chicken_2dsyntax_2escm",(void*)f_6693},
{"f_8562:chicken_2dsyntax_2escm",(void*)f_8562},
{"f_8564:chicken_2dsyntax_2escm",(void*)f_8564},
{"f_9993:chicken_2dsyntax_2escm",(void*)f_9993},
{"f_3561:chicken_2dsyntax_2escm",(void*)f_3561},
{"f_9983:chicken_2dsyntax_2escm",(void*)f_9983},
{"f_3570:chicken_2dsyntax_2escm",(void*)f_3570},
{"f_3573:chicken_2dsyntax_2escm",(void*)f_3573},
{"f_3564:chicken_2dsyntax_2escm",(void*)f_3564},
{"f_10529:chicken_2dsyntax_2escm",(void*)f_10529},
{"f_3567:chicken_2dsyntax_2escm",(void*)f_3567},
{"f_10527:chicken_2dsyntax_2escm",(void*)f_10527},
{"f_3582:chicken_2dsyntax_2escm",(void*)f_3582},
{"f_7938:chicken_2dsyntax_2escm",(void*)f_7938},
{"f_9635:chicken_2dsyntax_2escm",(void*)f_9635},
{"f_9971:chicken_2dsyntax_2escm",(void*)f_9971},
{"f_3576:chicken_2dsyntax_2escm",(void*)f_3576},
{"f_3579:chicken_2dsyntax_2escm",(void*)f_3579},
{"f_9967:chicken_2dsyntax_2escm",(void*)f_9967},
{"f_3592:chicken_2dsyntax_2escm",(void*)f_3592},
{"f_9626:chicken_2dsyntax_2escm",(void*)f_9626},
{"f_3586:chicken_2dsyntax_2escm",(void*)f_3586},
{"f_3589:chicken_2dsyntax_2escm",(void*)f_3589},
{"f_7793:chicken_2dsyntax_2escm",(void*)f_7793},
{"f_9955:chicken_2dsyntax_2escm",(void*)f_9955},
{"f_6505:chicken_2dsyntax_2escm",(void*)f_6505},
{"f_8158:chicken_2dsyntax_2escm",(void*)f_8158},
{"f_10269:chicken_2dsyntax_2escm",(void*)f_10269},
{"f_10260:chicken_2dsyntax_2escm",(void*)f_10260},
{"f_6866:chicken_2dsyntax_2escm",(void*)f_6866},
{"f_3595:chicken_2dsyntax_2escm",(void*)f_3595},
{"f_3598:chicken_2dsyntax_2escm",(void*)f_3598},
{"f_10533:chicken_2dsyntax_2escm",(void*)f_10533},
{"f_10253:chicken_2dsyntax_2escm",(void*)f_10253},
{"f_6477:chicken_2dsyntax_2escm",(void*)f_6477},
{"f_3733:chicken_2dsyntax_2escm",(void*)f_3733},
{"f_6491:chicken_2dsyntax_2escm",(void*)f_6491},
{"f_8130:chicken_2dsyntax_2escm",(void*)f_8130},
{"f_8136:chicken_2dsyntax_2escm",(void*)f_8136},
{"f_10244:chicken_2dsyntax_2escm",(void*)f_10244},
{"f_9931:chicken_2dsyntax_2escm",(void*)f_9931},
{"f_6481:chicken_2dsyntax_2escm",(void*)f_6481},
{"f_9924:chicken_2dsyntax_2escm",(void*)f_9924},
{"f_8106:chicken_2dsyntax_2escm",(void*)f_8106},
{"f_3755:chicken_2dsyntax_2escm",(void*)f_3755},
{"f_9921:chicken_2dsyntax_2escm",(void*)f_9921},
{"f_3751:chicken_2dsyntax_2escm",(void*)f_3751},
{"f_5984:chicken_2dsyntax_2escm",(void*)f_5984},
{"f_7751:chicken_2dsyntax_2escm",(void*)f_7751},
{"f_7757:chicken_2dsyntax_2escm",(void*)f_7757},
{"f_8062:chicken_2dsyntax_2escm",(void*)f_8062},
{"f_8064:chicken_2dsyntax_2escm",(void*)f_8064},
{"f_8068:chicken_2dsyntax_2escm",(void*)f_8068},
{"f_8110:chicken_2dsyntax_2escm",(void*)f_8110},
{"f_8112:chicken_2dsyntax_2escm",(void*)f_8112},
{"f_8116:chicken_2dsyntax_2escm",(void*)f_8116},
{"f_6485:chicken_2dsyntax_2escm",(void*)f_6485},
{"f_6487:chicken_2dsyntax_2escm",(void*)f_6487},
{"f_5997:chicken_2dsyntax_2escm",(void*)f_5997},
{"f_5999:chicken_2dsyntax_2escm",(void*)f_5999},
{"f_6572:chicken_2dsyntax_2escm",(void*)f_6572},
{"f_6315:chicken_2dsyntax_2escm",(void*)f_6315},
{"f_7771:chicken_2dsyntax_2escm",(void*)f_7771},
{"f_6829:chicken_2dsyntax_2escm",(void*)f_6829},
{"f_7774:chicken_2dsyntax_2escm",(void*)f_7774},
{"f_7778:chicken_2dsyntax_2escm",(void*)f_7778},
{"f_7760:chicken_2dsyntax_2escm",(void*)f_7760},
{"f_8050:chicken_2dsyntax_2escm",(void*)f_8050},
{"f_6558:chicken_2dsyntax_2escm",(void*)f_6558},
{"f_6586:chicken_2dsyntax_2escm",(void*)f_6586},
{"f_6535:chicken_2dsyntax_2escm",(void*)f_6535},
{"f_8007:chicken_2dsyntax_2escm",(void*)f_8007},
{"f_4241:chicken_2dsyntax_2escm",(void*)f_4241},
{"f_8003:chicken_2dsyntax_2escm",(void*)f_8003},
{"f_3540:chicken_2dsyntax_2escm",(void*)f_3540},
{"f_8382:chicken_2dsyntax_2escm",(void*)f_8382},
{"f_4239:chicken_2dsyntax_2escm",(void*)f_4239},
{"f_8387:chicken_2dsyntax_2escm",(void*)f_8387},
{"f_6560:chicken_2dsyntax_2escm",(void*)f_6560},
{"f_6566:chicken_2dsyntax_2escm",(void*)f_6566},
{"f_6564:chicken_2dsyntax_2escm",(void*)f_6564},
{"f_6715:chicken_2dsyntax_2escm",(void*)f_6715},
{"f_6717:chicken_2dsyntax_2escm",(void*)f_6717},
{"f_3536:chicken_2dsyntax_2escm",(void*)f_3536},
{"f_6270:chicken_2dsyntax_2escm",(void*)f_6270},
{"f_3549:chicken_2dsyntax_2escm",(void*)f_3549},
{"f_3546:chicken_2dsyntax_2escm",(void*)f_3546},
{"f_3543:chicken_2dsyntax_2escm",(void*)f_3543},
{"f_6266:chicken_2dsyntax_2escm",(void*)f_6266},
{"f_5141:chicken_2dsyntax_2escm",(void*)f_5141},
{"f_9703:chicken_2dsyntax_2escm",(void*)f_9703},
{"f_3558:chicken_2dsyntax_2escm",(void*)f_3558},
{"f_3555:chicken_2dsyntax_2escm",(void*)f_3555},
{"f_3552:chicken_2dsyntax_2escm",(void*)f_3552},
{"f_7919:chicken_2dsyntax_2escm",(void*)f_7919},
{"f_7904:chicken_2dsyntax_2escm",(void*)f_7904},
{"f_6765:chicken_2dsyntax_2escm",(void*)f_6765},
{"f_6918:chicken_2dsyntax_2escm",(void*)f_6918},
{"f_4251:chicken_2dsyntax_2escm",(void*)f_4251},
{"f_6234:chicken_2dsyntax_2escm",(void*)f_6234},
{"f_8228:chicken_2dsyntax_2escm",(void*)f_8228},
{"f_6908:chicken_2dsyntax_2escm",(void*)f_6908},
{"f_11215:chicken_2dsyntax_2escm",(void*)f_11215},
{"f_5104:chicken_2dsyntax_2escm",(void*)f_5104},
{"f_4268:chicken_2dsyntax_2escm",(void*)f_4268},
{"f_10814:chicken_2dsyntax_2escm",(void*)f_10814},
{"f_8209:chicken_2dsyntax_2escm",(void*)f_8209},
{"f_9601:chicken_2dsyntax_2escm",(void*)f_9601},
{"f_11226:chicken_2dsyntax_2escm",(void*)f_11226},
{"f_11228:chicken_2dsyntax_2escm",(void*)f_11228},
{"f_5114:chicken_2dsyntax_2escm",(void*)f_5114},
{"f_10884:chicken_2dsyntax_2escm",(void*)f_10884},
{"f_10887:chicken_2dsyntax_2escm",(void*)f_10887},
{"f_10881:chicken_2dsyntax_2escm",(void*)f_10881},
{"f_5128:chicken_2dsyntax_2escm",(void*)f_5128},
{"f_10878:chicken_2dsyntax_2escm",(void*)f_10878},
{"f_10870:chicken_2dsyntax_2escm",(void*)f_10870},
{"f_10866:chicken_2dsyntax_2escm",(void*)f_10866},
{"f_10864:chicken_2dsyntax_2escm",(void*)f_10864},
{"f_4299:chicken_2dsyntax_2escm",(void*)f_4299},
{"f_9913:chicken_2dsyntax_2escm",(void*)f_9913},
{"f_9909:chicken_2dsyntax_2escm",(void*)f_9909},
{"f_9906:chicken_2dsyntax_2escm",(void*)f_9906},
{"f_5389:chicken_2dsyntax_2escm",(void*)f_5389},
{"f_11232:chicken_2dsyntax_2escm",(void*)f_11232},
{"f_7361:chicken_2dsyntax_2escm",(void*)f_7361},
{"f_5941:chicken_2dsyntax_2escm",(void*)f_5941},
{"f_7319:chicken_2dsyntax_2escm",(void*)f_7319},
{"f_9435:chicken_2dsyntax_2escm",(void*)f_9435},
{"f_10891:chicken_2dsyntax_2escm",(void*)f_10891},
{"f_7301:chicken_2dsyntax_2escm",(void*)f_7301},
{"f_4309:chicken_2dsyntax_2escm",(void*)f_4309},
{"f_4307:chicken_2dsyntax_2escm",(void*)f_4307},
{"f_7331:chicken_2dsyntax_2escm",(void*)f_7331},
{"f_7327:chicken_2dsyntax_2escm",(void*)f_7327},
{"f_9442:chicken_2dsyntax_2escm",(void*)f_9442},
{"f_5202:chicken_2dsyntax_2escm",(void*)f_5202},
{"f_4601:chicken_2dsyntax_2escm",(void*)f_4601},
{"f_5212:chicken_2dsyntax_2escm",(void*)f_5212},
{"f_5210:chicken_2dsyntax_2escm",(void*)f_5210},
{"f_5216:chicken_2dsyntax_2escm",(void*)f_5216},
{"f_7165:chicken_2dsyntax_2escm",(void*)f_7165},
{"f_7162:chicken_2dsyntax_2escm",(void*)f_7162},
{"f_5262:chicken_2dsyntax_2escm",(void*)f_5262},
{"f_4609:chicken_2dsyntax_2escm",(void*)f_4609},
{"f_4289:chicken_2dsyntax_2escm",(void*)f_4289},
{"f_4369:chicken_2dsyntax_2escm",(void*)f_4369},
{"f_7195:chicken_2dsyntax_2escm",(void*)f_7195},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  foldl		1
S|  for-each		1
S|  ##sys#map		11
S|  map		36
o|eliminated procedure checks: 686 
o|specializations:
o|  1 (caddr (pair * (pair * pair)))
o|  1 (= fixnum fixnum)
o|  3 (cadr (pair * pair))
o|  1 (zero? fixnum)
o|  3 (length list)
o|  29 (##sys#check-list (or pair list) *)
o|  6 (cdddr (pair * (pair * pair)))
o|  2 (string-append string string)
o|  49 (cdr pair)
o|  20 (car pair)
o|  17 (cddr (pair * pair))
(o e)|safe calls: 1099 
o|Removed `not' forms: 12 
o|contracted procedure: k3699 
o|inlining procedure: k3696 
o|inlining procedure: k3696 
o|inlining procedure: k3809 
o|inlining procedure: k3809 
o|inlining procedure: k3830 
o|inlining procedure: k3830 
o|contracted procedure: k3879 
o|inlining procedure: k3876 
o|inlining procedure: k3916 
o|inlining procedure: k3972 
o|contracted procedure: "(chicken-syntax.scm:1257) g24652475" 
o|inlining procedure: k3972 
o|inlining procedure: k4042 
o|inlining procedure: k4069 
o|contracted procedure: "(chicken-syntax.scm:1248) g24282437" 
o|propagated global variable: g24452446 ##compiler#check-and-validate-type 
o|inlining procedure: k4069 
o|inlining procedure: k4042 
o|inlining procedure: k4113 
o|inlining procedure: k4113 
o|inlining procedure: k3916 
o|inlining procedure: k4160 
o|inlining procedure: k4160 
o|inlining procedure: k4197 
o|inlining procedure: k4197 
o|inlining procedure: k3876 
o|inlining procedure: k4246 
o|inlining procedure: k4337 
o|contracted procedure: "(chicken-syntax.scm:1210) g23622371" 
o|inlining procedure: k4337 
o|inlining procedure: k4371 
o|contracted procedure: "(chicken-syntax.scm:1210) g23342343" 
o|inlining procedure: k4371 
o|inlining procedure: k4246 
o|inlining procedure: k4408 
o|inlining procedure: k4423 
o|inlining procedure: k4439 
o|inlining procedure: k4439 
o|inlining procedure: k4423 
o|inlining procedure: k4408 
o|inlining procedure: k4473 
o|inlining procedure: k4489 
o|inlining procedure: k4489 
o|inlining procedure: k4524 
o|inlining procedure: k4524 
o|inlining procedure: k4473 
o|contracted procedure: k4558 
o|inlining procedure: k4555 
o|inlining procedure: k4555 
o|contracted procedure: k4596 
o|inlining procedure: k4593 
o|contracted procedure: k4624 
o|inlining procedure: k4621 
o|inlining procedure: k4650 
o|inlining procedure: k4650 
o|inlining procedure: k4621 
o|inlining procedure: k4593 
o|inlining procedure: k4763 
o|inlining procedure: k4763 
o|inlining procedure: k4778 
o|inlining procedure: k4790 
o|inlining procedure: k4790 
o|substituted constant variable: a4807 
o|inlining procedure: k4778 
o|inlining procedure: k4823 
o|inlining procedure: k4823 
o|inlining procedure: k4896 
o|inlining procedure: k4896 
o|inlining procedure: k4911 
o|inlining procedure: k4911 
o|inlining procedure: k4951 
o|inlining procedure: k4951 
o|inlining procedure: k4980 
o|inlining procedure: k4995 
o|inlining procedure: k5011 
o|inlining procedure: k5011 
o|inlining procedure: k4995 
o|inlining procedure: k4980 
o|inlining procedure: k5045 
o|inlining procedure: k5061 
o|inlining procedure: k5061 
o|inlining procedure: k5045 
o|inlining procedure: k5099 
o|inlining procedure: k5099 
o|inlining procedure: k5163 
o|inlining procedure: k5163 
o|inlining procedure: k5266 
o|inlining procedure: k5266 
o|inlining procedure: k5345 
o|inlining procedure: k5345 
o|inlining procedure: k5443 
o|inlining procedure: k5443 
o|inlining procedure: k5544 
o|inlining procedure: k5544 
o|inlining procedure: k5638 
o|inlining procedure: k5638 
o|inlining procedure: k5769 
o|inlining procedure: k5769 
o|inlining procedure: k5818 
o|contracted procedure: k5824 
o|inlining procedure: k5818 
o|inlining procedure: k5857 
o|inlining procedure: k5857 
o|inlining procedure: k5930 
o|inlining procedure: k5930 
o|inlining procedure: k5986 
o|inlining procedure: k5986 
o|inlining procedure: k6001 
o|inlining procedure: k6001 
o|inlining procedure: k6035 
o|inlining procedure: k6035 
o|inlining procedure: k6115 
o|inlining procedure: k6115 
o|inlining procedure: k6157 
o|inlining procedure: k6157 
o|inlining procedure: k6272 
o|inlining procedure: k6272 
o|inlining procedure: k6292 
o|inlining procedure: k6292 
o|inlining procedure: k6497 
o|inlining procedure: k6497 
o|inlining procedure: k6574 
o|inlining procedure: k6574 
o|inlining procedure: k6694 
o|inlining procedure: k6694 
o|inlining procedure: k6719 
o|inlining procedure: k6719 
o|inlining procedure: k6767 
o|inlining procedure: k6795 
o|inlining procedure: k6795 
o|inlining procedure: k6767 
o|inlining procedure: k6827 
o|inlining procedure: k6827 
o|inlining procedure: k6867 
o|inlining procedure: k6867 
o|inlining procedure: k6922 
o|contracted procedure: "(chicken-syntax.scm:773) g16371646" 
o|inlining procedure: k6922 
o|inlining procedure: k7042 
o|inlining procedure: k7042 
o|removed unused formal parameters: (rename1432) 
o|inlining procedure: k7349 
o|inlining procedure: k7349 
o|removed unused parameter to known procedure: rename1432 "(chicken-syntax.scm:676) make-if-tree1412" 
o|contracted procedure: "(chicken-syntax.scm:674) make-default-procs1411" 
o|inlining procedure: k7282 
o|inlining procedure: k7282 
o|inlining procedure: k7541 
o|inlining procedure: k7541 
o|inlining procedure: k7575 
o|inlining procedure: k7575 
o|inlining procedure: k7609 
o|inlining procedure: k7609 
o|inlining procedure: k7643 
o|inlining procedure: k7643 
o|inlining procedure: k7728 
o|inlining procedure: k7728 
o|contracted procedure: k7737 
o|inlining procedure: k7752 
o|inlining procedure: k7752 
o|inlining procedure: k7815 
o|inlining procedure: k7815 
o|inlining procedure: k7879 
o|inlining procedure: k7879 
o|contracted procedure: k7895 
o|inlining procedure: k7905 
o|inlining procedure: k7905 
o|inlining procedure: k7976 
o|inlining procedure: k7976 
o|contracted procedure: k7994 
o|inlining procedure: k7991 
o|inlining procedure: k7991 
o|inlining procedure: k8182 
o|inlining procedure: k8182 
o|inlining procedure: k8230 
o|contracted procedure: "(chicken-syntax.scm:434) g12001209" 
o|inlining procedure: k8230 
o|inlining procedure: k8264 
o|contracted procedure: "(chicken-syntax.scm:435) g12241225" 
o|inlining procedure: k8264 
o|substituted constant variable: g12161219 
o|inlining procedure: k8300 
o|inlining procedure: k8300 
o|inlining procedure: k8334 
o|inlining procedure: k8334 
o|inlining procedure: k8389 
o|inlining procedure: k8389 
o|contracted procedure: k8439 
o|inlining procedure: k8436 
o|inlining procedure: k8436 
o|inlining procedure: k8464 
o|inlining procedure: k8464 
o|contracted procedure: k8473 
o|inlining procedure: k8566 
o|inlining procedure: k8601 
o|inlining procedure: k8601 
o|inlining procedure: k8566 
o|inlining procedure: k8715 
o|contracted procedure: "(chicken-syntax.scm:392) g10921101" 
o|inlining procedure: k8715 
o|inlining procedure: k8749 
o|inlining procedure: k8749 
o|contracted procedure: k8769 
o|inlining procedure: k8793 
o|inlining procedure: k8793 
o|inlining procedure: k8827 
o|inlining procedure: k8827 
o|inlining procedure: k8850 
o|inlining procedure: k8850 
o|inlining procedure: k8865 
o|inlining procedure: k8865 
o|inlining procedure: k8946 
o|contracted procedure: "(chicken-syntax.scm:348) g919926" 
o|inlining procedure: k8946 
o|contracted procedure: "(chicken-syntax.scm:287) pname530" 
o|inlining procedure: k9049 
o|inlining procedure: k9049 
o|removed unused formal parameters: (z639) 
o|removed unused formal parameters: (z667) 
o|inlining procedure: k9214 
o|contracted procedure: "(chicken-syntax.scm:313) g862872" 
o|inlining procedure: k9214 
o|inlining procedure: k9341 
o|contracted procedure: "(chicken-syntax.scm:307) g826836" 
o|inlining procedure: k9341 
o|inlining procedure: k9389 
o|contracted procedure: "(chicken-syntax.scm:304) g790800" 
o|inlining procedure: k9389 
o|inlining procedure: k9437 
o|inlining procedure: k9437 
o|inlining procedure: k9487 
o|inlining procedure: k9487 
o|inlining procedure: k9507 
o|inlining procedure: k9507 
o|inlining procedure: k9555 
o|inlining procedure: k9555 
o|inlining procedure: k9603 
o|removed unused parameter to known procedure: z667 "(chicken-syntax.scm:289) g656665" 
o|inlining procedure: k9603 
o|inlining procedure: k9637 
o|removed unused parameter to known procedure: z639 "(chicken-syntax.scm:288) g628637" 
o|inlining procedure: k9637 
o|inlining procedure: k9671 
o|inlining procedure: k9671 
o|inlining procedure: k9705 
o|inlining procedure: k9705 
o|inlining procedure: k9739 
o|inlining procedure: k9739 
o|inlining procedure: k9798 
o|inlining procedure: k9813 
o|inlining procedure: k9813 
o|inlining procedure: k9798 
o|inlining procedure: k9828 
o|inlining procedure: k9849 
o|inlining procedure: k9849 
o|inlining procedure: k9828 
o|removed unused formal parameters: (x216) 
o|removed unused formal parameters: (x244) 
o|inlining procedure: k9995 
o|contracted procedure: "(chicken-syntax.scm:237) g462472" 
o|inlining procedure: k9995 
o|inlining procedure: k10043 
o|contracted procedure: "(chicken-syntax.scm:235) g426436" 
o|inlining procedure: k10043 
o|inlining procedure: k10142 
o|contracted procedure: "(chicken-syntax.scm:230) g390400" 
o|inlining procedure: k10142 
o|inlining procedure: k10190 
o|contracted procedure: "(chicken-syntax.scm:228) g354364" 
o|inlining procedure: k10190 
o|inlining procedure: k10273 
o|inlining procedure: k10273 
o|inlining procedure: k10323 
o|inlining procedure: k10323 
o|inlining procedure: k10343 
o|inlining procedure: k10343 
o|inlining procedure: k10391 
o|inlining procedure: k10391 
o|inlining procedure: k10425 
o|removed unused parameter to known procedure: x244 "(chicken-syntax.scm:218) g233242" 
o|inlining procedure: k10425 
o|inlining procedure: k10459 
o|removed unused parameter to known procedure: x216 "(chicken-syntax.scm:217) g205214" 
o|inlining procedure: k10459 
o|inlining procedure: k10493 
o|inlining procedure: k10493 
o|inlining procedure: k10570 
o|inlining procedure: k10570 
o|inlining procedure: k10647 
o|inlining procedure: k10647 
o|inlining procedure: k10675 
o|inlining procedure: k10675 
o|inlining procedure: k10778 
o|inlining procedure: k10778 
o|inlining procedure: k10893 
o|inlining procedure: k10893 
o|inlining procedure: k10914 
o|inlining procedure: k10926 
o|inlining procedure: k10926 
o|inlining procedure: k10914 
o|inlining procedure: k10978 
o|inlining procedure: k10978 
o|inlining procedure: k11038 
o|inlining procedure: k11038 
o|inlining procedure: k11127 
o|inlining procedure: k11127 
o|substituted constant variable: a11162 
o|substituted constant variable: a11187 
o|inlining procedure: k11192 
o|inlining procedure: k11192 
o|replaced variables: 1142 
o|removed binding forms: 409 
o|substituted constant variable: r369711241 
o|substituted constant variable: r411411256 
o|substituted constant variable: r419811262 
o|substituted constant variable: r387711263 
o|substituted constant variable: r442411274 
o|substituted constant variable: r440911275 
o|substituted constant variable: r452511280 
o|substituted constant variable: r447411281 
o|substituted constant variable: r465111288 
o|substituted constant variable: r465111288 
o|substituted constant variable: r459411291 
o|substituted constant variable: r479111304 
o|substituted constant variable: r477911305 
o|substituted constant variable: r489711308 
o|substituted constant variable: r489711308 
o|substituted constant variable: r499611320 
o|substituted constant variable: r498111321 
o|substituted constant variable: r504611325 
o|substituted constant variable: r516411329 
o|substituted constant variable: r577011340 
o|substituted constant variable: r593111349 
o|substituted constant variable: r598711351 
o|substituted constant variable: r627311360 
o|substituted constant variable: r627311360 
o|converted assignments to bindings: (parse-clause1788) 
o|substituted constant variable: r657511368 
o|substituted constant variable: r686811382 
o|converted assignments to bindings: (genvars1623) 
o|substituted constant variable: r728311390 
o|converted assignments to bindings: (make-if-tree1412) 
o|substituted constant variable: r772911400 
o|substituted constant variable: r799211420 
o|substituted constant variable: r846511436 
o|substituted constant variable: r948811467 
o|substituted constant variable: r1032411500 
o|substituted constant variable: r1067611521 
o|substituted constant variable: r1092711528 
o|substituted constant variable: r1091511529 
o|simplifications: ((let . 3)) 
o|replaced variables: 21 
o|removed binding forms: 1233 
o|removed call to pure procedure with unused result: "(chicken-syntax.scm:289) slot" 
o|removed call to pure procedure with unused result: "(chicken-syntax.scm:288) slot" 
o|inlining procedure: k9835 
o|inlining procedure: k9835 
o|inlining procedure: k9835 
o|removed call to pure procedure with unused result: "(chicken-syntax.scm:218) slot" 
o|removed call to pure procedure with unused result: "(chicken-syntax.scm:217) slot" 
o|replaced variables: 38 
o|removed binding forms: 58 
o|contracted procedure: k9628 
o|contracted procedure: k9662 
o|contracted procedure: k10450 
o|contracted procedure: k10484 
o|removed binding forms: 44 
o|removed binding forms: 4 
o|simplifications: ((if . 28) (##core#call . 1203)) 
o|  call simplifications:
o|    string?
o|    cdar
o|    caar
o|    not	3
o|    apply
o|    fx-	2
o|    fx>=
o|    assq	2
o|    cddddr
o|    cddr	6
o|    add1
o|    ##sys#call-with-values	2
o|    ##sys#pair?	7
o|    ##sys#eq?	7
o|    ##sys#car	15
o|    ##sys#cdr	22
o|    cdddr	2
o|    cadddr	2
o|    list?	4
o|    fx=
o|    symbol?	11
o|    null?	30
o|    vector
o|    cdr	18
o|    fx+	3
o|    ##sys#check-list	36
o|    pair?	90
o|    cons	122
o|    ##sys#setslot	47
o|    ##sys#slot	182
o|    car	47
o|    eq?	8
o|    list	9
o|    ##sys#cons	141
o|    memq	7
o|    cadr	51
o|    caddr	17
o|    ##sys#list	301
o|contracted procedure: k3743 
o|contracted procedure: k3719 
o|contracted procedure: k3723 
o|contracted procedure: k3727 
o|contracted procedure: k3715 
o|contracted procedure: k3735 
o|contracted procedure: k3739 
o|contracted procedure: k3756 
o|contracted procedure: k3866 
o|contracted procedure: k3862 
o|contracted procedure: k3769 
o|contracted procedure: k3785 
o|contracted procedure: k3801 
o|contracted procedure: k3806 
o|contracted procedure: k3816 
o|contracted procedure: k3821 
o|contracted procedure: k3781 
o|contracted procedure: k3777 
o|contracted procedure: k3773 
o|contracted procedure: k3833 
o|contracted procedure: k3836 
o|contracted procedure: k3839 
o|contracted procedure: k3847 
o|contracted procedure: k3855 
o|contracted procedure: k4233 
o|contracted procedure: k3885 
o|contracted procedure: k3888 
o|contracted procedure: k3907 
o|contracted procedure: k3919 
o|contracted procedure: k3928 
o|contracted procedure: k4018 
o|contracted procedure: k4022 
o|contracted procedure: k3938 
o|contracted procedure: k3946 
o|contracted procedure: k3954 
o|contracted procedure: k3950 
o|contracted procedure: k3942 
o|contracted procedure: k4011 
o|contracted procedure: k3975 
o|contracted procedure: k3978 
o|contracted procedure: k3981 
o|contracted procedure: k3989 
o|contracted procedure: k3993 
o|contracted procedure: k4001 
o|contracted procedure: k4005 
o|contracted procedure: k3963 
o|contracted procedure: k4038 
o|contracted procedure: k4034 
o|contracted procedure: k4045 
o|contracted procedure: k4052 
o|contracted procedure: k4060 
o|contracted procedure: k4072 
o|contracted procedure: k4075 
o|contracted procedure: k4078 
o|contracted procedure: k4086 
o|contracted procedure: k4094 
o|contracted procedure: k4116 
o|contracted procedure: k4123 
o|contracted procedure: k4131 
o|contracted procedure: k4135 
o|contracted procedure: k4138 
o|contracted procedure: k4144 
o|contracted procedure: k4153 
o|contracted procedure: k4157 
o|contracted procedure: k4188 
o|contracted procedure: k4172 
o|contracted procedure: k4176 
o|contracted procedure: k4184 
o|contracted procedure: k4194 
o|contracted procedure: k4200 
o|contracted procedure: k4207 
o|contracted procedure: k4229 
o|contracted procedure: k4218 
o|contracted procedure: k4243 
o|contracted procedure: k4252 
o|contracted procedure: k4260 
o|contracted procedure: k4263 
o|contracted procedure: k4269 
o|contracted procedure: k4281 
o|contracted procedure: k4284 
o|contracted procedure: k4290 
o|contracted procedure: k4301 
o|contracted procedure: k4331 
o|contracted procedure: k4327 
o|contracted procedure: k4319 
o|contracted procedure: k4315 
o|contracted procedure: k4340 
o|contracted procedure: k4343 
o|contracted procedure: k4346 
o|contracted procedure: k4354 
o|contracted procedure: k4362 
o|contracted procedure: k4278 
o|contracted procedure: k4374 
o|contracted procedure: k4396 
o|contracted procedure: k4392 
o|contracted procedure: k4377 
o|contracted procedure: k4380 
o|contracted procedure: k4388 
o|contracted procedure: k4405 
o|contracted procedure: k4433 
o|contracted procedure: k4452 
o|contracted procedure: k4460 
o|contracted procedure: k4464 
o|contracted procedure: k4483 
o|contracted procedure: k4501 
o|contracted procedure: k4511 
o|contracted procedure: k4518 
o|contracted procedure: k4521 
o|contracted procedure: k4527 
o|contracted procedure: k4534 
o|contracted procedure: k4538 
o|contracted procedure: k4542 
o|contracted procedure: k4580 
o|contracted procedure: k4572 
o|contracted procedure: k4576 
o|contracted procedure: k4688 
o|contracted procedure: k4602 
o|contracted procedure: k4680 
o|contracted procedure: k4676 
o|contracted procedure: k4672 
o|contracted procedure: k4638 
o|contracted procedure: k4634 
o|contracted procedure: k4661 
o|contracted procedure: k4657 
o|contracted procedure: k4650 
o|contracted procedure: k4668 
o|contracted procedure: k4684 
o|contracted procedure: k4704 
o|contracted procedure: k4707 
o|contracted procedure: k4711 
o|contracted procedure: k4732 
o|contracted procedure: k4752 
o|contracted procedure: k4757 
o|contracted procedure: k4769 
o|contracted procedure: k4781 
o|contracted procedure: k4787 
o|contracted procedure: k4804 
o|contracted procedure: k4793 
o|contracted procedure: k4800 
o|contracted procedure: k4811 
o|contracted procedure: k4814 
o|contracted procedure: k4736 
o|contracted procedure: k4740 
o|contracted procedure: k4744 
o|contracted procedure: k4717 
o|contracted procedure: k4724 
o|contracted procedure: k4728 
o|contracted procedure: k4826 
o|contracted procedure: k4829 
o|contracted procedure: k4832 
o|contracted procedure: k4840 
o|contracted procedure: k4848 
o|contracted procedure: k4881 
o|contracted procedure: k4885 
o|contracted procedure: k4877 
o|contracted procedure: k4899 
o|contracted procedure: k4905 
o|inlining procedure: k4896 
o|contracted procedure: k4914 
o|contracted procedure: k4924 
o|contracted procedure: k4928 
o|contracted procedure: k4931 
o|contracted procedure: k4938 
o|contracted procedure: k4948 
o|contracted procedure: k4957 
o|contracted procedure: k4960 
o|contracted procedure: k4971 
o|contracted procedure: k4977 
o|contracted procedure: k5005 
o|contracted procedure: k5024 
o|contracted procedure: k5032 
o|contracted procedure: k5036 
o|contracted procedure: k5055 
o|contracted procedure: k5074 
o|contracted procedure: k5082 
o|contracted procedure: k5086 
o|contracted procedure: k5096 
o|contracted procedure: k5105 
o|contracted procedure: k5120 
o|contracted procedure: k5116 
o|contracted procedure: k5129 
o|contracted procedure: k5151 
o|contracted procedure: k5132 
o|contracted procedure: k5147 
o|contracted procedure: k5143 
o|contracted procedure: k5157 
o|contracted procedure: k5160 
o|contracted procedure: k5166 
o|contracted procedure: k5173 
o|contracted procedure: k5176 
o|contracted procedure: k5183 
o|contracted procedure: k5204 
o|contracted procedure: k5221 
o|contracted procedure: k5250 
o|contracted procedure: k5242 
o|contracted procedure: k5263 
o|contracted procedure: k5269 
o|contracted procedure: k5292 
o|contracted procedure: k5288 
o|contracted procedure: k5282 
o|contracted procedure: k5276 
o|contracted procedure: k5308 
o|contracted procedure: k5304 
o|contracted procedure: k5506 
o|contracted procedure: k5315 
o|contracted procedure: k5348 
o|contracted procedure: k5383 
o|contracted procedure: k5379 
o|contracted procedure: k5375 
o|contracted procedure: k5367 
o|contracted procedure: k5393 
o|contracted procedure: k5412 
o|contracted procedure: k5408 
o|contracted procedure: k5404 
o|contracted procedure: k5432 
o|contracted procedure: k5436 
o|contracted procedure: k5452 
o|contracted procedure: k5480 
o|contracted procedure: k5472 
o|contracted procedure: k5476 
o|contracted procedure: k5492 
o|contracted procedure: k5502 
o|contracted procedure: k5495 
o|contracted procedure: k5686 
o|contracted procedure: k5514 
o|contracted procedure: k5547 
o|contracted procedure: k5578 
o|contracted procedure: k5574 
o|contracted procedure: k5570 
o|contracted procedure: k5588 
o|contracted procedure: k5609 
o|contracted procedure: k5603 
o|contracted procedure: k5599 
o|contracted procedure: k5627 
o|contracted procedure: k5631 
o|contracted procedure: k5647 
o|contracted procedure: k5664 
o|contracted procedure: k5672 
o|contracted procedure: k5682 
o|contracted procedure: k5675 
o|contracted procedure: k6067 
o|contracted procedure: k5694 
o|contracted procedure: k5707 
o|contracted procedure: k5710 
o|contracted procedure: k5713 
o|contracted procedure: k5716 
o|contracted procedure: k5725 
o|contracted procedure: k5734 
o|contracted procedure: k5737 
o|contracted procedure: k5977 
o|contracted procedure: k5981 
o|contracted procedure: k5989 
o|contracted procedure: k5992 
o|contracted procedure: k5973 
o|contracted procedure: k5969 
o|contracted procedure: k5751 
o|contracted procedure: k5957 
o|contracted procedure: k5965 
o|contracted procedure: k5961 
o|contracted procedure: k5759 
o|contracted procedure: k5755 
o|contracted procedure: k5747 
o|contracted procedure: k5772 
o|contracted procedure: k5775 
o|contracted procedure: k5953 
o|contracted procedure: k5778 
o|contracted procedure: k5781 
o|contracted procedure: k5900 
o|contracted procedure: k5916 
o|contracted procedure: k5924 
o|contracted procedure: k5920 
o|contracted procedure: k5912 
o|contracted procedure: k5904 
o|contracted procedure: k5908 
o|contracted procedure: k5787 
o|contracted procedure: k5815 
o|contracted procedure: k5835 
o|contracted procedure: k5831 
o|contracted procedure: k5843 
o|contracted procedure: k5850 
o|contracted procedure: k5857 
o|contracted procedure: k5876 
o|contracted procedure: k5892 
o|contracted procedure: k5896 
o|contracted procedure: k5888 
o|contracted procedure: k5880 
o|contracted procedure: k5884 
o|contracted procedure: k5927 
o|contracted procedure: k5933 
o|contracted procedure: k6004 
o|contracted procedure: k6007 
o|contracted procedure: k6010 
o|contracted procedure: k6018 
o|contracted procedure: k6026 
o|contracted procedure: k6038 
o|contracted procedure: k6060 
o|contracted procedure: k6056 
o|contracted procedure: k6041 
o|contracted procedure: k6044 
o|contracted procedure: k6052 
o|contracted procedure: k6344 
o|contracted procedure: k6348 
o|contracted procedure: k6075 
o|contracted procedure: k6118 
o|contracted procedure: k6136 
o|contracted procedure: k6145 
o|contracted procedure: k6148 
o|contracted procedure: k6132 
o|contracted procedure: k6128 
o|contracted procedure: k6160 
o|contracted procedure: k6163 
o|contracted procedure: k6166 
o|contracted procedure: k6174 
o|contracted procedure: k6182 
o|contracted procedure: k6204 
o|contracted procedure: k6196 
o|contracted procedure: k6200 
o|contracted procedure: k6192 
o|contracted procedure: k6211 
o|contracted procedure: k6225 
o|contracted procedure: k6220 
o|contracted procedure: k6340 
o|contracted procedure: k6332 
o|contracted procedure: k6336 
o|contracted procedure: k6328 
o|contracted procedure: k6324 
o|contracted procedure: k6244 
o|contracted procedure: k6248 
o|contracted procedure: k6251 
o|contracted procedure: k6254 
o|contracted procedure: k6260 
o|contracted procedure: k6236 
o|contracted procedure: k6240 
o|contracted procedure: k6275 
o|contracted procedure: k6286 
o|contracted procedure: k6282 
o|contracted procedure: k6272 
o|contracted procedure: k6295 
o|contracted procedure: k6298 
o|contracted procedure: k6301 
o|contracted procedure: k6309 
o|contracted procedure: k6317 
o|contracted procedure: k6467 
o|contracted procedure: k6471 
o|contracted procedure: k6360 
o|contracted procedure: k6395 
o|contracted procedure: k6463 
o|contracted procedure: k6447 
o|contracted procedure: k6459 
o|contracted procedure: k6455 
o|contracted procedure: k6451 
o|contracted procedure: k6407 
o|contracted procedure: k6439 
o|contracted procedure: k6419 
o|contracted procedure: k6435 
o|contracted procedure: k6431 
o|contracted procedure: k6427 
o|contracted procedure: k6423 
o|contracted procedure: k6415 
o|contracted procedure: k6411 
o|contracted procedure: k6399 
o|contracted procedure: k6391 
o|contracted procedure: k6383 
o|contracted procedure: k6492 
o|contracted procedure: k6500 
o|contracted procedure: k6526 
o|contracted procedure: k6510 
o|contracted procedure: k6522 
o|contracted procedure: k6518 
o|contracted procedure: k6514 
o|contracted procedure: k6530 
o|contracted procedure: k6544 
o|contracted procedure: k6540 
o|contracted procedure: k6548 
o|contracted procedure: k6954 
o|contracted procedure: k6958 
o|contracted procedure: k6962 
o|contracted procedure: k6966 
o|contracted procedure: k6970 
o|contracted procedure: k6552 
o|contracted procedure: k6577 
o|contracted procedure: k6592 
o|contracted procedure: k6891 
o|contracted procedure: k6887 
o|contracted procedure: k6641 
o|contracted procedure: k6637 
o|contracted procedure: k6655 
o|contracted procedure: k6668 
o|contracted procedure: k6697 
o|contracted procedure: k6704 
o|contracted procedure: k6707 
o|contracted procedure: k6710 
o|contracted procedure: k6758 
o|contracted procedure: k6722 
o|contracted procedure: k6748 
o|contracted procedure: k6752 
o|contracted procedure: k6744 
o|contracted procedure: k6725 
o|contracted procedure: k6728 
o|contracted procedure: k6736 
o|contracted procedure: k6740 
o|contracted procedure: k6770 
o|contracted procedure: k6792 
o|contracted procedure: k6784 
o|contracted procedure: k6788 
o|contracted procedure: k6780 
o|contracted procedure: k6813 
o|contracted procedure: k6798 
o|contracted procedure: k6807 
o|contracted procedure: k6856 
o|contracted procedure: k6860 
o|contracted procedure: k6844 
o|contracted procedure: k6852 
o|contracted procedure: k6848 
o|contracted procedure: k6823 
o|contracted procedure: k6830 
o|contracted procedure: k6870 
o|contracted procedure: k6881 
o|contracted procedure: k6895 
o|contracted procedure: k6910 
o|contracted procedure: k6913 
o|contracted procedure: k6925 
o|contracted procedure: k6928 
o|contracted procedure: k6931 
o|contracted procedure: k6939 
o|contracted procedure: k6947 
o|contracted procedure: k6904 
o|contracted procedure: k7142 
o|contracted procedure: k6994 
o|contracted procedure: k7007 
o|contracted procedure: k7010 
o|contracted procedure: k7138 
o|contracted procedure: k7032 
o|contracted procedure: k7045 
o|contracted procedure: k7052 
o|contracted procedure: k7055 
o|contracted procedure: k7061 
o|contracted procedure: k7111 
o|contracted procedure: k7115 
o|contracted procedure: k7119 
o|contracted procedure: k7107 
o|contracted procedure: k7081 
o|contracted procedure: k7093 
o|contracted procedure: k7097 
o|contracted procedure: k7101 
o|contracted procedure: k7089 
o|contracted procedure: k7085 
o|contracted procedure: k7071 
o|contracted procedure: k7134 
o|contracted procedure: k7130 
o|contracted procedure: k7126 
o|contracted procedure: k7215 
o|contracted procedure: k7219 
o|contracted procedure: k7223 
o|contracted procedure: k7150 
o|contracted procedure: k7211 
o|contracted procedure: k7207 
o|contracted procedure: k7170 
o|contracted procedure: k7178 
o|contracted procedure: k7182 
o|contracted procedure: k7196 
o|contracted procedure: k7185 
o|contracted procedure: k7189 
o|contracted procedure: k7174 
o|contracted procedure: k7675 
o|contracted procedure: k7679 
o|contracted procedure: k7239 
o|contracted procedure: k7252 
o|contracted procedure: k7255 
o|contracted procedure: k7352 
o|contracted procedure: k7362 
o|contracted procedure: k7369 
o|contracted procedure: k7421 
o|contracted procedure: k7373 
o|contracted procedure: k7413 
o|contracted procedure: k7397 
o|contracted procedure: k7405 
o|contracted procedure: k7401 
o|contracted procedure: k7381 
o|contracted procedure: k7377 
o|contracted procedure: k7393 
o|contracted procedure: k7434 
o|contracted procedure: k7437 
o|contracted procedure: k7456 
o|contracted procedure: k7468 
o|contracted procedure: k7474 
o|contracted procedure: k7486 
o|contracted procedure: k7519 
o|contracted procedure: k7535 
o|contracted procedure: k7531 
o|contracted procedure: k7527 
o|contracted procedure: k7523 
o|contracted procedure: k7515 
o|contracted procedure: k7285 
o|contracted procedure: k7288 
o|contracted procedure: k7309 
o|contracted procedure: k7321 
o|contracted procedure: k7313 
o|contracted procedure: k7295 
o|contracted procedure: k7337 
o|contracted procedure: k7333 
o|contracted procedure: k7544 
o|contracted procedure: k7547 
o|contracted procedure: k7550 
o|contracted procedure: k7558 
o|contracted procedure: k7566 
o|contracted procedure: k7578 
o|contracted procedure: k7600 
o|contracted procedure: k7596 
o|contracted procedure: k7581 
o|contracted procedure: k7584 
o|contracted procedure: k7592 
o|contracted procedure: k7612 
o|contracted procedure: k7615 
o|contracted procedure: k7618 
o|contracted procedure: k7626 
o|contracted procedure: k7634 
o|contracted procedure: k7646 
o|contracted procedure: k7668 
o|contracted procedure: k7664 
o|contracted procedure: k7649 
o|contracted procedure: k7652 
o|contracted procedure: k7660 
o|contracted procedure: k7700 
o|contracted procedure: k7855 
o|contracted procedure: k7718 
o|contracted procedure: k7731 
o|contracted procedure: k7851 
o|contracted procedure: k7743 
o|contracted procedure: k7746 
o|contracted procedure: k7797 
o|contracted procedure: k7806 
o|contracted procedure: k7783 
o|contracted procedure: k7787 
o|contracted procedure: k7818 
o|contracted procedure: k7821 
o|contracted procedure: k7824 
o|contracted procedure: k7832 
o|contracted procedure: k7840 
o|contracted procedure: k7847 
o|contracted procedure: k7868 
o|contracted procedure: k7882 
o|contracted procedure: k7888 
o|contracted procedure: k7952 
o|contracted procedure: k7948 
o|contracted procedure: k7908 
o|contracted procedure: k7944 
o|contracted procedure: k7940 
o|contracted procedure: k7928 
o|contracted procedure: k7932 
o|contracted procedure: k7967 
o|contracted procedure: k8039 
o|contracted procedure: k7970 
o|contracted procedure: k8019 
o|contracted procedure: k7982 
o|contracted procedure: k8015 
o|contracted procedure: k8011 
o|contracted procedure: k8022 
o|contracted procedure: k8029 
o|contracted procedure: k8052 
o|contracted procedure: k8100 
o|contracted procedure: k8056 
o|contracted procedure: k8096 
o|contracted procedure: k8076 
o|contracted procedure: k8092 
o|contracted procedure: k8084 
o|contracted procedure: k8080 
o|contracted procedure: k8117 
o|contracted procedure: k8122 
o|contracted procedure: k8125 
o|contracted procedure: k8131 
o|contracted procedure: k8145 
o|contracted procedure: k8153 
o|contracted procedure: k8159 
o|contracted procedure: k8141 
o|contracted procedure: k8170 
o|contracted procedure: k8173 
o|contracted procedure: k8221 
o|contracted procedure: k8185 
o|contracted procedure: k8188 
o|contracted procedure: k8191 
o|contracted procedure: k8199 
o|contracted procedure: k8203 
o|contracted procedure: k8211 
o|contracted procedure: k8215 
o|contracted procedure: k8233 
o|contracted procedure: k8255 
o|contracted procedure: k8251 
o|contracted procedure: k8236 
o|contracted procedure: k8239 
o|contracted procedure: k8247 
o|contracted procedure: k8267 
o|contracted procedure: k8274 
o|contracted procedure: k8294 
o|contracted procedure: k8303 
o|contracted procedure: k8325 
o|contracted procedure: k8321 
o|contracted procedure: k8306 
o|contracted procedure: k8309 
o|contracted procedure: k8317 
o|contracted procedure: k8337 
o|contracted procedure: k8359 
o|contracted procedure: k8355 
o|contracted procedure: k8340 
o|contracted procedure: k8343 
o|contracted procedure: k8351 
o|contracted procedure: k8375 
o|contracted procedure: k8392 
o|contracted procedure: k8399 
o|contracted procedure: k8416 
o|contracted procedure: k8406 
o|contracted procedure: k8429 
o|contracted procedure: k8459 
o|contracted procedure: k8449 
o|contracted procedure: k8467 
o|contracted procedure: k8497 
o|contracted procedure: k8493 
o|contracted procedure: k8502 
o|contracted procedure: k8505 
o|contracted procedure: k8514 
o|contracted procedure: k8530 
o|contracted procedure: k8542 
o|contracted procedure: k8552 
o|contracted procedure: k8569 
o|contracted procedure: k8580 
o|contracted procedure: k8592 
o|contracted procedure: k8576 
o|contracted procedure: k8604 
o|contracted procedure: k8607 
o|contracted procedure: k8610 
o|contracted procedure: k8618 
o|contracted procedure: k8626 
o|contracted procedure: k8662 
o|contracted procedure: k8666 
o|contracted procedure: k8658 
o|contracted procedure: k8642 
o|contracted procedure: k8650 
o|contracted procedure: k8695 
o|contracted procedure: k8673 
o|contracted procedure: k8677 
o|contracted procedure: k8687 
o|contracted procedure: k8709 
o|contracted procedure: k8698 
o|contracted procedure: k8705 
o|contracted procedure: k8718 
o|contracted procedure: k8740 
o|contracted procedure: k8736 
o|contracted procedure: k8721 
o|contracted procedure: k8724 
o|contracted procedure: k8732 
o|contracted procedure: k8752 
o|contracted procedure: k8758 
o|contracted procedure: k8787 
o|inlining procedure: k8761 
o|inlining procedure: k8761 
o|contracted procedure: k8796 
o|contracted procedure: k8799 
o|contracted procedure: k8802 
o|contracted procedure: k8810 
o|contracted procedure: k8818 
o|contracted procedure: k8830 
o|contracted procedure: k8833 
o|contracted procedure: k8844 
o|contracted procedure: k8853 
o|inlining procedure: k8836 
o|contracted procedure: k8868 
o|contracted procedure: k8890 
o|contracted procedure: k8886 
o|contracted procedure: k8871 
o|contracted procedure: k8874 
o|contracted procedure: k8882 
o|contracted procedure: k8919 
o|contracted procedure: k8937 
o|contracted procedure: k8949 
o|contracted procedure: k8959 
o|contracted procedure: k8963 
o|contracted procedure: k8980 
o|contracted procedure: k8984 
o|contracted procedure: k9001 
o|contracted procedure: k9005 
o|contracted procedure: k9009 
o|contracted procedure: k9029 
o|contracted procedure: k9033 
o|contracted procedure: k9064 
o|contracted procedure: k9078 
o|contracted procedure: k9081 
o|contracted procedure: k9087 
o|contracted procedure: k9093 
o|contracted procedure: k9052 
o|contracted procedure: k9105 
o|contracted procedure: k9111 
o|contracted procedure: k9126 
o|contracted procedure: k9145 
o|contracted procedure: k9148 
o|contracted procedure: k9159 
o|contracted procedure: k9162 
o|contracted procedure: k9165 
o|contracted procedure: k9501 
o|contracted procedure: k9497 
o|contracted procedure: k9176 
o|contracted procedure: k9272 
o|contracted procedure: k9285 
o|contracted procedure: k9281 
o|contracted procedure: k9288 
o|contracted procedure: k9268 
o|contracted procedure: k9264 
o|contracted procedure: k9184 
o|contracted procedure: k9260 
o|contracted procedure: k9188 
o|contracted procedure: k9200 
o|contracted procedure: k9196 
o|contracted procedure: k9192 
o|contracted procedure: k9180 
o|contracted procedure: k9172 
o|contracted procedure: k9155 
o|contracted procedure: k9253 
o|contracted procedure: k9217 
o|contracted procedure: k9243 
o|contracted procedure: k9247 
o|contracted procedure: k9239 
o|contracted procedure: k9220 
o|contracted procedure: k9223 
o|contracted procedure: k9231 
o|contracted procedure: k9235 
o|contracted procedure: k9299 
o|contracted procedure: k9319 
o|contracted procedure: k9335 
o|contracted procedure: k9331 
o|contracted procedure: k9380 
o|contracted procedure: k9344 
o|contracted procedure: k9370 
o|contracted procedure: k9374 
o|contracted procedure: k9366 
o|contracted procedure: k9347 
o|contracted procedure: k9350 
o|contracted procedure: k9358 
o|contracted procedure: k9362 
o|contracted procedure: k9428 
o|contracted procedure: k9392 
o|contracted procedure: k9395 
o|contracted procedure: k9398 
o|contracted procedure: k9406 
o|contracted procedure: k9410 
o|contracted procedure: k9418 
o|contracted procedure: k9422 
o|contracted procedure: k9308 
o|contracted procedure: k9443 
o|contracted procedure: k9446 
o|contracted procedure: k9454 
o|contracted procedure: k9458 
o|contracted procedure: k9462 
o|contracted procedure: k9470 
o|contracted procedure: k9474 
o|contracted procedure: k9478 
o|contracted procedure: k9484 
o|contracted procedure: k9490 
o|contracted procedure: k9546 
o|contracted procedure: k9510 
o|contracted procedure: k9536 
o|contracted procedure: k9540 
o|contracted procedure: k9532 
o|contracted procedure: k9513 
o|contracted procedure: k9516 
o|contracted procedure: k9524 
o|contracted procedure: k9528 
o|contracted procedure: k9594 
o|contracted procedure: k9558 
o|contracted procedure: k9584 
o|contracted procedure: k9588 
o|contracted procedure: k9580 
o|contracted procedure: k9561 
o|contracted procedure: k9564 
o|contracted procedure: k9572 
o|contracted procedure: k9576 
o|contracted procedure: k9606 
o|contracted procedure: k9609 
o|contracted procedure: k9612 
o|contracted procedure: k9620 
o|contracted procedure: k9640 
o|contracted procedure: k9643 
o|contracted procedure: k9646 
o|contracted procedure: k9654 
o|contracted procedure: k9674 
o|contracted procedure: k9677 
o|contracted procedure: k9680 
o|contracted procedure: k9688 
o|contracted procedure: k9696 
o|contracted procedure: k9708 
o|contracted procedure: k9730 
o|contracted procedure: k9726 
o|contracted procedure: k9711 
o|contracted procedure: k9714 
o|contracted procedure: k9722 
o|contracted procedure: k9742 
o|contracted procedure: k9764 
o|contracted procedure: k9760 
o|contracted procedure: k9745 
o|contracted procedure: k9748 
o|contracted procedure: k9756 
o|contracted procedure: k9780 
o|contracted procedure: k9783 
o|contracted procedure: k9801 
o|contracted procedure: k9807 
o|contracted procedure: k9831 
o|contracted procedure: k9842 
o|contracted procedure: k984211832 
o|contracted procedure: k984211836 
o|contracted procedure: k984211840 
o|contracted procedure: k9881 
o|contracted procedure: k9886 
o|contracted procedure: k9889 
o|contracted procedure: k9895 
o|contracted procedure: k9910 
o|contracted procedure: k10093 
o|contracted procedure: k9937 
o|contracted procedure: k10089 
o|contracted procedure: k9941 
o|contracted procedure: k9949 
o|contracted procedure: k9945 
o|contracted procedure: k9933 
o|contracted procedure: k9957 
o|contracted procedure: k9973 
o|contracted procedure: k9989 
o|contracted procedure: k9985 
o|contracted procedure: k10034 
o|contracted procedure: k9998 
o|contracted procedure: k10024 
o|contracted procedure: k10028 
o|contracted procedure: k10020 
o|contracted procedure: k10001 
o|contracted procedure: k10004 
o|contracted procedure: k10012 
o|contracted procedure: k10016 
o|contracted procedure: k10082 
o|contracted procedure: k10046 
o|contracted procedure: k10072 
o|contracted procedure: k10076 
o|contracted procedure: k10068 
o|contracted procedure: k10049 
o|contracted procedure: k10052 
o|contracted procedure: k10060 
o|contracted procedure: k10064 
o|contracted procedure: k10101 
o|contracted procedure: k10109 
o|contracted procedure: k10120 
o|contracted procedure: k10136 
o|contracted procedure: k10132 
o|contracted procedure: k10181 
o|contracted procedure: k10145 
o|contracted procedure: k10171 
o|contracted procedure: k10175 
o|contracted procedure: k10167 
o|contracted procedure: k10148 
o|contracted procedure: k10151 
o|contracted procedure: k10159 
o|contracted procedure: k10163 
o|contracted procedure: k10229 
o|contracted procedure: k10193 
o|contracted procedure: k10219 
o|contracted procedure: k10223 
o|contracted procedure: k10215 
o|contracted procedure: k10196 
o|contracted procedure: k10199 
o|contracted procedure: k10207 
o|contracted procedure: k10211 
o|contracted procedure: k10236 
o|contracted procedure: k10239 
o|contracted procedure: k10245 
o|contracted procedure: k10248 
o|contracted procedure: k10255 
o|contracted procedure: k10261 
o|contracted procedure: k10264 
o|contracted procedure: k10312 
o|contracted procedure: k10276 
o|contracted procedure: k10302 
o|contracted procedure: k10306 
o|contracted procedure: k10298 
o|contracted procedure: k10279 
o|contracted procedure: k10282 
o|contracted procedure: k10290 
o|contracted procedure: k10294 
o|contracted procedure: k10326 
o|contracted procedure: k10337 
o|contracted procedure: k10382 
o|contracted procedure: k10346 
o|contracted procedure: k10372 
o|contracted procedure: k10376 
o|contracted procedure: k10368 
o|contracted procedure: k10349 
o|contracted procedure: k10352 
o|contracted procedure: k10360 
o|contracted procedure: k10364 
o|contracted procedure: k10394 
o|contracted procedure: k10416 
o|contracted procedure: k10412 
o|contracted procedure: k10397 
o|contracted procedure: k10400 
o|contracted procedure: k10408 
o|contracted procedure: k10428 
o|contracted procedure: k10431 
o|contracted procedure: k10434 
o|contracted procedure: k10442 
o|contracted procedure: k10462 
o|contracted procedure: k10465 
o|contracted procedure: k10468 
o|contracted procedure: k10476 
o|contracted procedure: k10496 
o|contracted procedure: k10518 
o|contracted procedure: k10514 
o|contracted procedure: k10499 
o|contracted procedure: k10502 
o|contracted procedure: k10510 
o|contracted procedure: k10534 
o|contracted procedure: k10537 
o|contracted procedure: k10596 
o|contracted procedure: k10550 
o|contracted procedure: k10592 
o|contracted procedure: k10558 
o|contracted procedure: k10562 
o|contracted procedure: k10554 
o|contracted procedure: k10573 
o|contracted procedure: k10588 
o|contracted procedure: k10580 
o|contracted procedure: k10584 
o|contracted procedure: k10570 
o|contracted procedure: k10609 
o|contracted procedure: k10682 
o|contracted procedure: k10614 
o|contracted procedure: k10666 
o|contracted procedure: k10627 
o|contracted procedure: k10635 
o|contracted procedure: k10639 
o|contracted procedure: k10631 
o|contracted procedure: k10650 
o|contracted procedure: k10658 
o|contracted procedure: k10647 
o|contracted procedure: k10669 
o|contracted procedure: k10702 
o|contracted procedure: k10716 
o|contracted procedure: k10733 
o|contracted procedure: k10765 
o|contracted procedure: k10761 
o|contracted procedure: k10741 
o|contracted procedure: k10757 
o|contracted procedure: k10749 
o|contracted procedure: k10753 
o|contracted procedure: k10745 
o|contracted procedure: k10737 
o|contracted procedure: k10858 
o|contracted procedure: k10781 
o|contracted procedure: k10792 
o|contracted procedure: k10788 
o|contracted procedure: k10800 
o|contracted procedure: k10803 
o|contracted procedure: k10831 
o|contracted procedure: k10827 
o|contracted procedure: k10823 
o|contracted procedure: k10819 
o|contracted procedure: k10838 
o|contracted procedure: k10846 
o|contracted procedure: k10842 
o|contracted procedure: k10849 
o|contracted procedure: k10871 
o|contracted procedure: k10888 
o|contracted procedure: k10896 
o|contracted procedure: k10911 
o|contracted procedure: k10923 
o|contracted procedure: k10939 
o|contracted procedure: k10929 
o|inlining procedure: k10902 
o|inlining procedure: k10902 
o|inlining procedure: k10902 
o|inlining procedure: k10902 
o|inlining procedure: k10902 
o|contracted procedure: k10946 
o|contracted procedure: k11180 
o|contracted procedure: k11176 
o|contracted procedure: k11172 
o|contracted procedure: k11168 
o|contracted procedure: k10960 
o|contracted procedure: k11146 
o|contracted procedure: k11154 
o|contracted procedure: k11150 
o|contracted procedure: k11142 
o|contracted procedure: k10968 
o|contracted procedure: k10964 
o|contracted procedure: k10956 
o|contracted procedure: k10981 
o|contracted procedure: k10984 
o|contracted procedure: k11134 
o|contracted procedure: k10987 
o|contracted procedure: k11099 
o|contracted procedure: k11115 
o|contracted procedure: k11111 
o|contracted procedure: k11103 
o|contracted procedure: k11107 
o|contracted procedure: k10999 
o|contracted procedure: k11006 
o|contracted procedure: k11014 
o|contracted procedure: k11018 
o|contracted procedure: k11034 
o|contracted procedure: k11030 
o|contracted procedure: k11049 
o|contracted procedure: k11065 
o|contracted procedure: k11061 
o|contracted procedure: k11053 
o|contracted procedure: k11057 
o|contracted procedure: k11045 
o|contracted procedure: k11072 
o|contracted procedure: k11088 
o|contracted procedure: k11084 
o|contracted procedure: k11076 
o|contracted procedure: k11080 
o|contracted procedure: k11095 
o|contracted procedure: k11127 
o|contracted procedure: k11195 
o|contracted procedure: k11198 
o|contracted procedure: k11201 
o|contracted procedure: k11209 
o|contracted procedure: k11217 
o|contracted procedure: k11237 
o|simplifications: ((let . 108)) 
o|removed binding forms: 1012 
o|inlining procedure: k3797 
o|inlining procedure: k3797 
o|inlining procedure: k4042 
o|inlining procedure: k4042 
o|inlining procedure: k4889 
o|inlining procedure: k4889 
o|inlining procedure: k4889 
o|substituted constant variable: r1090312596 
o|substituted constant variable: r1090312597 
o|substituted constant variable: r1090312598 
o|substituted constant variable: r1090312599 
o|inlining procedure: k11038 
o|inlining procedure: k11038 
o|simplifications: ((let . 1)) 
o|replaced variables: 344 
o|removed binding forms: 2 
o|removed conditional forms: 4 
o|substituted constant variable: r379812604 
o|substituted constant variable: r379812604 
o|replaced variables: 1 
o|removed binding forms: 227 
o|contracted procedure: k3997 
o|contracted procedure: k4358 
o|contracted procedure: k9414 
o|replaced variables: 2 
o|removed binding forms: 6 
o|removed binding forms: 1 
o|direct leaf routine/allocation: g19271936 0 
o|direct leaf routine/allocation: g18141823 15 
o|direct leaf routine/allocation: g13771386 9 
o|direct leaf routine/allocation: g748759 30 
o|contracted procedure: "(chicken-syntax.scm:930) k6022" 
o|contracted procedure: "(chicken-syntax.scm:889) k6178" 
o|contracted procedure: "(chicken-syntax.scm:527) k7836" 
o|contracted procedure: "(chicken-syntax.scm:300) k9466" 
o|removed binding forms: 4 
o|customizable procedures: (g3140 map-loop2551 k11026 mapslots61 k10812 k10620 k10643 k10566 map-loop172189 g205214 map-loop199217 g233242 map-loop227245 map-loop278295 map-loop257302 loop333 map-loop314336 map-loop348372 map-loop384408 map-loop420444 map-loop456480 loop505 map-loop540557 map-loop567584 g600609 map-loop594612 g628637 map-loop622640 g656665 map-loop650668 map-loop680699 map-loop711730 k9440 map-loop742769 map-loop784808 map-loop820844 map-loop856880 for-each-loop918930 map-loop962979 loop987 g10061015 map-loop10001018 loop1028 map-loop10861104 k8635 fold1038 g10571066 map-loop10511069 fold1120 map-loop11391156 map-loop11651182 foldl12171221 map-loop11941233 map-loop12421261 quotify-proc12861288 k7973 k7985 fold1312 map-loop13711392 expand1347 map-loop14481465 g14841493 map-loop14781496 map-loop15061523 g15411550 map-loop15351553 recur1418 make-if-tree1412 prefix-sym1472 recur1433 loop1601 map-loop16311652 genvars1623 k6671 build1688 map-loop17111730 loop1625 map-loop18391856 k6106 k6109 k6112 map-loop18081829 map-loop18921909 map-loop19211939 k5784 k5790 k5797 k5805 loop1946 loop1990 loop2020 k5102 k5126 loop21192140 loop21192151 g22002209 map-loop21942221 k4772 k4646 k4504 loop22802301 loop22802317 map-loop23282346 map-loop23562374 k4163 loop2401 loop22415 map-loop24222447 map-loop24592483 g25202529 map-loop25142536) 
o|calls to known targets: 253 
o|identified direct recursive calls: f_3970 1 
o|identified direct recursive calls: f_4111 1 
o|identified direct recursive calls: f_3914 1 
o|identified direct recursive calls: f_4335 1 
o|identified direct recursive calls: f_4369 1 
o|identified direct recursive calls: f_5999 1 
o|identified direct recursive calls: f_6033 1 
o|identified direct recursive calls: f_6155 1 
o|identified direct recursive calls: f_6717 1 
o|identified direct recursive calls: f_7573 1 
o|identified direct recursive calls: f_7641 1 
o|identified direct recursive calls: f_7813 1 
o|identified direct recursive calls: f_7877 2 
o|identified direct recursive calls: f_8228 1 
o|identified direct recursive calls: f_8298 1 
o|identified direct recursive calls: f_8332 1 
o|identified direct recursive calls: f_8387 1 
o|identified direct recursive calls: f_8713 1 
o|identified direct recursive calls: f_8825 1 
o|identified direct recursive calls: f_8863 1 
o|identified direct recursive calls: f_9212 1 
o|identified direct recursive calls: f_9339 1 
o|identified direct recursive calls: f_9387 1 
o|identified direct recursive calls: f_9505 1 
o|identified direct recursive calls: f_9553 1 
o|identified direct recursive calls: f_9703 1 
o|identified direct recursive calls: f_9737 1 
o|identified direct recursive calls: f_9993 1 
o|identified direct recursive calls: f_10041 1 
o|identified direct recursive calls: f_10140 1 
o|identified direct recursive calls: f_10188 1 
o|identified direct recursive calls: f_10271 1 
o|identified direct recursive calls: f_10321 1 
o|identified direct recursive calls: f_10341 1 
o|identified direct recursive calls: f_10389 1 
o|identified direct recursive calls: f_10491 1 
o|fast box initializations: 74 
o|dropping unused closure argument: f_7443 
*/
/* end of file */
