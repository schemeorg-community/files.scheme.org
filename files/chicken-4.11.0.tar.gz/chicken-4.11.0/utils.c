/* Generated from utils.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:48
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: utils.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file utils.c
   unit: utils
*/

#include "chicken.h"


#if defined(_WIN32) && !defined(__CYGWIN__)
# include <windows.h>
# define C_HAS_MESSAGE_BOX 1
static int
C_confirmation_dialog(char *msg, char *caption, int def, int abort)
{
  int d = 0, r;
  int t = abort ? MB_YESNOCANCEL : MB_YESNO;

  switch(def) {
  case 0: d = MB_DEFBUTTON1; break;
  case 1: d = MB_DEFBUTTON2; break;
  case 2: d = MB_DEFBUTTON3;
  }

  r = MessageBox(NULL, msg, caption, t | MB_ICONQUESTION | d);

  switch(r) {
  case IDYES: return 1;
  case IDNO: return 0;
  default: return -1;
  }
}
#else
# define C_HAS_MESSAGE_BOX 0
static int
C_confirmation_dialog(char *msg, char *caption, int def, int abort) { return -1; }
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_srfi_2d13_toplevel)
C_externimport void C_ccall C_srfi_2d13_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_irregex_toplevel)
C_externimport void C_ccall C_irregex_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[89];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,25),40,115,121,115,116,101,109,42,32,102,115,116,114,54,52,32,46,32,97,114,103,115,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,6),40,97,54,49,52,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,19),40,114,101,97,100,45,97,108,108,32,46,32,102,105,108,101,54,57,41,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,11),40,103,49,48,51,32,99,49,49,52,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,20),40,109,97,112,45,108,111,111,112,57,55,32,103,49,48,57,49,50,48,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,20),40,113,115,32,115,116,114,56,54,32,46,32,116,109,112,56,53,56,55,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,6),40,97,56,52,51,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,12),40,97,56,51,55,32,101,120,50,48,50,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,9),40,116,109,112,49,53,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,6),40,97,56,54,53,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,20),40,116,109,112,50,53,53,50,32,97,114,103,115,49,57,54,50,48,53,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,6),40,97,56,53,50,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,14),40,97,56,51,49,32,107,49,57,53,50,48,49,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,6),40,97,57,48,50,41,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,12),40,97,56,57,54,32,101,120,49,56,57,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,9),40,116,109,112,49,53,52,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,6),40,97,57,49,56,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,20),40,116,109,112,50,53,53,48,32,97,114,103,115,49,56,51,49,57,48,41,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,6),40,97,57,48,53,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,14),40,97,56,57,48,32,107,49,56,50,49,56,56,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,6),40,97,56,56,49,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,6),40,97,57,56,52,41,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,38),40,99,111,109,112,105,108,101,45,102,105,108,101,32,102,105,108,101,110,97,109,101,49,51,56,32,46,32,116,109,112,49,51,55,49,51,57,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,19),40,102,95,49,48,51,48,32,103,50,50,57,50,51,48,50,51,51,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,36),40,115,99,97,110,45,105,110,112,117,116,45,108,105,110,101,115,32,114,120,50,49,52,32,46,32,116,109,112,50,49,51,50,49,53,41,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,11),40,103,101,116,45,105,110,112,117,116,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,7),40,97,49,50,54,57,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,31),40,121,101,115,45,111,114,45,110,111,63,32,115,116,114,50,54,50,32,46,32,116,109,112,50,54,49,50,54,51,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k1053 */
C_regparm static C_word C_fcall stub247(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_truep(C_a3);
C_r=C_fix((C_word)C_confirmation_dialog(t0,t1,t2,t3));
return C_r;}

C_noret_decl(f_752)
static void C_ccall f_752(C_word c,C_word *av) C_noret;
C_noret_decl(f_758)
static void C_ccall f_758(C_word c,C_word *av) C_noret;
C_noret_decl(f_988)
static void C_ccall f_988(C_word c,C_word *av) C_noret;
C_noret_decl(f_985)
static void C_ccall f_985(C_word c,C_word *av) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word *av) C_noret;
C_noret_decl(f_1177)
static void C_ccall f_1177(C_word c,C_word *av) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877(C_word c,C_word *av) C_noret;
C_noret_decl(f_764)
static void C_ccall f_764(C_word c,C_word *av) C_noret;
C_noret_decl(f_607)
static void C_ccall f_607(C_word c,C_word *av) C_noret;
C_noret_decl(f_995)
static void C_fcall f_995(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1189)
static void C_ccall f_1189(C_word c,C_word *av) C_noret;
C_noret_decl(f_1186)
static void C_ccall f_1186(C_word c,C_word *av) C_noret;
C_noret_decl(f_803)
static void C_ccall f_803(C_word c,C_word *av) C_noret;
C_noret_decl(f_806)
static void C_ccall f_806(C_word c,C_word *av) C_noret;
C_noret_decl(f_800)
static void C_ccall f_800(C_word c,C_word *av) C_noret;
C_noret_decl(f_734)
static void C_ccall f_734(C_word c,C_word *av) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word *av) C_noret;
C_noret_decl(f_738)
static void C_ccall f_738(C_word c,C_word *av) C_noret;
C_noret_decl(f_809)
static void C_ccall f_809(C_word c,C_word *av) C_noret;
C_noret_decl(f_582)
static void C_ccall f_582(C_word c,C_word *av) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word *av) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word *av) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word *av) C_noret;
C_noret_decl(f_1198)
static void C_ccall f_1198(C_word c,C_word *av) C_noret;
C_noret_decl(f_585)
static void C_ccall f_585(C_word c,C_word *av) C_noret;
C_noret_decl(f_741)
static void C_ccall f_741(C_word c,C_word *av) C_noret;
C_noret_decl(f_742)
static void C_ccall f_742(C_word c,C_word *av) C_noret;
C_noret_decl(f_818)
static void C_ccall f_818(C_word c,C_word *av) C_noret;
C_noret_decl(f_1030)
static void C_ccall f_1030(C_word c,C_word *av) C_noret;
C_noret_decl(f_973)
static void C_ccall f_973(C_word c,C_word *av) C_noret;
C_noret_decl(f_597)
static void C_ccall f_597(C_word c,C_word *av) C_noret;
C_noret_decl(f_827)
static void C_ccall f_827(C_word c,C_word *av) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word *av) C_noret;
C_noret_decl(f_1000)
static void C_fcall f_1000(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1013)
static void C_ccall f_1013(C_word c,C_word *av) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965(C_word c,C_word *av) C_noret;
C_noret_decl(f_657)
static void C_fcall f_657(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_844)
static void C_ccall f_844(C_word c,C_word *av) C_noret;
C_noret_decl(f_848)
static void C_ccall f_848(C_word c,C_word *av) C_noret;
C_noret_decl(C_utils_toplevel)
C_externexport void C_ccall C_utils_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_627)
static void C_ccall f_627(C_word c,C_word *av) C_noret;
C_noret_decl(f_853)
static void C_ccall f_853(C_word c,C_word *av) C_noret;
C_noret_decl(f_855)
static void C_fcall f_855(C_word t0,C_word t1) C_noret;
C_noret_decl(f_859)
static void C_ccall f_859(C_word c,C_word *av) C_noret;
C_noret_decl(f_942)
static void C_ccall f_942(C_word c,C_word *av) C_noret;
C_noret_decl(f_1116)
static void C_fcall f_1116(C_word t0,C_word t1) C_noret;
C_noret_decl(f_860)
static void C_fcall f_860(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_866)
static void C_ccall f_866(C_word c,C_word *av) C_noret;
C_noret_decl(f_950)
static void C_ccall f_950(C_word c,C_word *av) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954(C_word c,C_word *av) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word *av) C_noret;
C_noret_decl(f_648)
static void C_ccall f_648(C_word c,C_word *av) C_noret;
C_noret_decl(f_1083)
static void C_fcall f_1083(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_fcall f_1085(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1138)
static void C_ccall f_1138(C_word c,C_word *av) C_noret;
C_noret_decl(f_1080)
static void C_ccall f_1080(C_word c,C_word *av) C_noret;
C_noret_decl(f_930)
static void C_ccall f_930(C_word c,C_word *av) C_noret;
C_noret_decl(f_1143)
static void C_fcall f_1143(C_word t0,C_word t1) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797(C_word c,C_word *av) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word *av) C_noret;
C_noret_decl(f_794)
static void C_ccall f_794(C_word c,C_word *av) C_noret;
C_noret_decl(f_791)
static void C_ccall f_791(C_word c,C_word *av) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092(C_word c,C_word *av) C_noret;
C_noret_decl(f_906)
static void C_ccall f_906(C_word c,C_word *av) C_noret;
C_noret_decl(f_903)
static void C_ccall f_903(C_word c,C_word *av) C_noret;
C_noret_decl(f_1254)
static void C_ccall f_1254(C_word c,C_word *av) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word *av) C_noret;
C_noret_decl(f_908)
static void C_fcall f_908(C_word t0,C_word t1) C_noret;
C_noret_decl(f_913)
static void C_fcall f_913(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779(C_word c,C_word *av) C_noret;
C_noret_decl(f_776)
static void C_ccall f_776(C_word c,C_word *av) C_noret;
C_noret_decl(f_919)
static void C_ccall f_919(C_word c,C_word *av) C_noret;
C_noret_decl(f_1070)
static void C_ccall f_1070(C_word c,C_word *av) C_noret;
C_noret_decl(f_770)
static void C_ccall f_770(C_word c,C_word *av) C_noret;
C_noret_decl(f_832)
static void C_ccall f_832(C_word c,C_word *av) C_noret;
C_noret_decl(f_838)
static void C_ccall f_838(C_word c,C_word *av) C_noret;
C_noret_decl(f_785)
static void C_ccall f_785(C_word c,C_word *av) C_noret;
C_noret_decl(f_788)
static void C_ccall f_788(C_word c,C_word *av) C_noret;
C_noret_decl(f_782)
static void C_ccall f_782(C_word c,C_word *av) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word *av) C_noret;
C_noret_decl(f_1201)
static void C_ccall f_1201(C_word c,C_word *av) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word *av) C_noret;
C_noret_decl(f_631)
static void C_ccall f_631(C_word c,C_word *av) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270(C_word c,C_word *av) C_noret;
C_noret_decl(f_681)
static void C_ccall f_681(C_word c,C_word *av) C_noret;
C_noret_decl(f_683)
static void C_fcall f_683(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_886)
static void C_ccall f_886(C_word c,C_word *av) C_noret;
C_noret_decl(f_882)
static void C_ccall f_882(C_word c,C_word *av) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897(C_word c,C_word *av) C_noret;
C_noret_decl(f_891)
static void C_ccall f_891(C_word c,C_word *av) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word *av) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word *av) C_noret;
C_noret_decl(f_678)
static void C_ccall f_678(C_word c,C_word *av) C_noret;
C_noret_decl(f_564)
static void C_ccall f_564(C_word c,C_word *av) C_noret;
C_noret_decl(f_561)
static void C_ccall f_561(C_word c,C_word *av) C_noret;
C_noret_decl(f_567)
static void C_ccall f_567(C_word c,C_word *av) C_noret;
C_noret_decl(f_573)
static void C_ccall f_573(C_word c,C_word *av) C_noret;
C_noret_decl(f_570)
static void C_ccall f_570(C_word c,C_word *av) C_noret;
C_noret_decl(f_1227)
static void C_ccall f_1227(C_word c,C_word *av) C_noret;
C_noret_decl(f_578)
static void C_ccall f_578(C_word c,C_word *av) C_noret;
C_noret_decl(f_576)
static void C_ccall f_576(C_word c,C_word *av) C_noret;
C_noret_decl(f_558)
static void C_ccall f_558(C_word c,C_word *av) C_noret;
C_noret_decl(f_615)
static void C_ccall f_615(C_word c,C_word *av) C_noret;
C_noret_decl(f_1153)
static void C_fcall f_1153(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word *av) C_noret;
C_noret_decl(f_708)
static void C_ccall f_708(C_word c,C_word *av) C_noret;

C_noret_decl(trf_995)
static void C_ccall trf_995(C_word c,C_word *av) C_noret;
static void C_ccall trf_995(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_995(t0,t1);}

C_noret_decl(trf_1000)
static void C_ccall trf_1000(C_word c,C_word *av) C_noret;
static void C_ccall trf_1000(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1000(t0,t1);}

C_noret_decl(trf_657)
static void C_ccall trf_657(C_word c,C_word *av) C_noret;
static void C_ccall trf_657(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_657(t0,t1,t2);}

C_noret_decl(trf_855)
static void C_ccall trf_855(C_word c,C_word *av) C_noret;
static void C_ccall trf_855(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_855(t0,t1);}

C_noret_decl(trf_1116)
static void C_ccall trf_1116(C_word c,C_word *av) C_noret;
static void C_ccall trf_1116(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1116(t0,t1);}

C_noret_decl(trf_860)
static void C_ccall trf_860(C_word c,C_word *av) C_noret;
static void C_ccall trf_860(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_860(t0,t1,t2);}

C_noret_decl(trf_1083)
static void C_ccall trf_1083(C_word c,C_word *av) C_noret;
static void C_ccall trf_1083(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1083(t0,t1);}

C_noret_decl(trf_1085)
static void C_ccall trf_1085(C_word c,C_word *av) C_noret;
static void C_ccall trf_1085(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1085(t0,t1);}

C_noret_decl(trf_1143)
static void C_ccall trf_1143(C_word c,C_word *av) C_noret;
static void C_ccall trf_1143(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1143(t0,t1);}

C_noret_decl(trf_908)
static void C_ccall trf_908(C_word c,C_word *av) C_noret;
static void C_ccall trf_908(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_908(t0,t1);}

C_noret_decl(trf_913)
static void C_ccall trf_913(C_word c,C_word *av) C_noret;
static void C_ccall trf_913(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_913(t0,t1,t2);}

C_noret_decl(trf_683)
static void C_ccall trf_683(C_word c,C_word *av) C_noret;
static void C_ccall trf_683(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_683(t0,t1,t2);}

C_noret_decl(trf_1153)
static void C_ccall trf_1153(C_word c,C_word *av) C_noret;
static void C_ccall trf_1153(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1153(t0,t1);}

/* k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_752(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_752,2,av);}
a=C_alloc(12);
t2=t1;
t3=C_i_get_keyword(lf[26],((C_word*)t0)[2],C_SCHEME_FALSE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_758,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_983,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* utils.scm:84: make-pathname */
t7=*((C_word*)lf[49]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_758,2,av);}
a=C_alloc(10);
t2=(C_truep(t1)?t1:lf[27]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[3])){
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_764(2,av2);}}
else{
/* utils.scm:85: create-temporary-file */
t5=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[47];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* scan-input-lines in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +7,c,2))){
C_save_and_reclaim((void*)f_988,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+7);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
t4=C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[6]+1):C_i_car(t3));
t6=t5;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_995,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_closurep(t2))){
t8=t7;
f_995(t8,t2);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1029,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* utils.scm:120: irregex */
t9=*((C_word*)lf[55]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}

/* a984 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_985(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_985,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k981 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_983(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_983,2,av);}
/* utils.scm:84: file-exists? */
t2=*((C_word*)lf[48]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1175 in k1151 in k1148 in k1145 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1177(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1177,2,av);}
/* utils.scm:201: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1143(t2,((C_word*)t0)[3]);}

/* k875 in a852 in a831 in k816 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in ... */
static void C_ccall f_877(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_877,2,av);}
a=C_alloc(3);
/* tmp2552 */
t2=((C_word*)t0)[2];
f_860(t2,((C_word*)t0)[3],C_a_i_list(&a,1,t1));}

/* k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_764(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_764,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* utils.scm:86: build-platform */
t4=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k605 in read-all in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_607(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_607,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
/* read-string/port */
t2=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_615,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp);
/* utils.scm:55: with-input-from-file */
t3=*((C_word*)lf[8]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
av2[4]=lf[9];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k993 in scan-input-lines in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_fcall f_995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_995,2,t0,t1);}
a=C_alloc(8);
t2=t1;
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1000,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word)li23),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_1000(t6,((C_word*)t0)[3]);}

/* k1187 in k1184 in k1151 in k1148 in k1145 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1189(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1189,2,av);}
/* utils.scm:199: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[40]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[40]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* k1184 in k1151 in k1148 in k1145 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1186,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm:199: ##sys#print */
t3=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[72];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in ... */
static void C_ccall f_803(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_803,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
/* utils.scm:96: print */
t4=*((C_word*)lf[33]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[34];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_806(2,av2);}}}

/* k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in ... */
static void C_ccall f_806(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_806,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* utils.scm:97: system */
t3=*((C_word*)lf[3]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in ... */
static void C_ccall f_800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_800,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* utils.scm:87: get-output-string */
t3=*((C_word*)lf[35]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_734(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_734,2,av);}
a=C_alloc(6);
t2=C_mutate2((C_word*)lf[21]+1 /* (set! compile-file-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_738,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_CSC_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k1027 in scan-input-lines in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1029(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_1029,2,av);}
a=C_alloc(5);
t2=t1;
t3=*((C_word*)lf[54]+1);
t4=((C_word*)t0)[2];
f_995(t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1030,a[2]=t3,a[3]=t2,a[4]=((C_word)li24),tmp=(C_word)a,a+=5,tmp));}

/* k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_738(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_738,2,av);}
a=C_alloc(8);
t2=t1;
t3=*((C_word*)lf[22]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_741,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[84]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_BIN_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in ... */
static void C_ccall f_809(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_809,2,av);}
a=C_alloc(11);
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_818(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_882,a[2]=((C_word*)t0)[4],a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
/* utils.scm:100: on-exit */
t5=*((C_word*)lf[32]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}
else{
t3=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k580 in system* in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_582(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_582,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_585,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* utils.scm:44: system */
t4=*((C_word*)lf[3]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1228 in k1225 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1230(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_1230,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* utils.scm:188: ##sys#print */
t3=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[81];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1231 in k1228 in k1225 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1233(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_1233,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
/* utils.scm:188: ##sys#print */
t3=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[79];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
/* utils.scm:188: ##sys#print */
t3=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[80];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k1234 in k1231 in k1228 in k1225 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1236(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1236,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm:188: ##sys#print */
t3=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[78];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1196 in k1151 in k1148 in k1145 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1198(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1198,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm:200: ##sys#print */
t3=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[73];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k583 in k580 in system* in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_585(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_585,2,av);}
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* utils.scm:46: ##sys#error */
t3=*((C_word*)lf[1]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[2];
av2[3]=((C_word*)t0)[3];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_741(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_741,2,av);}
a=C_alloc(12);
t2=t1;
t3=C_mutate2((C_word*)lf[23]+1 /* (set! compile-file ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_742,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word)li22),tmp=(C_word)a,a+=6,tmp));
t4=C_mutate2((C_word*)lf[52]+1 /* (set! scan-input-lines ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_988,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[56]+1 /* (set! yes-or-no? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1070,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_742(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +13,c,4))){
C_save_and_reclaim((void*)f_742,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+13);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=C_i_get_keyword(lf[24],t3,C_SCHEME_FALSE);
t5=t4;
t6=C_i_get_keyword(lf[25],t3,C_SCHEME_FALSE);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_752,a[2]=t3,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=t5,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_985,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
/* utils.scm:80: ##sys#get-keyword */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[50]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[50]+1);
av2[1]=t8;
av2[2]=lf[51];
av2[3]=t3;
av2[4]=t9;
tp(5,av2);}}

/* k816 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in ... */
static void C_ccall f_818(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_818,2,av);}
a=C_alloc(8);
if(C_truep(((C_word*)t0)[2])){
t2=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:((C_word*)t0)[4]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_827,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_832,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* utils.scm:104: call-with-current-continuation */
t6=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* f_1030 in k1027 in scan-input-lines in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1030(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1030,3,av);}
/* utils.scm:120: g225226 */
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_973(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_973,2,av);}
a=C_alloc(12);
t2=C_eqp(t1,lf[12]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* utils.scm:87: open-output-string */
t5=*((C_word*)lf[45]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* read-all in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_597(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_597,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t3=C_i_nullp(t2);
t4=(C_truep(t3)?*((C_word*)lf[6]+1):C_i_car(t2));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_607,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* utils.scm:53: port? */
t7=*((C_word*)lf[10]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k825 in k816 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in ... */
static void C_ccall f_827(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_827,2,av);}
/* utils.scm:104: g199 */
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* k1002 in loop in k993 in scan-input-lines in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1004(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1004,2,av);}
a=C_alloc(4);
if(C_truep(C_eofp(t1))){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm:124: rx */
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* loop in k993 in scan-input-lines in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_fcall f_1000(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_1000,2,t0,t1);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1004,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm:122: read-line */
t3=*((C_word*)lf[53]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k1011 in k1002 in loop in k993 in scan-input-lines in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1013(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1013,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
/* utils.scm:125: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1000(t2,((C_word*)t0)[2]);}}

/* k963 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_965,2,av);}
/* utils.scm:87: ##sys#print */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* g103 in k629 in qs in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_fcall f_657(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(2,0,4))){
C_save_and_reclaim_args((void *)trf_657,3,t0,t1,t2);}
a=C_alloc(2);
if(C_truep(C_i_char_equalp(t2,((C_word*)t0)[2]))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=t2;
if(C_truep(C_u_i_char_equalp(t3,C_make_character(0)))){
/* utils.scm:69: error */
t4=*((C_word*)lf[16]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[11];
av2[3]=lf[17];
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_a_i_string(&a,1,t2);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}}

/* a843 in a837 in a831 in k816 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in ... */
static void C_ccall f_844(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_844,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_848,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* utils.scm:107: delete-file* */
t3=*((C_word*)lf[29]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k846 in a843 in a837 in a831 in k816 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in ... */
static void C_ccall f_848(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_848,2,av);}
/* utils.scm:108: abort */
t2=*((C_word*)lf[28]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;

void C_ccall C_utils_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_utils_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(405)){
C_save(t1);
C_rereclaim2(405*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,89);
lf[0]=C_h_intern(&lf[0],7,"system\052");
lf[1]=C_h_intern(&lf[1],9,"\003syserror");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\0003shell invocation failed with non-zero return status");
lf[3]=C_h_intern(&lf[3],6,"system");
lf[4]=C_h_intern(&lf[4],7,"sprintf");
lf[5]=C_h_intern(&lf[5],8,"read-all");
lf[6]=C_h_intern(&lf[6],18,"\003sysstandard-input");
lf[7]=C_h_intern(&lf[7],20,"\003sysread-string/port");
lf[8]=C_h_intern(&lf[8],20,"with-input-from-file");
lf[9]=C_h_intern(&lf[9],7,"\000binary");
lf[10]=C_h_intern(&lf[10],5,"port\077");
lf[11]=C_h_intern(&lf[11],2,"qs");
lf[12]=C_h_intern(&lf[12],7,"mingw32");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\002\042\042");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\004\047\134\047\047");
lf[15]=C_h_intern(&lf[15],13,"string-append");
lf[16]=C_h_intern(&lf[16],5,"error");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\0004NUL character can not be represented in shell string");
lf[18]=C_h_intern(&lf[18],18,"string-concatenate");
lf[19]=C_h_intern(&lf[19],16,"\003sysstring->list");
lf[20]=C_h_intern(&lf[20],14,"build-platform");
lf[21]=C_h_intern(&lf[21],20,"compile-file-options");
lf[22]=C_h_intern(&lf[22],4,"load");
lf[23]=C_h_intern(&lf[23],12,"compile-file");
lf[24]=C_h_intern(&lf[24],8,"\000options");
lf[25]=C_h_intern(&lf[25],12,"\000output-file");
lf[26]=C_h_intern(&lf[26],8,"\000verbose");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[28]=C_h_intern(&lf[28],5,"abort");
lf[29]=C_h_intern(&lf[29],12,"delete-file\052");
lf[30]=C_h_intern(&lf[30],22,"with-exception-handler");
lf[31]=C_h_intern(&lf[31],30,"call-with-current-continuation");
lf[32]=C_h_intern(&lf[32],7,"on-exit");
lf[33]=C_h_intern(&lf[33],5,"print");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[35]=C_h_intern(&lf[35],17,"get-output-string");
lf[36]=C_h_intern(&lf[36],9,"\003sysprint");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\004 -o ");
lf[40]=C_h_intern(&lf[40],16,"\003syswrite-char-0");
lf[41]=C_h_intern(&lf[41],18,"string-intersperse");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\004 -s ");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[45]=C_h_intern(&lf[45],18,"open-output-string");
lf[46]=C_h_intern(&lf[46],21,"create-temporary-file");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[48]=C_h_intern(&lf[48],12,"file-exists\077");
lf[49]=C_h_intern(&lf[49],13,"make-pathname");
lf[50]=C_h_intern(&lf[50],15,"\003sysget-keyword");
lf[51]=C_h_intern(&lf[51],5,"\000load");
lf[52]=C_h_intern(&lf[52],16,"scan-input-lines");
lf[53]=C_h_intern(&lf[53],9,"read-line");
lf[54]=C_h_intern(&lf[54],14,"irregex-search");
lf[55]=C_h_intern(&lf[55],7,"irregex");
lf[56]=C_h_intern(&lf[56],10,"yes-or-no\077");
lf[57]=C_h_intern(&lf[57],8,"\000default");
lf[58]=C_h_intern(&lf[58],6,"\000title");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\003yes");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN Runtime");
lf[63]=C_h_intern(&lf[63],17,"\003sysmake-c-string");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\003yes");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[66]=C_h_intern(&lf[66],16,"string-trim-both");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\003yes");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[70]=C_h_intern(&lf[70],19,"\003sysstandard-output");
lf[71]=C_h_intern(&lf[71],6,"printf");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000$Please enter \042yes\042, \042no\042 or \042abort\042.");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\033Please enter \042yes\042 or \042no\042.");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[76]=C_h_intern(&lf[76],12,"flush-output");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\002] ");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\006/abort");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\010 (yes/no");
lf[82]=C_h_intern(&lf[82],5,"reset");
lf[83]=C_h_intern(&lf[83],6,"\000abort");
lf[84]=C_h_intern(&lf[84],17,"\003syspeek-c-string");
lf[85]=C_h_intern(&lf[85],14,"make-parameter");
lf[86]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-O2\376\003\000\000\002\376B\000\000\003-d2\376\377\016");
lf[87]=C_h_intern(&lf[87],17,"register-feature!");
lf[88]=C_h_intern(&lf[88],5,"utils");
C_register_lf2(lf,89,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_558,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* qs in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_627(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_627,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+4);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_631,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* utils.scm:60: build-platform */
t5=*((C_word*)lf[20]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_i_car(t3);
f_631(2,av2);}}}

/* a852 in a831 in k816 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in ... */
static void C_ccall f_853(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_853,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_860,a[2]=((C_word*)t0)[4],a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_877,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tmp1551 */
t5=t2;
f_855(t5,t4);}

/* tmp1551 in a852 in a831 in k816 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in ... */
static void C_fcall f_855(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_855,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_859,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* utils.scm:109: load-file */
t3=((C_word*)t0)[3];{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k857 in tmp1551 in a852 in a831 in k816 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in ... */
static void C_ccall f_859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_859,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k940 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in ... */
static void C_ccall f_942(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_942,2,av);}
/* utils.scm:87: ##sys#print */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1114 in get-input in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_fcall f_1116(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_1116,2,t0,t1);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
t5=t1;
t6=((C_word*)t0)[5];
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1047,a[2]=t5,a[3]=t2,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t8=C_i_foreign_string_argumentp(t3);
/* utils.scm:168: ##sys#make-c-string */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[63]+1));
C_word av2[3];
av2[0]=*((C_word*)lf[63]+1);
av2[1]=t7;
av2[2]=t8;
tp(3,av2);}}
else{
t8=t7;{
C_word av2[2];
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
f_1047(2,av2);}}}

/* tmp2552 in a852 in a831 in k816 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in ... */
static void C_fcall f_860(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_860,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_866,a[2]=t2,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp);
/* utils.scm:104: k195 */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* a865 in tmp2552 in a852 in a831 in k816 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in ... */
static void C_ccall f_866(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_866,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k948 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 in ... */
static void C_ccall f_950(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_950,2,av);}
/* utils.scm:87: ##sys#print */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k952 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_954(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_954,2,av);}
/* utils.scm:87: ##sys#print */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k956 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_958(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_958,2,av);}
/* utils.scm:90: string-intersperse */
t2=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k646 in k629 in qs in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_648(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(2,c,4))){C_save_and_reclaim((void *)f_648,2,av);}
a=C_alloc(2);
t2=C_a_i_string(&a,1,((C_word*)t0)[2]);
/* utils.scm:63: string-append */
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=t1;
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_fcall f_1083(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(19,0,2))){
C_save_and_reclaim_args((void *)trf_1083,2,t0,t1);}
a=C_alloc(19);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1085,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li26),tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1143,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word)li27),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_1143(t7,((C_word*)t0)[6]);}

/* get-input in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_fcall f_1085(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_1085,2,t0,t1);}
a=C_alloc(9);
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1092,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:lf[62]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1116,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
if(C_truep(C_i_string_ci_equal_p(((C_word*)t0)[6],lf[64]))){
t6=t5;
f_1116(t6,C_fix(0));}
else{
t6=C_i_string_ci_equal_p(((C_word*)t0)[6],lf[65]);
t7=t5;
f_1116(t7,(C_truep(t6)?C_fix(1):C_fix(2)));}}
else{
t6=t5;
f_1116(t6,C_fix(3));}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1138,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm:185: read-line */
t3=*((C_word*)lf[53]+1);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1136 in get-input in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1138(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1138,2,av);}
/* utils.scm:185: string-trim-both */
t2=*((C_word*)lf[66]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1080(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_1080,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1083,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_mk_bool(C_HAS_MESSAGE_BOX))){
t4=C_fudge(C_fix(4));
t5=t3;
f_1083(t5,C_i_not(t4));}
else{
t4=t3;
f_1083(t4,C_SCHEME_FALSE);}}

/* k928 in a905 in a890 in a881 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in ... */
static void C_ccall f_930(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_930,2,av);}
a=C_alloc(3);
/* tmp2550 */
t2=((C_word*)t0)[2];
f_913(t2,((C_word*)t0)[3],C_a_i_list(&a,1,t1));}

/* loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_fcall f_1143(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(14,0,3))){
C_save_and_reclaim_args((void *)trf_1143,2,t0,t1);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1147,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=t2;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_1147(2,av2);}}
else{
t3=*((C_word*)lf[70]+1);
t4=*((C_word*)lf[70]+1);
t5=C_i_check_port_2(*((C_word*)lf[70]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[71]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1227,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* utils.scm:188: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[40]+1));
C_word av2[4];
av2[0]=*((C_word*)lf[40]+1);
av2[1]=t6;
av2[2]=C_make_character(10);
av2[3]=*((C_word*)lf[70]+1);
tp(4,av2);}}}

/* k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in ... */
static void C_ccall f_797(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_797,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[9])){
/* utils.scm:87: ##sys#print */
t3=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[37];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[10];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
/* utils.scm:87: ##sys#print */
t3=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[38];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[10];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k1145 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1147(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_1147,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* utils.scm:191: get-input */
t3=((C_word*)t0)[6];
f_1085(t3,t2);}

/* k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in ... */
static void C_ccall f_794(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_794,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_942,a[2]=t2,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
/* utils.scm:94: qs */
t4=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
/* utils.scm:94: qs */
t4=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 in ... */
static void C_ccall f_791(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_791,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* utils.scm:87: ##sys#print */
t3=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[39];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[10];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1090 in get-input in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1092(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1092,2,av);}
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=lf[59];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=C_eqp(t1,C_fix(1));
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=(C_truep(t3)?lf[60]:lf[61]);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a905 in a890 in a881 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in ... */
static void C_ccall f_906(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_906,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_908,a[2]=((C_word*)t0)[2],a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_913,a[2]=((C_word*)t0)[3],a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_930,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tmp1549 */
t5=t2;
f_908(t5,t4);}

/* a902 in a896 in a890 in a881 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in ... */
static void C_ccall f_903(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_903,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1252 in k1249 in k1237 in k1234 in k1231 in k1228 in k1225 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1254(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1254,2,av);}
/* utils.scm:189: ##sys#print */
t2=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[77];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k1249 in k1237 in k1234 in k1231 in k1228 in k1225 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1251(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1251,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm:189: ##sys#print */
t3=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* tmp1549 in a905 in a890 in a881 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in ... */
static void C_fcall f_908(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_908,2,t0,t1);}
/* utils.scm:102: delete-file* */
t2=*((C_word*)lf[29]+1);{
C_word av2[3];
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* tmp2550 in a905 in a890 in a881 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in ... */
static void C_fcall f_913(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_913,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_919,a[2]=t2,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp);
/* utils.scm:101: k182 */
t4=((C_word*)t0)[2];{
C_word av2[3];
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_779(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(13,c,4))){C_save_and_reclaim((void *)f_779,2,av);}
a=C_alloc(13);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* utils.scm:87: ##sys#print */
t3=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[42];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[10];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_776(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(17,c,2))){C_save_and_reclaim((void *)f_776,2,av);}
a=C_alloc(17);
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_965,a[2]=t2,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* utils.scm:89: qs */
t4=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[13];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a918 in tmp2550 in a905 in a890 in a881 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in ... */
static void C_ccall f_919(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_919,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1070(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +9,c,4))){
C_save_and_reclaim((void*)f_1070,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+9);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=C_i_get_keyword(lf[57],t3,C_SCHEME_FALSE);
t5=t4;
t6=C_i_get_keyword(lf[58],t3,C_SCHEME_FALSE);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1080,a[2]=t7,a[3]=t2,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1270,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp);
/* utils.scm:168: ##sys#get-keyword */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[50]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[50]+1);
av2[1]=t8;
av2[2]=lf[83];
av2[3]=t3;
av2[4]=t9;
tp(5,av2);}}

/* k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_770(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(14,c,4))){C_save_and_reclaim((void *)f_770,2,av);}
a=C_alloc(14);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[4]);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=t3,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[8])){
/* utils.scm:87: ##sys#print */
t6=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[43];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}
else{
/* utils.scm:87: ##sys#print */
t6=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[44];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}}

/* a831 in k816 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in ... */
static void C_ccall f_832(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_832,3,av);}
a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_838,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li7),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word)li11),tmp=(C_word)a,a+=6,tmp);
/* utils.scm:104: with-exception-handler */
t5=*((C_word*)lf[30]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* a837 in a831 in k816 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in ... */
static void C_ccall f_838(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_838,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_844,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li6),tmp=(C_word)a,a+=5,tmp);
/* utils.scm:104: k195 */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_785(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_785,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* utils.scm:87: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[40]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[40]+1);
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[10];
tp(4,av2);}}

/* k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_788(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_788,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_950,a[2]=t2,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* utils.scm:93: qs */
t4=*((C_word*)lf[11]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[11];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_782(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(19,c,2))){C_save_and_reclaim((void *)f_782,2,av);}
a=C_alloc(19);
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_954,a[2]=t2,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_958,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[12])){
/* utils.scm:90: string-intersperse */
t5=*((C_word*)lf[41]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=((C_word*)t0)[12];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
/* utils.scm:92: compile-file-options */
t5=*((C_word*)lf[21]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k1045 in k1114 in get-input in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1047(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_1047,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_i_foreign_string_argumentp(((C_word*)t0)[5]);
/* utils.scm:168: ##sys#make-c-string */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[63]+1));
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[63]+1);
av2[1]=t3;
av2[2]=t4;
tp(3,av2);}}
else{
t4=C_i_foreign_fixnum_argumentp(((C_word*)t0)[2]);
t5=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=stub247(C_SCHEME_UNDEFINED,t2,C_SCHEME_FALSE,t4,((C_word*)t0)[4]);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k1199 in k1196 in k1151 in k1148 in k1145 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1201(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1201,2,av);}
/* utils.scm:200: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[40]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[40]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=C_make_character(10);
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* k1049 in k1045 in k1114 in get-input in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1051(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1051,2,av);}
t2=C_i_foreign_fixnum_argumentp(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=stub247(C_SCHEME_UNDEFINED,((C_word*)t0)[4],t1,t2,((C_word*)t0)[5]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k629 in qs in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_631(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
if(!C_demand(C_calculate_demand(24,c,3))){C_save_and_reclaim((void *)f_631,2,av);}
a=C_alloc(24);
t2=C_eqp(t1,lf[12]);
t3=(C_truep(t2)?C_make_character(34):C_make_character(39));
t4=t3;
t5=C_eqp(t1,lf[12]);
t6=(C_truep(t5)?lf[13]:lf[14]);
t7=t6;
t8=C_a_i_string(&a,1,t4);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_648,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t12=t11;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=((C_word*)t13)[1];
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_657,a[2]=t4,a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp);
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_678,a[2]=t10,a[3]=t13,a[4]=t15,a[5]=t14,tmp=(C_word)a,a+=6,tmp);
/* string->list */
t17=*((C_word*)lf[19]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t17;
av2[1]=t16;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t17+1)))(3,av2);}}

/* a1269 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1270,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=*((C_word*)lf[82]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k679 in k676 in k629 in qs in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_681(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_681,2,av);}
/* utils.scm:65: string-concatenate */
t2=*((C_word*)lf[18]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop97 in k676 in k629 in qs in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_fcall f_683(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_683,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_708,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* utils.scm:66: g103 */
t5=((C_word*)t0)[4];
f_657(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k884 in a881 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in ... */
static void C_ccall f_886(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_886,2,av);}
/* utils.scm:101: g186 */
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* a881 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in k732 in ... */
static void C_ccall f_882(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_882,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_886,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_891,a[2]=((C_word*)t0)[2],a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
/* utils.scm:101: call-with-current-continuation */
t4=*((C_word*)lf[31]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a896 in a890 in a881 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in ... */
static void C_ccall f_897(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_897,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_903,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp);
/* utils.scm:101: k182 */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* a890 in a881 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 in k780 in k777 in k774 in k768 in k971 in k762 in k756 in k750 in compile-file in k739 in k736 in ... */
static void C_ccall f_891(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_891,3,av);}
a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_897,a[2]=t2,a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_906,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li18),tmp=(C_word)a,a+=5,tmp);
/* utils.scm:101: with-exception-handler */
t5=*((C_word*)lf[30]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k1240 in k1237 in k1234 in k1231 in k1228 in k1225 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1242(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1242,2,av);}
/* utils.scm:190: flush-output */
t2=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1237 in k1234 in k1231 in k1228 in k1225 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1239(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_1239,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1242,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=*((C_word*)lf[70]+1);
t4=*((C_word*)lf[70]+1);
t5=C_i_check_port_2(*((C_word*)lf[70]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[71]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1251,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* utils.scm:189: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[40]+1));
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[40]+1);
av2[1]=t6;
av2[2]=C_make_character(91);
av2[3]=*((C_word*)lf[70]+1);
tp(4,av2);}}
else{
/* utils.scm:190: flush-output */
t3=*((C_word*)lf[76]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k676 in k629 in qs in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_678(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_678,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_681,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_683,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li4),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_683(t6,t2,t1);}

/* k562 in k559 in k556 */
static void C_ccall f_564(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_564,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_567,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_posix_toplevel(2,av2);}}

/* k559 in k556 */
static void C_ccall f_561(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_561,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_564,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_srfi_2d13_toplevel(2,av2);}}

/* k565 in k562 in k559 in k556 */
static void C_ccall f_567(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_567,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_570,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_files_toplevel(2,av2);}}

/* k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_573,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_576,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm:36: register-feature! */
t3=*((C_word*)lf[87]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[88];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_570(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_570,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_573,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_irregex_toplevel(2,av2);}}

/* k1225 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1227(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_1227,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* utils.scm:188: ##sys#print */
t3=*((C_word*)lf[36]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* system* in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_578(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(C_calculate_demand((c-3)*C_SIZEOF_PAIR +3,c,4))){
C_save_and_reclaim((void*)f_578,c,av);}
a=C_alloc((c-3)*C_SIZEOF_PAIR+3);
t3=C_build_rest(&a,c,3,av);
C_word t4;
C_word t5;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_582,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t4;
av2[2]=*((C_word*)lf[4]+1);
av2[3]=t2;
av2[4]=t3;
C_apply(5,av2);}}

/* k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_576(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_576,2,av);}
a=C_alloc(12);
t2=C_mutate2((C_word*)lf[0]+1 /* (set! system* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_578,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate2((C_word*)lf[5]+1 /* (set! read-all ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_597,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[11]+1 /* (set! qs ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_627,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_734,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm:77: make-parameter */
t6=*((C_word*)lf[85]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[86];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k556 */
static void C_ccall f_558(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_558,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_561,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_extras_toplevel(2,av2);}}

/* a614 in k605 in read-all in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_615(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_615,2,av);}
/* read-string/port */
t2=*((C_word*)lf[7]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=C_SCHEME_FALSE;
av2[3]=*((C_word*)lf[6]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1151 in k1148 in k1145 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_fcall f_1153(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_1153,2,t0,t1);}
a=C_alloc(8);
if(C_truep(C_i_string_ci_equal_p(lf[67],((C_word*)((C_word*)t0)[2])[1]))){
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
if(C_truep(C_i_string_ci_equal_p(lf[68],((C_word*)((C_word*)t0)[2])[1]))){
t2=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(C_truep(((C_word*)t0)[4])?C_i_string_ci_equal_p(lf[69],((C_word*)((C_word*)t0)[2])[1]):C_SCHEME_FALSE);
if(C_truep(t2)){
/* utils.scm:196: abort */
t3=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
((C_proc)C_fast_retrieve_proc(t3))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1177,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=*((C_word*)lf[70]+1);
t5=*((C_word*)lf[70]+1);
t6=C_i_check_port_2(*((C_word*)lf[70]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[71]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1186,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* utils.scm:199: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[40]+1));
C_word av2[4];
av2[0]=*((C_word*)lf[40]+1);
av2[1]=t7;
av2[2]=C_make_character(10);
av2[3]=*((C_word*)lf[70]+1);
tp(4,av2);}}
else{
t4=*((C_word*)lf[70]+1);
t5=*((C_word*)lf[70]+1);
t6=C_i_check_port_2(*((C_word*)lf[70]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[71]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1198,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* utils.scm:200: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[40]+1));
C_word av2[4];
av2[0]=*((C_word*)lf[40]+1);
av2[1]=t7;
av2[2]=C_make_character(10);
av2[3]=*((C_word*)lf[70]+1);
tp(4,av2);}}}}}}

/* k1148 in k1145 in loop in k1081 in k1078 in yes-or-no? in k739 in k736 in k732 in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_1150(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_1150,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1153,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_eofp(((C_word*)t3)[1]))){
t5=C_set_block_item(t3,0,lf[74]);
t6=t4;
f_1153(t6,t5);}
else{
if(C_truep(((C_word*)t0)[5])){
if(C_truep(C_i_string_equal_p(lf[75],((C_word*)t3)[1]))){
t5=C_set_block_item(t3,0,((C_word*)t0)[5]);
t6=t4;
f_1153(t6,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t4;
f_1153(t6,t5);}}
else{
t5=C_SCHEME_UNDEFINED;
t6=t4;
f_1153(t6,t5);}}}

/* k706 in map-loop97 in k676 in k629 in qs in k574 in k571 in k568 in k565 in k562 in k559 in k556 */
static void C_ccall f_708(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_708,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_683(t6,((C_word*)t0)[5],t5);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[107] = {
{"f_752:utils_2escm",(void*)f_752},
{"f_758:utils_2escm",(void*)f_758},
{"f_988:utils_2escm",(void*)f_988},
{"f_985:utils_2escm",(void*)f_985},
{"f_983:utils_2escm",(void*)f_983},
{"f_1177:utils_2escm",(void*)f_1177},
{"f_877:utils_2escm",(void*)f_877},
{"f_764:utils_2escm",(void*)f_764},
{"f_607:utils_2escm",(void*)f_607},
{"f_995:utils_2escm",(void*)f_995},
{"f_1189:utils_2escm",(void*)f_1189},
{"f_1186:utils_2escm",(void*)f_1186},
{"f_803:utils_2escm",(void*)f_803},
{"f_806:utils_2escm",(void*)f_806},
{"f_800:utils_2escm",(void*)f_800},
{"f_734:utils_2escm",(void*)f_734},
{"f_1029:utils_2escm",(void*)f_1029},
{"f_738:utils_2escm",(void*)f_738},
{"f_809:utils_2escm",(void*)f_809},
{"f_582:utils_2escm",(void*)f_582},
{"f_1230:utils_2escm",(void*)f_1230},
{"f_1233:utils_2escm",(void*)f_1233},
{"f_1236:utils_2escm",(void*)f_1236},
{"f_1198:utils_2escm",(void*)f_1198},
{"f_585:utils_2escm",(void*)f_585},
{"f_741:utils_2escm",(void*)f_741},
{"f_742:utils_2escm",(void*)f_742},
{"f_818:utils_2escm",(void*)f_818},
{"f_1030:utils_2escm",(void*)f_1030},
{"f_973:utils_2escm",(void*)f_973},
{"f_597:utils_2escm",(void*)f_597},
{"f_827:utils_2escm",(void*)f_827},
{"f_1004:utils_2escm",(void*)f_1004},
{"f_1000:utils_2escm",(void*)f_1000},
{"f_1013:utils_2escm",(void*)f_1013},
{"f_965:utils_2escm",(void*)f_965},
{"f_657:utils_2escm",(void*)f_657},
{"f_844:utils_2escm",(void*)f_844},
{"f_848:utils_2escm",(void*)f_848},
{"toplevel:utils_2escm",(void*)C_utils_toplevel},
{"f_627:utils_2escm",(void*)f_627},
{"f_853:utils_2escm",(void*)f_853},
{"f_855:utils_2escm",(void*)f_855},
{"f_859:utils_2escm",(void*)f_859},
{"f_942:utils_2escm",(void*)f_942},
{"f_1116:utils_2escm",(void*)f_1116},
{"f_860:utils_2escm",(void*)f_860},
{"f_866:utils_2escm",(void*)f_866},
{"f_950:utils_2escm",(void*)f_950},
{"f_954:utils_2escm",(void*)f_954},
{"f_958:utils_2escm",(void*)f_958},
{"f_648:utils_2escm",(void*)f_648},
{"f_1083:utils_2escm",(void*)f_1083},
{"f_1085:utils_2escm",(void*)f_1085},
{"f_1138:utils_2escm",(void*)f_1138},
{"f_1080:utils_2escm",(void*)f_1080},
{"f_930:utils_2escm",(void*)f_930},
{"f_1143:utils_2escm",(void*)f_1143},
{"f_797:utils_2escm",(void*)f_797},
{"f_1147:utils_2escm",(void*)f_1147},
{"f_794:utils_2escm",(void*)f_794},
{"f_791:utils_2escm",(void*)f_791},
{"f_1092:utils_2escm",(void*)f_1092},
{"f_906:utils_2escm",(void*)f_906},
{"f_903:utils_2escm",(void*)f_903},
{"f_1254:utils_2escm",(void*)f_1254},
{"f_1251:utils_2escm",(void*)f_1251},
{"f_908:utils_2escm",(void*)f_908},
{"f_913:utils_2escm",(void*)f_913},
{"f_779:utils_2escm",(void*)f_779},
{"f_776:utils_2escm",(void*)f_776},
{"f_919:utils_2escm",(void*)f_919},
{"f_1070:utils_2escm",(void*)f_1070},
{"f_770:utils_2escm",(void*)f_770},
{"f_832:utils_2escm",(void*)f_832},
{"f_838:utils_2escm",(void*)f_838},
{"f_785:utils_2escm",(void*)f_785},
{"f_788:utils_2escm",(void*)f_788},
{"f_782:utils_2escm",(void*)f_782},
{"f_1047:utils_2escm",(void*)f_1047},
{"f_1201:utils_2escm",(void*)f_1201},
{"f_1051:utils_2escm",(void*)f_1051},
{"f_631:utils_2escm",(void*)f_631},
{"f_1270:utils_2escm",(void*)f_1270},
{"f_681:utils_2escm",(void*)f_681},
{"f_683:utils_2escm",(void*)f_683},
{"f_886:utils_2escm",(void*)f_886},
{"f_882:utils_2escm",(void*)f_882},
{"f_897:utils_2escm",(void*)f_897},
{"f_891:utils_2escm",(void*)f_891},
{"f_1242:utils_2escm",(void*)f_1242},
{"f_1239:utils_2escm",(void*)f_1239},
{"f_678:utils_2escm",(void*)f_678},
{"f_564:utils_2escm",(void*)f_564},
{"f_561:utils_2escm",(void*)f_561},
{"f_567:utils_2escm",(void*)f_567},
{"f_573:utils_2escm",(void*)f_573},
{"f_570:utils_2escm",(void*)f_570},
{"f_1227:utils_2escm",(void*)f_1227},
{"f_578:utils_2escm",(void*)f_578},
{"f_576:utils_2escm",(void*)f_576},
{"f_558:utils_2escm",(void*)f_558},
{"f_615:utils_2escm",(void*)f_615},
{"f_1153:utils_2escm",(void*)f_1153},
{"f_1150:utils_2escm",(void*)f_1150},
{"f_708:utils_2escm",(void*)f_708},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  printf		4
S|  sprintf		1
S|  map		1
o|eliminated procedure checks: 32 
o|specializations:
o|  2 (eqv? (not float) *)
o|  2 (##sys#call-with-values (procedure () *) *)
o|  5 (##sys#check-output-port * * *)
o|  1 (##sys#check-list (or pair list) *)
o|  1 (char=? char char)
o|  2 (zero? fixnum)
(o e)|safe calls: 88 
o|Removed `not' forms: 3 
o|inlining procedure: k586 
o|inlining procedure: k586 
o|inlining procedure: k602 
o|inlining procedure: k602 
o|inlining procedure: k659 
o|inlining procedure: k659 
o|substituted constant variable: a669 
o|inlining procedure: k685 
o|inlining procedure: k685 
o|substituted constant variable: a772 
o|substituted constant variable: a773 
o|inlining procedure: k810 
o|merged explicitly consed rest parameter: args196205 
o|consed rest parameter at call site: tmp2552 1 
o|merged explicitly consed rest parameter: args183190 
o|consed rest parameter at call site: tmp2550 1 
o|inlining procedure: k810 
o|inlining procedure: k936 
o|inlining procedure: k936 
o|inlining procedure: k944 
o|inlining procedure: k944 
o|inlining procedure: k956 
o|inlining procedure: k956 
o|inlining procedure: k967 
o|inlining procedure: k967 
o|contracted procedure: k974 
o|contracted procedure: k1008 
o|inlining procedure: k1005 
o|inlining procedure: k1005 
o|inlining procedure: k1087 
o|inlining procedure: k1099 
o|inlining procedure: k1099 
o|substituted constant variable: a1106 
o|substituted constant variable: a1108 
o|contracted procedure: "(utils.scm:173) dialog242" 
o|contracted procedure: k1117 
o|inlining procedure: k1120 
o|inlining procedure: k1120 
o|inlining procedure: k1087 
o|inlining procedure: k1154 
o|inlining procedure: k1154 
o|inlining procedure: k1166 
o|inlining procedure: k1166 
o|propagated global variable: out316320 ##sys#standard-output 
o|substituted constant variable: a1182 
o|substituted constant variable: a1183 
o|propagated global variable: out316320 ##sys#standard-output 
o|propagated global variable: out324328 ##sys#standard-output 
o|substituted constant variable: a1194 
o|substituted constant variable: a1195 
o|propagated global variable: out324328 ##sys#standard-output 
o|inlining procedure: k1212 
o|inlining procedure: k1212 
o|propagated global variable: out285289 ##sys#standard-output 
o|substituted constant variable: a1223 
o|substituted constant variable: a1224 
o|propagated global variable: out295299 ##sys#standard-output 
o|substituted constant variable: a1247 
o|substituted constant variable: a1248 
o|inlining procedure: k1240 
o|propagated global variable: out295299 ##sys#standard-output 
o|inlining procedure: k1240 
o|inlining procedure: k1259 
o|inlining procedure: k1259 
o|propagated global variable: out285289 ##sys#standard-output 
o|replaced variables: 116 
o|removed binding forms: 54 
o|substituted constant variable: r8111281 
o|substituted constant variable: r9371282 
o|substituted constant variable: r9371282 
o|substituted constant variable: r9371284 
o|substituted constant variable: r9371284 
o|substituted constant variable: r9681294 
o|substituted constant variable: r9681294 
o|substituted constant variable: r9681296 
o|substituted constant variable: r9681296 
o|substituted constant variable: r10061298 
o|substituted constant variable: r11001301 
o|substituted constant variable: r11001302 
o|substituted constant variable: r11211303 
o|substituted constant variable: r11551306 
o|propagated global variable: out316320 ##sys#standard-output 
o|propagated global variable: out324328 ##sys#standard-output 
o|propagated global variable: out285289 ##sys#standard-output 
o|propagated global variable: out295299 ##sys#standard-output 
o|substituted constant variable: r12601322 
o|substituted constant variable: r12601322 
o|substituted constant variable: r12601324 
o|substituted constant variable: r12601324 
o|converted assignments to bindings: (get-input269) 
o|simplifications: ((let . 1)) 
o|replaced variables: 13 
o|removed binding forms: 122 
o|replaced variables: 1 
o|removed binding forms: 31 
o|inlining procedure: k1215 
o|removed binding forms: 1 
o|substituted constant variable: r12161347 
o|removed conditional forms: 1 
o|removed binding forms: 1 
o|simplifications: ((if . 10) (##core#call . 49)) 
o|  call simplifications:
o|    ##sys#fudge
o|    not
o|    string=?
o|    string-ci=?	5
o|    ##sys#foreign-string-argument	2
o|    ##sys#foreign-fixnum-argument
o|    procedure?
o|    eof-object?	2
o|    ##sys#get-keyword	5
o|    ##sys#apply	2
o|    string->list
o|    pair?
o|    cons	2
o|    ##sys#setslot
o|    ##sys#slot	3
o|    char=?
o|    string	3
o|    null?	3
o|    car	3
o|    read-string	2
o|    apply
o|    eq?	7
o|contracted procedure: k589 
o|contracted procedure: k620 
o|contracted procedure: k599 
o|contracted procedure: k719 
o|contracted procedure: k632 
o|contracted procedure: k716 
o|contracted procedure: k635 
o|contracted procedure: k642 
o|contracted procedure: k650 
o|contracted procedure: k654 
o|contracted procedure: k662 
o|contracted procedure: k688 
o|contracted procedure: k691 
o|contracted procedure: k694 
o|contracted procedure: k702 
o|contracted procedure: k710 
o|contracted procedure: k722 
o|contracted procedure: k744 
o|contracted procedure: k747 
o|contracted procedure: k753 
o|contracted procedure: k759 
o|contracted procedure: k765 
o|contracted procedure: k813 
o|contracted procedure: k822 
o|contracted procedure: k1035 
o|contracted procedure: k990 
o|contracted procedure: k1021 
o|contracted procedure: k1024 
o|contracted procedure: k1072 
o|contracted procedure: k1075 
o|contracted procedure: k1096 
o|contracted procedure: k1102 
o|contracted procedure: k1110 
o|contracted procedure: k1053 
o|contracted procedure: k1060 
o|contracted procedure: k1067 
o|contracted procedure: k1123 
o|contracted procedure: k1129 
o|contracted procedure: k1157 
o|contracted procedure: k1163 
o|contracted procedure: k1169 
o|contracted procedure: k1208 
o|contracted procedure: k1215 
o|contracted procedure: k1266 
o|simplifications: ((let . 10)) 
o|removed binding forms: 44 
o|inlining procedure: k1049 
o|replaced variables: 18 
o|substituted constant variable: r10501386 
o|substituted constant variable: r10501386 
o|removed binding forms: 10 
o|removed binding forms: 2 
o|customizable procedures: (k1081 get-input269 k1151 loop284 k1114 k993 loop234 tmp1549 tmp2550 tmp1551 tmp2552 g103112 map-loop97119) 
o|calls to known targets: 29 
o|fast box initializations: 5 
*/
/* end of file */
