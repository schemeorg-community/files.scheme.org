/* Generated from chicken-install.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:51
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: chicken-install.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -local -no-trace -output-file chicken-install.c
   used units: library eval chicken_2dsyntax srfi_2d1 posix data_2dstructures utils irregex ports extras srfi_2d13 files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_srfi_2d1_toplevel)
C_externimport void C_ccall C_srfi_2d1_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_irregex_toplevel)
C_externimport void C_ccall C_irregex_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_srfi_2d13_toplevel)
C_externimport void C_ccall C_srfi_2d13_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[454];
static double C_possibly_force_alignment;


C_noret_decl(f_5140)
static void C_ccall f_5140(C_word c,C_word *av) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word *av) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word *av) C_noret;
C_noret_decl(f_3407)
static void C_ccall f_3407(C_word c,C_word *av) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word *av) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word *av) C_noret;
C_noret_decl(f_4135)
static void C_fcall f_4135(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159(C_word c,C_word *av) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word *av) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word *av) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845(C_word c,C_word *av) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word *av) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word *av) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word *av) C_noret;
C_noret_decl(f_3819)
static void C_ccall f_3819(C_word c,C_word *av) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word *av) C_noret;
C_noret_decl(f_3247)
static void C_fcall f_3247(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word *av) C_noret;
C_noret_decl(f_4802)
static void C_ccall f_4802(C_word c,C_word *av) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word *av) C_noret;
C_noret_decl(f_5320)
static void C_ccall f_5320(C_word c,C_word *av) C_noret;
C_noret_decl(f_5359)
static void C_ccall f_5359(C_word c,C_word *av) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word *av) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word *av) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word *av) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word *av) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word *av) C_noret;
C_noret_decl(f_5343)
static void C_fcall f_5343(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word *av) C_noret;
C_noret_decl(f_3121)
static void C_fcall f_3121(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3205)
static void C_fcall f_3205(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word *av) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word *av) C_noret;
C_noret_decl(f_7462)
static void C_ccall f_7462(C_word c,C_word *av) C_noret;
C_noret_decl(f_3632)
static void C_ccall f_3632(C_word c,C_word *av) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word *av) C_noret;
C_noret_decl(f_6858)
static void C_ccall f_6858(C_word c,C_word *av) C_noret;
C_noret_decl(f_3626)
static void C_fcall f_3626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word *av) C_noret;
C_noret_decl(f_6820)
static void C_ccall f_6820(C_word c,C_word *av) C_noret;
C_noret_decl(f_3617)
static void C_ccall f_3617(C_word c,C_word *av) C_noret;
C_noret_decl(f_3614)
static void C_fcall f_3614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word *av) C_noret;
C_noret_decl(f_6793)
static void C_ccall f_6793(C_word c,C_word *av) C_noret;
C_noret_decl(f_3602)
static void C_fcall f_3602(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word *av) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word *av) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word *av) C_noret;
C_noret_decl(f_6816)
static void C_ccall f_6816(C_word c,C_word *av) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word *av) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word *av) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word *av) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590(C_word c,C_word *av) C_noret;
C_noret_decl(f_7416)
static void C_ccall f_7416(C_word c,C_word *av) C_noret;
C_noret_decl(f_6171)
static void C_ccall f_6171(C_word c,C_word *av) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word *av) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word *av) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word *av) C_noret;
C_noret_decl(f_6187)
static void C_ccall f_6187(C_word c,C_word *av) C_noret;
C_noret_decl(f_6191)
static void C_fcall f_6191(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word *av) C_noret;
C_noret_decl(f_5587)
static void C_ccall f_5587(C_word c,C_word *av) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word *av) C_noret;
C_noret_decl(f_5581)
static void C_ccall f_5581(C_word c,C_word *av) C_noret;
C_noret_decl(f_5584)
static void C_ccall f_5584(C_word c,C_word *av) C_noret;
C_noret_decl(f_2633)
static void C_ccall f_2633(C_word c,C_word *av) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word *av) C_noret;
C_noret_decl(f_5578)
static void C_ccall f_5578(C_word c,C_word *av) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word *av) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word *av) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word *av) C_noret;
C_noret_decl(f_2612)
static void C_ccall f_2612(C_word c,C_word *av) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word *av) C_noret;
C_noret_decl(f_6161)
static void C_fcall f_6161(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5851)
static void C_ccall f_5851(C_word c,C_word *av) C_noret;
C_noret_decl(f_6165)
static void C_ccall f_6165(C_word c,C_word *av) C_noret;
C_noret_decl(f_6168)
static void C_ccall f_6168(C_word c,C_word *av) C_noret;
C_noret_decl(f_5865)
static void C_ccall f_5865(C_word c,C_word *av) C_noret;
C_noret_decl(f_5868)
static void C_ccall f_5868(C_word c,C_word *av) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word *av) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word *av) C_noret;
C_noret_decl(f_6990)
static void C_ccall f_6990(C_word c,C_word *av) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word *av) C_noret;
C_noret_decl(f_4211)
static void C_ccall f_4211(C_word c,C_word *av) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word *av) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word *av) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word *av) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word *av) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word *av) C_noret;
C_noret_decl(f8076)
static void C_ccall f8076(C_word c,C_word *av) C_noret;
C_noret_decl(f_6330)
static void C_ccall f_6330(C_word c,C_word *av) C_noret;
C_noret_decl(f_5831)
static void C_ccall f_5831(C_word c,C_word *av) C_noret;
C_noret_decl(f_4247)
static void C_fcall f_4247(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5845)
static void C_ccall f_5845(C_word c,C_word *av) C_noret;
C_noret_decl(f8088)
static void C_ccall f8088(C_word c,C_word *av) C_noret;
C_noret_decl(f_2373)
static void C_ccall f_2373(C_word c,C_word *av) C_noret;
C_noret_decl(f_7065)
static void C_ccall f_7065(C_word c,C_word *av) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word *av) C_noret;
C_noret_decl(f_2370)
static void C_ccall f_2370(C_word c,C_word *av) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word *av) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834(C_word c,C_word *av) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word *av) C_noret;
C_noret_decl(f_6356)
static void C_ccall f_6356(C_word c,C_word *av) C_noret;
C_noret_decl(f8149)
static void C_ccall f8149(C_word c,C_word *av) C_noret;
C_noret_decl(f_5780)
static void C_fcall f_5780(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f8144)
static void C_ccall f8144(C_word c,C_word *av) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word *av) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word *av) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word *av) C_noret;
C_noret_decl(f_6320)
static void C_fcall f_6320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word *av) C_noret;
C_noret_decl(f_5814)
static void C_ccall f_5814(C_word c,C_word *av) C_noret;
C_noret_decl(f_7091)
static void C_ccall f_7091(C_word c,C_word *av) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word *av) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word *av) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word *av) C_noret;
C_noret_decl(f_3541)
static void C_fcall f_3541(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6347)
static void C_ccall f_6347(C_word c,C_word *av) C_noret;
C_noret_decl(f_6343)
static void C_ccall f_6343(C_word c,C_word *av) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word *av) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word *av) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word *av) C_noret;
C_noret_decl(f_4077)
static void C_fcall f_4077(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word *av) C_noret;
C_noret_decl(f_2818)
static void C_fcall f_2818(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word *av) C_noret;
C_noret_decl(f_6484)
static void C_ccall f_6484(C_word c,C_word *av) C_noret;
C_noret_decl(f_3506)
static void C_ccall f_3506(C_word c,C_word *av) C_noret;
C_noret_decl(f_3502)
static void C_ccall f_3502(C_word c,C_word *av) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word *av) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word *av) C_noret;
C_noret_decl(f_5263)
static void C_ccall f_5263(C_word c,C_word *av) C_noret;
C_noret_decl(f_6493)
static void C_fcall f_6493(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4879)
static void C_ccall f_4879(C_word c,C_word *av) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word *av) C_noret;
C_noret_decl(f_4876)
static void C_ccall f_4876(C_word c,C_word *av) C_noret;
C_noret_decl(f_4093)
static void C_ccall f_4093(C_word c,C_word *av) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word *av) C_noret;
C_noret_decl(f_4097)
static void C_fcall f_4097(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5298)
static void C_ccall f_5298(C_word c,C_word *av) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word *av) C_noret;
C_noret_decl(f_6460)
static void C_ccall f_6460(C_word c,C_word *av) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word *av) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word *av) C_noret;
C_noret_decl(f_4897)
static void C_ccall f_4897(C_word c,C_word *av) C_noret;
C_noret_decl(f_6478)
static void C_ccall f_6478(C_word c,C_word *av) C_noret;
C_noret_decl(f_2581)
static void C_ccall f_2581(C_word c,C_word *av) C_noret;
C_noret_decl(f_5274)
static void C_ccall f_5274(C_word c,C_word *av) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word *av) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word *av) C_noret;
C_noret_decl(f_2577)
static void C_fcall f_2577(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6518)
static void C_ccall f_6518(C_word c,C_word *av) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word *av) C_noret;
C_noret_decl(f_2563)
static void C_fcall f_2563(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word *av) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word *av) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word *av) C_noret;
C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084(C_word c,C_word *av) C_noret;
C_noret_decl(f_4081)
static void C_ccall f_4081(C_word c,C_word *av) C_noret;
C_noret_decl(f_4348)
static void C_ccall f_4348(C_word c,C_word *av) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word *av) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word *av) C_noret;
C_noret_decl(f_6541)
static void C_ccall f_6541(C_word c,C_word *av) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word *av) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544(C_word c,C_word *av) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word *av) C_noret;
C_noret_decl(f_6620)
static void C_ccall f_6620(C_word c,C_word *av) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word *av) C_noret;
C_noret_decl(f_6563)
static void C_ccall f_6563(C_word c,C_word *av) C_noret;
C_noret_decl(f_5212)
static void C_ccall f_5212(C_word c,C_word *av) C_noret;
C_noret_decl(f_5218)
static void C_ccall f_5218(C_word c,C_word *av) C_noret;
C_noret_decl(f_3300)
static void C_fcall f_3300(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5958)
static void C_fcall f_5958(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5953)
static void C_ccall f_5953(C_word c,C_word *av) C_noret;
C_noret_decl(f_3328)
static void C_fcall f_3328(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5955)
static void C_fcall f_5955(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6630)
static void C_ccall f_6630(C_word c,C_word *av) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word *av) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word *av) C_noret;
C_noret_decl(f_5972)
static void C_ccall f_5972(C_word c,C_word *av) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word *av) C_noret;
C_noret_decl(f_4979)
static void C_fcall f_4979(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word *av) C_noret;
C_noret_decl(f_5992)
static void C_ccall f_5992(C_word c,C_word *av) C_noret;
C_noret_decl(f_5467)
static void C_fcall f_5467(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word *av) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word *av) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word *av) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word *av) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word *av) C_noret;
C_noret_decl(f_3067)
static void C_fcall f_3067(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7403)
static void C_ccall f_7403(C_word c,C_word *av) C_noret;
C_noret_decl(f_7409)
static void C_ccall f_7409(C_word c,C_word *av) C_noret;
C_noret_decl(f_7400)
static void C_ccall f_7400(C_word c,C_word *av) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word *av) C_noret;
C_noret_decl(f_3986)
static void C_fcall f_3986(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7121)
static void C_ccall f_7121(C_word c,C_word *av) C_noret;
C_noret_decl(f_6651)
static void C_fcall f_6651(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7426)
static void C_fcall f_7426(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4624)
static void C_fcall f_4624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7422)
static void C_ccall f_7422(C_word c,C_word *av) C_noret;
C_noret_decl(f_5642)
static void C_ccall f_5642(C_word c,C_word *av) C_noret;
C_noret_decl(f_5632)
static void C_fcall f_5632(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7446)
static void C_ccall f_7446(C_word c,C_word *av) C_noret;
C_noret_decl(f_7442)
static void C_ccall f_7442(C_word c,C_word *av) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word *av) C_noret;
C_noret_decl(f_4656)
static void C_ccall f_4656(C_word c,C_word *av) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word *av) C_noret;
C_noret_decl(f_3996)
static void C_fcall f_3996(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word *av) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word *av) C_noret;
C_noret_decl(f_7117)
static void C_ccall f_7117(C_word c,C_word *av) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word *av) C_noret;
C_noret_decl(f_6093)
static void C_ccall f_6093(C_word c,C_word *av) C_noret;
C_noret_decl(f_6099)
static void C_ccall f_6099(C_word c,C_word *av) C_noret;
C_noret_decl(f_6138)
static void C_fcall f_6138(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6130)
static void C_ccall f_6130(C_word c,C_word *av) C_noret;
C_noret_decl(f_4476)
static void C_ccall f_4476(C_word c,C_word *av) C_noret;
C_noret_decl(f_4734)
static void C_ccall f_4734(C_word c,C_word *av) C_noret;
C_noret_decl(f_6148)
static void C_ccall f_6148(C_word c,C_word *av) C_noret;
C_noret_decl(f_4463)
static void C_ccall f_4463(C_word c,C_word *av) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word *av) C_noret;
C_noret_decl(f_6078)
static void C_ccall f_6078(C_word c,C_word *av) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word *av) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word *av) C_noret;
C_noret_decl(f_6053)
static void C_fcall f_6053(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word *av) C_noret;
C_noret_decl(f_5616)
static void C_ccall f_5616(C_word c,C_word *av) C_noret;
C_noret_decl(f_4533)
static void C_fcall f_4533(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5612)
static void C_ccall f_5612(C_word c,C_word *av) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word *av) C_noret;
C_noret_decl(f_3088)
static void C_fcall f_3088(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word *av) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021(C_word c,C_word *av) C_noret;
C_noret_decl(f_5605)
static void C_ccall f_5605(C_word c,C_word *av) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word *av) C_noret;
C_noret_decl(f_5093)
static void C_ccall f_5093(C_word c,C_word *av) C_noret;
C_noret_decl(f_6030)
static void C_ccall f_6030(C_word c,C_word *av) C_noret;
C_noret_decl(f_7278)
static void C_fcall f_7278(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6034)
static void C_ccall f_6034(C_word c,C_word *av) C_noret;
C_noret_decl(f_7287)
static void C_ccall f_7287(C_word c,C_word *av) C_noret;
C_noret_decl(f_5667)
static void C_ccall f_5667(C_word c,C_word *av) C_noret;
C_noret_decl(f_6127)
static void C_ccall f_6127(C_word c,C_word *av) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word *av) C_noret;
C_noret_decl(f_6018)
static void C_ccall f_6018(C_word c,C_word *av) C_noret;
C_noret_decl(f_7293)
static void C_ccall f_7293(C_word c,C_word *av) C_noret;
C_noret_decl(f_6012)
static void C_ccall f_6012(C_word c,C_word *av) C_noret;
C_noret_decl(f_6015)
static void C_ccall f_6015(C_word c,C_word *av) C_noret;
C_noret_decl(f_5657)
static void C_ccall f_5657(C_word c,C_word *av) C_noret;
C_noret_decl(f_5659)
static void C_ccall f_5659(C_word c,C_word *av) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word *av) C_noret;
C_noret_decl(f_6886)
static void C_ccall f_6886(C_word c,C_word *av) C_noret;
C_noret_decl(f_6883)
static void C_ccall f_6883(C_word c,C_word *av) C_noret;
C_noret_decl(f_5060)
static void C_fcall f_5060(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word *av) C_noret;
C_noret_decl(f_5896)
static void C_ccall f_5896(C_word c,C_word *av) C_noret;
C_noret_decl(f_2970)
static void C_fcall f_2970(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5894)
static void C_ccall f_5894(C_word c,C_word *av) C_noret;
C_noret_decl(f_5078)
static void C_fcall f_5078(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5077)
static void C_ccall f_5077(C_word c,C_word *av) C_noret;
C_noret_decl(f_5073)
static void C_ccall f_5073(C_word c,C_word *av) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word *av) C_noret;
C_noret_decl(f_7562)
static void C_ccall f_7562(C_word c,C_word *av) C_noret;
C_noret_decl(f_7569)
static void C_ccall f_7569(C_word c,C_word *av) C_noret;
C_noret_decl(f_6290)
static void C_ccall f_6290(C_word c,C_word *av) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word *av) C_noret;
C_noret_decl(f_5882)
static void C_ccall f_5882(C_word c,C_word *av) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word *av) C_noret;
C_noret_decl(f_5067)
static void C_ccall f_5067(C_word c,C_word *av) C_noret;
C_noret_decl(f_5040)
static void C_ccall f_5040(C_word c,C_word *av) C_noret;
C_noret_decl(f_7533)
static void C_ccall f_7533(C_word c,C_word *av) C_noret;
C_noret_decl(f_7537)
static void C_ccall f_7537(C_word c,C_word *av) C_noret;
C_noret_decl(f_6263)
static void C_ccall f_6263(C_word c,C_word *av) C_noret;
C_noret_decl(f_5876)
static void C_ccall f_5876(C_word c,C_word *av) C_noret;
C_noret_decl(f_5874)
static void C_ccall f_5874(C_word c,C_word *av) C_noret;
C_noret_decl(f_5871)
static void C_ccall f_5871(C_word c,C_word *av) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word *av) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word *av) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word *av) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word *av) C_noret;
C_noret_decl(f_2682)
static void C_fcall f_2682(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6270)
static void C_ccall f_6270(C_word c,C_word *av) C_noret;
C_noret_decl(f_6274)
static void C_ccall f_6274(C_word c,C_word *av) C_noret;
C_noret_decl(f_6278)
static void C_ccall f_6278(C_word c,C_word *av) C_noret;
C_noret_decl(f_5045)
static void C_ccall f_5045(C_word c,C_word *av) C_noret;
C_noret_decl(f_7552)
static void C_ccall f_7552(C_word c,C_word *av) C_noret;
C_noret_decl(f_7558)
static void C_ccall f_7558(C_word c,C_word *av) C_noret;
C_noret_decl(f_7521)
static void C_ccall f_7521(C_word c,C_word *av) C_noret;
C_noret_decl(f_7527)
static void C_ccall f_7527(C_word c,C_word *av) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word *av) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word *av) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word *av) C_noret;
C_noret_decl(f_7543)
static void C_ccall f_7543(C_word c,C_word *av) C_noret;
C_noret_decl(f_7540)
static void C_ccall f_7540(C_word c,C_word *av) C_noret;
C_noret_decl(f_4508)
static void C_fcall f_4508(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7510)
static void C_ccall f_7510(C_word c,C_word *av) C_noret;
C_noret_decl(f_7519)
static void C_ccall f_7519(C_word c,C_word *av) C_noret;
C_noret_decl(f_7513)
static void C_ccall f_7513(C_word c,C_word *av) C_noret;
C_noret_decl(f_7516)
static void C_ccall f_7516(C_word c,C_word *av) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word *av) C_noret;
C_noret_decl(f_3488)
static void C_fcall f_3488(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3483)
static void C_ccall f_3483(C_word c,C_word *av) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word *av) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word *av) C_noret;
C_noret_decl(f_3472)
static void C_fcall f_3472(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word *av) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word *av) C_noret;
C_noret_decl(f_7507)
static void C_ccall f_7507(C_word c,C_word *av) C_noret;
C_noret_decl(f_7504)
static void C_ccall f_7504(C_word c,C_word *av) C_noret;
C_noret_decl(f_5206)
static void C_ccall f_5206(C_word c,C_word *av) C_noret;
C_noret_decl(f_5200)
static void C_ccall f_5200(C_word c,C_word *av) C_noret;
C_noret_decl(f_7361)
static void C_ccall f_7361(C_word c,C_word *av) C_noret;
C_noret_decl(f_7379)
static void C_ccall f_7379(C_word c,C_word *av) C_noret;
C_noret_decl(f_5249)
static void C_ccall f_5249(C_word c,C_word *av) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242(C_word c,C_word *av) C_noret;
C_noret_decl(f_7396)
static void C_fcall f_7396(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3279)
static void C_ccall f_3279(C_word c,C_word *av) C_noret;
C_noret_decl(f_5165)
static void C_ccall f_5165(C_word c,C_word *av) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word *av) C_noret;
C_noret_decl(f_5902)
static void C_ccall f_5902(C_word c,C_word *av) C_noret;
C_noret_decl(f_6453)
static void C_ccall f_6453(C_word c,C_word *av) C_noret;
C_noret_decl(f_6421)
static void C_ccall f_6421(C_word c,C_word *av) C_noret;
C_noret_decl(f_6424)
static void C_ccall f_6424(C_word c,C_word *av) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word *av) C_noret;
C_noret_decl(f_5921)
static void C_ccall f_5921(C_word c,C_word *av) C_noret;
C_noret_decl(f_6434)
static void C_ccall f_6434(C_word c,C_word *av) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word *av) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182(C_word c,C_word *av) C_noret;
C_noret_decl(f_4915)
static void C_ccall f_4915(C_word c,C_word *av) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021(C_word c,C_word *av) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word *av) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word *av) C_noret;
C_noret_decl(f_5911)
static void C_fcall f_5911(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word *av) C_noret;
C_noret_decl(f_6403)
static void C_ccall f_6403(C_word c,C_word *av) C_noret;
C_noret_decl(f_3238)
static void C_fcall f_3238(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word *av) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word *av) C_noret;
C_noret_decl(f_5171)
static void C_ccall f_5171(C_word c,C_word *av) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word *av) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word *av) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word *av) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word *av) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word *av) C_noret;
C_noret_decl(f_6418)
static void C_ccall f_6418(C_word c,C_word *av) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word *av) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word *av) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word *av) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word *av) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word *av) C_noret;
C_noret_decl(f_4932)
static void C_ccall f_4932(C_word c,C_word *av) C_noret;
C_noret_decl(f_3173)
static void C_ccall f_3173(C_word c,C_word *av) C_noret;
C_noret_decl(f_5934)
static void C_ccall f_5934(C_word c,C_word *av) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word *av) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196(C_word c,C_word *av) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195(C_word c,C_word *av) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word *av) C_noret;
C_noret_decl(f_3901)
static void C_ccall f_3901(C_word c,C_word *av) C_noret;
C_noret_decl(f_7300)
static void C_ccall f_7300(C_word c,C_word *av) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word *av) C_noret;
C_noret_decl(f_3907)
static void C_ccall f_3907(C_word c,C_word *av) C_noret;
C_noret_decl(f_6573)
static void C_ccall f_6573(C_word c,C_word *av) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word *av) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word *av) C_noret;
C_noret_decl(f_4938)
static void C_ccall f_4938(C_word c,C_word *av) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word *av) C_noret;
C_noret_decl(f_7312)
static void C_ccall f_7312(C_word c,C_word *av) C_noret;
C_noret_decl(f_7316)
static void C_fcall f_7316(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word *av) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word *av) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word *av) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word *av) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word *av) C_noret;
C_noret_decl(f_4951)
static void C_ccall f_4951(C_word c,C_word *av) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word *av) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word *av) C_noret;
C_noret_decl(f_6595)
static void C_fcall f_6595(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4944)
static void C_ccall f_4944(C_word c,C_word *av) C_noret;
C_noret_decl(f_6593)
static void C_ccall f_6593(C_word c,C_word *av) C_noret;
C_noret_decl(f_4941)
static void C_ccall f_4941(C_word c,C_word *av) C_noret;
C_noret_decl(f8174)
static void C_ccall f8174(C_word c,C_word *av) C_noret;
C_noret_decl(f8179)
static void C_ccall f8179(C_word c,C_word *av) C_noret;
C_noret_decl(f_6701)
static void C_ccall f_6701(C_word c,C_word *av) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word *av) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word *av) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word *av) C_noret;
C_noret_decl(f8191)
static void C_ccall f8191(C_word c,C_word *av) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word *av) C_noret;
C_noret_decl(f8169)
static void C_ccall f8169(C_word c,C_word *av) C_noret;
C_noret_decl(f8164)
static void C_ccall f8164(C_word c,C_word *av) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word *av) C_noret;
C_noret_decl(f_2726)
static void C_fcall f_2726(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6731)
static void C_ccall f_6731(C_word c,C_word *av) C_noret;
C_noret_decl(f_5367)
static void C_ccall f_5367(C_word c,C_word *av) C_noret;
C_noret_decl(f8139)
static void C_ccall f8139(C_word c,C_word *av) C_noret;
C_noret_decl(f_5363)
static void C_ccall f_5363(C_word c,C_word *av) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word *av) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word *av) C_noret;
C_noret_decl(f8132)
static void C_ccall f8132(C_word c,C_word *av) C_noret;
C_noret_decl(f_5455)
static void C_ccall f_5455(C_word c,C_word *av) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word *av) C_noret;
C_noret_decl(f_4681)
static void C_fcall f_4681(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word *av) C_noret;
C_noret_decl(f_3910)
static void C_ccall f_3910(C_word c,C_word *av) C_noret;
C_noret_decl(f_3913)
static void C_ccall f_3913(C_word c,C_word *av) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word *av) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word *av) C_noret;
C_noret_decl(f_2524)
static void C_fcall f_2524(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4790)
static void C_ccall f_4790(C_word c,C_word *av) C_noret;
C_noret_decl(f8186)
static void C_ccall f8186(C_word c,C_word *av) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word *av) C_noret;
C_noret_decl(f_3892)
static void C_ccall f_3892(C_word c,C_word *av) C_noret;
C_noret_decl(f_3898)
static void C_ccall f_3898(C_word c,C_word *av) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word *av) C_noret;
C_noret_decl(f_5449)
static void C_ccall f_5449(C_word c,C_word *av) C_noret;
C_noret_decl(f_5384)
static void C_ccall f_5384(C_word c,C_word *av) C_noret;
C_noret_decl(f8116)
static void C_ccall f8116(C_word c,C_word *av) C_noret;
C_noret_decl(f8111)
static void C_ccall f8111(C_word c,C_word *av) C_noret;
C_noret_decl(f_2512)
static void C_ccall f_2512(C_word c,C_word *av) C_noret;
C_noret_decl(f_4782)
static void C_fcall f_4782(C_word t0,C_word t1) C_noret;
C_noret_decl(f8159)
static void C_ccall f8159(C_word c,C_word *av) C_noret;
C_noret_decl(f_5382)
static void C_ccall f_5382(C_word c,C_word *av) C_noret;
C_noret_decl(f8154)
static void C_ccall f8154(C_word c,C_word *av) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word *av) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word *av) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word *av) C_noret;
C_noret_decl(f_6760)
static void C_ccall f_6760(C_word c,C_word *av) C_noret;
C_noret_decl(f_6764)
static void C_ccall f_6764(C_word c,C_word *av) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word *av) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word *av) C_noret;
C_noret_decl(f_3111)
static void C_fcall f_3111(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word *av) C_noret;
C_noret_decl(f_3878)
static void C_fcall f_3878(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word *av) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word *av) C_noret;
C_noret_decl(f_3038)
static C_word C_fcall f_3038(C_word t0,C_word t1);
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word *av) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751(C_word c,C_word *av) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word *av) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word *av) C_noret;
C_noret_decl(f_3026)
static void C_ccall f_3026(C_word c,C_word *av) C_noret;
C_noret_decl(f8126)
static void C_ccall f8126(C_word c,C_word *av) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word *av) C_noret;
C_noret_decl(f8121)
static void C_ccall f8121(C_word c,C_word *av) C_noret;
C_noret_decl(f_3019)
static void C_fcall f_3019(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403(C_word c,C_word *av) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word *av) C_noret;
C_noret_decl(f_2457)
static void C_fcall f_2457(C_word t0) C_noret;
C_noret_decl(f_5408)
static void C_fcall f_5408(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5696)
static void C_ccall f_5696(C_word c,C_word *av) C_noret;
C_noret_decl(f_5691)
static void C_ccall f_5691(C_word c,C_word *av) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word *av) C_noret;
C_noret_decl(f_3723)
static void C_fcall f_3723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5688)
static void C_ccall f_5688(C_word c,C_word *av) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word *av) C_noret;
C_noret_decl(f_6976)
static void C_ccall f_6976(C_word c,C_word *av) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word *av) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word *av) C_noret;
C_noret_decl(f_3714)
static void C_fcall f_3714(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word *av) C_noret;
C_noret_decl(f_6909)
static void C_ccall f_6909(C_word c,C_word *av) C_noret;
C_noret_decl(f_6008)
static void C_ccall f_6008(C_word c,C_word *av) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word *av) C_noret;
C_noret_decl(f_6912)
static void C_ccall f_6912(C_word c,C_word *av) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490(C_word c,C_word *av) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word *av) C_noret;
C_noret_decl(f_5309)
static void C_ccall f_5309(C_word c,C_word *av) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word *av) C_noret;
C_noret_decl(f_2773)
static void C_fcall f_2773(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word *av) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word *av) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word *av) C_noret;
C_noret_decl(f_3760)
static void C_fcall f_3760(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word *av) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word *av) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word *av) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word *av) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word *av) C_noret;
C_noret_decl(f_6942)
static void C_ccall f_6942(C_word c,C_word *av) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word *av) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word *av) C_noret;
C_noret_decl(f_6956)
static void C_ccall f_6956(C_word c,C_word *av) C_noret;
C_noret_decl(f_4598)
static void C_fcall f_4598(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word *av) C_noret;
C_noret_decl(f_2949)
static void C_ccall f_2949(C_word c,C_word *av) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word *av) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word *av) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word *av) C_noret;
C_noret_decl(f_6241)
static void C_fcall f_6241(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word *av) C_noret;
C_noret_decl(f_2939)
static void C_fcall f_2939(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4421)
static void C_fcall f_4421(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word *av) C_noret;
C_noret_decl(f_6259)
static void C_ccall f_6259(C_word c,C_word *av) C_noret;
C_noret_decl(f_6253)
static void C_ccall f_6253(C_word c,C_word *av) C_noret;
C_noret_decl(f_7577)
static void C_ccall f_7577(C_word c,C_word *av) C_noret;
C_noret_decl(f_4459)
static void C_ccall f_4459(C_word c,C_word *av) C_noret;
C_noret_decl(f_7571)
static void C_ccall f_7571(C_word c,C_word *av) C_noret;
C_noret_decl(f_6224)
static void C_ccall f_6224(C_word c,C_word *av) C_noret;
C_noret_decl(f_6222)
static void C_ccall f_6222(C_word c,C_word *av) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word *av) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word *av) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word *av) C_noret;
C_noret_decl(f_3551)
static void C_ccall f_3551(C_word c,C_word *av) C_noret;
C_noret_decl(f_4585)
static void C_ccall f_4585(C_word c,C_word *av) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word *av) C_noret;
C_noret_decl(f_3586)
static void C_ccall f_3586(C_word c,C_word *av) C_noret;
C_noret_decl(f_4575)
static void C_fcall f_4575(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word *av) C_noret;
C_noret_decl(f_7232)
static void C_ccall f_7232(C_word c,C_word *av) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word *av) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word *av) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word *av) C_noret;
C_noret_decl(f_5559)
static void C_fcall f_5559(C_word t0) C_noret;
C_noret_decl(f_4269)
static void C_ccall f_4269(C_word c,C_word *av) C_noret;
C_noret_decl(f_4402)
static void C_ccall f_4402(C_word c,C_word *av) C_noret;
C_noret_decl(f_4405)
static void C_ccall f_4405(C_word c,C_word *av) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word *av) C_noret;
C_noret_decl(f_7585)
static void C_ccall f_7585(C_word c,C_word *av) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word *av) C_noret;
C_noret_decl(f_5509)
static void C_ccall f_5509(C_word c,C_word *av) C_noret;
C_noret_decl(f_5503)
static void C_ccall f_5503(C_word c,C_word *av) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515(C_word c,C_word *av) C_noret;
C_noret_decl(f_7589)
static void C_ccall f_7589(C_word c,C_word *av) C_noret;
C_noret_decl(f_5020)
static void C_ccall f_5020(C_word c,C_word *av) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word *av) C_noret;
C_noret_decl(f_6378)
static void C_ccall f_6378(C_word c,C_word *av) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word *av) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word *av) C_noret;
C_noret_decl(f_5033)
static void C_fcall f_5033(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word *av) C_noret;
C_noret_decl(f_5037)
static void C_ccall f_5037(C_word c,C_word *av) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word *av) C_noret;
C_noret_decl(f_5023)
static void C_ccall f_5023(C_word c,C_word *av) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word *av) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word *av) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word *av) C_noret;
C_noret_decl(f_7206)
static void C_ccall f_7206(C_word c,C_word *av) C_noret;
C_noret_decl(f_5013)
static void C_fcall f_5013(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word *av) C_noret;
C_noret_decl(f_5017)
static void C_fcall f_5017(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word *av) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word *av) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word *av) C_noret;
C_noret_decl(f_5006)
static void C_ccall f_5006(C_word c,C_word *av) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word *av) C_noret;
C_noret_decl(f_3360)
static void C_ccall f_3360(C_word c,C_word *av) C_noret;
C_noret_decl(f_4371)
static void C_ccall f_4371(C_word c,C_word *av) C_noret;
C_noret_decl(f_6383)
static void C_fcall f_6383(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word *av) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word *av) C_noret;
C_noret_decl(f_4366)
static void C_ccall f_4366(C_word c,C_word *av) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word *av) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word *av) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word *av) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word *av) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word *av) C_noret;
C_noret_decl(f_4381)
static void C_ccall f_4381(C_word c,C_word *av) C_noret;
C_noret_decl(f_4386)
static void C_ccall f_4386(C_word c,C_word *av) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word *av) C_noret;
C_noret_decl(f_7353)
static void C_ccall f_7353(C_word c,C_word *av) C_noret;
C_noret_decl(f_4201)
static void C_fcall f_4201(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5725)
static void C_ccall f_5725(C_word c,C_word *av) C_noret;
C_noret_decl(f_3392)
static void C_ccall f_3392(C_word c,C_word *av) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word *av) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word *av) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word *av) C_noret;
C_noret_decl(f_5711)
static C_word C_fcall f_5711(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word *av) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word *av) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word *av) C_noret;
C_noret_decl(f_5746)
static void C_fcall f_5746(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word *av) C_noret;
C_noret_decl(f_5744)
static void C_ccall f_5744(C_word c,C_word *av) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word *av) C_noret;
C_noret_decl(f_2863)
static void C_fcall f_2863(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word *av) C_noret;
C_noret_decl(f_3422)
static void C_ccall f_3422(C_word c,C_word *av) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word *av) C_noret;
C_noret_decl(f_5117)
static void C_ccall f_5117(C_word c,C_word *av) C_noret;
C_noret_decl(f_5110)
static void C_ccall f_5110(C_word c,C_word *av) C_noret;
C_noret_decl(f_4857)
static void C_ccall f_4857(C_word c,C_word *av) C_noret;
C_noret_decl(f_5730)
static C_word C_fcall f_5730(C_word *a,C_word t0,C_word t1);

C_noret_decl(trf_4135)
static void C_ccall trf_4135(C_word c,C_word *av) C_noret;
static void C_ccall trf_4135(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4135(t0,t1,t2);}

C_noret_decl(trf_3247)
static void C_ccall trf_3247(C_word c,C_word *av) C_noret;
static void C_ccall trf_3247(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_3247(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5343)
static void C_ccall trf_5343(C_word c,C_word *av) C_noret;
static void C_ccall trf_5343(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5343(t0,t1);}

C_noret_decl(trf_3121)
static void C_ccall trf_3121(C_word c,C_word *av) C_noret;
static void C_ccall trf_3121(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3121(t0,t1);}

C_noret_decl(trf_3205)
static void C_ccall trf_3205(C_word c,C_word *av) C_noret;
static void C_ccall trf_3205(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3205(t0,t1);}

C_noret_decl(trf_3626)
static void C_ccall trf_3626(C_word c,C_word *av) C_noret;
static void C_ccall trf_3626(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3626(t0,t1);}

C_noret_decl(trf_3614)
static void C_ccall trf_3614(C_word c,C_word *av) C_noret;
static void C_ccall trf_3614(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3614(t0,t1);}

C_noret_decl(trf_3602)
static void C_ccall trf_3602(C_word c,C_word *av) C_noret;
static void C_ccall trf_3602(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3602(t0,t1);}

C_noret_decl(trf_6191)
static void C_ccall trf_6191(C_word c,C_word *av) C_noret;
static void C_ccall trf_6191(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6191(t0,t1,t2);}

C_noret_decl(trf_6161)
static void C_ccall trf_6161(C_word c,C_word *av) C_noret;
static void C_ccall trf_6161(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6161(t0,t1);}

C_noret_decl(trf_4247)
static void C_ccall trf_4247(C_word c,C_word *av) C_noret;
static void C_ccall trf_4247(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4247(t0,t1);}

C_noret_decl(trf_5780)
static void C_ccall trf_5780(C_word c,C_word *av) C_noret;
static void C_ccall trf_5780(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5780(t0,t1,t2);}

C_noret_decl(trf_6320)
static void C_ccall trf_6320(C_word c,C_word *av) C_noret;
static void C_ccall trf_6320(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6320(t0,t1);}

C_noret_decl(trf_3541)
static void C_ccall trf_3541(C_word c,C_word *av) C_noret;
static void C_ccall trf_3541(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3541(t0,t1,t2);}

C_noret_decl(trf_4077)
static void C_ccall trf_4077(C_word c,C_word *av) C_noret;
static void C_ccall trf_4077(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4077(t0,t1,t2);}

C_noret_decl(trf_2818)
static void C_ccall trf_2818(C_word c,C_word *av) C_noret;
static void C_ccall trf_2818(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2818(t0,t1,t2);}

C_noret_decl(trf_6493)
static void C_ccall trf_6493(C_word c,C_word *av) C_noret;
static void C_ccall trf_6493(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6493(t0,t1,t2);}

C_noret_decl(trf_4097)
static void C_ccall trf_4097(C_word c,C_word *av) C_noret;
static void C_ccall trf_4097(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4097(t0,t1,t2);}

C_noret_decl(trf_2577)
static void C_ccall trf_2577(C_word c,C_word *av) C_noret;
static void C_ccall trf_2577(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2577(t0,t1,t2);}

C_noret_decl(trf_2563)
static void C_ccall trf_2563(C_word c,C_word *av) C_noret;
static void C_ccall trf_2563(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2563(t0,t1,t2);}

C_noret_decl(trf_3300)
static void C_ccall trf_3300(C_word c,C_word *av) C_noret;
static void C_ccall trf_3300(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3300(t0,t1);}

C_noret_decl(trf_5958)
static void C_ccall trf_5958(C_word c,C_word *av) C_noret;
static void C_ccall trf_5958(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5958(t0,t1);}

C_noret_decl(trf_3328)
static void C_ccall trf_3328(C_word c,C_word *av) C_noret;
static void C_ccall trf_3328(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3328(t0,t1);}

C_noret_decl(trf_5955)
static void C_ccall trf_5955(C_word c,C_word *av) C_noret;
static void C_ccall trf_5955(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5955(t0,t1);}

C_noret_decl(trf_4979)
static void C_ccall trf_4979(C_word c,C_word *av) C_noret;
static void C_ccall trf_4979(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4979(t0,t1);}

C_noret_decl(trf_5467)
static void C_ccall trf_5467(C_word c,C_word *av) C_noret;
static void C_ccall trf_5467(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5467(t0,t1,t2);}

C_noret_decl(trf_3067)
static void C_ccall trf_3067(C_word c,C_word *av) C_noret;
static void C_ccall trf_3067(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3067(t0,t1,t2);}

C_noret_decl(trf_3986)
static void C_ccall trf_3986(C_word c,C_word *av) C_noret;
static void C_ccall trf_3986(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3986(t0,t1,t2);}

C_noret_decl(trf_6651)
static void C_ccall trf_6651(C_word c,C_word *av) C_noret;
static void C_ccall trf_6651(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_6651(t0,t1);}

C_noret_decl(trf_7426)
static void C_ccall trf_7426(C_word c,C_word *av) C_noret;
static void C_ccall trf_7426(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7426(t0,t1,t2);}

C_noret_decl(trf_4624)
static void C_ccall trf_4624(C_word c,C_word *av) C_noret;
static void C_ccall trf_4624(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4624(t0,t1);}

C_noret_decl(trf_5632)
static void C_ccall trf_5632(C_word c,C_word *av) C_noret;
static void C_ccall trf_5632(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5632(t0,t1,t2);}

C_noret_decl(trf_3996)
static void C_ccall trf_3996(C_word c,C_word *av) C_noret;
static void C_ccall trf_3996(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3996(t0,t1);}

C_noret_decl(trf_6138)
static void C_ccall trf_6138(C_word c,C_word *av) C_noret;
static void C_ccall trf_6138(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6138(t0,t1,t2);}

C_noret_decl(trf_6053)
static void C_ccall trf_6053(C_word c,C_word *av) C_noret;
static void C_ccall trf_6053(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6053(t0,t1,t2);}

C_noret_decl(trf_4533)
static void C_ccall trf_4533(C_word c,C_word *av) C_noret;
static void C_ccall trf_4533(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4533(t0,t1);}

C_noret_decl(trf_3088)
static void C_ccall trf_3088(C_word c,C_word *av) C_noret;
static void C_ccall trf_3088(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3088(t0,t1,t2);}

C_noret_decl(trf_7278)
static void C_ccall trf_7278(C_word c,C_word *av) C_noret;
static void C_ccall trf_7278(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7278(t0,t1);}

C_noret_decl(trf_5060)
static void C_ccall trf_5060(C_word c,C_word *av) C_noret;
static void C_ccall trf_5060(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5060(t0,t1);}

C_noret_decl(trf_2970)
static void C_ccall trf_2970(C_word c,C_word *av) C_noret;
static void C_ccall trf_2970(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2970(t0,t1);}

C_noret_decl(trf_5078)
static void C_ccall trf_5078(C_word c,C_word *av) C_noret;
static void C_ccall trf_5078(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5078(t0,t1);}

C_noret_decl(trf_2682)
static void C_ccall trf_2682(C_word c,C_word *av) C_noret;
static void C_ccall trf_2682(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2682(t0,t1,t2);}

C_noret_decl(trf_4508)
static void C_ccall trf_4508(C_word c,C_word *av) C_noret;
static void C_ccall trf_4508(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4508(t0,t1,t2);}

C_noret_decl(trf_3488)
static void C_ccall trf_3488(C_word c,C_word *av) C_noret;
static void C_ccall trf_3488(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_3488(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3472)
static void C_ccall trf_3472(C_word c,C_word *av) C_noret;
static void C_ccall trf_3472(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3472(t0,t1,t2);}

C_noret_decl(trf_7396)
static void C_ccall trf_7396(C_word c,C_word *av) C_noret;
static void C_ccall trf_7396(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_7396(t0,t1);}

C_noret_decl(trf_5911)
static void C_ccall trf_5911(C_word c,C_word *av) C_noret;
static void C_ccall trf_5911(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5911(t0,t1,t2);}

C_noret_decl(trf_3238)
static void C_ccall trf_3238(C_word c,C_word *av) C_noret;
static void C_ccall trf_3238(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3238(t0,t1);}

C_noret_decl(trf_7316)
static void C_ccall trf_7316(C_word c,C_word *av) C_noret;
static void C_ccall trf_7316(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_7316(t0,t1,t2);}

C_noret_decl(trf_6595)
static void C_ccall trf_6595(C_word c,C_word *av) C_noret;
static void C_ccall trf_6595(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6595(t0,t1,t2);}

C_noret_decl(trf_2726)
static void C_ccall trf_2726(C_word c,C_word *av) C_noret;
static void C_ccall trf_2726(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2726(t0,t1,t2);}

C_noret_decl(trf_4681)
static void C_ccall trf_4681(C_word c,C_word *av) C_noret;
static void C_ccall trf_4681(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4681(t0,t1);}

C_noret_decl(trf_2524)
static void C_ccall trf_2524(C_word c,C_word *av) C_noret;
static void C_ccall trf_2524(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2524(t0,t1);}

C_noret_decl(trf_4782)
static void C_ccall trf_4782(C_word c,C_word *av) C_noret;
static void C_ccall trf_4782(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_4782(t0,t1);}

C_noret_decl(trf_3111)
static void C_ccall trf_3111(C_word c,C_word *av) C_noret;
static void C_ccall trf_3111(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3111(t0,t1);}

C_noret_decl(trf_3878)
static void C_ccall trf_3878(C_word c,C_word *av) C_noret;
static void C_ccall trf_3878(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3878(t0,t1,t2);}

C_noret_decl(trf_3019)
static void C_ccall trf_3019(C_word c,C_word *av) C_noret;
static void C_ccall trf_3019(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3019(t0,t1);}

C_noret_decl(trf_2457)
static void C_ccall trf_2457(C_word c,C_word *av) C_noret;
static void C_ccall trf_2457(C_word c,C_word *av){
C_word t0=av[0];
f_2457(t0);}

C_noret_decl(trf_5408)
static void C_ccall trf_5408(C_word c,C_word *av) C_noret;
static void C_ccall trf_5408(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5408(t0,t1,t2,t3);}

C_noret_decl(trf_3723)
static void C_ccall trf_3723(C_word c,C_word *av) C_noret;
static void C_ccall trf_3723(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3723(t0,t1,t2);}

C_noret_decl(trf_3714)
static void C_ccall trf_3714(C_word c,C_word *av) C_noret;
static void C_ccall trf_3714(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3714(t0,t1);}

C_noret_decl(trf_2773)
static void C_ccall trf_2773(C_word c,C_word *av) C_noret;
static void C_ccall trf_2773(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2773(t0,t1,t2);}

C_noret_decl(trf_3760)
static void C_ccall trf_3760(C_word c,C_word *av) C_noret;
static void C_ccall trf_3760(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3760(t0,t1);}

C_noret_decl(trf_4598)
static void C_ccall trf_4598(C_word c,C_word *av) C_noret;
static void C_ccall trf_4598(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4598(t0,t1,t2);}

C_noret_decl(trf_6241)
static void C_ccall trf_6241(C_word c,C_word *av) C_noret;
static void C_ccall trf_6241(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_6241(t0,t1,t2);}

C_noret_decl(trf_2939)
static void C_ccall trf_2939(C_word c,C_word *av) C_noret;
static void C_ccall trf_2939(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2939(t0,t1,t2);}

C_noret_decl(trf_4421)
static void C_ccall trf_4421(C_word c,C_word *av) C_noret;
static void C_ccall trf_4421(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4421(t0,t1,t2);}

C_noret_decl(trf_4575)
static void C_ccall trf_4575(C_word c,C_word *av) C_noret;
static void C_ccall trf_4575(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4575(t0,t1,t2);}

C_noret_decl(trf_5559)
static void C_ccall trf_5559(C_word c,C_word *av) C_noret;
static void C_ccall trf_5559(C_word c,C_word *av){
C_word t0=av[0];
f_5559(t0);}

C_noret_decl(trf_5033)
static void C_ccall trf_5033(C_word c,C_word *av) C_noret;
static void C_ccall trf_5033(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5033(t0,t1,t2);}

C_noret_decl(trf_5013)
static void C_ccall trf_5013(C_word c,C_word *av) C_noret;
static void C_ccall trf_5013(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_5013(t0,t1,t2,t3);}

C_noret_decl(trf_5017)
static void C_ccall trf_5017(C_word c,C_word *av) C_noret;
static void C_ccall trf_5017(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_5017(t0,t1);}

C_noret_decl(trf_6383)
static void C_ccall trf_6383(C_word c,C_word *av) C_noret;
static void C_ccall trf_6383(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_6383(t0,t1,t2,t3);}

C_noret_decl(trf_4201)
static void C_ccall trf_4201(C_word c,C_word *av) C_noret;
static void C_ccall trf_4201(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_4201(t0,t1,t2);}

C_noret_decl(trf_5746)
static void C_ccall trf_5746(C_word c,C_word *av) C_noret;
static void C_ccall trf_5746(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_5746(t0,t1,t2);}

C_noret_decl(trf_2863)
static void C_ccall trf_2863(C_word c,C_word *av) C_noret;
static void C_ccall trf_2863(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2863(t0,t1);}

/* a5139 in a5133 in a5121 in a5097 in k5075 in k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in ... */
static void C_ccall f_5140(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5140,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k2891 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_2893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2893,2,av);}
t2=C_mutate2(&lf[38] /* (set! main#*hacks* ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2841 in map-loop344 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_2843(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2843,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2818(t6,((C_word*)t0)[5],t5);}

/* k3405 in k3329 in k3326 in k3236 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_3407(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_3407,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
/* chicken-install.scm:287: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3360,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
/* chicken-install.scm:275: ->string */
t5=C_fast_retrieve(lf[56]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* a5133 in a5121 in a5097 in k5075 in k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in ... */
static void C_ccall f_5134(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,2))){
C_save_and_reclaim((void*)f_5134,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5140,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:651: k1164 */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k4120 in k4108 in k4102 in k4099 in g706 in k4094 in k4091 in k4082 in k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_4122(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4122,2,av);}
a=C_alloc(5);
t2=C_i_check_list_2(((C_word*)t0)[2],lf[99]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4135,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4135(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* for-each-loop722 in k4120 in k4108 in k4102 in k4099 in g706 in k4094 in k4091 in k4082 in k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_fcall f_4135(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_4135,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4145,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:435: g738 */
t5=*((C_word*)lf[83]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[100];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5157 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in ... */
static void C_ccall f_5159(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5159,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5165,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:647: directory? */
t3=C_fast_retrieve(lf[275]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[276];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_5073(2,av2);}}}

/* k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in ... */
static void C_ccall f_4811(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_4811,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm:543: setup-api#sudo-install */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[309]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[309]+1);
av2[1]=t3;
tp(2,av2);}}

/* k4839 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in ... */
static void C_ccall f_4841(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_4841,2,av);}
a=C_alloc(16);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_pairp(C_retrieve2(lf[25],"main#\052csc-features\052")))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4888,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:558: open-output-string */
t5=C_fast_retrieve(lf[45]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=lf[300];
f_4845(2,av2);}}}

/* k4843 in k4839 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in ... */
static void C_ccall f_4845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(17,c,2))){C_save_and_reclaim((void *)f_4845,2,av);}
a=C_alloc(17);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_i_pairp(C_retrieve2(lf[26],"main#\052csc-nonfeatures\052")))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4867,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:561: open-output-string */
t5=C_fast_retrieve(lf[45]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=lf[297];
f_4849(2,av2);}}}

/* k4847 in k4843 in k4839 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in ... */
static void C_ccall f_4849(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_4849,2,av);}
a=C_alloc(18);
t2=t1;
t3=(C_truep(C_retrieve2(lf[23],"main#\052deploy\052"))?lf[289]:lf[290]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,a[14]=t4,tmp=(C_word)a,a+=15,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4861,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:565: string-append */
t7=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[13];
av2[3]=lf[294];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in ... */
static void C_ccall f_3834(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_3834,2,av);}
a=C_alloc(9);
t2=t1;
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[5];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3575,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3580,a[2]=t3,a[3]=t5,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:316: call-with-current-continuation */
t9=*((C_word*)lf[191]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}

/* k4143 in for-each-loop722 in k4120 in k4108 in k4102 in k4099 in g706 in k4094 in k4091 in k4082 in k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_4145(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4145,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4135(t3,((C_word*)t0)[4],t2);}

/* a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in ... */
static void C_ccall f_3819(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_3819,5,av);}
a=C_alloc(9);
t5=t2;
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3840,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:374: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t6;
av2[3]=t7;
C_call_with_values(4,av2);}}
else{
/* chicken-install.scm:373: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=C_SCHEME_FALSE;
av2[3]=lf[192];
C_values(4,av2);}}}

/* k3801 in trying-sources in k3716 in main#with-default-sources in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_3803(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3803,2,av);}
t2=C_i_cadr(t1);
/* chicken-install.scm:356: resolve-location */
f_2970(((C_word*)t0)[2],t2);}

/* scan in k3236 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_3247(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,4))){
C_save_and_reclaim_args((void *)trf_3247,5,t0,t1,t2,t3,t4);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t2))){
if(C_truep(t4)){
/* chicken-install.scm:254: values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=C_SCHEME_FALSE;
av2[3]=t4;
C_values(4,av2);}}
else{
if(C_truep(t3)){
t5=t3;
/* chicken-install.scm:254: values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t5;
av2[3]=t4;
C_values(4,av2);}}
else{
/* chicken-install.scm:254: values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=C_SCHEME_FALSE;
av2[3]=t4;
C_values(4,av2);}}}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3269,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3279,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:259: ##sys#call-with-values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t5;
av2[3]=t6;
C_call_with_values(4,av2);}}}

/* k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in ... */
static void C_ccall f_4805(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_4805,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm:541: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[310];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in ... */
static void C_ccall f_4802(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_4802,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-install.scm:541: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[9];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in ... */
static void C_ccall f_4808(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_4808,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:541: get-output-string */
t3=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5318 in k5307 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in ... */
static void C_ccall f_5320(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_5320,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];
t3=C_a_i_list(&a,3,((C_word*)t0)[3],t1,((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8088,a[2]=t2,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t4;
av2[2]=*((C_word*)lf[40]+1);
av2[3]=lf[335];
av2[4]=t3;
C_apply(5,av2);}}

/* k5357 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in ... */
static void C_ccall f_5359(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5359,2,av);}
t2=((C_word*)t0)[2];
f_5343(t2,C_i_not(t1));}

/* k3220 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_3222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3222,2,av);}
/* chicken-install.scm:248: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}

/* k3131 in k3128 in k3125 in k3119 in main#ext-version in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_3133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3133,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=t1;
t4=C_i_assq(lf[55],t3);
if(C_truep(t4)){
t5=C_i_cadr(t4);
/* chicken-install.scm:236: ->string */
t6=C_fast_retrieve(lf[56]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=lf[57];
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k3128 in k3125 in k3119 in main#ext-version in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_3130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3130,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3133,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3157,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:231: file-exists? */
t5=C_fast_retrieve(lf[60]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5347 in k5344 in k5341 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in ... */
static void C_ccall f_5349(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5349,2,av);}
/* chicken-install.scm:615: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5344 in k5341 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in ... */
static void C_ccall f_5346(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5346,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5349,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:614: cleanup */
f_5559(t2);}

/* k5341 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in ... */
static void C_fcall f_5343(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_5343,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:613: print */
t3=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[340];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
f_5020(2,av2);}}}

/* k3125 in k3119 in main#ext-version in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_3127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3127,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3130,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3164,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:230: repo-path */
f_2457(t4);}

/* k3119 in main#ext-version in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_3121(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,3))){
C_save_and_reclaim_args((void *)trf_3121,2,t0,t1);}
a=C_alloc(3);
if(C_truep(t1)){
/* chicken-install.scm:226: chicken-version */
t2=C_fast_retrieve(lf[54]);{
C_word av2[2];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3127,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:229: ##sys#canonicalize-extension-path */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[62]);
C_word av2[4];
av2[0]=*((C_word*)lf[62]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=lf[63];
tp(4,av2);}}}

/* main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_3205(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_3205,2,t1,t2);}
a=C_alloc(8);
t3=C_i_symbolp(t2);
t4=(C_truep(t3)?t3:C_i_stringp(t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3222,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3232,a[2]=t1,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:248: ext-version */
f_3111(t6,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3238,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_listp(t2))){
t6=C_i_car(t2);
t7=t5;
f_3238(t7,C_eqp(lf[76],t6));}
else{
t6=t5;
f_3238(t6,C_SCHEME_FALSE);}}}

/* k3155 in k3128 in k3125 in k3119 in main#ext-version in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_3157(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3157,2,av);}
if(C_truep(t1)){
/* chicken-install.scm:232: with-input-from-file */
t2=C_fast_retrieve(lf[58]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=*((C_word*)lf[59]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_3133(2,av2);}}}

/* k2778 in g350 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_2780(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2780,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_i_cadr(((C_word*)t0)[2]);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_a_i_cons(&a,2,t2,t3);
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* chicken-install.scm:172: broken */
t2=((C_word*)t0)[4];
f_2563(t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k7460 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_7462(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_7462,2,av);}
a=C_alloc(7);
if(C_truep(C_i_equalp(lf[436],t1))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:1052: pathname-file */
t3=C_fast_retrieve(lf[361]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:1066: irregex-match */
t3=C_fast_retrieve(lf[228]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k3630 in k3627 in k3624 in k3612 in k3600 in a3591 in a3585 in a3579 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_3632(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3632,2,av);}
/* chicken-install.scm:339: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=lf[171];
C_values(4,av2);}}

/* k6849 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_6851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6851,2,av);}
/* chicken-install.scm:962: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6856 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_6858(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6858,2,av);}
/* chicken-install.scm:961: print */
t2=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3624 in k3612 in k3600 in a3591 in a3585 in a3579 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_fcall f_3626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_3626,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3629,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:337: print */
t4=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[173];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];
/* chicken-install.scm:341: abort */
t3=C_fast_retrieve(lf[174]);{
C_word av2[3];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k3627 in k3624 in k3612 in k3600 in a3591 in a3585 in a3579 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_3629(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3629,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3632,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:338: print-error-message */
t3=C_fast_retrieve(lf[172]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6818 in k6807 in k6791 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_6820(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6820,2,av);}
/* chicken-install.scm:954: make-pathname */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3615 in k3612 in k3600 in a3591 in a3585 in a3579 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_3617(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3617,2,av);}
/* chicken-install.scm:335: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=lf[169];
C_values(4,av2);}}

/* k3612 in k3600 in a3591 in a3585 in a3579 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_fcall f_3614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_3614,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3617,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:334: print */
t3=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[170];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=C_i_memv(lf[175],((C_word*)t0)[4]);
t4=t2;
f_3626(t4,(C_truep(t3)?C_i_memv(lf[176],((C_word*)t0)[4]):C_SCHEME_FALSE));}
else{
t3=t2;
f_3626(t3,C_SCHEME_FALSE);}}}

/* k3787 in k3755 in trying-sources in k3716 in main#with-default-sources in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_3789(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3789,2,av);}
t2=((C_word*)t0)[2];
f_3760(t2,C_i_cadr(t1));}

/* k6791 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_6793(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_6793,2,av);}
a=C_alloc(10);
t2=C_i_cadr(((C_word*)t0)[2]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6809,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:951: absolute-pathname? */
t6=C_fast_retrieve(lf[94]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k3600 in a3591 in a3585 in a3579 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_fcall f_3602(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_3602,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3605,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:331: print */
t3=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[168];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=C_i_memv(lf[175],((C_word*)t0)[4]);
t4=t2;
f_3614(t4,(C_truep(t3)?C_i_memv(lf[177],((C_word*)t0)[4]):C_SCHEME_FALSE));}
else{
t3=t2;
f_3614(t3,C_SCHEME_FALSE);}}}

/* k3603 in k3600 in a3591 in a3585 in a3579 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_3605(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3605,2,av);}
/* chicken-install.scm:332: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=lf[167];
C_values(4,av2);}}

/* k6798 in k6791 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_6800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6800,2,av);}
t2=C_mutate2(&lf[27] /* (set! main#*prefix* ...) */,t1);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
/* chicken-install.scm:955: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6383(t6,((C_word*)t0)[4],t5,((C_word*)((C_word*)t0)[5])[1]);}

/* k6807 in k6791 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_6809(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_6809,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
f_6800(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6816,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6820,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:954: current-directory */
t4=C_fast_retrieve(lf[93]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6814 in k6807 in k6791 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_6816(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6816,2,av);}
/* chicken-install.scm:953: normalize-pathname */
t2=C_fast_retrieve(lf[303]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5597 in k5594 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in ... */
static void C_ccall f_5599(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_5599,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5618,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:717: with-output-to-file */
t4=C_fast_retrieve(lf[238]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5594 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_5596(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5596,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:716: newline */
t4=*((C_word*)lf[235]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_5593(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_5593,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5657,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5681,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:704: append-map */
t5=C_fast_retrieve(lf[211]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=C_fast_retrieve(lf[247]);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_5590(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5590,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:701: print */
t3=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[248];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7414 in k7407 in k7398 in k7377 in k7460 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_7416(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7416,2,av);}
/* chicken-install.scm:1061: make-pathname */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6169 in k6166 in k6163 in main#$system in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_6171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6171,2,av);}
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* chicken-install.scm:763: error */
t3=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[213];
av2[3]=t1;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2406(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2406,2,av);}
a=C_alloc(3);
t2=C_mutate2(&lf[0] /* (set! main#constant159 ...) */,lf[1]);
t3=C_mutate2(&lf[2] /* (set! main#constant163 ...) */,lf[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:74: get-environment-variable */
t5=C_fast_retrieve(lf[222]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[450];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2403(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2403,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2406,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:27: ##sys#require */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[451]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[451]+1);
av2[1]=t2;
av2[2]=lf[452];
tp(3,av2);}}

/* k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2400(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2400,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2403,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:27: ##sys#require */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[451]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[451]+1);
av2[1]=t2;
av2[2]=lf[453];
tp(3,av2);}}

/* k6185 in main#$system in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_6187(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_6187,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6191,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:752: g1492 */
t3=t2;
f_6191(t3,((C_word*)t0)[3],t1);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
f_6165(2,av2);}}}

/* g1492 in k6185 in main#$system in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_fcall f_6191(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_6191,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6199,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:758: qs */
t4=C_fast_retrieve(lf[220]);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6197 in g1492 in k6185 in main#$system in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_6199(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_6199,2,av);}
/* chicken-install.scm:757: string-append */
t2=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[218];
av2[3]=t1;
av2[4]=lf[219];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}

/* k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_5587(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(20,c,4))){C_save_and_reclaim((void *)f_5587,2,av);}
a=C_alloc(20);
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5814,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5819,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5934,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:689: ##sys#dynamic-wind */
t10=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t10;
av2[1]=t6;
av2[2]=t7;
av2[3]=t8;
av2[4]=t9;
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}

/* k2628 in k2625 in k2622 in k2619 in k2616 in k2610 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in ... */
static void C_ccall f_2630(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2630,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:145: get-output-string */
t3=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_5581(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5581,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5584,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:687: make-pathname */
t4=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_retrieve2(lf[0],"main#constant159");
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_5584(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5584,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:688: print */
t4=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[256];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2631 in k2628 in k2625 in k2622 in k2619 in k2616 in k2610 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in ... */
static void C_ccall f_2633(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2633,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:144: error */
t3=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2446(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(24,c,3))){C_save_and_reclaim((void *)f_2446,2,av);}
a=C_alloc(24);
t2=C_mutate2(&lf[29] /* (set! main#*cross-chicken* ...) */,t1);
t3=C_mutate2(&lf[30] /* (set! main#*host-extension* ...) */,C_retrieve2(lf[29],"main#\052cross-chicken\052"));
t4=C_mutate2(&lf[31] /* (set! main#*target-extension* ...) */,C_retrieve2(lf[29],"main#\052cross-chicken\052"));
t5=lf[32] /* main#*debug-setup* */ =C_SCHEME_FALSE;;
t6=lf[33] /* main#*keep-going* */ =C_SCHEME_FALSE;;
t7=lf[34] /* main#*override* */ =C_SCHEME_END_OF_LIST;;
t8=lf[35] /* main#*reinstall* */ =C_SCHEME_FALSE;;
t9=lf[36] /* main#*show-depends* */ =C_SCHEME_FALSE;;
t10=lf[37] /* main#*show-foreign-depends* */ =C_SCHEME_FALSE;;
t11=lf[38] /* main#*hacks* */ =C_SCHEME_END_OF_LIST;;
t12=C_mutate2(&lf[39] /* (set! main#repo-path ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2457,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate2(&lf[49] /* (set! main#get-prefix ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2524,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate2(&lf[50] /* (set! main#resolve-location ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2970,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate2(&lf[51] /* (set! main#deps ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3038,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate2(&lf[52] /* (set! main#ext-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3111,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate2(&lf[67] /* (set! main#check-dependency ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3205,tmp=(C_word)a,a+=2,tmp));
t18=lf[77] /* main#*eggs+dirs+vers* */ =C_SCHEME_END_OF_LIST;;
t19=lf[78] /* main#*dependencies* */ =C_SCHEME_END_OF_LIST;;
t20=lf[79] /* main#*checked* */ =C_SCHEME_END_OF_LIST;;
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3569,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7585,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7589,a[2]=t22,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t24=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t24;
av2[1]=t23;
av2[2]=C_mpointer(&a,(void*)C_CSI_PROGRAM);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t24+1)))(4,av2);}}

/* k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_5578(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5578,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5581,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:686: create-temporary-directory */
t4=C_fast_retrieve(lf[257]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2619 in k2616 in k2610 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_2621(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2621,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:145: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[370];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2622 in k2619 in k2616 in k2610 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in ... */
static void C_ccall f_2624(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2624,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:145: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fix(1);
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2625 in k2622 in k2619 in k2616 in k2610 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in ... */
static void C_ccall f_2627(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_2627,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:145: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[131]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[131]+1);
av2[1]=t2;
av2[2]=C_make_character(41);
av2[3]=((C_word*)t0)[5];
tp(4,av2);}}

/* k2610 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_2612(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2612,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[40]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:145: ##sys#print */
t6=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[371];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2616 in k2610 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_2618(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2618,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:145: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_retrieve2(lf[2],"main#constant163");
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* main#$system in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_6161(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,4))){
C_save_and_reclaim_args((void *)trf_6161,2,t1,t2);}
a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6165,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"main#\052windows-shell\052"))){
/* chicken-install.scm:753: string-append */
t4=*((C_word*)lf[70]+1);{
C_word av2[5];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[216];
av2[3]=t2;
av2[4]=lf[217];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6187,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6212,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:754: software-version */
t6=C_fast_retrieve(lf[224]);{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* a5850 in a5844 in a5838 in k5829 in k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in ... */
static void C_ccall f_5851(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5851,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5859,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:698: open-output-string */
t3=C_fast_retrieve(lf[45]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6163 in main#$system in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_6165(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_6165,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6168,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:760: print */
t4=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[215];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k6166 in k6163 in main#$system in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_6168(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6168,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:761: system */
t3=C_fast_retrieve(lf[214]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5863 in k5857 in a5850 in a5844 in a5838 in k5829 in k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in ... */
static void C_ccall f_5865(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_5865,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:698: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k5866 in k5863 in k5857 in a5850 in a5844 in a5838 in k5829 in k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in ... */
static void C_ccall f_5868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5868,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:698: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[131]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[131]+1);
av2[1]=t2;
av2[2]=C_make_character(39);
av2[3]=((C_word*)t0)[5];
tp(4,av2);}}

/* k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2416(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2416,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2419,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t1;
f_2419(2,av2);}}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[46]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_mpointer(&a,(void*)C_INSTALL_BIN_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2419(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2419,2,av);}
a=C_alloc(3);
t2=C_mutate2(&lf[4] /* (set! main#*program-path* ...) */,t1);
t3=lf[5] /* main#*keep* */ =C_SCHEME_FALSE;;
t4=lf[6] /* main#*keep-existing* */ =C_SCHEME_FALSE;;
t5=lf[7] /* main#*force* */ =C_SCHEME_FALSE;;
t6=lf[8] /* main#*run-tests* */ =C_SCHEME_FALSE;;
t7=lf[9] /* main#*retrieve-only* */ =C_SCHEME_FALSE;;
t8=lf[10] /* main#*no-install* */ =C_SCHEME_FALSE;;
t9=lf[11] /* main#*username* */ =C_SCHEME_FALSE;;
t10=lf[12] /* main#*password* */ =C_SCHEME_FALSE;;
t11=lf[13] /* main#*default-sources* */ =C_SCHEME_END_OF_LIST;;
t12=lf[14] /* main#*default-location* */ =C_SCHEME_FALSE;;
t13=C_mutate2(&lf[15] /* (set! main#*default-transport* ...) */,lf[16]);
t14=C_mutate2(&lf[17] /* (set! main#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t15=lf[18] /* main#*proxy-host* */ =C_SCHEME_FALSE;;
t16=lf[19] /* main#*proxy-port* */ =C_SCHEME_FALSE;;
t17=lf[20] /* main#*proxy-user-pass* */ =C_SCHEME_FALSE;;
t18=lf[21] /* main#*running-test* */ =C_SCHEME_FALSE;;
t19=lf[22] /* main#*mappings* */ =C_SCHEME_END_OF_LIST;;
t20=lf[23] /* main#*deploy* */ =C_SCHEME_FALSE;;
t21=lf[24] /* main#*trunk* */ =C_SCHEME_FALSE;;
t22=lf[25] /* main#*csc-features* */ =C_SCHEME_END_OF_LIST;;
t23=lf[26] /* main#*csc-nonfeatures* */ =C_SCHEME_END_OF_LIST;;
t24=lf[27] /* main#*prefix* */ =C_SCHEME_FALSE;;
t25=lf[28] /* main#*aliases* */ =C_SCHEME_END_OF_LIST;;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2446,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:101: feature? */
t27=C_fast_retrieve(lf[151]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t27;
av2[1]=t26;
av2[2]=lf[448];
((C_proc)(void*)(*((C_word*)t27+1)))(3,av2);}}

/* k6988 in k6974 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_6990(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_6990,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_retrieve2(lf[26],"main#\052csc-nonfeatures\052"));
t3=C_mutate2(&lf[26] /* (set! main#*csc-nonfeatures* ...) */,t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
/* chicken-install.scm:983: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6383(t7,((C_word*)t0)[4],t6,((C_word*)((C_word*)t0)[5])[1]);}

/* k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2413(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_2413,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2416,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* chicken-install.scm:75: make-pathname */
t3=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
av2[3]=lf[449];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_2416(2,av2);}}}

/* k4209 in for-each-loop705 in k4094 in k4091 in k4082 in k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in ... */
static void C_ccall f_4211(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4211,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4201(t3,((C_word*)t0)[4],t2);}

/* k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2391(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2391,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_extras_toplevel(2,av2);}}

/* k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2397(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2397,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_files_toplevel(2,av2);}}

/* k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2394(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2394,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_srfi_2d13_toplevel(2,av2);}}

/* k5857 in a5850 in a5844 in a5838 in k5829 in k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in ... */
static void C_ccall f_5859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_5859,2,av);}
a=C_alloc(7);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[40]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:698: ##sys#print */
t6=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[250];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k6334 in k6328 in main#setup-proxy in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_6336(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_6336,2,av);}
a=C_alloc(5);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6343,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:847: get-environment-variable */
t4=C_fast_retrieve(lf[222]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[227];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* f8076 in tmp1154 in k5075 in k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in ... */
static void C_ccall f8076(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8076,2,av);}
/* chicken-install.scm:798: $system */
f_6161(((C_word*)t0)[2],t1);}

/* k6328 in main#setup-proxy in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_6330(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_6330,2,av);}
a=C_alloc(4);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6336,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:846: irregex-match-substring */
t4=C_fast_retrieve(lf[226]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_fix(3);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k5829 in k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in ... */
static void C_ccall f_5831(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_5831,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5834,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5839,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:691: call-with-current-continuation */
t5=*((C_word*)lf[191]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_4247(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_4247,2,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4251,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:441: print */
t4=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[201];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a5844 in a5838 in k5829 in k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in ... */
static void C_ccall f_5845(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5845,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5851,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:691: k1272 */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* f8088 in k5318 in k5307 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in ... */
static void C_ccall f8088(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8088,2,av);}
/* chicken-install.scm:798: $system */
f_6161(((C_word*)t0)[2],t1);}

/* k2371 in k2368 in k2365 */
static void C_ccall f_2373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2373,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_srfi_2d1_toplevel(2,av2);}}

/* k7063 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_7065(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7065,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_mutate2(&lf[11] /* (set! main#*username* ...) */,t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
/* chicken-install.scm:1002: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6383(t7,((C_word*)t0)[4],t6,((C_word*)((C_word*)t0)[5])[1]);}

/* k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2376(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2376,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_posix_toplevel(2,av2);}}

/* k2368 in k2365 */
static void C_ccall f_2370(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2370,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_chicken_2dsyntax_toplevel(2,av2);}}

/* k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2379(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2379,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2382,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_data_2dstructures_toplevel(2,av2);}}

/* k5832 in k5829 in k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in ... */
static void C_ccall f_5834(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5834,2,av);}
/* chicken-install.scm:691: g1276 */
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* a5838 in k5829 in k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in ... */
static void C_ccall f_5839(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_5839,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5845,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5876,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:691: with-exception-handler */
t5=C_fast_retrieve(lf[190]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* main#info->egg in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_6356(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6356,3,av);}
t3=C_i_cdr(t2);
if(C_truep((C_truep(C_i_equalp(t3,lf[231]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[232]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[233]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t4=t2;
t5=C_u_i_car(t4);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t4=t2;
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* f8149 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f8149(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8149,2,av);}
/* chicken-install.scm:841: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* map-loop1322 in a5701 in k5689 in k5686 in a5680 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in ... */
static void C_fcall f_5780(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,0,2))){
C_save_and_reclaim_args((void *)trf_5780,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_5711(C_a_i(&a,9),((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* f8144 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f8144(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8144,2,av);}
/* chicken-install.scm:841: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in ... */
static void C_ccall f_5828(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5828,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:694: pathname-strip-extension */
t3=C_fast_retrieve(lf[253]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_5825(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5825,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5828,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:693: pathname-strip-extension */
t4=C_fast_retrieve(lf[253]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_4251(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_4251,2,av);}
a=C_alloc(8);
t2=((C_word*)t0)[2];
t3=C_i_check_list_2(t2,lf[99]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4330,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4598,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4598(t8,t4,t2);}

/* main#setup-proxy in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_6320(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,3))){
C_save_and_reclaim_args((void *)trf_6320,2,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_stringp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6330,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:845: irregex-match */
t4=C_fast_retrieve(lf[228]);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[229];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_5819(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5819,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5911,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5911(t5,t1,((C_word*)t0)[2]);}

/* a5813 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_5814(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5814,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_fast_retrieve(lf[249]));
t3=C_mutate2((C_word*)lf[249]+1 /* (set! ##sys#warnings-enabled ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k7089 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_7091(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7091,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
/* chicken-install.scm:1006: loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_6383(t7,((C_word*)t0)[5],t6,((C_word*)((C_word*)t0)[6])[1]);}

/* k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2385(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2385,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2388,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_irregex_toplevel(2,av2);}}

/* k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2382(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2382,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2385,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_utils_toplevel(2,av2);}}

/* k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2388(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2388,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2391,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_ports_toplevel(2,av2);}}

/* for-each-loop507 in k3469 in a4370 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_fcall f_3541(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_3541,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3551,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:294: g508 */
t5=((C_word*)t0)[3];
f_3472(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6345 in k6341 in k6334 in k6328 in main#setup-proxy in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_6347(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,1))){C_save_and_reclaim((void *)f_6347,2,av);}
a=C_alloc(4);
t2=C_mutate2(&lf[18] /* (set! main#*proxy-host* ...) */,t1);
t3=C_a_i_string_to_number(&a,2,((C_word*)t0)[2],C_fix(10));
if(C_truep(t3)){
t4=C_mutate2(&lf[19] /* (set! main#*proxy-port* ...) */,t3);
t5=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=lf[19] /* main#*proxy-port* */ =C_fix(80);;
t5=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k6341 in k6334 in k6328 in main#setup-proxy in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_6343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_6343,2,av);}
a=C_alloc(4);
t2=C_mutate2(&lf[20] /* (set! main#*proxy-user-pass* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:848: irregex-match-substring */
t4=C_fast_retrieve(lf[226]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=C_fix(2);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* a2693 in k2687 in k2684 in g305 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in ... */
static void C_ccall f_2694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2694,2,av);}
/* chicken-install.scm:162: split-at */
t2=C_fast_retrieve(lf[373]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2365 */
static void C_ccall f_2367(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2367,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2370,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k2675 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_2677(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2677,2,av);}
t2=C_mutate2(&lf[22] /* (set! main#*mappings* ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_4077(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_4077,3,t1,t2,t3);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4081,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:420: print */
t5=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[111];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k2814 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_2816(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2816,2,av);}
/* chicken-install.scm:167: append */
t2=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[28],"main#\052aliases\052");
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop344 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_fcall f_2818(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_2818,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2843,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:169: g350 */
t5=((C_word*)t0)[4];
f_2773(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2659 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_2661(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2661,2,av);}
t2=C_mutate2(&lf[13] /* (set! main#*default-sources* ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6482 in k6476 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_6484(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_6484,2,av);}
a=C_alloc(17);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=C_retrieve2(lf[230],"main#info->egg");
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6493,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_6493(t11,t7,((C_word*)t0)[4]);}
else{
/* chicken-install.scm:886: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k3504 in k3500 in loop in k3481 in k3469 in a4370 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_3506(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3506,2,av);}
/* chicken-install.scm:301: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
C_values(4,av2);}}

/* k3500 in loop in k3481 in k3469 in a4370 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_3502(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3502,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3506,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:301: reverse */
t4=*((C_word*)lf[112]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a5267 in k5256 in k5247 in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in ... */
static void C_ccall f_5268(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5268,2,av);}
/* chicken-install.scm:665: setup */
t2=((C_word*)t0)[2];
f_5033(t2,t1,((C_word*)t0)[3]);}

/* k4871 in k4865 in k4843 in k4839 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in ... */
static void C_ccall f_4873(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4873,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:561: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_retrieve2(lf[26],"main#\052csc-nonfeatures\052");
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* a5262 in k5256 in k5247 in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in ... */
static void C_ccall f_5263(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5263,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[30],"main#\052host-extension\052"));
t3=C_mutate2(&lf[30] /* (set! main#*host-extension* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* map-loop1583 in k6482 in k6476 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_fcall f_6493(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_6493,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6518,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:885: g1589 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4877 in k4874 in k4871 in k4865 in k4843 in k4839 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in ... */
static void C_ccall f_4879(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4879,2,av);}
/* chicken-install.scm:561: get-output-string */
t2=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6489 in k6482 in k6476 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_6491(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6491,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
f_6421(2,av2);}}

/* k4874 in k4871 in k4865 in k4843 in k4839 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in ... */
static void C_ccall f_4876(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_4876,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:561: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[295];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4091 in k4082 in k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_4093(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_4093,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:422: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[106];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4094 in k4091 in k4082 in k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_4096(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_4096,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4097,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve2(lf[77],"main#\052eggs+dirs+vers\052");
t4=C_i_check_list_2(C_retrieve2(lf[77],"main#\052eggs+dirs+vers\052"),lf[99]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4193,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4201,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4201(t9,t5,C_retrieve2(lf[77],"main#\052eggs+dirs+vers\052"));}

/* g706 in k4094 in k4091 in k4082 in k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in ... */
static void C_fcall f_4097(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_4097,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4101,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_cadr(t2);
t5=t2;
t6=C_u_i_car(t5);
/* chicken-install.scm:428: make-pathname */
t7=C_fast_retrieve(lf[41]);{
C_word av2[5];
av2[0]=t7;
av2[1]=t3;
av2[2]=t4;
av2[3]=t6;
av2[4]=lf[104];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}

/* a5297 in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in ... */
static void C_ccall f_5298(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5298,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[23],"main#\052deploy\052"));
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[27],"main#\052prefix\052"));
t4=C_mutate2(&lf[23] /* (set! main#*deploy* ...) */,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate2(&lf[27] /* (set! main#*prefix* ...) */,((C_word*)((C_word*)t0)[5])[1]);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* a5291 in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in ... */
static void C_ccall f_5292(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5292,2,av);}
/* chicken-install.scm:660: setup */
t2=((C_word*)t0)[2];
f_5033(t2,t1,((C_word*)t0)[3]);}

/* k6458 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_6460(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6460,2,av);}
if(C_truep(C_retrieve2(lf[14],"main#\052default-location\052"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
f_6424(2,av2);}}
else{
/* chicken-install.scm:905: error */
t2=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[353];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k4892 in k4886 in k4839 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in ... */
static void C_ccall f_4894(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4894,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:558: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_retrieve2(lf[25],"main#\052csc-features\052");
av2[3]=C_SCHEME_TRUE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4028 in k4025 in k4022 in k4019 in k4016 in k4013 in k4010 in k4007 in k4001 in k3994 in g656 in k3977 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_4030(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4030,2,av);}
/* chicken-install.scm:409: warning */
t2=C_fast_retrieve(lf[74]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4895 in k4892 in k4886 in k4839 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in ... */
static void C_ccall f_4897(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_4897,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:558: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[298];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6476 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_6478(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_6478,2,av);}
a=C_alloc(9);
t2=t1;
t3=C_retrieve2(lf[7],"main#\052force\052");
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[7],"main#\052force\052"))){
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_retrieve2(lf[7],"main#\052force\052");
f_6484(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6535,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:881: open-output-string */
t6=C_fast_retrieve(lf[45]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}

/* k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_2581(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(23,c,3))){C_save_and_reclaim((void *)f_2581,2,av);}
a=C_alloc(23);
t2=C_i_car(((C_word*)t0)[2]);
t3=C_eqp(t2,lf[55]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
if(C_truep(C_i_pairp(t5))){
t6=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_i_nequalp(t6,C_fix(1)))){
t7=C_SCHEME_UNDEFINED;
t8=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:145: open-output-string */
t8=C_fast_retrieve(lf[45]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}}
else{
/* chicken-install.scm:142: broken */
t6=((C_word*)t0)[4];
f_2563(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t4=C_eqp(t2,lf[372]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2661,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_a_i_list1(&a,1,t7);
/* chicken-install.scm:154: append */
t9=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t5;
av2[2]=C_retrieve2(lf[13],"main#\052default-sources\052");
av2[3]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
t5=C_eqp(t2,lf[114]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2677,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t9)[1];
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t12=((C_word*)t0)[2];
t13=C_u_i_cdr(t12);
t14=C_i_check_list_2(t13,lf[114]);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2724,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2726,a[2]=t9,a[3]=t17,a[4]=t11,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t19=((C_word*)t17)[1];
f_2726(t19,t15,t13);}
else{
t6=C_eqp(t2,lf[375]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t9=t8;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=((C_word*)t10)[1];
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2773,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=((C_word*)t0)[2];
t14=C_u_i_cdr(t13);
t15=C_i_check_list_2(t14,lf[114]);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2816,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2818,a[2]=t10,a[3]=t18,a[4]=t12,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_2818(t20,t16,t14);}
else{
t7=C_eqp(t2,lf[377]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2863,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
if(C_truep(C_i_pairp(t11))){
t12=C_i_cadr(((C_word*)t0)[2]);
t13=t9;
f_2863(t13,C_i_stringp(t12));}
else{
t12=t9;
f_2863(t12,C_SCHEME_FALSE);}}
else{
t8=C_eqp(t2,lf[378]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2901,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:180: eval */
t12=C_fast_retrieve(lf[252]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t12;
av2[1]=t10;
av2[2]=t11;
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}
else{
/* chicken-install.scm:181: broken */
t9=((C_word*)t0)[4];
f_2563(t9,((C_word*)t0)[3],((C_word*)t0)[2]);}}}}}}}

/* a5273 in k5256 in k5247 in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in ... */
static void C_ccall f_5274(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5274,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[30],"main#\052host-extension\052"));
t3=C_mutate2(&lf[30] /* (set! main#*host-extension* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_4330(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_4330,2,av);}
a=C_alloc(5);
if(C_truep(C_retrieve2(lf[9],"main#\052retrieve-only\052"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_retrieve2(lf[77],"main#\052eggs+dirs+vers\052");
t3=C_i_check_list_2(C_retrieve2(lf[77],"main#\052eggs+dirs+vers\052"),lf[99]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4575,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4575(t7,((C_word*)t0)[2],C_retrieve2(lf[77],"main#\052eggs+dirs+vers\052"));}}

/* k2568 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_2570(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2570,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_pairp(C_retrieve2(lf[13],"main#\052default-sources\052"));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_fcall f_2577(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_2577,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2581,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t2))){
t4=t2;
t5=C_u_i_length(t4);
if(C_truep(C_fixnum_greaterp(t5,C_fix(0)))){
t6=t3;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_2581(2,av2);}}
else{
/* chicken-install.scm:139: broken */
t6=((C_word*)t0)[2];
f_2563(t6,t3,t2);}}
else{
/* chicken-install.scm:139: broken */
t4=((C_word*)t0)[2];
f_2563(t4,t3,t2);}}

/* k6516 in map-loop1583 in k6482 in k6476 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_6518(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6518,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6493(t6,((C_word*)t0)[5],t5);}

/* k4318 in a4288 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in ... */
static void C_ccall f_4320(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4320,2,av);}
if(C_truep(C_i_nullp(t1))){
/* chicken-install.scm:454: error */
t2=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[195];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
f_4293(2,av2);}}}

/* broken in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_fcall f_2563(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_2563,3,t0,t1,t2);}
/* chicken-install.scm:133: error */
t3=*((C_word*)lf[69]+1);{
C_word av2[5];
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[369];
av2[3]=((C_word*)t0)[2];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in ... */
static void C_ccall f_4357(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4357,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4360,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_u_i_car(((C_word*)t0)[2]);
/* chicken-install.scm:466: print */
t5=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[158];
av2[3]=t4;
av2[4]=lf[159];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_2561(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_2561,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2563,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2964,a[2]=t3,a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:134: file-exists? */
t6=C_fast_retrieve(lf[60]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in ... */
static void C_ccall f_4354(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,5))){C_save_and_reclaim((void *)f_4354,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:465: with-input-from-file */
t3=C_fast_retrieve(lf[58]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=*((C_word*)lf[59]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4553,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_u_i_car(((C_word*)t0)[2]);
/* chicken-install.scm:500: string-append */
t4=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[160];
av2[3]=t3;
av2[4]=lf[161];
av2[5]=lf[162];
((C_proc)(void*)(*((C_word*)t4+1)))(6,av2);}}}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point

void C_ccall C_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(1305)){
C_save(t1);
C_rereclaim2(1305*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,454);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\016setup.defaults");
lf[16]=C_h_intern(&lf[16],4,"http");
lf[40]=C_h_intern(&lf[40],7,"sprintf");
lf[41]=C_h_intern(&lf[41],13,"make-pathname");
lf[42]=C_h_intern(&lf[42],17,"get-output-string");
lf[43]=C_h_intern(&lf[43],9,"\003sysprint");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\010chicken/");
lf[45]=C_h_intern(&lf[45],18,"open-output-string");
lf[46]=C_h_intern(&lf[46],17,"\003syspeek-c-string");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[48]=C_h_intern(&lf[48],15,"repository-path");
lf[53]=C_h_intern(&lf[53],7,"chicken");
lf[54]=C_h_intern(&lf[54],15,"chicken-version");
lf[55]=C_h_intern(&lf[55],7,"version");
lf[56]=C_h_intern(&lf[56],8,"->string");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\0050.0.0");
lf[58]=C_h_intern(&lf[58],20,"with-input-from-file");
lf[59]=C_h_intern(&lf[59],4,"read");
lf[60]=C_h_intern(&lf[60],12,"file-exists\077");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[62]=C_h_intern(&lf[62],31,"\003syscanonicalize-extension-path");
lf[63]=C_h_intern(&lf[63],11,"ext-version");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[65]=C_h_intern(&lf[65],24,"\003syscore-library-modules");
lf[66]=C_h_intern(&lf[66],23,"\003syscore-syntax-modules");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[69]=C_h_intern(&lf[69],5,"error");
lf[70]=C_h_intern(&lf[70],13,"string-append");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000JYour CHICKEN version is not recent enough to use this extension - version ");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\025 or newer is required");
lf[73]=C_h_intern(&lf[73],20,"setup-api#version>=\077");
lf[74]=C_h_intern(&lf[74],7,"warning");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\0007invalid dependency syntax in extension meta information");
lf[76]=C_h_intern(&lf[76],2,"or");
lf[82]=C_h_intern(&lf[82],4,"exit");
lf[83]=C_h_intern(&lf[83],5,"print");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000,Could not determine a source of extensions. ");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000.Please specify a valid location and transport.");
lf[86]=C_h_intern(&lf[86],19,"with-output-to-port");
lf[87]=C_h_intern(&lf[87],18,"\003sysstandard-error");
lf[88]=C_h_intern(&lf[88],5,"local");
lf[89]=C_h_intern(&lf[89],9,"transport");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\027missing transport entry");
lf[91]=C_h_intern(&lf[91],8,"location");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\026missing location entry");
lf[93]=C_h_intern(&lf[93],17,"current-directory");
lf[94]=C_h_intern(&lf[94],18,"absolute-pathname\077");
lf[96]=C_h_intern(&lf[96],7,"depends");
lf[97]=C_h_intern(&lf[97],19,"\003sysstandard-output");
lf[98]=C_h_intern(&lf[98],6,"printf");
lf[99]=C_h_intern(&lf[99],8,"for-each");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\001\011");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[102]=C_h_intern(&lf[102],5,"needs");
lf[103]=C_h_intern(&lf[103],6,"append");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000$ dependencies as reported in .meta:\012");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\003Egg");
lf[108]=C_h_intern(&lf[108],15,"foreign-depends");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\007Foreign");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\034fetching meta information...");
lf[112]=C_h_intern(&lf[112],7,"reverse");
lf[113]=C_h_intern(&lf[113],12,"test-depends");
lf[114]=C_h_intern(&lf[114],3,"map");
lf[115]=C_h_intern(&lf[115],26,"setup-api#remove-extension");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000)removing previously installed extension `");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\012 upgrade: ");
lf[119]=C_h_intern(&lf[119],18,"string-intersperse");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[121]=C_h_intern(&lf[121],6,"unzip1");
lf[122]=C_h_intern(&lf[122],10,"yes-or-no\077");
lf[123]=C_h_intern(&lf[123],8,"\000default");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[125]=C_h_intern(&lf[125],6,"\000abort");
lf[126]=C_h_intern(&lf[126],21,"setup-api#abort-setup");
lf[127]=C_h_intern(&lf[127],18,"string-concatenate");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000:The following installed extensions are outdated, because `");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\033\047 requires later versions:\012");
lf[130]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\0000\012Do you want to replace the existing extensions\077\376\377\016");
lf[131]=C_h_intern(&lf[131],16,"\003syswrite-char-0");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\036\047 overrides required version `");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\020\047 of extension `");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\011version `");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\003\077\077\077");
lf[136]=C_h_intern(&lf[136],4,"conc");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\002 (");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[141]=C_h_intern(&lf[141],21,"extension-information");
lf[142]=C_h_intern(&lf[142],14,"string->symbol");
lf[143]=C_h_intern(&lf[143],10,"filter-map");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\012 missing: ");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\033checking dependencies for `");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000)extension is not targeted for this system");
lf[150]=C_h_intern(&lf[150],8,"platform");
lf[151]=C_h_intern(&lf[151],8,"feature\077");
lf[152]=C_h_intern(&lf[152],3,"and");
lf[153]=C_h_intern(&lf[153],5,"every");
lf[154]=C_h_intern(&lf[154],3,"any");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid `platform\047 property");
lf[156]=C_h_intern(&lf[156],3,"not");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid `platform\047 property");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\027checking platform for `");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\013extension `");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\024\047 has no .meta file ");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000!- assuming it has no dependencies");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[164]=C_h_intern(&lf[164],6,"delete");
lf[165]=C_h_intern(&lf[165],3,"eq\077");
lf[166]=C_h_intern(&lf[166],9,"condition");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\023TCP connect timeout");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\023HTTP protocol error");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[172]=C_h_intern(&lf[172],19,"print-error-message");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\015Server error:");
lf[174]=C_h_intern(&lf[174],5,"abort");
lf[175]=C_h_intern(&lf[175],3,"exn");
lf[176]=C_h_intern(&lf[176],20,"setup-download-error");
lf[177]=C_h_intern(&lf[177],10,"http-fetch");
lf[178]=C_h_intern(&lf[178],3,"net");
lf[179]=C_h_intern(&lf[179],33,"setup-download#retrieve-extension");
lf[180]=C_h_intern(&lf[180],8,"\000version");
lf[181]=C_h_intern(&lf[181],12,"\000destination");
lf[182]=C_h_intern(&lf[182],6,"\000tests");
lf[183]=C_h_intern(&lf[183],9,"\000username");
lf[184]=C_h_intern(&lf[184],9,"\000password");
lf[185]=C_h_intern(&lf[185],6,"\000trunk");
lf[186]=C_h_intern(&lf[186],11,"\000proxy-host");
lf[187]=C_h_intern(&lf[187],11,"\000proxy-port");
lf[188]=C_h_intern(&lf[188],16,"\000proxy-user-pass");
lf[189]=C_h_intern(&lf[189],6,"\000clean");
lf[190]=C_h_intern(&lf[190],22,"with-exception-handler");
lf[191]=C_h_intern(&lf[191],30,"call-with-current-continuation");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\014 located at ");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\036extension or version not found");
lf[196]=C_h_intern(&lf[196],9,"directory");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000&\047 overrides explicitly given version `");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\020\047 of extension `");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\011version `");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\014overriding: ");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\016retrieving ...");
lf[202]=C_h_intern(&lf[202],26,"setup-api#remove-directory");
lf[203]=C_h_intern(&lf[203],34,"setup-download#temporary-directory");
lf[204]=C_h_intern(&lf[204],14,"symbol->string");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\035internal error - bad egg spec");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\007mapped ");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\004 to ");
lf[208]=C_h_intern(&lf[208],5,"lset=");
lf[209]=C_h_intern(&lf[209],17,"delete-duplicates");
lf[210]=C_h_intern(&lf[210],4,"find");
lf[211]=C_h_intern(&lf[211],10,"append-map");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000/shell command terminated with nonzero exit code");
lf[214]=C_h_intern(&lf[214],6,"system");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\037/usr/bin/env DYLD_LIBRARY_PATH=");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[220]=C_h_intern(&lf[220],2,"qs");
lf[221]=C_h_intern(&lf[221],6,"macosx");
lf[222]=C_h_intern(&lf[222],24,"get-environment-variable");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\021DYLD_LIBRARY_PATH");
lf[224]=C_h_intern(&lf[224],16,"software-version");
lf[226]=C_h_intern(&lf[226],23,"irregex-match-substring");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\012proxy_auth");
lf[228]=C_h_intern(&lf[228],13,"irregex-match");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\033(http://)\077([^:]+):\077([0-9]\052)");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\007unknown");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[234]=C_h_intern(&lf[234],25,"\003sysimplicit-exit-handler");
lf[235]=C_h_intern(&lf[235],7,"newline");
lf[236]=C_h_intern(&lf[236],19,"setup-api#copy-file");
lf[237]=C_h_intern(&lf[237],5,"write");
lf[238]=C_h_intern(&lf[238],19,"with-output-to-file");
lf[239]=C_h_intern(&lf[239],8,"string<\077");
lf[240]=C_h_intern(&lf[240],4,"sort");
lf[241]=C_h_intern(&lf[241],18,"\003sysmodule-exports");
lf[242]=C_h_intern(&lf[242],6,"syntax");
lf[243]=C_h_intern(&lf[243],5,"value");
lf[244]=C_h_intern(&lf[244],6,"print\052");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[246]=C_h_intern(&lf[246],15,"\003sysmodule-name");
lf[247]=C_h_intern(&lf[247],16,"\003sysmodule-table");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\023generating database");
lf[249]=C_h_intern(&lf[249],20,"\003syswarnings-enabled");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\027Failed to import from `");
lf[251]=C_h_intern(&lf[251],6,"import");
lf[252]=C_h_intern(&lf[252],4,"eval");
lf[253]=C_h_intern(&lf[253],24,"pathname-strip-extension");
lf[254]=C_h_intern(&lf[254],24,"pathname-strip-directory");
lf[255]=C_h_intern(&lf[255],16,"\003sysdynamic-wind");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\034loading import libraries ...");
lf[257]=C_h_intern(&lf[257],26,"create-temporary-directory");
lf[258]=C_h_intern(&lf[258],4,"glob");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\014\052.import.scm");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\013\052.import.so");
lf[261]=C_h_intern(&lf[261],2,"pp");
lf[262]=C_h_intern(&lf[262],6,"cadadr");
lf[263]=C_h_intern(&lf[263],37,"setup-download#gather-egg-information");
lf[264]=C_h_intern(&lf[264],7,"display");
lf[265]=C_h_intern(&lf[265],30,"setup-download#list-extensions");
lf[266]=C_h_intern(&lf[266],6,"\000quiet");
lf[267]=C_h_intern(&lf[267],16,"change-directory");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\023~a -s run.scm ~a ~a");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000$\012nevertheless trying to continue ...");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\007testing");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\014 extension `");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\011\047 failed:");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\015tests/run.scm");
lf[275]=C_h_intern(&lf[275],10,"directory\077");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\012installing");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\034-e \042(setup-error-handling)\042 ");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\027 -e \042(sudo-install #t)\042");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(keep-intermediates #t)\042");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(setup-install-mode #f)\042");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\031 -e \042(host-extension #t)\042");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\032 -e \042(deployment-mode #t)\042");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\006 -bnq ");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\0009-e \042(require-library setup-api)\042 -e \042(import setup-api)\042 ");
lf[293]=C_h_intern(&lf[293],19,"setup-api#shellpath");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\006.setup");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\002)\042");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\031 -e \042(extra-nonfeatures \047");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\002)\042");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\026 -e \042(extra-features \047");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\004\134\042)\042");
lf[302]=C_h_intern(&lf[302],16,"string-translate");
lf[303]=C_h_intern(&lf[303],18,"normalize-pathname");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\027 -e \042(runtime-prefix \134\042");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\004\134\042)\042");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\033 -e \042(destination-prefix \134\042");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[309]=C_h_intern(&lf[309],22,"setup-api#sudo-install");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\005\134\042))\042");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\005\134\042 \134\042");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000$-e \042(extension-name-and-version \047(\134\042");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\014-setup-mode ");
lf[315]=C_h_intern(&lf[315],1,"\052");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\003dll");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[320]=C_h_intern(&lf[320],3,"seq");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[322]=C_h_intern(&lf[322],12,"delete-file\052");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[324]=C_h_intern(&lf[324],10,"find-files");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[326]=C_h_intern(&lf[326],5,"\000test");
lf[327]=C_h_intern(&lf[327],7,"\000action");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\033deleting stale binaries ...");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\033deleting stale binaries ...");
lf[330]=C_h_intern(&lf[330],12,"dynamic-wind");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\036changing current directory to ");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\031installing for target ...");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\005xcopy");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\010~a ~a ~a");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\047copying sources for target installation");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\013installing ");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\026aborting installation.");
lf[341]=C_h_intern(&lf[341],17,"\003sysstring-append");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000@You specified `-no-install\047, but this extension has dependencies");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000C that are required for building.\012Do you still want to install them\077");
lf[344]=C_h_intern(&lf[344],4,"iota");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\016install order:");
lf[346]=C_h_intern(&lf[346],7,"fprintf");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\030\012Unresolved dependency: ");
lf[349]=C_h_intern(&lf[349],10,"list-index");
lf[350]=C_h_intern(&lf[350],16,"topological-sort");
lf[351]=C_h_intern(&lf[351],8,"string=\077");
lf[352]=C_h_intern(&lf[352],6,"remove");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000;no default location defined - please use `-location\047 option");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000=no default transport defined - please use `-transport\047 option");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\0009 currently installed extensions - do you want to proceed\077");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\030About to re-install all ");
lf[357]=C_h_intern(&lf[357],6,"equal\077");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[359]=C_h_intern(&lf[359],8,"egg-name");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000Dinstalled extension has no information about which egg it belongs to");
lf[361]=C_h_intern(&lf[361],13,"pathname-file");
lf[362]=C_h_intern(&lf[362],9,"read-file");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\033no setup-scripts to process");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\007\052.setup");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid entry in defaults file");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000$\047 does not match setup-API version (");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\026version of installed `");
lf[372]=C_h_intern(&lf[372],6,"server");
lf[373]=C_h_intern(&lf[373],8,"split-at");
lf[374]=C_h_intern(&lf[374],2,"->");
lf[375]=C_h_intern(&lf[375],5,"alias");
lf[376]=C_h_intern(&lf[376],7,"string\077");
lf[377]=C_h_intern(&lf[377],8,"override");
lf[378]=C_h_intern(&lf[378],4,"hack");
lf[379]=C_h_intern(&lf[379],12,"chicken-home");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000B`-deploy\047 only makes sense in combination with `-prefix DIRECTORY`");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\012+usage: chicken-install [OPTION | EXTENSION[:VERSION]] ...\012\012  -h   -help    "
"                show this message and exit\012       -version                 show "
"version and exit\012       -force                   don\047t ask, install even if vers"
"ions don\047t match\012  -k   -keep                    keep temporary files\012  -x   -ke"
"ep-installed          install only if not already installed\012       -reinstall   "
"            reinstall all currently installed extensions\012  -l   -location LOCATI"
"ON       install from given location instead of default\012  -t   -transport TRANSP"
"ORT     use given transport instead of default\012       -proxy HOST[:PORT]       d"
"ownload via HTTP proxy\012  -s   -sudo                    use external command to e"
"levate privileges for filesystem operations\012  -r   -retrieve                only"
" retrieve egg into current directory, don\047t install\012  -n   -no-install          "
"    do not install, just build (implies `-keep\047)\012  -p   -prefix PREFIX          "
" change installation prefix to PREFIX\012       -list                    list exten"
"sions available over selected transport and location\012       -host               "
"     when cross-compiling, compile extension only for host\012       -target       "
"           when cross-compiling, compile extension only for target\012       -test "
"                   run included test-cases, if available\012       -username USER  "
"         set username for transports that require this\012       -password PASS    "
"       set password for transports that require this\012  -i   -init DIRECTORY     "
"     initialize empty alternative repository\012  -u   -update-db               upd"
"ate export database\012       -repository              print path used for egg inst"
"allation\012       -deploy                  build extensions for deployment\012       "
"-trunk                   build trunk instead of tagged version (only local)\012  -D"
"   -feature FEATURE         features to pass to sub-invocations of `csc\047\012       "
"-debug                   enable full display of error message information\012      "
" -keep-going              continue installation even if dependency fails\012       "
"-scan DIRECTORY          scan local directory for highest available egg versions"
"\012       -override FILENAME       override versions for installed eggs with infor"
"mation from file\012       -csi FILENAME            use given pathname for invocati"
"ons of \042csi\042\012       -show-depends            display a list of egg dependencies "
"for the given egg(s)\012       -show-foreign-depends    display a list of foreign d"
"ependencies for the given egg(s)\012\012chicken-install recognizes the SUDO, http_prox"
"y and proxy_auth environment variables, if set.\012");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\013-repository");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\006-force");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\005-keep");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\005-sudo");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\002-r");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\011-retrieve");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\011-location");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\002-t");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\012-transport");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\007-prefix");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\002-n");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-install");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\002-u");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\012-update-db");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\002-i");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\005-init");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\004copy");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\010~a ~a ~a");
lf[407]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014setup-api.so\376\003\000\000\002\376B\000\000\023setup-api.import.so\376\003\000\000\002\376B\000\000\021setup-download.so\376\003"
"\000\000\002\376B\000\000\030setup-download.import.so\376\003\000\000\002\376B\000\000\021chicken.import.so\376\003\000\000\002\376B\000\000\021lolevel.imp"
"ort.so\376\003\000\000\002\376B\000\000\020srfi-1.import.so\376\003\000\000\002\376B\000\000\020srfi-4.import.so\376\003\000\000\002\376B\000\000\031data-structu"
"res.import.so\376\003\000\000\002\376B\000\000\017ports.import.so\376\003\000\000\002\376B\000\000\017files.import.so\376\003\000\000\002\376B\000\000\017posix.i"
"mport.so\376\003\000\000\002\376B\000\000\021srfi-13.import.so\376\003\000\000\002\376B\000\000\021srfi-69.import.so\376\003\000\000\002\376B\000\000\020extras.i"
"mport.so\376\003\000\000\002\376B\000\000\021srfi-14.import.so\376\003\000\000\002\376B\000\000\015tcp.import.so\376\003\000\000\002\376B\000\000\021foreign.impo"
"rt.so\376\003\000\000\002\376B\000\000\021srfi-18.import.so\376\003\000\000\002\376B\000\000\017utils.import.so\376\003\000\000\002\376B\000\000\015csi.import.so"
"\376\003\000\000\002\376B\000\000\021irregex.import.so\376\003\000\000\002\376B\000\000\010types.db\376\377\016");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\032copying required files to ");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[410]=C_h_intern(&lf[410],16,"create-directory");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\006-proxy");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-feature");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\005-test");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\007-target");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\006-debug");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\007-deploy");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\011-username");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\005-scan");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\011-override");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\002-x");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\017-keep-installed");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\012-reinstall");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\006-trunk");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\013-keep-going");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\005-list");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\004-csi");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\011-password");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\015-show-depends");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\025-show-foreign-depends");
lf[433]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000l\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000p\376\003\000\000\002\376\377\012\000\000r\376\003\000"
"\000\002\376\377\012\000\000n\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000D\376\377\016");
lf[434]=C_h_intern(&lf[434],16,"\003sysstring->list");
lf[435]=C_h_intern(&lf[435],9,"substring");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[438]=C_h_intern(&lf[438],18,"pathname-directory");
lf[439]=C_h_intern(&lf[439],18,"pathname-extension");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\012http_proxy");
lf[443]=C_h_intern(&lf[443],7,"irregex");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\014([^:]+):(.+)");
lf[445]=C_h_intern(&lf[445],22,"command-line-arguments");
lf[446]=C_h_intern(&lf[446],17,"register-feature!");
lf[447]=C_h_intern(&lf[447],15,"chicken-install");
lf[448]=C_h_intern(&lf[448],14,"\000cross-chicken");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[451]=C_h_intern(&lf[451],11,"\003sysrequire");
lf[452]=C_h_intern(&lf[452],9,"setup-api");
lf[453]=C_h_intern(&lf[453],14,"setup-download");
C_register_lf2(lf,454,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2367,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* k4082 in k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_4084(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4084,2,av);}
a=C_alloc(5);
t2=((C_word*)t0)[2];
t3=C_i_nullp(t2);
t4=(C_truep(t3)?lf[96]:C_i_car(t2));
t5=t4;
t6=*((C_word*)lf[97]+1);
t7=*((C_word*)lf[97]+1);
t8=C_i_check_port_2(*((C_word*)lf[97]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[98]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4093,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t10=C_eqp(t5,lf[96]);
if(C_truep(t10)){
/* chicken-install.scm:422: ##sys#print */
t11=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t11;
av2[1]=t9;
av2[2]=lf[107];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[97]+1);
((C_proc)(void*)(*((C_word*)t11+1)))(5,av2);}}
else{
t11=C_eqp(t5,lf[108]);
if(C_truep(t11)){
/* chicken-install.scm:422: ##sys#print */
t12=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t12;
av2[1]=t9;
av2[2]=lf[109];
av2[3]=C_SCHEME_FALSE;
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t12+1)))(5,av2);}}
else{
t12=C_SCHEME_UNDEFINED;
/* chicken-install.scm:422: ##sys#print */
t13=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t13;
av2[1]=t9;
av2[2]=t12;
av2[3]=C_SCHEME_FALSE;
av2[4]=t6;
((C_proc)(void*)(*((C_word*)t13+1)))(5,av2);}}}}

/* k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_4081(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4081,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:421: retrieve */
f_4247(t2,((C_word*)t0)[4]);}

/* k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_4348(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_4348,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:464: file-exists? */
t4=C_fast_retrieve(lf[60]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6533 in k6476 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_6535(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_6535,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[40]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6541,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:881: ##sys#print */
t6=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[356];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* a5284 in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in ... */
static void C_ccall f_5285(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5285,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[23],"main#\052deploy\052"));
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[27],"main#\052prefix\052"));
t4=C_mutate2(&lf[23] /* (set! main#*deploy* ...) */,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate2(&lf[27] /* (set! main#*prefix* ...) */,((C_word*)((C_word*)t0)[5])[1]);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* k6539 in k6533 in k6476 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_6541(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_6541,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_length(((C_word*)t0)[5]);
/* chicken-install.scm:881: ##sys#print */
t4=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k6545 in k6542 in k6539 in k6533 in k6476 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_6547(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6547,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6550,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:881: get-output-string */
t3=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6542 in k6539 in k6533 in k6476 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_6544(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_6544,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:881: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[355];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4886 in k4839 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in ... */
static void C_ccall f_4888(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4888,2,av);}
a=C_alloc(5);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[40]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4894,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:558: ##sys#print */
t6=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[299];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k6618 in map-loop1614 in k6561 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_6620(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6620,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6595(t6,((C_word*)t0)[5],t5);}

/* k6548 in k6545 in k6542 in k6539 in k6533 in k6476 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_6550(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6550,2,av);}
/* chicken-install.scm:880: yes-or-no? */
t2=C_fast_retrieve(lf[122]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[125];
av2[4]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k6561 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_6563(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_6563,2,av);}
a=C_alloc(18);
if(C_truep(C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6573,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6593,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6595,a[2]=t5,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_6595(t11,t7,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6630,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:898: print */
t3=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[367];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* a5211 in a5199 in a5175 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in ... */
static void C_ccall f_5212(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,2))){
C_save_and_reclaim((void*)f_5212,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5218,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:638: k1137 */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* a5217 in a5211 in a5199 in a5175 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in ... */
static void C_ccall f_5218(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5218,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k3298 in a3278 in scan in k3236 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_fcall f_3300(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,4))){
C_save_and_reclaim_args((void *)trf_3300,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[2])?C_i_not(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
/* chicken-install.scm:262: scan */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3247(t3,((C_word*)t0)[5],((C_word*)t0)[6],t1,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
/* chicken-install.scm:262: scan */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3247(t4,((C_word*)t0)[5],((C_word*)t0)[6],t1,t3);}}

/* canonical in main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_5958(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,3))){
C_save_and_reclaim_args((void *)trf_5958,2,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5972,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:725: symbol->string */
t4=*((C_word*)lf[204]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
if(C_truep(C_i_stringp(t2))){
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,t2,C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* chicken-install.scm:728: error */
t3=*((C_word*)lf[69]+1);{
C_word av2[4];
av2[0]=t3;
av2[1]=t1;
av2[2]=lf[205];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}}}

/* k5951 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_5953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5953,2,av);}
/* chicken-install.scm:684: make-pathname */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[260];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3326 in k3236 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_3328(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_3328,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* chicken-install.scm:271: ext-version */
f_3111(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3422,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:289: warning */
t3=C_fast_retrieve(lf[74]);{
C_word av2[4];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[75];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_5955(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(21,0,4))){
C_save_and_reclaim_args((void *)trf_5955,2,t1,t2);}
a=C_alloc(21);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5958,tmp=(C_word)a,a+=2,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5992,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6015,a[2]=t1,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6028,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6030,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:733: append-map */
t12=C_fast_retrieve(lf[211]);{
C_word av2[4];
av2[0]=t12;
av2[1]=t10;
av2[2]=t11;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t12+1)))(4,av2);}}

/* k6628 in k6561 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_6630(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6630,2,av);}
/* chicken-install.scm:899: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* loop in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in ... */
static void C_ccall f_4646(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_4646,3,av);}
a=C_alloc(8);
if(C_truep(C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4656,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:512: feature? */
t4=C_fast_retrieve(lf[151]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
if(C_truep(C_i_listp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4681,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=C_i_car(t2);
t5=C_eqp(lf[156],t4);
if(C_truep(t5)){
t6=t2;
t7=C_u_i_cdr(t6);
t8=t3;
f_4681(t8,C_i_pairp(t7));}
else{
t6=t3;
f_4681(t6,C_SCHEME_FALSE);}}
else{
t3=C_i_cadr(((C_word*)t0)[4]);
/* chicken-install.scm:514: error */
t4=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[157];
av2[3]=((C_word*)t0)[5];
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}}

/* k3342 in k3329 in k3326 in k3236 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_3344(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3344,2,av);}
/* chicken-install.scm:273: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}

/* k5970 in canonical in main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_5972(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_5972,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,t1,C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in ... */
static void C_ccall f_4964(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_4964,2,av);}
a=C_alloc(11);
t2=(C_truep(t1)?lf[281]:lf[282]);
t3=t2;
t4=(C_truep(C_retrieve2(lf[5],"main#\052keep\052"))?lf[283]:lf[284]);
t5=t4;
t6=(C_truep(C_retrieve2(lf[10],"main#\052no-install\052"))?(C_truep(((C_word*)t0)[2])?lf[285]:lf[286]):lf[285]);
t7=t6;
t8=(C_truep(C_retrieve2(lf[30],"main#\052host-extension\052"))?lf[287]:lf[288]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4831,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t5,a[8]=t7,a[9]=t9,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* chicken-install.scm:547: get-prefix */
f_2524(t10,C_SCHEME_END_OF_LIST);}

/* k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_fcall f_4979(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_4979,2,t0,t1);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:587: retrieve */
f_4247(t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k3329 in k3326 in k3236 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_3331(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_3331,2,av);}
a=C_alloc(8);
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3411,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cadr(((C_word*)t0)[3]);
/* chicken-install.scm:274: ->string */
t6=C_fast_retrieve(lf[56]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_car(t4);
/* chicken-install.scm:273: ->string */
t6=C_fast_retrieve(lf[56]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* same? in main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_5992(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5992,4,av);}
a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6012,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:730: canonical */
f_5958(t4,t2);}

/* map-loop1050 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in ... */
static void C_fcall f_5467(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_5467,3,t0,t1,t2);}
a=C_alloc(3);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_assoc(t3,C_retrieve2(lf[77],"main#\052eggs+dirs+vers\052"));
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3073 in g412 in k3064 in k3061 in k3055 in k6881 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_3075(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3075,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:217: setup-api#shellpath */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[293]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[293]+1);
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}

/* k3077 in k3073 in g412 in k3064 in k3061 in k3055 in k6881 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_3079(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_3079,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];
t3=C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8132,a[2]=t2,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=t4;
av2[2]=*((C_word*)lf[40]+1);
av2[3]=lf[406];
av2[4]=t3;
C_apply(5,av2);}}

/* k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_4982(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4982,2,av);}
a=C_alloc(7);
if(C_truep(C_retrieve2(lf[9],"main#\052retrieve-only\052"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5503,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:589: topological-sort */
t4=C_fast_retrieve(lf[350]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_retrieve2(lf[78],"main#\052dependencies\052");
av2[3]=*((C_word*)lf[351]+1);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}

/* k3061 in k3055 in k6881 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_3063(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_3063,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:214: print */
t3=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[408];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[409];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3064 in k3061 in k3055 in k6881 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_3066(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_3066,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3088,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3088(t6,((C_word*)t0)[5],lf[407]);}

/* g412 in k3064 in k3061 in k3055 in k6881 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_fcall f_3067(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_3067,3,t0,t1,t2);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3075,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3083,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:217: make-pathname */
t5=C_fast_retrieve(lf[41]);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k7401 in k7398 in k7377 in k7460 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_7403(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_7403,2,av);}
a=C_alloc(6);
t2=((C_word*)t0)[2];
f_7396(t2,C_a_i_list2(&a,2,t1,lf[437]));}

/* k7407 in k7398 in k7377 in k7460 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_7409(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_7409,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_7396(t2,C_a_i_list2(&a,2,((C_word*)t0)[3],lf[437]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7416,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:1061: current-directory */
t3=C_fast_retrieve(lf[93]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7398 in k7377 in k7460 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_7400(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_7400,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7403,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7409,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:1059: absolute-pathname? */
t5=C_fast_retrieve(lf[94]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
/* chicken-install.scm:1062: current-directory */
t4=C_fast_retrieve(lf[93]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_4988(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(19,c,3))){C_save_and_reclaim((void *)f_4988,2,av);}
a=C_alloc(19);
t2=t1;
t3=C_u_i_length(t2);
t4=C_retrieve2(lf[7],"main#\052force\052");
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5000,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5467,a[2]=t7,a[3]=t11,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_5467(t13,t9,t2);}

/* g656 in k3977 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_fcall f_3986(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,2))){
C_save_and_reclaim_args((void *)trf_3986,3,t0,t1,t2);}
a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3990,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3996,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t5=C_i_cadr(t2);
t6=C_u_i_cdr(((C_word*)t0)[2]);
t7=C_i_equalp(t5,t6);
t8=t4;
f_3996(t8,C_i_not(t7));}
else{
t5=t4;
f_3996(t5,C_SCHEME_FALSE);}}

/* k7119 in k7115 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_7121(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7121,2,av);}
t2=C_mutate2(&lf[34] /* (set! main#*override* ...) */,t1);
t3=C_i_cddr(((C_word*)t0)[2]);
/* chicken-install.scm:1010: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6383(t4,((C_word*)t0)[4],t3,((C_word*)((C_word*)t0)[5])[1]);}

/* k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in ... */
static void C_fcall f_6651(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_6651,2,t0,t1);}
a=C_alloc(10);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8111,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:801: print */
t4=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
if(C_truep(C_u_i_string_equal_p(((C_word*)t0)[3],lf[383]))){
t2=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[5];
t4=C_u_i_cdr(t3);
/* chicken-install.scm:926: loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_6383(t5,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(((C_word*)t0)[3],lf[384]))){
t2=lf[7] /* main#*force* */ =C_SCHEME_TRUE;;
t3=((C_word*)t0)[5];
t4=C_u_i_cdr(t3);
/* chicken-install.scm:929: loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_6383(t5,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[7])[1]);}
else{
t2=C_u_i_string_equal_p(((C_word*)t0)[3],lf[385]);
t3=(C_truep(t2)?t2:C_u_i_string_equal_p(((C_word*)t0)[3],lf[386]));
if(C_truep(t3)){
t4=lf[5] /* main#*keep* */ =C_SCHEME_TRUE;;
t5=((C_word*)t0)[5];
t6=C_u_i_cdr(t5);
/* chicken-install.scm:932: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_6383(t7,((C_word*)t0)[2],t6,((C_word*)((C_word*)t0)[7])[1]);}
else{
t4=C_u_i_string_equal_p(((C_word*)t0)[3],lf[387]);
t5=(C_truep(t4)?t4:C_u_i_string_equal_p(((C_word*)t0)[3],lf[388]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6701,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:934: setup-api#sudo-install */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[309]);
C_word av2[3];
av2[0]=*((C_word*)lf[309]+1);
av2[1]=t6;
av2[2]=C_SCHEME_TRUE;
tp(3,av2);}}
else{
t6=C_u_i_string_equal_p(((C_word*)t0)[3],lf[389]);
t7=(C_truep(t6)?t6:C_u_i_string_equal_p(((C_word*)t0)[3],lf[390]));
if(C_truep(t7)){
t8=lf[9] /* main#*retrieve-only* */ =C_SCHEME_TRUE;;
t9=((C_word*)t0)[5];
t10=C_u_i_cdr(t9);
/* chicken-install.scm:938: loop */
t11=((C_word*)((C_word*)t0)[6])[1];
f_6383(t11,((C_word*)t0)[2],t10,((C_word*)((C_word*)t0)[7])[1]);}
else{
t8=C_u_i_string_equal_p(((C_word*)t0)[3],lf[391]);
t9=(C_truep(t8)?t8:C_u_i_string_equal_p(((C_word*)t0)[3],lf[392]));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6731,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t11=((C_word*)t0)[5];
t12=C_u_i_cdr(t11);
if(C_truep(C_i_pairp(t12))){
t13=t10;{
C_word av2[2];
av2[0]=t13;
av2[1]=C_SCHEME_UNDEFINED;
f_6731(2,av2);}}
else{
t13=t10;
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8116,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:801: print */
t15=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t15;
av2[1]=t14;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t15+1)))(3,av2);}}}
else{
t10=C_u_i_string_equal_p(((C_word*)t0)[3],lf[393]);
t11=(C_truep(t10)?t10:C_u_i_string_equal_p(((C_word*)t0)[3],lf[394]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6760,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t13=((C_word*)t0)[5];
t14=C_u_i_cdr(t13);
if(C_truep(C_i_pairp(t14))){
t15=t12;{
C_word av2[2];
av2[0]=t15;
av2[1]=C_SCHEME_UNDEFINED;
f_6760(2,av2);}}
else{
t15=t12;
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8121,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:801: print */
t17=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t17;
av2[1]=t16;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t17+1)))(3,av2);}}}
else{
t12=C_u_i_string_equal_p(((C_word*)t0)[3],lf[395]);
t13=(C_truep(t12)?t12:C_u_i_string_equal_p(((C_word*)t0)[3],lf[396]));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6793,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t15=((C_word*)t0)[5];
t16=C_u_i_cdr(t15);
if(C_truep(C_i_pairp(t16))){
t17=t14;{
C_word av2[2];
av2[0]=t17;
av2[1]=C_SCHEME_UNDEFINED;
f_6793(2,av2);}}
else{
t17=t14;
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8126,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:801: print */
t19=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t19;
av2[1]=t18;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t19+1)))(3,av2);}}}
else{
t14=C_u_i_string_equal_p(((C_word*)t0)[3],lf[397]);
t15=(C_truep(t14)?t14:C_u_i_string_equal_p(((C_word*)t0)[3],lf[398]));
if(C_truep(t15)){
t16=lf[5] /* main#*keep* */ =C_SCHEME_TRUE;;
t17=lf[10] /* main#*no-install* */ =C_SCHEME_TRUE;;
t18=((C_word*)t0)[5];
t19=C_u_i_cdr(t18);
/* chicken-install.scm:959: loop */
t20=((C_word*)((C_word*)t0)[6])[1];
f_6383(t20,((C_word*)t0)[2],t19,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(((C_word*)t0)[3],lf[399]))){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6851,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6858,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:961: chicken-version */
t18=C_fast_retrieve(lf[54]);{
C_word av2[2];
av2[0]=t18;
av2[1]=t17;
((C_proc)(void*)(*((C_word*)t18+1)))(2,av2);}}
else{
t16=C_u_i_string_equal_p(((C_word*)t0)[3],lf[400]);
t17=(C_truep(t16)?t16:C_u_i_string_equal_p(((C_word*)t0)[3],lf[401]));
if(C_truep(t17)){
t18=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_TRUE);
t19=((C_word*)t0)[5];
t20=C_u_i_cdr(t19);
/* chicken-install.scm:965: loop */
t21=((C_word*)((C_word*)t0)[6])[1];
f_6383(t21,((C_word*)t0)[2],t20,((C_word*)((C_word*)t0)[7])[1]);}
else{
t18=C_u_i_string_equal_p(((C_word*)t0)[3],lf[402]);
t19=(C_truep(t18)?t18:C_u_i_string_equal_p(((C_word*)t0)[3],lf[403]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t21=((C_word*)t0)[5];
t22=C_u_i_cdr(t21);
if(C_truep(C_i_pairp(t22))){
t23=t20;{
C_word av2[2];
av2[0]=t23;
av2[1]=C_SCHEME_UNDEFINED;
f_6883(2,av2);}}
else{
t23=t20;
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8139,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:801: print */
t25=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t25;
av2[1]=t24;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t25+1)))(3,av2);}}}
else{
if(C_truep(C_u_i_string_equal_p(lf[411],((C_word*)t0)[3]))){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6909,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t21=((C_word*)t0)[5];
t22=C_u_i_cdr(t21);
if(C_truep(C_i_pairp(t22))){
t23=t20;{
C_word av2[2];
av2[0]=t23;
av2[1]=C_SCHEME_UNDEFINED;
f_6909(2,av2);}}
else{
t23=t20;
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8144,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:801: print */
t25=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t25;
av2[1]=t24;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t25+1)))(3,av2);}}}
else{
t20=C_u_i_string_equal_p(lf[412],((C_word*)t0)[3]);
t21=(C_truep(t20)?t20:C_u_i_string_equal_p(lf[413],((C_word*)t0)[3]));
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6942,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t23=((C_word*)t0)[5];
t24=C_u_i_cdr(t23);
if(C_truep(C_i_pairp(t24))){
t25=t22;{
C_word av2[2];
av2[0]=t25;
av2[1]=C_SCHEME_UNDEFINED;
f_6942(2,av2);}}
else{
t25=t22;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8149,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:801: print */
t27=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t27;
av2[1]=t26;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t27+1)))(3,av2);}}}
else{
if(C_truep(C_u_i_string_equal_p(lf[414],((C_word*)t0)[3]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6976,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t23=((C_word*)t0)[5];
t24=C_u_i_cdr(t23);
if(C_truep(C_i_pairp(t24))){
t25=t22;{
C_word av2[2];
av2[0]=t25;
av2[1]=C_SCHEME_UNDEFINED;
f_6976(2,av2);}}
else{
t25=t22;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8154,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:801: print */
t27=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t27;
av2[1]=t26;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t27+1)))(3,av2);}}}
else{
if(C_truep(C_u_i_string_equal_p(lf[415],((C_word*)t0)[3]))){
t22=lf[8] /* main#*run-tests* */ =C_SCHEME_TRUE;;
t23=((C_word*)t0)[5];
t24=C_u_i_cdr(t23);
/* chicken-install.scm:986: loop */
t25=((C_word*)((C_word*)t0)[6])[1];
f_6383(t25,((C_word*)t0)[2],t24,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[416],((C_word*)t0)[3]))){
t22=lf[31] /* main#*target-extension* */ =C_SCHEME_FALSE;;
t23=((C_word*)t0)[5];
t24=C_u_i_cdr(t23);
/* chicken-install.scm:989: loop */
t25=((C_word*)((C_word*)t0)[6])[1];
f_6383(t25,((C_word*)t0)[2],t24,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[417],((C_word*)t0)[3]))){
t22=lf[30] /* main#*host-extension* */ =C_SCHEME_FALSE;;
t23=((C_word*)t0)[5];
t24=C_u_i_cdr(t23);
/* chicken-install.scm:992: loop */
t25=((C_word*)((C_word*)t0)[6])[1];
f_6383(t25,((C_word*)t0)[2],t24,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[418],((C_word*)t0)[3]))){
t22=lf[32] /* main#*debug-setup* */ =C_SCHEME_TRUE;;
t23=((C_word*)t0)[5];
t24=C_u_i_cdr(t23);
/* chicken-install.scm:995: loop */
t25=((C_word*)((C_word*)t0)[6])[1];
f_6383(t25,((C_word*)t0)[2],t24,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[419],((C_word*)t0)[3]))){
t22=lf[23] /* main#*deploy* */ =C_SCHEME_TRUE;;
t23=((C_word*)t0)[5];
t24=C_u_i_cdr(t23);
/* chicken-install.scm:998: loop */
t25=((C_word*)((C_word*)t0)[6])[1];
f_6383(t25,((C_word*)t0)[2],t24,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[420],((C_word*)t0)[3]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7065,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t23=((C_word*)t0)[5];
t24=C_u_i_cdr(t23);
if(C_truep(C_i_pairp(t24))){
t25=t22;{
C_word av2[2];
av2[0]=t25;
av2[1]=C_SCHEME_UNDEFINED;
f_7065(2,av2);}}
else{
t25=t22;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8159,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:801: print */
t27=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t27;
av2[1]=t26;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t27+1)))(3,av2);}}}
else{
if(C_truep(C_u_i_string_equal_p(lf[421],((C_word*)t0)[3]))){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7091,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t23=((C_word*)t0)[5];
t24=C_u_i_cdr(t23);
if(C_truep(C_i_pairp(t24))){
t25=t22;{
C_word av2[2];
av2[0]=t25;
av2[1]=C_SCHEME_UNDEFINED;
f_7091(2,av2);}}
else{
t25=t22;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8164,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:801: print */
t27=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t27;
av2[1]=t26;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t27+1)))(3,av2);}}}
else{
if(C_truep(C_u_i_string_equal_p(lf[422],((C_word*)t0)[3]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7117,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t23=((C_word*)t0)[5];
t24=C_u_i_cdr(t23);
if(C_truep(C_i_pairp(t24))){
t25=t22;{
C_word av2[2];
av2[0]=t25;
av2[1]=C_SCHEME_UNDEFINED;
f_7117(2,av2);}}
else{
t25=t22;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8169,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:801: print */
t27=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t27;
av2[1]=t26;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t27+1)))(3,av2);}}}
else{
t22=C_u_i_string_equal_p(lf[423],((C_word*)t0)[3]);
t23=(C_truep(t22)?t22:C_u_i_string_equal_p(lf[424],((C_word*)t0)[3]));
if(C_truep(t23)){
t24=lf[6] /* main#*keep-existing* */ =C_SCHEME_TRUE;;
t25=((C_word*)t0)[5];
t26=C_u_i_cdr(t25);
/* chicken-install.scm:1013: loop */
t27=((C_word*)((C_word*)t0)[6])[1];
f_6383(t27,((C_word*)t0)[2],t26,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[425],((C_word*)t0)[3]))){
t24=lf[35] /* main#*reinstall* */ =C_SCHEME_TRUE;;
t25=((C_word*)t0)[5];
t26=C_u_i_cdr(t25);
/* chicken-install.scm:1016: loop */
t27=((C_word*)((C_word*)t0)[6])[1];
f_6383(t27,((C_word*)t0)[2],t26,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[426],((C_word*)t0)[3]))){
t24=lf[24] /* main#*trunk* */ =C_SCHEME_TRUE;;
t25=((C_word*)t0)[5];
t26=C_u_i_cdr(t25);
/* chicken-install.scm:1019: loop */
t27=((C_word*)((C_word*)t0)[6])[1];
f_6383(t27,((C_word*)t0)[2],t26,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[427],((C_word*)t0)[3]))){
t24=lf[33] /* main#*keep-going* */ =C_SCHEME_TRUE;;
t25=((C_word*)t0)[5];
t26=C_u_i_cdr(t25);
/* chicken-install.scm:1022: loop */
t27=((C_word*)((C_word*)t0)[6])[1];
f_6383(t27,((C_word*)t0)[2],t26,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[428],((C_word*)t0)[3]))){
t24=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t25=((C_word*)t0)[5];
t26=C_u_i_cdr(t25);
/* chicken-install.scm:1025: loop */
t27=((C_word*)((C_word*)t0)[6])[1];
f_6383(t27,((C_word*)t0)[2],t26,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[429],((C_word*)t0)[3]))){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7206,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t25=((C_word*)t0)[5];
t26=C_u_i_cdr(t25);
if(C_truep(C_i_pairp(t26))){
t27=t24;{
C_word av2[2];
av2[0]=t27;
av2[1]=C_SCHEME_UNDEFINED;
f_7206(2,av2);}}
else{
t27=t24;
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8174,a[2]=t27,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:801: print */
t29=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t29;
av2[1]=t28;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t29+1)))(3,av2);}}}
else{
if(C_truep(C_u_i_string_equal_p(lf[430],((C_word*)t0)[3]))){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7232,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t25=((C_word*)t0)[5];
t26=C_u_i_cdr(t25);
if(C_truep(C_i_pairp(t26))){
t27=t24;{
C_word av2[2];
av2[0]=t27;
av2[1]=C_SCHEME_UNDEFINED;
f_7232(2,av2);}}
else{
t27=t24;
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8179,a[2]=t27,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:801: print */
t29=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t29;
av2[1]=t28;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t29+1)))(3,av2);}}}
else{
if(C_truep(C_u_i_string_equal_p(lf[431],((C_word*)t0)[3]))){
t24=lf[36] /* main#*show-depends* */ =C_SCHEME_TRUE;;
t25=((C_word*)t0)[5];
t26=C_u_i_cdr(t25);
/* chicken-install.scm:1036: loop */
t27=((C_word*)((C_word*)t0)[6])[1];
f_6383(t27,((C_word*)t0)[2],t26,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep(C_u_i_string_equal_p(lf[432],((C_word*)t0)[3]))){
t24=lf[37] /* main#*show-foreign-depends* */ =C_SCHEME_TRUE;;
t25=((C_word*)t0)[5];
t26=C_u_i_cdr(t25);
/* chicken-install.scm:1039: loop */
t27=((C_word*)((C_word*)t0)[6])[1];
f_6383(t27,((C_word*)t0)[2],t26,((C_word*)((C_word*)t0)[7])[1]);}
else{
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7278,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t25=C_block_size(((C_word*)t0)[3]);
if(C_truep(C_fixnum_greaterp(t25,C_fix(0)))){
t26=C_i_string_ref(((C_word*)t0)[3],C_fix(0));
t27=t24;
f_7278(t27,C_u_i_char_equalp(C_make_character(45),t26));}
else{
t26=t24;
f_7278(t26,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* g1786 in k7420 in k7460 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_fcall f_7426(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_7426,3,t0,t1,t2);}
a=C_alloc(7);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7442,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:1071: irregex-match-substring */
t6=C_fast_retrieve(lf[226]);{
C_word av2[4];
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
av2[3]=C_fix(1);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* fail in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in ... */
static void C_fcall f_4624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,3))){
C_save_and_reclaim_args((void *)trf_4624,2,t0,t1);}
/* chicken-install.scm:507: error */
t2=*((C_word*)lf[69]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[149];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k7420 in k7460 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_7422(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_7422,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:919: g1786 */
t3=t2;
f_7426(t3,((C_word*)t0)[5],t1);}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1]);
/* chicken-install.scm:1074: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_6383(t5,((C_word*)t0)[5],t3,t4);}}

/* k5640 in for-each-loop1379 in a5617 in k5597 in k5594 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in ... */
static void C_ccall f_5642(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5642,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5632(t3,((C_word*)t0)[4],t2);}

/* for-each-loop1379 in a5617 in k5597 in k5594 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in ... */
static void C_fcall f_5632(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_5632,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5642,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5624,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:719: write */
t7=*((C_word*)lf[237]+1);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k7444 in k7440 in g1786 in k7420 in k7460 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_7446(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_7446,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1),((C_word*)((C_word*)t0)[3])[1]);
/* chicken-install.scm:1068: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6383(t3,((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* k7440 in g1786 in k7420 in k7460 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_7442(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_7442,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7446,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:1072: irregex-match-substring */
t4=C_fast_retrieve(lf[226]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[6];
av2[3]=C_fix(2);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3977 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_3979(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_3979,2,av);}
a=C_alloc(4);
t2=t1;
t3=C_i_assq(t2,C_retrieve2(lf[34],"main#\052override\052"));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3986,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:404: g656 */
t5=t4;
f_3986(t5,((C_word*)t0)[3],t3);}
else{
t4=C_i_pairp(((C_word*)t0)[2]);
t5=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=(C_truep(t4)?C_u_i_cdr(((C_word*)t0)[2]):C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k4654 in loop in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_4656(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4656,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
/* chicken-install.scm:512: fail */
t2=((C_word*)t0)[3];
f_4624(t2,((C_word*)t0)[2]);}}

/* k3963 in a3869 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in ... */
static void C_ccall f_3965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_3965,2,av);}
a=C_alloc(5);
t2=C_i_assq(t1,C_retrieve2(lf[34],"main#\052override\052"));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3878,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:386: g625 */
t4=t3;
f_3878(t4,((C_word*)t0)[3],t2);}
else{
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[2];
t7=C_u_i_car(t6);
/* chicken-install.scm:397: extension-information */
t8=C_fast_retrieve(lf[141]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t5;
av2[2]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}}

/* k3994 in g656 in k3977 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in ... */
static void C_fcall f_3996(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_3996,2,t0,t1);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:410: open-output-string */
t3=C_fast_retrieve(lf[45]);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
/* chicken-install.scm:414: print */
t2=*((C_word*)lf[83]+1);{
C_word av2[4];
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[200];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* k3988 in g656 in k3977 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in ... */
static void C_ccall f_3990(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3990,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_cadr(((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k4606 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_4608(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4608,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4598(t3,((C_word*)t0)[4],t2);}

/* k7115 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_7117(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_7117,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:1009: read-file */
t4=C_fast_retrieve(lf[362]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k4708 in k4679 in loop in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_4710(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4710,2,av);}
if(C_truep(t1)){
/* chicken-install.scm:518: fail */
t2=((C_word*)t0)[2];
f_4624(t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a6092 in a6029 in main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_6093(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_6093,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(t2);
/* chicken-install.scm:735: find */
t5=C_fast_retrieve(lf[210]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* a6098 in a6092 in a6029 in main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_6099(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6099,3,av);}
/* chicken-install.scm:735: g1428 */
t3=((C_word*)((C_word*)t0)[2])[1];{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
f_5992(4,av2);}}

/* for-each-loop1466 in k6128 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_fcall f_6138(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_6138,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6148,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=C_i_car(t4);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6127,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:748: cadadr */
t9=*((C_word*)lf[262]+1);{
C_word av2[3];
av2[0]=t9;
av2[1]=t8;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6128 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_6130(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_6130,2,av);}
a=C_alloc(5);
t2=C_i_check_list_2(t1,lf[99]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6138,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6138(t6,((C_word*)t0)[2],t1);}

/* k4474 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_4476(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4476,2,av);}
/* chicken-install.scm:482: print */
t2=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[144];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4732 in k4679 in loop in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_4734(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4734,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
/* chicken-install.scm:520: fail */
t2=((C_word*)t0)[3];
f_4624(t2,((C_word*)t0)[2]);}}

/* k6146 in for-each-loop1466 in k6128 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_6148(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6148,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6138(t3,((C_word*)t0)[4],t2);}

/* k4461 in k4457 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in ... */
static void C_ccall f_4463(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_4463,2,av);}
/* chicken-install.scm:486: yes-or-no? */
t2=C_fast_retrieve(lf[122]);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[123];
av2[4]=lf[124];
av2[5]=lf[125];
av2[6]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* k4467 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_4469(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4469,2,av);}
/* chicken-install.scm:483: retrieve */
f_4247(((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);}

/* k6076 in map-loop1435 in k6032 in a6029 in main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_6078(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6078,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6053(t6,((C_word*)t0)[5],t5);}

/* k5622 in for-each-loop1379 in a5617 in k5597 in k5594 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in ... */
static void C_ccall f_5624(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5624,2,av);}
/* chicken-install.scm:719: newline */
t2=*((C_word*)lf[235]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3096 in for-each-loop411 in k3064 in k3061 in k3055 in k6881 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_3098(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3098,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3088(t3,((C_word*)t0)[4],t2);}

/* map-loop1435 in k6032 in a6029 in main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_fcall f_6053(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_6053,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6078,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:737: g1441 */
t5=((C_word*)t0)[4];{
C_word av2[3];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a5617 in k5597 in k5594 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in ... */
static void C_ccall f_5618(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5618,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5632,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5632(t5,t1,((C_word*)t0)[2]);}

/* k5614 in k5600 in k5597 in k5594 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in ... */
static void C_ccall f_5616(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5616,2,av);}
/* chicken-install.scm:720: make-pathname */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_retrieve2(lf[0],"main#constant159");
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4531 in map-loop829 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_fcall f_4533(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_4533,2,t0,t1);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4508(t6,((C_word*)t0)[5],t5);}

/* k5610 in k5600 in k5597 in k5594 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in ... */
static void C_ccall f_5612(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5612,2,av);}
/* chicken-install.scm:720: setup-api#copy-file */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[236]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[236]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
tp(4,av2);}}

/* k3081 in g412 in k3064 in k3061 in k3055 in k6881 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_3083(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3083,2,av);}
/* chicken-install.scm:217: setup-api#shellpath */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[293]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[293]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* for-each-loop411 in k3064 in k3061 in k3055 in k6881 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_fcall f_3088(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_3088,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3098,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:215: g412 */
t5=((C_word*)t0)[3];
f_3067(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k6026 in main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_6028(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6028,2,av);}
/* chicken-install.scm:732: delete-duplicates */
t2=C_fast_retrieve(lf[209]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6019 in k6013 in main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_6021(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_6021,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
/* chicken-install.scm:742: print */
t2=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[4];
av2[2]=lf[206];
av2[3]=((C_word*)t0)[5];
av2[4]=lf[207];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(6,av2);}}}

/* k5603 in k5600 in k5597 in k5594 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in ... */
static void C_ccall f_5605(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5605,2,av);}
/* chicken-install.scm:721: setup-api#remove-directory */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[202]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[202]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}

/* k5600 in k5597 in k5594 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in ... */
static void C_ccall f_5602(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_5602,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5605,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5612,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5616,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:720: repo-path */
f_2457(t4);}

/* k5091 in k5075 in k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in ... */
static void C_ccall f_5093(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5093,2,av);}
/* chicken-install.scm:651: g1168 */
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* a6029 in main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_6030(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_6030,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6034,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6093,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:735: find */
t5=C_fast_retrieve(lf[210]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=C_retrieve2(lf[22],"main#\052mappings\052");
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_fcall f_7278(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_7278,2,t0,t1);}
a=C_alloc(9);
if(C_truep(t1)){
t2=C_block_size(((C_word*)t0)[2]);
if(C_truep(C_fixnum_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7287,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7361,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1043: substring */
t5=*((C_word*)lf[435]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[2];
av2[3]=C_fix(1);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8191,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:801: print */
t5=*((C_word*)lf[83]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7462,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm:1051: pathname-extension */
t3=C_fast_retrieve(lf[439]);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* k6032 in a6029 in main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_6034(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_6034,2,av);}
a=C_alloc(13);
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=t1;
t4=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t6)[1];
t8=C_fast_retrieve(lf[56]);
t9=C_i_cdr(t3);
t10=C_i_check_list_2(t9,lf[114]);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6053,a[2]=t6,a[3]=t12,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_6053(t14,t2,t9);}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_list1(&a,1,((C_word*)t0)[3]);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k7285 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_7287(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_7287,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7353,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:1044: every */
t5=C_fast_retrieve(lf[153]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k5665 in a5658 in k5655 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in ... */
static void C_ccall f_5667(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5667,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5671,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[3]);
/* chicken-install.scm:715: symbol->string */
t5=*((C_word*)lf[204]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6125 in for-each-loop1466 in k6128 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_6127(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_6127,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* chicken-install.scm:748: pp */
t3=C_fast_retrieve(lf[261]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* a5097 in k5075 in k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in ... */
static void C_ccall f_5098(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_5098,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5104,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5122,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:651: with-exception-handler */
t5=C_fast_retrieve(lf[190]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k6016 in k6013 in main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_6018(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6018,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k7291 in k7285 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_7293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(21,c,3))){C_save_and_reclaim((void *)f_7293,2,av);}
a=C_alloc(21);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7312,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7316,a[2]=t5,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_7316(t11,t7,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8186,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:801: print */
t4=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[382];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k6010 in same? in main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_6012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6012,2,av);}
a=C_alloc(4);
t2=C_i_car(t1);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6008,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:730: canonical */
f_5958(t4,((C_word*)t0)[4]);}

/* k6013 in main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_6015(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_6015,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6018,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6021,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:741: lset= */
t5=C_fast_retrieve(lf[208]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
av2[3]=((C_word*)t0)[3];
av2[4]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k5655 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_5657(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(2,c,4))){C_save_and_reclaim((void *)f_5657,2,av);}
a=C_alloc(2);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5659,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:703: sort */
t3=C_fast_retrieve(lf[240]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a5658 in k5655 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in ... */
static void C_ccall f_5659(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5659,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5667,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(t2);
/* chicken-install.scm:715: symbol->string */
t6=*((C_word*)lf[204]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k5087 in k5075 in k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in ... */
static void C_ccall f_5089(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5089,2,av);}
t2=lf[21] /* main#*running-test* */ =C_SCHEME_FALSE;;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k6884 in k6881 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_6886(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6886,2,av);}
/* chicken-install.scm:969: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6881 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_6883(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_6883,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6886,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
t4=t2;
t5=t3;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3057,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:209: repo-path */
f_2457(t6);}

/* tmp1127 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in ... */
static void C_fcall f_5060(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_5060,2,t0,t1);}
/* chicken-install.scm:643: $system */
f_6161(t1,((C_word*)t0)[2]);}

/* k6280 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_6282(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_6282,2,av);}
/* chicken-install.scm:779: make-pathname */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[363];
av2[4]=lf[364];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* a5895 in a5875 in a5838 in k5829 in k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in ... */
static void C_ccall f_5896(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,2))){
C_save_and_reclaim((void*)f_5896,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5902,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:691: k1272 */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* main#resolve-location in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_2970(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_2970,2,t1,t2);}
t3=C_i_assoc(t2,C_retrieve2(lf[28],"main#\052aliases\052"));
if(C_truep(t3)){
t4=t1;
t5=C_i_cdr(t3);
/* chicken-install.scm:190: resolve-location */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
t4=t2;
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k5892 in a5881 in a5875 in a5838 in k5829 in k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in ... */
static void C_ccall f_5894(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5894,2,av);}
a=C_alloc(6);
t2=C_a_i_list(&a,2,lf[251],t1);
/* chicken-install.scm:699: eval */
t3=C_fast_retrieve(lf[252]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* tmp1154 in k5075 in k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in ... */
static void C_fcall f_5078(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,0,4))){
C_save_and_reclaim_args((void *)trf_5078,2,t0,t1);}
a=C_alloc(12);
t2=C_i_caddr(((C_word*)t0)[2]);
t3=t1;
t4=C_a_i_list(&a,3,C_retrieve2(lf[80],"main#\052csi\052"),((C_word*)t0)[3],t2);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f8076,a[2]=t3,tmp=(C_word)a,a+=3,tmp);{
C_word av2[5];
av2[0]=0;
av2[1]=t5;
av2[2]=*((C_word*)lf[40]+1);
av2[3]=lf[268];
av2[4]=t4;
C_apply(5,av2);}}

/* k5075 in k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in ... */
static void C_ccall f_5077(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_5077,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5089,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[33],"main#\052keep-going\052"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5093,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5098,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:651: call-with-current-continuation */
t6=*((C_word*)lf[191]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
/* chicken-install.scm:651: tmp1154 */
t4=t2;
f_5078(t4,t3);}}

/* k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in ... */
static void C_ccall f_5073(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5073,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=lf[21] /* main#*running-test* */ =C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:650: current-directory */
t4=C_fast_retrieve(lf[93]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[273];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in ... */
static void C_ccall f_5051(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_5051,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5055,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[29],"main#\052cross-chicken\052"))){
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5527,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:670: print* */
t5=*((C_word*)lf[244]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[329];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_5055(2,av2);}}}

/* k7560 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_7562(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_7562,2,av);}
/* chicken-install.scm:1085: cleanup */
f_5559(((C_word*)t0)[2]);}

/* k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_7569(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_7569,2,av);}
a=C_alloc(16);
t2=((C_word*)t0)[2];
t3=t1;
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6375,a[2]=t11,a[3]=t5,a[4]=t7,a[5]=t9,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm:863: irregex */
t13=C_fast_retrieve(lf[443]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t13;
av2[1]=t12;
av2[2]=lf[444];
((C_proc)(void*)(*((C_word*)t13+1)))(3,av2);}}

/* a6289 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_6290(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,15))){C_save_and_reclaim((void *)f_6290,5,av);}
if(C_truep(t2)){
/* chicken-install.scm:786: setup-download#list-extensions */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[265]);
C_word *av2;
if(c >= 16) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(16);
}
av2[0]=*((C_word*)lf[265]+1);
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
av2[4]=lf[266];
av2[5]=C_SCHEME_TRUE;
av2[6]=lf[183];
av2[7]=C_retrieve2(lf[11],"main#\052username\052");
av2[8]=lf[184];
av2[9]=C_retrieve2(lf[12],"main#\052password\052");
av2[10]=lf[186];
av2[11]=C_retrieve2(lf[18],"main#\052proxy-host\052");
av2[12]=lf[187];
av2[13]=C_retrieve2(lf[19],"main#\052proxy-port\052");
av2[14]=lf[188];
av2[15]=C_retrieve2(lf[20],"main#\052proxy-user-pass\052");
tp(16,av2);}}
else{
/* chicken-install.scm:794: next */
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t1;
((C_proc)C_fast_retrieve_proc(t5))(2,av2);}}}

/* k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_2964(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_2964,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2577,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2934,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:182: read-file */
t4=C_fast_retrieve(lf[362]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_pairp(C_retrieve2(lf[13],"main#\052default-sources\052"));
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a5881 in a5875 in a5838 in k5829 in k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in ... */
static void C_ccall f_5882(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5882,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5894,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:699: string->symbol */
t3=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2966 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_2968(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2968,2,av);}
/* chicken-install.scm:131: make-pathname */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_retrieve2(lf[2],"main#constant163");
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in ... */
static void C_ccall f_5067(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_5067,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[8],"main#\052run-tests\052"))){
if(C_truep(((C_word*)t0)[5])){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_5073(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5159,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:646: file-exists? */
t4=C_fast_retrieve(lf[60]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[277];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_5073(2,av2);}}}

/* k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in ... */
static void C_ccall f_5040(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_5040,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5045,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5242,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:632: dynamic-wind */
t6=C_fast_retrieve(lf[330]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=((C_word*)t0)[6];
av2[2]=t3;
av2[3]=t4;
av2[4]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* a7532 in a7526 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_7533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_7533,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7537,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:1080: newline */
t3=*((C_word*)lf[235]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=*((C_word*)lf[87]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k7535 in a7532 in a7526 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_7537(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_7537,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7540,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1081: print-error-message */
t3=C_fast_retrieve(lf[172]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=*((C_word*)lf[87]+1);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k6261 in k6268 in a6223 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_6263(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6263,2,av);}
/* chicken-install.scm:775: warning */
t2=C_fast_retrieve(lf[74]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[360];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a5875 in a5838 in k5829 in k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in ... */
static void C_ccall f_5876(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5876,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5882,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5896,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:691: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* k5872 in k5869 in k5866 in k5863 in k5857 in a5850 in a5844 in a5838 in k5829 in k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in ... */
static void C_ccall f_5874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5874,2,av);}
/* chicken-install.scm:696: print-error-message */
t2=C_fast_retrieve(lf[172]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=*((C_word*)lf[87]+1);
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k5869 in k5866 in k5863 in k5857 in a5850 in a5844 in a5838 in k5829 in k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in ... */
static void C_ccall f_5871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5871,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:698: get-output-string */
t3=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in ... */
static void C_ccall f_5058(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_5058,2,av);}
a=C_alloc(16);
t2=t1;
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5060,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5067,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[33],"main#\052keep-going\052"))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5171,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5176,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:638: call-with-current-continuation */
t9=*((C_word*)lf[191]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t7;
av2[2]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}
else{
/* chicken-install.scm:638: tmp1127 */
t7=t5;
f_5060(t7,t6);}}

/* k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in ... */
static void C_ccall f_5055(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_5055,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[2]);
t4=C_i_caddr(((C_word*)t0)[2]);
t5=C_i_greaterp(((C_word*)t0)[5],C_fix(1));
t6=t2;
t7=t3;
t8=t4;
t9=t5;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4782,a[2]=t9,a[3]=t6,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t11=C_retrieve2(lf[23],"main#\052deploy\052");
if(C_truep(C_retrieve2(lf[23],"main#\052deploy\052"))){
t12=C_retrieve2(lf[23],"main#\052deploy\052");
t13=t10;
f_4782(t13,(C_truep(C_retrieve2(lf[23],"main#\052deploy\052"))?lf[313]:lf[314]));}
else{
if(C_truep(C_retrieve2(lf[29],"main#\052cross-chicken\052"))){
t12=C_retrieve2(lf[30],"main#\052host-extension\052");
t13=t10;
f_4782(t13,(C_truep(C_retrieve2(lf[30],"main#\052host-extension\052"))?lf[314]:lf[313]));}
else{
t12=t10;
f_4782(t12,lf[314]);}}}

/* k2687 in k2684 in g305 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_2689(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2689,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2700,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:162: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[4];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* k2684 in g305 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_2686(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2686,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2689,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2689(2,av2);}}
else{
/* chicken-install.scm:161: broken */
t4=((C_word*)t0)[4];
f_2563(t4,t3,((C_word*)t0)[5]);}}

/* g305 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_fcall f_2682(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,3))){
C_save_and_reclaim_args((void *)trf_2682,3,t0,t1,t2);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2686,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2713,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:160: list-index */
t5=C_fast_retrieve(lf[349]);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k6268 in a6223 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_6270(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_6270,2,av);}
a=C_alloc(6);
t2=C_i_car(t1);
t3=C_i_assq(lf[55],t2);
t4=(C_truep(t3)?C_i_cadr(t3):lf[358]);
t5=t4;
t6=C_i_assq(lf[359],t2);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6241,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:768: g1513 */
t8=t7;
f_6241(t8,((C_word*)t0)[2],t6);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6259,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6263,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:777: pathname-file */
t9=C_fast_retrieve(lf[361]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}

/* k6272 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_6274(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6274,2,av);}
/* chicken-install.scm:767: filter-map */
t2=C_fast_retrieve(lf[143]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k6276 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_6278(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6278,2,av);}
/* chicken-install.scm:779: glob */
t2=C_fast_retrieve(lf[258]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a5044 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in ... */
static void C_ccall f_5045(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5045,2,av);}
/* chicken-install.scm:634: change-directory */
t2=C_fast_retrieve(lf[267]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_7552(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_7552,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7558,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7571,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1078: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_7558(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_7558,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7562,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7569,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1084: command-line-arguments */
t4=C_fast_retrieve(lf[445]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_7521(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_7521,3,av);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7527,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7552,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1078: with-exception-handler */
t5=C_fast_retrieve(lf[190]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* a7526 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_7527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_7527,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7533,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1078: k1791 */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k4551 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in ... */
static void C_ccall f_4553(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4553,2,av);}
/* chicken-install.scm:499: warning */
t2=C_fast_retrieve(lf[74]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_4506(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_4506,2,av);}
a=C_alloc(18);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,C_retrieve2(lf[78],"main#\052dependencies\052"));
t4=C_mutate2(&lf[78] /* (set! main#*dependencies* ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4393,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[6])[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4469,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4476,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:482: string-intersperse */
t8=C_fast_retrieve(lf[119]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=((C_word*)((C_word*)t0)[6])[1];
av2[3]=lf[145];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_4393(2,av2);}}}

/* k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_4500(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_4500,2,av);}
a=C_alloc(14);
t2=C_i_check_list_2(t1,lf[114]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4508,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4508(t7,t3,t1);}

/* k7541 in k7538 in k7535 in a7532 in a7526 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in ... */
static void C_ccall f_7543(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7543,2,av);}
if(C_truep(C_retrieve2(lf[21],"main#\052running-test\052"))){
/* chicken-install.scm:1083: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(2);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
/* chicken-install.scm:1083: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k7538 in k7535 in a7532 in a7526 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in ... */
static void C_ccall f_7540(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_7540,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7543,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1082: cleanup */
f_5559(t2);}

/* map-loop829 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_fcall f_4508(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_4508,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4533,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
if(C_truep(C_i_pairp(t4))){
t5=C_u_i_car(t4);
t6=t3;
f_4533(t6,t5);}
else{
t5=t3;
f_4533(t5,t4);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k7508 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_7510(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_7510,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7513,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1078: g1795 */
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)C_fast_retrieve_proc(t3))(2,av2);}}

/* k7517 in k7511 in k7508 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_7519(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_7519,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* k7511 in k7508 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_7513(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_7513,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7516,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7519,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[234]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[234]+1);
av2[1]=t3;
tp(2,av2);}}

/* k7514 in k7511 in k7508 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_7516(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_7516,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3409 in k3329 in k3326 in k3236 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_3411(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3411,2,av);}
/* chicken-install.scm:274: setup-api#version>=? */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[73]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[73]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
tp(4,av2);}}

/* loop in k3481 in k3469 in a4370 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_fcall f_3488(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,4))){
C_save_and_reclaim_args((void *)trf_3488,5,t0,t1,t2,t3,t4);}
a=C_alloc(9);
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3502,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:301: reverse */
t6=*((C_word*)lf[112]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=C_i_car(t2);
t6=t5;
t7=t2;
t8=C_u_i_cdr(t7);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3515,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3521,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:302: ##sys#call-with-values */{
C_word av2[4];
av2[0]=0;
av2[1]=t1;
av2[2]=t9;
av2[3]=t10;
C_call_with_values(4,av2);}}}

/* k3481 in k3469 in a4370 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_3483(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,5))){C_save_and_reclaim((void *)f_3483,2,av);}
a=C_alloc(5);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3488,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3488(t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k6210 in main#$system in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_6212(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6212,2,av);}
t2=C_eqp(t1,lf[221]);
if(C_truep(t2)){
/* chicken-install.scm:755: get-environment-variable */
t3=C_fast_retrieve(lf[222]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[223];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_6187(2,av2);}}}

/* k3469 in a4370 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_3471(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_3471,2,av);}
a=C_alloc(16);
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3472,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=C_retrieve2(lf[38],"main#\052hacks\052");
t6=C_i_check_list_2(C_retrieve2(lf[38],"main#\052hacks\052"),lf[99]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3483,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3541,a[2]=t9,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_3541(t11,t7,C_retrieve2(lf[38],"main#\052hacks\052"));}

/* g508 in k3469 in a4370 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_fcall f_3472(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_3472,3,t0,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3477,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:297: h */
t4=t2;{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)((C_word*)t0)[2])[1];
((C_proc)C_fast_retrieve_proc(t4))(4,av2);}}

/* k3475 in g508 in k3469 in a4370 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_3477(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3477,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5256 in k5247 in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in ... */
static void C_ccall f_5258(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,4))){C_save_and_reclaim((void *)f_5258,2,av);}
a=C_alloc(16);
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5263,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5274,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:664: ##sys#dynamic-wind */
t9=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t9;
av2[1]=((C_word*)t0)[4];
av2[2]=t6;
av2[3]=t7;
av2[4]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}

/* k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_7507(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_7507,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7510,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7521,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:1078: call-with-current-continuation */
t4=*((C_word*)lf[191]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k7502 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in ... */
static void C_ccall f_7504(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7504,2,av);}
/* chicken-install.scm:864: setup-proxy */
f_6320(((C_word*)t0)[2],t1);}

/* a5205 in a5199 in a5175 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in ... */
static void C_ccall f_5206(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5206,2,av);}
/* chicken-install.scm:638: tmp1127 */
t2=((C_word*)t0)[2];
f_5060(t2,t1);}

/* a5199 in a5175 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in ... */
static void C_ccall f_5200(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5200,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5206,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5212,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:638: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* k7359 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_7361(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7361,2,av);}
/* string->list */
t2=C_fast_retrieve(lf[434]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7377 in k7460 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_7379(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_7379,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7396,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7400,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1057: pathname-directory */
t5=C_fast_retrieve(lf[438]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k5247 in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in ... */
static void C_ccall f_5249(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_5249,2,av);}
a=C_alloc(5);
t2=(C_truep(C_retrieve2(lf[31],"main#\052target-extension\052"))?C_retrieve2(lf[30],"main#\052host-extension\052"):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:663: print */
t4=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[332];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* a5241 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in ... */
static void C_ccall f_5242(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5242,2,av);}
/* chicken-install.scm:656: change-directory */
t2=C_fast_retrieve(lf[267]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k7394 in k7377 in k7460 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_fcall f_7396(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_7396,2,t0,t1);}
a=C_alloc(9);
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1),C_retrieve2(lf[77],"main#\052eggs+dirs+vers\052"));
t3=C_mutate2(&lf[77] /* (set! main#*eggs+dirs+vers* ...) */,t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);
/* chicken-install.scm:1065: loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_6383(t7,((C_word*)t0)[6],t5,t6);}

/* a3278 in scan in k3236 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_3279(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_3279,4,av);}
a=C_alloc(7);
t4=t3;
t5=(C_truep(t2)?C_SCHEME_FALSE:C_i_not(t4));
if(C_truep(t5)){
/* chicken-install.scm:261: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=C_SCHEME_FALSE;
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}
else{
t6=C_i_cdr(((C_word*)t0)[2]);
t7=t6;
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3300,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t9=((C_word*)t0)[5];
t10=t8;
f_3300(t10,(C_truep(t9)?((C_word*)t0)[5]:t2));}
else{
t9=t8;
f_3300(t9,((C_word*)t0)[5]);}}}

/* k5163 in k5157 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in ... */
static void C_ccall f_5165(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5165,2,av);}
if(C_truep(t1)){
/* chicken-install.scm:648: file-exists? */
t2=C_fast_retrieve(lf[60]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[274];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_5073(2,av2);}}}

/* k6455 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_6457(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6457,2,av);}
/* chicken-install.scm:916: apply-mappings */
f_5955(((C_word*)t0)[2],t1);}

/* a5901 in a5895 in a5875 in a5838 in k5829 in k5826 in k5823 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in ... */
static void C_ccall f_5902(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5902,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_6453(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_6453,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];
t3=t1;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4979,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[6],"main#\052keep-existing\052"))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5507,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5509,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:584: remove */
t8=C_fast_retrieve(lf[352]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=t7;
av2[3]=((C_word*)t4)[1];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t6=t5;
f_4979(t6,C_SCHEME_UNDEFINED);}}

/* k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_6421(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_6421,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_UNDEFINED;
f_6424(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6460,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"main#\052default-transport\052"))){
if(C_truep(C_retrieve2(lf[14],"main#\052default-location\052"))){
t4=C_SCHEME_UNDEFINED;
t5=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
f_6424(2,av2);}}
else{
/* chicken-install.scm:905: error */
t4=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[353];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}
else{
/* chicken-install.scm:902: error */
t4=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[354];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}}

/* k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_6424(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_6424,2,av);}
a=C_alloc(6);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6434,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve2(lf[15],"main#\052default-transport\052");
t4=C_retrieve2(lf[14],"main#\052default-location\052");
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6290,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:783: with-default-sources */
f_3714(t2,t5);}
else{
if(C_truep(C_retrieve2(lf[36],"main#\052show-depends\052"))){
/* chicken-install.scm:912: show-depends */
f_4077(((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1],C_a_i_list(&a,1,lf[96]));}
else{
if(C_truep(C_retrieve2(lf[37],"main#\052show-foreign-depends\052"))){
/* chicken-install.scm:914: show-depends */
f_4077(((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1],C_a_i_list(&a,1,lf[108]));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6453,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6457,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:916: reverse */
t4=*((C_word*)lf[112]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}}}

/* a5187 in a5181 in a5175 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in ... */
static void C_ccall f_5188(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,5))){C_save_and_reclaim((void *)f_5188,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5192,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:638: print */
t3=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[278];
av2[3]=lf[271];
av2[4]=((C_word*)t0)[3];
av2[5]=lf[272];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k5919 in for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_5921(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5921,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5911(t3,((C_word*)t0)[4],t2);}

/* k6432 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_6434(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6434,2,av);}
/* chicken-install.scm:908: display */
t2=*((C_word*)lf[264]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4910 in k4904 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in ... */
static void C_ccall f_4912(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_4912,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4925,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4929,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:555: normalize-pathname */
t5=C_fast_retrieve(lf[303]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* a5181 in a5175 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in ... */
static void C_ccall f_5182(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5182,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5188,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:638: k1137 */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k4913 in k4910 in k4904 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in ... */
static void C_ccall f_4915(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_4915,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:554: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[301];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4019 in k4016 in k4013 in k4010 in k4007 in k4001 in k3994 in g656 in k3977 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_4021(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4021,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm:410: ##sys#print */
t4=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* a5175 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in ... */
static void C_ccall f_5176(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_5176,3,av);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5182,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5200,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:638: with-exception-handler */
t5=C_fast_retrieve(lf[190]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k4022 in k4019 in k4016 in k4013 in k4010 in k4007 in k4001 in k3994 in g656 in k3977 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_4024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_4024,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:410: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[131]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[131]+1);
av2[1]=t2;
av2[2]=C_make_character(39);
av2[3]=((C_word*)t0)[4];
tp(4,av2);}}

/* for-each-loop1258 in a5818 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_fcall f_5911(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_5911,3,t0,t1,t2);}
a=C_alloc(8);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5921,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5825,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:692: pathname-strip-directory */
t7=C_fast_retrieve(lf[254]);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k3230 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_3232(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3232,2,av);}
if(C_truep(t1)){
/* chicken-install.scm:248: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}
else{
/* chicken-install.scm:249: ->string */
t2=C_fast_retrieve(lf[56]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}}

/* k6401 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_6403(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_6403,2,av);}
/* chicken-install.scm:871: print */
t2=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3236 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_3238(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,5))){
C_save_and_reclaim_args((void *)trf_3238,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3247,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3247(t6,((C_word*)t0)[3],t2,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3328,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[2];
t4=C_u_i_length(t3);
t5=C_eqp(C_fix(2),t4);
if(C_truep(t5)){
t6=C_i_car(((C_word*)t0)[2]);
t7=C_i_stringp(t6);
if(C_truep(t7)){
t8=t2;
f_3328(t8,t7);}
else{
t8=((C_word*)t0)[2];
t9=C_u_i_car(t8);
t10=t2;
f_3328(t10,C_i_symbolp(t9));}}
else{
t6=t2;
f_3328(t6,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3328(t3,C_SCHEME_FALSE);}}}

/* k4025 in k4022 in k4019 in k4016 in k4013 in k4010 in k4007 in k4001 in k3994 in g656 in k3977 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_4027(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4027,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4030,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:410: get-output-string */
t3=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4898 in k4895 in k4892 in k4886 in k4839 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in ... */
static void C_ccall f_4900(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4900,2,av);}
/* chicken-install.scm:558: get-output-string */
t2=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5169 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in ... */
static void C_ccall f_5171(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5171,2,av);}
/* chicken-install.scm:638: g1141 */
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* k4904 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in ... */
static void C_ccall f_4906(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4906,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[40]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4912,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:554: ##sys#print */
t6=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[304];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4916 in k4913 in k4910 in k4904 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in ... */
static void C_ccall f_4918(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4918,2,av);}
/* chicken-install.scm:554: get-output-string */
t2=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5947 in k5939 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_5949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5949,2,av);}
/* chicken-install.scm:685: make-pathname */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[259];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5943 in k5939 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_5945(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5945,2,av);}
/* chicken-install.scm:684: glob */
t2=C_fast_retrieve(lf[258]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4176 in k4099 in g706 in k4094 in k4091 in k4082 in k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in ... */
static void C_ccall f_4178(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4178,2,av);}
if(C_truep(t1)){
/* chicken-install.scm:429: with-input-from-file */
t2=C_fast_retrieve(lf[58]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=*((C_word*)lf[59]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_4104(2,av2);}}}

/* k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_6418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(25,c,3))){C_save_and_reclaim((void *)f_6418,2,av);}
a=C_alloc(25);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[4])[1]))){
if(C_truep(C_retrieve2(lf[35],"main#\052reinstall\052"))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6478,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6222,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6224,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6274,a[2]=t6,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6278,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6282,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:779: repo-path */
f_2457(t10);}
else{
t4=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t4)){
t5=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_6421(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6563,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:888: glob */
t6=C_fast_retrieve(lf[258]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[368];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_6421(2,av2);}}}

/* k5939 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_5941(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5941,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5945,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5949,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:685: repo-path */
f_2457(t4);}

/* k4013 in k4010 in k4007 in k4001 in k3994 in g656 in k3977 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_4015(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4015,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:410: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4010 in k4007 in k4001 in k3994 in g656 in k3977 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in ... */
static void C_ccall f_4012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4012,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:410: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[198];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4016 in k4013 in k4010 in k4007 in k4001 in k3994 in g656 in k3977 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_4018(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4018,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:410: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[197];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* a3268 in scan in k3236 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_3269(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3269,2,av);}
t2=C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm:259: check-dependency */
f_3205(t1,t2);}

/* k4930 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in ... */
static void C_ccall f_4932(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_4932,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[40]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4938,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:549: ##sys#print */
t6=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[307];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3171 in main#ext-version in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_3173(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3173,2,av);}
t2=C_i_member(t1,C_fast_retrieve(lf[65]));
t3=((C_word*)t0)[2];
f_3121(t3,(C_truep(t2)?t2:C_i_member(t1,C_fast_retrieve(lf[66]))));}

/* a5933 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_5934(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5934,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_fast_retrieve(lf[249]));
t3=C_mutate2((C_word*)lf[249]+1 /* (set! ##sys#warnings-enabled ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4191 in k4094 in k4091 in k4082 in k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in ... */
static void C_ccall f_4193(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4193,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4196,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:437: cleanup */
f_5559(t2);}

/* k4194 in k4191 in k4094 in k4091 in k4082 in k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in ... */
static void C_ccall f_4196(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4196,2,av);}
/* chicken-install.scm:438: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5193 in k5190 in a5187 in a5181 in a5175 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in ... */
static void C_ccall f_5195(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5195,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5198,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:638: print */
t3=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[269];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5196 in k5193 in k5190 in a5187 in a5181 in a5175 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in ... */
static void C_ccall f_5198(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5198,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k3899 in k3896 in k3890 in g625 in k3963 in a3869 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in ... */
static void C_ccall f_3901(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_3901,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:391: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[133];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k7298 in k7291 in k7285 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_7300(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7300,2,av);}
/* chicken-install.scm:1045: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6383(t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[4])[1]);}

/* k3902 in k3899 in k3896 in k3890 in g625 in k3963 in a3869 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in ... */
static void C_ccall f_3904(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_3904,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[6];
t4=C_u_i_car(t3);
/* chicken-install.scm:391: ##sys#print */
t5=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k3905 in k3902 in k3899 in k3896 in k3890 in g625 in k3963 in a3869 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in ... */
static void C_ccall f_3907(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_3907,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:391: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[132];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k6571 in k6561 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_6573(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6573,2,av);}
t2=C_mutate2(&lf[77] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
f_6421(2,av2);}}

/* k5190 in a5187 in a5181 in a5175 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in ... */
static void C_ccall f_5192(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5192,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5195,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:638: print-error-message */
t3=C_fast_retrieve(lf[172]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k4923 in k4910 in k4904 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in ... */
static void C_ccall f_4925(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4925,2,av);}
/* chicken-install.scm:554: ##sys#print */
t2=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4936 in k4930 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in ... */
static void C_ccall f_4938(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_4938,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4951,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4955,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:550: normalize-pathname */
t5=C_fast_retrieve(lf[303]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3162 in k3125 in k3119 in main#ext-version in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_3164(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3164,2,av);}
/* chicken-install.scm:230: make-pathname */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
av2[4]=lf[61];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k7310 in k7291 in k7285 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_7312(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7312,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* chicken-install.scm:1045: append */
t4=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* map-loop1750 in k7291 in k7285 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_fcall f_7316(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_7316,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_string(&a,2,C_make_character(45),t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2507 in k2504 in k2498 in main#repo-path in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_2509(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2509,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2512,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:120: get-output-string */
t3=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2504 in k2498 in main#repo-path in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2506(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2506,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_fudge(C_fix(42));
/* chicken-install.scm:120: ##sys#print */
t4=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k2498 in main#repo-path in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2500(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2500,2,av);}
a=C_alloc(5);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[40]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:120: ##sys#print */
t6=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[47];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k6584 in map-loop1614 in k6561 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_6586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,1))){C_save_and_reclaim((void *)f_6586,2,av);}
a=C_alloc(9);
t2=C_a_i_list2(&a,2,lf[365],lf[366]);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,t1,t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4953 in k4936 in k4930 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in ... */
static void C_ccall f_4955(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4955,2,av);}
if(C_truep(C_retrieve2(lf[17],"main#\052windows-shell\052"))){
/* chicken-install.scm:525: string-translate */
t2=C_fast_retrieve(lf[302]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_make_character(92);
av2[4]=C_make_character(47);
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
t2=t1;
/* chicken-install.scm:549: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k4949 in k4936 in k4930 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in ... */
static void C_ccall f_4951(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4951,2,av);}
/* chicken-install.scm:549: ##sys#print */
t2=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k4927 in k4910 in k4904 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in ... */
static void C_ccall f_4929(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_4929,2,av);}
if(C_truep(C_retrieve2(lf[17],"main#\052windows-shell\052"))){
/* chicken-install.scm:525: string-translate */
t2=C_fast_retrieve(lf[302]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_make_character(92);
av2[4]=C_make_character(47);
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}
else{
t2=t1;
/* chicken-install.scm:554: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}}

/* k4692 in k4679 in loop in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_4694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_4694,2,av);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
/* chicken-install.scm:516: fail */
t2=((C_word*)t0)[3];
f_4624(t2,((C_word*)t0)[2]);}}

/* map-loop1614 in k6561 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_fcall f_6595(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_6595,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6620,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6586,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:894: pathname-file */
t7=C_fast_retrieve(lf[361]);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4942 in k4939 in k4936 in k4930 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in ... */
static void C_ccall f_4944(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4944,2,av);}
/* chicken-install.scm:549: get-output-string */
t2=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6591 in k6561 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_6593(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6593,2,av);}
/* chicken-install.scm:891: append */
t2=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_retrieve2(lf[77],"main#\052eggs+dirs+vers\052");
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4939 in k4936 in k4930 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in ... */
static void C_ccall f_4941(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_4941,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:549: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[306];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* f8174 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f8174(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8174,2,av);}
/* chicken-install.scm:841: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* f8179 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f8179(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8179,2,av);}
/* chicken-install.scm:841: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k6699 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_6701(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6701,2,av);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* chicken-install.scm:935: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6383(t4,((C_word*)t0)[4],t3,((C_word*)((C_word*)t0)[5])[1]);}

/* k3957 in k3963 in a3869 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in ... */
static void C_ccall f_3959(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,9))){C_save_and_reclaim((void *)f_3959,2,av);}
t2=C_i_assq(lf[55],t1);
t3=(C_truep(t2)?C_i_cadr(t2):lf[135]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
/* chicken-install.scm:395: conc */
t6=C_fast_retrieve(lf[136]);{
C_word *av2;
if(c >= 10) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(10);
}
av2[0]=t6;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[137];
av2[3]=((C_word*)t0)[4];
av2[4]=lf[138];
av2[5]=t3;
av2[6]=lf[139];
av2[7]=t5;
av2[8]=lf[140];
av2[9]=C_make_character(10);
((C_proc)(void*)(*((C_word*)t6+1)))(10,av2);}}

/* k4001 in k3994 in g656 in k3977 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in ... */
static void C_ccall f_4003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_4003,2,av);}
a=C_alloc(8);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[40]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4009,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm:410: ##sys#print */
t6=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[199];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k4007 in k4001 in k3994 in g656 in k3977 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in ... */
static void C_ccall f_4009(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4009,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_cadr(((C_word*)t0)[7]);
/* chicken-install.scm:410: ##sys#print */
t4=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* f8191 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f8191(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8191,2,av);}
/* chicken-install.scm:841: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a5103 in a5097 in k5075 in k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in ... */
static void C_ccall f_5104(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5104,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5110,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:651: k1164 */
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* f8169 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f8169(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8169,2,av);}
/* chicken-install.scm:841: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* f8164 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f8164(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8164,2,av);}
/* chicken-install.scm:841: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2722 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_2724(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2724,2,av);}
/* chicken-install.scm:157: append */
t2=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[22],"main#\052mappings\052");
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* map-loop299 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_fcall f_2726(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_2726,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2751,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:159: g305 */
t5=((C_word*)t0)[4];
f_2682(t5,t3,t4);}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k6729 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_6731(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6731,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_mutate2(&lf[14] /* (set! main#*default-location* ...) */,t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
/* chicken-install.scm:942: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6383(t7,((C_word*)t0)[4],t6,((C_word*)((C_word*)t0)[5])[1]);}

/* k5365 in k5361 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in ... */
static void C_ccall f_5367(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_5367,2,av);}
/* chicken-install.scm:608: yes-or-no? */
t2=C_fast_retrieve(lf[122]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[125];
av2[4]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* f8139 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f8139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8139,2,av);}
/* chicken-install.scm:841: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5361 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in ... */
static void C_ccall f_5363(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5363,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5367,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:612: setup-api#abort-setup */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[126]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[126]+1);
av2[1]=t3;
tp(2,av2);}}

/* k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in ... */
static void C_ccall f_4799(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_4799,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-install.scm:541: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[311];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in ... */
static void C_ccall f_4796(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_4796,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-install.scm:541: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* f8132 in k3077 in k3073 in g412 in k3064 in k3061 in k3055 in k6881 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in ... */
static void C_ccall f8132(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8132,2,av);}
/* chicken-install.scm:798: $system */
f_6161(((C_word*)t0)[2],t1);}

/* k5453 in k5450 in k5447 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in ... */
static void C_ccall f_5455(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5455,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5458,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:596: cleanup */
f_5559(t2);}

/* k5456 in k5453 in k5450 in k5447 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in ... */
static void C_ccall f_5458(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5458,2,av);}
/* chicken-install.scm:597: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4679 in loop in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_fcall f_4681(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,4))){
C_save_and_reclaim_args((void *)trf_4681,2,t0,t1);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* chicken-install.scm:516: loop */
t4=((C_word*)((C_word*)t0)[5])[1];{
C_word av2[3];
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
f_4646(3,av2);}}
else{
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(lf[152],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4710,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[4];
t7=C_u_i_cdr(t6);
/* chicken-install.scm:518: every */
t8=C_fast_retrieve(lf[153]);{
C_word av2[4];
av2[0]=t8;
av2[1]=t5;
av2[2]=((C_word*)((C_word*)t0)[5])[1];
av2[3]=t7;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
t5=((C_word*)t0)[4];
t6=C_u_i_car(t5);
t7=C_eqp(lf[76],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=((C_word*)t0)[4];
t10=C_u_i_cdr(t9);
/* chicken-install.scm:520: any */
t11=C_fast_retrieve(lf[154]);{
C_word av2[4];
av2[0]=t11;
av2[1]=t8;
av2[2]=((C_word*)((C_word*)t0)[5])[1];
av2[3]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(4,av2);}}
else{
t8=C_i_cadr(((C_word*)t0)[6]);
/* chicken-install.scm:521: error */
t9=*((C_word*)lf[69]+1);{
C_word av2[5];
av2[0]=t9;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[155];
av2[3]=((C_word*)t0)[7];
av2[4]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}}}}

/* k5450 in k5447 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in ... */
static void C_ccall f_5452(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,4))){C_save_and_reclaim((void *)f_5452,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5455,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:595: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[347];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3908 in k3905 in k3902 in k3899 in k3896 in k3890 in g625 in k3963 in a3869 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in ... */
static void C_ccall f_3910(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_3910,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[5];
t4=C_u_i_cdr(t3);
/* chicken-install.scm:391: ##sys#print */
t5=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k3911 in k3908 in k3905 in k3902 in k3899 in k3896 in k3890 in g625 in k3963 in a3869 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in ... */
static void C_ccall f_3913(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_3913,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:391: ##sys#write-char-0 */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[131]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[131]+1);
av2[1]=t2;
av2[2]=C_make_character(39);
av2[3]=((C_word*)t0)[4];
tp(4,av2);}}

/* k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in k3896 in k3890 in g625 in k3963 in a3869 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in ... */
static void C_ccall f_3916(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3916,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3919,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:391: get-output-string */
t3=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in k3896 in k3890 in g625 in k3963 in a3869 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in ... */
static void C_ccall f_3919(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3919,2,av);}
/* chicken-install.scm:390: warning */
t2=C_fast_retrieve(lf[74]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* main#get-prefix in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_2524(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,3))){
C_save_and_reclaim_args((void *)trf_2524,2,t1,t2);}
a=C_alloc(3);
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
t5=(C_truep(C_retrieve2(lf[29],"main#\052cross-chicken\052"))?C_i_not(C_retrieve2(lf[30],"main#\052host-extension\052")):C_SCHEME_FALSE);
if(C_truep(t5)){
if(C_truep(t4)){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[46]+1);{
C_word av2[4];
av2[0]=t6;
av2[1]=t1;
av2[2]=C_mpointer(&a,(void*)C_TARGET_PREFIX);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
t6=C_retrieve2(lf[27],"main#\052prefix\052");
if(C_truep(C_retrieve2(lf[27],"main#\052prefix\052"))){
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_retrieve2(lf[27],"main#\052prefix\052");
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[46]+1);{
C_word av2[4];
av2[0]=t7;
av2[1]=t1;
av2[2]=C_mpointer(&a,(void*)C_TARGET_PREFIX);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}}
else{
t6=C_retrieve2(lf[27],"main#\052prefix\052");
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_retrieve2(lf[27],"main#\052prefix\052");
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in ... */
static void C_ccall f_4790(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_4790,2,av);}
a=C_alloc(10);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[40]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t3,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* chicken-install.scm:541: ##sys#print */
t6=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[312];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* f8186 in k7291 in k7285 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f8186(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8186,2,av);}
/* chicken-install.scm:841: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4108 in k4102 in k4099 in g706 in k4094 in k4091 in k4082 in k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in ... */
static void C_ccall f_4110(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_4110,2,av);}
a=C_alloc(4);
t2=t1;
if(C_truep(t2)){
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4122,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
t5=C_u_i_car(t4);
/* chicken-install.scm:434: print */
t6=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t3;
av2[2]=t5;
av2[3]=lf[101];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}
else{
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3890 in g625 in k3963 in a3869 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in ... */
static void C_ccall f_3892(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_3892,2,av);}
a=C_alloc(7);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[40]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3898,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:391: ##sys#print */
t6=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[134];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k3896 in k3890 in g625 in k3963 in a3869 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in ... */
static void C_ccall f_3898(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_3898,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_cadr(((C_word*)t0)[6]);
/* chicken-install.scm:391: ##sys#print */
t4=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k3055 in k6881 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_3057(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_3057,2,av);}
a=C_alloc(6);
t2=t1;
t3=(C_truep(C_retrieve2(lf[17],"main#\052windows-shell\052"))?lf[404]:lf[405]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3063,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:213: create-directory */
t6=C_fast_retrieve(lf[410]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
av2[3]=C_SCHEME_TRUE;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k5447 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in ... */
static void C_ccall f_5449(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_5449,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_list_ref(((C_word*)t0)[4],((C_word*)t0)[5]);
/* chicken-install.scm:595: ##sys#print */
t4=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* a5383 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in ... */
static void C_ccall f_5384(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5384,3,av);}
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
t5=C_i_car(((C_word*)t0)[2]);
t6=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_i_equalp(t4,t5);
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t3=t2;
t4=C_i_car(((C_word*)t0)[2]);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_i_equalp(t3,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* f8116 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f8116(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8116,2,av);}
/* chicken-install.scm:841: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* f8111 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f8111(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8111,2,av);}
/* chicken-install.scm:841: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2510 in k2507 in k2504 in k2498 in main#repo-path in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_2512(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2512,2,av);}
/* chicken-install.scm:118: make-pathname */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[27],"main#\052prefix\052");
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in ... */
static void C_fcall f_4782(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_4782,2,t0,t1);}
a=C_alloc(8);
t2=t1;
t3=(C_truep(C_retrieve2(lf[32],"main#\052debug-setup\052"))?lf[279]:lf[280]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm:541: open-output-string */
t6=C_fast_retrieve(lf[45]);{
C_word av2[2];
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}

/* f8159 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f8159(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8159,2,av);}
/* chicken-install.scm:841: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5380 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in ... */
static void C_ccall f_5382(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5382,2,av);}
t2=((C_word*)t0)[2];
f_5017(t2,C_i_not(t1));}

/* f8154 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f8154(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8154,2,av);}
/* chicken-install.scm:841: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k4099 in g706 in k4094 in k4091 in k4082 in k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in ... */
static void C_ccall f_4101(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_4101,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4178,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:429: file-exists? */
t5=C_fast_retrieve(lf[60]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k4102 in k4099 in g706 in k4094 in k4091 in k4082 in k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in ... */
static void C_ccall f_4104(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_4104,2,av);}
a=C_alloc(4);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_eqp(((C_word*)t0)[4],lf[96]);
if(C_truep(t3)){
t4=f_3038(lf[102],t1);
t5=f_3038(((C_word*)t0)[4],t1);
/* chicken-install.scm:431: append */
t6=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t2;
av2[2]=t4;
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}
else{
/* chicken-install.scm:432: deps */
t4=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=f_3038(((C_word*)t0)[4],t1);
f_4110(2,av2);}}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k3880 in g625 in k3963 in a3869 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in ... */
static void C_ccall f_3882(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3882,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6758 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_6760(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6760,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:945: string->symbol */
t4=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6762 in k6758 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_6764(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6764,2,av);}
t2=C_mutate2(&lf[15] /* (set! main#*default-transport* ...) */,t1);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
/* chicken-install.scm:946: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6383(t6,((C_word*)t0)[4],t5,((C_word*)((C_word*)t0)[5])[1]);}

/* k2482 in k2476 in k2472 in main#repo-path in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_2484(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2484,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:116: ##sys#print */
t3=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fix((C_word)C_BINARY_VERSION);
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2485 in k2482 in k2476 in k2472 in main#repo-path in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_2487(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2487,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:116: get-output-string */
t3=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* main#ext-version in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_3111(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,2))){
C_save_and_reclaim_args((void *)trf_3111,2,t1,t2);}
a=C_alloc(7);
t3=C_eqp(t2,lf[53]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3121,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3121(t5,t3);}
else{
t5=C_i_equalp(t2,lf[64]);
if(C_truep(t5)){
t6=t4;
f_3121(t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3173,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:223: ->string */
t7=C_fast_retrieve(lf[56]);{
C_word av2[3];
av2[0]=t7;
av2[1]=t6;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}}}

/* a3869 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_3870(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3870,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3965,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(t2);
/* chicken-install.scm:387: string->symbol */
t5=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* g625 in k3963 in a3869 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in ... */
static void C_fcall f_3878(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,0,2))){
C_save_and_reclaim_args((void *)trf_3878,3,t0,t1,t2);}
a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3882,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_i_cadr(t2);
t5=C_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_equalp(t4,t5))){
t6=t1;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3892,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:391: open-output-string */
t7=C_fast_retrieve(lf[45]);{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k3034 in main#with-default-sources in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_3036(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3036,2,av);}
t2=((C_word*)t0)[2];
f_3019(t2,C_i_not(t1));}

/* k2472 in main#repo-path in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2474(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2474,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2478,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:116: open-output-string */
t4=C_fast_retrieve(lf[45]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* main#deps in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static C_word C_fcall f_3038(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_overflow_check;{}
t3=C_i_assq(t1,t2);
if(C_truep(t3)){
t4=C_i_cdr(t3);
return((C_truep(t4)?t4:C_SCHEME_END_OF_LIST));}
else{
return(C_SCHEME_END_OF_LIST);}}

/* k2476 in k2472 in main#repo-path in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_2478(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2478,2,av);}
a=C_alloc(6);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[40]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:116: ##sys#print */
t6=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[44];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2749 in map-loop299 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_2751(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2751,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2726(t6,((C_word*)t0)[5],t5);}

/* k3858 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_3860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3860,2,av);}
/* chicken-install.scm:380: string-concatenate */
t2=C_fast_retrieve(lf[127]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3866 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_3868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_3868,2,av);}
/* chicken-install.scm:381: append */
t2=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
av2[4]=lf[130];
((C_proc)(void*)(*((C_word*)t2+1)))(5,av2);}}

/* k3024 in k3017 in main#with-default-sources in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_3026(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3026,2,av);}
/* chicken-install.scm:198: make-pathname */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_retrieve2(lf[14],"main#\052default-location\052");
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* f8126 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f8126(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8126,2,av);}
/* chicken-install.scm:841: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5416 in for-each-loop1095 in k5401 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in ... */
static void C_ccall f_5418(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5418,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_5408(t4,((C_word*)t0)[5],t2,t3);}

/* f8121 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f8121(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f8121,2,av);}
/* chicken-install.scm:841: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3017 in main#with-default-sources in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_3019(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(21,0,2))){
C_save_and_reclaim_args((void *)trf_3019,2,t0,t1);}
a=C_alloc(21);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3026,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:198: current-directory */
t3=C_fast_retrieve(lf[93]);{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=C_retrieve2(lf[14],"main#\052default-location\052");
t3=C_retrieve2(lf[14],"main#\052default-location\052");
t4=C_a_i_list(&a,2,lf[91],C_retrieve2(lf[14],"main#\052default-location\052"));
t5=C_a_i_list(&a,2,lf[89],C_retrieve2(lf[15],"main#\052default-transport\052"));
t6=C_a_i_list(&a,2,t4,t5);
t7=((C_word*)t0)[3];{
C_word av2[2];
av2[0]=t7;
av2[1]=C_a_i_list(&a,1,t6);
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k5401 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in ... */
static void C_ccall f_5403(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_5403,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5408,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5408(t5,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k3014 in main#with-default-sources in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_3016(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(21,c,1))){C_save_and_reclaim((void *)f_3016,2,av);}
a=C_alloc(21);
t2=C_a_i_list(&a,2,lf[91],t1);
t3=C_a_i_list(&a,2,lf[89],C_retrieve2(lf[15],"main#\052default-transport\052"));
t4=C_a_i_list(&a,2,t2,t3);
t5=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_list(&a,1,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* main#repo-path in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_2457(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_2457,1,t1);}
a=C_alloc(6);
if(C_truep(C_retrieve2(lf[23],"main#\052deploy\052"))){
t2=C_retrieve2(lf[27],"main#\052prefix\052");
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_retrieve2(lf[27],"main#\052prefix\052");
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(C_truep(C_retrieve2(lf[29],"main#\052cross-chicken\052"))?C_i_not(C_retrieve2(lf[30],"main#\052host-extension\052")):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2474,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[46]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=C_mpointer(&a,(void*)C_TARGET_LIB_HOME);
av2[3]=C_fix(0);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
if(C_truep(C_retrieve2(lf[27],"main#\052prefix\052"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2500,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:120: open-output-string */
t4=C_fast_retrieve(lf[45]);{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
/* chicken-install.scm:121: repository-path */
t3=C_fast_retrieve(lf[48]);{
C_word av2[2];
av2[0]=t3;
av2[1]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}}}

/* for-each-loop1095 in k5401 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in ... */
static void C_fcall f_5408(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_5408,4,t0,t1,t2,t3);}
a=C_alloc(6);
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5418,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* chicken-install.scm:600: g1096 */
t9=((C_word*)t0)[3];
f_5013(t9,t6,t7,t8);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* a5695 in k5689 in k5686 in a5680 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in ... */
static void C_ccall f_5696(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5696,2,av);}
/* chicken-install.scm:709: ##sys#module-exports */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[241]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[241]+1);
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
tp(3,av2);}}

/* k5689 in k5686 in a5680 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in ... */
static void C_ccall f_5691(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_5691,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5696,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5702,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:709: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[4];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* a3839 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in ... */
static void C_ccall f_3840(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3840,4,av);}
if(C_truep(t2)){
/* chicken-install.scm:376: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_values(4,av2);}}
else{
/* chicken-install.scm:377: next */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t1;
((C_proc)C_fast_retrieve_proc(t4))(2,av2);}}}

/* trying-sources in k3716 in main#with-default-sources in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_fcall f_3723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,4))){
C_save_and_reclaim_args((void *)trf_3723,3,t0,t1,t2);}
a=C_alloc(10);
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3735,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:347: proc */
t4=((C_word*)t0)[2];{
C_word av2[5];
av2[0]=t4;
av2[1]=t1;
av2[2]=C_SCHEME_FALSE;
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)C_fast_retrieve_proc(t4))(5,av2);}}
else{
t3=C_i_car(t2);
t4=t3;
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3757,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=C_i_assq(lf[91],t4);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3803,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t6)){
t8=C_i_cadr(t6);
/* chicken-install.scm:356: resolve-location */
f_2970(t5,t8);}
else{
/* chicken-install.scm:358: error */
t8=*((C_word*)lf[69]+1);{
C_word av2[4];
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[92];
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}}
else{
t5=t2;
t6=C_u_i_cdr(t5);
/* chicken-install.scm:367: trying-sources */
t10=t1;
t11=t6;
t1=t10;
t2=t11;
goto loop;}}}

/* k5686 in a5680 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in ... */
static void C_ccall f_5688(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5688,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5691,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:708: print* */
t4=*((C_word*)lf[244]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[245];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* a5680 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_5681(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_5681,3,av);}
a=C_alloc(4);
t3=C_i_cdr(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5688,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:707: ##sys#module-name */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[246]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[246]+1);
av2[1]=t5;
av2[2]=t4;
tp(3,av2);}}

/* k6974 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_6976(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6976,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:982: string->symbol */
t4=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a2712 in g305 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_2713(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2713,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_eqp(lf[374],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5669 in k5665 in a5658 in k5655 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in ... */
static void C_ccall f_5671(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5671,2,av);}
/* chicken-install.scm:715: string<? */
t2=*((C_word*)lf[239]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* main#with-default-sources in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_3714(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,0,2))){
C_save_and_reclaim_args((void *)trf_3714,2,t1,t2);}
a=C_alloc(14);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3718,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t3;
t5=(C_truep(C_retrieve2(lf[14],"main#\052default-location\052"))?C_retrieve2(lf[15],"main#\052default-transport\052"):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3016,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3019,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t8=C_eqp(C_retrieve2(lf[15],"main#\052default-transport\052"),lf[88]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3036,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:197: absolute-pathname? */
t10=C_fast_retrieve(lf[94]);{
C_word av2[3];
av2[0]=t10;
av2[1]=t9;
av2[2]=C_retrieve2(lf[14],"main#\052default-location\052");
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}
else{
t9=t7;
f_3019(t9,C_SCHEME_FALSE);}}
else{
t6=C_retrieve2(lf[13],"main#\052default-sources\052");
t7=t4;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_retrieve2(lf[13],"main#\052default-sources\052");
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}}

/* k3716 in main#with-default-sources in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_3718(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_3718,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3723,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3723(t5,((C_word*)t0)[3],t1);}

/* k6907 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_6909(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6909,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:972: setup-proxy */
f_6320(t2,t3);}

/* k6006 in k6010 in same? in main#apply-mappings in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_6008(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6008,2,av);}
t2=C_i_car(t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_equalp(((C_word*)t0)[3],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a2699 in k2687 in k2684 in g305 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in ... */
static void C_ccall f_2700(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_2700,4,av);}
a=C_alloc(3);
t4=C_i_cdr(t3);
t5=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_a_i_cons(&a,2,t2,t4);
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k6910 in k6907 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_6912(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6912,2,av);}
t2=C_i_cddr(((C_word*)t0)[2]);
/* chicken-install.scm:973: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6383(t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[5])[1]);}

/* k2488 in k2485 in k2482 in k2476 in k2472 in main#repo-path in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_2490(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2490,2,av);}
/* chicken-install.scm:116: make-pathname */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5544 in a5541 in k5528 in k5525 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in ... */
static void C_ccall f_5546(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5546,2,av);}
/* chicken-install.scm:675: delete-file* */
t2=C_fast_retrieve(lf[322]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k5307 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in ... */
static void C_ccall f_5309(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_5309,2,av);}
a=C_alloc(5);
t2=(C_truep(C_retrieve2(lf[17],"main#\052windows-shell\052"))?lf[333]:lf[334]);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5320,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:626: make-pathname */
t5=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[336];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k2899 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_2901(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_2901,2,av);}
a=C_alloc(3);
t2=C_a_i_list1(&a,1,t1);
/* chicken-install.scm:180: append */
t3=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[38],"main#\052hacks\052");
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* g350 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_fcall f_2773(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_2773,3,t0,t1,t2);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2780,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_listp(t2))){
t4=t2;
t5=C_u_i_length(t4);
t6=C_eqp(C_fix(2),t5);
if(C_truep(t6)){
/* chicken-install.scm:170: every */
t7=C_fast_retrieve(lf[153]);{
C_word av2[4];
av2[0]=t7;
av2[1]=t3;
av2[2]=*((C_word*)lf[376]+1);
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t7=t3;{
C_word av2[2];
av2[0]=t7;
av2[1]=C_SCHEME_FALSE;
f_2780(2,av2);}}}
else{
t4=t3;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_2780(2,av2);}}}

/* a5541 in k5528 in k5525 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in ... */
static void C_ccall f_5542(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_5542,4,av);}
a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5546,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:674: print* */
t5=*((C_word*)lf[244]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[323];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* a3734 in trying-sources in k3716 in main#with-default-sources in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_3735(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_3735,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3739,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3744,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:349: with-output-to-port */
t4=C_fast_retrieve(lf[86]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=*((C_word*)lf[87]+1);
av2[3]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3737 in a3734 in trying-sources in k3716 in main#with-default-sources in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_3739(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3739,2,av);}
/* chicken-install.scm:353: exit */
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3758 in k3755 in trying-sources in k3716 in main#with-default-sources in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_fcall f_3760(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_3760,2,t0,t1);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3765,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:361: proc */
t4=((C_word*)t0)[4];{
C_word av2[5];
av2[0]=t4;
av2[1]=((C_word*)t0)[5];
av2[2]=t2;
av2[3]=((C_word*)t0)[6];
av2[4]=t3;
((C_proc)C_fast_retrieve_proc(t4))(5,av2);}}

/* k5528 in k5525 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in ... */
static void C_ccall f_5530(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(38,c,6))){C_save_and_reclaim((void *)f_5530,2,av);}
a=C_alloc(38);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_list(&a,2,lf[315],lf[154]);
t4=C_a_i_list(&a,5,lf[76],lf[316],lf[317],lf[318],lf[319]);
t5=C_a_i_list(&a,4,lf[320],t3,lf[321],t4);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5542,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:672: find-files */
t7=C_fast_retrieve(lf[324]);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t7;
av2[1]=t2;
av2[2]=lf[325];
av2[3]=lf[326];
av2[4]=t5;
av2[5]=lf[327];
av2[6]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(7,av2);}}

/* k5531 in k5528 in k5525 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in ... */
static void C_ccall f_5533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5533,2,av);}
/* chicken-install.scm:676: newline */
t2=*((C_word*)lf[235]+1);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2766 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_2768(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2768,2,av);}
t2=C_mutate2(&lf[28] /* (set! main#*aliases* ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a3764 in k3758 in k3755 in trying-sources in k3716 in main#with-default-sources in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in ... */
static void C_ccall f_3765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3765,2,av);}
t2=C_eqp(lf[88],((C_word*)t0)[2]);
if(C_truep(t2)){
t3=C_i_cdr(((C_word*)t0)[3]);
/* chicken-install.scm:366: trying-sources */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3723(t4,t1,t3);}
else{
t3=C_i_set_car(((C_word*)t0)[3],C_SCHEME_FALSE);
t4=C_i_cdr(((C_word*)t0)[3]);
/* chicken-install.scm:366: trying-sources */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3723(t5,t1,t4);}}

/* k3755 in trying-sources in k3716 in main#with-default-sources in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_3757(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_3757,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=C_i_assq(lf[89],((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3789,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t4)){
t6=t3;
f_3760(t6,C_i_cadr(t4));}
else{
/* chicken-install.scm:360: error */
t6=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[90];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}

/* k6940 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_6942(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_6942,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:977: string->symbol */
t4=*((C_word*)lf[142]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a3701 in a3672 in a3579 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_3702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,2))){
C_save_and_reclaim((void*)f_3702,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3708,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:316: k555 */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* a3707 in a3701 in a3672 in a3579 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_3708(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3708,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k6954 in k6940 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_6956(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_6956,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_retrieve2(lf[25],"main#\052csc-features\052"));
t3=C_mutate2(&lf[25] /* (set! main#*csc-features* ...) */,t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
/* chicken-install.scm:978: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6383(t7,((C_word*)t0)[4],t6,((C_word*)((C_word*)t0)[5])[1]);}

/* for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_fcall f_4598(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,0,4))){
C_save_and_reclaim_args((void *)trf_4598,3,t0,t1,t2);}
a=C_alloc(13);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4608,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=C_i_assoc(t4,C_retrieve2(lf[77],"main#\052eggs+dirs+vers\052"));
if(C_truep(t6)){
t7=t5;
t8=t6;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4269,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:447: delete */
t10=C_fast_retrieve(lf[164]);{
C_word av2[5];
av2[0]=t10;
av2[1]=t9;
av2[2]=t8;
av2[3]=C_retrieve2(lf[77],"main#\052eggs+dirs+vers\052");
av2[4]=*((C_word*)lf[165]+1);
((C_proc)(void*)(*((C_word*)t10+1)))(5,av2);}}
else{
t7=C_i_pairp(t4);
t8=(C_truep(t7)?C_u_i_car(t4):t4);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4278,a[2]=t9,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t11=t10;
t12=t4;
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3979,a[2]=t12,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t12))){
t14=C_u_i_car(t12);
/* chicken-install.scm:405: string->symbol */
t15=*((C_word*)lf[142]+1);{
C_word av2[3];
av2[0]=t15;
av2[1]=t13;
av2[2]=t14;
((C_proc)(void*)(*((C_word*)t15+1)))(3,av2);}}
else{
/* chicken-install.scm:405: string->symbol */
t14=*((C_word*)lf[142]+1);{
C_word av2[3];
av2[0]=t14;
av2[1]=t13;
av2[2]=t12;
((C_proc)(void*)(*((C_word*)t14+1)))(3,av2);}}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k3685 in a3678 in a3672 in a3579 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_3687(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,24))){C_save_and_reclaim((void *)f_3687,2,av);}
t2=C_retrieve2(lf[9],"main#\052retrieve-only\052");
t3=(C_truep(C_retrieve2(lf[9],"main#\052retrieve-only\052"))?C_SCHEME_FALSE:C_i_not(C_retrieve2(lf[5],"main#\052keep\052")));
/* chicken-install.scm:318: setup-download#retrieve-extension */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[179]);
C_word *av2;
if(c >= 25) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(25);
}
av2[0]=*((C_word*)lf[179]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=lf[180];
av2[6]=((C_word*)t0)[6];
av2[7]=lf[181];
av2[8]=t1;
av2[9]=lf[182];
av2[10]=C_retrieve2(lf[8],"main#\052run-tests\052");
av2[11]=lf[183];
av2[12]=C_retrieve2(lf[11],"main#\052username\052");
av2[13]=lf[184];
av2[14]=C_retrieve2(lf[12],"main#\052password\052");
av2[15]=lf[185];
av2[16]=C_retrieve2(lf[24],"main#\052trunk\052");
av2[17]=lf[186];
av2[18]=C_retrieve2(lf[18],"main#\052proxy-host\052");
av2[19]=lf[187];
av2[20]=C_retrieve2(lf[19],"main#\052proxy-port\052");
av2[21]=lf[188];
av2[22]=C_retrieve2(lf[20],"main#\052proxy-user-pass\052");
av2[23]=lf[189];
av2[24]=t3;
tp(25,av2);}}

/* k2947 in for-each-loop260 in k2932 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_2949(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2949,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2939(t3,((C_word*)t0)[4],t2);}

/* k4429 in for-each-loop862 in k4403 in k4400 in k4397 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in ... */
static void C_ccall f_4431(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4431,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4421(t3,((C_word*)t0)[4],t2);}

/* a3678 in a3672 in a3579 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_3679(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_3679,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3687,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve2(lf[9],"main#\052retrieve-only\052"))){
/* chicken-install.scm:321: current-directory */
t3=C_fast_retrieve(lf[93]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_3687(2,av2);}}}

/* a3672 in a3579 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in ... */
static void C_ccall f_3673(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_3673,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3702,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:316: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* g1513 in k6268 in a6223 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_fcall f_6241(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_6241,3,t0,t1,t2);}
a=C_alloc(4);
t3=C_i_cadr(t2);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6253,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:773: ->string */
t6=C_fast_retrieve(lf[56]);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}

/* k2932 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_2934(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2934,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2939,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2939(t5,((C_word*)t0)[3],t1);}

/* for-each-loop260 in k2932 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_fcall f_2939(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_2939,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2949,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:136: g261 */
t5=((C_word*)t0)[3];
f_2577(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* for-each-loop862 in k4403 in k4400 in k4397 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in ... */
static void C_fcall f_4421(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,4))){
C_save_and_reclaim_args((void *)trf_4421,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4431,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4410,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:494: print */
t8=*((C_word*)lf[83]+1);{
C_word av2[5];
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[116];
av2[3]=t6;
av2[4]=lf[117];
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5525 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in ... */
static void C_ccall f_5527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5527,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5530,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:671: print* */
t3=*((C_word*)lf[244]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[328];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k6257 in k6268 in a6223 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in ... */
static void C_ccall f_6259(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_6259,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k6251 in g1513 in k6268 in a6223 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_6253(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_6253,2,av);}
a=C_alloc(3);
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a7576 in a7570 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_7577(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7577,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* k4457 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_4459(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_4459,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4463,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:489: setup-api#abort-setup */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[126]);
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=*((C_word*)lf[126]+1);
av2[1]=t3;
tp(2,av2);}}

/* a7570 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_7571(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +3,c,2))){
C_save_and_reclaim((void*)f_7571,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+3);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7577,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1078: k1791 */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* a6223 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_6224(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_6224,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6270,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:769: read-file */
t4=C_fast_retrieve(lf[362]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k6220 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_6222(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_6222,2,av);}
/* chicken-install.scm:766: delete-duplicates */
t2=C_fast_retrieve(lf[209]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=*((C_word*)lf[357]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a3743 in a3734 in trying-sources in k3716 in main#with-default-sources in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_3744(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3744,2,av);}
/* chicken-install.scm:351: print */
t2=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=lf[84];
av2[3]=lf[85];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_3569(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(19,c,4))){C_save_and_reclaim((void *)f_3569,2,av);}
a=C_alloc(19);
t2=C_mutate2(&lf[80] /* (set! main#*csi* ...) */,t1);
t3=C_mutate2(&lf[81] /* (set! main#with-default-sources ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3714,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate2(&lf[95] /* (set! main#show-depends ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4077,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate2(&lf[110] /* (set! main#retrieve ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4247,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate2(&lf[105] /* (set! main#cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5559,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate2(&lf[146] /* (set! main#apply-mappings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5955,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate2(&lf[212] /* (set! main#$system ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6161,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate2(&lf[225] /* (set! main#setup-proxy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6320,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate2(&lf[230] /* (set! main#info->egg ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6356,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7507,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:1076: register-feature! */
t12=C_fast_retrieve(lf[446]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t12;
av2[1]=t11;
av2[2]=lf[447];
((C_proc)(void*)(*((C_word*)t12+1)))(3,av2);}}

/* k4444 in k4400 in k4397 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in ... */
static void C_ccall f_4446(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_4446,2,av);}
/* chicken-install.scm:491: print */
t2=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[118];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3549 in for-each-loop507 in k3469 in a4370 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_3551(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3551,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3541(t3,((C_word*)t0)[4],t2);}

/* k4583 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_4585(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4585,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4575(t3,((C_word*)t0)[4],t2);}

/* a3579 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in ... */
static void C_ccall f_3580(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_3580,3,av);}
a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3586,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:316: with-exception-handler */
t5=C_fast_retrieve(lf[190]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* a3585 in a3579 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in ... */
static void C_ccall f_3586(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3586,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3592,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:316: k555 */
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_fcall f_4575(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,0,4))){
C_save_and_reclaim_args((void *)trf_4575,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4585,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=C_i_car(t6);
if(C_truep(C_i_member(t7,C_retrieve2(lf[79],"main#\052checked\052")))){
t8=C_SCHEME_UNDEFINED;
t9=t5;{
C_word av2[2];
av2[0]=t9;
av2[1]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(2,av2);}}
else{
t8=C_u_i_car(t6);
t9=C_a_i_cons(&a,2,t8,C_retrieve2(lf[79],"main#\052checked\052"));
t10=C_mutate2(&lf[79] /* (set! main#*checked* ...) */,t9);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4348,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t12=C_i_cadr(t6);
t13=C_u_i_car(t6);
/* chicken-install.scm:463: make-pathname */
t14=C_fast_retrieve(lf[41]);{
C_word av2[5];
av2[0]=t14;
av2[1]=t11;
av2[2]=t12;
av2[3]=t13;
av2[4]=lf[163];
((C_proc)(void*)(*((C_word*)t14+1)))(5,av2);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5564 in main#cleanup in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_5566(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5566,2,av);}
if(C_truep(t1)){
/* chicken-install.scm:681: setup-api#remove-directory */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[202]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[202]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k7230 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_7232(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7232,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_mutate2(&lf[12] /* (set! main#*password* ...) */,t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
/* chicken-install.scm:1033: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6383(t7,((C_word*)t0)[4],t6,((C_word*)((C_word*)t0)[5])[1]);}

/* k4408 in for-each-loop862 in k4403 in k4400 in k4397 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in ... */
static void C_ccall f_4410(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4410,2,av);}
/* chicken-install.scm:495: setup-api#remove-extension */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[115]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[115]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
tp(3,av2);}}

/* k3573 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in ... */
static void C_ccall f_3575(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3575,2,av);}
/* chicken-install.scm:316: g559 */
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* k4414 in k4403 in k4400 in k4397 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in ... */
static void C_ccall f_4416(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4416,2,av);}
/* chicken-install.scm:497: retrieve */
f_4247(((C_word*)t0)[2],((C_word*)t0)[3]);}

/* main#cleanup in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_fcall f_5559(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_5559,1,t1);}
a=C_alloc(3);
if(C_truep(C_retrieve2(lf[5],"main#\052keep\052"))){
t2=C_SCHEME_UNDEFINED;
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5566,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:680: setup-download#temporary-directory */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[203]);
C_word av2[2];
av2[0]=*((C_word*)lf[203]+1);
av2[1]=t2;
tp(2,av2);}}}

/* k4267 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_4269(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,1))){C_save_and_reclaim((void *)f_4269,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_mutate2(&lf[77] /* (set! main#*eggs+dirs+vers* ...) */,t2);
t4=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k4400 in k4397 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in ... */
static void C_ccall f_4402(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_4402,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4405,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4446,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:491: string-intersperse */
t5=C_fast_retrieve(lf[119]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=t2;
av2[3]=lf[120];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k4403 in k4400 in k4397 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in ... */
static void C_ccall f_4405(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_4405,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4421,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4421(t6,t2,((C_word*)t0)[3]);}

/* a3520 in loop in k3481 in k3469 in a4370 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_3521(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_3521,4,av);}
a=C_alloc(6);
t4=(C_truep(t2)?C_a_i_cons(&a,2,t2,((C_word*)t0)[2]):((C_word*)t0)[2]);
if(C_truep(t3)){
t5=C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* chicken-install.scm:305: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3488(t6,t1,((C_word*)t0)[5],t4,t5);}
else{
t5=((C_word*)t0)[3];
/* chicken-install.scm:305: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3488(t6,t1,((C_word*)t0)[5],t4,t5);}}

/* k7583 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_7585(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_7585,2,av);}
/* chicken-install.scm:314: setup-api#shellpath */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[293]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[293]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* k5505 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_5507(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5507,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_4979(t3,t2);}

/* a5508 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_5509(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5509,3,av);}
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
/* chicken-install.scm:585: extension-information */
t5=C_fast_retrieve(lf[141]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t3=t2;
/* chicken-install.scm:585: extension-information */
t4=C_fast_retrieve(lf[141]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k5501 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_5503(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_5503,2,av);}
/* chicken-install.scm:589: reverse */
t2=*((C_word*)lf[112]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a3514 in loop in k3481 in k3469 in a4370 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_3515(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3515,2,av);}
/* chicken-install.scm:304: check-dependency */
f_3205(t1,((C_word*)t0)[2]);}

/* k7587 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 */
static void C_ccall f_7589(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7589,2,av);}
/* chicken-install.scm:314: make-pathname */
t2=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[4],"main#\052program-path\052");
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in ... */
static void C_ccall f_5020(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,6))){C_save_and_reclaim((void *)f_5020,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5023,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[2]);
t4=C_i_caddr(((C_word*)t0)[2]);
/* chicken-install.scm:616: print */
t5=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=lf[338];
av2[3]=t3;
av2[4]=C_make_character(58);
av2[5]=t4;
av2[6]=lf[339];
((C_proc)(void*)(*((C_word*)t5+1)))(7,av2);}}

/* k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in ... */
static void C_ccall f_6375(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_6375,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7504,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:864: get-environment-variable */
t5=C_fast_retrieve(lf[222]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[442];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in ... */
static void C_ccall f_6378(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_6378,2,av);}
a=C_alloc(10);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_6383(t5,((C_word*)t0)[7],((C_word*)t0)[8],C_SCHEME_END_OF_LIST);}

/* a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_4283(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,5))){C_save_and_reclaim((void *)f_4283,2,av);}
a=C_alloc(4);
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3819,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:370: with-default-sources */
f_3714(t1,t4);}

/* a4288 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_4289(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_4289,4,av);}
a=C_alloc(9);
t4=t2;
t5=t3;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4293,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_i_not(t4);
if(C_truep(t7)){
if(C_truep(t7)){
/* chicken-install.scm:454: error */
t8=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=lf[195];
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}
else{
t8=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_UNDEFINED;
f_4293(2,av2);}}}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4320,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:453: directory */
t9=C_fast_retrieve(lf[196]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t9+1)))(3,av2);}}}

/* setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in ... */
static void C_fcall f_5033(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_5033,3,t0,t1,t2);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5037,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:630: print */
t4=*((C_word*)lf[83]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[331];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in ... */
static void C_ccall f_5032(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(34,c,4))){C_save_and_reclaim((void *)f_5032,2,av);}
a=C_alloc(34);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5249,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(C_retrieve2(lf[31],"main#\052target-extension\052"))?C_retrieve2(lf[30],"main#\052host-extension\052"):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5285,a[2]=t10,a[3]=t12,a[4]=t6,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5292,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5298,a[2]=t6,a[3]=t8,a[4]=t10,a[5]=t12,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:658: ##sys#dynamic-wind */
t16=*((C_word*)lf[255]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t16;
av2[1]=t3;
av2[2]=t13;
av2[3]=t14;
av2[4]=t15;
((C_proc)(void*)(*((C_word*)t16+1)))(5,av2);}}
else{
/* chicken-install.scm:661: setup */
t5=t2;
f_5033(t5,t3,((C_word*)t0)[7]);}}

/* k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in ... */
static void C_ccall f_5037(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5037,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:631: current-directory */
t3=C_fast_retrieve(lf[93]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in ... */
static void C_ccall f_4278(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4278,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4283,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4289,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:449: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=t3;
av2[3]=t4;
C_call_with_values(4,av2);}}

/* k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in ... */
static void C_ccall f_5023(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_5023,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[31],"main#\052target-extension\052"))){
if(C_truep(C_retrieve2(lf[30],"main#\052host-extension\052"))){
/* chicken-install.scm:619: create-temporary-directory */
t3=C_fast_retrieve(lf[257]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_5026(2,av2);}}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_5026(2,av2);}}}

/* k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in ... */
static void C_ccall f_5026(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,2))){C_save_and_reclaim((void *)f_5026,2,av);}
a=C_alloc(13);
t2=t1;
t3=C_i_cadr(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5309,a[2]=t5,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:622: print */
t7=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[337];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t6=t5;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_5032(2,av2);}}}

/* k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in ... */
static void C_ccall f_5000(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_5000,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm:593: list-index */
t4=C_fast_retrieve(lf[349]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=*((C_word*)lf[156]+1);
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in ... */
static void C_ccall f_6393(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_6393,2,av);}
a=C_alloc(11);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6403,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:871: repo-path */
f_2457(t2);}
else{
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5578,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5941,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5953,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:684: repo-path */
f_2457(t5);}
else{
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t2=((C_word*)t0)[3];
t3=((C_word*)((C_word*)t0)[5])[1];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6130,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:749: setup-download#gather-egg-information */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[263]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[263]+1);
av2[1]=t4;
av2[2]=t3;
tp(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6418,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2561,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2968,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:131: chicken-home */
t6=C_fast_retrieve(lf[379]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}}}}

/* k7204 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_7206(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_7206,2,av);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_mutate2(&lf[80] /* (set! main#*csi* ...) */,t2);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
/* chicken-install.scm:1029: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_6383(t7,((C_word*)t0)[4],t6,((C_word*)((C_word*)t0)[5])[1]);}

/* g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in ... */
static void C_fcall f_5013(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_5013,4,t0,t1,t2,t3);}
a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5017,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5382,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5384,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:603: find */
t7=C_fast_retrieve(lf[210]);{
C_word av2[4];
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
av2[3]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t5=t4;
f_5017(t5,C_SCHEME_FALSE);}}

/* k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in ... */
static void C_ccall f_5012(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_5012,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5403,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:667: iota */
t5=C_fast_retrieve(lf[344]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[6];
av2[4]=C_fix(-1);
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}

/* k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in ... */
static void C_fcall f_5017(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,0,3))){
C_save_and_reclaim_args((void *)trf_5017,2,t0,t1);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5020,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[5])?C_SCHEME_FALSE:t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5343,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[10],"main#\052no-install\052"))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5359,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5363,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#string-append */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[341]);
C_word av2[4];
av2[0]=*((C_word*)lf[341]+1);
av2[1]=t7;
av2[2]=lf[342];
av2[3]=lf[343];
tp(4,av2);}}
else{
t6=t5;
f_5343(t6,C_SCHEME_FALSE);}}
else{
t5=t3;{
C_word av2[2];
av2[0]=t5;
av2[1]=C_SCHEME_UNDEFINED;
f_5020(2,av2);}}}

/* k4291 in a4288 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in ... */
static void C_ccall f_4293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_4293,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4296,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:455: print */
t3=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[193];
av2[3]=((C_word*)t0)[2];
av2[4]=lf[194];
av2[5]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4294 in k4291 in a4288 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in ... */
static void C_ccall f_4296(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,1))){C_save_and_reclaim((void *)f_4296,2,av);}
a=C_alloc(12);
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);
t3=C_a_i_cons(&a,2,t2,C_retrieve2(lf[77],"main#\052eggs+dirs+vers\052"));
t4=C_mutate2(&lf[77] /* (set! main#*eggs+dirs+vers* ...) */,t3);
t5=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k5007 in k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in ... */
static void C_ccall f_5009(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_5009,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm:599: pp */
t3=C_fast_retrieve(lf[261]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5004 in k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in ... */
static void C_ccall f_5006(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_5006,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm:598: print */
t3=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[345];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k5001 in k4998 in k4986 in k4980 in k4977 in k6451 in k6422 in k6419 in k6416 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in ... */
static void C_ccall f_5003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,c,4))){C_save_and_reclaim((void *)f_5003,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=*((C_word*)lf[87]+1);
t5=*((C_word*)lf[87]+1);
t6=C_i_check_port_2(*((C_word*)lf[87]+1),C_SCHEME_FALSE,C_SCHEME_TRUE,lf[346]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5449,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[7],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:595: ##sys#print */
t8=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=lf[348];
av2[3]=C_SCHEME_FALSE;
av2[4]=*((C_word*)lf[87]+1);
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_5006(2,av2);}}}

/* k3358 in k3405 in k3329 in k3326 in k3236 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in ... */
static void C_ccall f_3360(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_3360,2,av);}
a=C_alloc(4);
if(C_truep(C_u_i_string_equal_p(lf[68],t1))){
if(C_truep(C_retrieve2(lf[7],"main#\052force\052"))){
/* chicken-install.scm:277: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* chicken-install.scm:279: string-append */
t4=*((C_word*)lf[70]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[71];
av2[3]=t3;
av2[4]=lf[72];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
/* chicken-install.scm:286: ->string */
t5=C_fast_retrieve(lf[56]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t2;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* a4370 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_4371(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_4371,2,av);}
a=C_alloc(4);
t2=C_i_car(((C_word*)t0)[2]);
t3=t1;
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3471,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=f_3038(lf[96],((C_word*)t0)[3]);
t7=f_3038(lf[102],((C_word*)t0)[3]);
if(C_truep(C_retrieve2(lf[8],"main#\052run-tests\052"))){
t8=f_3038(lf[113],((C_word*)t0)[3]);
/* chicken-install.scm:241: append */
t9=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t9;
av2[1]=t5;
av2[2]=t6;
av2[3]=t7;
av2[4]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}
else{
/* chicken-install.scm:241: append */
t8=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t8;
av2[1]=t5;
av2[2]=t6;
av2[3]=t7;
av2[4]=C_SCHEME_END_OF_LIST;
((C_proc)(void*)(*((C_word*)t8+1)))(5,av2);}}}

/* loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in ... */
static void C_fcall f_6383(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,0,2))){
C_save_and_reclaim_args((void *)trf_6383,4,t0,t1,t2,t3);}
a=C_alloc(14);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6393,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve2(lf[23],"main#\052deploy\052"))){
if(C_truep(C_retrieve2(lf[27],"main#\052prefix\052"))){
t6=C_SCHEME_UNDEFINED;
t7=t5;{
C_word av2[2];
av2[0]=t7;
av2[1]=t6;
f_6393(2,av2);}}
else{
/* chicken-install.scm:869: error */
t6=*((C_word*)lf[69]+1);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[380];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}
else{
t6=t5;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_UNDEFINED;
f_6393(2,av2);}}}
else{
t5=C_i_car(t2);
t6=t5;
t7=C_i_string_equal_p(t6,lf[381]);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6651,a[2]=t1,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t7)){
t9=t8;
f_6651(t9,t7);}
else{
t9=C_u_i_string_equal_p(t6,lf[440]);
if(C_truep(t9)){
t10=t8;
f_6651(t10,t9);}
else{
t10=C_u_i_string_equal_p(t6,lf[441]);
t11=t8;
f_6651(t11,t10);}}}}

/* k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in ... */
static void C_ccall f_4363(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4363,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_u_i_car(((C_word*)t0)[2]);
/* chicken-install.scm:468: print */
t4=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[147];
av2[3]=t3;
av2[4]=lf[148];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}

/* k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in ... */
static void C_ccall f_4360(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,3))){C_save_and_reclaim((void *)f_4360,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_u_i_car(((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4624,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[29],"main#\052cross-chicken\052"))){
t6=C_SCHEME_UNDEFINED;
t7=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=t6;
f_4363(2,av2);}}
else{
t6=C_i_assq(lf[150],((C_word*)t0)[3]);
t7=t6;
if(C_truep(t7)){
t8=C_i_cadr(t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4646,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t12;
av2[1]=t2;
av2[2]=t8;
f_4646(3,av2);}}
else{
t8=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_FALSE;
f_4363(2,av2);}}}}

/* k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_4366(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_4366,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4381,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:469: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[4];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* k4397 in k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in ... */
static void C_ccall f_4399(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_4399,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4402,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:490: unzip1 */
t3=C_fast_retrieve(lf[121]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k3386 in k3358 in k3405 in k3329 in k3326 in k3236 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in ... */
static void C_ccall f_3388(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3388,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3392,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cadr(((C_word*)t0)[3]);
/* chicken-install.scm:286: ->string */
t5=C_fast_retrieve(lf[56]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k4391 in k4504 in k4498 in k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in ... */
static void C_ccall f_4393(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(25,c,3))){C_save_and_reclaim((void *)f_4393,2,av);}
a=C_alloc(25);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t3=C_retrieve2(lf[7],"main#\052force\052");
if(C_truep(C_retrieve2(lf[7],"main#\052force\052"))){
t4=C_retrieve2(lf[7],"main#\052force\052");
t5=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_retrieve2(lf[7],"main#\052force\052");
f_4399(2,av2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4459,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3860,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=C_i_car(((C_word*)t0)[4]);
t8=C_a_i_list3(&a,3,lf[128],t7,lf[129]);
t9=t8;
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3868,a[2]=t6,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3870,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm:385: filter-map */
t12=C_fast_retrieve(lf[143]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t12;
av2[1]=t10;
av2[2]=t11;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t12+1)))(4,av2);}}}
else{
t3=t2;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_SCHEME_FALSE;
f_4399(2,av2);}}}

/* a5701 in k5689 in k5686 in a5680 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in ... */
static void C_ccall f_5702(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(21,c,3))){C_save_and_reclaim((void *)f_5702,5,av);}
a=C_alloc(21);
t5=t3;
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5711,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=C_i_check_list_2(t4,lf[114]);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5725,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5780,a[2]=t10,a[3]=t8,a[4]=t14,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_5780(t16,t12,t4);}

/* k3371 in k3358 in k3405 in k3329 in k3326 in k3236 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in ... */
static void C_ccall f_3373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3373,2,av);}
/* chicken-install.scm:278: error */
t2=*((C_word*)lf[69]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in ... */
static void C_ccall f_4381(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_4381,4,av);}
a=C_alloc(8);
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=t3;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4386,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm:471: apply-mappings */
f_5955(t7,((C_word*)t5)[1]);}

/* k4384 in a4380 in k4364 in k4361 in k4358 in k4355 in k4352 in k4346 in for-each-loop802 in k4328 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_4386(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_4386,2,av);}
a=C_alloc(14);
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_i_car(((C_word*)t0)[3]);
t4=t3;
t5=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t7)[1];
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4500,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t7,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* chicken-install.scm:479: append */
t10=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t10;
av2[1]=t9;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}

/* a3591 in a3585 in a3579 in a3833 in a3818 in a4282 in k4276 in for-each-loop760 in k4249 in main#retrieve in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in ... */
static void C_ccall f_3592(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3592,2,av);}
a=C_alloc(5);
t2=C_i_structurep(((C_word*)t0)[2],lf[166]);
t3=(C_truep(t2)?C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3602,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=C_i_memv(lf[175],t4);
t7=t5;
f_3602(t7,(C_truep(t6)?C_i_memv(lf[178],t4):C_SCHEME_FALSE));}
else{
t6=t5;
f_3602(t6,C_SCHEME_FALSE);}}

/* a7352 in k7285 in k7276 in k6649 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in ... */
static void C_ccall f_7353(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_7353,3,av);}
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_i_memq(t2,lf[433]);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* for-each-loop705 in k4094 in k4091 in k4082 in k4079 in main#show-depends in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in ... */
static void C_fcall f_4201(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_4201,3,t0,t1,t2);}
a=C_alloc(5);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4211,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-install.scm:426: g706 */
t5=((C_word*)t0)[3];
f_4097(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k5723 in a5701 in k5689 in k5686 in a5680 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in ... */
static void C_ccall f_5725(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(20,c,3))){C_save_and_reclaim((void *)f_5725,2,av);}
a=C_alloc(20);
t2=t1;
t3=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t5)[1];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5730,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=C_i_check_list_2(((C_word*)t0)[3],lf[114]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5744,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5746,a[2]=t7,a[3]=t5,a[4]=t11,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_5746(t13,t9,((C_word*)t0)[3]);}

/* k3390 in k3386 in k3358 in k3405 in k3329 in k3326 in k3236 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in ... */
static void C_ccall f_3392(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_3392,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* chicken-install.scm:284: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_FALSE;
av2[3]=t2;
C_values(4,av2);}}

/* k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in ... */
static void C_ccall f_4831(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_4831,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4932,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:549: open-output-string */
t5=C_fast_retrieve(lf[45]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=lf[308];
f_4834(2,av2);}}}

/* k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in ... */
static void C_ccall f_4834(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_4834,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-install.scm:552: get-prefix */
f_2524(t3,C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in ... */
static void C_ccall f_4838(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,2))){C_save_and_reclaim((void *)f_4838,2,av);}
a=C_alloc(16);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4906,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:554: open-output-string */
t5=C_fast_retrieve(lf[45]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=lf[305];
f_4841(2,av2);}}}

/* g1328 in a5701 in k5689 in k5686 in a5680 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in ... */
static C_word C_fcall f_5711(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_i_car(t1);
return(C_a_i_list3(&a,3,t2,lf[242],((C_word*)t0)[2]));}

/* a5127 in a5121 in a5097 in k5075 in k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in ... */
static void C_ccall f_5128(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5128,2,av);}
/* chicken-install.scm:651: tmp1154 */
t2=((C_word*)t0)[2];
f_5078(t2,t1);}

/* a5121 in a5097 in k5075 in k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in k4998 in ... */
static void C_ccall f_5122(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_5122,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5128,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5134,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:651: ##sys#call-with-values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* k5118 in k5115 in k5112 in a5109 in a5103 in a5097 in k5075 in k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in ... */
static void C_ccall f_5120(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_5120,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* map-loop1349 in k5723 in a5701 in k5689 in k5686 in a5680 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in ... */
static void C_fcall f_5746(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,0,2))){
C_save_and_reclaim_args((void *)trf_5746,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_5730(C_a_i(&a,9),((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(1),t5);
t7=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_slot(t2,C_fix(1));
t10=t1;
t11=t8;
t1=t10;
t2=t11;
goto loop;}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[5],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k4859 in k4847 in k4843 in k4839 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in ... */
static void C_ccall f_4861(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_4861,2,av);}
/* chicken-install.scm:565: setup-api#shellpath */
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[293]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[293]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
tp(3,av2);}}

/* k5742 in k5723 in a5701 in k5689 in k5686 in a5680 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in ... */
static void C_ccall f_5744(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_5744,2,av);}
/* chicken-install.scm:710: append */
t2=*((C_word*)lf[103]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k4865 in k4843 in k4839 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in ... */
static void C_ccall f_4867(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_4867,2,av);}
a=C_alloc(5);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[40]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4873,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm:561: ##sys#print */
t6=*((C_word*)lf[43]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[296];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2861 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_fcall f_2863(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,0,2))){
C_save_and_reclaim_args((void *)trf_2863,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm:177: read-file */
t3=C_fast_retrieve(lf[362]);{
C_word av2[3];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_mutate2(&lf[34] /* (set! main#*override* ...) */,t3);
t5=((C_word*)t0)[4];{
C_word av2[2];
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}}

/* k5112 in a5109 in a5103 in a5097 in k5075 in k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in ... */
static void C_ccall f_5114(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5114,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5117,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:651: print-error-message */
t3=C_fast_retrieve(lf[172]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3420 in k3326 in k3236 in main#check-dependency in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in k2395 in k2392 in k2389 in k2386 in k2383 in k2380 in k2377 in k2374 in k2371 in k2368 in k2365 in ... */
static void C_ccall f_3422(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3422,2,av);}
/* chicken-install.scm:292: values */{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=C_SCHEME_FALSE;
C_values(4,av2);}}

/* k2858 in k2579 in g261 in k2962 in k2559 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in k2444 in k2417 in k2414 in k2411 in k2404 in k2401 in k2398 in ... */
static void C_ccall f_2860(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2860,2,av);}
t2=C_mutate2(&lf[34] /* (set! main#*override* ...) */,t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k5115 in k5112 in a5109 in a5103 in a5097 in k5075 in k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in ... */
static void C_ccall f_5117(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_5117,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5120,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm:651: print */
t3=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[269];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* a5109 in a5103 in a5097 in k5075 in k5071 in k5065 in k5056 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in k5024 in k5021 in k5018 in k5015 in g1096 in k5010 in k5007 in k5004 in k5001 in ... */
static void C_ccall f_5110(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,5))){C_save_and_reclaim((void *)f_5110,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5114,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm:651: print */
t3=*((C_word*)lf[83]+1);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[270];
av2[3]=lf[271];
av2[4]=((C_word*)t0)[3];
av2[5]=lf[272];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* k4855 in k4847 in k4843 in k4839 in k4836 in k4832 in k4829 in k4962 in k4809 in k4806 in k4803 in k4800 in k4797 in k4794 in k4788 in k4780 in k5053 in a5050 in k5038 in k5035 in setup in k5030 in ... */
static void C_ccall f_4857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,18))){C_save_and_reclaim((void *)f_4857,2,av);}
/* chicken-install.scm:529: conc */
t2=C_fast_retrieve(lf[136]);{
C_word *av2;
if(c >= 19) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(19);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=C_retrieve2(lf[80],"main#\052csi\052");
av2[3]=lf[291];
av2[4]=((C_word*)t0)[3];
av2[5]=lf[292];
av2[6]=((C_word*)t0)[4];
av2[7]=((C_word*)t0)[5];
av2[8]=((C_word*)t0)[6];
av2[9]=((C_word*)t0)[7];
av2[10]=((C_word*)t0)[8];
av2[11]=((C_word*)t0)[9];
av2[12]=((C_word*)t0)[10];
av2[13]=((C_word*)t0)[11];
av2[14]=((C_word*)t0)[12];
av2[15]=((C_word*)t0)[13];
av2[16]=((C_word*)t0)[14];
av2[17]=C_make_character(32);
av2[18]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(19,av2);}}

/* g1355 in k5723 in a5701 in k5689 in k5686 in a5680 in k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k6391 in loop in k6376 in k6373 in k7567 in a7557 in a7551 in a7520 in k7505 in k3567 in ... */
static C_word C_fcall f_5730(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_overflow_check;{}
t2=C_i_car(t1);
return(C_a_i_list3(&a,3,t2,lf[243],((C_word*)t0)[2]));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[585] = {
{"f_5140:chicken_2dinstall_2escm",(void*)f_5140},
{"f_2893:chicken_2dinstall_2escm",(void*)f_2893},
{"f_2843:chicken_2dinstall_2escm",(void*)f_2843},
{"f_3407:chicken_2dinstall_2escm",(void*)f_3407},
{"f_5134:chicken_2dinstall_2escm",(void*)f_5134},
{"f_4122:chicken_2dinstall_2escm",(void*)f_4122},
{"f_4135:chicken_2dinstall_2escm",(void*)f_4135},
{"f_5159:chicken_2dinstall_2escm",(void*)f_5159},
{"f_4811:chicken_2dinstall_2escm",(void*)f_4811},
{"f_4841:chicken_2dinstall_2escm",(void*)f_4841},
{"f_4845:chicken_2dinstall_2escm",(void*)f_4845},
{"f_4849:chicken_2dinstall_2escm",(void*)f_4849},
{"f_3834:chicken_2dinstall_2escm",(void*)f_3834},
{"f_4145:chicken_2dinstall_2escm",(void*)f_4145},
{"f_3819:chicken_2dinstall_2escm",(void*)f_3819},
{"f_3803:chicken_2dinstall_2escm",(void*)f_3803},
{"f_3247:chicken_2dinstall_2escm",(void*)f_3247},
{"f_4805:chicken_2dinstall_2escm",(void*)f_4805},
{"f_4802:chicken_2dinstall_2escm",(void*)f_4802},
{"f_4808:chicken_2dinstall_2escm",(void*)f_4808},
{"f_5320:chicken_2dinstall_2escm",(void*)f_5320},
{"f_5359:chicken_2dinstall_2escm",(void*)f_5359},
{"f_3222:chicken_2dinstall_2escm",(void*)f_3222},
{"f_3133:chicken_2dinstall_2escm",(void*)f_3133},
{"f_3130:chicken_2dinstall_2escm",(void*)f_3130},
{"f_5349:chicken_2dinstall_2escm",(void*)f_5349},
{"f_5346:chicken_2dinstall_2escm",(void*)f_5346},
{"f_5343:chicken_2dinstall_2escm",(void*)f_5343},
{"f_3127:chicken_2dinstall_2escm",(void*)f_3127},
{"f_3121:chicken_2dinstall_2escm",(void*)f_3121},
{"f_3205:chicken_2dinstall_2escm",(void*)f_3205},
{"f_3157:chicken_2dinstall_2escm",(void*)f_3157},
{"f_2780:chicken_2dinstall_2escm",(void*)f_2780},
{"f_7462:chicken_2dinstall_2escm",(void*)f_7462},
{"f_3632:chicken_2dinstall_2escm",(void*)f_3632},
{"f_6851:chicken_2dinstall_2escm",(void*)f_6851},
{"f_6858:chicken_2dinstall_2escm",(void*)f_6858},
{"f_3626:chicken_2dinstall_2escm",(void*)f_3626},
{"f_3629:chicken_2dinstall_2escm",(void*)f_3629},
{"f_6820:chicken_2dinstall_2escm",(void*)f_6820},
{"f_3617:chicken_2dinstall_2escm",(void*)f_3617},
{"f_3614:chicken_2dinstall_2escm",(void*)f_3614},
{"f_3789:chicken_2dinstall_2escm",(void*)f_3789},
{"f_6793:chicken_2dinstall_2escm",(void*)f_6793},
{"f_3602:chicken_2dinstall_2escm",(void*)f_3602},
{"f_3605:chicken_2dinstall_2escm",(void*)f_3605},
{"f_6800:chicken_2dinstall_2escm",(void*)f_6800},
{"f_6809:chicken_2dinstall_2escm",(void*)f_6809},
{"f_6816:chicken_2dinstall_2escm",(void*)f_6816},
{"f_5599:chicken_2dinstall_2escm",(void*)f_5599},
{"f_5596:chicken_2dinstall_2escm",(void*)f_5596},
{"f_5593:chicken_2dinstall_2escm",(void*)f_5593},
{"f_5590:chicken_2dinstall_2escm",(void*)f_5590},
{"f_7416:chicken_2dinstall_2escm",(void*)f_7416},
{"f_6171:chicken_2dinstall_2escm",(void*)f_6171},
{"f_2406:chicken_2dinstall_2escm",(void*)f_2406},
{"f_2403:chicken_2dinstall_2escm",(void*)f_2403},
{"f_2400:chicken_2dinstall_2escm",(void*)f_2400},
{"f_6187:chicken_2dinstall_2escm",(void*)f_6187},
{"f_6191:chicken_2dinstall_2escm",(void*)f_6191},
{"f_6199:chicken_2dinstall_2escm",(void*)f_6199},
{"f_5587:chicken_2dinstall_2escm",(void*)f_5587},
{"f_2630:chicken_2dinstall_2escm",(void*)f_2630},
{"f_5581:chicken_2dinstall_2escm",(void*)f_5581},
{"f_5584:chicken_2dinstall_2escm",(void*)f_5584},
{"f_2633:chicken_2dinstall_2escm",(void*)f_2633},
{"f_2446:chicken_2dinstall_2escm",(void*)f_2446},
{"f_5578:chicken_2dinstall_2escm",(void*)f_5578},
{"f_2621:chicken_2dinstall_2escm",(void*)f_2621},
{"f_2624:chicken_2dinstall_2escm",(void*)f_2624},
{"f_2627:chicken_2dinstall_2escm",(void*)f_2627},
{"f_2612:chicken_2dinstall_2escm",(void*)f_2612},
{"f_2618:chicken_2dinstall_2escm",(void*)f_2618},
{"f_6161:chicken_2dinstall_2escm",(void*)f_6161},
{"f_5851:chicken_2dinstall_2escm",(void*)f_5851},
{"f_6165:chicken_2dinstall_2escm",(void*)f_6165},
{"f_6168:chicken_2dinstall_2escm",(void*)f_6168},
{"f_5865:chicken_2dinstall_2escm",(void*)f_5865},
{"f_5868:chicken_2dinstall_2escm",(void*)f_5868},
{"f_2416:chicken_2dinstall_2escm",(void*)f_2416},
{"f_2419:chicken_2dinstall_2escm",(void*)f_2419},
{"f_6990:chicken_2dinstall_2escm",(void*)f_6990},
{"f_2413:chicken_2dinstall_2escm",(void*)f_2413},
{"f_4211:chicken_2dinstall_2escm",(void*)f_4211},
{"f_2391:chicken_2dinstall_2escm",(void*)f_2391},
{"f_2397:chicken_2dinstall_2escm",(void*)f_2397},
{"f_2394:chicken_2dinstall_2escm",(void*)f_2394},
{"f_5859:chicken_2dinstall_2escm",(void*)f_5859},
{"f_6336:chicken_2dinstall_2escm",(void*)f_6336},
{"f8076:chicken_2dinstall_2escm",(void*)f8076},
{"f_6330:chicken_2dinstall_2escm",(void*)f_6330},
{"f_5831:chicken_2dinstall_2escm",(void*)f_5831},
{"f_4247:chicken_2dinstall_2escm",(void*)f_4247},
{"f_5845:chicken_2dinstall_2escm",(void*)f_5845},
{"f8088:chicken_2dinstall_2escm",(void*)f8088},
{"f_2373:chicken_2dinstall_2escm",(void*)f_2373},
{"f_7065:chicken_2dinstall_2escm",(void*)f_7065},
{"f_2376:chicken_2dinstall_2escm",(void*)f_2376},
{"f_2370:chicken_2dinstall_2escm",(void*)f_2370},
{"f_2379:chicken_2dinstall_2escm",(void*)f_2379},
{"f_5834:chicken_2dinstall_2escm",(void*)f_5834},
{"f_5839:chicken_2dinstall_2escm",(void*)f_5839},
{"f_6356:chicken_2dinstall_2escm",(void*)f_6356},
{"f8149:chicken_2dinstall_2escm",(void*)f8149},
{"f_5780:chicken_2dinstall_2escm",(void*)f_5780},
{"f8144:chicken_2dinstall_2escm",(void*)f8144},
{"f_5828:chicken_2dinstall_2escm",(void*)f_5828},
{"f_5825:chicken_2dinstall_2escm",(void*)f_5825},
{"f_4251:chicken_2dinstall_2escm",(void*)f_4251},
{"f_6320:chicken_2dinstall_2escm",(void*)f_6320},
{"f_5819:chicken_2dinstall_2escm",(void*)f_5819},
{"f_5814:chicken_2dinstall_2escm",(void*)f_5814},
{"f_7091:chicken_2dinstall_2escm",(void*)f_7091},
{"f_2385:chicken_2dinstall_2escm",(void*)f_2385},
{"f_2382:chicken_2dinstall_2escm",(void*)f_2382},
{"f_2388:chicken_2dinstall_2escm",(void*)f_2388},
{"f_3541:chicken_2dinstall_2escm",(void*)f_3541},
{"f_6347:chicken_2dinstall_2escm",(void*)f_6347},
{"f_6343:chicken_2dinstall_2escm",(void*)f_6343},
{"f_2694:chicken_2dinstall_2escm",(void*)f_2694},
{"f_2367:chicken_2dinstall_2escm",(void*)f_2367},
{"f_2677:chicken_2dinstall_2escm",(void*)f_2677},
{"f_4077:chicken_2dinstall_2escm",(void*)f_4077},
{"f_2816:chicken_2dinstall_2escm",(void*)f_2816},
{"f_2818:chicken_2dinstall_2escm",(void*)f_2818},
{"f_2661:chicken_2dinstall_2escm",(void*)f_2661},
{"f_6484:chicken_2dinstall_2escm",(void*)f_6484},
{"f_3506:chicken_2dinstall_2escm",(void*)f_3506},
{"f_3502:chicken_2dinstall_2escm",(void*)f_3502},
{"f_5268:chicken_2dinstall_2escm",(void*)f_5268},
{"f_4873:chicken_2dinstall_2escm",(void*)f_4873},
{"f_5263:chicken_2dinstall_2escm",(void*)f_5263},
{"f_6493:chicken_2dinstall_2escm",(void*)f_6493},
{"f_4879:chicken_2dinstall_2escm",(void*)f_4879},
{"f_6491:chicken_2dinstall_2escm",(void*)f_6491},
{"f_4876:chicken_2dinstall_2escm",(void*)f_4876},
{"f_4093:chicken_2dinstall_2escm",(void*)f_4093},
{"f_4096:chicken_2dinstall_2escm",(void*)f_4096},
{"f_4097:chicken_2dinstall_2escm",(void*)f_4097},
{"f_5298:chicken_2dinstall_2escm",(void*)f_5298},
{"f_5292:chicken_2dinstall_2escm",(void*)f_5292},
{"f_6460:chicken_2dinstall_2escm",(void*)f_6460},
{"f_4894:chicken_2dinstall_2escm",(void*)f_4894},
{"f_4030:chicken_2dinstall_2escm",(void*)f_4030},
{"f_4897:chicken_2dinstall_2escm",(void*)f_4897},
{"f_6478:chicken_2dinstall_2escm",(void*)f_6478},
{"f_2581:chicken_2dinstall_2escm",(void*)f_2581},
{"f_5274:chicken_2dinstall_2escm",(void*)f_5274},
{"f_4330:chicken_2dinstall_2escm",(void*)f_4330},
{"f_2570:chicken_2dinstall_2escm",(void*)f_2570},
{"f_2577:chicken_2dinstall_2escm",(void*)f_2577},
{"f_6518:chicken_2dinstall_2escm",(void*)f_6518},
{"f_4320:chicken_2dinstall_2escm",(void*)f_4320},
{"f_2563:chicken_2dinstall_2escm",(void*)f_2563},
{"f_4357:chicken_2dinstall_2escm",(void*)f_4357},
{"f_2561:chicken_2dinstall_2escm",(void*)f_2561},
{"f_4354:chicken_2dinstall_2escm",(void*)f_4354},
{"toplevel:chicken_2dinstall_2escm",(void*)C_toplevel},
{"f_4084:chicken_2dinstall_2escm",(void*)f_4084},
{"f_4081:chicken_2dinstall_2escm",(void*)f_4081},
{"f_4348:chicken_2dinstall_2escm",(void*)f_4348},
{"f_6535:chicken_2dinstall_2escm",(void*)f_6535},
{"f_5285:chicken_2dinstall_2escm",(void*)f_5285},
{"f_6541:chicken_2dinstall_2escm",(void*)f_6541},
{"f_6547:chicken_2dinstall_2escm",(void*)f_6547},
{"f_6544:chicken_2dinstall_2escm",(void*)f_6544},
{"f_4888:chicken_2dinstall_2escm",(void*)f_4888},
{"f_6620:chicken_2dinstall_2escm",(void*)f_6620},
{"f_6550:chicken_2dinstall_2escm",(void*)f_6550},
{"f_6563:chicken_2dinstall_2escm",(void*)f_6563},
{"f_5212:chicken_2dinstall_2escm",(void*)f_5212},
{"f_5218:chicken_2dinstall_2escm",(void*)f_5218},
{"f_3300:chicken_2dinstall_2escm",(void*)f_3300},
{"f_5958:chicken_2dinstall_2escm",(void*)f_5958},
{"f_5953:chicken_2dinstall_2escm",(void*)f_5953},
{"f_3328:chicken_2dinstall_2escm",(void*)f_3328},
{"f_5955:chicken_2dinstall_2escm",(void*)f_5955},
{"f_6630:chicken_2dinstall_2escm",(void*)f_6630},
{"f_4646:chicken_2dinstall_2escm",(void*)f_4646},
{"f_3344:chicken_2dinstall_2escm",(void*)f_3344},
{"f_5972:chicken_2dinstall_2escm",(void*)f_5972},
{"f_4964:chicken_2dinstall_2escm",(void*)f_4964},
{"f_4979:chicken_2dinstall_2escm",(void*)f_4979},
{"f_3331:chicken_2dinstall_2escm",(void*)f_3331},
{"f_5992:chicken_2dinstall_2escm",(void*)f_5992},
{"f_5467:chicken_2dinstall_2escm",(void*)f_5467},
{"f_3075:chicken_2dinstall_2escm",(void*)f_3075},
{"f_3079:chicken_2dinstall_2escm",(void*)f_3079},
{"f_4982:chicken_2dinstall_2escm",(void*)f_4982},
{"f_3063:chicken_2dinstall_2escm",(void*)f_3063},
{"f_3066:chicken_2dinstall_2escm",(void*)f_3066},
{"f_3067:chicken_2dinstall_2escm",(void*)f_3067},
{"f_7403:chicken_2dinstall_2escm",(void*)f_7403},
{"f_7409:chicken_2dinstall_2escm",(void*)f_7409},
{"f_7400:chicken_2dinstall_2escm",(void*)f_7400},
{"f_4988:chicken_2dinstall_2escm",(void*)f_4988},
{"f_3986:chicken_2dinstall_2escm",(void*)f_3986},
{"f_7121:chicken_2dinstall_2escm",(void*)f_7121},
{"f_6651:chicken_2dinstall_2escm",(void*)f_6651},
{"f_7426:chicken_2dinstall_2escm",(void*)f_7426},
{"f_4624:chicken_2dinstall_2escm",(void*)f_4624},
{"f_7422:chicken_2dinstall_2escm",(void*)f_7422},
{"f_5642:chicken_2dinstall_2escm",(void*)f_5642},
{"f_5632:chicken_2dinstall_2escm",(void*)f_5632},
{"f_7446:chicken_2dinstall_2escm",(void*)f_7446},
{"f_7442:chicken_2dinstall_2escm",(void*)f_7442},
{"f_3979:chicken_2dinstall_2escm",(void*)f_3979},
{"f_4656:chicken_2dinstall_2escm",(void*)f_4656},
{"f_3965:chicken_2dinstall_2escm",(void*)f_3965},
{"f_3996:chicken_2dinstall_2escm",(void*)f_3996},
{"f_3990:chicken_2dinstall_2escm",(void*)f_3990},
{"f_4608:chicken_2dinstall_2escm",(void*)f_4608},
{"f_7117:chicken_2dinstall_2escm",(void*)f_7117},
{"f_4710:chicken_2dinstall_2escm",(void*)f_4710},
{"f_6093:chicken_2dinstall_2escm",(void*)f_6093},
{"f_6099:chicken_2dinstall_2escm",(void*)f_6099},
{"f_6138:chicken_2dinstall_2escm",(void*)f_6138},
{"f_6130:chicken_2dinstall_2escm",(void*)f_6130},
{"f_4476:chicken_2dinstall_2escm",(void*)f_4476},
{"f_4734:chicken_2dinstall_2escm",(void*)f_4734},
{"f_6148:chicken_2dinstall_2escm",(void*)f_6148},
{"f_4463:chicken_2dinstall_2escm",(void*)f_4463},
{"f_4469:chicken_2dinstall_2escm",(void*)f_4469},
{"f_6078:chicken_2dinstall_2escm",(void*)f_6078},
{"f_5624:chicken_2dinstall_2escm",(void*)f_5624},
{"f_3098:chicken_2dinstall_2escm",(void*)f_3098},
{"f_6053:chicken_2dinstall_2escm",(void*)f_6053},
{"f_5618:chicken_2dinstall_2escm",(void*)f_5618},
{"f_5616:chicken_2dinstall_2escm",(void*)f_5616},
{"f_4533:chicken_2dinstall_2escm",(void*)f_4533},
{"f_5612:chicken_2dinstall_2escm",(void*)f_5612},
{"f_3083:chicken_2dinstall_2escm",(void*)f_3083},
{"f_3088:chicken_2dinstall_2escm",(void*)f_3088},
{"f_6028:chicken_2dinstall_2escm",(void*)f_6028},
{"f_6021:chicken_2dinstall_2escm",(void*)f_6021},
{"f_5605:chicken_2dinstall_2escm",(void*)f_5605},
{"f_5602:chicken_2dinstall_2escm",(void*)f_5602},
{"f_5093:chicken_2dinstall_2escm",(void*)f_5093},
{"f_6030:chicken_2dinstall_2escm",(void*)f_6030},
{"f_7278:chicken_2dinstall_2escm",(void*)f_7278},
{"f_6034:chicken_2dinstall_2escm",(void*)f_6034},
{"f_7287:chicken_2dinstall_2escm",(void*)f_7287},
{"f_5667:chicken_2dinstall_2escm",(void*)f_5667},
{"f_6127:chicken_2dinstall_2escm",(void*)f_6127},
{"f_5098:chicken_2dinstall_2escm",(void*)f_5098},
{"f_6018:chicken_2dinstall_2escm",(void*)f_6018},
{"f_7293:chicken_2dinstall_2escm",(void*)f_7293},
{"f_6012:chicken_2dinstall_2escm",(void*)f_6012},
{"f_6015:chicken_2dinstall_2escm",(void*)f_6015},
{"f_5657:chicken_2dinstall_2escm",(void*)f_5657},
{"f_5659:chicken_2dinstall_2escm",(void*)f_5659},
{"f_5089:chicken_2dinstall_2escm",(void*)f_5089},
{"f_6886:chicken_2dinstall_2escm",(void*)f_6886},
{"f_6883:chicken_2dinstall_2escm",(void*)f_6883},
{"f_5060:chicken_2dinstall_2escm",(void*)f_5060},
{"f_6282:chicken_2dinstall_2escm",(void*)f_6282},
{"f_5896:chicken_2dinstall_2escm",(void*)f_5896},
{"f_2970:chicken_2dinstall_2escm",(void*)f_2970},
{"f_5894:chicken_2dinstall_2escm",(void*)f_5894},
{"f_5078:chicken_2dinstall_2escm",(void*)f_5078},
{"f_5077:chicken_2dinstall_2escm",(void*)f_5077},
{"f_5073:chicken_2dinstall_2escm",(void*)f_5073},
{"f_5051:chicken_2dinstall_2escm",(void*)f_5051},
{"f_7562:chicken_2dinstall_2escm",(void*)f_7562},
{"f_7569:chicken_2dinstall_2escm",(void*)f_7569},
{"f_6290:chicken_2dinstall_2escm",(void*)f_6290},
{"f_2964:chicken_2dinstall_2escm",(void*)f_2964},
{"f_5882:chicken_2dinstall_2escm",(void*)f_5882},
{"f_2968:chicken_2dinstall_2escm",(void*)f_2968},
{"f_5067:chicken_2dinstall_2escm",(void*)f_5067},
{"f_5040:chicken_2dinstall_2escm",(void*)f_5040},
{"f_7533:chicken_2dinstall_2escm",(void*)f_7533},
{"f_7537:chicken_2dinstall_2escm",(void*)f_7537},
{"f_6263:chicken_2dinstall_2escm",(void*)f_6263},
{"f_5876:chicken_2dinstall_2escm",(void*)f_5876},
{"f_5874:chicken_2dinstall_2escm",(void*)f_5874},
{"f_5871:chicken_2dinstall_2escm",(void*)f_5871},
{"f_5058:chicken_2dinstall_2escm",(void*)f_5058},
{"f_5055:chicken_2dinstall_2escm",(void*)f_5055},
{"f_2689:chicken_2dinstall_2escm",(void*)f_2689},
{"f_2686:chicken_2dinstall_2escm",(void*)f_2686},
{"f_2682:chicken_2dinstall_2escm",(void*)f_2682},
{"f_6270:chicken_2dinstall_2escm",(void*)f_6270},
{"f_6274:chicken_2dinstall_2escm",(void*)f_6274},
{"f_6278:chicken_2dinstall_2escm",(void*)f_6278},
{"f_5045:chicken_2dinstall_2escm",(void*)f_5045},
{"f_7552:chicken_2dinstall_2escm",(void*)f_7552},
{"f_7558:chicken_2dinstall_2escm",(void*)f_7558},
{"f_7521:chicken_2dinstall_2escm",(void*)f_7521},
{"f_7527:chicken_2dinstall_2escm",(void*)f_7527},
{"f_4553:chicken_2dinstall_2escm",(void*)f_4553},
{"f_4506:chicken_2dinstall_2escm",(void*)f_4506},
{"f_4500:chicken_2dinstall_2escm",(void*)f_4500},
{"f_7543:chicken_2dinstall_2escm",(void*)f_7543},
{"f_7540:chicken_2dinstall_2escm",(void*)f_7540},
{"f_4508:chicken_2dinstall_2escm",(void*)f_4508},
{"f_7510:chicken_2dinstall_2escm",(void*)f_7510},
{"f_7519:chicken_2dinstall_2escm",(void*)f_7519},
{"f_7513:chicken_2dinstall_2escm",(void*)f_7513},
{"f_7516:chicken_2dinstall_2escm",(void*)f_7516},
{"f_3411:chicken_2dinstall_2escm",(void*)f_3411},
{"f_3488:chicken_2dinstall_2escm",(void*)f_3488},
{"f_3483:chicken_2dinstall_2escm",(void*)f_3483},
{"f_6212:chicken_2dinstall_2escm",(void*)f_6212},
{"f_3471:chicken_2dinstall_2escm",(void*)f_3471},
{"f_3472:chicken_2dinstall_2escm",(void*)f_3472},
{"f_3477:chicken_2dinstall_2escm",(void*)f_3477},
{"f_5258:chicken_2dinstall_2escm",(void*)f_5258},
{"f_7507:chicken_2dinstall_2escm",(void*)f_7507},
{"f_7504:chicken_2dinstall_2escm",(void*)f_7504},
{"f_5206:chicken_2dinstall_2escm",(void*)f_5206},
{"f_5200:chicken_2dinstall_2escm",(void*)f_5200},
{"f_7361:chicken_2dinstall_2escm",(void*)f_7361},
{"f_7379:chicken_2dinstall_2escm",(void*)f_7379},
{"f_5249:chicken_2dinstall_2escm",(void*)f_5249},
{"f_5242:chicken_2dinstall_2escm",(void*)f_5242},
{"f_7396:chicken_2dinstall_2escm",(void*)f_7396},
{"f_3279:chicken_2dinstall_2escm",(void*)f_3279},
{"f_5165:chicken_2dinstall_2escm",(void*)f_5165},
{"f_6457:chicken_2dinstall_2escm",(void*)f_6457},
{"f_5902:chicken_2dinstall_2escm",(void*)f_5902},
{"f_6453:chicken_2dinstall_2escm",(void*)f_6453},
{"f_6421:chicken_2dinstall_2escm",(void*)f_6421},
{"f_6424:chicken_2dinstall_2escm",(void*)f_6424},
{"f_5188:chicken_2dinstall_2escm",(void*)f_5188},
{"f_5921:chicken_2dinstall_2escm",(void*)f_5921},
{"f_6434:chicken_2dinstall_2escm",(void*)f_6434},
{"f_4912:chicken_2dinstall_2escm",(void*)f_4912},
{"f_5182:chicken_2dinstall_2escm",(void*)f_5182},
{"f_4915:chicken_2dinstall_2escm",(void*)f_4915},
{"f_4021:chicken_2dinstall_2escm",(void*)f_4021},
{"f_5176:chicken_2dinstall_2escm",(void*)f_5176},
{"f_4024:chicken_2dinstall_2escm",(void*)f_4024},
{"f_5911:chicken_2dinstall_2escm",(void*)f_5911},
{"f_3232:chicken_2dinstall_2escm",(void*)f_3232},
{"f_6403:chicken_2dinstall_2escm",(void*)f_6403},
{"f_3238:chicken_2dinstall_2escm",(void*)f_3238},
{"f_4027:chicken_2dinstall_2escm",(void*)f_4027},
{"f_4900:chicken_2dinstall_2escm",(void*)f_4900},
{"f_5171:chicken_2dinstall_2escm",(void*)f_5171},
{"f_4906:chicken_2dinstall_2escm",(void*)f_4906},
{"f_4918:chicken_2dinstall_2escm",(void*)f_4918},
{"f_5949:chicken_2dinstall_2escm",(void*)f_5949},
{"f_5945:chicken_2dinstall_2escm",(void*)f_5945},
{"f_4178:chicken_2dinstall_2escm",(void*)f_4178},
{"f_6418:chicken_2dinstall_2escm",(void*)f_6418},
{"f_5941:chicken_2dinstall_2escm",(void*)f_5941},
{"f_4015:chicken_2dinstall_2escm",(void*)f_4015},
{"f_4012:chicken_2dinstall_2escm",(void*)f_4012},
{"f_4018:chicken_2dinstall_2escm",(void*)f_4018},
{"f_3269:chicken_2dinstall_2escm",(void*)f_3269},
{"f_4932:chicken_2dinstall_2escm",(void*)f_4932},
{"f_3173:chicken_2dinstall_2escm",(void*)f_3173},
{"f_5934:chicken_2dinstall_2escm",(void*)f_5934},
{"f_4193:chicken_2dinstall_2escm",(void*)f_4193},
{"f_4196:chicken_2dinstall_2escm",(void*)f_4196},
{"f_5195:chicken_2dinstall_2escm",(void*)f_5195},
{"f_5198:chicken_2dinstall_2escm",(void*)f_5198},
{"f_3901:chicken_2dinstall_2escm",(void*)f_3901},
{"f_7300:chicken_2dinstall_2escm",(void*)f_7300},
{"f_3904:chicken_2dinstall_2escm",(void*)f_3904},
{"f_3907:chicken_2dinstall_2escm",(void*)f_3907},
{"f_6573:chicken_2dinstall_2escm",(void*)f_6573},
{"f_5192:chicken_2dinstall_2escm",(void*)f_5192},
{"f_4925:chicken_2dinstall_2escm",(void*)f_4925},
{"f_4938:chicken_2dinstall_2escm",(void*)f_4938},
{"f_3164:chicken_2dinstall_2escm",(void*)f_3164},
{"f_7312:chicken_2dinstall_2escm",(void*)f_7312},
{"f_7316:chicken_2dinstall_2escm",(void*)f_7316},
{"f_2509:chicken_2dinstall_2escm",(void*)f_2509},
{"f_2506:chicken_2dinstall_2escm",(void*)f_2506},
{"f_2500:chicken_2dinstall_2escm",(void*)f_2500},
{"f_6586:chicken_2dinstall_2escm",(void*)f_6586},
{"f_4955:chicken_2dinstall_2escm",(void*)f_4955},
{"f_4951:chicken_2dinstall_2escm",(void*)f_4951},
{"f_4929:chicken_2dinstall_2escm",(void*)f_4929},
{"f_4694:chicken_2dinstall_2escm",(void*)f_4694},
{"f_6595:chicken_2dinstall_2escm",(void*)f_6595},
{"f_4944:chicken_2dinstall_2escm",(void*)f_4944},
{"f_6593:chicken_2dinstall_2escm",(void*)f_6593},
{"f_4941:chicken_2dinstall_2escm",(void*)f_4941},
{"f8174:chicken_2dinstall_2escm",(void*)f8174},
{"f8179:chicken_2dinstall_2escm",(void*)f8179},
{"f_6701:chicken_2dinstall_2escm",(void*)f_6701},
{"f_3959:chicken_2dinstall_2escm",(void*)f_3959},
{"f_4003:chicken_2dinstall_2escm",(void*)f_4003},
{"f_4009:chicken_2dinstall_2escm",(void*)f_4009},
{"f8191:chicken_2dinstall_2escm",(void*)f8191},
{"f_5104:chicken_2dinstall_2escm",(void*)f_5104},
{"f8169:chicken_2dinstall_2escm",(void*)f8169},
{"f8164:chicken_2dinstall_2escm",(void*)f8164},
{"f_2724:chicken_2dinstall_2escm",(void*)f_2724},
{"f_2726:chicken_2dinstall_2escm",(void*)f_2726},
{"f_6731:chicken_2dinstall_2escm",(void*)f_6731},
{"f_5367:chicken_2dinstall_2escm",(void*)f_5367},
{"f8139:chicken_2dinstall_2escm",(void*)f8139},
{"f_5363:chicken_2dinstall_2escm",(void*)f_5363},
{"f_4799:chicken_2dinstall_2escm",(void*)f_4799},
{"f_4796:chicken_2dinstall_2escm",(void*)f_4796},
{"f8132:chicken_2dinstall_2escm",(void*)f8132},
{"f_5455:chicken_2dinstall_2escm",(void*)f_5455},
{"f_5458:chicken_2dinstall_2escm",(void*)f_5458},
{"f_4681:chicken_2dinstall_2escm",(void*)f_4681},
{"f_5452:chicken_2dinstall_2escm",(void*)f_5452},
{"f_3910:chicken_2dinstall_2escm",(void*)f_3910},
{"f_3913:chicken_2dinstall_2escm",(void*)f_3913},
{"f_3916:chicken_2dinstall_2escm",(void*)f_3916},
{"f_3919:chicken_2dinstall_2escm",(void*)f_3919},
{"f_2524:chicken_2dinstall_2escm",(void*)f_2524},
{"f_4790:chicken_2dinstall_2escm",(void*)f_4790},
{"f8186:chicken_2dinstall_2escm",(void*)f8186},
{"f_4110:chicken_2dinstall_2escm",(void*)f_4110},
{"f_3892:chicken_2dinstall_2escm",(void*)f_3892},
{"f_3898:chicken_2dinstall_2escm",(void*)f_3898},
{"f_3057:chicken_2dinstall_2escm",(void*)f_3057},
{"f_5449:chicken_2dinstall_2escm",(void*)f_5449},
{"f_5384:chicken_2dinstall_2escm",(void*)f_5384},
{"f8116:chicken_2dinstall_2escm",(void*)f8116},
{"f8111:chicken_2dinstall_2escm",(void*)f8111},
{"f_2512:chicken_2dinstall_2escm",(void*)f_2512},
{"f_4782:chicken_2dinstall_2escm",(void*)f_4782},
{"f8159:chicken_2dinstall_2escm",(void*)f8159},
{"f_5382:chicken_2dinstall_2escm",(void*)f_5382},
{"f8154:chicken_2dinstall_2escm",(void*)f8154},
{"f_4101:chicken_2dinstall_2escm",(void*)f_4101},
{"f_4104:chicken_2dinstall_2escm",(void*)f_4104},
{"f_3882:chicken_2dinstall_2escm",(void*)f_3882},
{"f_6760:chicken_2dinstall_2escm",(void*)f_6760},
{"f_6764:chicken_2dinstall_2escm",(void*)f_6764},
{"f_2484:chicken_2dinstall_2escm",(void*)f_2484},
{"f_2487:chicken_2dinstall_2escm",(void*)f_2487},
{"f_3111:chicken_2dinstall_2escm",(void*)f_3111},
{"f_3870:chicken_2dinstall_2escm",(void*)f_3870},
{"f_3878:chicken_2dinstall_2escm",(void*)f_3878},
{"f_3036:chicken_2dinstall_2escm",(void*)f_3036},
{"f_2474:chicken_2dinstall_2escm",(void*)f_2474},
{"f_3038:chicken_2dinstall_2escm",(void*)f_3038},
{"f_2478:chicken_2dinstall_2escm",(void*)f_2478},
{"f_2751:chicken_2dinstall_2escm",(void*)f_2751},
{"f_3860:chicken_2dinstall_2escm",(void*)f_3860},
{"f_3868:chicken_2dinstall_2escm",(void*)f_3868},
{"f_3026:chicken_2dinstall_2escm",(void*)f_3026},
{"f8126:chicken_2dinstall_2escm",(void*)f8126},
{"f_5418:chicken_2dinstall_2escm",(void*)f_5418},
{"f8121:chicken_2dinstall_2escm",(void*)f8121},
{"f_3019:chicken_2dinstall_2escm",(void*)f_3019},
{"f_5403:chicken_2dinstall_2escm",(void*)f_5403},
{"f_3016:chicken_2dinstall_2escm",(void*)f_3016},
{"f_2457:chicken_2dinstall_2escm",(void*)f_2457},
{"f_5408:chicken_2dinstall_2escm",(void*)f_5408},
{"f_5696:chicken_2dinstall_2escm",(void*)f_5696},
{"f_5691:chicken_2dinstall_2escm",(void*)f_5691},
{"f_3840:chicken_2dinstall_2escm",(void*)f_3840},
{"f_3723:chicken_2dinstall_2escm",(void*)f_3723},
{"f_5688:chicken_2dinstall_2escm",(void*)f_5688},
{"f_5681:chicken_2dinstall_2escm",(void*)f_5681},
{"f_6976:chicken_2dinstall_2escm",(void*)f_6976},
{"f_2713:chicken_2dinstall_2escm",(void*)f_2713},
{"f_5671:chicken_2dinstall_2escm",(void*)f_5671},
{"f_3714:chicken_2dinstall_2escm",(void*)f_3714},
{"f_3718:chicken_2dinstall_2escm",(void*)f_3718},
{"f_6909:chicken_2dinstall_2escm",(void*)f_6909},
{"f_6008:chicken_2dinstall_2escm",(void*)f_6008},
{"f_2700:chicken_2dinstall_2escm",(void*)f_2700},
{"f_6912:chicken_2dinstall_2escm",(void*)f_6912},
{"f_2490:chicken_2dinstall_2escm",(void*)f_2490},
{"f_5546:chicken_2dinstall_2escm",(void*)f_5546},
{"f_5309:chicken_2dinstall_2escm",(void*)f_5309},
{"f_2901:chicken_2dinstall_2escm",(void*)f_2901},
{"f_2773:chicken_2dinstall_2escm",(void*)f_2773},
{"f_5542:chicken_2dinstall_2escm",(void*)f_5542},
{"f_3735:chicken_2dinstall_2escm",(void*)f_3735},
{"f_3739:chicken_2dinstall_2escm",(void*)f_3739},
{"f_3760:chicken_2dinstall_2escm",(void*)f_3760},
{"f_5530:chicken_2dinstall_2escm",(void*)f_5530},
{"f_5533:chicken_2dinstall_2escm",(void*)f_5533},
{"f_2768:chicken_2dinstall_2escm",(void*)f_2768},
{"f_3765:chicken_2dinstall_2escm",(void*)f_3765},
{"f_3757:chicken_2dinstall_2escm",(void*)f_3757},
{"f_6942:chicken_2dinstall_2escm",(void*)f_6942},
{"f_3702:chicken_2dinstall_2escm",(void*)f_3702},
{"f_3708:chicken_2dinstall_2escm",(void*)f_3708},
{"f_6956:chicken_2dinstall_2escm",(void*)f_6956},
{"f_4598:chicken_2dinstall_2escm",(void*)f_4598},
{"f_3687:chicken_2dinstall_2escm",(void*)f_3687},
{"f_2949:chicken_2dinstall_2escm",(void*)f_2949},
{"f_4431:chicken_2dinstall_2escm",(void*)f_4431},
{"f_3679:chicken_2dinstall_2escm",(void*)f_3679},
{"f_3673:chicken_2dinstall_2escm",(void*)f_3673},
{"f_6241:chicken_2dinstall_2escm",(void*)f_6241},
{"f_2934:chicken_2dinstall_2escm",(void*)f_2934},
{"f_2939:chicken_2dinstall_2escm",(void*)f_2939},
{"f_4421:chicken_2dinstall_2escm",(void*)f_4421},
{"f_5527:chicken_2dinstall_2escm",(void*)f_5527},
{"f_6259:chicken_2dinstall_2escm",(void*)f_6259},
{"f_6253:chicken_2dinstall_2escm",(void*)f_6253},
{"f_7577:chicken_2dinstall_2escm",(void*)f_7577},
{"f_4459:chicken_2dinstall_2escm",(void*)f_4459},
{"f_7571:chicken_2dinstall_2escm",(void*)f_7571},
{"f_6224:chicken_2dinstall_2escm",(void*)f_6224},
{"f_6222:chicken_2dinstall_2escm",(void*)f_6222},
{"f_3744:chicken_2dinstall_2escm",(void*)f_3744},
{"f_3569:chicken_2dinstall_2escm",(void*)f_3569},
{"f_4446:chicken_2dinstall_2escm",(void*)f_4446},
{"f_3551:chicken_2dinstall_2escm",(void*)f_3551},
{"f_4585:chicken_2dinstall_2escm",(void*)f_4585},
{"f_3580:chicken_2dinstall_2escm",(void*)f_3580},
{"f_3586:chicken_2dinstall_2escm",(void*)f_3586},
{"f_4575:chicken_2dinstall_2escm",(void*)f_4575},
{"f_5566:chicken_2dinstall_2escm",(void*)f_5566},
{"f_7232:chicken_2dinstall_2escm",(void*)f_7232},
{"f_4410:chicken_2dinstall_2escm",(void*)f_4410},
{"f_3575:chicken_2dinstall_2escm",(void*)f_3575},
{"f_4416:chicken_2dinstall_2escm",(void*)f_4416},
{"f_5559:chicken_2dinstall_2escm",(void*)f_5559},
{"f_4269:chicken_2dinstall_2escm",(void*)f_4269},
{"f_4402:chicken_2dinstall_2escm",(void*)f_4402},
{"f_4405:chicken_2dinstall_2escm",(void*)f_4405},
{"f_3521:chicken_2dinstall_2escm",(void*)f_3521},
{"f_7585:chicken_2dinstall_2escm",(void*)f_7585},
{"f_5507:chicken_2dinstall_2escm",(void*)f_5507},
{"f_5509:chicken_2dinstall_2escm",(void*)f_5509},
{"f_5503:chicken_2dinstall_2escm",(void*)f_5503},
{"f_3515:chicken_2dinstall_2escm",(void*)f_3515},
{"f_7589:chicken_2dinstall_2escm",(void*)f_7589},
{"f_5020:chicken_2dinstall_2escm",(void*)f_5020},
{"f_6375:chicken_2dinstall_2escm",(void*)f_6375},
{"f_6378:chicken_2dinstall_2escm",(void*)f_6378},
{"f_4283:chicken_2dinstall_2escm",(void*)f_4283},
{"f_4289:chicken_2dinstall_2escm",(void*)f_4289},
{"f_5033:chicken_2dinstall_2escm",(void*)f_5033},
{"f_5032:chicken_2dinstall_2escm",(void*)f_5032},
{"f_5037:chicken_2dinstall_2escm",(void*)f_5037},
{"f_4278:chicken_2dinstall_2escm",(void*)f_4278},
{"f_5023:chicken_2dinstall_2escm",(void*)f_5023},
{"f_5026:chicken_2dinstall_2escm",(void*)f_5026},
{"f_5000:chicken_2dinstall_2escm",(void*)f_5000},
{"f_6393:chicken_2dinstall_2escm",(void*)f_6393},
{"f_7206:chicken_2dinstall_2escm",(void*)f_7206},
{"f_5013:chicken_2dinstall_2escm",(void*)f_5013},
{"f_5012:chicken_2dinstall_2escm",(void*)f_5012},
{"f_5017:chicken_2dinstall_2escm",(void*)f_5017},
{"f_4293:chicken_2dinstall_2escm",(void*)f_4293},
{"f_4296:chicken_2dinstall_2escm",(void*)f_4296},
{"f_5009:chicken_2dinstall_2escm",(void*)f_5009},
{"f_5006:chicken_2dinstall_2escm",(void*)f_5006},
{"f_5003:chicken_2dinstall_2escm",(void*)f_5003},
{"f_3360:chicken_2dinstall_2escm",(void*)f_3360},
{"f_4371:chicken_2dinstall_2escm",(void*)f_4371},
{"f_6383:chicken_2dinstall_2escm",(void*)f_6383},
{"f_4363:chicken_2dinstall_2escm",(void*)f_4363},
{"f_4360:chicken_2dinstall_2escm",(void*)f_4360},
{"f_4366:chicken_2dinstall_2escm",(void*)f_4366},
{"f_4399:chicken_2dinstall_2escm",(void*)f_4399},
{"f_3388:chicken_2dinstall_2escm",(void*)f_3388},
{"f_4393:chicken_2dinstall_2escm",(void*)f_4393},
{"f_5702:chicken_2dinstall_2escm",(void*)f_5702},
{"f_3373:chicken_2dinstall_2escm",(void*)f_3373},
{"f_4381:chicken_2dinstall_2escm",(void*)f_4381},
{"f_4386:chicken_2dinstall_2escm",(void*)f_4386},
{"f_3592:chicken_2dinstall_2escm",(void*)f_3592},
{"f_7353:chicken_2dinstall_2escm",(void*)f_7353},
{"f_4201:chicken_2dinstall_2escm",(void*)f_4201},
{"f_5725:chicken_2dinstall_2escm",(void*)f_5725},
{"f_3392:chicken_2dinstall_2escm",(void*)f_3392},
{"f_4831:chicken_2dinstall_2escm",(void*)f_4831},
{"f_4834:chicken_2dinstall_2escm",(void*)f_4834},
{"f_4838:chicken_2dinstall_2escm",(void*)f_4838},
{"f_5711:chicken_2dinstall_2escm",(void*)f_5711},
{"f_5128:chicken_2dinstall_2escm",(void*)f_5128},
{"f_5122:chicken_2dinstall_2escm",(void*)f_5122},
{"f_5120:chicken_2dinstall_2escm",(void*)f_5120},
{"f_5746:chicken_2dinstall_2escm",(void*)f_5746},
{"f_4861:chicken_2dinstall_2escm",(void*)f_4861},
{"f_5744:chicken_2dinstall_2escm",(void*)f_5744},
{"f_4867:chicken_2dinstall_2escm",(void*)f_4867},
{"f_2863:chicken_2dinstall_2escm",(void*)f_2863},
{"f_5114:chicken_2dinstall_2escm",(void*)f_5114},
{"f_3422:chicken_2dinstall_2escm",(void*)f_3422},
{"f_2860:chicken_2dinstall_2escm",(void*)f_2860},
{"f_5117:chicken_2dinstall_2escm",(void*)f_5117},
{"f_5110:chicken_2dinstall_2escm",(void*)f_5110},
{"f_4857:chicken_2dinstall_2escm",(void*)f_4857},
{"f_5730:chicken_2dinstall_2escm",(void*)f_5730},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|hiding nonexported module bindings: main#+default-repository-files+ 
o|hiding nonexported module bindings: main#constant159 
o|hiding nonexported module bindings: main#constant163 
o|hiding nonexported module bindings: main#*program-path* 
o|hiding nonexported module bindings: main#*keep* 
o|hiding nonexported module bindings: main#*keep-existing* 
o|hiding nonexported module bindings: main#*force* 
o|hiding nonexported module bindings: main#*run-tests* 
o|hiding nonexported module bindings: main#*retrieve-only* 
o|hiding nonexported module bindings: main#*no-install* 
o|hiding nonexported module bindings: main#*username* 
o|hiding nonexported module bindings: main#*password* 
o|hiding nonexported module bindings: main#*default-sources* 
o|hiding nonexported module bindings: main#*default-location* 
o|hiding nonexported module bindings: main#*default-transport* 
o|hiding nonexported module bindings: main#*windows-shell* 
o|hiding nonexported module bindings: main#*proxy-host* 
o|hiding nonexported module bindings: main#*proxy-port* 
o|hiding nonexported module bindings: main#*proxy-user-pass* 
o|hiding nonexported module bindings: main#*running-test* 
o|hiding nonexported module bindings: main#*mappings* 
o|hiding nonexported module bindings: main#*deploy* 
o|hiding nonexported module bindings: main#*trunk* 
o|hiding nonexported module bindings: main#*csc-features* 
o|hiding nonexported module bindings: main#*csc-nonfeatures* 
o|hiding nonexported module bindings: main#*prefix* 
o|hiding nonexported module bindings: main#*aliases* 
o|hiding nonexported module bindings: main#*cross-chicken* 
o|hiding nonexported module bindings: main#*host-extension* 
o|hiding nonexported module bindings: main#*target-extension* 
o|hiding nonexported module bindings: main#*debug-setup* 
o|hiding nonexported module bindings: main#*keep-going* 
o|hiding nonexported module bindings: main#*override* 
o|hiding nonexported module bindings: main#*reinstall* 
o|hiding nonexported module bindings: main#*show-depends* 
o|hiding nonexported module bindings: main#*show-foreign-depends* 
o|hiding nonexported module bindings: main#*hacks* 
o|hiding nonexported module bindings: main#repo-path 
o|hiding nonexported module bindings: main#get-prefix 
o|hiding nonexported module bindings: main#load-defaults 
o|hiding nonexported module bindings: main#resolve-location 
o|hiding nonexported module bindings: main#known-default-sources 
o|hiding nonexported module bindings: main#deps 
o|hiding nonexported module bindings: main#init-repository 
o|hiding nonexported module bindings: main#ext-version 
o|hiding nonexported module bindings: main#meta-dependencies 
o|hiding nonexported module bindings: main#check-dependency 
o|hiding nonexported module bindings: main#outdated-dependencies 
o|hiding nonexported module bindings: main#*eggs+dirs+vers* 
o|hiding nonexported module bindings: main#*dependencies* 
o|hiding nonexported module bindings: main#*checked* 
o|hiding nonexported module bindings: main#*csi* 
o|hiding nonexported module bindings: main#try-extension 
o|hiding nonexported module bindings: main#with-default-sources 
o|hiding nonexported module bindings: main#try-default-sources 
o|hiding nonexported module bindings: main#make-replace-extension-question 
o|hiding nonexported module bindings: main#override-version 
o|hiding nonexported module bindings: main#show-depends 
o|hiding nonexported module bindings: main#retrieve 
o|hiding nonexported module bindings: main#check-platform 
o|hiding nonexported module bindings: main#back-slash->forward-slash 
o|hiding nonexported module bindings: main#make-install-command 
o|hiding nonexported module bindings: main#keep-going 
o|hiding nonexported module bindings: main#install 
o|hiding nonexported module bindings: main#delete-stale-binaries 
o|hiding nonexported module bindings: main#cleanup 
o|hiding nonexported module bindings: main#update-db 
o|hiding nonexported module bindings: main#apply-mappings 
o|hiding nonexported module bindings: main#scan-directory 
o|hiding nonexported module bindings: main#$system 
o|hiding nonexported module bindings: main#installed-extensions 
o|hiding nonexported module bindings: main#list-available-extensions 
o|hiding nonexported module bindings: main#command 
o|hiding nonexported module bindings: main#usage 
o|hiding nonexported module bindings: main#setup-proxy 
o|hiding nonexported module bindings: main#info->egg 
o|hiding nonexported module bindings: main#*short-options* 
o|hiding nonexported module bindings: main#main 
S|applied compiler syntax:
S|  fprintf		1
S|  printf		1
S|  map		10
S|  for-each		12
S|  sprintf		12
o|eliminated procedure checks: 142 
o|specializations:
o|  1 (> fixnum fixnum)
o|  1 (char=? char char)
o|  1 (string-ref string fixnum)
o|  2 (string-length string)
o|  9 (cddr (pair * pair))
o|  1 (zero? fixnum)
o|  1 (string-append string string)
o|  5 (current-error-port)
o|  46 (string=? string string)
o|  24 (car pair)
o|  11 (##sys#check-list (or pair list) *)
o|  2 (= fixnum fixnum)
o|  49 (cdr pair)
o|  8 (eqv? * (not float))
o|  2 (positive? fixnum)
o|  4 (length list)
o|  14 (##sys#check-output-port * * *)
(o e)|safe calls: 747 
(o e)|dropped branches: 1 
o|Removed `not' forms: 16 
o|inlining procedure: k2459 
o|propagated global variable: r24607596 main#*prefix* 
o|inlining procedure: k2459 
o|substituted constant variable: a2480 
o|substituted constant variable: a2481 
o|inlining procedure: k2491 
o|substituted constant variable: a2502 
o|substituted constant variable: a2503 
o|inlining procedure: k2491 
o|merged explicitly consed rest parameter: tmp234235 
o|inlining procedure: k2529 
o|contracted procedure: k2544 
o|inlining procedure: k2529 
o|propagated global variable: r25307601 main#*prefix* 
o|inlining procedure: k2975 
o|contracted procedure: "(chicken-install.scm:185) g388389" 
o|inlining procedure: k2975 
o|inlining procedure: k3046 
o|inlining procedure: k3046 
o|inlining procedure: k3113 
o|inlining procedure: k3113 
o|contracted procedure: "(chicken-install.scm:220) g450451" 
o|inlining procedure: k3142 
o|inlining procedure: k3142 
o|inlining procedure: k3168 
o|inlining procedure: k3168 
o|inlining procedure: k3207 
o|contracted procedure: k3223 
o|inlining procedure: k3220 
o|inlining procedure: k3220 
o|inlining procedure: k3207 
o|inlining procedure: k3249 
o|inlining procedure: k3259 
o|inlining procedure: k3259 
o|inlining procedure: k3249 
o|inlining procedure: k3281 
o|inlining procedure: k3281 
o|inlining procedure: k3302 
o|inlining procedure: k3302 
o|inlining procedure: k3311 
o|inlining procedure: k3311 
o|contracted procedure: k3317 
o|inlining procedure: k3323 
o|contracted procedure: k3335 
o|contracted procedure: k3350 
o|inlining procedure: k3347 
o|inlining procedure: k3347 
o|substituted constant variable: a3356 
o|inlining procedure: k3361 
o|inlining procedure: k3361 
o|inlining procedure: k3323 
o|inlining procedure: k3429 
o|inlining procedure: k3429 
o|substituted constant variable: a3450 
o|inlining procedure: k3725 
o|inlining procedure: k3725 
o|inlining procedure: k3787 
o|inlining procedure: k3787 
o|inlining procedure: k3801 
o|inlining procedure: k3801 
o|contracted procedure: "(chicken-install.scm:344) main#known-default-sources" 
o|inlining procedure: k2992 
o|inlining procedure: k3014 
o|inlining procedure: k3014 
o|propagated global variable: r30157653 main#*default-location* 
o|inlining procedure: k2992 
o|propagated global variable: r29937655 main#*default-sources* 
o|merged explicitly consed rest parameter: type684 
o|propagated global variable: out690694 ##sys#standard-output 
o|substituted constant variable: a4089 
o|substituted constant variable: a4090 
o|inlining procedure: k4105 
o|inlining procedure: k4114 
o|inlining procedure: k4114 
o|inlining procedure: k4137 
o|contracted procedure: "(chicken-install.scm:435) g723730" 
o|inlining procedure: k4137 
o|inlining procedure: k4105 
o|inlining procedure: k4203 
o|inlining procedure: k4203 
o|propagated global variable: g712714 main#*eggs+dirs+vers* 
o|inlining procedure: k4224 
o|inlining procedure: k4224 
o|substituted constant variable: a4237 
o|substituted constant variable: a4239 
o|inlining procedure: k4331 
o|inlining procedure: k4331 
o|inlining procedure: k4577 
o|contracted procedure: "(chicken-install.scm:459) g803810" 
o|inlining procedure: k4336 
o|inlining procedure: k4336 
o|contracted procedure: "(chicken-install.scm:470) main#outdated-dependencies" 
o|inlining procedure: k3490 
o|inlining procedure: k3490 
o|inlining procedure: k3531 
o|inlining procedure: k3531 
o|inlining procedure: k3543 
o|inlining procedure: k3543 
o|propagated global variable: g514516 main#*hacks* 
o|contracted procedure: "(chicken-install.scm:295) main#meta-dependencies" 
o|inlining procedure: k3198 
o|inlining procedure: k3198 
o|inlining procedure: k4394 
o|inlining procedure: k4423 
o|contracted procedure: "(chicken-install.scm:492) g863870" 
o|inlining procedure: k4423 
o|inlining procedure: k4394 
o|propagated global variable: tmp856858 main#*force* 
o|inlining procedure: k4450 
o|propagated global variable: tmp856858 main#*force* 
o|inlining procedure: k4450 
o|contracted procedure: "(chicken-install.scm:487) main#make-replace-extension-question" 
o|inlining procedure: k3880 
o|inlining procedure: k3880 
o|substituted constant variable: a3894 
o|substituted constant variable: a3895 
o|inlining procedure: k3875 
o|inlining procedure: k3875 
o|inlining procedure: k4510 
o|contracted procedure: "(chicken-install.scm:475) g835844" 
o|inlining procedure: k4491 
o|inlining procedure: k4491 
o|inlining procedure: k4510 
o|contracted procedure: "(chicken-install.scm:467) main#check-platform" 
o|inlining procedure: k4629 
o|inlining procedure: k4629 
o|inlining procedure: k4648 
o|inlining procedure: k4648 
o|contracted procedure: k4666 
o|inlining procedure: k4676 
o|contracted procedure: k4685 
o|inlining procedure: k4676 
o|inlining procedure: k4705 
o|inlining procedure: k4705 
o|inlining procedure: k4716 
o|contracted procedure: k4725 
o|inlining procedure: k4716 
o|inlining procedure: k4577 
o|propagated global variable: g809811 main#*eggs+dirs+vers* 
o|inlining procedure: k4600 
o|contracted procedure: "(chicken-install.scm:442) g761768" 
o|inlining procedure: k4257 
o|contracted procedure: "(chicken-install.scm:443) g777778" 
o|inlining procedure: k4257 
o|contracted procedure: "(chicken-install.scm:451) main#try-default-sources" 
o|contracted procedure: k3824 
o|inlining procedure: k3821 
o|contracted procedure: "(chicken-install.scm:374) main#try-extension" 
o|inlining procedure: k3597 
o|inlining procedure: k3597 
o|inlining procedure: k3621 
o|inlining procedure: k3621 
o|inlining procedure: k3639 
o|inlining procedure: k3639 
o|inlining procedure: k3648 
o|inlining procedure: k3648 
o|inlining procedure: k3657 
o|inlining procedure: k3657 
o|contracted procedure: k3692 
o|propagated global variable: r3693 main#*retrieve-only* 
o|inlining procedure: k3842 
o|inlining procedure: k3842 
o|inlining procedure: k3821 
o|contracted procedure: "(chicken-install.scm:450) main#override-version" 
o|inlining procedure: k3988 
o|substituted constant variable: a4005 
o|substituted constant variable: a4006 
o|inlining procedure: k3988 
o|inlining procedure: k3983 
o|inlining procedure: k3983 
o|inlining procedure: k4069 
o|inlining procedure: k4069 
o|inlining procedure: k4600 
o|inlining procedure: k4767 
o|inlining procedure: k4767 
o|inlining procedure: k5561 
o|inlining procedure: k5561 
o|inlining procedure: k5960 
o|inlining procedure: k5960 
o|inlining procedure: k5982 
o|inlining procedure: k5982 
o|inlining procedure: k6016 
o|inlining procedure: k6016 
o|inlining procedure: k6035 
o|contracted procedure: "(chicken-install.scm:734) g14301431" 
o|inlining procedure: k6055 
o|inlining procedure: k6055 
o|inlining procedure: k6035 
o|inlining procedure: k6172 
o|inlining procedure: k6172 
o|inlining procedure: k6188 
o|inlining procedure: k6188 
o|merged explicitly consed rest parameter: args1525 
o|inlining procedure: k6322 
o|inlining procedure: k6337 
o|inlining procedure: k6337 
o|inlining procedure: k6322 
o|inlining procedure: k6358 
o|inlining procedure: k6358 
o|inlining procedure: k7548 
o|inlining procedure: k7548 
o|contracted procedure: "(chicken-install.scm:1084) main#main" 
o|inlining procedure: k6385 
o|inlining procedure: k6404 
o|contracted procedure: "(chicken-install.scm:872) main#update-db" 
o|inlining procedure: k5634 
o|contracted procedure: "(chicken-install.scm:718) g13801387" 
o|inlining procedure: k5634 
o|inlining procedure: k5748 
o|inlining procedure: k5748 
o|inlining procedure: k5782 
o|inlining procedure: k5782 
o|inlining procedure: k5913 
o|contracted procedure: "(chicken-install.scm:689) g12591266" 
o|substituted constant variable: a5861 
o|substituted constant variable: a5862 
o|inlining procedure: k5913 
o|inlining procedure: k6404 
o|contracted procedure: "(chicken-install.scm:873) main#scan-directory" 
o|inlining procedure: k6140 
o|contracted procedure: "(chicken-install.scm:745) g14671474" 
o|inlining procedure: k6140 
o|inlining procedure: k6425 
o|contracted procedure: "(chicken-install.scm:909) main#list-available-extensions" 
o|inlining procedure: k6292 
o|inlining procedure: k6292 
o|inlining procedure: k6425 
o|consed rest parameter at call site: "(chicken-install.scm:912) main#show-depends" 2 
o|inlining procedure: k6441 
o|consed rest parameter at call site: "(chicken-install.scm:914) main#show-depends" 2 
o|inlining procedure: k6441 
o|contracted procedure: "(chicken-install.scm:916) main#install" 
o|inlining procedure: k4983 
o|consed rest parameter at call site: "(chicken-install.scm:653) main#command" 2 
o|inlining procedure: k5068 
o|inlining procedure: k5068 
o|contracted procedure: k5151 
o|inlining procedure: k5148 
o|inlining procedure: k5148 
o|inlining procedure: k5160 
o|inlining procedure: k5160 
o|contracted procedure: "(chicken-install.scm:638) main#make-install-command" 
o|substituted constant variable: a4792 
o|substituted constant variable: a4793 
o|substituted constant variable: a4869 
o|substituted constant variable: a4870 
o|substituted constant variable: a4890 
o|substituted constant variable: a4891 
o|substituted constant variable: a4908 
o|substituted constant variable: a4909 
o|consed rest parameter at call site: "(chicken-install.scm:552) main#get-prefix" 1 
o|substituted constant variable: a4934 
o|substituted constant variable: a4935 
o|consed rest parameter at call site: "(chicken-install.scm:547) main#get-prefix" 1 
o|inlining procedure: k4956 
o|inlining procedure: k4956 
o|propagated global variable: tmp921923 main#*deploy* 
o|inlining procedure: k4965 
o|propagated global variable: tmp921923 main#*deploy* 
o|inlining procedure: k4965 
o|contracted procedure: "(chicken-install.scm:637) main#delete-stale-binaries" 
o|inlining procedure: k5250 
o|inlining procedure: k5250 
o|consed rest parameter at call site: "(chicken-install.scm:623) main#command" 2 
o|inlining procedure: k5321 
o|inlining procedure: k5321 
o|inlining procedure: k5338 
o|inlining procedure: k5338 
o|substituted constant variable: a5368 
o|substituted constant variable: a5369 
o|contracted procedure: k5370 
o|inlining procedure: k4983 
o|inlining procedure: k5410 
o|inlining procedure: k5410 
o|propagated global variable: out10831087 ##sys#standard-error 
o|substituted constant variable: a5445 
o|substituted constant variable: a5446 
o|propagated global variable: out10831087 ##sys#standard-error 
o|inlining procedure: k5469 
o|contracted procedure: "(chicken-install.scm:592) g10561065" 
o|inlining procedure: k5469 
o|inlining procedure: k5515 
o|inlining procedure: k5515 
o|inlining procedure: k6461 
o|inlining procedure: k6461 
o|inlining procedure: k6473 
o|inlining procedure: k6495 
o|inlining procedure: k6495 
o|propagated global variable: tmp15651567 main#*force* 
o|propagated global variable: tmp15651567 main#*force* 
o|substituted constant variable: a6537 
o|substituted constant variable: a6538 
o|contracted procedure: "(chicken-install.scm:878) main#installed-extensions" 
o|inlining procedure: k6238 
o|inlining procedure: k6238 
o|inlining procedure: k6473 
o|contracted procedure: k6558 
o|inlining procedure: k6564 
o|inlining procedure: k6597 
o|contracted procedure: "(chicken-install.scm:892) g16201629" 
o|inlining procedure: k6597 
o|inlining procedure: k6564 
o|contracted procedure: "(chicken-install.scm:875) main#load-defaults" 
o|contracted procedure: k2574 
o|inlining procedure: k2585 
o|contracted procedure: k2594 
o|contracted procedure: k2603 
o|inlining procedure: k2600 
o|inlining procedure: k2600 
o|substituted constant variable: a2614 
o|substituted constant variable: a2615 
o|inlining procedure: k2585 
o|inlining procedure: k2668 
o|inlining procedure: k2728 
o|inlining procedure: k2728 
o|inlining procedure: k2668 
o|inlining procedure: k2775 
o|inlining procedure: k2775 
o|inlining procedure: k2798 
o|inlining procedure: k2798 
o|substituted constant variable: a2807 
o|inlining procedure: k2820 
o|inlining procedure: k2820 
o|inlining procedure: k2851 
o|inlining procedure: k2851 
o|substituted constant variable: a2910 
o|substituted constant variable: a2912 
o|substituted constant variable: a2914 
o|substituted constant variable: a2916 
o|substituted constant variable: a2918 
o|substituted constant variable: a2920 
o|inlining procedure: k2568 
o|inlining procedure: k2941 
o|inlining procedure: k2941 
o|inlining procedure: k2568 
o|inlining procedure: k6634 
o|inlining procedure: k6634 
o|inlining procedure: k6385 
o|substituted constant variable: a6659 
o|inlining procedure: k6655 
o|inlining procedure: k6655 
o|substituted constant variable: a6670 
o|substituted constant variable: a6681 
o|inlining procedure: k6677 
o|inlining procedure: k6677 
o|substituted constant variable: a6695 
o|substituted constant variable: a6711 
o|inlining procedure: k6707 
o|inlining procedure: k6707 
o|substituted constant variable: a6725 
o|substituted constant variable: a6754 
o|inlining procedure: k6750 
o|inlining procedure: k6750 
o|substituted constant variable: a6787 
o|substituted constant variable: a6833 
o|inlining procedure: k6829 
o|inlining procedure: k6829 
o|substituted constant variable: a6848 
o|substituted constant variable: a6863 
o|inlining procedure: k6859 
o|inlining procedure: k6859 
o|substituted constant variable: a6877 
o|contracted procedure: "(chicken-install.scm:968) main#init-repository" 
o|consed rest parameter at call site: "(chicken-install.scm:217) main#command" 2 
o|substituted constant variable: main#+default-repository-files+ 
o|inlining procedure: k3090 
o|inlining procedure: k3090 
o|substituted constant variable: main#+default-repository-files+ 
o|substituted constant variable: a6905 
o|inlining procedure: k6902 
o|inlining procedure: k6902 
o|substituted constant variable: a6935 
o|substituted constant variable: a6972 
o|inlining procedure: k6969 
o|inlining procedure: k6969 
o|substituted constant variable: a7006 
o|substituted constant variable: a7017 
o|inlining procedure: k7014 
o|inlining procedure: k7014 
o|substituted constant variable: a7028 
o|substituted constant variable: a7039 
o|inlining procedure: k7036 
o|inlining procedure: k7036 
o|substituted constant variable: a7050 
o|substituted constant variable: a7061 
o|inlining procedure: k7058 
o|inlining procedure: k7058 
o|substituted constant variable: a7087 
o|substituted constant variable: a7113 
o|inlining procedure: k7110 
o|inlining procedure: k7110 
o|substituted constant variable: a7144 
o|substituted constant variable: a7158 
o|inlining procedure: k7155 
o|inlining procedure: k7155 
o|substituted constant variable: a7169 
o|substituted constant variable: a7180 
o|inlining procedure: k7177 
o|inlining procedure: k7177 
o|substituted constant variable: a7191 
o|substituted constant variable: a7202 
o|inlining procedure: k7199 
o|inlining procedure: k7199 
o|substituted constant variable: a7228 
o|substituted constant variable: a7254 
o|inlining procedure: k7251 
o|inlining procedure: k7251 
o|substituted constant variable: a7265 
o|inlining procedure: k7273 
o|inlining procedure: k7288 
o|inlining procedure: k7318 
o|contracted procedure: "(chicken-install.scm:1046) g17561765" 
o|inlining procedure: k7318 
o|inlining procedure: k7288 
o|substituted constant variable: main#*short-options* 
o|substituted constant variable: a7369 
o|inlining procedure: k7273 
o|inlining procedure: k7401 
o|inlining procedure: k7401 
o|inlining procedure: k7423 
o|inlining procedure: k7423 
o|substituted constant variable: a7470 
o|substituted constant variable: a7467 
o|substituted constant variable: a7472 
o|substituted constant variable: a7474 
o|substituted constant variable: a7477 
o|substituted constant variable: a7479 
o|substituted constant variable: a7481 
o|substituted constant variable: a7483 
o|substituted constant variable: a7485 
o|substituted constant variable: a7487 
o|substituted constant variable: a7489 
o|substituted constant variable: a7491 
o|substituted constant variable: a7493 
o|substituted constant variable: a7495 
o|inlining procedure: k7496 
o|inlining procedure: k7496 
o|substituted constant variable: a7500 
o|replaced variables: 939 
o|removed binding forms: 427 
o|Removed `not' forms: 2 
o|removed side-effect free assignment to unused variable: main#+default-repository-files+ 
o|substituted constant variable: r30477605 
o|substituted constant variable: r31437609 
o|substituted constant variable: r32217613 
o|substituted constant variable: r32217613 
o|substituted constant variable: r32607619 
o|substituted constant variable: r32607619 
o|inlining procedure: k3259 
o|inlining procedure: k3259 
o|contracted procedure: k3311 
o|substituted constant variable: r33127631 
o|substituted constant variable: r34307639 
o|propagated global variable: a30137654 main#*default-location* 
o|propagated global variable: out690694 ##sys#standard-output 
o|substituted constant variable: r41067661 
o|substituted constant variable: r42257664 
o|substituted constant variable: r42257664 
o|inlining procedure: k4224 
o|inlining procedure: k4224 
o|substituted constant variable: r31997683 
o|substituted constant variable: r31997683 
o|propagated global variable: r44517689 main#*force* 
o|substituted constant variable: r47067708 
o|converted assignments to bindings: (fail898) 
o|substituted constant variable: r36407721 
o|substituted constant variable: r36497723 
o|substituted constant variable: r36587725 
o|inlining procedure: k6352 
o|inlining procedure: k6352 
o|substituted constant variable: r63387768 
o|substituted constant variable: r63237769 
o|removed side-effect free assignment to unused variable: main#*short-options* 
o|substituted constant variable: r75497772 
o|substituted constant variable: r75497772 
o|substituted constant variable: r75497774 
o|substituted constant variable: r75497774 
o|substituted constant variable: r51497798 
o|substituted constant variable: r51617801 
o|contracted procedure: k4956 
o|substituted constant variable: r49577803 
o|propagated global variable: r49667804 main#*deploy* 
o|inlining procedure: k4965 
o|substituted constant variable: r53227809 
o|propagated global variable: out10831087 ##sys#standard-error 
o|substituted constant variable: r62397827 
o|substituted constant variable: r27997844 
o|inlining procedure: k2858 
o|converted assignments to bindings: (broken256) 
o|inlining procedure: k7401 
o|simplifications: ((let . 2)) 
o|replaced variables: 38 
o|removed binding forms: 994 
o|removed conditional forms: 2 
o|Removed `not' forms: 1 
o|inlining procedure: k2535 
o|inlining procedure: k2535 
o|propagated global variable: r25368029 main#*prefix* 
o|propagated global variable: r25368029 main#*prefix* 
o|inlining procedure: k3043 
o|substituted constant variable: r32607914 
o|inlining procedure: k3767 
o|inlining procedure: k4308 
o|substituted constant variable: r63537964 
o|inlining procedure: "(chicken-install.scm:653) main#command" 
o|inlining procedure: "(chicken-install.scm:555) main#back-slash->forward-slash" 
o|inlining procedure: "(chicken-install.scm:550) main#back-slash->forward-slash" 
o|contracted procedure: k4965 
o|propagated global variable: r4966 main#*host-extension* 
o|substituted constant variable: r49667987 
o|inlining procedure: "(chicken-install.scm:623) main#command" 
o|inlining procedure: k6458 
o|inlining procedure: k2921 
o|inlining procedure: k2921 
o|inlining procedure: "(chicken-install.scm:923) main#usage" 
o|inlining procedure: "(chicken-install.scm:940) main#usage" 
o|inlining procedure: "(chicken-install.scm:944) main#usage" 
o|inlining procedure: "(chicken-install.scm:948) main#usage" 
o|inlining procedure: "(chicken-install.scm:217) main#command" 
o|inlining procedure: "(chicken-install.scm:967) main#usage" 
o|inlining procedure: "(chicken-install.scm:971) main#usage" 
o|inlining procedure: "(chicken-install.scm:975) main#usage" 
o|inlining procedure: "(chicken-install.scm:980) main#usage" 
o|inlining procedure: "(chicken-install.scm:1000) main#usage" 
o|inlining procedure: "(chicken-install.scm:1004) main#usage" 
o|inlining procedure: "(chicken-install.scm:1008) main#usage" 
o|inlining procedure: "(chicken-install.scm:1027) main#usage" 
o|inlining procedure: "(chicken-install.scm:1031) main#usage" 
o|inlining procedure: "(chicken-install.scm:1049) main#usage" 
o|inlining procedure: "(chicken-install.scm:1050) main#usage" 
o|replaced variables: 24 
o|removed binding forms: 80 
o|removed conditional forms: 1 
o|substituted constant variable: r25368028 
o|substituted constant variable: r25368028 
o|substituted constant variable: r30448030 
o|substituted constant variable: r30448030 
o|substituted constant variable: r30448030 
o|substituted constant variable: r42257932 
o|removed side-effect free assignment to unused variable: main#back-slash->forward-slash 
o|removed side-effect free assignment to unused variable: main#command 
o|removed side-effect free assignment to unused variable: main#usage 
o|substituted constant variable: fstr15248073 
o|substituted constant variable: fstr15248085 
o|substituted constant variable: r29228105 
o|substituted constant variable: code15288109 
o|substituted constant variable: code15288114 
o|substituted constant variable: code15288119 
o|substituted constant variable: code15288124 
o|substituted constant variable: fstr15248129 
o|substituted constant variable: code15288137 
o|substituted constant variable: code15288142 
o|substituted constant variable: code15288147 
o|substituted constant variable: code15288152 
o|substituted constant variable: code15288157 
o|substituted constant variable: code15288162 
o|substituted constant variable: code15288167 
o|substituted constant variable: code15288172 
o|substituted constant variable: code15288177 
o|substituted constant variable: code15288184 
o|substituted constant variable: code15288189 
o|simplifications: ((let . 1)) 
o|replaced variables: 10 
o|removed binding forms: 32 
o|removed conditional forms: 3 
o|inlining procedure: k4923 
o|inlining procedure: k4949 
o|removed binding forms: 31 
o|simplifications: ((if . 46) (##core#call . 416)) 
o|  call simplifications:
o|    string=?
o|    alist-cons	2
o|    ##sys#size	2
o|    fx>
o|    string->list
o|    memq
o|    string
o|    cddr	2
o|    =
o|    first
o|    length
o|    list-ref
o|    >
o|    caddr	3
o|    apply	3
o|    string->number
o|    ##sys#apply	5
o|    ##sys#structure?
o|    memv	6
o|    ##sys#setslot	10
o|    list	10
o|    ##sys#check-list	12
o|    pair?	54
o|    ##sys#slot	57
o|    ##sys#list	9
o|    set-car!
o|    list?	5
o|    string?	5
o|    symbol?	4
o|    cons	39
o|    ##sys#call-with-values	12
o|    values	17
o|    eq?	21
o|    equal?	6
o|    member	4
o|    cadr	41
o|    assq	10
o|    assoc	3
o|    cdr	13
o|    null?	9
o|    car	28
o|    not	10
o|    ##sys#fudge
o|contracted procedure: k2465 
o|contracted procedure: k2514 
o|contracted procedure: k2550 
o|contracted procedure: k2526 
o|contracted procedure: k2532 
o|contracted procedure: k2972 
o|contracted procedure: k2980 
o|contracted procedure: k3040 
o|contracted procedure: k3043 
o|contracted procedure: k3116 
o|contracted procedure: k3139 
o|contracted procedure: k3149 
o|contracted procedure: k3165 
o|contracted procedure: k3174 
o|contracted procedure: k3210 
o|contracted procedure: k3213 
o|contracted procedure: k3243 
o|contracted procedure: k3252 
o|contracted procedure: k3275 
o|contracted procedure: k3284 
o|contracted procedure: k3294 
o|contracted procedure: k3305 
o|contracted procedure: k3375 
o|contracted procedure: k3382 
o|contracted procedure: k3394 
o|contracted procedure: k3413 
o|contracted procedure: k3417 
o|contracted procedure: k3426 
o|contracted procedure: k3432 
o|contracted procedure: k3447 
o|contracted procedure: k3435 
o|contracted procedure: k3453 
o|contracted procedure: k3460 
o|contracted procedure: k3728 
o|contracted procedure: k3749 
o|contracted procedure: k3777 
o|contracted procedure: k37748038 
o|contracted procedure: k3767 
o|contracted procedure: k3774 
o|contracted procedure: k3784 
o|contracted procedure: k3798 
o|inlining procedure: k3794 
o|inlining procedure: k3794 
o|contracted procedure: k2995 
o|contracted procedure: k3010 
o|contracted procedure: k3002 
o|contracted procedure: k3027 
o|contracted procedure: k4240 
o|contracted procedure: k4085 
o|contracted procedure: k4117 
o|contracted procedure: k4128 
o|contracted procedure: k4140 
o|contracted procedure: k4150 
o|contracted procedure: k4154 
o|contracted procedure: k4159 
o|contracted procedure: k4183 
o|contracted procedure: k4188 
o|contracted procedure: k4206 
o|contracted procedure: k4216 
o|contracted procedure: k4220 
o|propagated global variable: g712714 main#*eggs+dirs+vers* 
o|contracted procedure: k4227 
o|propagated global variable: out690694 ##sys#standard-output 
o|contracted procedure: k4233 
o|contracted procedure: k4325 
o|contracted procedure: k4568 
o|contracted procedure: k4580 
o|contracted procedure: k4590 
o|contracted procedure: k4594 
o|contracted procedure: k4565 
o|contracted procedure: k4339 
o|contracted procedure: k4343 
o|contracted procedure: k4377 
o|contracted procedure: k3478 
o|contracted procedure: k3493 
o|contracted procedure: k3507 
o|contracted procedure: k3527 
o|contracted procedure: k3531 
o|contracted procedure: k3546 
o|contracted procedure: k3556 
o|contracted procedure: k3560 
o|propagated global variable: g514516 main#*hacks* 
o|contracted procedure: k4482 
o|contracted procedure: k4486 
o|contracted procedure: k4501 
o|contracted procedure: k4478 
o|contracted procedure: k4388 
o|contracted procedure: k4426 
o|contracted procedure: k4436 
o|contracted procedure: k4440 
o|contracted procedure: k4447 
o|contracted procedure: k3971 
o|contracted procedure: k3862 
o|contracted procedure: k3872 
o|contracted procedure: k3929 
o|contracted procedure: k3933 
o|contracted procedure: k3883 
o|contracted procedure: k3925 
o|contracted procedure: k3945 
o|contracted procedure: k3948 
o|contracted procedure: k3967 
o|contracted procedure: k4464 
o|contracted procedure: k4513 
o|contracted procedure: k4516 
o|contracted procedure: k4519 
o|contracted procedure: k4527 
o|contracted procedure: k4535 
o|contracted procedure: k4494 
o|contracted procedure: k4632 
o|contracted procedure: k4642 
o|contracted procedure: k4651 
o|contracted procedure: k4761 
o|contracted procedure: k4696 
o|contracted procedure: k4702 
o|contracted procedure: k4719 
o|contracted procedure: k4741 
o|contracted procedure: k4757 
o|contracted procedure: k4748 
o|contracted procedure: k4673 
o|contracted procedure: k4557 
o|propagated global variable: g809811 main#*eggs+dirs+vers* 
o|contracted procedure: k4603 
o|contracted procedure: k4613 
o|contracted procedure: k4617 
o|contracted procedure: k4254 
o|contracted procedure: k4263 
o|contracted procedure: k4321 
o|contracted procedure: k4273 
o|contracted procedure: k3666 
o|contracted procedure: k3594 
o|contracted procedure: k3642 
o|contracted procedure: k3651 
o|contracted procedure: k3660 
o|contracted procedure: k3689 
o|contracted procedure: k4302 
o|contracted procedure: k4298 
o|contracted procedure: k4305 
o|contracted procedure: k4308 
o|contracted procedure: k3980 
o|contracted procedure: k4032 
o|contracted procedure: k4036 
o|contracted procedure: k4042 
o|contracted procedure: k4053 
o|contracted procedure: k4049 
o|contracted procedure: k4064 
o|contracted procedure: k4072 
o|contracted procedure: k5963 
o|contracted procedure: k5976 
o|contracted procedure: k5985 
o|contracted procedure: k5998 
o|contracted procedure: k6002 
o|contracted procedure: k6040 
o|contracted procedure: k6043 
o|contracted procedure: k6046 
o|contracted procedure: k6058 
o|contracted procedure: k6061 
o|contracted procedure: k6064 
o|contracted procedure: k6072 
o|contracted procedure: k6080 
o|contracted procedure: k6105 
o|contracted procedure: k6175 
o|contracted procedure: k6203 
o|contracted procedure: k6325 
o|contracted procedure: k6349 
o|contracted procedure: k6366 
o|contracted procedure: k6361 
o|contracted procedure: k6388 
o|contracted procedure: k5637 
o|contracted procedure: k5647 
o|contracted procedure: k5651 
o|contracted procedure: k5673 
o|contracted procedure: k5677 
o|contracted procedure: k5683 
o|contracted procedure: k5708 
o|contracted procedure: k5717 
o|contracted procedure: k5720 
o|contracted procedure: k5727 
o|contracted procedure: k5736 
o|contracted procedure: k5739 
o|contracted procedure: k5751 
o|contracted procedure: k5754 
o|contracted procedure: k5757 
o|contracted procedure: k5765 
o|contracted procedure: k5773 
o|contracted procedure: k5785 
o|contracted procedure: k5788 
o|contracted procedure: k5791 
o|contracted procedure: k5799 
o|contracted procedure: k5807 
o|contracted procedure: k5916 
o|contracted procedure: k5926 
o|contracted procedure: k5930 
o|contracted procedure: k5888 
o|contracted procedure: k6131 
o|contracted procedure: k6143 
o|contracted procedure: k6153 
o|contracted procedure: k6157 
o|contracted procedure: k6121 
o|contracted procedure: k6117 
o|contracted procedure: k4990 
o|contracted procedure: k5027 
o|contracted procedure: k5084 
o|contracted procedure: k5227 
o|contracted procedure: k5231 
o|contracted procedure: k5235 
o|contracted procedure: k4784 
o|contracted procedure: k4813 
o|contracted procedure: k4817 
o|contracted procedure: k4821 
o|contracted procedure: k4825 
o|contracted procedure: k4851 
o|contracted procedure: k4862 
o|contracted procedure: k4883 
o|contracted procedure: k5551 
o|contracted procedure: k5555 
o|contracted procedure: k5538 
o|contracted procedure: k5253 
o|contracted procedure: k5278 
o|contracted procedure: k5314 
o|contracted procedure: k5328 
o|contracted procedure: k5332 
o|contracted procedure: k5335 
o|contracted procedure: k5373 
o|contracted procedure: k5394 
o|contracted procedure: k5397 
o|contracted procedure: k5438 
o|contracted procedure: k5413 
o|contracted procedure: k5423 
o|contracted procedure: k5427 
o|contracted procedure: k5431 
o|contracted procedure: k5435 
o|contracted procedure: k5463 
o|contracted procedure: k5472 
o|contracted procedure: k5494 
o|contracted procedure: k5490 
o|contracted procedure: k5475 
o|contracted procedure: k5478 
o|contracted procedure: k5486 
o|contracted procedure: k5518 
o|contracted procedure: k6470 
o|contracted procedure: k6486 
o|contracted procedure: k6498 
o|contracted procedure: k6501 
o|contracted procedure: k6504 
o|contracted procedure: k6512 
o|contracted procedure: k6520 
o|contracted procedure: k6552 
o|contracted procedure: k6226 
o|contracted procedure: k6229 
o|contracted procedure: k6232 
o|contracted procedure: k6235 
o|contracted procedure: k6247 
o|contracted procedure: k6567 
o|contracted procedure: k6575 
o|contracted procedure: k6600 
o|contracted procedure: k6603 
o|contracted procedure: k6606 
o|contracted procedure: k6614 
o|contracted procedure: k6622 
o|contracted procedure: k6588 
o|contracted procedure: k2582 
o|contracted procedure: k2588 
o|contracted procedure: k2647 
o|contracted procedure: k2643 
o|contracted procedure: k2639 
o|contracted procedure: k2635 
o|contracted procedure: k2655 
o|contracted procedure: k2663 
o|contracted procedure: k2671 
o|contracted procedure: k2679 
o|contracted procedure: k2706 
o|contracted procedure: k2719 
o|contracted procedure: k2731 
o|contracted procedure: k2734 
o|contracted procedure: k2737 
o|contracted procedure: k2745 
o|contracted procedure: k2753 
o|contracted procedure: k2762 
o|contracted procedure: k2770 
o|contracted procedure: k2785 
o|contracted procedure: k2789 
o|contracted procedure: k2795 
o|contracted procedure: k2801 
o|contracted procedure: k2811 
o|contracted procedure: k2823 
o|contracted procedure: k2826 
o|contracted procedure: k2829 
o|contracted procedure: k2837 
o|contracted procedure: k2845 
o|contracted procedure: k2854 
o|contracted procedure: k2868 
o|contracted procedure: k2872 
o|contracted procedure: k2879 
o|contracted procedure: k2887 
o|contracted procedure: k2895 
o|contracted procedure: k2903 
o|contracted procedure: k2927 
o|contracted procedure: k2944 
o|contracted procedure: k2954 
o|contracted procedure: k2958 
o|contracted procedure: k6640 
o|contracted procedure: k6646 
o|contracted procedure: k6682 
o|contracted procedure: k6696 
o|contracted procedure: k6712 
o|contracted procedure: k6726 
o|contracted procedure: k6733 
o|contracted procedure: k6742 
o|contracted procedure: k6755 
o|contracted procedure: k6772 
o|contracted procedure: k6775 
o|contracted procedure: k6788 
o|contracted procedure: k6795 
o|contracted procedure: k6821 
o|contracted procedure: k6834 
o|contracted procedure: k6864 
o|contracted procedure: k6878 
o|contracted procedure: k6891 
o|contracted procedure: k3058 
o|contracted procedure: k3093 
o|contracted procedure: k3103 
o|contracted procedure: k3107 
o|contracted procedure: k6894 
o|contracted procedure: k6917 
o|contracted procedure: k6921 
o|contracted procedure: k6924 
o|contracted procedure: k6937 
o|contracted procedure: k6944 
o|contracted procedure: k6958 
o|contracted procedure: k6961 
o|contracted procedure: k6978 
o|contracted procedure: k6992 
o|contracted procedure: k6995 
o|contracted procedure: k7067 
o|contracted procedure: k7076 
o|contracted procedure: k7093 
o|contracted procedure: k7102 
o|contracted procedure: k7126 
o|contracted procedure: k7130 
o|contracted procedure: k7133 
o|contracted procedure: k7146 
o|contracted procedure: k7208 
o|contracted procedure: k7217 
o|contracted procedure: k7234 
o|contracted procedure: k7243 
o|contracted procedure: k7366 
o|contracted procedure: k7282 
o|contracted procedure: k7302 
o|contracted procedure: k7321 
o|contracted procedure: k7343 
o|contracted procedure: k7339 
o|contracted procedure: k7324 
o|contracted procedure: k7327 
o|contracted procedure: k7335 
o|contracted procedure: k7374 
o|contracted procedure: k7381 
o|contracted procedure: k7390 
o|contracted procedure: k7432 
o|contracted procedure: k7436 
o|contracted procedure: k7456 
o|contracted procedure: k7464 
o|simplifications: ((if . 1) (let . 69)) 
o|removed binding forms: 355 
o|inlining procedure: k3006 
o|inlining procedure: k3006 
o|inlining procedure: k5390 
o|inlining procedure: k5390 
o|replaced variables: 101 
o|removed binding forms: 1 
o|simplifications: ((if . 1)) 
o|replaced variables: 4 
o|removed binding forms: 57 
o|removed binding forms: 4 
o|direct leaf routine/allocation: main#deps 0 
o|direct leaf routine/allocation: g13281337 9 
o|direct leaf routine/allocation: g13551364 9 
o|contracted procedure: "(chicken-install.scm:431) k4166" 
o|contracted procedure: "(chicken-install.scm:431) k4170" 
o|contracted procedure: "(chicken-install.scm:242) k3190" 
o|contracted procedure: "(chicken-install.scm:243) k3194" 
o|contracted procedure: "(chicken-install.scm:244) k3198" 
o|contracted procedure: "(chicken-install.scm:712) k5769" 
o|contracted procedure: "(chicken-install.scm:711) k5803" 
o|removed binding forms: 7 
o|replaced variables: 14 
o|removed binding forms: 6 
o|customizable procedures: (k6649 k7276 g17861787 k7394 map-loop17501775 main#setup-proxy g412419 for-each-loop411422 loop1549 g261268 for-each-loop260373 k2861 g350359 map-loop344364 g305314 map-loop299335 broken256 map-loop16141632 g15131514 map-loop15831600 k4977 map-loop10501075 g10961104 for-each-loop10951219 k5015 k5341 setup1121 k4780 main#get-prefix tmp11271136 tmp11541163 main#$system main#show-depends for-each-loop14661477 for-each-loop12581297 map-loop13221340 map-loop13491367 for-each-loop13791391 g14921493 map-loop14351452 canonical1404 g656657 k3994 main#with-default-sources k3600 k3612 k3624 for-each-loop760795 k4679 fail898 main#apply-mappings k4531 map-loop829847 g625626 for-each-loop862874 g508515 for-each-loop507518 loop523 for-each-loop802888 main#retrieve g706713 for-each-loop705746 main#cleanup for-each-loop722740 k3017 k3758 trying-sources587 k3236 k3326 k3298 scan467 main#check-dependency main#ext-version k3119 main#repo-path main#resolve-location) 
o|calls to known targets: 262 
o|identified direct recursive calls: f_2970 1 
o|identified direct recursive calls: f_3723 1 
o|identified direct recursive calls: f_5746 1 
o|identified direct recursive calls: f_5780 1 
o|identified direct recursive calls: f_5467 1 
o|identified direct recursive calls: f_7316 1 
o|fast box initializations: 29 
o|fast global references: 190 
o|fast global assignments: 103 
o|dropping unused closure argument: f_3205 
o|dropping unused closure argument: f_6161 
o|dropping unused closure argument: f_4247 
o|dropping unused closure argument: f_6320 
o|dropping unused closure argument: f_4077 
o|dropping unused closure argument: f_5958 
o|dropping unused closure argument: f_5955 
o|dropping unused closure argument: f_2970 
o|dropping unused closure argument: f_2524 
o|dropping unused closure argument: f_3111 
o|dropping unused closure argument: f_3038 
o|dropping unused closure argument: f_2457 
o|dropping unused closure argument: f_3714 
o|dropping unused closure argument: f_5559 
*/
/* end of file */
