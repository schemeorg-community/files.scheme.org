/* Generated from setup-download.scm by the CHICKEN compiler
   http://www.call-cc.org
   2016-05-28 13:51
   Version 4.11.0 (rev ce980c4)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2016-05-28 on yves.more-magic.net (Linux)
   command line: setup-download.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -feature chicken-compile-shared -dynamic -emit-import-library setup-download -output-file setup-download.c
   used units: library eval chicken_2dsyntax extras irregex posix utils srfi_2d1 data_2dstructures tcp srfi_2d13 files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externimport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_irregex_toplevel)
C_externimport void C_ccall C_irregex_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_srfi_2d1_toplevel)
C_externimport void C_ccall C_srfi_2d1_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_srfi_2d13_toplevel)
C_externimport void C_ccall C_srfi_2d13_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word *av) C_noret;

static C_TLS C_word lf[259];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,34),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,100,32,102,115,116,114,49,53,55,32,97,114,103,115,49,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,40),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,101,116,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,101,120,105,115,116,105,110,103,45,118,101,114,115,105,111,110,32,101,103,103,49,54,57,32,118,101,114,115,105,111,110,49,55,48,32,118,115,49,55,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,7),40,97,49,53,55,48,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,51,52,54,32,103,51,53,51,51,53,57,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,18),40,97,49,55,52,57,32,103,51,51,57,51,52,48,51,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,33),40,97,49,54,48,55,32,115,114,99,50,56,52,50,56,53,50,57,49,32,118,101,114,50,56,54,50,56,55,50,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,59),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,108,111,99,97,108,32,101,103,103,50,54,49,32,100,105,114,50,54,50,32,46,32,116,109,112,50,54,48,50,54,51,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,7),40,97,49,56,52,54,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,7),40,97,49,57,48,52,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,13),40,97,49,56,57,56,32,101,120,51,56,54,41,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,7),40,97,49,57,49,57,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,7),40,97,49,57,51,49,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,20),40,97,49,57,50,53,32,46,32,97,114,103,115,51,56,48,51,56,56,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,7),40,97,49,57,49,51,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,15),40,97,49,56,57,50,32,107,51,55,57,51,56,53,41,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,17),40,97,49,56,54,55,32,114,101,116,117,114,110,51,55,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,37),40,97,49,56,53,50,32,108,111,99,51,54,56,51,54,57,51,55,50,32,118,101,114,115,105,111,110,51,55,48,51,55,49,51,55,51,41,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,14),40,97,49,56,52,48,32,101,103,103,51,54,55,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,97,116,104,101,114,45,101,103,103,45,105,110,102,111,114,109,97,116,105,111,110,32,100,105,114,51,54,53,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,66),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,109,97,107,101,45,115,118,110,45,108,115,45,99,109,100,32,117,97,114,103,51,57,53,32,112,97,114,103,51,57,54,32,112,110,97,109,51,57,55,32,116,109,112,51,57,52,51,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,50,50,54,48,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,37),40,97,50,50,56,56,32,102,105,108,101,100,105,114,53,51,52,53,51,53,53,51,57,32,118,101,114,53,51,54,53,51,55,53,52,48,41,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,97,50,51,53,52,32,102,53,51,50,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,115,118,110,32,101,103,103,53,49,48,32,114,101,112,111,53,49,49,32,46,32,116,109,112,53,48,57,53,49,50,41,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,39),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,100,101,99,111,110,115,116,114,117,99,116,45,117,114,108,32,117,114,108,53,53,53,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,7),40,97,50,53,50,48,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,50,53,54,50,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,14),40,97,50,53,53,54,32,101,120,110,54,49,48,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,7),40,97,51,49,56,52,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,11),40,103,55,51,50,32,109,55,51,52,41,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,6),40,115,107,105,112,41,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,7),40,97,51,49,53,55,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,102,105,108,101,115,32,102,105,108,101,115,55,53,48,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,32),40,97,51,49,57,48,32,105,110,55,56,53,55,56,54,55,56,57,32,111,117,116,55,56,55,55,56,56,55,57,48,41};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,7),40,97,50,53,56,48,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,7),40,97,50,54,48,50,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,20),40,97,50,53,57,54,32,46,32,97,114,103,115,54,48,52,54,49,57,41,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,7),40,97,50,53,55,52,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,15),40,97,50,53,53,48,32,107,54,48,51,54,48,57,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,31),40,97,50,53,50,54,32,104,111,115,116,53,57,51,32,112,111,114,116,53,57,52,32,108,111,99,110,53,57,53,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,104,116,116,112,32,101,103,103,53,55,50,32,117,114,108,53,55,51,32,46,32,116,109,112,53,55,49,53,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,7),40,97,50,55,54,48,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,7),40,97,50,55,54,51,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,7),40,97,50,55,54,54,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,50,55,54,57,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,78),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,109,97,107,101,45,72,84,84,80,45,71,69,84,47,49,46,49,32,108,111,99,97,116,105,111,110,54,51,48,32,117,115,101,114,45,97,103,101,110,116,54,51,49,32,104,111,115,116,54,51,50,32,116,109,112,54,50,57,54,51,51,41,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,53),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,114,101,115,112,111,110,115,101,45,109,97,116,99,104,45,99,111,100,101,63,32,109,114,115,112,54,52,53,32,99,111,100,101,54,52,54,41,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,7),40,97,50,56,49,54,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,99,104,117,110,107,115,32,100,97,116,97,56,50,55,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,7),40,97,50,57,49,48,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,36),40,97,50,57,49,54,32,105,110,112,120,54,56,57,54,57,48,54,57,51,32,111,117,116,112,120,54,57,49,54,57,50,54,57,52,41,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,32),40,97,50,56,51,48,32,105,110,54,55,50,54,55,51,54,56,50,32,111,117,116,54,55,52,54,55,53,54,56,51,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,100),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,104,116,116,112,45,99,111,110,110,101,99,116,32,104,111,115,116,54,53,49,32,112,111,114,116,54,53,50,32,108,111,99,110,54,53,51,32,112,114,111,120,121,45,104,111,115,116,54,53,52,32,112,114,111,120,121,45,112,111,114,116,54,53,53,32,112,114,111,120,121,45,117,115,101,114,45,112,97,115,115,54,53,54,41,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,39),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,99,104,101,99,107,45,101,103,103,45,110,97,109,101,32,110,97,109,101,56,52,51,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,7),40,97,51,51,57,50,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,51,52,48,49,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,7),40,97,51,52,52,48,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,7),40,97,51,52,52,57,41,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,80),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,114,101,116,114,105,101,118,101,45,101,120,116,101,110,115,105,111,110,32,110,97,109,101,56,53,48,32,116,114,97,110,115,112,111,114,116,56,53,49,32,108,111,99,97,116,105,111,110,56,53,50,32,46,32,116,109,112,56,52,57,56,53,51,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,7),40,97,51,52,55,54,41,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,49,56,49,32,103,49,57,51,50,48,55,41,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,52,50,56,32,103,52,52,48,52,52,55,41,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,7),40,97,51,50,48,50,41,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,7),40,97,51,50,49,52,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,32),40,97,51,50,50,52,32,105,110,56,49,48,56,49,49,56,49,52,32,111,117,116,56,49,50,56,49,51,56,49,53,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,49),40,97,51,50,48,56,32,104,111,115,116,55,57,56,55,57,57,56,48,52,32,112,111,114,116,56,48,48,56,48,49,56,48,53,32,108,111,99,110,56,48,50,56,48,51,56,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,7),40,97,51,52,56,49,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,7),40,97,51,53,50,48,41,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,69),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,105,115,116,45,101,120,116,101,110,115,105,111,110,115,32,116,114,97,110,115,112,111,114,116,57,48,57,32,108,111,99,97,116,105,111,110,57,49,48,32,46,32,116,109,112,57,48,56,57,49,49,41,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,7),40,97,51,53,52,51,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,50,50,51,32,103,50,51,53,50,52,57,41,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,52,55,57,32,103,52,57,49,52,57,56,41,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,7),40,97,51,53,52,56,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,7),40,97,51,53,55,54,41,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,85),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,105,115,116,45,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,115,32,110,97,109,101,57,52,48,32,116,114,97,110,115,112,111,114,116,57,52,49,32,108,111,99,97,116,105,111,110,57,52,50,32,46,32,116,109,112,57,51,57,57,52,51,41,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_2575)
static void C_ccall f_2575(C_word c,C_word *av) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word *av) C_noret;
C_noret_decl(f_1533)
static void C_ccall f_1533(C_word c,C_word *av) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word *av) C_noret;
C_noret_decl(f_2976)
static void C_fcall f_2976(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word *av) C_noret;
C_noret_decl(f_2880)
static void C_fcall f_2880(C_word t0,C_word t1) C_noret;
C_noret_decl(f3797)
static void C_ccall f3797(C_word c,C_word *av) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word *av) C_noret;
C_noret_decl(f3793)
static void C_ccall f3793(C_word c,C_word *av) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word *av) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word *av) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word *av) C_noret;
C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word *av) C_noret;
C_noret_decl(f_1378)
static void C_fcall f_1378(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word *av) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word *av) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word *av) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word *av) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word *av) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word *av) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word *av) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word *av) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word *av) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word *av) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word *av) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word *av) C_noret;
C_noret_decl(f_1361)
static void C_ccall f_1361(C_word c,C_word *av) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word *av) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word *av) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word *av) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word *av) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word *av) C_noret;
C_noret_decl(f_1363)
static void C_fcall f_1363(C_word t0) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word *av) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word *av) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word *av) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word *av) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word *av) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word *av) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word *av) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word *av) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word *av) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word *av) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word *av) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word *av) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word *av) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word *av) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word *av) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word *av) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word *av) C_noret;
C_noret_decl(f_2808)
static void C_fcall f_2808(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word *av) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word *av) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word *av) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word *av) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word *av) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word *av) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word *av) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word *av) C_noret;
C_noret_decl(f_3348)
static void C_ccall f_3348(C_word c,C_word *av) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word *av) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word *av) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word *av) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word *av) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word *av) C_noret;
C_noret_decl(f_2431)
static void C_fcall f_2431(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word *av) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word *av) C_noret;
C_noret_decl(f_3336)
static void C_fcall f_3336(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2785)
static void C_fcall f_2785(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word *av) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817(C_word c,C_word *av) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word *av) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word *av) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word *av) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word *av) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word *av) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word *av) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word *av) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word *av) C_noret;
C_noret_decl(f_1853)
static void C_ccall f_1853(C_word c,C_word *av) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word *av) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word *av) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word *av) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word *av) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293(C_word c,C_word *av) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word *av) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847(C_word c,C_word *av) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word *av) C_noret;
C_noret_decl(f_2720)
static void C_fcall f_2720(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word *av) C_noret;
C_noret_decl(f_2844)
static void C_ccall f_2844(C_word c,C_word *av) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word *av) C_noret;
C_noret_decl(f_3296)
static void C_ccall f_3296(C_word c,C_word *av) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word *av) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word *av) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word *av) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word *av) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word *av) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word *av) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word *av) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word *av) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word *av) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word *av) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word *av) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word *av) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word *av) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word *av) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word *av) C_noret;
C_noret_decl(f_1938)
static void C_fcall f_1938(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word *av) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word *av) C_noret;
C_noret_decl(f_1688)
static void C_ccall f_1688(C_word c,C_word *av) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word *av) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word *av) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word *av) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word *av) C_noret;
C_noret_decl(f_3382)
static void C_ccall f_3382(C_word c,C_word *av) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word *av) C_noret;
C_noret_decl(f_1627)
static void C_ccall f_1627(C_word c,C_word *av) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word *av) C_noret;
C_noret_decl(f_3265)
static void C_fcall f_3265(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word *av) C_noret;
C_noret_decl(f_1633)
static void C_ccall f_1633(C_word c,C_word *av) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word *av) C_noret;
C_noret_decl(f_1639)
static void C_ccall f_1639(C_word c,C_word *av) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word *av) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word *av) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word *av) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word *av) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word *av) C_noret;
C_noret_decl(f_3071)
static void C_ccall f_3071(C_word c,C_word *av) C_noret;
C_noret_decl(f_3067)
static void C_fcall f_3067(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3229)
static void C_ccall f_3229(C_word c,C_word *av) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word *av) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word *av) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word *av) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608(C_word c,C_word *av) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word *av) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word *av) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word *av) C_noret;
C_noret_decl(f_3203)
static void C_ccall f_3203(C_word c,C_word *av) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word *av) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word *av) C_noret;
C_noret_decl(f_1691)
static void C_ccall f_1691(C_word c,C_word *av) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word *av) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word *av) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word *av) C_noret;
C_noret_decl(f_3021)
static void C_fcall f_3021(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3526)
static void C_ccall f_3526(C_word c,C_word *av) C_noret;
C_noret_decl(f_3080)
static void C_fcall f_3080(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word *av) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word *av) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word *av) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word *av) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word *av) C_noret;
C_noret_decl(f_1618)
static void C_fcall f_1618(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word *av) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word *av) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word *av) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word *av) C_noret;
C_noret_decl(f_1705)
static void C_ccall f_1705(C_word c,C_word *av) C_noret;
C_noret_decl(f_1701)
static void C_ccall f_1701(C_word c,C_word *av) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word *av) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word *av) C_noret;
C_noret_decl(f_1727)
static void C_fcall f_1727(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1719)
static void C_ccall f_1719(C_word c,C_word *av) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word *av) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word *av) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word *av) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word *av) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word *av) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word *av) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word *av) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word *av) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word *av) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word *av) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word *av) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word *av) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word *av) C_noret;
C_noret_decl(f_2369)
static void C_ccall f_2369(C_word c,C_word *av) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word *av) C_noret;
C_noret_decl(f_1354)
static void C_ccall f_1354(C_word c,C_word *av) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word *av) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word *av) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word *av) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word *av) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word *av) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word *av) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word *av) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word *av) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word *av) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331(C_word c,C_word *av) C_noret;
C_noret_decl(f_1337)
static void C_ccall f_1337(C_word c,C_word *av) C_noret;
C_noret_decl(f_1334)
static void C_ccall f_1334(C_word c,C_word *av) C_noret;
C_noret_decl(f_2323)
static void C_ccall f_2323(C_word c,C_word *av) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word *av) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word *av) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word *av) C_noret;
C_noret_decl(f_2141)
static void C_fcall f_2141(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word *av) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word *av) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word *av) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word *av) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word *av) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word *av) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word *av) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word *av) C_noret;
C_noret_decl(f_1347)
static void C_fcall f_1347(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2336)
static void C_ccall f_2336(C_word c,C_word *av) C_noret;
C_noret_decl(f_1394)
static void C_ccall f_1394(C_word c,C_word *av) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word *av) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word *av) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word *av) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word *av) C_noret;
C_noret_decl(f_1324)
static void C_ccall f_1324(C_word c,C_word *av) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word *av) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word *av) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word *av) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word *av) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word *av) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word *av) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word *av) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word *av) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word *av) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word *av) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word *av) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word *av) C_noret;
C_noret_decl(f_2581)
static void C_ccall f_2581(C_word c,C_word *av) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word *av) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word *av) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word *av) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word *av) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word *av) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word *av) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word *av) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word *av) C_noret;
C_noret_decl(f_3145)
static void C_ccall f_3145(C_word c,C_word *av) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word *av) C_noret;
C_noret_decl(f_3120)
static void C_ccall f_3120(C_word c,C_word *av) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word *av) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word *av) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word *av) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word *av) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word *av) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word *av) C_noret;
C_noret_decl(f_1497)
static void C_fcall f_1497(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word *av) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word *av) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word *av) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word *av) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word *av) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word *av) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428(C_word c,C_word *av) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word *av) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word *av) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word *av) C_noret;
C_noret_decl(f_1433)
static void C_fcall f_1433(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1431)
static void C_ccall f_1431(C_word c,C_word *av) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word *av) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word *av) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word *av) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word *av) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word *av) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word *av) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word *av) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word *av) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word *av) C_noret;
C_noret_decl(f_1560)
static void C_ccall f_1560(C_word c,C_word *av) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word *av) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word *av) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word *av) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word *av) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word *av) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word *av) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word *av) C_noret;
C_noret_decl(f_2018)
static void C_fcall f_2018(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word *av) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word *av) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word *av) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word *av) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word *av) C_noret;
C_noret_decl(f_1769)
static void C_ccall f_1769(C_word c,C_word *av) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word *av) C_noret;
C_noret_decl(f_2999)
static void C_fcall f_2999(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word *av) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word *av) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word *av) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word *av) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word *av) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word *av) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word *av) C_noret;
C_noret_decl(f_1522)
static void C_ccall f_1522(C_word c,C_word *av) C_noret;

C_noret_decl(trf_2976)
static void C_ccall trf_2976(C_word c,C_word *av) C_noret;
static void C_ccall trf_2976(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2976(t0,t1);}

C_noret_decl(trf_2880)
static void C_ccall trf_2880(C_word c,C_word *av) C_noret;
static void C_ccall trf_2880(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2880(t0,t1);}

C_noret_decl(trf_1378)
static void C_ccall trf_1378(C_word c,C_word *av) C_noret;
static void C_ccall trf_1378(C_word c,C_word *av){
C_word t0=av[3];
C_word t1=av[2];
C_word t2=av[1];
C_word t3=av[0];
f_1378(t0,t1,t2,t3);}

C_noret_decl(trf_1363)
static void C_ccall trf_1363(C_word c,C_word *av) C_noret;
static void C_ccall trf_1363(C_word c,C_word *av){
C_word t0=av[0];
f_1363(t0);}

C_noret_decl(trf_2808)
static void C_ccall trf_2808(C_word c,C_word *av) C_noret;
static void C_ccall trf_2808(C_word c,C_word *av){
C_word t0=av[6];
C_word t1=av[5];
C_word t2=av[4];
C_word t3=av[3];
C_word t4=av[2];
C_word t5=av[1];
C_word t6=av[0];
f_2808(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2431)
static void C_ccall trf_2431(C_word c,C_word *av) C_noret;
static void C_ccall trf_2431(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_2431(t0,t1);}

C_noret_decl(trf_3336)
static void C_ccall trf_3336(C_word c,C_word *av) C_noret;
static void C_ccall trf_3336(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3336(t0,t1);}

C_noret_decl(trf_2785)
static void C_ccall trf_2785(C_word c,C_word *av) C_noret;
static void C_ccall trf_2785(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2785(t0,t1,t2);}

C_noret_decl(trf_2720)
static void C_ccall trf_2720(C_word c,C_word *av) C_noret;
static void C_ccall trf_2720(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_2720(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1938)
static void C_ccall trf_1938(C_word c,C_word *av) C_noret;
static void C_ccall trf_1938(C_word c,C_word *av){
C_word t0=av[4];
C_word t1=av[3];
C_word t2=av[2];
C_word t3=av[1];
C_word t4=av[0];
f_1938(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3265)
static void C_ccall trf_3265(C_word c,C_word *av) C_noret;
static void C_ccall trf_3265(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3265(t0,t1,t2);}

C_noret_decl(trf_3067)
static void C_ccall trf_3067(C_word c,C_word *av) C_noret;
static void C_ccall trf_3067(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_3067(t0,t1,t2);}

C_noret_decl(trf_3021)
static void C_ccall trf_3021(C_word c,C_word *av) C_noret;
static void C_ccall trf_3021(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3021(t0,t1);}

C_noret_decl(trf_3080)
static void C_ccall trf_3080(C_word c,C_word *av) C_noret;
static void C_ccall trf_3080(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_3080(t0,t1);}

C_noret_decl(trf_1618)
static void C_ccall trf_1618(C_word c,C_word *av) C_noret;
static void C_ccall trf_1618(C_word c,C_word *av){
C_word t0=av[1];
C_word t1=av[0];
f_1618(t0,t1);}

C_noret_decl(trf_1727)
static void C_ccall trf_1727(C_word c,C_word *av) C_noret;
static void C_ccall trf_1727(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1727(t0,t1,t2);}

C_noret_decl(trf_2141)
static void C_ccall trf_2141(C_word c,C_word *av) C_noret;
static void C_ccall trf_2141(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2141(t0,t1,t2);}

C_noret_decl(trf_1347)
static void C_ccall trf_1347(C_word c,C_word *av) C_noret;
static void C_ccall trf_1347(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1347(t0,t1,t2);}

C_noret_decl(trf_1497)
static void C_ccall trf_1497(C_word c,C_word *av) C_noret;
static void C_ccall trf_1497(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1497(t0,t1,t2);}

C_noret_decl(trf_1433)
static void C_ccall trf_1433(C_word c,C_word *av) C_noret;
static void C_ccall trf_1433(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_1433(t0,t1,t2);}

C_noret_decl(trf_2018)
static void C_ccall trf_2018(C_word c,C_word *av) C_noret;
static void C_ccall trf_2018(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2018(t0,t1,t2);}

C_noret_decl(trf_2999)
static void C_ccall trf_2999(C_word c,C_word *av) C_noret;
static void C_ccall trf_2999(C_word c,C_word *av){
C_word t0=av[2];
C_word t1=av[1];
C_word t2=av[0];
f_2999(t0,t1,t2);}

/* a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_2575(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_2575,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li35),tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2597,a[2]=((C_word*)t0)[10],a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:248: ##sys#call-with-values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* k1886 in k1874 in a1867 in k1861 in k1855 in a1852 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_1888(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_1888,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:144: g383");
t3=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)C_fast_retrieve_proc(t3))(2,av2);}}

/* k1531 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_1533(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1533,2,av);}
C_trace("setup-download.scm:88: make-pathname");
t2=C_fast_retrieve(lf[20]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1535(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +7,c,3))){
C_save_and_reclaim((void*)f_1535,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+7);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:C_i_car(t9));
t12=t11;
t13=C_i_nullp(t9);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t15=C_i_nullp(t14);
t16=(C_truep(t15)?C_SCHEME_FALSE:C_i_car(t14));
t17=t16;
t18=C_i_nullp(t14);
t19=(C_truep(t18)?C_SCHEME_END_OF_LIST:C_i_cdr(t14));
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1557,a[2]=t2,a[3]=t7,a[4]=t17,a[5]=t1,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:95: make-pathname");
t21=C_fast_retrieve(lf[20]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t21;
av2[1]=t20;
av2[2]=t3;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t21+1)))(4,av2);}}

/* skip in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in ... */
static void C_fcall f_2976(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_2976,2,t0,t1);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2980,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:344: read-line");
t3=C_fast_retrieve(lf[115]);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in ... */
static void C_ccall f_2974(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(21,c,3))){C_save_and_reclaim((void *)f_2974,2,av);}
a=C_alloc(21);
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2976,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word)li31),tmp=(C_word)a,a+=6,tmp));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3067,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word)li33),tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_3067(t10,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* loop in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in ... */
static void C_fcall f_2880(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,2))){
C_save_and_reclaim_args((void *)trf_2880,2,t0,t1);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2884,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:328: read-line");
t3=C_fast_retrieve(lf[115]);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* f3797 in k2900 in k2888 in k2882 in loop in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in ... */
static void C_ccall f3797(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f3797,2,av);}
C_trace("setup-download.scm:332: loop");
t2=((C_word*)((C_word*)t0)[2])[1];
f_2880(t2,((C_word*)t0)[3]);}

/* k2882 in loop in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in ... */
static void C_ccall f_2884(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_2884,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:329: string-null?");
t4=C_fast_retrieve(lf[180]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* f3793 in k2900 in k2888 in k2882 in loop in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in ... */
static void C_ccall f3793(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f3793,2,av);}
C_trace("setup-download.scm:332: loop");
t2=((C_word*)((C_word*)t0)[2])[1];
f_2880(t2,((C_word*)t0)[3]);}

/* k1988 in k1985 in k1982 in k1979 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_1990(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_1990,2,av);}
a=C_alloc(10);
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2010,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:167: with-input-from-pipe");
t7=C_fast_retrieve(lf[85]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[3];
av2[3]=C_fast_retrieve(lf[86]);
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}

/* k2317 in k2291 in a2288 in k2254 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_ccall f_2319(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_2319,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=C_eqp(C_retrieve2(lf[3],"setup-download#\052mode\052"),lf[80]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2329,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:211: create-directory");
t6=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
t5=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[6];
f_2323(2,av2);}}}

/* k2313 in k2297 in k2294 in k2291 in a2288 in k2254 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in ... */
static void C_ccall f_2315(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2315,2,av);}
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
C_trace("setup-download.scm:216: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
C_values(4,av2);}}
else{
C_trace("setup-download.scm:217: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=lf[75];
C_values(4,av2);}}}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point

void C_ccall C_toplevel(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) {C_kontinue(t1,C_SCHEME_UNDEFINED);}
else C_toplevel_entry(C_text("toplevel"));
C_check_nursery_minimum(C_calculate_demand(3,c,2));
if(!C_demand(C_calculate_demand(3,c,2))){
C_save_and_reclaim((void*)C_toplevel,c,av);}
toplevel_initialized=1;
if(!C_demand_2(784)){
C_save(t1);
C_rereclaim2(784*sizeof(C_word),1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,259);
lf[4]=C_h_intern(&lf[4],7,"default");
lf[7]=C_h_intern(&lf[7],18,"\003sysstandard-error");
lf[8]=C_h_intern(&lf[8],19,"\003sysstandard-output");
lf[9]=C_h_intern(&lf[9],12,"flush-output");
lf[10]=C_h_intern(&lf[10],7,"fprintf");
lf[11]=C_h_intern(&lf[11],34,"setup-download#temporary-directory");
lf[13]=C_h_intern(&lf[13],26,"create-temporary-directory");
lf[15]=C_h_intern(&lf[15],5,"error");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\021version not found");
lf[17]=C_h_intern(&lf[17],4,"sort");
lf[18]=C_h_intern(&lf[18],20,"setup-api#version>=\077");
lf[19]=C_h_intern(&lf[19],31,"setup-download#locate-egg/local");
lf[20]=C_h_intern(&lf[20],13,"make-pathname");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[23]=C_h_intern(&lf[23],10,"directory\077");
lf[24]=C_h_intern(&lf[24],12,"file-exists\077");
lf[25]=C_h_intern(&lf[25],7,"warning");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000-extension has no such version - using default");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[30]=C_h_intern(&lf[30],6,"system");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[32]=C_h_intern(&lf[32],7,"sprintf");
lf[33]=C_h_intern(&lf[33],17,"get-output-string");
lf[34]=C_h_intern(&lf[34],9,"\003sysprint");
lf[35]=C_h_intern(&lf[35],16,"\003syswrite-char-0");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\006xcopy ");
lf[37]=C_h_intern(&lf[37],18,"open-output-string");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\003/\052 ");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\006cp -r ");
lf[40]=C_h_intern(&lf[40],2,"qs");
lf[41]=C_h_intern(&lf[41],18,"normalize-pathname");
lf[42]=C_h_intern(&lf[42],16,"create-directory");
lf[43]=C_h_intern(&lf[43],12,"delete-file\052");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\0006 deleting stale file `~a\047 from local build directory~%");
lf[45]=C_h_intern(&lf[45],14,"string-suffix\077");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\003.so");
lf[47]=C_h_intern(&lf[47],6,"filter");
lf[48]=C_h_intern(&lf[48],9,"directory");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\004tags");
lf[50]=C_h_intern(&lf[50],37,"setup-download#gather-egg-information");
lf[51]=C_h_intern(&lf[51],7,"version");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000.extension has syntactically invalid .meta file");
lf[53]=C_h_intern(&lf[53],20,"with-input-from-file");
lf[54]=C_h_intern(&lf[54],4,"read");
lf[55]=C_h_intern(&lf[55],22,"with-exception-handler");
lf[56]=C_h_intern(&lf[56],30,"call-with-current-continuation");
lf[57]=C_h_intern(&lf[57],14,"string->symbol");
lf[58]=C_h_intern(&lf[58],7,"call/cc");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[60]=C_h_intern(&lf[60],10,"filter-map");
lf[62]=C_h_intern(&lf[62],11,"\000recursive\077");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\004 -R ");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[65]=C_h_intern(&lf[65],4,"conc");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\007svn ls ");
lf[67]=C_h_intern(&lf[67],29,"setup-download#locate-egg/svn");
lf[68]=C_h_intern(&lf[68],13,"string-append");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\005tags/");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\006trunk/");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\005 1>&2");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\013svn export ");
lf[80]=C_h_intern(&lf[80],4,"meta");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\005.meta");
lf[82]=C_h_intern(&lf[82],23,"irregex-match-substring");
lf[83]=C_h_intern(&lf[83],14,"irregex-search");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\016^tags/([^/]+)/");
lf[85]=C_h_intern(&lf[85],20,"with-input-from-pipe");
lf[86]=C_h_intern(&lf[86],10,"read-lines");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\047checking available versions ...~%  ~a~%");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\020not a valid port");
lf[97]=C_h_intern(&lf[97],13,"irregex-match");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000$(http://)\077([^/:]+)(:([^:/]+))\077(/.\052)\077");
lf[99]=C_h_intern(&lf[99],30,"setup-download#locate-egg/http");
lf[100]=C_h_intern(&lf[100],6,"signal");
lf[101]=C_h_intern(&lf[101],26,"setup-api#remove-directory");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[104]=C_h_intern(&lf[104],17,"open-input-string");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\002#f");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000 files-versions are not identical");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000=unrecognized file-information - possibly corrupt transmission");
lf[110]=C_h_intern(&lf[110],12,"string-every");
lf[111]=C_h_intern(&lf[111],19,"char-set:whitespace");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\026^[ ]\052\134(error .\052\134)[ ]\052$");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\031 \052#\134|[- ]\052([^- ]\052) \052\134|#.\052");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\011 \052#!eof \052");
lf[115]=C_h_intern(&lf[115],9,"read-line");
lf[116]=C_h_intern(&lf[116],5,"abort");
lf[117]=C_h_intern(&lf[117],24,"make-composite-condition");
lf[118]=C_h_intern(&lf[118],23,"make-property-condition");
lf[119]=C_h_intern(&lf[119],20,"setup-download-error");
lf[120]=C_h_intern(&lf[120],3,"exn");
lf[121]=C_h_intern(&lf[121],7,"message");
lf[122]=C_h_intern(&lf[122],9,"arguments");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\011[Server] ");
lf[124]=C_h_intern(&lf[124],17,"close-output-port");
lf[125]=C_h_intern(&lf[125],16,"close-input-port");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[127]=C_h_intern(&lf[127],7,"display");
lf[128]=C_h_intern(&lf[128],19,"with-output-to-file");
lf[129]=C_h_intern(&lf[129],7,"\000binary");
lf[130]=C_h_intern(&lf[130],20,"\003sysread-string/port");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\0001invalid file name - possibly corrupt transmission");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\023reading files ...~%");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\006\077name=");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\006&mode=");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\012&tests=yes");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[139]=C_h_intern(&lf[139],8,"->string");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\011&version=");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[143]=C_h_intern(&lf[143],11,"\000proxy-host");
lf[144]=C_h_intern(&lf[144],16,"\000proxy-user-pass");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\004GET ");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\011 HTTP/1.1");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\014Connection: ");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\014User-Agent: ");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\010Accept: ");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\006Host: ");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\020Content-length: ");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\033Proxy-Authorization: Basic ");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\007http://");
lf[163]=C_h_intern(&lf[163],15,"\003sysget-keyword");
lf[164]=C_h_intern(&lf[164],15,"\000content-length");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[166]=C_h_intern(&lf[166],7,"\000accept");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\005close");
lf[168]=C_h_intern(&lf[168],11,"\000connection");
lf[169]=C_h_intern(&lf[169],5,"\000port");
lf[171]=C_h_intern(&lf[171],14,"number->string");
lf[172]=C_h_intern(&lf[172],11,"tcp-connect");
lf[173]=C_h_intern(&lf[173],26,"string-concatenate-reverse");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\002~%");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000/invalid response from server - please try again");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\017reading chunks ");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000$[Tt]ransfer-[Ee]ncoding:\134s\052chunked.\052");
lf[180]=C_h_intern(&lf[180],12,"string-null\077");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\003\052/\052");
lf[182]=C_h_intern(&lf[182],11,"\000proxy-port");
lf[183]=C_h_intern(&lf[183],10,"http-fetch");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid response from server");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\034HTTP/[0-9.]+\134s+([0-9]+)\134s+.\052");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\026reading response ...~%");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\003\052/\052");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\023requesting ~s ...~%");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000&connecting to host ~s, port ~a ~a...~%");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\005(via ");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid extension name");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[200]=C_h_intern(&lf[200],12,"string-index");
lf[201]=C_h_intern(&lf[201],33,"setup-download#retrieve-extension");
lf[202]=C_h_intern(&lf[202],8,"\000version");
lf[203]=C_h_intern(&lf[203],6,"\000quiet");
lf[204]=C_h_intern(&lf[204],12,"\000destination");
lf[205]=C_h_intern(&lf[205],9,"\000username");
lf[206]=C_h_intern(&lf[206],9,"\000password");
lf[207]=C_h_intern(&lf[207],6,"\000tests");
lf[208]=C_h_intern(&lf[208],6,"\000trunk");
lf[209]=C_h_intern(&lf[209],6,"\000clean");
lf[210]=C_h_intern(&lf[210],5,"local");
lf[211]=C_h_intern(&lf[211],3,"svn");
lf[212]=C_h_intern(&lf[212],4,"http");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\0001cannot retrieve extension - unsupported transport");
lf[214]=C_h_intern(&lf[214],16,"\003sysdynamic-wind");
lf[215]=C_h_intern(&lf[215],5,"\000mode");
lf[216]=C_h_intern(&lf[216],30,"setup-download#list-extensions");
lf[217]=C_h_intern(&lf[217],18,"string-concatenate");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[219]=C_h_intern(&lf[219],3,"map");
lf[220]=C_h_intern(&lf[220],17,"\003sysstring-append");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[222]=C_h_intern(&lf[222],12,"string-chomp");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\047listing extension directory ...~%  ~a~%");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\007\077list=1");
lf[232]=C_h_intern(&lf[232],8,"read-all");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000.cannot list extensions - unsupported transport");
lf[234]=C_h_intern(&lf[234],38,"setup-download#list-extension-versions");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010unknown\012");
lf[237]=C_h_intern(&lf[237],17,"directory-exists\077");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\005/tags");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\010unknown\012");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\005/tags");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000.cannot list extensions - unsupported transport");
lf[250]=C_h_intern(&lf[250],8,"char-set");
lf[251]=C_h_intern(&lf[251],14,"make-parameter");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-install ");
lf[253]=C_h_intern(&lf[253],15,"chicken-version");
lf[254]=C_h_intern(&lf[254],17,"tcp-write-timeout");
lf[255]=C_h_intern(&lf[255],16,"tcp-read-timeout");
lf[256]=C_h_intern(&lf[256],19,"tcp-connect-timeout");
lf[257]=C_h_intern(&lf[257],11,"\003sysrequire");
lf[258]=C_h_intern(&lf[258],9,"setup-api");
C_register_lf2(lf,259,create_ptable());{}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1291,a[2]=t1,tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_library_toplevel(2,av2);}}

/* setup-download#existing-version in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_fcall f_1378(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,4))){
C_save_and_reclaim_args((void *)trf_1378,4,t1,t2,t3,t4);}
a=C_alloc(3);
if(C_truep(t3)){
if(C_truep(C_i_member(t3,t4))){
t5=t1;{
C_word av2[2];
av2[0]=t5;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}
else{
C_trace("setup-download.scm:76: error");
t5=*((C_word*)lf[15]+1);{
C_word av2[5];
av2[0]=t5;
av2[1]=t1;
av2[2]=lf[16];
av2[3]=t2;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1394,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:77: sort");
t6=C_fast_retrieve(lf[17]);{
C_word av2[4];
av2[0]=t6;
av2[1]=t5;
av2[2]=t4;
av2[3]=C_fast_retrieve(lf[18]);
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}

/* k1374 in k1371 in k1365 in setup-download#get-temporary-directory in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_1376(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1376,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1371 in k1365 in setup-download#get-temporary-directory in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1373(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1373,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1376,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:69: temporary-directory");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[11]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[11]+1);
av2[1]=t3;
av2[2]=t2;
tp(3,av2);}}

/* k2978 in skip in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in ... */
static void C_ccall f_2980(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2980,2,av);}
a=C_alloc(6);
t2=t1;
t3=C_eofp(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2989,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t3;
f_2989(2,av2);}}
else{
C_trace("setup-download.scm:346: irregex-match");
t5=C_fast_retrieve(lf[97]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[114];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}

/* k2987 in k2978 in skip in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in ... */
static void C_ccall f_2989(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2989,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
C_trace("setup-download.scm:347: open-input-string");
t2=C_fast_retrieve(lf[104]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[105];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:348: irregex-match");
t3=C_fast_retrieve(lf[97]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[113];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k2888 in k2882 in loop in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in ... */
static void C_ccall f_2890(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2890,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2902,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:296: irregex-match");
t3=C_fast_retrieve(lf[97]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[179];
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k2931 in k2904 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in ... */
static void C_ccall f_2933(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,6))){C_save_and_reclaim((void *)f_2933,2,av);}
a=C_alloc(9);
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
f_2856(2,av2);}}
else{
t2=((C_word*)t0)[2];
t3=C_a_i_list(&a,1,((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2710,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2714,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:259: make-property-condition");
t6=C_fast_retrieve(lf[118]);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[120];
av2[3]=lf[121];
av2[4]=lf[184];
av2[5]=lf[122];
av2[6]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(7,av2);}}}

/* a2769 in setup-download#make-HTTP-GET/1.1 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2770(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2770,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(80);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2960 in k2957 in k2954 in k2951 in k2945 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in ... */
static void C_ccall f_2962(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2962,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:301: ##sys#print");
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[191];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2963 in k2960 in k2957 in k2954 in k2951 in k2945 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_2965(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2965,2,av);}
C_trace("setup-download.scm:301: get-output-string");
t2=C_fast_retrieve(lf[33]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1469 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_1471(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1471,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:89: directory-exists?");
t4=C_fast_retrieve(lf[237]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1475 in k1469 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in ... */
static void C_ccall f_1477(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_1477,2,av);}
a=C_alloc(10);
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1492,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:91: directory");
t7=C_fast_retrieve(lf[48]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[236];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k2869 in k2866 in k2857 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in ... */
static void C_ccall f_2871(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_2871,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:336: close-input-port");
t4=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1361(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(36,c,8))){C_save_and_reclaim((void *)f_1361,2,av);}
a=C_alloc(36);
t2=C_mutate2((C_word*)lf[11]+1 /* (set! setup-download#temporary-directory ...) */,t1);
t3=C_mutate2(&lf[12] /* (set! setup-download#get-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1363,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2(&lf[14] /* (set! setup-download#existing-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1378,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[19]+1 /* (set! setup-download#locate-egg/local ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1535,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[50]+1 /* (set! setup-download#gather-egg-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1832,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate2(&lf[61] /* (set! setup-download#make-svn-ls-cmd ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1938,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate2((C_word*)lf[67]+1 /* (set! setup-download#locate-egg/svn ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2213,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate2(&lf[94] /* (set! setup-download#deconstruct-url ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2431,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate2((C_word*)lf[99]+1 /* (set! setup-download#locate-egg/http ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2479,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate2(&lf[142] /* (set! setup-download#make-HTTP-GET/1.1 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2720,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate2(&lf[170] /* (set! setup-download#response-match-code? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2785,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate2(&lf[103] /* (set! setup-download#http-connect ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2808,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:427: char-set");
t15=C_fast_retrieve(lf[250]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t15;
av2[1]=t14;
av2[2]=C_make_character(92);
av2[3]=C_make_character(47);
((C_proc)(void*)(*((C_word*)t15+1)))(4,av2);}}

/* k2876 in k2872 in k2869 in k2866 in k2857 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in ... */
static void C_ccall f_2878(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2878,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t1);
C_trace("setup-download.scm:338: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)((C_word*)t0)[2])[1];
av2[3]=((C_word*)((C_word*)t0)[4])[1];
C_values(4,av2);}}

/* k2872 in k2869 in k2866 in k2857 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in ... */
static void C_ccall f_2874(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2874,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:337: open-input-string");
t3=C_fast_retrieve(lf[104]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k1365 in setup-download#get-temporary-directory in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1367(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1367,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:68: create-temporary-directory");
t3=C_fast_retrieve(lf[13]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* a2916 in k2904 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in ... */
static void C_ccall f_2917(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(34,c,5))){C_save_and_reclaim((void *)f_2917,4,av);}
a=C_alloc(34);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_mutate2(((C_word *)((C_word*)t0)[3])+1,t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2927,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:320: make-HTTP-GET/1.1");
f_2720(t6,((C_word*)t0)[4],C_retrieve2(lf[1],"setup-download#\052chicken-install-user-agent\052"),((C_word*)t0)[5],C_a_i_list(&a,10,lf[169],((C_word*)t0)[6],lf[166],lf[181],lf[143],((C_word*)t0)[7],lf[182],((C_word*)t0)[8],lf[144],((C_word*)t0)[9]));}

/* a2910 in k2904 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in ... */
static void C_ccall f_2911(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2911,2,av);}
C_trace("setup-download.scm:317: tcp-connect");
t2=C_fast_retrieve(lf[172]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* setup-download#get-temporary-directory in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_fcall f_1363(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,0,2))){
C_save_and_reclaim_args((void *)trf_1363,1,t1);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1367,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:67: temporary-directory");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[11]);
C_word av2[2];
av2[0]=*((C_word*)lf[11]+1);
av2[1]=t2;
tp(2,av2);}}

/* k2460 in k2457 in k2440 in k2433 in setup-download#deconstruct-url in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_2462(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_2462,2,av);}
a=C_alloc(4);
t2=C_a_i_string_to_number(&a,2,t1,C_fix(10));
if(C_truep(t2)){
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
f_2446(2,av2);}}
else{
C_trace("setup-download.scm:229: error");
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[96];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k2945 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2947(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_2947,2,av);}
a=C_alloc(7);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[32]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2953,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:301: ##sys#print");
t6=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[192];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k2938 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_2940(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2940,2,av);}
C_trace("setup-download.scm:305: display");
t2=*((C_word*)lf[127]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2942 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2944(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_2944,2,av);}
a=C_alloc(9);
C_trace("setup-download.scm:299: d");
f_1347(((C_word*)t0)[2],lf[190],C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2479(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +14,c,5))){
C_save_and_reclaim((void*)f_2479,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+14);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:C_i_car(t9));
t12=t11;
t13=C_i_nullp(t9);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t15=C_i_nullp(t14);
t16=(C_truep(t15)?C_SCHEME_FALSE:C_i_car(t14));
t17=t16;
t18=C_i_nullp(t14);
t19=(C_truep(t18)?C_SCHEME_END_OF_LIST:C_i_cdr(t14));
t20=C_i_nullp(t19);
t21=(C_truep(t20)?C_SCHEME_FALSE:C_i_car(t19));
t22=t21;
t23=C_i_nullp(t19);
t24=(C_truep(t23)?C_SCHEME_END_OF_LIST:C_i_cdr(t19));
t25=C_i_nullp(t24);
t26=(C_truep(t25)?C_SCHEME_FALSE:C_i_car(t24));
t27=t26;
t28=C_i_nullp(t24);
t29=(C_truep(t28)?C_SCHEME_END_OF_LIST:C_i_cdr(t24));
t30=C_i_nullp(t29);
t31=(C_truep(t30)?C_SCHEME_FALSE:C_i_car(t29));
t32=t31;
t33=C_i_nullp(t29);
t34=(C_truep(t33)?C_SCHEME_END_OF_LIST:C_i_cdr(t29));
t35=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2521,a[2]=t3,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
t36=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2527,a[2]=t7,a[3]=t22,a[4]=t27,a[5]=t32,a[6]=t2,a[7]=t12,a[8]=t17,a[9]=((C_word)li40),tmp=(C_word)a,a+=10,tmp);
C_trace("setup-download.scm:234: ##sys#call-with-values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t35;
av2[3]=t36;
C_call_with_values(4,av2);}}

/* k2857 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in ... */
static void C_ccall f_2859(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_2859,2,av);}
a=C_alloc(5);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2868,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:334: d");
f_1347(t2,lf[177],C_SCHEME_END_OF_LIST);}
else{
C_trace("setup-download.scm:338: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)((C_word*)t0)[3])[1];
av2[3]=((C_word*)((C_word*)t0)[5])[1];
C_values(4,av2);}}}

/* k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_2856(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_2856,2,av);}
a=C_alloc(14);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2880(t6,t2);}

/* k2440 in k2433 in setup-download#deconstruct-url in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2442(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_2442,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2446,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2459,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("setup-download.scm:226: irregex-match-substring");
t5=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[3];
av2[3]=C_fix(3);
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=t4;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_2459(2,av2);}}}

/* k2444 in k2440 in k2433 in setup-download#deconstruct-url in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_2446(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_2446,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
C_trace("setup-download.scm:231: irregex-match-substring");
t4=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
av2[3]=C_fix(5);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_2450(2,av2);}}}

/* k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_2850(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_2850,2,av);}
a=C_alloc(17);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,tmp=(C_word)a,a+=14,tmp);
C_trace("setup-download.scm:314: d");
f_1347(t3,lf[185],C_a_i_list(&a,1,((C_word*)t0)[12]));}

/* k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_ccall f_2853(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(19,c,3))){C_save_and_reclaim((void *)f_2853,2,av);}
a=C_alloc(19);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2906,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
C_trace("setup-download.scm:316: response-match-code?");
f_2785(t3,((C_word*)t0)[13],C_fix(407));}

/* k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1315(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1315,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_tcp_toplevel(2,av2);}}

/* k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1318(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1318,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_srfi_2d13_toplevel(2,av2);}}

/* k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1312(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1312,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_data_2dstructures_toplevel(2,av2);}}

/* k1580 in a1570 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_1582(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1582,2,av);}
C_trace("setup-download.scm:103: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
C_values(4,av2);}}

/* k2925 in a2916 in k2904 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in ... */
static void C_ccall f_2927(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2927,2,av);}
C_trace("setup-download.scm:319: display");
t2=*((C_word*)lf[127]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2448 in k2444 in k2440 in k2433 in setup-download#deconstruct-url in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_2450(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_2450,2,av);}
if(C_truep(t1)){
t2=t1;
C_trace("setup-download.scm:224: values");{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=t2;
C_values(5,av2);}}
else{
C_trace("setup-download.scm:224: values");{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=lf[95];
C_values(5,av2);}}}

/* setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_fcall f_2808(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(23,0,3))){
C_save_and_reclaim_args((void *)trf_2808,7,t1,t2,t3,t4,t5,t6,t7);}
a=C_alloc(23);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2812,a[2]=t5,a[3]=t2,a[4]=t6,a[5]=t3,a[6]=t4,a[7]=t7,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2944,a[2]=t8,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2947,a[2]=t9,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:301: open-output-string");
t11=C_fast_retrieve(lf[37]);{
C_word av2[2];
av2[0]=t11;
av2[1]=t10;
((C_proc)(void*)(*((C_word*)t11+1)))(2,av2);}}
else{
C_trace("setup-download.scm:299: d");
f_1347(t8,lf[190],C_a_i_list(&a,3,t2,t3,lf[193]));}}

/* k1586 in k1583 in a1570 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in ... */
static void C_ccall f_1588(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_1588,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1603,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:106: file-exists?");
t4=C_fast_retrieve(lf[24]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1583 in a1570 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_1585(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_1585,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1588,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
if(C_truep(((C_word*)t0)[5])){
C_trace("setup-download.scm:82: warning");
t5=C_fast_retrieve(lf[25]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t5;
av2[1]=t3;
av2[2]=lf[26];
av2[3]=t4;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t5+1)))(5,av2);}}
else{
t5=C_SCHEME_UNDEFINED;
t6=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t6;
av2[1]=t5;
f_1588(2,av2);}}}

/* k2457 in k2440 in k2433 in setup-download#deconstruct-url in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_2459(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_2459,2,av);}
a=C_alloc(3);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2462,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:227: irregex-match-substring");
t3=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=C_fix(4);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(80);
f_2446(2,av2);}}}

/* k2798 in k2794 in setup-download#response-match-code? in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2800(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2800,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_string_equal_p(((C_word*)t0)[3],t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_2838(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_2838,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download.scm:309: flush-output");
t3=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)((C_word*)t0)[4])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2831(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_2831,4,av);}
a=C_alloc(18);
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=t3;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2835,a[2]=t5,a[3]=t1,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download.scm:304: d");
f_1347(t8,lf[189],C_a_i_list(&a,1,((C_word*)t0)[4]));}

/* k1592 in k1586 in k1583 in a1570 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_1594(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1594,2,av);}
if(C_truep(t1)){
C_trace("setup-download.scm:107: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[21];
C_values(4,av2);}}
else{
C_trace("setup-download.scm:108: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[22];
C_values(4,av2);}}}

/* k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_2835(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(39,c,5))){C_save_and_reclaim((void *)f_2835,2,av);}
a=C_alloc(39);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2940,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:306: make-HTTP-GET/1.1");
f_2720(t3,((C_word*)t0)[7],C_retrieve2(lf[1],"setup-download#\052chicken-install-user-agent\052"),((C_word*)t0)[8],C_a_i_list(&a,8,lf[169],((C_word*)t0)[9],lf[166],lf[188],lf[143],((C_word*)t0)[5],lf[182],((C_word*)t0)[6]));}

/* setup-download#retrieve-extension in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_3348(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-5)*C_SIZEOF_PAIR +20,c,4))){
C_save_and_reclaim((void*)f_3348,c,av);}
a=C_alloc((c-5)*C_SIZEOF_PAIR+20);
t5=C_build_rest(&a,c,5,av);
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
t6=C_i_get_keyword(lf[202],t5,C_SCHEME_FALSE);
t7=t6;
t8=C_i_get_keyword(lf[203],t5,C_SCHEME_FALSE);
t9=t8;
t10=C_i_get_keyword(lf[204],t5,C_SCHEME_FALSE);
t11=t10;
t12=C_i_get_keyword(lf[205],t5,C_SCHEME_FALSE);
t13=t12;
t14=C_i_get_keyword(lf[206],t5,C_SCHEME_FALSE);
t15=t14;
t16=C_i_get_keyword(lf[207],t5,C_SCHEME_FALSE);
t17=t16;
t18=C_i_get_keyword(lf[143],t5,C_SCHEME_FALSE);
t19=t18;
t20=C_i_get_keyword(lf[182],t5,C_SCHEME_FALSE);
t21=t20;
t22=C_i_get_keyword(lf[144],t5,C_SCHEME_FALSE);
t23=t22;
t24=C_i_get_keyword(lf[208],t5,C_SCHEME_FALSE);
t25=t24;
t26=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3382,a[2]=t5,a[3]=t9,a[4]=t25,a[5]=t3,a[6]=t2,a[7]=t4,a[8]=t7,a[9]=t11,a[10]=t13,a[11]=t15,a[12]=t17,a[13]=t19,a[14]=t21,a[15]=t23,a[16]=t1,tmp=(C_word)a,a+=17,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3450,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:437: ##sys#get-keyword");
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[163]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[163]+1);
av2[1]=t26;
av2[2]=lf[215];
av2[3]=t5;
av2[4]=t27;
tp(5,av2);}}

/* k2794 in setup-download#response-match-code? in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2796(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_2796,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2800,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:293: irregex-match-substring");
t4=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
av2[3]=C_fix(1);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k3341 in setup-download#check-egg-name in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_3343(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3343,2,av);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}
else{
C_trace("setup-download.scm:435: error");
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[196];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* a3476 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_3477(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3477,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate2(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k2866 in k2857 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in ... */
static void C_ccall f_2868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_2868,2,av);}
a=C_alloc(12);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3265,a[2]=t5,a[3]=t3,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3265(t7,t2,C_SCHEME_END_OF_LIST);}

/* k2904 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_2906(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,4))){C_save_and_reclaim((void *)f_2906,2,av);}
a=C_alloc(16);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li51),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2917,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[9],a[10]=((C_word)li52),tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download.scm:317: ##sys#call-with-values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[10];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2933,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:325: response-match-code?");
f_2785(t2,((C_word*)t0)[12],C_fix(200));}}

/* setup-download#deconstruct-url in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_fcall f_2431(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,3))){
C_save_and_reclaim_args((void *)trf_2431,2,t1,t2);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2435,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:223: irregex-match");
t4=C_fast_retrieve(lf[97]);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[98];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2900 in k2888 in k2882 in loop in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in ... */
static void C_ccall f_2902(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_2902,2,av);}
a=C_alloc(7);
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f3793,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:331: d");
f_1347(t3,lf[178],C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f3797,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:331: d");
f_1347(t2,lf[178],C_a_i_list(&a,1,((C_word*)t0)[5]));}}

/* k2433 in setup-download#deconstruct-url in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2435(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_2435,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2442,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
C_trace("setup-download.scm:225: irregex-match-substring");
t4=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_fix(2);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
f_2442(2,av2);}}}

/* setup-download#check-egg-name in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_fcall f_3336(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,0,3))){
C_save_and_reclaim_args((void *)trf_3336,2,t1,t2);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3343,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=t3;
t5=t2;
if(C_truep((C_truep(C_i_equalp(t5,lf[197]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t5,lf[198]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t5,lf[199]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t6=t4;{
C_word av2[2];
av2[0]=t6;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t6+1)))(2,av2);}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3330,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:431: string-index");
t7=C_fast_retrieve(lf[200]);{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=t5;
av2[3]=C_retrieve2(lf[194],"setup-download#slashes");
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}

/* setup-download#response-match-code? in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_fcall f_2785(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,2))){
C_save_and_reclaim_args((void *)trf_2785,3,t1,t2,t3);}
a=C_alloc(4);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2796,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:293: number->string");
t5=*((C_word*)lf[171]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k3328 in setup-download#check-egg-name in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_3330(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3330,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_i_not(t1);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a2816 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2817(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2817,2,av);}
t2=((C_word*)t0)[2];
t3=(C_truep(t2)?t2:((C_word*)t0)[3]);
t4=((C_word*)t0)[4];
if(C_truep(t4)){
C_trace("setup-download.scm:303: tcp-connect");
t5=C_fast_retrieve(lf[172]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t5=((C_word*)t0)[5];
C_trace("setup-download.scm:303: tcp-connect");
t6=C_fast_retrieve(lf[172]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=t3;
av2[3]=t5;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}

/* k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2812(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(16,c,4))){C_save_and_reclaim((void *)f_2812,2,av);}
a=C_alloc(16);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word)li53),tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:303: ##sys#call-with-values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[8];
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* a2766 in k2722 in setup-download#make-HTTP-GET/1.1 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2767(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2767,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[167];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a2760 in k2728 in k2725 in k2722 in setup-download#make-HTTP-GET/1.1 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_2761(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2761,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_fix(0);
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* a2763 in k2725 in k2722 in setup-download#make-HTTP-GET/1.1 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_2764(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2764,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[165];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_3453(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +24,c,4))){
C_save_and_reclaim((void*)f_3453,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+24);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
t5=C_i_get_keyword(lf[203],t4,C_SCHEME_FALSE);
t6=C_i_get_keyword(lf[205],t4,C_SCHEME_FALSE);
t7=t6;
t8=C_i_get_keyword(lf[206],t4,C_SCHEME_FALSE);
t9=t8;
t10=C_i_get_keyword(lf[143],t4,C_SCHEME_FALSE);
t11=t10;
t12=C_i_get_keyword(lf[182],t4,C_SCHEME_FALSE);
t13=t12;
t14=C_i_get_keyword(lf[144],t4,C_SCHEME_FALSE);
t15=t14;
t16=t5;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3477,a[2]=t19,a[3]=t17,a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp);
t21=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3482,a[2]=t2,a[3]=t3,a[4]=t7,a[5]=t9,a[6]=t11,a[7]=t13,a[8]=t15,a[9]=((C_word)li68),tmp=(C_word)a,a+=10,tmp);
t22=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3521,a[2]=t17,a[3]=t19,a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:455: ##sys#dynamic-wind");
t23=*((C_word*)lf[214]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t23;
av2[1]=t1;
av2[2]=t20;
av2[3]=t21;
av2[4]=t22;
((C_proc)(void*)(*((C_word*)t23+1)))(5,av2);}}

/* a3449 in setup-download#retrieve-extension in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_3450(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3450,2,av);}
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[4];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k2751 in k2747 in k2731 in k2728 in k2725 in k2722 in setup-download#make-HTTP-GET/1.1 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_2753(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,24))){C_save_and_reclaim((void *)f_2753,2,av);}
C_trace("setup-download.scm:272: conc");
t2=C_fast_retrieve(lf[65]);{
C_word *av2;
if(c >= 25) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(25);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[145];
av2[3]=((C_word*)t0)[3];
av2[4]=lf[146];
av2[5]=lf[147];
av2[6]=lf[148];
av2[7]=((C_word*)t0)[4];
av2[8]=lf[149];
av2[9]=lf[150];
av2[10]=((C_word*)t0)[5];
av2[11]=lf[151];
av2[12]=lf[152];
av2[13]=((C_word*)t0)[6];
av2[14]=lf[153];
av2[15]=lf[154];
av2[16]=((C_word*)t0)[7];
av2[17]=C_make_character(58);
av2[18]=((C_word*)t0)[8];
av2[19]=lf[155];
av2[20]=t1;
av2[21]=lf[156];
av2[22]=((C_word*)t0)[9];
av2[23]=lf[157];
av2[24]=lf[158];
((C_proc)(void*)(*((C_word*)t2+1)))(25,av2);}}

/* a3440 in k3386 in k3380 in setup-download#retrieve-extension in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_3441(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3441,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#\052trunk\052"));
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,C_retrieve2(lf[3],"setup-download#\052mode\052"));
t5=C_mutate2(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate2(&lf[2] /* (set! setup-download#*trunk* ...) */,((C_word*)((C_word*)t0)[6])[1]);
t7=C_mutate2(&lf[3] /* (set! setup-download#*mode* ...) */,((C_word*)((C_word*)t0)[7])[1]);
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* a1852 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_1853(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_1853,4,av);}
a=C_alloc(5);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1857,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:138: make-pathname");
t6=C_fast_retrieve(lf[20]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
av2[3]=((C_word*)t0)[2];
av2[4]=lf[59];
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k1855 in a1852 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_1857(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_1857,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:139: file-exists?");
t4=C_fast_retrieve(lf[24]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2747 in k2731 in k2728 in k2725 in k2722 in setup-download#make-HTTP-GET/1.1 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in ... */
static void C_ccall f_2749(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_2749,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2753,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[9])){
C_trace("setup-download.scm:283: string-append");
t4=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[159];
av2[3]=((C_word*)t0)[9];
av2[4]=lf[160];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=lf[161];
f_2753(2,av2);}}}

/* setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1832(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_1832,3,av);}
a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1836,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:134: directory");
t4=C_fast_retrieve(lf[48]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1836(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1836,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[2],a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:135: filter-map");
t3=C_fast_retrieve(lf[60]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t2;
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k3291 in k3308 in get-chunks in k2866 in k2857 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in ... */
static void C_ccall f_3293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_3293,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3296,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:423: d");
f_1347(t3,lf[175],C_SCHEME_END_OF_LIST);}

/* k2725 in k2722 in setup-download#make-HTTP-GET/1.1 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2727(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_2727,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2764,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:265: ##sys#get-keyword");
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[163]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[163]+1);
av2[1]=t3;
av2[2]=lf[166];
av2[3]=((C_word*)t0)[2];
av2[4]=t4;
tp(5,av2);}}

/* k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in ... */
static void C_ccall f_2847(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_2847,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_stringp(t2))){
C_trace("setup-download.scm:290: irregex-match");
t4=C_fast_retrieve(lf[97]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[186];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_2850(2,av2);}}}

/* k2722 in setup-download#make-HTTP-GET/1.1 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2724(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,4))){C_save_and_reclaim((void *)f_2724,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2767,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:265: ##sys#get-keyword");
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[163]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[163]+1);
av2[1]=t3;
av2[2]=lf[168];
av2[3]=((C_word*)t0)[2];
av2[4]=t4;
tp(5,av2);}}

/* setup-download#make-HTTP-GET/1.1 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_fcall f_2720(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,4))){
C_save_and_reclaim_args((void *)trf_2720,5,t1,t2,t3,t4,t5);}
a=C_alloc(10);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2724,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2770,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:265: ##sys#get-keyword");
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[163]+1));
C_word av2[5];
av2[0]=*((C_word*)lf[163]+1);
av2[1]=t6;
av2[2]=lf[169];
av2[3]=t5;
av2[4]=t7;
tp(5,av2);}}

/* k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in ... */
static void C_ccall f_2841(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_2841,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download.scm:310: d");
f_1347(t2,lf[187],C_SCHEME_END_OF_LIST);}

/* k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_2844(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,c,2))){C_save_and_reclaim((void *)f_2844,2,av);}
a=C_alloc(14);
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2847,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("setup-download.scm:312: read-line");
t5=C_fast_retrieve(lf[115]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)((C_word*)t0)[2])[1];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}

/* k3297 in k3294 in k3291 in k3308 in get-chunks in k2866 in k2857 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in ... */
static void C_ccall f_3299(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3299,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
C_trace("setup-download.scm:425: get-chunks");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3265(t3,((C_word*)t0)[5],t2);}

/* k3294 in k3291 in k3308 in get-chunks in k2866 in k2857 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in ... */
static void C_ccall f_3296(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3296,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:424: read-line");
t3=C_fast_retrieve(lf[115]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k1861 in k1855 in a1852 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in ... */
static void C_ccall f_1863(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1863,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:140: call/cc");
t3=*((C_word*)lf[58]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[5];
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[5];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* a1867 in k1861 in k1855 in a1852 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_1868(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_1868,3,av);}
a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:142: string->symbol");
t4=*((C_word*)lf[57]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2716 in k2712 in k2931 in k2904 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in ... */
static void C_ccall f_2718(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2718,2,av);}
C_trace("setup-download.scm:258: make-composite-condition");
t2=C_fast_retrieve(lf[117]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2712 in k2931 in k2904 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in ... */
static void C_ccall f_2714(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2714,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:263: make-property-condition");
t4=C_fast_retrieve(lf[118]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[183];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2708 in k2931 in k2904 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in ... */
static void C_ccall f_2710(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2710,2,av);}
C_trace("setup-download.scm:257: signal");
t2=C_fast_retrieve(lf[100]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1653 in k1637 in k1634 in k1631 in k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in ... */
static void C_ccall f_1655(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1655,2,av);}
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
C_trace("setup-download.scm:120: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
C_values(4,av2);}}
else{
C_trace("setup-download.scm:121: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=lf[29];
C_values(4,av2);}}}

/* k1656 in k1631 in k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in ... */
static void C_ccall f_1658(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_1658,2,av);}
a=C_alloc(7);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[32]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1664,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:116: ##sys#print");
t6=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[36];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k1665 in k1662 in k1656 in k1631 in k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in ... */
static void C_ccall f_1667(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1667,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:116: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[35]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[35]+1);
av2[1]=t2;
av2[2]=C_make_character(32);
av2[3]=((C_word*)t0)[5];
tp(4,av2);}}

/* k1662 in k1656 in k1631 in k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in ... */
static void C_ccall f_1664(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_1664,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:116: ##sys#print");
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1668 in k1665 in k1662 in k1656 in k1631 in k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in ... */
static void C_ccall f_1670(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1670,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:116: ##sys#print");
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2728 in k2725 in k2722 in setup-download#make-HTTP-GET/1.1 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_2730(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,4))){C_save_and_reclaim((void *)f_2730,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2761,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:265: ##sys#get-keyword");
{C_proc tp=(C_proc)C_fast_retrieve_proc(*((C_word*)lf[163]+1));
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=*((C_word*)lf[163]+1);
av2[1]=t3;
av2[2]=lf[164];
av2[3]=((C_word*)t0)[2];
av2[4]=t4;
tp(5,av2);}}

/* k2731 in k2728 in k2725 in k2722 in setup-download#make-HTTP-GET/1.1 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_2733(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,4))){C_save_and_reclaim((void *)f_2733,2,av);}
a=C_alloc(10);
t2=t1;
t3=C_i_get_keyword(lf[143],((C_word*)t0)[2],C_SCHEME_FALSE);
t4=C_i_get_keyword(lf[144],((C_word*)t0)[2],C_SCHEME_FALSE);
t5=t4;
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2749,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=t5,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
C_trace("setup-download.scm:275: string-append");
t7=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[162];
av2[3]=((C_word*)t0)[7];
av2[4]=((C_word*)t0)[9];
((C_proc)(void*)(*((C_word*)t7+1)))(5,av2);}}
else{
t7=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=((C_word*)t0)[9];
f_2749(2,av2);}}}

/* k1677 in k1631 in k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in ... */
static void C_ccall f_1679(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,4))){C_save_and_reclaim((void *)f_1679,2,av);}
a=C_alloc(7);
t2=t1;
t3=t2;
t4=C_i_check_port_2(t3,C_SCHEME_FALSE,C_SCHEME_TRUE,lf[32]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:117: ##sys#print");
t6=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=lf[39];
av2[3]=C_SCHEME_FALSE;
av2[4]=t3;
((C_proc)(void*)(*((C_word*)t6+1)))(5,av2);}}

/* k1671 in k1668 in k1665 in k1662 in k1656 in k1631 in k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in ... */
static void C_ccall f_1673(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1673,2,av);}
C_trace("setup-download.scm:116: get-output-string");
t2=C_fast_retrieve(lf[33]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a1931 in a1925 in a1913 in a1892 in k1874 in a1867 in k1861 in k1855 in a1852 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in ... */
static void C_ccall f_1932(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1932,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* setup-download#make-svn-ls-cmd in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_fcall f_1938(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_1938,5,t1,t2,t3,t4,t5);}
a=C_alloc(6);
t6=C_i_get_keyword(lf[62],t5,C_SCHEME_FALSE);
t7=(C_truep(t6)?lf[63]:lf[64]);
t8=t7;
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1953,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:154: qs");
t10=C_fast_retrieve(lf[40]);{
C_word av2[3];
av2[0]=t10;
av2[1]=t9;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t10+1)))(3,av2);}}

/* k3255 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in ... */
static void C_ccall f_3257(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_3257,2,av);}
C_trace("setup-download.scm:407: make-property-condition");
t2=C_fast_retrieve(lf[118]);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[120];
av2[3]=lf[121];
av2[4]=t1;
av2[5]=lf[122];
av2[6]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* a3392 in k3386 in k3380 in setup-download#retrieve-extension in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_3393(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3393,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate2(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#\052trunk\052"));
t4=C_mutate2(((C_word *)((C_word*)t0)[4])+1,C_retrieve2(lf[3],"setup-download#\052mode\052"));
t5=C_mutate2(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate2(&lf[2] /* (set! setup-download#*trunk* ...) */,((C_word*)((C_word*)t0)[6])[1]);
t7=C_mutate2(&lf[3] /* (set! setup-download#*mode* ...) */,((C_word*)((C_word*)t0)[7])[1]);
t8=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t8;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t8+1)))(2,av2);}}

/* k1686 in k1683 in k1677 in k1631 in k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in ... */
static void C_ccall f_1688(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_1688,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:117: ##sys#print");
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[38];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1683 in k1677 in k1631 in k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in ... */
static void C_ccall f_1685(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_1685,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:117: ##sys#print");
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k3251 in k3247 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in ... */
static void C_ccall f_3253(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3253,2,av);}
C_trace("setup-download.scm:406: make-composite-condition");
t2=C_fast_retrieve(lf[117]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k3285 in k3308 in get-chunks in k2866 in k2857 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in ... */
static void C_ccall f_3287(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3287,2,av);}
C_trace("setup-download.scm:420: string-concatenate-reverse");
t2=C_fast_retrieve(lf[173]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3386 in k3380 in setup-download#retrieve-extension in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_3388(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(45,c,4))){C_save_and_reclaim((void *)f_3388,2,av);}
a=C_alloc(45);
t2=((C_word*)t0)[2];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[3];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t0)[4];
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3393,a[2]=t9,a[3]=t11,a[4]=t13,a[5]=t3,a[6]=t5,a[7]=t7,a[8]=((C_word)li56),tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3402,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word)li57),tmp=(C_word)a,a+=15,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3441,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t9,a[6]=t11,a[7]=t13,a[8]=((C_word)li58),tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:442: ##sys#dynamic-wind");
t17=*((C_word*)lf[214]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t17;
av2[1]=((C_word*)t0)[17];
av2[2]=t14;
av2[3]=t15;
av2[4]=t16;
((C_proc)(void*)(*((C_word*)t17+1)))(5,av2);}}

/* k3380 in setup-download#retrieve-extension in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_3382(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(18,c,2))){C_save_and_reclaim((void *)f_3382,2,av);}
a=C_alloc(18);
t2=t1;
t3=C_i_get_keyword(lf[209],((C_word*)t0)[2],C_SCHEME_FALSE);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3388,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
C_trace("setup-download.scm:441: check-egg-name");
f_3336(t5,((C_word*)t0)[6]);}

/* k3233 in k3230 in k3227 in a3224 in a3208 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in ... */
static void C_ccall f_3235(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3235,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_1627(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_1627,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1705,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:113: normalize-pathname");
t4=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3230 in k3227 in a3224 in a3208 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_3232(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3232,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:401: close-output-port");
t3=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* get-chunks in k2866 in k2857 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in ... */
static void C_fcall f_3265(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,2))){
C_save_and_reclaim_args((void *)trf_3265,3,t0,t1,t2);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3310,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:415: read-line");
t4=C_fast_retrieve(lf[115]);{
C_word av2[3];
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_ccall f_1630(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,2))){C_save_and_reclaim((void *)f_1630,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1701,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:114: normalize-pathname");
t4=C_fast_retrieve(lf[41]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k1631 in k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_1633(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_1633,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[5],"setup-download#\052windows-shell\052"))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1658,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:116: open-output-string");
t4=C_fast_retrieve(lf[37]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1679,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:117: open-output-string");
t4=C_fast_retrieve(lf[37]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k1634 in k1631 in k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in ... */
static void C_ccall f_1636(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_1636,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:118: d");
f_1347(t3,lf[31],C_a_i_list(&a,1,t2));}

/* k1637 in k1634 in k1631 in k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in ... */
static void C_ccall f_1639(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_1639,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:119: system");
t3=C_fast_retrieve(lf[30]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* a3214 in a3208 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_3215(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_3215,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3223,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm:397: string-append");
t3=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[7];
av2[3]=lf[231];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k3247 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in ... */
static void C_ccall f_3249(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3249,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3253,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:411: make-property-condition");
t4=C_fast_retrieve(lf[118]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[119];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3243 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in ... */
static void C_ccall f_3245(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3245,2,av);}
C_trace("setup-download.scm:405: abort");
t2=C_fast_retrieve(lf[116]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in ... */
static void C_ccall f_3074(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_3074,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3080,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_pairp(t2))){
t4=C_u_i_car(t2);
t5=t3;
f_3080(t5,C_eqp(lf[15],t4));}
else{
t4=t3;
f_3080(t4,C_SCHEME_FALSE);}}

/* a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_3482(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,5))){C_save_and_reclaim((void *)f_3482,2,av);}
a=C_alloc(11);
t2=((C_word*)t0)[2];
t3=C_eqp(t2,lf[210]);
if(C_truep(t3)){
t4=t1;
t5=((C_word*)t0)[3];
t6=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t8)[1];
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1428,a[2]=t4,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:85: directory");
t11=C_fast_retrieve(lf[48]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t11;
av2[1]=t10;
av2[2]=t5;
((C_proc)(void*)(*((C_word*)t11+1)))(3,av2);}}
else{
t4=C_eqp(t2,lf[211]);
if(C_truep(t4)){
t5=t1;
t6=((C_word*)t0)[3];
t7=C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[5]);
t8=C_i_nullp(t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:C_i_car(t7));
t10=C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:C_i_cdr(t7));
t12=C_i_nullp(t11);
t13=(C_truep(t12)?C_SCHEME_FALSE:C_i_car(t11));
t14=t13;
t15=C_i_nullp(t11);
t16=(C_truep(t15)?C_SCHEME_END_OF_LIST:C_i_cdr(t11));
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1981,a[2]=t5,a[3]=t6,a[4]=t14,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
C_trace("setup-download.scm:161: string-append");
t18=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t18;
av2[1]=t17;
av2[2]=lf[228];
av2[3]=t9;
av2[4]=lf[229];
((C_proc)(void*)(*((C_word*)t18+1)))(5,av2);}}
else{
t18=t17;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t18;
av2[1]=lf[230];
f_1981(2,av2);}}}
else{
t5=C_eqp(t2,lf[212]);
if(C_truep(t5)){
t6=t1;
t7=((C_word*)t0)[3];
t8=((C_word*)t0)[6];
t9=((C_word*)t0)[7];
t10=((C_word*)t0)[8];
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3203,a[2]=t7,a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3209,a[2]=t8,a[3]=t9,a[4]=t10,a[5]=((C_word)li67),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:392: ##sys#call-with-values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t6;
av2[2]=t11;
av2[3]=t12;
C_call_with_values(4,av2);}}
else{
C_trace("setup-download.scm:466: error");
t6=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=lf[233];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}}}

/* k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in ... */
static void C_ccall f_3071(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_3071,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
C_trace("setup-download.scm:367: read");
t4=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in ... */
static void C_fcall f_3067(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,2))){
C_save_and_reclaim_args((void *)trf_3067,3,t0,t1,t2);}
a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3071,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:366: skip");
t4=((C_word*)((C_word*)t0)[7])[1];
f_2976(t4,t3);}

/* k3227 in a3224 in a3208 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in ... */
static void C_ccall f_3229(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3229,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3232,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:400: close-input-port");
t4=*((C_word*)lf[125]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* a3224 in a3208 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_3225(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_3225,4,av);}
a=C_alloc(5);
t4=t2;
t5=t3;
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3229,a[2]=t1,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:399: read-all");
t7=C_fast_retrieve(lf[232]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k3221 in a3214 in a3208 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in ... */
static void C_ccall f_3223(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,7))){C_save_and_reclaim((void *)f_3223,2,av);}
C_trace("setup-download.scm:395: http-connect");
f_2808(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}

/* k3051 in k3042 in k2993 in k2987 in k2978 in skip in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in ... */
static void C_ccall f_3053(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3053,2,av);}
if(C_truep(t1)){
C_trace("setup-download.scm:361: skip");
t2=((C_word*)((C_word*)t0)[2])[1];
f_2976(t2,((C_word*)t0)[3]);}
else{
C_trace("setup-download.scm:363: error");
t2=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[109];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}}

/* a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in ... */
static void C_ccall f_1608(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_1608,4,av);}
a=C_alloc(8);
t4=t2;
t5=t3;
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1769,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm:109: file-exists?");
t7=C_fast_retrieve(lf[24]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* k1601 in k1586 in k1583 in a1570 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_1603(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1603,2,av);}
if(C_truep(t1)){
C_trace("setup-download.scm:106: directory?");
t2=C_fast_retrieve(lf[23]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
C_trace("setup-download.scm:108: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[4];
av2[2]=((C_word*)t0)[5];
av2[3]=lf[22];
C_values(4,av2);}}}

/* k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_3314(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,5))){C_save_and_reclaim((void *)f_3314,2,av);}
a=C_alloc(12);
t2=C_mutate2(&lf[194] /* (set! setup-download#slashes ...) */,t1);
t3=C_mutate2(&lf[195] /* (set! setup-download#check-egg-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3336,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate2((C_word*)lf[201]+1 /* (set! setup-download#retrieve-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3348,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate2((C_word*)lf[216]+1 /* (set! setup-download#list-extensions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3453,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate2((C_word*)lf[234]+1 /* (set! setup-download#list-extension-versions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3526,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t7+1)))(2,av2);}}

/* k3308 in get-chunks in k2866 in k2857 in k2854 in k2851 in k2848 in k2845 in k2842 in k2839 in k2836 in k2833 in a2830 in k2810 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in ... */
static void C_ccall f_3310(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_3310,2,av);}
a=C_alloc(10);
t2=C_a_i_string_to_number(&a,2,t1,C_fix(16));
if(C_truep(t2)){
if(C_truep(C_i_zerop(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:419: d");
f_1347(t3,lf[174],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3293,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("read-string/port");
t4=C_fast_retrieve(lf[130]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}
else{
C_trace("setup-download.scm:417: error");
t3=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[176];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* a3202 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_3203(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3203,2,av);}
C_trace("setup-download.scm:393: deconstruct-url");
f_2431(t1,((C_word*)t0)[2]);}

/* a3520 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_3521(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3521,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate2(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a3208 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_3209(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_3209,5,av);}
a=C_alloc(12);
t5=t2;
t6=t3;
t7=t4;
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3215,a[2]=t5,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t7,a[8]=((C_word)li65),tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3225,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:392: ##sys#call-with-values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t8;
av2[3]=t9;
C_call_with_values(4,av2);}}

/* k1689 in k1686 in k1683 in k1677 in k1631 in k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in ... */
static void C_ccall f_1691(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_1691,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:117: ##sys#print");
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1692 in k1689 in k1686 in k1683 in k1677 in k1631 in k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in ... */
static void C_ccall f_1694(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1694,2,av);}
C_trace("setup-download.scm:117: get-output-string");
t2=C_fast_retrieve(lf[33]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_3539(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(22,c,4))){C_save_and_reclaim((void *)f_3539,2,av);}
a=C_alloc(22);
t2=((C_word*)t0)[2];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3544,a[2]=t5,a[3]=t3,a[4]=((C_word)li71),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li74),tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3577,a[2]=t3,a[3]=t5,a[4]=((C_word)li75),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:470: ##sys#dynamic-wind");
t9=*((C_word*)lf[214]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t9;
av2[1]=((C_word*)t0)[8];
av2[2]=t6;
av2[3]=t7;
av2[4]=t8;
((C_proc)(void*)(*((C_word*)t9+1)))(5,av2);}}

/* k3022 in k3019 in k3001 in g732 in k2993 in k2987 in k2978 in skip in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in ... */
static void C_ccall f_3024(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3024,2,av);}
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
C_trace("setup-download.scm:357: open-input-string");
t3=C_fast_retrieve(lf[104]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k3019 in k3001 in g732 in k2993 in k2987 in k2978 in skip in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in ... */
static void C_fcall f_3021(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,4))){
C_save_and_reclaim_args((void *)trf_3021,2,t0,t1);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:353: warning");
t3=C_fast_retrieve(lf[25]);{
C_word av2[5];
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[108];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)((C_word*)t0)[2])[1];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}
else{
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[5]);
C_trace("setup-download.scm:357: open-input-string");
t3=C_fast_retrieve(lf[104]);{
C_word av2[3];
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}}

/* setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_3526(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word *a;
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-5)*C_SIZEOF_PAIR +9,c,2))){
C_save_and_reclaim((void*)f_3526,c,av);}
a=C_alloc((c-5)*C_SIZEOF_PAIR+9);
t5=C_build_rest(&a,c,5,av);
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t6=C_i_get_keyword(lf[203],t5,C_SCHEME_FALSE);
t7=t6;
t8=C_i_get_keyword(lf[205],t5,C_SCHEME_FALSE);
t9=t8;
t10=C_i_get_keyword(lf[206],t5,C_SCHEME_FALSE);
t11=t10;
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3539,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t4,a[6]=t9,a[7]=t11,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:469: check-egg-name");
f_3336(t12,t2);}

/* k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in ... */
static void C_fcall f_3080(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,0,3))){
C_save_and_reclaim_args((void *)trf_3080,2,t0,t1);}
a=C_alloc(10);
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_u_i_cdr(((C_word*)t0)[2]);
t4=C_u_i_cdr(t3);
t5=((C_word*)t0)[3];
t6=t4;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3245,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3249,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3257,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:409: string-append");
t10=*((C_word*)lf[68]+1);{
C_word av2[4];
av2[0]=t10;
av2[1]=t9;
av2[2]=lf[123];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t10+1)))(4,av2);}}
else{
t2=C_eofp(((C_word*)t0)[2]);
t3=(C_truep(t2)?t2:C_i_not(((C_word*)t0)[2]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:371: close-input-port");
t5=*((C_word*)lf[125]+1);{
C_word av2[3];
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3120,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:376: string-suffix?");
t5=C_fast_retrieve(lf[45]);{
C_word av2[4];
av2[0]=t5;
av2[1]=t4;
av2[2]=lf[132];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
C_trace("setup-download.scm:375: error");
t4=*((C_word*)lf[15]+1);{
C_word av2[4];
av2[0]=t4;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[133];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}}}}

/* k3582 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_3584(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_3584,2,av);}
C_trace("setup-download.scm:54: conc");
t2=C_fast_retrieve(lf[65]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[252];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a3401 in k3386 in k3380 in setup-download#retrieve-extension in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_3402(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,9))){C_save_and_reclaim((void *)f_3402,2,av);}
t2=((C_word*)t0)[2];
t3=C_eqp(t2,lf[210]);
if(C_truep(t3)){
C_trace("setup-download.scm:447: locate-egg/local");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[19]);
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=*((C_word*)lf[19]+1);
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=((C_word*)t0)[6];
av2[6]=((C_word*)t0)[7];
tp(7,av2);}}
else{
t4=C_eqp(t2,lf[211]);
if(C_truep(t4)){
C_trace("setup-download.scm:449: locate-egg/svn");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[67]);
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=*((C_word*)lf[67]+1);
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=((C_word*)t0)[6];
av2[6]=((C_word*)t0)[8];
av2[7]=((C_word*)t0)[9];
tp(8,av2);}}
else{
t5=C_eqp(t2,lf[212]);
if(C_truep(t5)){
C_trace("setup-download.scm:451: locate-egg/http");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[99]);
C_word *av2;
if(c >= 10) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(10);
}
av2[0]=*((C_word*)lf[99]+1);
av2[1]=t1;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
av2[4]=((C_word*)t0)[5];
av2[5]=((C_word*)t0)[6];
av2[6]=((C_word*)t0)[10];
av2[7]=((C_word*)t0)[11];
av2[8]=((C_word*)t0)[12];
av2[9]=((C_word*)t0)[13];
tp(10,av2);}}
else{
C_trace("setup-download.scm:453: error");
t6=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t1;
av2[2]=lf[213];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}}}}

/* k3042 in k2993 in k2987 in k2978 in skip in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in ... */
static void C_ccall f_3044(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_3044,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
C_trace("setup-download.scm:359: open-input-string");
t2=C_fast_retrieve(lf[104]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3053,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:360: string-every");
t3=C_fast_retrieve(lf[110]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fast_retrieve(lf[111]);
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* a3543 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_3544(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3544,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate2(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_3549(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,4))){C_save_and_reclaim((void *)f_3549,2,av);}
a=C_alloc(12);
t2=((C_word*)t0)[2];
t3=C_eqp(t2,lf[210]);
if(C_truep(t3)){
t4=t1;
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1471,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1533,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:88: string-append");
t9=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t9;
av2[1]=t8;
av2[2]=t5;
av2[3]=lf[238];
((C_proc)(void*)(*((C_word*)t9+1)))(4,av2);}}
else{
t4=C_eqp(t2,lf[211]);
if(C_truep(t4)){
t5=t1;
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[4];
t8=C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_nullp(t12);
t14=(C_truep(t13)?C_SCHEME_FALSE:C_i_car(t12));
t15=t14;
t16=C_i_nullp(t12);
t17=(C_truep(t16)?C_SCHEME_END_OF_LIST:C_i_cdr(t12));
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2098,a[2]=t5,a[3]=t7,a[4]=t6,a[5]=t15,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t10)){
C_trace("setup-download.scm:170: string-append");
t19=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t19;
av2[1]=t18;
av2[2]=lf[246];
av2[3]=t10;
av2[4]=lf[247];
((C_proc)(void*)(*((C_word*)t19+1)))(5,av2);}}
else{
t19=t18;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t19;
av2[1]=lf[248];
f_2098(2,av2);}}}
else{
C_trace("setup-download.scm:477: error");
t5=*((C_word*)lf[15]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=lf[249];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}}}

/* k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in ... */
static void C_fcall f_1618(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,0,3))){
C_save_and_reclaim_args((void *)trf_1618,2,t0,t1);}
a=C_alloc(15);
if(C_truep(t1)){
C_trace("setup-download.scm:110: values");{
C_word av2[4];
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=C_SCHEME_FALSE;
av2[3]=lf[28];
C_values(4,av2);}}
else{
if(C_truep(((C_word*)t0)[3])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:112: create-directory");
t3=C_fast_retrieve(lf[42]);{
C_word av2[3];
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1714,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1750,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1758,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:125: directory");
t6=C_fast_retrieve(lf[48]);{
C_word av2[3];
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}
else{
C_trace("setup-download.scm:131: values");{
C_word av2[4];
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[4];
C_values(4,av2);}}}}}

/* k2297 in k2294 in k2291 in a2288 in k2254 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_2299(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_2299,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:215: system");
t3=C_fast_retrieve(lf[30]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2294 in k2291 in a2288 in k2254 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_ccall f_2296(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_2296,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:214: d");
f_1347(t3,lf[76],C_a_i_list(&a,1,t2));}

/* k2291 in a2288 in k2254 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_2293(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(17,c,6))){C_save_and_reclaim((void *)f_2293,2,av);}
a=C_alloc(17);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2296,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2319,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2336,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t6=C_eqp(C_retrieve2(lf[3],"setup-download#\052mode\052"),lf[80]);
if(C_truep(t6)){
t7=((C_word*)t0)[6];
C_trace("setup-download.scm:220: conc");
t8=C_fast_retrieve(lf[65]);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t8;
av2[1]=t5;
av2[2]=((C_word*)t0)[8];
av2[3]=C_make_character(47);
av2[4]=t7;
av2[5]=lf[81];
((C_proc)(void*)(*((C_word*)t8+1)))(6,av2);}}
else{
C_trace("setup-download.scm:204: conc");
t7=C_fast_retrieve(lf[65]);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t7;
av2[1]=t4;
av2[2]=((C_word*)t0)[7];
av2[3]=C_make_character(47);
av2[4]=((C_word*)t0)[6];
av2[5]=C_make_character(47);
av2[6]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t7+1)))(7,av2);}}}

/* k1706 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_1708(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1708,2,av);}
C_trace("setup-download.scm:131: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
C_values(4,av2);}}

/* k1703 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_ccall f_1705(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1705,2,av);}
C_trace("setup-download.scm:113: qs");
t2=C_fast_retrieve(lf[40]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1699 in k1628 in k1625 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_1701(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1701,2,av);}
C_trace("setup-download.scm:114: qs");
t2=C_fast_retrieve(lf[40]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3001 in g732 in k2993 in k2987 in k2978 in skip in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in ... */
static void C_ccall f_3003(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_3003,2,av);}
a=C_alloc(6);
t2=t1;
t3=C_i_string_equal_p(lf[106],t2);
t4=(C_truep(t3)?t3:C_u_i_string_equal_p(lf[107],t2));
if(C_truep(t4)){
C_trace("setup-download.scm:357: open-input-string");
t5=C_fast_retrieve(lf[104]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3021,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_string_equal_p(t2,((C_word*)((C_word*)t0)[4])[1]);
t7=t5;
f_3021(t7,C_i_not(t6));}
else{
t6=t5;
f_3021(t6,C_SCHEME_FALSE);}}}

/* a2288 in k2254 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in ... */
static void C_ccall f_2289(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_2289,4,av);}
a=C_alloc(13);
t4=t2;
t5=t3;
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2293,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2346,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[6])){
C_trace("setup-download.scm:201: make-pathname");
t8=C_fast_retrieve(lf[20]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t8;
av2[1]=t6;
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t8+1)))(4,av2);}}
else{
C_trace("setup-download.scm:201: get-temporary-directory");
f_1363(t7);}}

/* for-each-loop346 in k1712 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_fcall f_1727(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,0,3))){
C_save_and_reclaim_args((void *)trf_1727,3,t0,t1,t2);}
a=C_alloc(12);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1737,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=t4;
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1719,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:128: d");
f_1347(t7,lf[44],C_a_i_list(&a,1,t6));}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;{
C_word av2[2];
av2[0]=t4;
av2[1]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}}

/* k1717 in for-each-loop346 in k1712 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_1719(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1719,2,av);}
C_trace("setup-download.scm:129: delete-file*");
t2=C_fast_retrieve(lf[43]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a3576 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_3577(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3577,2,av);}
t2=C_mutate2(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate2(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
((C_proc)(void*)(*((C_word*)t4+1)))(2,av2);}}

/* k1712 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_1714(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1714,2,av);}
a=C_alloc(6);
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1727,a[2]=t3,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1727(t5,((C_word*)t0)[2],t1);}

/* a2260 in k2254 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in ... */
static void C_ccall f_2261(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_2261,2,av);}
a=C_alloc(4);
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2272,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:195: string-append");
t3=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[69];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2275,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
if(C_truep(((C_word*)t0)[5])){
C_trace("setup-download.scm:82: warning");
t4=C_fast_retrieve(lf[25]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=lf[26];
av2[3]=t3;
av2[4]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
if(C_truep(C_i_member(lf[70],((C_word*)t0)[3]))){
C_trace("setup-download.scm:199: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=lf[71];
av2[3]=lf[72];
C_values(4,av2);}}
else{
C_trace("setup-download.scm:200: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=lf[73];
av2[3]=lf[74];
C_values(4,av2);}}}}}

/* k2270 in a2260 in k2254 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_2272(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2272,2,av);}
C_trace("setup-download.scm:195: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
C_values(4,av2);}}

/* k2273 in a2260 in k2254 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_2275(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2275,2,av);}
if(C_truep(C_i_member(lf[70],((C_word*)t0)[2]))){
C_trace("setup-download.scm:199: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[71];
av2[3]=lf[72];
C_values(4,av2);}}
else{
C_trace("setup-download.scm:200: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[3];
av2[2]=lf[73];
av2[3]=lf[74];
C_values(4,av2);}}}

/* k1735 in for-each-loop346 in k1712 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_1737(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1737,2,av);}
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1727(t3,((C_word*)t0)[4],t2);}

/* k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2244(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,c,3))){C_save_and_reclaim((void *)f_2244,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2247,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2369,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:183: make-pathname");
t5=C_fast_retrieve(lf[20]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2241(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,4))){C_save_and_reclaim((void *)f_2241,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
C_trace("setup-download.scm:182: string-append");
t4=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[88];
av2[3]=((C_word*)t0)[7];
av2[4]=lf[89];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=lf[90];
f_2244(2,av2);}}}

/* k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_2247(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(13,c,3))){C_save_and_reclaim((void *)f_2247,2,av);}
a=C_alloc(13);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
C_trace("setup-download.scm:184: d");
f_1347(t3,lf[87],C_a_i_list(&a,1,t2));}

/* k2175 in k2099 in k2096 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_2177(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_2177,2,av);}
C_trace("setup-download.scm:172: make-svn-ls-cmd");
f_1938(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,C_SCHEME_END_OF_LIST);}

/* k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in ... */
static void C_ccall f_2253(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_2253,2,av);}
a=C_alloc(18);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2256,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2353,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2355,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:188: filter-map");
t6=C_fast_retrieve(lf[60]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t4;
av2[2]=t5;
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_2250(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_2250,2,av);}
a=C_alloc(9);
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:185: with-input-from-pipe");
t3=C_fast_retrieve(lf[85]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[9];
av2[3]=C_fast_retrieve(lf[86]);
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2254 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_2256(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,c,4))){C_save_and_reclaim((void *)f_2256,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2261,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li21),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2289,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word)li22),tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm:185: ##sys#call-with-values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[9];
av2[2]=t3;
av2[3]=t4;
C_call_with_values(4,av2);}}

/* k2367 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_2369(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,5))){C_save_and_reclaim((void *)f_2369,2,av);}
a=C_alloc(6);
C_trace("setup-download.scm:183: make-svn-ls-cmd");
f_1938(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,C_a_i_list(&a,2,lf[62],C_SCHEME_TRUE));}

/* k2179 in k2099 in k2096 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_2181(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2181,2,av);}
C_trace("setup-download.scm:172: make-pathname");
t2=C_fast_retrieve(lf[20]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k1352 in setup-download#d in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1354(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1354,2,av);}
C_trace("setup-download.scm:62: flush-output");
t2=*((C_word*)lf[9]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2344 in a2288 in k2254 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_2346(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2346,2,av);}
C_trace("setup-download.scm:201: make-pathname");
t2=C_fast_retrieve(lf[20]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2164 in map-loop479 in k2131 in k2105 in k2102 in k2099 in k2096 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_2166(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2166,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2141(t6,((C_word*)t0)[5],t5);}

/* k2351 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_2353(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_2353,2,av);}
C_trace("setup-download.scm:186: existing-version");
f_1378(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* a2354 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_2355(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,3))){C_save_and_reclaim((void *)f_2355,3,av);}
a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:190: irregex-search");
t4=C_fast_retrieve(lf[83]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[84];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2357 in a2354 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in ... */
static void C_ccall f_2359(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2359,2,av);}
if(C_truep(t1)){
C_trace("setup-download.scm:191: irregex-match-substring");
t2=C_fast_retrieve(lf[82]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=C_fix(1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}}

/* k2131 in k2105 in k2102 in k2099 in k2096 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_2133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_2133,2,av);}
a=C_alloc(11);
t2=C_i_check_list_2(t1,lf[219]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2141,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word)li73),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2141(t7,t3,t1);}

/* k2619 in k2615 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_2621(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,8))){C_save_and_reclaim((void *)f_2621,2,av);}
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-download.scm:238: string-append");
t2=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[135];
av2[4]=((C_word*)t0)[5];
av2[5]=((C_word*)t0)[6];
av2[6]=lf[136];
av2[7]=t1;
av2[8]=lf[137];
((C_proc)(void*)(*((C_word*)t2+1)))(9,av2);}}
else{
C_trace("setup-download.scm:238: string-append");
t2=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 9) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(9);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=lf[135];
av2[4]=((C_word*)t0)[5];
av2[5]=((C_word*)t0)[6];
av2[6]=lf[136];
av2[7]=t1;
av2[8]=lf[138];
((C_proc)(void*)(*((C_word*)t2+1)))(9,av2);}}}

/* k2137 in k2131 in k2105 in k2102 in k2099 in k2096 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_ccall f_2139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2139,2,av);}
C_trace("setup-download.scm:176: string-concatenate");
t2=C_fast_retrieve(lf[217]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2213(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word *a;
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-4)*C_SIZEOF_PAIR +8,c,4))){
C_save_and_reclaim((void*)f_2213,c,av);}
a=C_alloc((c-4)*C_SIZEOF_PAIR+8);
t4=C_build_rest(&a,c,4,av);
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=t6;
t8=C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t10=C_i_nullp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:C_i_car(t9));
t12=t11;
t13=C_i_nullp(t9);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:C_i_cdr(t9));
t15=C_i_nullp(t14);
t16=(C_truep(t15)?C_SCHEME_FALSE:C_i_car(t14));
t17=C_i_nullp(t14);
t18=(C_truep(t17)?C_SCHEME_END_OF_LIST:C_i_cdr(t14));
t19=C_i_nullp(t18);
t20=(C_truep(t19)?C_SCHEME_FALSE:C_i_car(t18));
t21=t20;
t22=C_i_nullp(t18);
t23=(C_truep(t22)?C_SCHEME_END_OF_LIST:C_i_cdr(t18));
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2241,a[2]=t2,a[3]=t7,a[4]=t3,a[5]=t12,a[6]=t1,a[7]=t21,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
C_trace("setup-download.scm:181: string-append");
t25=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t25;
av2[1]=t24;
av2[2]=lf[91];
av2[3]=t16;
av2[4]=lf[92];
((C_proc)(void*)(*((C_word*)t25+1)))(5,av2);}}
else{
t25=t24;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t25;
av2[1]=lf[93];
f_2241(2,av2);}}}

/* k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1331(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1331,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1334,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:50: tcp-read-timeout");
t3=C_fast_retrieve(lf[255]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fix(30000);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1337(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_1337,2,av);}
a=C_alloc(6);
t2=lf[0] /* setup-download#*quiet* */ =C_SCHEME_FALSE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1342,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3584,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:54: chicken-version");
t5=C_fast_retrieve(lf[253]);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(2,av2);}}

/* k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1334(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1334,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:51: tcp-write-timeout");
t3=C_fast_retrieve(lf[254]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fix(30000);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k2321 in k2317 in k2291 in a2288 in k2254 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_2323(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,14))){C_save_and_reclaim((void *)f_2323,2,av);}
t2=(C_truep(C_retrieve2(lf[0],"setup-download#\052quiet\052"))?lf[77]:lf[78]);
C_trace("setup-download.scm:157: conc");
t3=C_fast_retrieve(lf[65]);{
C_word *av2;
if(c >= 15) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(15);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[79];
av2[3]=((C_word*)t0)[3];
av2[4]=C_make_character(32);
av2[5]=((C_word*)t0)[4];
av2[6]=C_make_character(32);
av2[7]=C_make_character(34);
av2[8]=((C_word*)t0)[5];
av2[9]=C_make_character(34);
av2[10]=C_make_character(32);
av2[11]=C_make_character(34);
av2[12]=t1;
av2[13]=C_make_character(34);
av2[14]=t2;
((C_proc)(void*)(*((C_word*)t3+1)))(15,av2);}}

/* k2327 in k2317 in k2291 in a2288 in k2254 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_2329(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,5))){C_save_and_reclaim((void *)f_2329,2,av);}
t2=((C_word*)t0)[2];
C_trace("setup-download.scm:220: conc");
t3=C_fast_retrieve(lf[65]);{
C_word *av2;
if(c >= 6) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(6);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=((C_word*)t0)[4];
av2[3]=C_make_character(47);
av2[4]=t2;
av2[5]=lf[81];
((C_proc)(void*)(*((C_word*)t3+1)))(6,av2);}}

/* a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_3191(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_3191,4,av);}
a=C_alloc(6);
t4=t1;
t5=t2;
t6=t3;
t7=((C_word*)t0)[2];
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2974,a[2]=t5,a[3]=t6,a[4]=t7,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:341: d");
f_1347(t8,lf[134],C_SCHEME_END_OF_LIST);}

/* k2954 in k2951 in k2945 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_2956(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_2956,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:301: ##sys#write-char-0");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[35]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[35]+1);
av2[1]=t2;
av2[2]=C_make_character(58);
av2[3]=((C_word*)t0)[4];
tp(4,av2);}}

/* map-loop479 in k2131 in k2105 in k2102 in k2099 in k2096 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_fcall f_2141(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_2141,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2166,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2129,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:177: string-chomp");
t7=C_fast_retrieve(lf[222]);{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
av2[3]=lf[241];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k2957 in k2954 in k2951 in k2945 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_2959(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_2959,2,av);}
a=C_alloc(5);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:301: ##sys#print");
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k2096 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_2098(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2098,2,av);}
a=C_alloc(6);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2101,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
C_trace("setup-download.scm:171: string-append");
t4=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[243];
av2[3]=((C_word*)t0)[5];
av2[4]=lf[244];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=lf[245];
f_2101(2,av2);}}}

/* k2951 in k2945 in setup-download#http-connect in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_2953,2,av);}
a=C_alloc(6);
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:301: ##sys#print");
t3=*((C_word*)lf[34]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[6];
av2[3]=C_SCHEME_FALSE;
av2[4]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* k1779 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_1781(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_1781,2,av);}
a=C_alloc(6);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:98: directory?");
t3=C_fast_retrieve(lf[23]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_1563(2,av2);}}}

/* a1846 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_1847(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1847,2,av);}
C_trace("setup-download.scm:137: locate-egg/local");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[19]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[19]+1);
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=((C_word*)t0)[3];
tp(4,av2);}}

/* k1785 in k1779 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_1787(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_1787,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:99: directory");
t3=C_fast_retrieve(lf[48]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[5];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=C_SCHEME_FALSE;
f_1563(2,av2);}}}

/* k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1342(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,4))){C_save_and_reclaim((void *)f_1342,2,av);}
a=C_alloc(6);
t2=C_mutate2(&lf[1] /* (set! setup-download#*chicken-install-user-agent* ...) */,t1);
t3=lf[2] /* setup-download#*trunk* */ =C_SCHEME_FALSE;;
t4=C_mutate2(&lf[3] /* (set! setup-download#*mode* ...) */,lf[4]);
t5=C_mutate2(&lf[5] /* (set! setup-download#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t6=C_mutate2(&lf[6] /* (set! setup-download#d ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1347,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1361,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:64: make-parameter");
t8=C_fast_retrieve(lf[251]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t8;
av2[1]=t7;
av2[2]=C_SCHEME_FALSE;
((C_proc)(void*)(*((C_word*)t8+1)))(3,av2);}}

/* a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1841(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,4))){C_save_and_reclaim((void *)f_1841,3,av);}
a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1847,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1853,a[2]=t2,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:136: ##sys#call-with-values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
C_call_with_values(4,av2);}}

/* setup-download#d in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_fcall f_1347(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,0,5))){
C_save_and_reclaim_args((void *)trf_1347,3,t1,t2,t3);}
a=C_alloc(4);
t4=(C_truep(C_retrieve2(lf[0],"setup-download#\052quiet\052"))?*((C_word*)lf[7]+1):*((C_word*)lf[8]+1));
t5=t4;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1354,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);{
C_word av2[6];
av2[0]=0;
av2[1]=t6;
av2[2]=*((C_word*)lf[10]+1);
av2[3]=t5;
av2[4]=t2;
av2[5]=t3;
C_apply(6,av2);}}

/* k2334 in k2291 in a2288 in k2254 in k2251 in k2248 in k2245 in k2242 in k2239 in setup-download#locate-egg/svn in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_ccall f_2336(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,6))){C_save_and_reclaim((void *)f_2336,2,av);}
C_trace("setup-download.scm:204: conc");
t2=C_fast_retrieve(lf[65]);{
C_word *av2;
if(c >= 7) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(7);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=C_make_character(47);
av2[4]=((C_word*)t0)[4];
av2[5]=C_make_character(47);
av2[6]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(7,av2);}}

/* k1392 in setup-download#existing-version in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1394(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1394,2,av);}
t2=C_i_pairp(t1);
t3=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=(C_truep(t2)?C_u_i_car(t1):C_SCHEME_FALSE);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* k2127 in map-loop479 in k2131 in k2105 in k2102 in k2099 in k2096 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_2129(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2129,2,av);}
C_trace("##sys#string-append");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[220]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[220]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[240];
tp(4,av2);}}

/* a3184 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_3185(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,7))){C_save_and_reclaim((void *)f_3185,2,av);}
C_trace("setup-download.scm:389: http-connect");
f_2808(t1,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}

/* k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1321(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1321,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_files_toplevel(2,av2);}}

/* k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1327(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1327,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1331,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:49: tcp-connect-timeout");
t3=C_fast_retrieve(lf[256]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=C_fix(30000);
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1324(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1324,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:27: ##sys#require");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[257]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[257]+1);
av2[1]=t2;
av2[2]=lf[258];
tp(3,av2);}}

/* k1792 in k1785 in k1779 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in ... */
static void C_ccall f_1794(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,4))){C_save_and_reclaim((void *)f_1794,2,av);}
C_trace("setup-download.scm:99: existing-version");
f_1378(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k1951 in setup-download#make-svn-ls-cmd in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1953(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,7))){C_save_and_reclaim((void *)f_1953,2,av);}
C_trace("setup-download.scm:154: conc");
t2=C_fast_retrieve(lf[65]);{
C_word *av2;
if(c >= 8) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(8);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=lf[66];
av2[3]=((C_word*)t0)[3];
av2[4]=C_make_character(32);
av2[5]=((C_word*)t0)[4];
av2[6]=((C_word*)t0)[5];
av2[7]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(8,av2);}}

/* k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2531(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_2531,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[10])){
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=((C_word*)t0)[10];
f_2534(2,av2);}}
else{
C_trace("setup-download.scm:244: get-temporary-directory");
f_1363(t3);}}

/* k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_2537(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,2))){C_save_and_reclaim((void *)f_2537,2,av);}
a=C_alloc(11);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download.scm:246: file-exists?");
t4=C_fast_retrieve(lf[24]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_2534(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_2534,2,av);}
a=C_alloc(10);
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("setup-download.scm:245: make-pathname");
t3=C_fast_retrieve(lf[20]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
av2[3]=((C_word*)t0)[10];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k2105 in k2102 in k2099 in k2096 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in ... */
static void C_ccall f_2107(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_2107,2,av);}
a=C_alloc(10);
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=lf[239];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}
else{
t2=C_a_i_cons(&a,2,C_SCHEME_UNDEFINED,C_SCHEME_END_OF_LIST);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t4)[1];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2133,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:178: with-input-from-pipe");
t7=C_fast_retrieve(lf[85]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=((C_word*)t0)[3];
av2[3]=C_fast_retrieve(lf[86]);
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}}

/* k2099 in k2096 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in ... */
static void C_ccall f_2101(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_2101,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2104,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2177,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2181,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:172: string-append");
t6=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=((C_word*)t0)[5];
av2[3]=lf[242];
((C_proc)(void*)(*((C_word*)t6+1)))(4,av2);}}

/* k2102 in k2099 in k2096 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_2104(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_2104,2,av);}
a=C_alloc(4);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2107,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:173: with-input-from-pipe");
t4=C_fast_retrieve(lf[85]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_fast_retrieve(lf[86]);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k1907 in a1904 in a1898 in a1892 in k1874 in a1867 in k1861 in k1855 in a1852 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in ... */
static void C_ccall f_1909(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1909,2,av);}
C_trace("setup-download.scm:149: return");
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[3];
av2[2]=C_SCHEME_FALSE;
((C_proc)C_fast_retrieve_proc(t2))(3,av2);}}

/* a1904 in a1898 in a1892 in k1874 in a1867 in k1861 in k1855 in a1852 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_1905(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,3))){C_save_and_reclaim((void *)f_1905,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:146: warning");
t3=C_fast_retrieve(lf[25]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[52];
av2[3]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* a1919 in a1913 in a1892 in k1874 in a1867 in k1861 in k1855 in a1852 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_1920(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1920,2,av);}
C_trace("setup-download.scm:150: with-input-from-file");
t2=C_fast_retrieve(lf[53]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
av2[3]=*((C_word*)lf[54]+1);
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* k2583 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_2585(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2585,2,av);}
if(C_truep(t1)){
t2=t1;
C_trace("setup-download.scm:254: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t2;
C_values(4,av2);}}
else{
if(C_truep(((C_word*)t0)[4])){
C_trace("setup-download.scm:254: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[4];
C_values(4,av2);}}
else{
C_trace("setup-download.scm:254: values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=lf[102];
C_values(4,av2);}}}}

/* a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_ccall f_2581(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(18,c,4))){C_save_and_reclaim((void *)f_2581,2,av);}
a=C_alloc(18);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2585,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[2];
t7=((C_word*)t0)[7];
t8=((C_word*)t0)[8];
t9=((C_word*)t0)[9];
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3185,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t7,a[6]=t8,a[7]=t9,a[8]=((C_word)li29),tmp=(C_word)a,a+=9,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3191,a[2]=t6,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:387: ##sys#call-with-values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t2;
av2[2]=t10;
av2[3]=t11;
C_call_with_values(4,av2);}}

/* k3140 in k3137 in k3134 in k3118 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in ... */
static void C_ccall f_3142(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,3))){C_save_and_reclaim((void *)f_3142,2,av);}
a=C_alloc(10);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3145,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3156,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:384: make-pathname");
t5=C_fast_retrieve(lf[20]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[6];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k3154 in k3140 in k3137 in k3134 in k3118 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in ... */
static void C_ccall f_3156(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,4))){C_save_and_reclaim((void *)f_3156,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3158,a[2]=((C_word*)t0)[2],a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:384: with-output-to-file");
t3=C_fast_retrieve(lf[128]);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t3;
av2[1]=((C_word*)t0)[3];
av2[2]=t1;
av2[3]=t2;
av2[4]=lf[129];
((C_proc)(void*)(*((C_word*)t3+1)))(5,av2);}}

/* a3157 in k3154 in k3140 in k3137 in k3134 in k3118 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in ... */
static void C_ccall f_3158(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3158,2,av);}
C_trace("setup-download.scm:384: g770");
t2=*((C_word*)lf[127]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a2596 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_ccall f_2597(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_2597,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2603,a[2]=t2,a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:248: k603");
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k1295 in k1292 in k1289 */
static void C_ccall f_1297(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1297,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_extras_toplevel(2,av2);}}

/* k1289 */
static void C_ccall f_1291(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1291,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_eval_toplevel(2,av2);}}

/* k1292 in k1289 */
static void C_ccall f_1294(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1294,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1297,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_chicken_2dsyntax_toplevel(2,av2);}}

/* a1925 in a1913 in a1892 in k1874 in a1867 in k1861 in k1855 in a1852 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_1926(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand((c-2)*C_SIZEOF_PAIR +4,c,2))){
C_save_and_reclaim((void*)f_1926,c,av);}
a=C_alloc((c-2)*C_SIZEOF_PAIR+4);
t2=C_build_rest(&a,c,2,av);
C_word t3;
C_word t4;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1932,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:144: k379");
t4=((C_word*)t0)[2];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* k3143 in k3140 in k3137 in k3134 in k3118 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in ... */
static void C_ccall f_3145(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_3145,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
C_trace("setup-download.scm:385: get-files");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3067(t3,((C_word*)t0)[5],t2);}

/* a2562 in a2556 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_ccall f_2563(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_2563,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2567,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("setup-download.scm:250: signal");
t3=C_fast_retrieve(lf[100]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}
else{
C_trace("setup-download.scm:249: setup-api#remove-directory");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[101]);
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=*((C_word*)lf[101]+1);
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
tp(3,av2);}}}

/* k3118 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in ... */
static void C_ccall f_3120(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,3))){C_save_and_reclaim((void *)f_3120,2,av);}
a=C_alloc(12);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:377: d");
f_1347(t2,lf[126],C_a_i_list(&a,1,((C_word*)t0)[6]));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3136,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:381: d");
f_1347(t2,lf[131],C_a_i_list(&a,1,((C_word*)t0)[6]));}}

/* k2565 in a2562 in a2556 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_2567(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2567,2,av);}
C_trace("setup-download.scm:250: signal");
t2=C_fast_retrieve(lf[100]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3137 in k3134 in k3118 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in ... */
static void C_ccall f_3139(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_3139,2,av);}
a=C_alloc(7);
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("read-string/port");
t3=C_fast_retrieve(lf[130]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=t1;
av2[3]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}

/* k3131 in k3121 in k3118 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in ... */
static void C_ccall f_3133(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3133,2,av);}
C_trace("setup-download.scm:378: create-directory");
t2=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* a1913 in a1892 in k1874 in a1867 in k1861 in k1855 in a1852 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_ccall f_1914(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_1914,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1920,a[2]=((C_word*)t0)[2],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[3],a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:144: ##sys#call-with-values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=t1;
av2[2]=t2;
av2[3]=t3;
C_call_with_values(4,av2);}}

/* k3134 in k3118 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in ... */
static void C_ccall f_3136(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,2))){C_save_and_reclaim((void *)f_3136,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm:382: read");
t3=*((C_word*)lf[54]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[8];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* k1490 in k1475 in k1469 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_1492(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_1492,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1495,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1497,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word)li72),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_1497(t6,t2,t1);}

/* map-loop223 in k1490 in k1475 in k1469 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in ... */
static void C_fcall f_1497(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_1497,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1522,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-download.scm:91: g246");
t5=*((C_word*)lf[68]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[235];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1493 in k1490 in k1475 in k1469 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in ... */
static void C_ccall f_1495(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1495,2,av);}
C_trace("setup-download.scm:90: string-concatenate");
t2=C_fast_retrieve(lf[217]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k3124 in k3121 in k3118 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in ... */
static void C_ccall f_3126(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_3126,2,av);}
C_trace("setup-download.scm:379: get-files");
t2=((C_word*)((C_word*)t0)[2])[1];
f_3067(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k3121 in k3118 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in ... */
static void C_ccall f_3123(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_3123,2,av);}
a=C_alloc(8);
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3133,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:378: make-pathname");
t4=C_fast_retrieve(lf[20]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[5];
av2[3]=((C_word*)t0)[6];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in ... */
static void C_ccall f_2540(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(12,c,2))){C_save_and_reclaim((void *)f_2540,2,av);}
a=C_alloc(12);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2543,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_UNDEFINED;
f_2543(2,av2);}}
else{
C_trace("setup-download.scm:247: create-directory");
t4=C_fast_retrieve(lf[42]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[3];
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}}

/* k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_2543(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,c,3))){C_save_and_reclaim((void *)f_2543,2,av);}
a=C_alloc(15);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2551,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word)li39),tmp=(C_word)a,a+=12,tmp);
C_trace("setup-download.scm:248: call-with-current-continuation");
t4=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t2;
av2[2]=t3;
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k2544 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in ... */
static void C_ccall f_2546(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_2546,2,av);}
C_trace("setup-download.scm:248: g607");
t2=t1;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
((C_proc)C_fast_retrieve_proc(t2))(2,av2);}}

/* k1426 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_1428(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_1428,2,av);}
a=C_alloc(11);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1431,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1433,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_1433(t6,t2,t1);}

/* a2602 in a2596 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in ... */
static void C_ccall f_2603(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2603,2,av);}{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=0;
av2[1]=t1;
av2[2]=((C_word*)t0)[2];
C_apply_values(3,av2);}}

/* a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in ... */
static void C_ccall f_2551(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(18,c,3))){C_save_and_reclaim((void *)f_2551,3,av);}
a=C_alloc(18);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word)li28),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word)li38),tmp=(C_word)a,a+=12,tmp);
C_trace("setup-download.scm:248: with-exception-handler");
t5=C_fast_retrieve(lf[55]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* a2556 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_2557(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,2))){C_save_and_reclaim((void *)f_2557,3,av);}
a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2563,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li27),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:248: k603");
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* map-loop181 in k1426 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_fcall f_1433(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,0,3))){
C_save_and_reclaim_args((void *)trf_1433,3,t0,t1,t2);}
a=C_alloc(6);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1458,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-download.scm:85: g204");
t5=*((C_word*)lf[68]+1);{
C_word av2[4];
av2[0]=t5;
av2[1]=t3;
av2[2]=t4;
av2[3]=lf[218];
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1429 in k1426 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_1431(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_1431,2,av);}
C_trace("setup-download.scm:85: string-concatenate");
t2=C_fast_retrieve(lf[217]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k2615 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2617(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,2))){C_save_and_reclaim((void *)f_2617,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:242: ->string");
t4=C_fast_retrieve(lf[139]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=C_retrieve2(lf[3],"setup-download#\052mode\052");
((C_proc)(void*)(*((C_word*)t4+1)))(3,av2);}}

/* k3100 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in ... */
static void C_ccall f_3102(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(4,c,2))){C_save_and_reclaim((void *)f_3102,2,av);}
a=C_alloc(4);
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:372: close-output-port");
t3=*((C_word*)lf[124]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t3+1)))(3,av2);}}

/* a1892 in k1874 in a1867 in k1861 in k1855 in a1852 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_1893(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_1893,3,av);}
a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word)li10),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:144: with-exception-handler");
t5=C_fast_retrieve(lf[55]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t5;
av2[1]=t1;
av2[2]=t3;
av2[3]=t4;
((C_proc)(void*)(*((C_word*)t5+1)))(4,av2);}}

/* k3103 in k3100 in k3078 in k3072 in k3069 in get-files in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in ... */
static void C_ccall f_3105(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_3105,2,av);}
t2=((C_word*)t0)[2];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t2;
av2[1]=((C_word*)((C_word*)t0)[3])[1];
((C_proc)(void*)(*((C_word*)t2+1)))(2,av2);}}

/* k1889 in k1886 in k1874 in a1867 in k1861 in k1855 in a1852 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_ccall f_1891(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,1))){C_save_and_reclaim((void *)f_1891,2,av);}
a=C_alloc(6);
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t3;
av2[1]=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}

/* a2520 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2521(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2521,2,av);}
C_trace("setup-download.scm:237: deconstruct-url");
f_2431(t1,((C_word*)t0)[2]);}

/* a1898 in a1892 in k1874 in a1867 in k1861 in k1855 in a1852 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_ccall f_1899(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,2))){C_save_and_reclaim((void *)f_1899,3,av);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li9),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:144: k379");
t4=((C_word*)t0)[4];{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=t3;
((C_proc)C_fast_retrieve_proc(t4))(3,av2);}}

/* a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_2527(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3=av[3];
C_word t4=av[4];
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_2527,5,av);}
a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2531,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2617,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-download.scm:241: string-append");
t7=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t7;
av2[1]=t6;
av2[2]=lf[140];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t7=t6;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t7;
av2[1]=lf[141];
f_2617(2,av2);}}}

/* k2041 in map-loop428 in k2008 in k1988 in k1985 in k1982 in k1979 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_ccall f_2043(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_2043,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2018(t6,((C_word*)t0)[5],t5);}

/* k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1560(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(15,c,2))){C_save_and_reclaim((void *)f_1560,2,av);}
a=C_alloc(15);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1563,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=C_retrieve2(lf[2],"setup-download#\052trunk\052");
if(C_truep(C_retrieve2(lf[2],"setup-download#\052trunk\052"))){
t5=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t5;
av2[1]=C_SCHEME_FALSE;
f_1563(2,av2);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1781,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:98: file-exists?");
t6=C_fast_retrieve(lf[24]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t6;
av2[1]=t5;
av2[2]=t2;
((C_proc)(void*)(*((C_word*)t6+1)))(3,av2);}}}

/* k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_1563(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,c,3))){C_save_and_reclaim((void *)f_1563,2,av);}
a=C_alloc(9);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1566,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[8])){
C_trace("setup-download.scm:100: make-pathname");
t4=C_fast_retrieve(lf[20]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=((C_word*)t0)[8];
av2[3]=((C_word*)t0)[4];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=C_SCHEME_FALSE;
f_1566(2,av2);}}}

/* k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_1566(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(14,c,4))){C_save_and_reclaim((void *)f_1566,2,av);}
a=C_alloc(14);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li3),tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1608,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word)li6),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:94: ##sys#call-with-values");{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=0;
av2[1]=((C_word*)t0)[8];
av2[2]=t3;
av2[3]=t4;
C_call_with_values(4,av2);}}

/* k1456 in map-loop181 in k1426 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in ... */
static void C_ccall f_1458(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1458,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1433(t6,((C_word*)t0)[5],t5);}

/* k2014 in k2008 in k1988 in k1985 in k1982 in k1979 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_2016(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,2))){C_save_and_reclaim((void *)f_2016,2,av);}
C_trace("setup-download.scm:165: string-concatenate");
t2=C_fast_retrieve(lf[217]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(3,av2);}}

/* k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1309(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1309,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_srfi_2d1_toplevel(2,av2);}}

/* k2008 in k1988 in k1985 in k1982 in k1979 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in ... */
static void C_ccall f_2010(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(11,c,3))){C_save_and_reclaim((void *)f_2010,2,av);}
a=C_alloc(11);
t2=C_i_check_list_2(t1,lf[219]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2016,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word)li63),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2018(t7,t3,t1);}

/* k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1306(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1306,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_utils_toplevel(2,av2);}}

/* map-loop428 in k2008 in k1988 in k1985 in k1982 in k1979 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_fcall f_2018(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(9,0,3))){
C_save_and_reclaim_args((void *)trf_2018,3,t0,t1,t2);}
a=C_alloc(9);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2043,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
t5=t3;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2006,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:166: string-chomp");
t7=C_fast_retrieve(lf[222]);{
C_word av2[4];
av2[0]=t7;
av2[1]=t6;
av2[2]=t4;
av2[3]=lf[223];
((C_proc)(void*)(*((C_word*)t7+1)))(4,av2);}}
else{
t3=t1;{
C_word av2[2];
av2[0]=t3;
av2[1]=C_slot(((C_word*)t0)[4],C_fix(1));
((C_proc)(void*)(*((C_word*)t3+1)))(2,av2);}}}

/* k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1303(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1303,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_posix_toplevel(2,av2);}}

/* k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1300(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1300,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1303,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=C_SCHEME_UNDEFINED;
av2[1]=t2;
C_irregex_toplevel(2,av2);}}

/* k1874 in a1867 in k1861 in k1855 in a1852 in a1840 in k1834 in setup-download#gather-egg-information in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in ... */
static void C_ccall f_1876(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(17,c,3))){C_save_and_reclaim((void *)f_1876,2,av);}
a=C_alloc(17);
t2=t1;
t3=C_a_i_list2(&a,2,lf[51],((C_word*)t0)[2]);
t4=t3;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1888,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word)li15),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:144: call-with-current-continuation");
t7=*((C_word*)lf[56]+1);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t7;
av2[1]=t5;
av2[2]=t6;
((C_proc)(void*)(*((C_word*)t7+1)))(3,av2);}}

/* a1570 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in ... */
static void C_ccall f_1571(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(6,c,3))){C_save_and_reclaim((void *)f_1571,2,av);}
a=C_alloc(6);
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1582,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:103: make-pathname");
t3=C_fast_retrieve(lf[20]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[3];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1585,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:104: make-pathname");
t3=C_fast_retrieve(lf[20]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=((C_word*)t0)[4];
av2[3]=lf[27];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k1763 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in ... */
static void C_ccall f_1765(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,1))){C_save_and_reclaim((void *)f_1765,2,av);}
t2=((C_word*)t0)[2];
f_1618(t2,C_i_not(t1));}

/* k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in ... */
static void C_ccall f_1769(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(10,c,2))){C_save_and_reclaim((void *)f_1769,2,av);}
a=C_alloc(10);
t2=C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_1618(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1765,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:109: directory?");
t5=C_fast_retrieve(lf[23]);{
C_word *av2;
if(c >= 3) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(3);
}
av2[0]=t5;
av2[1]=t4;
av2[2]=((C_word*)t0)[7];
((C_proc)(void*)(*((C_word*)t5+1)))(3,av2);}}}

/* k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 */
static void C_ccall f_1557(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(8,c,3))){C_save_and_reclaim((void *)f_1557,2,av);}
a=C_alloc(8);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1560,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm:96: make-pathname");
t4=C_fast_retrieve(lf[20]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=lf[49];
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* g732 in k2993 in k2987 in k2978 in skip in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in ... */
static void C_fcall f_2999(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,0,3))){
C_save_and_reclaim_args((void *)trf_2999,3,t0,t1,t2);}
a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3003,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:350: irregex-match-substring");
t4=C_fast_retrieve(lf[82]);{
C_word av2[4];
av2[0]=t4;
av2[1]=t3;
av2[2]=t2;
av2[3]=C_fix(1);
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k2993 in k2987 in k2978 in skip in k2972 in a3190 in a2580 in a2574 in a2550 in k2541 in k2538 in k2535 in k2532 in k2529 in a2526 in setup-download#locate-egg/http in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in ... */
static void C_ccall f_2995(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,3))){C_save_and_reclaim((void *)f_2995,2,av);}
a=C_alloc(5);
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li30),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:342: g732");
t3=t2;
f_2999(t3,((C_word*)t0)[4],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3044,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:358: irregex-match");
t3=C_fast_retrieve(lf[97]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t3;
av2[1]=t2;
av2[2]=lf[112];
av2[3]=((C_word*)t0)[2];
((C_proc)(void*)(*((C_word*)t3+1)))(4,av2);}}}

/* k1982 in k1979 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in ... */
static void C_ccall f_1984(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,5))){C_save_and_reclaim((void *)f_1984,2,av);}
a=C_alloc(3);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:163: make-svn-ls-cmd");
f_1938(t2,((C_word*)t0)[3],t1,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* k1979 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in ... */
static void C_ccall f_1981(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(5,c,4))){C_save_and_reclaim((void *)f_1981,2,av);}
a=C_alloc(5);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1984,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
C_trace("setup-download.scm:162: string-append");
t4=*((C_word*)lf[68]+1);{
C_word *av2;
if(c >= 5) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(5);
}
av2[0]=t4;
av2[1]=t3;
av2[2]=lf[225];
av2[3]=((C_word*)t0)[4];
av2[4]=lf[226];
((C_proc)(void*)(*((C_word*)t4+1)))(5,av2);}}
else{
t4=t3;{
C_word *av2;
if(c >= 2) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(2);
}
av2[0]=t4;
av2[1]=lf[227];
f_1984(2,av2);}}}

/* k1985 in k1982 in k1979 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in ... */
static void C_ccall f_1987(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(7,c,3))){C_save_and_reclaim((void *)f_1987,2,av);}
a=C_alloc(7);
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1990,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:164: d");
f_1347(t3,lf[224],C_a_i_list(&a,1,t2));}

/* k2004 in map-loop428 in k2008 in k1988 in k1985 in k1982 in k1979 in a3481 in setup-download#list-extensions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in ... */
static void C_ccall f_2006(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_2006,2,av);}
C_trace("##sys#string-append");
{C_proc tp=(C_proc)C_fast_retrieve_symbol_proc(lf[220]);
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=*((C_word*)lf[220]+1);
av2[1]=((C_word*)t0)[2];
av2[2]=t1;
av2[3]=lf[221];
tp(4,av2);}}

/* k1756 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_1758(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1758,2,av);}
C_trace("setup-download.scm:125: filter");
t2=C_fast_retrieve(lf[47]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t2;
av2[1]=((C_word*)t0)[2];
av2[2]=((C_word*)t0)[3];
av2[3]=t1;
((C_proc)(void*)(*((C_word*)t2+1)))(4,av2);}}

/* a1749 in k1616 in k1767 in a1607 in k1564 in k1561 in k1558 in k1555 in setup-download#locate-egg/local in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_1750(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2=av[2];
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(0,c,3))){C_save_and_reclaim((void *)f_1750,3,av);}
t3=C_fast_retrieve(lf[45]);
C_trace("setup-download.scm:125: g342");
t4=C_fast_retrieve(lf[45]);{
C_word *av2;
if(c >= 4) {
  av2=av; /* Re-use our own argvector */
} else {
  av2=C_alloc(4);
}
av2[0]=t4;
av2[1]=t1;
av2[2]=lf[46];
av2[3]=t2;
((C_proc)(void*)(*((C_word*)t4+1)))(4,av2);}}

/* k1520 in map-loop223 in k1490 in k1475 in k1469 in a3548 in k3537 in setup-download#list-extension-versions in k3312 in k1359 in k1340 in k1335 in k1332 in k1329 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in ... */
static void C_ccall f_1522(C_word c,C_word *av){
C_word tmp;
C_word t0=av[0];
C_word t1=av[1];
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_demand(C_calculate_demand(3,c,2))){C_save_and_reclaim((void *)f_1522,2,av);}
a=C_alloc(3);
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate2(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1497(t6,((C_word*)t0)[5],t5);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[295] = {
{"f_2575:setup_2ddownload_2escm",(void*)f_2575},
{"f_1888:setup_2ddownload_2escm",(void*)f_1888},
{"f_1533:setup_2ddownload_2escm",(void*)f_1533},
{"f_1535:setup_2ddownload_2escm",(void*)f_1535},
{"f_2976:setup_2ddownload_2escm",(void*)f_2976},
{"f_2974:setup_2ddownload_2escm",(void*)f_2974},
{"f_2880:setup_2ddownload_2escm",(void*)f_2880},
{"f3797:setup_2ddownload_2escm",(void*)f3797},
{"f_2884:setup_2ddownload_2escm",(void*)f_2884},
{"f3793:setup_2ddownload_2escm",(void*)f3793},
{"f_1990:setup_2ddownload_2escm",(void*)f_1990},
{"f_2319:setup_2ddownload_2escm",(void*)f_2319},
{"f_2315:setup_2ddownload_2escm",(void*)f_2315},
{"toplevel:setup_2ddownload_2escm",(void*)C_toplevel},
{"f_1378:setup_2ddownload_2escm",(void*)f_1378},
{"f_1376:setup_2ddownload_2escm",(void*)f_1376},
{"f_1373:setup_2ddownload_2escm",(void*)f_1373},
{"f_2980:setup_2ddownload_2escm",(void*)f_2980},
{"f_2989:setup_2ddownload_2escm",(void*)f_2989},
{"f_2890:setup_2ddownload_2escm",(void*)f_2890},
{"f_2933:setup_2ddownload_2escm",(void*)f_2933},
{"f_2770:setup_2ddownload_2escm",(void*)f_2770},
{"f_2962:setup_2ddownload_2escm",(void*)f_2962},
{"f_2965:setup_2ddownload_2escm",(void*)f_2965},
{"f_1471:setup_2ddownload_2escm",(void*)f_1471},
{"f_1477:setup_2ddownload_2escm",(void*)f_1477},
{"f_2871:setup_2ddownload_2escm",(void*)f_2871},
{"f_1361:setup_2ddownload_2escm",(void*)f_1361},
{"f_2878:setup_2ddownload_2escm",(void*)f_2878},
{"f_2874:setup_2ddownload_2escm",(void*)f_2874},
{"f_1367:setup_2ddownload_2escm",(void*)f_1367},
{"f_2917:setup_2ddownload_2escm",(void*)f_2917},
{"f_2911:setup_2ddownload_2escm",(void*)f_2911},
{"f_1363:setup_2ddownload_2escm",(void*)f_1363},
{"f_2462:setup_2ddownload_2escm",(void*)f_2462},
{"f_2947:setup_2ddownload_2escm",(void*)f_2947},
{"f_2940:setup_2ddownload_2escm",(void*)f_2940},
{"f_2944:setup_2ddownload_2escm",(void*)f_2944},
{"f_2479:setup_2ddownload_2escm",(void*)f_2479},
{"f_2859:setup_2ddownload_2escm",(void*)f_2859},
{"f_2856:setup_2ddownload_2escm",(void*)f_2856},
{"f_2442:setup_2ddownload_2escm",(void*)f_2442},
{"f_2446:setup_2ddownload_2escm",(void*)f_2446},
{"f_2850:setup_2ddownload_2escm",(void*)f_2850},
{"f_2853:setup_2ddownload_2escm",(void*)f_2853},
{"f_1315:setup_2ddownload_2escm",(void*)f_1315},
{"f_1318:setup_2ddownload_2escm",(void*)f_1318},
{"f_1312:setup_2ddownload_2escm",(void*)f_1312},
{"f_1582:setup_2ddownload_2escm",(void*)f_1582},
{"f_2927:setup_2ddownload_2escm",(void*)f_2927},
{"f_2450:setup_2ddownload_2escm",(void*)f_2450},
{"f_2808:setup_2ddownload_2escm",(void*)f_2808},
{"f_1588:setup_2ddownload_2escm",(void*)f_1588},
{"f_1585:setup_2ddownload_2escm",(void*)f_1585},
{"f_2459:setup_2ddownload_2escm",(void*)f_2459},
{"f_2800:setup_2ddownload_2escm",(void*)f_2800},
{"f_2838:setup_2ddownload_2escm",(void*)f_2838},
{"f_2831:setup_2ddownload_2escm",(void*)f_2831},
{"f_1594:setup_2ddownload_2escm",(void*)f_1594},
{"f_2835:setup_2ddownload_2escm",(void*)f_2835},
{"f_3348:setup_2ddownload_2escm",(void*)f_3348},
{"f_2796:setup_2ddownload_2escm",(void*)f_2796},
{"f_3343:setup_2ddownload_2escm",(void*)f_3343},
{"f_3477:setup_2ddownload_2escm",(void*)f_3477},
{"f_2868:setup_2ddownload_2escm",(void*)f_2868},
{"f_2906:setup_2ddownload_2escm",(void*)f_2906},
{"f_2431:setup_2ddownload_2escm",(void*)f_2431},
{"f_2902:setup_2ddownload_2escm",(void*)f_2902},
{"f_2435:setup_2ddownload_2escm",(void*)f_2435},
{"f_3336:setup_2ddownload_2escm",(void*)f_3336},
{"f_2785:setup_2ddownload_2escm",(void*)f_2785},
{"f_3330:setup_2ddownload_2escm",(void*)f_3330},
{"f_2817:setup_2ddownload_2escm",(void*)f_2817},
{"f_2812:setup_2ddownload_2escm",(void*)f_2812},
{"f_2767:setup_2ddownload_2escm",(void*)f_2767},
{"f_2761:setup_2ddownload_2escm",(void*)f_2761},
{"f_2764:setup_2ddownload_2escm",(void*)f_2764},
{"f_3453:setup_2ddownload_2escm",(void*)f_3453},
{"f_3450:setup_2ddownload_2escm",(void*)f_3450},
{"f_2753:setup_2ddownload_2escm",(void*)f_2753},
{"f_3441:setup_2ddownload_2escm",(void*)f_3441},
{"f_1853:setup_2ddownload_2escm",(void*)f_1853},
{"f_1857:setup_2ddownload_2escm",(void*)f_1857},
{"f_2749:setup_2ddownload_2escm",(void*)f_2749},
{"f_1832:setup_2ddownload_2escm",(void*)f_1832},
{"f_1836:setup_2ddownload_2escm",(void*)f_1836},
{"f_3293:setup_2ddownload_2escm",(void*)f_3293},
{"f_2727:setup_2ddownload_2escm",(void*)f_2727},
{"f_2847:setup_2ddownload_2escm",(void*)f_2847},
{"f_2724:setup_2ddownload_2escm",(void*)f_2724},
{"f_2720:setup_2ddownload_2escm",(void*)f_2720},
{"f_2841:setup_2ddownload_2escm",(void*)f_2841},
{"f_2844:setup_2ddownload_2escm",(void*)f_2844},
{"f_3299:setup_2ddownload_2escm",(void*)f_3299},
{"f_3296:setup_2ddownload_2escm",(void*)f_3296},
{"f_1863:setup_2ddownload_2escm",(void*)f_1863},
{"f_1868:setup_2ddownload_2escm",(void*)f_1868},
{"f_2718:setup_2ddownload_2escm",(void*)f_2718},
{"f_2714:setup_2ddownload_2escm",(void*)f_2714},
{"f_2710:setup_2ddownload_2escm",(void*)f_2710},
{"f_1655:setup_2ddownload_2escm",(void*)f_1655},
{"f_1658:setup_2ddownload_2escm",(void*)f_1658},
{"f_1667:setup_2ddownload_2escm",(void*)f_1667},
{"f_1664:setup_2ddownload_2escm",(void*)f_1664},
{"f_1670:setup_2ddownload_2escm",(void*)f_1670},
{"f_2730:setup_2ddownload_2escm",(void*)f_2730},
{"f_2733:setup_2ddownload_2escm",(void*)f_2733},
{"f_1679:setup_2ddownload_2escm",(void*)f_1679},
{"f_1673:setup_2ddownload_2escm",(void*)f_1673},
{"f_1932:setup_2ddownload_2escm",(void*)f_1932},
{"f_1938:setup_2ddownload_2escm",(void*)f_1938},
{"f_3257:setup_2ddownload_2escm",(void*)f_3257},
{"f_3393:setup_2ddownload_2escm",(void*)f_3393},
{"f_1688:setup_2ddownload_2escm",(void*)f_1688},
{"f_1685:setup_2ddownload_2escm",(void*)f_1685},
{"f_3253:setup_2ddownload_2escm",(void*)f_3253},
{"f_3287:setup_2ddownload_2escm",(void*)f_3287},
{"f_3388:setup_2ddownload_2escm",(void*)f_3388},
{"f_3382:setup_2ddownload_2escm",(void*)f_3382},
{"f_3235:setup_2ddownload_2escm",(void*)f_3235},
{"f_1627:setup_2ddownload_2escm",(void*)f_1627},
{"f_3232:setup_2ddownload_2escm",(void*)f_3232},
{"f_3265:setup_2ddownload_2escm",(void*)f_3265},
{"f_1630:setup_2ddownload_2escm",(void*)f_1630},
{"f_1633:setup_2ddownload_2escm",(void*)f_1633},
{"f_1636:setup_2ddownload_2escm",(void*)f_1636},
{"f_1639:setup_2ddownload_2escm",(void*)f_1639},
{"f_3215:setup_2ddownload_2escm",(void*)f_3215},
{"f_3249:setup_2ddownload_2escm",(void*)f_3249},
{"f_3245:setup_2ddownload_2escm",(void*)f_3245},
{"f_3074:setup_2ddownload_2escm",(void*)f_3074},
{"f_3482:setup_2ddownload_2escm",(void*)f_3482},
{"f_3071:setup_2ddownload_2escm",(void*)f_3071},
{"f_3067:setup_2ddownload_2escm",(void*)f_3067},
{"f_3229:setup_2ddownload_2escm",(void*)f_3229},
{"f_3225:setup_2ddownload_2escm",(void*)f_3225},
{"f_3223:setup_2ddownload_2escm",(void*)f_3223},
{"f_3053:setup_2ddownload_2escm",(void*)f_3053},
{"f_1608:setup_2ddownload_2escm",(void*)f_1608},
{"f_1603:setup_2ddownload_2escm",(void*)f_1603},
{"f_3314:setup_2ddownload_2escm",(void*)f_3314},
{"f_3310:setup_2ddownload_2escm",(void*)f_3310},
{"f_3203:setup_2ddownload_2escm",(void*)f_3203},
{"f_3521:setup_2ddownload_2escm",(void*)f_3521},
{"f_3209:setup_2ddownload_2escm",(void*)f_3209},
{"f_1691:setup_2ddownload_2escm",(void*)f_1691},
{"f_1694:setup_2ddownload_2escm",(void*)f_1694},
{"f_3539:setup_2ddownload_2escm",(void*)f_3539},
{"f_3024:setup_2ddownload_2escm",(void*)f_3024},
{"f_3021:setup_2ddownload_2escm",(void*)f_3021},
{"f_3526:setup_2ddownload_2escm",(void*)f_3526},
{"f_3080:setup_2ddownload_2escm",(void*)f_3080},
{"f_3584:setup_2ddownload_2escm",(void*)f_3584},
{"f_3402:setup_2ddownload_2escm",(void*)f_3402},
{"f_3044:setup_2ddownload_2escm",(void*)f_3044},
{"f_3544:setup_2ddownload_2escm",(void*)f_3544},
{"f_3549:setup_2ddownload_2escm",(void*)f_3549},
{"f_1618:setup_2ddownload_2escm",(void*)f_1618},
{"f_2299:setup_2ddownload_2escm",(void*)f_2299},
{"f_2296:setup_2ddownload_2escm",(void*)f_2296},
{"f_2293:setup_2ddownload_2escm",(void*)f_2293},
{"f_1708:setup_2ddownload_2escm",(void*)f_1708},
{"f_1705:setup_2ddownload_2escm",(void*)f_1705},
{"f_1701:setup_2ddownload_2escm",(void*)f_1701},
{"f_3003:setup_2ddownload_2escm",(void*)f_3003},
{"f_2289:setup_2ddownload_2escm",(void*)f_2289},
{"f_1727:setup_2ddownload_2escm",(void*)f_1727},
{"f_1719:setup_2ddownload_2escm",(void*)f_1719},
{"f_3577:setup_2ddownload_2escm",(void*)f_3577},
{"f_1714:setup_2ddownload_2escm",(void*)f_1714},
{"f_2261:setup_2ddownload_2escm",(void*)f_2261},
{"f_2272:setup_2ddownload_2escm",(void*)f_2272},
{"f_2275:setup_2ddownload_2escm",(void*)f_2275},
{"f_1737:setup_2ddownload_2escm",(void*)f_1737},
{"f_2244:setup_2ddownload_2escm",(void*)f_2244},
{"f_2241:setup_2ddownload_2escm",(void*)f_2241},
{"f_2247:setup_2ddownload_2escm",(void*)f_2247},
{"f_2177:setup_2ddownload_2escm",(void*)f_2177},
{"f_2253:setup_2ddownload_2escm",(void*)f_2253},
{"f_2250:setup_2ddownload_2escm",(void*)f_2250},
{"f_2256:setup_2ddownload_2escm",(void*)f_2256},
{"f_2369:setup_2ddownload_2escm",(void*)f_2369},
{"f_2181:setup_2ddownload_2escm",(void*)f_2181},
{"f_1354:setup_2ddownload_2escm",(void*)f_1354},
{"f_2346:setup_2ddownload_2escm",(void*)f_2346},
{"f_2166:setup_2ddownload_2escm",(void*)f_2166},
{"f_2353:setup_2ddownload_2escm",(void*)f_2353},
{"f_2355:setup_2ddownload_2escm",(void*)f_2355},
{"f_2359:setup_2ddownload_2escm",(void*)f_2359},
{"f_2133:setup_2ddownload_2escm",(void*)f_2133},
{"f_2621:setup_2ddownload_2escm",(void*)f_2621},
{"f_2139:setup_2ddownload_2escm",(void*)f_2139},
{"f_2213:setup_2ddownload_2escm",(void*)f_2213},
{"f_1331:setup_2ddownload_2escm",(void*)f_1331},
{"f_1337:setup_2ddownload_2escm",(void*)f_1337},
{"f_1334:setup_2ddownload_2escm",(void*)f_1334},
{"f_2323:setup_2ddownload_2escm",(void*)f_2323},
{"f_2329:setup_2ddownload_2escm",(void*)f_2329},
{"f_3191:setup_2ddownload_2escm",(void*)f_3191},
{"f_2956:setup_2ddownload_2escm",(void*)f_2956},
{"f_2141:setup_2ddownload_2escm",(void*)f_2141},
{"f_2959:setup_2ddownload_2escm",(void*)f_2959},
{"f_2098:setup_2ddownload_2escm",(void*)f_2098},
{"f_2953:setup_2ddownload_2escm",(void*)f_2953},
{"f_1781:setup_2ddownload_2escm",(void*)f_1781},
{"f_1847:setup_2ddownload_2escm",(void*)f_1847},
{"f_1787:setup_2ddownload_2escm",(void*)f_1787},
{"f_1342:setup_2ddownload_2escm",(void*)f_1342},
{"f_1841:setup_2ddownload_2escm",(void*)f_1841},
{"f_1347:setup_2ddownload_2escm",(void*)f_1347},
{"f_2336:setup_2ddownload_2escm",(void*)f_2336},
{"f_1394:setup_2ddownload_2escm",(void*)f_1394},
{"f_2129:setup_2ddownload_2escm",(void*)f_2129},
{"f_3185:setup_2ddownload_2escm",(void*)f_3185},
{"f_1321:setup_2ddownload_2escm",(void*)f_1321},
{"f_1327:setup_2ddownload_2escm",(void*)f_1327},
{"f_1324:setup_2ddownload_2escm",(void*)f_1324},
{"f_1794:setup_2ddownload_2escm",(void*)f_1794},
{"f_1953:setup_2ddownload_2escm",(void*)f_1953},
{"f_2531:setup_2ddownload_2escm",(void*)f_2531},
{"f_2537:setup_2ddownload_2escm",(void*)f_2537},
{"f_2534:setup_2ddownload_2escm",(void*)f_2534},
{"f_2107:setup_2ddownload_2escm",(void*)f_2107},
{"f_2101:setup_2ddownload_2escm",(void*)f_2101},
{"f_2104:setup_2ddownload_2escm",(void*)f_2104},
{"f_1909:setup_2ddownload_2escm",(void*)f_1909},
{"f_1905:setup_2ddownload_2escm",(void*)f_1905},
{"f_1920:setup_2ddownload_2escm",(void*)f_1920},
{"f_2585:setup_2ddownload_2escm",(void*)f_2585},
{"f_2581:setup_2ddownload_2escm",(void*)f_2581},
{"f_3142:setup_2ddownload_2escm",(void*)f_3142},
{"f_3156:setup_2ddownload_2escm",(void*)f_3156},
{"f_3158:setup_2ddownload_2escm",(void*)f_3158},
{"f_2597:setup_2ddownload_2escm",(void*)f_2597},
{"f_1297:setup_2ddownload_2escm",(void*)f_1297},
{"f_1291:setup_2ddownload_2escm",(void*)f_1291},
{"f_1294:setup_2ddownload_2escm",(void*)f_1294},
{"f_1926:setup_2ddownload_2escm",(void*)f_1926},
{"f_3145:setup_2ddownload_2escm",(void*)f_3145},
{"f_2563:setup_2ddownload_2escm",(void*)f_2563},
{"f_3120:setup_2ddownload_2escm",(void*)f_3120},
{"f_2567:setup_2ddownload_2escm",(void*)f_2567},
{"f_3139:setup_2ddownload_2escm",(void*)f_3139},
{"f_3133:setup_2ddownload_2escm",(void*)f_3133},
{"f_1914:setup_2ddownload_2escm",(void*)f_1914},
{"f_3136:setup_2ddownload_2escm",(void*)f_3136},
{"f_1492:setup_2ddownload_2escm",(void*)f_1492},
{"f_1497:setup_2ddownload_2escm",(void*)f_1497},
{"f_1495:setup_2ddownload_2escm",(void*)f_1495},
{"f_3126:setup_2ddownload_2escm",(void*)f_3126},
{"f_3123:setup_2ddownload_2escm",(void*)f_3123},
{"f_2540:setup_2ddownload_2escm",(void*)f_2540},
{"f_2543:setup_2ddownload_2escm",(void*)f_2543},
{"f_2546:setup_2ddownload_2escm",(void*)f_2546},
{"f_1428:setup_2ddownload_2escm",(void*)f_1428},
{"f_2603:setup_2ddownload_2escm",(void*)f_2603},
{"f_2551:setup_2ddownload_2escm",(void*)f_2551},
{"f_2557:setup_2ddownload_2escm",(void*)f_2557},
{"f_1433:setup_2ddownload_2escm",(void*)f_1433},
{"f_1431:setup_2ddownload_2escm",(void*)f_1431},
{"f_2617:setup_2ddownload_2escm",(void*)f_2617},
{"f_3102:setup_2ddownload_2escm",(void*)f_3102},
{"f_1893:setup_2ddownload_2escm",(void*)f_1893},
{"f_3105:setup_2ddownload_2escm",(void*)f_3105},
{"f_1891:setup_2ddownload_2escm",(void*)f_1891},
{"f_2521:setup_2ddownload_2escm",(void*)f_2521},
{"f_1899:setup_2ddownload_2escm",(void*)f_1899},
{"f_2527:setup_2ddownload_2escm",(void*)f_2527},
{"f_2043:setup_2ddownload_2escm",(void*)f_2043},
{"f_1560:setup_2ddownload_2escm",(void*)f_1560},
{"f_1563:setup_2ddownload_2escm",(void*)f_1563},
{"f_1566:setup_2ddownload_2escm",(void*)f_1566},
{"f_1458:setup_2ddownload_2escm",(void*)f_1458},
{"f_2016:setup_2ddownload_2escm",(void*)f_2016},
{"f_1309:setup_2ddownload_2escm",(void*)f_1309},
{"f_2010:setup_2ddownload_2escm",(void*)f_2010},
{"f_1306:setup_2ddownload_2escm",(void*)f_1306},
{"f_2018:setup_2ddownload_2escm",(void*)f_2018},
{"f_1303:setup_2ddownload_2escm",(void*)f_1303},
{"f_1300:setup_2ddownload_2escm",(void*)f_1300},
{"f_1876:setup_2ddownload_2escm",(void*)f_1876},
{"f_1571:setup_2ddownload_2escm",(void*)f_1571},
{"f_1765:setup_2ddownload_2escm",(void*)f_1765},
{"f_1769:setup_2ddownload_2escm",(void*)f_1769},
{"f_1557:setup_2ddownload_2escm",(void*)f_1557},
{"f_2999:setup_2ddownload_2escm",(void*)f_2999},
{"f_2995:setup_2ddownload_2escm",(void*)f_2995},
{"f_1984:setup_2ddownload_2escm",(void*)f_1984},
{"f_1981:setup_2ddownload_2escm",(void*)f_1981},
{"f_1987:setup_2ddownload_2escm",(void*)f_1987},
{"f_2006:setup_2ddownload_2escm",(void*)f_2006},
{"f_1758:setup_2ddownload_2escm",(void*)f_1758},
{"f_1750:setup_2ddownload_2escm",(void*)f_1750},
{"f_1522:setup_2ddownload_2escm",(void*)f_1522},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|hiding nonexported module bindings: setup-download#constant148 
o|hiding nonexported module bindings: setup-download#*quiet* 
o|hiding nonexported module bindings: setup-download#*chicken-install-user-agent* 
o|hiding nonexported module bindings: setup-download#*trunk* 
o|hiding nonexported module bindings: setup-download#*mode* 
o|hiding nonexported module bindings: setup-download#*windows-shell* 
o|hiding nonexported module bindings: setup-download#d 
o|hiding nonexported module bindings: setup-download#get-temporary-directory 
o|hiding nonexported module bindings: setup-download#existing-version 
o|hiding nonexported module bindings: setup-download#when-no-such-version-warning 
o|hiding nonexported module bindings: setup-download#list-eggs/local 
o|hiding nonexported module bindings: setup-download#list-egg-versions/local 
o|hiding nonexported module bindings: setup-download#make-svn-ls-cmd 
o|hiding nonexported module bindings: setup-download#make-svn-export-cmd 
o|hiding nonexported module bindings: setup-download#list-eggs/svn 
o|hiding nonexported module bindings: setup-download#list-egg-versions/svn 
o|hiding nonexported module bindings: setup-download#metafile 
o|hiding nonexported module bindings: setup-download#deconstruct-url 
o|hiding nonexported module bindings: setup-download#network-failure 
o|hiding nonexported module bindings: setup-download#make-HTTP-GET/1.1 
o|hiding nonexported module bindings: setup-download#match-http-response 
o|hiding nonexported module bindings: setup-download#response-match-code? 
o|hiding nonexported module bindings: setup-download#match-chunked-transfer-encoding 
o|hiding nonexported module bindings: setup-download#http-connect 
o|hiding nonexported module bindings: setup-download#http-retrieve-files 
o|hiding nonexported module bindings: setup-download#http-fetch 
o|hiding nonexported module bindings: setup-download#list-eggs/http 
o|hiding nonexported module bindings: setup-download#throw-server-error 
o|hiding nonexported module bindings: setup-download#read-chunks 
o|hiding nonexported module bindings: setup-download#slashes 
o|hiding nonexported module bindings: setup-download#valid-extension-name? 
o|hiding nonexported module bindings: setup-download#check-egg-name 
S|applied compiler syntax:
S|  for-each		1
S|  sprintf		3
S|  map		4
o|eliminated procedure checks: 43 
o|specializations:
o|  8 (eqv? * (not float))
o|  1 (cddr (pair * pair))
o|  1 (string=? string string)
o|  2 (string-append string string)
o|  2 (zero? fixnum)
o|  3 (##sys#check-output-port * * *)
o|  3 (##sys#check-list (or pair list) *)
o|  2 (car pair)
o|  1 (current-output-port)
o|  1 (current-error-port)
(o e)|safe calls: 378 
o|Removed `not' forms: 4 
o|merged explicitly consed rest parameter: args158 
o|inlining procedure: k1368 
o|inlining procedure: k1368 
o|inlining procedure: k1380 
o|inlining procedure: k1380 
o|inlining procedure: k1405 
o|inlining procedure: k1405 
o|inlining procedure: k1573 
o|inlining procedure: k1573 
o|inlining procedure: k1610 
o|inlining procedure: k1610 
o|inlining procedure: k1640 
o|inlining procedure: k1640 
o|consed rest parameter at call site: "(setup-download.scm:118) setup-download#d" 2 
o|substituted constant variable: a1660 
o|substituted constant variable: a1661 
o|substituted constant variable: a1681 
o|substituted constant variable: a1682 
o|inlining procedure: k1706 
o|inlining procedure: k1729 
o|contracted procedure: "(setup-download.scm:125) g347354" 
o|consed rest parameter at call site: "(setup-download.scm:128) setup-download#d" 2 
o|inlining procedure: k1729 
o|propagated global variable: g342343 string-suffix? 
o|inlining procedure: k1706 
o|contracted procedure: k1773 
o|propagated global variable: r1774 setup-download#*trunk* 
o|inlining procedure: k1776 
o|inlining procedure: k1776 
o|inlining procedure: k1858 
o|inlining procedure: k1858 
o|merged explicitly consed rest parameter: tmp394398 
o|inlining procedure: k2263 
o|inlining procedure: k2263 
o|inlining procedure: k2300 
o|inlining procedure: k2300 
o|consed rest parameter at call site: "(setup-download.scm:214) setup-download#d" 2 
o|contracted procedure: "(setup-download.scm:202) setup-download#make-svn-export-cmd" 
o|inlining procedure: "(setup-download.scm:212) setup-download#metafile" 
o|inlining procedure: k2334 
o|inlining procedure: "(setup-download.scm:207) setup-download#metafile" 
o|inlining procedure: k2334 
o|inlining procedure: k2344 
o|inlining procedure: k2344 
o|inlining procedure: k2360 
o|inlining procedure: k2360 
o|consed rest parameter at call site: "(setup-download.scm:184) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:183) setup-download#make-svn-ls-cmd" 4 
o|inlining procedure: k2451 
o|inlining procedure: k2451 
o|inlining procedure: k2466 
o|inlining procedure: k2466 
o|substituted constant variable: setup-download#constant148 
o|inlining procedure: k2565 
o|inlining procedure: k2565 
o|inlining procedure: k2590 
o|inlining procedure: k2590 
o|contracted procedure: "(setup-download.scm:252) setup-download#http-fetch" 
o|contracted procedure: "(setup-download.scm:390) setup-download#http-retrieve-files" 
o|inlining procedure: k2981 
o|inlining procedure: k2981 
o|inlining procedure: k3010 
o|inlining procedure: k3010 
o|substituted constant variable: a3034 
o|inlining procedure: k3039 
o|inlining procedure: k3039 
o|inlining procedure: k3075 
o|contracted procedure: "(setup-download.scm:369) setup-download#throw-server-error" 
o|inlining procedure: k3075 
o|contracted procedure: k3109 
o|inlining procedure: k3106 
o|consed rest parameter at call site: "(setup-download.scm:377) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:381) setup-download#d" 2 
o|inlining procedure: k3106 
o|consed rest parameter at call site: "(setup-download.scm:341) setup-download#d" 2 
o|inlining procedure: k2623 
o|inlining procedure: k2623 
o|merged explicitly consed rest parameter: tmp629633 
o|inlining procedure: k2787 
o|inlining procedure: k2787 
o|inlining procedure: k2827 
o|inlining procedure: k2827 
o|inlining procedure: k2860 
o|contracted procedure: "(setup-download.scm:335) setup-download#read-chunks" 
o|contracted procedure: k3273 
o|inlining procedure: k3270 
o|consed rest parameter at call site: "(setup-download.scm:419) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:423) setup-download#d" 2 
o|inlining procedure: k3270 
o|consed rest parameter at call site: "(setup-download.scm:334) setup-download#d" 2 
o|inlining procedure: k2860 
o|inlining procedure: k2885 
o|inlining procedure: k2885 
o|consed rest parameter at call site: "(setup-download.scm:331) setup-download#d" 2 
o|contracted procedure: "(setup-download.scm:330) setup-download#match-chunked-transfer-encoding" 
o|consed rest parameter at call site: "(setup-download.scm:320) setup-download#make-HTTP-GET/1.1" 4 
o|inlining procedure: k2928 
o|inlining procedure: k2928 
o|contracted procedure: "(setup-download.scm:326) setup-download#network-failure" 
o|consed rest parameter at call site: "(setup-download.scm:314) setup-download#d" 2 
o|contracted procedure: "(setup-download.scm:313) setup-download#match-http-response" 
o|inlining procedure: k2775 
o|inlining procedure: k2775 
o|consed rest parameter at call site: "(setup-download.scm:310) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:306) setup-download#make-HTTP-GET/1.1" 4 
o|consed rest parameter at call site: "(setup-download.scm:304) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:299) setup-download#d" 2 
o|substituted constant variable: a2949 
o|substituted constant variable: a2950 
o|inlining procedure: k2942 
o|consed rest parameter at call site: "(setup-download.scm:299) setup-download#d" 2 
o|inlining procedure: k2942 
o|consed rest parameter at call site: "(setup-download.scm:299) setup-download#d" 2 
o|inlining procedure: k3338 
o|inlining procedure: k3338 
o|contracted procedure: "(setup-download.scm:434) setup-download#valid-extension-name?" 
o|contracted procedure: k3321 
o|inlining procedure: k3318 
o|inlining procedure: k3318 
o|inlining procedure: k3404 
o|inlining procedure: k3404 
o|inlining procedure: k3422 
o|inlining procedure: k3422 
o|substituted constant variable: a3435 
o|substituted constant variable: a3437 
o|substituted constant variable: a3439 
o|inlining procedure: k3484 
o|contracted procedure: "(setup-download.scm:460) setup-download#list-eggs/local" 
o|inlining procedure: k1435 
o|contracted procedure: "(setup-download.scm:85) g187196" 
o|inlining procedure: k1435 
o|inlining procedure: k3484 
o|contracted procedure: "(setup-download.scm:462) setup-download#list-eggs/svn" 
o|inlining procedure: k2020 
o|contracted procedure: "(setup-download.scm:166) g434443" 
o|substituted constant variable: a2007 
o|inlining procedure: k2020 
o|consed rest parameter at call site: "(setup-download.scm:164) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:163) setup-download#make-svn-ls-cmd" 4 
o|inlining procedure: k3502 
o|contracted procedure: "(setup-download.scm:464) setup-download#list-eggs/http" 
o|inlining procedure: k3502 
o|substituted constant variable: a3515 
o|substituted constant variable: a3517 
o|substituted constant variable: a3519 
o|inlining procedure: k3551 
o|contracted procedure: "(setup-download.scm:473) setup-download#list-egg-versions/local" 
o|inlining procedure: k1472 
o|inlining procedure: k1499 
o|contracted procedure: "(setup-download.scm:91) g229238" 
o|inlining procedure: k1499 
o|inlining procedure: k1472 
o|inlining procedure: k3551 
o|contracted procedure: "(setup-download.scm:475) setup-download#list-egg-versions/svn" 
o|inlining procedure: k2108 
o|inlining procedure: k2108 
o|inlining procedure: k2143 
o|contracted procedure: "(setup-download.scm:177) g485494" 
o|substituted constant variable: a2130 
o|inlining procedure: k2143 
o|consed rest parameter at call site: "(setup-download.scm:172) setup-download#make-svn-ls-cmd" 4 
o|substituted constant variable: a3573 
o|substituted constant variable: a3575 
o|replaced variables: 360 
o|removed binding forms: 179 
o|removed side-effect free assignment to unused variable: setup-download#constant148 
o|substituted constant variable: r17773610 
o|substituted constant variable: r18593612 
o|substituted constant variable: r23613638 
o|removed side-effect free assignment to unused variable: setup-download#metafile 
o|substituted constant variable: r24523641 
o|substituted constant variable: r24523641 
o|inlining procedure: k2590 
o|inlining procedure: k2590 
o|inlining procedure: k3010 
o|inlining procedure: k3010 
o|substituted constant variable: r26243677 
o|substituted constant variable: r26243677 
o|substituted constant variable: r26243679 
o|substituted constant variable: r26243679 
o|removed call to pure procedure with unused result: "(setup-download.scm:265) get-keyword" 
o|substituted constant variable: r27883682 
o|substituted constant variable: r27763704 
o|substituted constant variable: r29433707 
o|substituted constant variable: r29433707 
o|substituted constant variable: r33193711 
o|substituted constant variable: r14733729 
o|substituted constant variable: r21093731 
o|replaced variables: 21 
o|removed binding forms: 386 
o|inlining procedure: "(setup-download.scm:105) setup-download#when-no-such-version-warning" 
o|inlining procedure: "(setup-download.scm:197) setup-download#when-no-such-version-warning" 
o|contracted procedure: k2737 
o|inlining procedure: k2891 
o|inlining procedure: k2891 
o|replaced variables: 17 
o|removed binding forms: 53 
o|removed side-effect free assignment to unused variable: setup-download#when-no-such-version-warning 
o|substituted constant variable: r25913745 
o|replaced variables: 10 
o|removed binding forms: 19 
o|removed binding forms: 8 
o|simplifications: ((if . 41) (##core#call . 200)) 
o|  call simplifications:
o|    ##sys#check-list	2
o|    ##sys#setslot	4
o|    zero?
o|    string?	2
o|    read-string	2
o|    cadr
o|    eof-object?	2
o|    string=?	3
o|    string->number	2
o|    ##sys#get-keyword	23
o|    list
o|    ##sys#apply	2
o|    cons	12
o|    car	17
o|    null?	35
o|    cdr	17
o|    ##sys#call-with-values	11
o|    not	5
o|    ##sys#slot	14
o|    eq?	13
o|    values	20
o|    pair?	7
o|    member	3
o|    apply
o|contracted procedure: k1349 
o|contracted procedure: k1386 
o|contracted procedure: k1398 
o|contracted procedure: k1825 
o|contracted procedure: k1537 
o|contracted procedure: k1819 
o|contracted procedure: k1540 
o|contracted procedure: k1813 
o|contracted procedure: k1543 
o|contracted procedure: k1807 
o|contracted procedure: k1546 
o|contracted procedure: k1801 
o|contracted procedure: k1549 
o|contracted procedure: k1795 
o|contracted procedure: k1552 
o|inlining procedure: k1592 
o|contracted procedure: k1613 
o|contracted procedure: k1643 
o|contracted procedure: k1732 
o|contracted procedure: k1742 
o|contracted procedure: k1746 
o|contracted procedure: k1882 
o|contracted procedure: k1878 
o|contracted procedure: k1940 
o|contracted procedure: k1947 
o|contracted procedure: k2418 
o|contracted procedure: k2215 
o|contracted procedure: k2412 
o|contracted procedure: k2218 
o|contracted procedure: k2406 
o|contracted procedure: k2221 
o|contracted procedure: k2400 
o|contracted procedure: k2224 
o|contracted procedure: k2394 
o|contracted procedure: k2227 
o|contracted procedure: k2388 
o|contracted procedure: k2230 
o|contracted procedure: k2382 
o|contracted procedure: k2233 
o|contracted procedure: k2376 
o|contracted procedure: k2236 
o|contracted procedure: k2279 
o|contracted procedure: k2303 
o|contracted procedure: k1961 
o|contracted procedure: k2324 
o|contracted procedure: k2337 
o|contracted procedure: k2463 
o|contracted procedure: k2695 
o|contracted procedure: k2481 
o|contracted procedure: k2689 
o|contracted procedure: k2484 
o|contracted procedure: k2683 
o|contracted procedure: k2487 
o|contracted procedure: k2677 
o|contracted procedure: k2490 
o|contracted procedure: k2671 
o|contracted procedure: k2493 
o|contracted procedure: k2665 
o|contracted procedure: k2496 
o|contracted procedure: k2659 
o|contracted procedure: k2499 
o|contracted procedure: k2653 
o|contracted procedure: k2502 
o|contracted procedure: k2647 
o|contracted procedure: k2505 
o|contracted procedure: k2641 
o|contracted procedure: k2508 
o|contracted procedure: k2635 
o|contracted procedure: k2511 
o|contracted procedure: k2629 
o|contracted procedure: k2514 
o|contracted procedure: k2984 
o|contracted procedure: k3004 
o|contracted procedure: k3007 
o|contracted procedure: k3031 
o|contracted procedure: k3085 
o|contracted procedure: k3094 
o|contracted procedure: k3097 
o|contracted procedure: k3164 
o|contracted procedure: k3150 
o|contracted procedure: k3170 
o|contracted procedure: k2734 
o|contracted procedure: k2740 
o|contracted procedure: k2823 
o|contracted procedure: k3267 
o|contracted procedure: k3282 
o|contracted procedure: k3304 
o|contracted procedure: k2778 
o|contracted procedure: k3332 
o|contracted procedure: k3350 
o|contracted procedure: k3353 
o|contracted procedure: k3356 
o|contracted procedure: k3359 
o|contracted procedure: k3362 
o|contracted procedure: k3365 
o|contracted procedure: k3368 
o|contracted procedure: k3371 
o|contracted procedure: k3374 
o|contracted procedure: k3377 
o|contracted procedure: k3383 
o|contracted procedure: k3407 
o|contracted procedure: k3416 
o|contracted procedure: k3425 
o|contracted procedure: k3455 
o|contracted procedure: k3458 
o|contracted procedure: k3461 
o|contracted procedure: k3464 
o|contracted procedure: k3467 
o|contracted procedure: k3470 
o|contracted procedure: k3487 
o|contracted procedure: k1418 
o|contracted procedure: k1438 
o|contracted procedure: k1441 
o|contracted procedure: k1444 
o|contracted procedure: k1452 
o|contracted procedure: k1460 
o|contracted procedure: k3496 
o|contracted procedure: k2075 
o|contracted procedure: k1967 
o|contracted procedure: k2069 
o|contracted procedure: k1970 
o|contracted procedure: k2063 
o|contracted procedure: k1973 
o|contracted procedure: k2057 
o|contracted procedure: k1976 
o|contracted procedure: k1995 
o|contracted procedure: k2011 
o|contracted procedure: k2023 
o|contracted procedure: k2026 
o|contracted procedure: k2029 
o|contracted procedure: k2037 
o|contracted procedure: k2045 
o|contracted procedure: k3505 
o|contracted procedure: k3528 
o|contracted procedure: k3531 
o|contracted procedure: k3534 
o|contracted procedure: k3554 
o|contracted procedure: k1482 
o|contracted procedure: k1502 
o|contracted procedure: k1505 
o|contracted procedure: k1508 
o|contracted procedure: k1516 
o|contracted procedure: k1524 
o|contracted procedure: k3563 
o|contracted procedure: k2206 
o|contracted procedure: k2084 
o|contracted procedure: k2200 
o|contracted procedure: k2087 
o|contracted procedure: k2194 
o|contracted procedure: k2090 
o|contracted procedure: k2188 
o|contracted procedure: k2093 
o|contracted procedure: k2111 
o|contracted procedure: k2118 
o|contracted procedure: k2134 
o|contracted procedure: k2146 
o|contracted procedure: k2149 
o|contracted procedure: k2152 
o|contracted procedure: k2160 
o|contracted procedure: k2168 
o|simplifications: ((if . 1) (let . 13)) 
o|removed binding forms: 159 
o|substituted constant variable: r15933881 
o|inlining procedure: k2273 
o|replaced variables: 108 
o|removed conditional forms: 1 
o|removed binding forms: 42 
o|removed binding forms: 1 
o|customizable procedures: (map-loop479497 map-loop223248 map-loop428446 map-loop181206 setup-download#check-egg-name setup-download#response-match-code? setup-download#make-HTTP-GET/1.1 loop699 get-chunks826 k3078 get-files749 skip721 g732733 k3019 setup-download#http-connect setup-download#deconstruct-url setup-download#make-svn-ls-cmd setup-download#get-temporary-directory setup-download#existing-version k1616 for-each-loop346358 setup-download#d) 
o|calls to known targets: 87 
o|fast box initializations: 9 
o|fast global references: 56 
o|fast global assignments: 25 
o|dropping unused closure argument: f_1378 
o|dropping unused closure argument: f_1363 
o|dropping unused closure argument: f_2808 
o|dropping unused closure argument: f_2431 
o|dropping unused closure argument: f_3336 
o|dropping unused closure argument: f_2785 
o|dropping unused closure argument: f_2720 
o|dropping unused closure argument: f_1938 
o|dropping unused closure argument: f_1347 
*/
/* end of file */
