#!/bin/sh
echo "(+ 2 2)" | $@
