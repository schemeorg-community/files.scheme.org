# Hello World for Loko on KVM

This program demonstrates how to use the interpreter to load code
dynamically on a bare machine.

Multiboot modules provided by `-initrd` are made available in `/boot`.
This sample is a minimal library and program that runs directly on a
PC with the help of Loko.
