/* Generated from regex.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-07 01:29
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-07 on galinha (Linux)
   command line: regex.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -unsafe -no-lambda-info -output-file uregex.c
   unit: regex
*/

#include "chicken.h"

static void
out_of_memory_failure(const char *modnam, const char *prcnam, const char *typnam)
{
  fprintf(stderr, "%s@%s: out of memory - cannot allocate %s\\n", modnam, prcnam, typnam);
  exit(EXIT_FAILURE);
}
#include "pcre/pcre.h"
static const char *C_regex_error;
static int C_regex_error_offset;
#define OVECTOR_LENGTH_MULTIPLE 3
#define STATIC_OVECTOR_LEN 256
static int C_regex_ovector[OVECTOR_LENGTH_MULTIPLE * STATIC_OVECTOR_LEN];

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[96];
static double C_possibly_force_alignment;


/* from k1235 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub172(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub172(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *extra=(const pcre_extra *)C_c_pointer_or_null(C_a1);
int cc;pcre_fullinfo(code, extra, PCRE_INFO_CAPTURECOUNT, &cc);return(cc + 1);
C_ret:
#undef return

return C_r;}

/* from k1221 in k1244 in perform-match in k458 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub160(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub160(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *extra=(const pcre_extra *)C_c_pointer_or_null(C_a1);
char * str=(char * )C_c_string(C_a2);
int start=(int )C_unfix(C_a3);
int range=(int )C_unfix(C_a4);
unsigned int options=(unsigned int )C_num_to_unsigned_int(C_a5);
return(pcre_exec(code, extra, str, start + range, start, options, C_regex_ovector, STATIC_OVECTOR_LEN * OVECTOR_LENGTH_MULTIPLE));
C_ret:
#undef return

return C_r;}

/* from ovector-end-ref */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub139(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub139(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_regex_ovector[(i * 2) + 1]);
C_ret:
#undef return

return C_r;}

/* from ovector-start-ref */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub135(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub135(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_regex_ovector[i * 2]);
C_ret:
#undef return

return C_r;}

/* from k1073 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub122(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub122(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
return(pcre_study(code, 0, &C_regex_error));
C_ret:
#undef return

return C_r;}

/* from k899 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub74(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub74(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * patt=(char * )C_c_string(C_a0);
unsigned int options=(unsigned int )C_num_to_unsigned_int(C_a1);
const unsigned C_char *tables=(const unsigned C_char *)C_c_pointer_or_null(C_a2);
return(pcre_compile(patt, options, &C_regex_error, &C_regex_error_offset, tables));
C_ret:
#undef return

return C_r;}

/* from k865 */
static C_word C_fcall stub49(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub49(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
pcre_free(t0);
return C_r;}

C_noret_decl(C_regex_toplevel)
C_externexport void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_460)
static void C_ccall f_460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2415)
static void C_fcall f_2415(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_fcall f_2410(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2365)
static void C_fcall f_2365(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2389)
static void C_ccall f_2389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2322)
static void C_fcall f_2322(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2276)
static void C_fcall f_2276(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2295)
static void C_ccall f_2295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2302)
static void C_ccall f_2302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_fcall f_2016(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_fcall f_2074(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2156)
static void C_fcall f_2156(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2135)
static void C_ccall f_2135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2076)
static void C_fcall f_2076(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2072)
static void C_ccall f_2072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1927)
static void C_fcall f_1927(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1946)
static void C_fcall f_1946(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1877)
static void C_fcall f_1877(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1755)
static void C_fcall f_1755(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1649)
static void C_fcall f_1649(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1655)
static void C_fcall f_1655(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1710)
static void C_ccall f_1710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static C_word C_fcall f_1634(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1456)
static void C_fcall f_1456(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1464)
static void C_fcall f_1464(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1529)
static void C_ccall f_1529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1425)
static void C_ccall f_1425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1371)
static void C_fcall f_1371(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1384)
static void C_fcall f_1384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1353)
static void C_ccall f_1353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1353)
static void C_ccall f_1353r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1361)
static void C_ccall f_1361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1351)
static void C_ccall f_1351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1300)
static void C_fcall f_1300(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1242)
static void C_fcall f_1242(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1246)
static void C_ccall f_1246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1223)
static void C_ccall f_1223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1255)
static void C_ccall f_1255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1189)
static void C_fcall f_1189(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1193)
static void C_ccall f_1193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1201)
static void C_ccall f_1201(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1117)
static void C_fcall f_1117(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_fcall f_1135(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1169)
static void C_fcall f_1169(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1173)
static void C_ccall f_1173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1090)
static void C_ccall f_1090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1025)
static void C_fcall f_1025(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1020)
static void C_fcall f_1020(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_993)
static void C_fcall f_993(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1003)
static void C_ccall f_1003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1009)
static void C_ccall f_1009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_982)
static void C_ccall f_982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_923)
static void C_fcall f_923(C_word t0,C_word t1) C_noret;
C_noret_decl(f_944)
static void C_fcall f_944(C_word t0,C_word t1) C_noret;
C_noret_decl(f_906)
static void C_fcall f_906(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_878)
static void C_fcall f_878(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_890)
static void C_ccall f_890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_886)
static void C_ccall f_886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_872)
static void C_ccall f_872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_862)
static void C_ccall f_862(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_490)
static void C_fcall f_490(C_word t0,C_word t1) C_noret;
C_noret_decl(f_500)
static void C_fcall f_500(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_525)
static void C_ccall f_525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_478)
static void C_ccall f_478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_485)
static void C_ccall f_485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_462)
static void C_ccall f_462(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_2415)
static void C_fcall trf_2415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2415(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2415(t0,t1);}

C_noret_decl(trf_2410)
static void C_fcall trf_2410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2410(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2410(t0,t1,t2);}

C_noret_decl(trf_2365)
static void C_fcall trf_2365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2365(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2365(t0,t1,t2,t3);}

C_noret_decl(trf_2322)
static void C_fcall trf_2322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2322(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2322(t0,t1,t2);}

C_noret_decl(trf_2276)
static void C_fcall trf_2276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2276(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2276(t0,t1,t2);}

C_noret_decl(trf_2016)
static void C_fcall trf_2016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2016(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2016(t0,t1,t2);}

C_noret_decl(trf_2074)
static void C_fcall trf_2074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2074(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2074(t0,t1,t2);}

C_noret_decl(trf_2156)
static void C_fcall trf_2156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2156(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2156(t0,t1);}

C_noret_decl(trf_2076)
static void C_fcall trf_2076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2076(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2076(t0,t1,t2,t3);}

C_noret_decl(trf_1927)
static void C_fcall trf_1927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1927(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1927(t0,t1,t2);}

C_noret_decl(trf_1946)
static void C_fcall trf_1946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1946(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1946(t0,t1);}

C_noret_decl(trf_1877)
static void C_fcall trf_1877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1877(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1877(t0,t1,t2,t3);}

C_noret_decl(trf_1755)
static void C_fcall trf_1755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1755(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1755(t0,t1,t2,t3);}

C_noret_decl(trf_1649)
static void C_fcall trf_1649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1649(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1649(t0,t1,t2);}

C_noret_decl(trf_1655)
static void C_fcall trf_1655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1655(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1655(t0,t1,t2,t3);}

C_noret_decl(trf_1456)
static void C_fcall trf_1456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1456(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1456(t0,t1);}

C_noret_decl(trf_1464)
static void C_fcall trf_1464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1464(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1464(t0,t1,t2,t3);}

C_noret_decl(trf_1371)
static void C_fcall trf_1371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1371(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1371(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1384)
static void C_fcall trf_1384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1384(t0,t1);}

C_noret_decl(trf_1300)
static void C_fcall trf_1300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1300(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1300(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1242)
static void C_fcall trf_1242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1242(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1242(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1189)
static void C_fcall trf_1189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1189(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1189(t0,t1,t2,t3);}

C_noret_decl(trf_1117)
static void C_fcall trf_1117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1117(t0,t1);}

C_noret_decl(trf_1135)
static void C_fcall trf_1135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1135(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1135(t0,t1,t2);}

C_noret_decl(trf_1169)
static void C_fcall trf_1169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1169(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1169(t0,t1);}

C_noret_decl(trf_1025)
static void C_fcall trf_1025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1025(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1025(t0,t1);}

C_noret_decl(trf_1020)
static void C_fcall trf_1020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1020(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1020(t0,t1,t2);}

C_noret_decl(trf_993)
static void C_fcall trf_993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_993(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_993(t0,t1,t2,t3);}

C_noret_decl(trf_923)
static void C_fcall trf_923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_923(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_923(t0,t1);}

C_noret_decl(trf_944)
static void C_fcall trf_944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_944(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_944(t0,t1);}

C_noret_decl(trf_906)
static void C_fcall trf_906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_906(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_906(t0,t1,t2,t3);}

C_noret_decl(trf_878)
static void C_fcall trf_878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_878(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_878(t0,t1,t2,t3,t4);}

C_noret_decl(trf_490)
static void C_fcall trf_490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_490(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_490(t0,t1);}

C_noret_decl(trf_500)
static void C_fcall trf_500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_500(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_500(t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(740)){
C_save(t1);
C_rereclaim2(740*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,96);
lf[0]=C_h_intern(&lf[0],24,"\003sysregex-chardef-table\077");
lf[1]=C_h_intern(&lf[1],13,"chardef-table");
lf[2]=C_h_intern(&lf[2],23,"\003syscheck-chardef-table");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000-invalid character definition tables structure");
lf[6]=C_h_intern(&lf[6],8,"caseless");
lf[7]=C_h_intern(&lf[7],9,"multiline");
lf[8]=C_h_intern(&lf[8],6,"dotall");
lf[9]=C_h_intern(&lf[9],8,"extended");
lf[10]=C_h_intern(&lf[10],8,"anchored");
lf[11]=C_h_intern(&lf[11],14,"dollar-endonly");
lf[12]=C_h_intern(&lf[12],5,"extra");
lf[13]=C_h_intern(&lf[13],6,"notbol");
lf[14]=C_h_intern(&lf[14],6,"noteol");
lf[15]=C_h_intern(&lf[15],8,"ungreedy");
lf[16]=C_h_intern(&lf[16],8,"notempty");
lf[17]=C_h_intern(&lf[17],4,"utf8");
lf[18]=C_h_intern(&lf[18],15,"no-auto-capture");
lf[19]=C_h_intern(&lf[19],13,"no-utf8-check");
lf[20]=C_h_intern(&lf[20],12,"auto-callout");
lf[21]=C_h_intern(&lf[21],7,"partial");
lf[22]=C_h_intern(&lf[22],12,"dfa-shortest");
lf[23]=C_h_intern(&lf[23],11,"dfa-restart");
lf[24]=C_h_intern(&lf[24],9,"firstline");
lf[25]=C_h_intern(&lf[25],8,"dupnames");
lf[26]=C_h_intern(&lf[26],10,"newline-cr");
lf[27]=C_h_intern(&lf[27],10,"newline-lf");
lf[28]=C_h_intern(&lf[28],12,"newline-crlf");
lf[29]=C_h_intern(&lf[29],11,"newline-any");
lf[30]=C_h_intern(&lf[30],15,"newline-anycrlf");
lf[31]=C_h_intern(&lf[31],11,"bsr-anycrlf");
lf[32]=C_h_intern(&lf[32],11,"bsr-unicode");
lf[33]=C_h_intern(&lf[33],5,"error");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\024not a member of enum");
lf[35]=C_h_intern(&lf[35],11,"pcre-option");
lf[37]=C_h_intern(&lf[37],7,"regexp\077");
lf[38]=C_h_intern(&lf[38],6,"regexp");
lf[39]=C_h_intern(&lf[39],13,"string-append");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[42]=C_h_intern(&lf[42],17,"\003syspeek-c-string");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000!cannot compile regular expression");
lf[45]=C_h_intern(&lf[45],17,"\003sysmake-c-string");
lf[46]=C_h_intern(&lf[46],14,"set-finalizer!");
lf[47]=C_h_intern(&lf[47],7,"regexp*");
lf[48]=C_h_intern(&lf[48],15,"regexp-optimize");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot optimize regular expression");
lf[51]=C_h_intern(&lf[51],9,"substring");
lf[53]=C_h_intern(&lf[53],7,"\003sysmap");
lf[55]=C_h_intern(&lf[55],15,"\003syssignal-hook");
lf[56]=C_h_intern(&lf[56],11,"\000type-error");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\077bad argument type - not a string or compiled regular expression");
lf[58]=C_h_intern(&lf[58],19,"\003sysundefined-value");
lf[59]=C_h_intern(&lf[59],12,"string-match");
lf[60]=C_h_intern(&lf[60],22,"string-match-positions");
lf[61]=C_h_intern(&lf[61],21,"make-anchored-pattern");
lf[62]=C_h_intern(&lf[62],13,"string-search");
lf[63]=C_h_intern(&lf[63],23,"string-search-positions");
lf[64]=C_h_intern(&lf[64],7,"reverse");
lf[65]=C_h_intern(&lf[65],19,"string-split-fields");
lf[66]=C_h_intern(&lf[66],6,"\000infix");
lf[67]=C_h_intern(&lf[67],7,"\000suffix");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\037record does not end with suffix");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[70]=C_h_intern(&lf[70],11,"make-string");
lf[71]=C_h_intern(&lf[71],17,"string-substitute");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\030empty substitution match");
lf[73]=C_h_intern(&lf[73],21,"\003sysfragments->string");
lf[74]=C_h_intern(&lf[74],18,"string-substitute*");
lf[75]=C_h_intern(&lf[75],5,"glob\077");
lf[76]=C_h_intern(&lf[76],12,"list->string");
lf[77]=C_h_intern(&lf[77],12,"string->list");
lf[78]=C_h_intern(&lf[78],12,"glob->regexp");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000!unexpected end of character class");
lf[80]=C_h_intern(&lf[80],15,"\003sysmatch-error");
lf[81]=C_h_intern(&lf[81],4,"grep");
lf[82]=C_h_intern(&lf[82],18,"open-output-string");
lf[83]=C_h_intern(&lf[83],17,"get-output-string");
lf[84]=C_h_intern(&lf[84],13,"regexp-escape");
lf[85]=C_h_intern(&lf[85],16,"\003syswrite-char-0");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\001^");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\001$");
lf[90]=C_h_intern(&lf[90],10,"bitwise-or");
lf[91]=C_h_intern(&lf[91],7,"warning");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000<cannot select partial anchor for compiled regular expression");
lf[93]=C_h_intern(&lf[93],17,"register-feature!");
lf[94]=C_h_intern(&lf[94],5,"regex");
lf[95]=C_h_intern(&lf[95],4,"pcre");
C_register_lf2(lf,96,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_460,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 125  register-feature! */
t3=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[94],lf[95]);}

/* k458 */
static void C_ccall f_460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_460,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_462,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_478,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[5],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_490,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[36],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_862,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_872,tmp=(C_word)a,a+=2,tmp));
t7=*((C_word*)lf[39]+1);
t8=C_mutate(&lf[40],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_878,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[43],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_906,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_921,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_991,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1077,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[50],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1117,tmp=(C_word)a,a+=2,tmp));
t14=*((C_word*)lf[51]+1);
t15=C_mutate(&lf[52],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1189,a[2]=t14,tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[54],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1242,tmp=(C_word)a,a+=2,tmp));
t17=*((C_word*)lf[58]+1);
t18=C_mutate((C_word*)lf[59]+1,t17);
t19=*((C_word*)lf[58]+1);
t20=C_mutate((C_word*)lf[60]+1,t19);
t21=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1300,tmp=(C_word)a,a+=2,tmp);
t22=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1343,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1353,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t24=*((C_word*)lf[58]+1);
t25=C_mutate((C_word*)lf[62]+1,t24);
t26=*((C_word*)lf[58]+1);
t27=C_mutate((C_word*)lf[63]+1,t26);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1371,tmp=(C_word)a,a+=2,tmp);
t29=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1417,a[2]=t28,tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1427,a[2]=t28,tmp=(C_word)a,a+=3,tmp));
t31=*((C_word*)lf[64]+1);
t32=*((C_word*)lf[51]+1);
t33=*((C_word*)lf[63]+1);
t34=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1437,a[2]=t31,a[3]=t33,a[4]=t32,tmp=(C_word)a,a+=5,tmp));
t35=*((C_word*)lf[51]+1);
t36=*((C_word*)lf[64]+1);
t37=*((C_word*)lf[70]+1);
t38=*((C_word*)lf[63]+1);
t39=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1619,a[2]=t38,a[3]=t36,a[4]=t35,tmp=(C_word)a,a+=5,tmp));
t40=*((C_word*)lf[71]+1);
t41=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1862,a[2]=t40,tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1914,tmp=(C_word)a,a+=2,tmp));
t43=*((C_word*)lf[76]+1);
t44=*((C_word*)lf[77]+1);
t45=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1999,a[2]=t44,a[3]=t43,tmp=(C_word)a,a+=4,tmp));
t46=*((C_word*)lf[62]+1);
t47=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2267,a[2]=t46,tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[82]+1);
t49=*((C_word*)lf[83]+1);
t50=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2307,a[2]=t48,a[3]=t49,tmp=(C_word)a,a+=4,tmp));
t51=*((C_word*)lf[39]+1);
t52=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2363,a[2]=t51,tmp=(C_word)a,a+=3,tmp));
t53=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t53+1)))(2,t53,C_SCHEME_UNDEFINED);}

/* make-anchored-pattern in k458 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_2363r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2363r(t0,t1,t2,t3);}}

static void C_ccall f_2363r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2365,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2410,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2415,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-nos398414 */
t7=t6;
f_2415(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-noe399412 */
t9=t5;
f_2410(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body396401 */
t11=t4;
f_2365(t11,t1,t7,t9);}}}

/* def-nos398 in make-anchored-pattern in k458 */
static void C_fcall f_2415(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2415,NULL,2,t0,t1);}
/* def-noe399412 */
t2=((C_word*)t0)[2];
f_2410(t2,t1,C_SCHEME_FALSE);}

/* def-noe399 in make-anchored-pattern in k458 */
static void C_fcall f_2410(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2410,NULL,3,t0,t1,t2);}
/* body396401 */
t3=((C_word*)t0)[2];
f_2365(t3,t1,t2,C_SCHEME_FALSE);}

/* body396 in make-anchored-pattern in k458 */
static void C_fcall f_2365(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2365,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
t4=(C_truep(t2)?lf[86]:lf[87]);
t5=(C_truep(t3)?lf[88]:lf[89]);
/* regex.scm: 638  string-append */
t6=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t4,((C_word*)t0)[3],t5);}
else{
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[3],lf[38],lf[61]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2389,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=t2;
t7=(C_truep(t6)?t6:t3);
if(C_truep(t7)){
/* regex.scm: 642  warning */
t8=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,lf[61],lf[92]);}
else{
t8=t5;
f_2389(2,t8,C_SCHEME_UNDEFINED);}}}

/* k2387 in body396 in make-anchored-pattern in k458 */
static void C_ccall f_2389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2389,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[38]+1);
t5=(C_word)C_slot(t4,C_fix(3));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2403,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 646  pcre-option->number */
f_490(t6,lf[10]);}

/* k2401 in k2387 in body396 in make-anchored-pattern in k458 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 645  bitwise-or */
t2=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2390 in k2387 in body396 in make-anchored-pattern in k458 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* regexp-escape in k458 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2307,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2314,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 617  open-output-string */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2312 in regexp-escape in k458 */
static void C_ccall f_2314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2314,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2322,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2322(t6,((C_word*)t0)[2],C_fix(0));}

/* loop in k2312 in regexp-escape in k458 */
static void C_fcall f_2322(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2322,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
/* regex.scm: 620  get-output-string */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(63)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(42)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(43)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(94)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(36)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(40)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(41)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(91)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(93)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(124)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(125)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 623  ##sys#write-char-0 */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(92),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2354,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 627  ##sys#write-char-0 */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,(C_word)C_subchar(((C_word*)t0)[3],t2),((C_word*)t0)[4]);}}}

/* k2352 in loop in k2312 in regexp-escape in k458 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 628  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2322(t3,((C_word*)t0)[2],t2);}

/* k2339 in loop in k2312 in regexp-escape in k458 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2344,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 624  ##sys#write-char-0 */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,(C_word)C_subchar(((C_word*)t0)[3],((C_word*)t0)[6]),((C_word*)t0)[2]);}

/* k2342 in k2339 in loop in k2312 in regexp-escape in k458 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 625  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2322(t3,((C_word*)t0)[2],t2);}

/* grep in k458 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2267,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[81]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2276,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2276(t8,t1,t3);}

/* loop in grep in k458 */
static void C_fcall f_2276(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2276,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2295,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 605  string-search */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k2293 in loop in grep in k458 */
static void C_ccall f_2295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2295,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2302,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 606  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2276(t3,t2,((C_word*)t0)[2]);}
else{
/* regex.scm: 607  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2276(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k2300 in k2293 in loop in grep in k458 */
static void C_ccall f_2302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2302,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* glob->regexp in k458 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1999,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[78]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2010,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2014,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 572  string->list */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2012 in glob->regexp in k458 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2014,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2016,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2016(t5,((C_word*)t0)[2],t1);}

/* loop in k2012 in glob->regexp in k458 */
static void C_fcall f_2016(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(24);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2016,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
switch(t3){
case C_make_character(42):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2046,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 577  loop */
t16=t5;
t17=t4;
t1=t16;
t2=t17;
goto loop;
case C_make_character(63):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2059,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 578  loop */
t16=t5;
t17=t4;
t1=t16;
t2=t17;
goto loop;
case C_make_character(91):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2072,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_2074(t9,t5,t4);
default:
t5=(C_word)C_u_i_char_alphabeticp(t3);
t6=(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t3));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2251,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 590  loop */
t16=t7;
t17=t4;
t1=t16;
t2=t17;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2262,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 591  loop */
t16=t7;
t17=t4;
t1=t16;
t2=t17;
goto loop;}}}}

/* k2260 in loop in k2012 in glob->regexp in k458 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2262,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(92),t2));}

/* k2249 in loop in k2012 in glob->regexp in k458 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2251,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop2 in loop in k2012 in glob->regexp in k458 */
static void C_fcall f_2074(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2074,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_eqp(t4,C_make_character(93));
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2106,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 584  loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_2016(t8,t7,t6);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,C_make_character(45));
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_u_i_cadr(t2);
t10=(C_word)C_u_i_cddr(t2);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2135,a[2]=t1,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* loop2347 */
t22=t11;
t23=t10;
t1=t22;
t2=t23;
goto loop;}
else{
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_slot(t2,C_fix(1));
/* g353356 */
t11=t3;
f_2076(t11,t1,t9,t10);}}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2156,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_u_i_cadr(t2);
t11=(C_word)C_eqp(t10,C_make_character(45));
if(C_truep(t11)){
t12=(C_word)C_u_i_cddr(t2);
t13=t8;
f_2156(t13,(C_word)C_i_pairp(t12));}
else{
t12=t8;
f_2156(t12,C_SCHEME_FALSE);}}
else{
t10=t8;
f_2156(t10,C_SCHEME_FALSE);}}}}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* error */
t4=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[78],lf[79],((C_word*)t0)[2]);}
else{
/* ##sys#match-error */
t4=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}}

/* k2154 in loop2 in loop in k2012 in glob->regexp in k458 */
static void C_fcall f_2156(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2156,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_u_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2180,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* loop2347 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2074(t6,t5,t4);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* g353356 */
t4=((C_word*)t0)[2];
f_2076(t4,((C_word*)t0)[4],t2,t3);}}

/* k2178 in k2154 in loop2 in loop in k2012 in glob->regexp in k458 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2180,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,C_make_character(45),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2133 in loop2 in loop in k2012 in glob->regexp in k458 */
static void C_ccall f_2135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2135,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(45),t2));}

/* k2104 in loop2 in loop in k2012 in glob->regexp in k458 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2106,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(93),t1));}

/* g353 in loop2 in loop in k2012 in glob->regexp in k458 */
static void C_fcall f_2076(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2076,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2084,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 587  loop2 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2074(t5,t4,t3);}

/* k2082 in g353 in loop2 in loop in k2012 in glob->regexp in k458 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2084,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2070 in loop in k2012 in glob->regexp in k458 */
static void C_ccall f_2072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2072,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(91),t1));}

/* k2057 in loop in k2012 in glob->regexp in k458 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2059,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(46),t1));}

/* k2044 in loop in k2012 in glob->regexp in k458 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2046,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(42),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(46),t2));}

/* k2008 in glob->regexp in k458 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 571  list->string */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* glob? in k458 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1914,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[75]);
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=(C_word)C_u_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1927,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1927(t9,t1,t5);}

/* loop in glob? in k458 */
static void C_fcall f_1927(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1927,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(0),t2))){
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(t3,C_make_character(42));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_1946(t6,t4);}
else{
t6=(C_word)C_eqp(t3,C_make_character(93));
t7=t5;
f_1946(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,C_make_character(63))));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1944 in loop in glob? in k458 */
static void C_fcall f_1946(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(C_fix(0),((C_word*)t0)[5]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_subchar(((C_word*)t0)[3],t3);
t5=(C_word)C_eqp(C_make_character(92),t4);
t6=(C_word)C_i_not(t5);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 562  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1927(t8,((C_word*)t0)[4],t7);}}}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 564  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1927(t3,((C_word*)t0)[4],t2);}}

/* string-substitute* in k458 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1862r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1862r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1862r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(7);
t5=(C_word)C_i_check_string_2(t2,lf[74]);
t6=(C_word)C_i_check_list_2(t3,lf[74]);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1877,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_1877(t12,t1,t2,t3);}

/* loop in string-substitute* in k458 */
static void C_fcall f_1877(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1877,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1894,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t4);
t7=(C_word)C_slot(t4,C_fix(1));
/* regex.scm: 547  string-substitute */
t8=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t6,t7,t2,((C_word*)t0)[2]);}}

/* k1892 in loop in string-substitute* in k458 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 547  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1877(t3,((C_word*)t0)[2],t1,t2);}

/* string-substitute in k458 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+31)){
C_save_and_reclaim((void*)tr5rv,(void*)f_1619r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_1619r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1619r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a=C_alloc(31);
t6=(C_word)C_i_check_string_2(t3,lf[71]);
t7=(C_word)C_notvemptyp(t5);
t8=(C_truep(t7)?(C_word)C_slot(t5,C_fix(0)):C_fix(1));
t9=(C_word)C_block_size(t3);
t10=(C_word)C_u_fixnum_difference(t9,C_fix(1));
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_fix(0);
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1634,a[2]=t14,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1649,a[2]=t4,a[3]=t9,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t15,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1755,a[2]=((C_word*)t0)[2],a[3]=t12,a[4]=((C_word*)t0)[3],a[5]=t14,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=t16,a[9]=t18,a[10]=t15,a[11]=t8,a[12]=t2,tmp=(C_word)a,a+=13,tmp));
t20=((C_word*)t18)[1];
f_1755(t20,t1,C_fix(0),C_fix(1));}

/* loop in string-substitute in k458 */
static void C_fcall f_1755(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1755,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1759,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t3,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
/* regex.scm: 518  string-search-positions */
t5=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[12],((C_word*)t0)[6],t2);}

/* k1757 in loop in string-substitute in k458 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1759,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_u_fixnum_difference(t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* regex.scm: 523  ##sys#error */
t8=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[14],lf[71],lf[72],((C_word*)t0)[13]);}
else{
t8=(C_word)C_fixnump(((C_word*)t0)[12]);
t9=(C_word)C_i_not(t8);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[12]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1799,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t12=(C_word)C_u_i_car(t2);
/* regex.scm: 527  substring */
t13=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t11,((C_word*)t0)[6],((C_word*)t0)[5],t12);}
else{
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1817,a[2]=t3,a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 531  substring */
t12=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t11,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[6]);
/* regex.scm: 534  substring */
t4=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}

/* k1848 in k1757 in loop in string-substitute in k458 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1850,2,t0,t1);}
t2=f_1634(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 535  reverse */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k1844 in k1848 in k1757 in loop in string-substitute in k458 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 535  ##sys#fragments->string */
t2=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1815 in k1757 in loop in string-substitute in k458 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1817,2,t0,t1);}
t2=f_1634(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 532  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1755(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1797 in k1757 in loop in string-substitute in k458 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1799,2,t0,t1);}
t2=f_1634(C_a_i(&a,3),((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1792,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 528  substitute */
t4=((C_word*)t0)[3];
f_1649(t4,t3,((C_word*)t0)[2]);}

/* k1790 in k1797 in k1757 in loop in string-substitute in k458 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 529  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1755(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* substitute in string-substitute in k458 */
static void C_fcall f_1649(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1649,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1655,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_1655(t6,t1,C_fix(0),C_fix(0));}

/* loop in substitute in string-substitute in k458 */
static void C_fcall f_1655(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1655,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1669,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t4;
f_1669(2,t6,((C_word*)t0)[7]);}
else{
/* regex.scm: 505  substring */
t6=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[7],t2,((C_word*)t0)[5]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[7],t3);
t5=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t6=(C_word)C_eqp(t4,C_make_character(92));
if(C_truep(t6)){
t7=(C_word)C_subchar(((C_word*)t0)[7],t5);
t8=(C_word)C_eqp(C_make_character(92),t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:(C_word)C_u_i_char_numericp(t7));
if(C_truep(t9)){
t10=(C_word)C_fix((C_word)C_character_code(t7));
t11=(C_word)C_u_fixnum_difference(t10,C_fix(48));
t12=(C_word)C_u_i_list_ref(((C_word*)t0)[4],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t12,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t3,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* regex.scm: 512  substring */
t14=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t13,((C_word*)t0)[7],t2,t3);}
else{
t10=(C_word)C_u_fixnum_plus(t5,C_fix(1));
/* regex.scm: 515  loop */
t18=t1;
t19=t2;
t20=t10;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}
else{
/* regex.scm: 516  loop */
t18=t1;
t19=t2;
t20=t5;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}}

/* k1720 in loop in substitute in string-substitute in k458 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1722,2,t0,t1);}
t2=f_1634(C_a_i(&a,3),((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1710,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[4]);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* regex.scm: 513  substring */
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,((C_word*)t0)[2],t4,t5);}

/* k1708 in k1720 in loop in substitute in string-substitute in k458 */
static void C_ccall f_1710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1710,2,t0,t1);}
t2=f_1634(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 514  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1655(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k1667 in loop in substitute in string-substitute in k458 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1669,2,t0,t1);}
/* regex.scm: 505  push */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_1634(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in string-substitute in k458 */
static C_word C_fcall f_1634(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(C_word)C_block_size(t1);
t5=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t4);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}

/* string-split-fields in k458 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+25)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1437r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1437r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1437r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(25);
t5=(C_word)C_i_check_string_2(t3,lf[65]);
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_greaterp(t6,C_fix(0));
t9=(C_truep(t8)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_TRUE);
t10=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t11=(C_truep(t10)?(C_word)C_slot(t4,C_fix(1)):C_fix(0));
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1456,a[2]=t11,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_eqp(t9,lf[67]);
if(C_truep(t13)){
t14=t12;
f_1456(t14,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t7,tmp=(C_word)a,a+=6,tmp));}
else{
t14=(C_word)C_eqp(t9,lf[66]);
t15=t12;
f_1456(t15,(C_truep(t14)?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1575,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t7,tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1601,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}}

/* f_1601 in string-split-fields in k458 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1601,4,t0,t1,t2,t3);}
/* regex.scm: 467  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}

/* f_1575 in string-split-fields in k458 */
static void C_ccall f_1575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1575,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=(C_word)C_a_i_cons(&a,2,lf[69],t2);
/* regex.scm: 465  reverse */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1600,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 466  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}}

/* k1598 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1600,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* regex.scm: 466  reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_1555 in string-split-fields in k458 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1555,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[5]))){
/* regex.scm: 459  ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[65],lf[68],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* regex.scm: 461  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k1454 in string-split-fields in k458 */
static void C_fcall f_1456(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1456,NULL,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[66]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[67]));
t4=(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1539,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1544,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1464,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_1464(t8,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k1454 in string-split-fields in k458 */
static void C_fcall f_1464(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1464,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1468,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* regex.scm: 472  string-search-positions */
t5=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1466 in loop in k1454 in string-split-fields in k458 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1468,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(t4,((C_word*)t0)[8]);
if(C_truep(t6)){
/* regex.scm: 479  fini */
t7=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1510,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t4,C_fix(2));
/* regex.scm: 480  fetch */
t10=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,((C_word*)t0)[4],t8,t9);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1529,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 481  fetch */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[4],t3,t4);}}
else{
/* regex.scm: 482  fini */
t2=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k1527 in k1466 in loop in k1454 in string-split-fields in k458 */
static void C_ccall f_1529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1529,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 481  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1464(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1508 in k1466 in loop in k1454 in string-split-fields in k458 */
static void C_ccall f_1510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1510,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 480  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1464(t4,((C_word*)t0)[2],t2,t3);}

/* f_1544 in k1454 in string-split-fields in k458 */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1544,5,t0,t1,t2,t3,t4);}
/* regex.scm: 470  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* f_1539 in k1454 in string-split-fields in k458 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1539,5,t0,t1,t2,t3,t4);}
/* regex.scm: 469  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* string-search-positions in k458 */
static void C_ccall f_1427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_1427r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1427r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1427r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1435,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 440  prepare-search */
f_1371(t5,t2,t3,t4,lf[63]);}

/* k1433 in string-search-positions in k458 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 440  gather-result-positions */
f_1117(((C_word*)t0)[2],t1);}

/* string-search in k458 */
static void C_ccall f_1417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1417r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1417r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1417r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1425,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 436  prepare-search */
f_1371(t5,t2,t3,t4,lf[62]);}

/* k1423 in string-search in k458 */
static void C_ccall f_1425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 436  gather-results */
t2=lf[52];
f_1189(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* prepare-search in k458 */
static void C_fcall f_1371(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1371,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_string_2(t3,t5);
t7=(C_word)C_i_pairp(t4);
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(1)):C_SCHEME_FALSE);
t9=(C_truep(t8)?(C_word)C_u_i_car(t4):C_fix(0));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1384,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t8))){
t11=t10;
f_1384(t11,(C_word)C_u_i_car(t8));}
else{
t11=(C_word)C_block_size(t3);
t12=t10;
f_1384(t12,(C_word)C_u_fixnum_difference(t11,t9));}}

/* k1382 in prepare-search in k458 */
static void C_fcall f_1384(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_i_check_exact_2(t1,((C_word*)t0)[5]);
/* regex.scm: 432  perform-match */
f_1242(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],t1,((C_word*)t0)[5]);}

/* string-match-positions in k458 */
static void C_ccall f_1353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_1353r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1353r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1353r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1361,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 413  prepare-match */
f_1300(t5,t2,t3,t4,lf[60]);}

/* k1359 in string-match-positions in k458 */
static void C_ccall f_1361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 413  gather-result-positions */
f_1117(((C_word*)t0)[2],t1);}

/* string-match in k458 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1343r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1343r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1343r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1351,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 409  prepare-match */
f_1300(t5,t2,t3,t4,lf[59]);}

/* k1349 in string-match in k458 */
static void C_ccall f_1351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 409  gather-results */
t2=lf[52];
f_1189(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* prepare-match in k458 */
static void C_fcall f_1300(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1300,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_string_2(t3,t5);
t7=(C_word)C_i_pairp(t4);
t8=(C_truep(t7)?(C_word)C_u_i_car(t4):C_fix(0));
t9=(C_word)C_i_check_exact_2(t8,t5);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1317,a[2]=t5,a[3]=t1,a[4]=t8,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t11=(C_word)C_fixnum_lessp(C_fix(0),t8);
/* regex.scm: 402  make-anchored-pattern */
t12=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t2,t11);}
else{
t11=t10;
f_1317(2,t11,t2);}}

/* k1315 in prepare-match in k458 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[4]);
/* regex.scm: 401  perform-match */
f_1242(((C_word*)t0)[3],t1,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[2]);}

/* perform-match in k458 */
static void C_fcall f_1242(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1242,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1246,a[2]=t2,a[3]=t1,a[4]=t10,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
/* regex.scm: 373  re-checked-compile */
f_906(t11,t2,C_fix(0),t6);}
else{
t12=t2;
if(C_truep((C_word)C_i_structurep(t12,lf[38]))){
t13=t2;
t14=(C_word)C_slot(t13,C_fix(2));
t15=C_set_block_item(t8,0,t14);
t16=t2;
t17=(C_word)C_slot(t16,C_fix(3));
t18=C_set_block_item(t10,0,t17);
t19=t2;
t20=t11;
f_1246(2,t20,(C_word)C_slot(t19,C_fix(1)));}
else{
/* regex.scm: 379  ##sys#signal-hook */
t13=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t11,lf[56],t6,lf[57],t2);}}}

/* k1244 in perform-match in k458 */
static void C_ccall f_1246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1246,2,t0,t1);}
t2=t1;
t3=((C_word*)((C_word*)t0)[8])[1];
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t6=(C_word)stub172(C_SCHEME_UNDEFINED,t4,t5);
t7=t1;
t8=((C_word*)((C_word*)t0)[8])[1];
t9=((C_word*)t0)[7];
t10=((C_word*)t0)[6];
t11=((C_word*)t0)[5];
t12=((C_word*)((C_word*)t0)[4])[1];
t13=(C_word)C_i_foreign_pointer_argumentp(t7);
t14=(C_truep(t8)?(C_word)C_i_foreign_pointer_argumentp(t8):C_SCHEME_FALSE);
t15=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1223,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=t12,a[7]=t11,a[8]=t10,a[9]=t14,a[10]=t13,tmp=(C_word)a,a+=11,tmp);
/* ##sys#make-c-string */
t16=*((C_word*)lf[45]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,t9);}

/* k1221 in k1244 in perform-match in k458 */
static void C_ccall f_1223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1223,2,t0,t1);}
t2=(C_word)stub160(C_SCHEME_UNDEFINED,((C_word*)t0)[10],((C_word*)t0)[9],t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1255,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
/* regex.scm: 385  re-finalizer */
t4=lf[36];
f_862(3,t4,t3,((C_word*)t0)[2]);}
else{
t4=t3;
f_1255(2,t4,C_SCHEME_UNDEFINED);}}

/* k1253 in k1221 in k1244 in perform-match in k458 */
static void C_ccall f_1255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1255,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* gather-results in k458 */
static void C_fcall f_1189(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1189,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1193,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 349  gather-result-positions */
f_1117(t4,t3);}

/* k1191 in gather-results in k458 */
static void C_ccall f_1193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1193,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1201,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 351  ##sys#map */
t3=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1200 in k1191 in gather-results in k458 */
static void C_ccall f_1201(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1201,3,t0,t1,t2);}
if(C_truep(t2)){
C_apply(5,0,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* gather-result-positions in k458 */
static void C_fcall f_1117(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1117,NULL,2,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1135,a[2]=t6,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_1135(t8,t1,C_fix(0));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* loop in gather-result-positions in k458 */
static void C_fcall f_1135(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1135,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1155,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* regex.scm: 339  loop */
t11=t3;
t12=t4;
t1=t11;
t2=t12;
goto loop;}
else{
t3=t2;
t4=(C_word)stub135(C_SCHEME_UNDEFINED,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1169,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(0)))){
t6=t2;
t7=(C_word)stub139(C_SCHEME_UNDEFINED,t6);
t8=t5;
f_1169(t8,(C_word)C_a_i_list(&a,2,t4,t7));}
else{
t6=t5;
f_1169(t6,C_SCHEME_FALSE);}}}}

/* k1167 in loop in gather-result-positions in k458 */
static void C_fcall f_1169(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1169,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1173,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* regex.scm: 344  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1135(t4,t2,t3);}

/* k1171 in k1167 in loop in gather-result-positions in k458 */
static void C_ccall f_1173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1173,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1153 in loop in gather-result-positions in k458 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1155,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* regexp-optimize in k458 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1077,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[38],lf[48]);
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t7=(C_word)C_i_foreign_pointer_argumentp(t5);
t8=(C_word)stub122(t6,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1090,a[2]=t8,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t10=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_regex_error),C_fix(0));}

/* k1088 in regexp-optimize in k458 */
static void C_ccall f_1090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1090,2,t0,t1);}
if(C_truep(t1)){
/* regex.scm: 299  re-error */
t2=lf[40];
f_878(t2,((C_word*)t0)[4],lf[48],lf[49],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep(((C_word*)t0)[2])){
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1099,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* set-finalizer! */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],lf[36]);}
else{
t4=t3;
f_1099(2,t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k1097 in k1088 in regexp-optimize in k458 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* regexp* in k458 */
static void C_ccall f_991(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_991r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_991r(t0,t1,t2,t3);}}

static void C_ccall f_991r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_993,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1020,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1025,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-options102115 */
t7=t6;
f_1025(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-tables103113 */
t9=t5;
f_1020(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body100105 */
t11=t4;
f_993(t11,t1,t7,t9);}}}

/* def-options102 in regexp* in k458 */
static void C_fcall f_1025(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1025,NULL,2,t0,t1);}
/* def-tables103113 */
t2=((C_word*)t0)[2];
f_1020(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-tables103 in regexp* in k458 */
static void C_fcall f_1020(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1020,NULL,3,t0,t1,t2);}
/* body100105 */
t3=((C_word*)t0)[2];
f_993(t3,t1,t2,C_SCHEME_FALSE);}

/* body100 in regexp* in k458 */
static void C_fcall f_993(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_993,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[47]);
t5=(C_word)C_i_check_list_2(t2,lf[47]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1003,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* regex.scm: 280  ##sys#check-chardef-table */
t7=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[47]);}
else{
t7=t6;
f_1003(2,t7,C_SCHEME_UNDEFINED);}}

/* k1001 in body100 in regexp* in k458 */
static void C_ccall f_1003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1006,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1016,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 281  pcre-option->number */
f_490(t3,((C_word*)t0)[2]);}

/* k1014 in k1001 in body100 in regexp* in k458 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 281  re-checked-compile */
f_906(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[47]);}

/* k1004 in k1001 in body100 in regexp* in k458 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1009,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* set-finalizer! */
t3=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[36]);}

/* k1007 in k1004 in k1001 in body100 in regexp* in k458 */
static void C_ccall f_1009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1009,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[38],((C_word*)t0)[2],C_SCHEME_FALSE,C_fix(0)));}

/* regexp in k458 */
static void C_ccall f_921(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_921r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_921r(t0,t1,t2,t3);}}

static void C_ccall f_921r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_923,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_979,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_989,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 272  options->integer */
t7=t4;
f_923(t7,t6);}

/* k987 in regexp in k458 */
static void C_ccall f_989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 272  re-checked-compile */
f_906(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[38]);}

/* k977 in regexp in k458 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_982,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* set-finalizer! */
t3=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[36]);}

/* k980 in k977 in regexp in k458 */
static void C_ccall f_982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_982,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[38],((C_word*)t0)[2],C_SCHEME_FALSE,C_fix(0)));}

/* options->integer in regexp in k458 */
static void C_fcall f_923(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_923,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=(C_truep(t2)?C_unsigned_int_to_num(&a,PCRE_CASELESS):C_fix(0));
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_944,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_944(t6,C_fix(0));}
else{
t6=(C_word)C_u_i_car(t4);
t7=(C_truep(t6)?C_unsigned_int_to_num(&a,PCRE_EXTENDED):C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_i_pairp(t8);
t10=(C_truep(t9)?(C_word)C_u_i_car(t8):C_SCHEME_FALSE);
t11=(C_truep(t10)?C_unsigned_int_to_num(&a,PCRE_UTF8):C_fix(0));
t12=t5;
f_944(t12,(C_word)C_a_i_plus(&a,2,t7,t11));}}}

/* k942 in options->integer in regexp in k458 */
static void C_fcall f_944(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_944,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t1));}

/* re-checked-compile in k458 */
static void C_fcall f_906(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_906,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=t2;
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_897,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-c-string */
t9=*((C_word*)lf[45]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}

/* k895 in re-checked-compile in k458 */
static void C_ccall f_897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_897,2,t0,t1);}
t2=(C_word)stub74(((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* regex.scm: 256  re-error */
t3=lf[40];
f_878(t3,((C_word*)t0)[4],((C_word*)t0)[3],lf[44],(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],C_fix((C_word)C_regex_error_offset)));}}

/* re-error in k458 */
static void C_fcall f_878(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_878,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_886,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_890,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_regex_error),C_fix(0));}

/* k888 in re-error in k458 */
static void C_ccall f_890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 243  string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[41],t1);}

/* k884 in re-error in k458 */
static void C_ccall f_886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],*((C_word*)lf[3]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* regexp? in k458 */
static void C_ccall f_872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_872,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[38]));}

/* re-finalizer in k458 */
static void C_ccall f_862(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_862,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub49(C_SCHEME_UNDEFINED,t3));}

/* pcre-option->number in k458 */
static void C_fcall f_490(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_490,NULL,2,t1,t2);}
t3=(C_word)C_i_symbolp(t2);
t4=(C_truep(t3)?(C_word)C_a_i_list(&a,1,t2):t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_500,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_500(t8,t1,t4,C_fix(0));}

/* loop in pcre-option->number in k458 */
static void C_fcall f_500(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_500,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_525,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_eqp(t5,lf[6]);
if(C_truep(t7)){
t8=t6;
f_525(2,t8,C_unsigned_int_to_num(&a,PCRE_CASELESS));}
else{
t8=(C_word)C_eqp(t5,lf[7]);
if(C_truep(t8)){
t9=t6;
f_525(2,t9,C_unsigned_int_to_num(&a,PCRE_MULTILINE));}
else{
t9=(C_word)C_eqp(t5,lf[8]);
if(C_truep(t9)){
t10=t6;
f_525(2,t10,C_unsigned_int_to_num(&a,PCRE_DOTALL));}
else{
t10=(C_word)C_eqp(t5,lf[9]);
if(C_truep(t10)){
t11=t6;
f_525(2,t11,C_unsigned_int_to_num(&a,PCRE_EXTENDED));}
else{
t11=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t11)){
t12=t6;
f_525(2,t12,C_unsigned_int_to_num(&a,PCRE_ANCHORED));}
else{
t12=(C_word)C_eqp(t5,lf[11]);
if(C_truep(t12)){
t13=t6;
f_525(2,t13,C_unsigned_int_to_num(&a,PCRE_DOLLAR_ENDONLY));}
else{
t13=(C_word)C_eqp(t5,lf[12]);
if(C_truep(t13)){
t14=t6;
f_525(2,t14,C_unsigned_int_to_num(&a,PCRE_EXTRA));}
else{
t14=(C_word)C_eqp(t5,lf[13]);
if(C_truep(t14)){
t15=t6;
f_525(2,t15,C_unsigned_int_to_num(&a,PCRE_NOTBOL));}
else{
t15=(C_word)C_eqp(t5,lf[14]);
if(C_truep(t15)){
t16=t6;
f_525(2,t16,C_unsigned_int_to_num(&a,PCRE_NOTEOL));}
else{
t16=(C_word)C_eqp(t5,lf[15]);
if(C_truep(t16)){
t17=t6;
f_525(2,t17,C_unsigned_int_to_num(&a,PCRE_UNGREEDY));}
else{
t17=(C_word)C_eqp(t5,lf[16]);
if(C_truep(t17)){
t18=t6;
f_525(2,t18,C_unsigned_int_to_num(&a,PCRE_NOTEMPTY));}
else{
t18=(C_word)C_eqp(t5,lf[17]);
if(C_truep(t18)){
t19=t6;
f_525(2,t19,C_unsigned_int_to_num(&a,PCRE_UTF8));}
else{
t19=(C_word)C_eqp(t5,lf[18]);
if(C_truep(t19)){
t20=t6;
f_525(2,t20,C_unsigned_int_to_num(&a,PCRE_NO_AUTO_CAPTURE));}
else{
t20=(C_word)C_eqp(t5,lf[19]);
if(C_truep(t20)){
t21=t6;
f_525(2,t21,C_unsigned_int_to_num(&a,PCRE_NO_UTF8_CHECK));}
else{
t21=(C_word)C_eqp(t5,lf[20]);
if(C_truep(t21)){
t22=t6;
f_525(2,t22,C_unsigned_int_to_num(&a,PCRE_AUTO_CALLOUT));}
else{
t22=(C_word)C_eqp(t5,lf[21]);
if(C_truep(t22)){
t23=t6;
f_525(2,t23,C_unsigned_int_to_num(&a,PCRE_PARTIAL));}
else{
t23=(C_word)C_eqp(t5,lf[22]);
if(C_truep(t23)){
t24=t6;
f_525(2,t24,C_unsigned_int_to_num(&a,PCRE_DFA_SHORTEST));}
else{
t24=(C_word)C_eqp(t5,lf[23]);
if(C_truep(t24)){
t25=t6;
f_525(2,t25,C_unsigned_int_to_num(&a,PCRE_DFA_RESTART));}
else{
t25=(C_word)C_eqp(t5,lf[24]);
if(C_truep(t25)){
t26=t6;
f_525(2,t26,C_unsigned_int_to_num(&a,PCRE_FIRSTLINE));}
else{
t26=(C_word)C_eqp(t5,lf[25]);
if(C_truep(t26)){
t27=t6;
f_525(2,t27,C_unsigned_int_to_num(&a,PCRE_DUPNAMES));}
else{
t27=(C_word)C_eqp(t5,lf[26]);
if(C_truep(t27)){
t28=t6;
f_525(2,t28,C_unsigned_int_to_num(&a,PCRE_NEWLINE_CR));}
else{
t28=(C_word)C_eqp(t5,lf[27]);
if(C_truep(t28)){
t29=t6;
f_525(2,t29,C_unsigned_int_to_num(&a,PCRE_NEWLINE_LF));}
else{
t29=(C_word)C_eqp(t5,lf[28]);
if(C_truep(t29)){
t30=t6;
f_525(2,t30,C_unsigned_int_to_num(&a,PCRE_NEWLINE_CRLF));}
else{
t30=(C_word)C_eqp(t5,lf[29]);
if(C_truep(t30)){
t31=t6;
f_525(2,t31,C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANY));}
else{
t31=(C_word)C_eqp(t5,lf[30]);
if(C_truep(t31)){
t32=t6;
f_525(2,t32,C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANYCRLF));}
else{
t32=(C_word)C_eqp(t5,lf[31]);
if(C_truep(t32)){
t33=t6;
f_525(2,t33,C_unsigned_int_to_num(&a,PCRE_BSR_ANYCRLF));}
else{
t33=(C_word)C_eqp(t5,lf[32]);
if(C_truep(t33)){
t34=t6;
f_525(2,t34,C_unsigned_int_to_num(&a,PCRE_BSR_UNICODE));}
else{
/* regex.scm: 164  error */
t34=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t34+1)))(5,t34,t6,lf[34],t5,lf[35]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k523 in loop in pcre-option->number in k458 */
static void C_ccall f_525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_525,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_ior(&a,2,((C_word*)t0)[5],t1);
/* regex.scm: 164  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_500(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* ##sys#check-chardef-table in k458 */
static void C_ccall f_478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_478,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_485,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 146  ##sys#regex-chardef-table? */
t5=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k483 in ##sys#check-chardef-table in k458 */
static void C_ccall f_485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* regex.scm: 147  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[4],((C_word*)t0)[2]);}}

/* ##sys#regex-chardef-table? in k458 */
static void C_ccall f_462(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_462,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[1],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[122] = {
{"toplevelregex.scm",(void*)C_regex_toplevel},
{"f_460regex.scm",(void*)f_460},
{"f_2363regex.scm",(void*)f_2363},
{"f_2415regex.scm",(void*)f_2415},
{"f_2410regex.scm",(void*)f_2410},
{"f_2365regex.scm",(void*)f_2365},
{"f_2389regex.scm",(void*)f_2389},
{"f_2403regex.scm",(void*)f_2403},
{"f_2392regex.scm",(void*)f_2392},
{"f_2307regex.scm",(void*)f_2307},
{"f_2314regex.scm",(void*)f_2314},
{"f_2322regex.scm",(void*)f_2322},
{"f_2354regex.scm",(void*)f_2354},
{"f_2341regex.scm",(void*)f_2341},
{"f_2344regex.scm",(void*)f_2344},
{"f_2267regex.scm",(void*)f_2267},
{"f_2276regex.scm",(void*)f_2276},
{"f_2295regex.scm",(void*)f_2295},
{"f_2302regex.scm",(void*)f_2302},
{"f_1999regex.scm",(void*)f_1999},
{"f_2014regex.scm",(void*)f_2014},
{"f_2016regex.scm",(void*)f_2016},
{"f_2262regex.scm",(void*)f_2262},
{"f_2251regex.scm",(void*)f_2251},
{"f_2074regex.scm",(void*)f_2074},
{"f_2156regex.scm",(void*)f_2156},
{"f_2180regex.scm",(void*)f_2180},
{"f_2135regex.scm",(void*)f_2135},
{"f_2106regex.scm",(void*)f_2106},
{"f_2076regex.scm",(void*)f_2076},
{"f_2084regex.scm",(void*)f_2084},
{"f_2072regex.scm",(void*)f_2072},
{"f_2059regex.scm",(void*)f_2059},
{"f_2046regex.scm",(void*)f_2046},
{"f_2010regex.scm",(void*)f_2010},
{"f_1914regex.scm",(void*)f_1914},
{"f_1927regex.scm",(void*)f_1927},
{"f_1946regex.scm",(void*)f_1946},
{"f_1862regex.scm",(void*)f_1862},
{"f_1877regex.scm",(void*)f_1877},
{"f_1894regex.scm",(void*)f_1894},
{"f_1619regex.scm",(void*)f_1619},
{"f_1755regex.scm",(void*)f_1755},
{"f_1759regex.scm",(void*)f_1759},
{"f_1850regex.scm",(void*)f_1850},
{"f_1846regex.scm",(void*)f_1846},
{"f_1817regex.scm",(void*)f_1817},
{"f_1799regex.scm",(void*)f_1799},
{"f_1792regex.scm",(void*)f_1792},
{"f_1649regex.scm",(void*)f_1649},
{"f_1655regex.scm",(void*)f_1655},
{"f_1722regex.scm",(void*)f_1722},
{"f_1710regex.scm",(void*)f_1710},
{"f_1669regex.scm",(void*)f_1669},
{"f_1634regex.scm",(void*)f_1634},
{"f_1437regex.scm",(void*)f_1437},
{"f_1601regex.scm",(void*)f_1601},
{"f_1575regex.scm",(void*)f_1575},
{"f_1600regex.scm",(void*)f_1600},
{"f_1555regex.scm",(void*)f_1555},
{"f_1456regex.scm",(void*)f_1456},
{"f_1464regex.scm",(void*)f_1464},
{"f_1468regex.scm",(void*)f_1468},
{"f_1529regex.scm",(void*)f_1529},
{"f_1510regex.scm",(void*)f_1510},
{"f_1544regex.scm",(void*)f_1544},
{"f_1539regex.scm",(void*)f_1539},
{"f_1427regex.scm",(void*)f_1427},
{"f_1435regex.scm",(void*)f_1435},
{"f_1417regex.scm",(void*)f_1417},
{"f_1425regex.scm",(void*)f_1425},
{"f_1371regex.scm",(void*)f_1371},
{"f_1384regex.scm",(void*)f_1384},
{"f_1353regex.scm",(void*)f_1353},
{"f_1361regex.scm",(void*)f_1361},
{"f_1343regex.scm",(void*)f_1343},
{"f_1351regex.scm",(void*)f_1351},
{"f_1300regex.scm",(void*)f_1300},
{"f_1317regex.scm",(void*)f_1317},
{"f_1242regex.scm",(void*)f_1242},
{"f_1246regex.scm",(void*)f_1246},
{"f_1223regex.scm",(void*)f_1223},
{"f_1255regex.scm",(void*)f_1255},
{"f_1189regex.scm",(void*)f_1189},
{"f_1193regex.scm",(void*)f_1193},
{"f_1201regex.scm",(void*)f_1201},
{"f_1117regex.scm",(void*)f_1117},
{"f_1135regex.scm",(void*)f_1135},
{"f_1169regex.scm",(void*)f_1169},
{"f_1173regex.scm",(void*)f_1173},
{"f_1155regex.scm",(void*)f_1155},
{"f_1077regex.scm",(void*)f_1077},
{"f_1090regex.scm",(void*)f_1090},
{"f_1099regex.scm",(void*)f_1099},
{"f_991regex.scm",(void*)f_991},
{"f_1025regex.scm",(void*)f_1025},
{"f_1020regex.scm",(void*)f_1020},
{"f_993regex.scm",(void*)f_993},
{"f_1003regex.scm",(void*)f_1003},
{"f_1016regex.scm",(void*)f_1016},
{"f_1006regex.scm",(void*)f_1006},
{"f_1009regex.scm",(void*)f_1009},
{"f_921regex.scm",(void*)f_921},
{"f_989regex.scm",(void*)f_989},
{"f_979regex.scm",(void*)f_979},
{"f_982regex.scm",(void*)f_982},
{"f_923regex.scm",(void*)f_923},
{"f_944regex.scm",(void*)f_944},
{"f_906regex.scm",(void*)f_906},
{"f_897regex.scm",(void*)f_897},
{"f_878regex.scm",(void*)f_878},
{"f_890regex.scm",(void*)f_890},
{"f_886regex.scm",(void*)f_886},
{"f_872regex.scm",(void*)f_872},
{"f_862regex.scm",(void*)f_862},
{"f_490regex.scm",(void*)f_490},
{"f_500regex.scm",(void*)f_500},
{"f_525regex.scm",(void*)f_525},
{"f_478regex.scm",(void*)f_478},
{"f_485regex.scm",(void*)f_485},
{"f_462regex.scm",(void*)f_462},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
