/* Generated from posixwin.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-07 01:28
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-07 on galinha (Linux)
   command line: posixwin.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file posixwin.c
   unit: posix
*/

#include "chicken.h"

#ifndef WIN32_LEAN_AND_MEAN
# define WIN32_LEAN_AND_MEAN
#endif

/*
MinGW should have winsock2.h and ws2tcpip.h as well.
The CMake build will set HAVE_WINSOCK2_H and HAVE_WS2TCPIP_H.
However, the _MSC_VER test is still needed for vcbuild.bat.
./configure doesn't test for these.  It should, for MinGW.
*/
#if (_MSC_VER > 1300) || (defined(HAVE_WINSOCK2_H) && defined(HAVE_WS2TCPIP_H))
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <winsock.h>
#endif

#include <signal.h>
#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <process.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <direct.h>

#include <time.h>

#define ARG_MAX		256
#define PIPE_BUF	512
#ifndef ENV_MAX
# define ENV_MAX	1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS struct stat C_statbuf;

/* pipe handles */
static C_TLS HANDLE C_rd0, C_wr0, C_wr0_, C_rd1, C_wr1, C_rd1_;
static C_TLS HANDLE C_save0, C_save1; /* saved I/O handles */
static C_TLS char C_rdbuf; /* one-char buffer for read */
static C_TLS int C_exstatus;

/* platform information; initialized for cached testing */
static C_TLS char C_hostname[256] = "";
static C_TLS char C_osver[16] = "";
static C_TLS char C_osrel[16] = "";
static C_TLS char C_processor[16] = "";
static C_TLS char C_shlcmd[256] = "";

/* Windows NT or better */
static int C_isNT = 0;

/* Current user name */
static C_TLS TCHAR C_username[255 + 1] = "";

/* Directory Operations */

#define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#define C_chdir(str)	    C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)	    C_fix(rmdir(C_c_string(str)))

#ifndef __WATCOMC__
/* DIRENT stuff */
struct dirent
{
    char *		d_name;
};

typedef struct
{
    struct _finddata_t	fdata;
    int			handle;
    struct dirent	current;
} DIR;

static DIR * C_fcall
opendir(const char *name)
{
    int name_len = strlen(name);
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    char *what;
    if (!dir)
    {
	errno = ENOMEM;
	return NULL;
    }
    what = (char *)malloc(name_len + 3);
    if (!what)
    {
	free(dir);
	errno = ENOMEM;
	return NULL;
    }
    strcpy(what, name);
    if (strchr("\\/", name[name_len - 1]))
	strcat(what, "*");
    else
	strcat(what, "\\*");

    dir->handle = _findfirst(what, &dir->fdata);
    if (dir->handle == -1)
    {
	free(what);
	free(dir);
	return NULL;
    }
    dir->current.d_name = NULL; /* as the first-time indicator */
    free(what);
    return dir;
}

static int C_fcall
closedir(DIR * dir)
{
    if (dir)
    {
	int res = _findclose(dir->handle);
	free(dir);
	return res;
    }
    return -1;
}

static struct dirent * C_fcall
readdir(DIR * dir)
{
    if (dir)
    {
	if (!dir->current.d_name /* first time after opendir */
	     || _findnext(dir->handle, &dir->fdata) != -1)
	{
	    dir->current.d_name = dir->fdata.name;
	    return &dir->current;
	}
    }
    return NULL;
}
#endif /* ifndef __WATCOMC__ */

#ifdef __WATCOMC__
# define mktemp _mktemp
/* there is no P_DETACH in Watcom CRTL */
# define P_DETACH P_NOWAIT
#endif

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)		(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)	    (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, _popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, _popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)			     C_fix(_pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_getpid	    getpid
#define C_chmod(fn, m)	    C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)	    C_fix(fileno(C_port_file(p)))
#define C_dup(x)	    C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)	    C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)	    C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_pipe(d, m)	    C_fix(_pipe(C_pipefds, PIPE_BUF, C_unfix(m)))
#define C_close(fd)	    C_fix(close(C_unfix(fd)))

#define C_getenventry(i)   environ[ i ]

#define C_putenv(s)	    C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)	    C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)	    C_fix(fstat(C_unfix(f), &C_statbuf))

static C_word C_fcall
C_setenv(C_word x, C_word y)
{
    char *sx = C_data_pointer(x),
	 *sy = C_data_pointer(y);
    int n1 = C_strlen(sx),
	n2 = C_strlen(sy);
    char *buf = (char *)C_malloc(n1 + n2 + 2);
    if (buf == NULL)
	return(C_fix(0));
    else
    {
	C_strcpy(buf, sx);
	buf[ n1 ] = '=';
	C_strcpy(buf + n1 + 1, sy);
	return(C_fix(putenv(buf)));
    }
}

static void C_fcall
C_set_arg_string(char **where, int i, char *dat, int len)
{
    char *ptr;
    if (dat)
    {
	ptr = (char *)C_malloc(len + 1);
	C_memcpy(ptr, dat, len);
	ptr[ len ] = '\0';
    }
    else
	ptr = NULL;
    where[ i ] = ptr;
}

static void C_fcall
C_free_arg_string(char **where) {
  while (*where) C_free(*(where++));
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)

#define C_free_exec_args()		(C_free_arg_string(C_exec_args), C_SCHEME_TRUE)
#define C_free_exec_env()		(C_free_arg_string(C_exec_env), C_SCHEME_TRUE)

#define C_execvp(f)	    C_fix(execvp(C_data_pointer(f), (const char *const *)C_exec_args))
#define C_execve(f)	    C_fix(execve(C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

/* MS replacement for the fork-exec pair */
#define C_spawnvp(m, f)	    C_fix(spawnvp(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args))
#define C_spawnvpe(m, f)    C_fix(spawnvpe(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)	    C_fix(mktemp(C_c_string(t)))

#define C_ftell(p)	    C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)   C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_flushall()	    C_fix(_flushall())

#define C_ctime(n)	    (C_secs = (n), ctime(&C_secs))

#define C_asctime(v)	    (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), asctime(&C_tm) )
#define C_mktime(v)	    (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), (C_temporary_flonum = mktime(&C_tm)) != -1)

/*
  mapping from Win32 error codes to errno
*/

typedef struct
{
    DWORD   win32;
    int	    libc;
} errmap_t;

static errmap_t errmap[] =
{
    {ERROR_INVALID_FUNCTION,	  EINVAL},
    {ERROR_FILE_NOT_FOUND,	  ENOENT},
    {ERROR_PATH_NOT_FOUND,	  ENOENT},
    {ERROR_TOO_MANY_OPEN_FILES,	  EMFILE},
    {ERROR_ACCESS_DENIED,	  EACCES},
    {ERROR_INVALID_HANDLE,	  EBADF},
    {ERROR_ARENA_TRASHED,	  ENOMEM},
    {ERROR_NOT_ENOUGH_MEMORY,	  ENOMEM},
    {ERROR_INVALID_BLOCK,	  ENOMEM},
    {ERROR_BAD_ENVIRONMENT,	  E2BIG},
    {ERROR_BAD_FORMAT,		  ENOEXEC},
    {ERROR_INVALID_ACCESS,	  EINVAL},
    {ERROR_INVALID_DATA,	  EINVAL},
    {ERROR_INVALID_DRIVE,	  ENOENT},
    {ERROR_CURRENT_DIRECTORY,	  EACCES},
    {ERROR_NOT_SAME_DEVICE,	  EXDEV},
    {ERROR_NO_MORE_FILES,	  ENOENT},
    {ERROR_LOCK_VIOLATION,	  EACCES},
    {ERROR_BAD_NETPATH,		  ENOENT},
    {ERROR_NETWORK_ACCESS_DENIED, EACCES},
    {ERROR_BAD_NET_NAME,	  ENOENT},
    {ERROR_FILE_EXISTS,		  EEXIST},
    {ERROR_CANNOT_MAKE,		  EACCES},
    {ERROR_FAIL_I24,		  EACCES},
    {ERROR_INVALID_PARAMETER,	  EINVAL},
    {ERROR_NO_PROC_SLOTS,	  EAGAIN},
    {ERROR_DRIVE_LOCKED,	  EACCES},
    {ERROR_BROKEN_PIPE,		  EPIPE},
    {ERROR_DISK_FULL,		  ENOSPC},
    {ERROR_INVALID_TARGET_HANDLE, EBADF},
    {ERROR_INVALID_HANDLE,	  EINVAL},
    {ERROR_WAIT_NO_CHILDREN,	  ECHILD},
    {ERROR_CHILD_NOT_COMPLETE,	  ECHILD},
    {ERROR_DIRECT_ACCESS_HANDLE,  EBADF},
    {ERROR_NEGATIVE_SEEK,	  EINVAL},
    {ERROR_SEEK_ON_DEVICE,	  EACCES},
    {ERROR_DIR_NOT_EMPTY,	  ENOTEMPTY},
    {ERROR_NOT_LOCKED,		  EACCES},
    {ERROR_BAD_PATHNAME,	  ENOENT},
    {ERROR_MAX_THRDS_REACHED,	  EAGAIN},
    {ERROR_LOCK_FAILED,		  EACCES},
    {ERROR_ALREADY_EXISTS,	  EEXIST},
    {ERROR_FILENAME_EXCED_RANGE,  ENOENT},
    {ERROR_NESTING_NOT_ALLOWED,	  EAGAIN},
    {ERROR_NOT_ENOUGH_QUOTA,	  ENOMEM},
    {0, 0}
};

static void C_fcall
set_errno(DWORD w32err)
{
    errmap_t *map = errmap;
    for (; errmap->win32; ++map)
    {
	if (errmap->win32 == w32err)
	{
	    errno = errmap->libc;
	    return;
	}
    }
}

static int C_fcall
set_last_errno()
{
    set_errno(GetLastError());
    return 0;
}

/* Functions for creating process with redirected I/O */

static int C_fcall
zero_handles()
{
    C_rd0 = C_wr0 = C_wr0_ = INVALID_HANDLE_VALUE;
    C_rd1 = C_wr1 = C_rd1_ = INVALID_HANDLE_VALUE;
    C_save0 = C_save1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
close_handles()
{
    if (C_rd0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd0);
    if (C_rd1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1);
    if (C_wr0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0);
    if (C_wr1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr1);
    if (C_rd1_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1_);
    if (C_wr0_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0_);
    if (C_save0 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	CloseHandle(C_save0);
    }
    if (C_save1 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	CloseHandle(C_save1);
    }
    return zero_handles();
}

static int C_fcall
redir_io()
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    zero_handles();

    C_save0 = GetStdHandle(STD_INPUT_HANDLE);
    C_save1 = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!CreatePipe(&C_rd0, &C_wr0, &sa, 0)
	    || !SetStdHandle(STD_INPUT_HANDLE, C_rd0)
	    || !DuplicateHandle(GetCurrentProcess(), C_wr0, GetCurrentProcess(),
		&C_wr0_, 0, FALSE, DUPLICATE_SAME_ACCESS)
	    || !CreatePipe(&C_rd1, &C_wr1, &sa, 0)
	    || !SetStdHandle(STD_OUTPUT_HANDLE, C_wr1)
	    || !DuplicateHandle(GetCurrentProcess(), C_rd1, GetCurrentProcess(),
		&C_rd1_, 0, FALSE, DUPLICATE_SAME_ACCESS))
    {
	set_last_errno();
	close_handles();
	return 0;
    }

    CloseHandle(C_wr0);
    C_wr0 = INVALID_HANDLE_VALUE;
    CloseHandle(C_rd1);
    C_rd1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
run_process(char *cmdline)
{
    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);

    C_wr0_ = C_rd1_ = INVALID_HANDLE_VALUE; /* these handles are saved */

    if (CreateProcess(NULL, cmdline, NULL, NULL, TRUE, 0, NULL,
		      NULL, &si, &pi))
    {
	CloseHandle(pi.hThread);

	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	C_save0 = C_save1 = INVALID_HANDLE_VALUE;

	CloseHandle(C_rd0);
	CloseHandle(C_wr1);
	C_rd0 = C_wr1 = INVALID_HANDLE_VALUE;
	return (int)pi.hProcess;
    }
    else
	return set_last_errno();
}

static int C_fcall
pipe_write(int hpipe, void* buf, int count)
{
    DWORD done = 0;
    if (WriteFile((HANDLE)hpipe, buf, count, &done, NULL))
	return 1;
    else
	return set_last_errno();
}

static int C_fcall
pipe_read(int hpipe)
{
    DWORD done = 0;
    /* TODO:
    if (!pipe_ready(hpipe))
	go_to_sleep;
    */
    if (ReadFile((HANDLE)hpipe, &C_rdbuf, 1, &done, NULL))
    {
	if (done > 0) /* not EOF yet */
	    return 1;
	else
	    return -1;
    }
    return set_last_errno();
}

static int C_fcall
pipe_ready(int hpipe)
{
    DWORD avail = 0;
    if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL) && avail)
	return 1;
    else
    {
	Sleep(0); /* give pipe a chance */
	if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL))
	    return (avail > 0);
	else
	    return 0;
    }
}

#define C_zero_handles() C_fix(zero_handles())
#define C_close_handles() C_fix(close_handles())
#define C_redir_io() (redir_io() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_run_process(cmdline) C_fix(run_process(C_c_string(cmdline)))
#define C_pipe_write(h, b, n) (pipe_write(C_unfix(h), C_c_string(b), C_unfix(n)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_pipe_read(h) C_fix(pipe_read(C_unfix(h)))
#define C_pipe_ready(h) (pipe_ready(C_unfix(h)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define close_handle(h) CloseHandle((HANDLE)h)

static int C_fcall
process_wait(int h, int t)
{
    if (WaitForSingleObject((HANDLE)h, (t ? 0 : INFINITE)) == WAIT_OBJECT_0)
    {
	DWORD ret;
	if (GetExitCodeProcess((HANDLE)h, &ret))
	{
	    CloseHandle((HANDLE)h);
	    C_exstatus = ret;
	    return 1;
	}
    }
    return set_last_errno();
}

#define C_process_wait(p, t) (process_wait(C_unfix(p), C_truep(t)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sleep(t) (Sleep(C_unfix(t) * 1000), C_SCHEME_UNDEFINED)

static int C_fcall
get_hostname()
{
    /* Do we already have hostname? */
    if (strlen(C_hostname))
    {
	return 1;
    }
    else
    {
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(1, 1), &wsa) == 0)
	{
	    int nok = gethostname(C_hostname, sizeof(C_hostname));
	    WSACleanup();
	    return !nok;
	}
	return 0;
    }
}

static int C_fcall
sysinfo()
{
    /* Do we need to build the sysinfo? */
    if (!strlen(C_osrel))
    {
	OSVERSIONINFO ovf;
	ZeroMemory(&ovf, sizeof(ovf));
	ovf.dwOSVersionInfoSize = sizeof(ovf);
	if (get_hostname() && GetVersionEx(&ovf))
	{
	    SYSTEM_INFO si;
	    _snprintf(C_osver, sizeof(C_osver) - 1, "%d.%d.%d",
			ovf.dwMajorVersion, ovf.dwMinorVersion, ovf.dwBuildNumber);
	    strncpy(C_osrel, "Win", sizeof(C_osrel) - 1);
	    switch (ovf.dwPlatformId)
	    {
	    case VER_PLATFORM_WIN32s:
		strncpy(C_osrel, "Win32s", sizeof(C_osrel) - 1);
		break;
	    case VER_PLATFORM_WIN32_WINDOWS:
		if (ovf.dwMajorVersion == 4)
		{
		    if (ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win95", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 10)
			strncpy(C_osrel, "Win98", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 90)
			strncpy(C_osrel, "WinMe", sizeof(C_osrel) - 1);
		}
		break;
	    case VER_PLATFORM_WIN32_NT:
		C_isNT = 1;
		if (ovf.dwMajorVersion == 6)
		    strncpy(C_osrel, "WinVista", sizeof(C_osrel) - 1);
		else if (ovf.dwMajorVersion == 5)
		{
		    if (ovf.dwMinorVersion == 2)
			strncpy(C_osrel, "WinServer2003", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 1)
			strncpy(C_osrel, "WinXP", sizeof(C_osrel) - 1);
		    else if ( ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win2000", sizeof(C_osrel) - 1);
		}
		else if (ovf.dwMajorVersion <= 4)
		   strncpy(C_osrel, "WinNT", sizeof(C_osrel) - 1);
		break;
	    }
	    GetSystemInfo(&si);
	    strncpy(C_processor, "Unknown", sizeof(C_processor) - 1);
	    switch (si.wProcessorArchitecture)
	    {
	    case PROCESSOR_ARCHITECTURE_INTEL:
		strncpy(C_processor, "x86", sizeof(C_processor) - 1);
		break;
#	    ifdef PROCESSOR_ARCHITECTURE_IA64
	    case PROCESSOR_ARCHITECTURE_IA64:
		strncpy(C_processor, "IA64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_AMD64
	    case PROCESSOR_ARCHITECTURE_AMD64:
		strncpy(C_processor, "x64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_IA32_ON_WIN64
	    case PROCESSOR_ARCHITECTURE_IA32_ON_WIN64:
		strncpy(C_processor, "WOW64", sizeof(C_processor) - 1);
		break;
#	    endif
	    }
	}
	else
	    return set_last_errno();
    }
    return 1;
}

static int C_fcall
get_shlcmd()
{
    /* Do we need to build the shell command pathname? */
    if (!strlen(C_shlcmd))
    {
	if (sysinfo())
	{
	    char *cmdnam = C_isNT ? "\\cmd.exe" : "\\command.com";
	    UINT len = GetSystemDirectory(C_shlcmd, sizeof(C_shlcmd) - strlen(cmdnam));
	    if (len)
		strcpy(C_shlcmd + len, cmdnam);
	    else
		return set_last_errno();
	}
	else
	    return 0;
    }
    return 1;
}

#define C_get_hostname() (get_hostname() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sysinfo() (sysinfo() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_get_shlcmd() (get_shlcmd() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* GetUserName */

static int C_fcall
get_user_name()
{
    if (!strlen(C_username))
    {
	DWORD bufCharCount = sizeof(C_username) / sizeof(C_username[0]);
	if (!GetUserName(C_username, &bufCharCount))
	    return set_last_errno();
    }
    return 1;
}

#define C_get_user_name() (get_user_name() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* User Information */

#if 0
static int C_fcall
get_netinfo()
{
    HINSTANCE hNet = 0,
	      hLoc = 0;

    if (isNT)
	hNet = LoadLibrary("netapi32.dll");
    else
    {
	hLoc = LoadLibrary("rlocal32.dll");
	hNet = LoadLibrary("radmin32.dll");
	//hNet = LoadLibrary("netapi.dll");
    }

    if (!hNet)
	return 0;

    
}
#endif

/*
    Spawn a process directly.
    Params:
    app		Command to execute.
    cmdlin	Command line (arguments).
    env		Environment for the new process (may be NULL).
    handle, stdin, stdout, stderr
		Spawned process info are returned in integers.
		When spawned process shares standard io stream with the parent
		process the respective value in handle, stdin, stdout, stderr
		is -1.
    params	A bitmask controling operation.
		Bit 1: Child & parent share standard input if this bit is set.
		Bit 2: Share standard output if bit is set.
		Bit 3: Share standard error if bit is set.

    Returns: zero return value indicates failure.
*/
static int C_fcall
C_process(const char * app, const char * cmdlin, const char ** env,
	  int * phandle,
	  int * pstdin_fd, int * pstdout_fd, int * pstderr_fd,
	  int params)
{
    int i;
    int success = TRUE;
    const int f_share_io[3] = { params & 1, params & 2, params & 4};
    int io_fds[3] = { -1, -1, -1 };
    HANDLE
	child_io_handles[3] = { NULL, NULL, NULL },
	standard_io_handles[3] = {
	    GetStdHandle(STD_INPUT_HANDLE),
	    GetStdHandle(STD_OUTPUT_HANDLE),
	    GetStdHandle(STD_ERROR_HANDLE)};
    const char modes[3] = "rww";
    HANDLE cur_process = GetCurrentProcess(), child_process = NULL;
    void* envblk = NULL;

    /****** create io handles & fds ***/

    for (i=0; i<3 && success; ++i)
    {
	if (f_share_io[i])
	{
	    success = DuplicateHandle(
		cur_process, standard_io_handles[i],
		cur_process, &child_io_handles[i],
		0, FALSE, DUPLICATE_SAME_ACCESS);
	}
	else
	{
	    HANDLE a, b;
	    success = CreatePipe(&a,&b,NULL,0);
	    if(success)
	    {
		HANDLE parent_end;
		if (modes[i]=='r') { child_io_handles[i]=a; parent_end=b; }
		else		   { parent_end=a; child_io_handles[i]=b; }
		success = (io_fds[i] = _open_osfhandle((long)parent_end,0)) >= 0;
	    }
	}
    }

    /****** make handles inheritable */

    for (i=0; i<3 && success; ++i)
	success = SetHandleInformation(child_io_handles[i], HANDLE_FLAG_INHERIT, -1);

#if 0 /* Requires a sorted list by key! */
    /****** create environment block if necessary ****/

    if (env && success)
    {
	char** p;
	int len = 0;

	for (p = env; *p; ++p) len += strlen(*p) + 1;

	if (envblk = C_malloc(len + 1))
	{
	    char* pb = (char*)envblk;
	    for (p = env; *p; ++p)
	    {
		strcpy(pb, *p);
		pb += strlen(*p) + 1;
	    }
	    *pb = '\0';
	}
	else
	    success = FALSE;
    }
#endif

    /****** finally spawn process ****/

    if (success)
    {
	PROCESS_INFORMATION pi;
	STARTUPINFO si;

	ZeroMemory(&pi,sizeof pi);
	ZeroMemory(&si,sizeof si);
	si.cb = sizeof si;
	si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdInput = child_io_handles[0];
	si.hStdOutput = child_io_handles[1];
	si.hStdError = child_io_handles[2];

	/* FIXME passing 'app' param causes failure & possible stack corruption */
	success = CreateProcess(
	    NULL, (char*)cmdlin, NULL, NULL, TRUE, 0, envblk, NULL, &si, &pi);

	if (success)
	{
	    child_process=pi.hProcess;
	    CloseHandle(pi.hThread);
	}
	else
	    set_last_errno();
    }
    else
	set_last_errno();

    /****** cleanup & return *********/

    /* parent must close child end */
    for (i=0; i<3; ++i) CloseHandle(child_io_handles[i]);

    if (success)
    {
	*phandle = (int)child_process;
	*pstdin_fd = io_fds[0];
	*pstdout_fd = io_fds[1];
	*pstderr_fd = io_fds[2];
    }
    else
    {
	for (i=0; i<3; ++i) _close(io_fds[i]);
    }

    return success;
}

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[363];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,38),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,55,32,108,111,99,56,32,109,115,103,57,32,46,32,97,114,103,115,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,49,51,32,102,108,97,103,115,49,52,32,46,32,109,111,100,101,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,99,108,111,115,101,32,102,100,50,51,41,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,114,101,97,100,32,102,100,50,55,32,115,105,122,101,50,56,32,46,32,98,117,102,102,101,114,50,57,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,119,114,105,116,101,32,102,100,51,55,32,98,117,102,102,101,114,51,56,32,46,32,115,105,122,101,51,57,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,25),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,52,56,41,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,19),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,53,53,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,115,116,97,116,32,102,53,57,32,46,32,103,53,56,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,15),40,102,105,108,101,45,115,105,122,101,32,102,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,28),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,54,56,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,55,48,41,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,111,119,110,101,114,32,102,55,52,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,23),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,55,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,24),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,56,49,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,112,111,115,105,116,105,111,110,32,112,111,114,116,56,51,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,44),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,56,55,32,112,111,115,56,56,32,46,32,119,104,101,110,99,101,56,57,41,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,25),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,57,53,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,25),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,57,56,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,49,48,49,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,49,49,49,32,115,112,101,99,49,49,55,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,49,49,56,41,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,49,49,52,32,37,115,112,101,99,49,48,57,49,51,56,41,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,49,49,51,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,32,46,32,103,49,48,55,49,48,56,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,49,52,52,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,103,49,52,56,49,52,57,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,49,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,26),40,99,104,101,99,107,32,99,109,100,49,54,49,32,105,110,112,49,54,50,32,114,49,54,51,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,49,54,55,32,46,32,109,49,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,49,55,51,32,46,32,109,49,55,52,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,49,55,57,41,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,7),40,97,49,57,57,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,20),40,97,50,48,48,50,32,46,32,114,101,115,117,108,116,115,49,57,55,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,49,57,51,32,112,114,111,99,49,57,52,32,46,32,109,111,100,101,49,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,7),40,97,50,48,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,20),40,97,50,48,50,54,32,46,32,114,101,115,117,108,116,115,50,48,51,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,49,57,57,32,112,114,111,99,50,48,48,32,46,32,109,111,100,101,50,48,49,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,20),40,97,50,48,52,53,32,46,32,114,101,115,117,108,116,115,50,49,48,41,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,50,48,53,32,116,104,117,110,107,50,48,54,32,46,32,109,111,100,101,50,48,55,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,20),40,97,50,48,54,53,32,46,32,114,101,115,117,108,116,115,50,49,57,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,50,49,52,32,116,104,117,110,107,50,49,53,32,46,32,109,111,100,101,50,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,23),40,99,114,101,97,116,101,45,112,105,112,101,32,46,32,103,50,50,54,50,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,50,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,36),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,50,51,55,32,112,114,111,99,50,51,56,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,50,52,49,32,115,116,97,116,101,50,52,50,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,32),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,50,52,55,32,109,50,52,56,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,50,53,51,32,97,99,99,50,53,52,32,108,111,99,50,53,53,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,50,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,50,54,48,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,50,54,49,41,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,18),40,109,111,100,101,32,105,110,112,50,54,55,32,109,50,54,56,41,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,25),40,99,104,101,99,107,32,102,100,50,55,50,32,105,110,112,50,55,51,32,114,50,55,52,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,50,55,56,32,46,32,109,50,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,50,56,49,32,46,32,109,50,56,50,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,22),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,50,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,34),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,50,57,50,32,46,32,110,101,119,50,57,51,41,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,22),40,115,101,116,101,110,118,32,118,97,114,51,48,48,32,118,97,108,51,48,49,41,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,17),40,117,110,115,101,116,101,110,118,32,118,97,114,51,48,53,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,11),40,115,99,97,110,32,106,51,49,57,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,51,49,54,41,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,21),40,99,117,114,114,101,110,116,45,101,110,118,105,114,111,110,109,101,110,116,41,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,29),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,51,50,50,41,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,27),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,51,50,52,41,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,25),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,51,51,50,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,20),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,51,52,49,41,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,27),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,51,52,54,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,17),40,95,101,120,105,116,32,46,32,99,111,100,101,51,53,55,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,51,53,56,32,109,111,100,101,51,53,57,32,46,32,115,105,122,101,51,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,7),40,97,50,55,56,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,102,110,115,51,57,51,41,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,37),40,97,50,55,57,49,32,100,105,114,51,55,56,51,56,49,32,102,105,108,51,55,57,51,56,50,32,101,120,116,51,56,48,51,56,51,41,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,20),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,51,55,54,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,17),40,103,108,111,98,32,46,32,112,97,116,104,115,51,55,52,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,52,49,49,41,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,21),40,110,101,101,100,115,45,113,117,111,116,105,110,103,63,32,115,52,48,56,41,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,105,108,115,116,52,49,52,32,111,108,115,116,52,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,35),40,36,113,117,111,116,101,45,97,114,103,115,45,108,105,115,116,32,108,115,116,52,48,53,32,101,120,97,99,116,102,52,48,54,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,32),40,115,101,116,97,114,103,32,97,52,50,52,52,50,56,32,97,52,50,51,52,50,57,32,97,52,50,50,52,51,48,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,32),40,115,101,116,101,110,118,32,97,52,51,52,52,51,56,32,97,52,51,51,52,51,57,32,97,52,51,50,52,52,48,41};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,17),40,100,111,52,52,54,32,108,52,52,56,32,105,52,52,57,41,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,57),40,98,117,105,108,100,45,101,120,101,99,45,97,114,103,118,101,99,32,108,111,99,52,52,50,32,108,115,116,52,52,51,32,97,114,103,118,101,99,45,115,101,116,116,101,114,52,52,52,32,105,100,120,52,52,53,41,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,62),40,36,101,120,101,99,45,115,101,116,117,112,32,108,111,99,52,53,53,32,102,105,108,101,110,97,109,101,52,53,54,32,97,114,103,108,115,116,52,53,55,32,101,110,118,108,115,116,52,53,56,32,101,120,97,99,116,102,52,53,57,41,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,49),40,36,101,120,101,99,45,116,101,97,114,100,111,119,110,32,108,111,99,52,54,54,32,109,115,103,52,54,55,32,102,105,108,101,110,97,109,101,52,54,56,32,114,101,115,52,54,57,41,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,39),40,98,111,100,121,52,55,57,32,97,114,103,108,115,116,52,56,54,32,101,110,118,108,115,116,52,56,55,32,101,120,97,99,116,102,52,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,52,56,51,32,37,97,114,103,108,115,116,52,55,54,52,57,49,32,37,101,110,118,108,115,116,52,55,55,52,57,50,41,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,101,110,118,108,115,116,52,56,50,32,37,97,114,103,108,115,116,52,55,54,52,57,52,41,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,97,114,103,108,115,116,52,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,39),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,52,55,52,32,46,32,103,52,55,51,52,55,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,39),40,98,111,100,121,53,48,57,32,97,114,103,108,115,116,53,49,54,32,101,110,118,108,115,116,53,49,55,32,101,120,97,99,116,102,53,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,101,120,97,99,116,102,53,49,51,32,37,97,114,103,108,115,116,53,48,54,53,50,49,32,37,101,110,118,108,115,116,53,48,55,53,50,50,41,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,101,110,118,108,115,116,53,49,50,32,37,97,114,103,108,115,116,53,48,54,53,50,52,41,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,97,114,103,108,115,116,53,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,45),40,112,114,111,99,101,115,115,45,115,112,97,119,110,32,109,111,100,101,53,48,51,32,102,105,108,101,110,97,109,101,53,48,52,32,46,32,103,53,48,50,53,48,53,41,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,53,51,55,41,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,28),40,112,114,111,99,101,115,115,45,114,117,110,32,102,53,52,48,32,46,32,97,114,103,115,53,52,49,41,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,22),40,99,108,111,115,101,45,104,97,110,100,108,101,32,97,53,52,51,53,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,86),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,53,56,49,32,99,109,100,53,56,50,32,97,114,103,115,53,56,51,32,101,110,118,53,56,52,32,115,116,100,111,117,116,102,53,56,53,32,115,116,100,105,110,102,53,56,54,32,115,116,100,101,114,114,102,53,56,55,32,46,32,103,53,56,48,53,56,56,41,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,15),40,97,51,53,49,57,32,103,54,50,56,54,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,18),40,99,104,107,115,116,114,108,115,116,32,108,115,116,54,50,55,41,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,7),40,97,51,53,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,34),40,97,51,53,52,51,32,105,110,54,51,51,32,111,117,116,54,51,52,32,112,105,100,54,51,53,32,101,114,114,54,51,54,41,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,57),40,37,112,114,111,99,101,115,115,32,108,111,99,54,50,48,32,101,114,114,63,54,50,49,32,99,109,100,54,50,50,32,97,114,103,115,54,50,51,32,101,110,118,54,50,52,32,101,120,97,99,116,102,54,50,53,41,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,54,52,54,32,97,114,103,115,54,53,51,32,101,110,118,54,53,52,32,101,120,97,99,116,102,54,53,53,41,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,38),40,100,101,102,45,101,120,97,99,116,102,54,53,48,32,37,97,114,103,115,54,52,51,54,53,55,32,37,101,110,118,54,52,52,54,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,24),40,100,101,102,45,101,110,118,54,52,57,32,37,97,114,103,115,54,52,51,54,54,48,41};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,97,114,103,115,54,52,56,41,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,26),40,112,114,111,99,101,115,115,32,99,109,100,54,52,49,32,46,32,103,54,52,48,54,52,50,41,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,54,55,52,32,97,114,103,115,54,56,49,32,101,110,118,54,56,50,32,101,120,97,99,116,102,54,56,51,41,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,38),40,100,101,102,45,101,120,97,99,116,102,54,55,56,32,37,97,114,103,115,54,55,49,54,56,53,32,37,101,110,118,54,55,50,54,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,24),40,100,101,102,45,101,110,118,54,55,55,32,37,97,114,103,115,54,55,49,54,56,56,41};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,97,114,103,115,54,55,54,41,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,27),40,112,114,111,99,101,115,115,42,32,99,109,100,54,54,57,32,46,32,103,54,54,56,54,55,48,41,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,54,57,55,32,110,111,104,97,110,103,54,57,56,41,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,7),40,97,51,55,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,33),40,97,51,55,54,57,32,101,112,105,100,55,48,54,32,101,110,111,114,109,55,48,55,32,101,99,111,100,101,55,48,56,41,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,54,57,57,32,46,32,97,114,103,115,55,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,12),40,115,108,101,101,112,32,116,55,49,49,41,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,13),40,102,95,51,57,57,48,32,120,55,52,48,41,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,7),40,97,51,57,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,7),40,97,51,57,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,7),40,97,51,57,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,102,115,55,52,50,32,114,55,52,51,41,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,15),40,102,95,52,48,48,54,32,46,32,95,55,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,15),40,102,95,51,57,57,56,32,46,32,95,55,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,55,50,53,32,97,99,116,105,111,110,55,51,50,32,105,100,55,51,51,32,108,105,109,105,116,55,51,52,41,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,38),40,100,101,102,45,108,105,109,105,116,55,50,57,32,37,97,99,116,105,111,110,55,50,50,55,53,55,32,37,105,100,55,50,51,55,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,105,100,55,50,56,32,37,97,99,116,105,111,110,55,50,50,55,54,48,41,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,17),40,97,52,48,50,54,32,120,55,54,50,32,121,55,54,51,41,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,97,99,116,105,111,110,55,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,48),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,55,49,57,32,112,114,101,100,55,50,48,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,55,50,49,41};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,46,32,95,55,55,48,41,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,20),40,99,114,101,97,116,101,45,102,105,102,111,32,46,32,95,55,55,50,41,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,23),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,32,46,32,95,55,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,29),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,46,32,95,55,55,52,41,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,35),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,103,114,111,117,112,45,105,100,32,46,32,95,55,55,53,41,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,34),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,105,100,32,46,32,95,55,55,54,41,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,36),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,32,46,32,95,55,55,55,41,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,25),40,99,117,114,114,101,110,116,45,103,114,111,117,112,45,105,100,32,46,32,95,55,55,56,41,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,24),40,99,117,114,114,101,110,116,45,117,115,101,114,45,105,100,32,46,32,95,55,55,57,41};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,27),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,46,32,95,55,56,48,41,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,108,105,110,107,32,46,32,95,55,56,49,41,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,108,111,99,107,32,46,32,95,55,56,50,41,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,27),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,46,32,95,55,56,51,41,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,20),40,102,105,108,101,45,115,101,108,101,99,116,32,46,32,95,55,56,52,41,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,46,32,95,55,56,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,46,32,95,55,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,20),40,102,105,108,101,45,117,110,108,111,99,107,32,46,32,95,55,56,55,41,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,19),40,103,101,116,45,103,114,111,117,112,115,32,46,32,95,55,56,56,41,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,26),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,46,32,95,55,56,57,41,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,26),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,46,32,95,55,57,48,41,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,35),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,46,32,95,55,57,49,41,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,26),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,32,46,32,95,55,57,50,41,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,21),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,95,55,57,51,41,0,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,25),40,112,114,111,99,101,115,115,45,103,114,111,117,112,45,105,100,32,46,32,95,55,57,52,41,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,23),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,46,32,95,55,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,27),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,46,32,95,55,57,54,41,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,19),40,115,101,116,45,97,108,97,114,109,33,32,46,32,95,55,57,55,41,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,103,114,111,117,112,45,105,100,33,32,46,32,95,55,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,20),40,115,101,116,45,103,114,111,117,112,115,33,32,46,32,95,55,57,57,41,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,30),40,115,101,116,45,112,114,111,99,101,115,115,45,103,114,111,117,112,45,105,100,33,32,46,32,95,56,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,28),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,46,32,95,56,48,49,41,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,25),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,46,32,95,56,48,50,41,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,21),40,115,101,116,45,117,115,101,114,45,105,100,33,32,46,32,95,56,48,51,41,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,20),40,115,105,103,110,97,108,45,109,97,115,107,32,46,32,95,56,48,52,41,0,0,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,21),40,115,105,103,110,97,108,45,109,97,115,107,33,32,46,32,95,56,48,53,41,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,46,32,95,56,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,46,32,95,56,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,22),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,46,32,95,56,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,23),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,46,32,95,56,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,22),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,46,32,95,56,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,31),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,46,32,95,56,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,25),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,46,32,95,56,49,50,41,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,26),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,46,32,95,56,49,51,41,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,12),40,102,105,102,111,63,32,95,56,49,52,41,0,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,26),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,95,56,49,53,41,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0};


/* from k3358 */
static C_word C_fcall stub556(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7) C_regparm;
C_regparm static C_word C_fcall stub556(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
int *t3=(int *)C_c_pointer_or_null(C_a3);
int *t4=(int *)C_c_pointer_or_null(C_a4);
int *t5=(int *)C_c_pointer_or_null(C_a5);
int *t6=(int *)C_c_pointer_or_null(C_a6);
int t7=(int )C_unfix(C_a7);
C_r=C_mk_bool(C_process(t0,t1,t2,t3,t4,t5,t6,t7));
return C_r;}

/* from close-handle in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static C_word C_fcall stub544(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub544(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_truep(C_a0);
C_r=C_fix((C_word)close_handle(t0));
return C_r;}

/* from current-process-id in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static C_word C_fcall stub532(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub532(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from k2987 */
static C_word C_fcall stub435(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub435(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from k2970 */
static C_word C_fcall stub425(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub425(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k2687 */
static C_word C_fcall stub354(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub354(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub349(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub349(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char *z = (daylight ? _tzname[1] : _tzname[0]);return(z);
C_ret:
#undef return

return C_r;}

/* from asctime */
static C_word C_fcall stub337(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub337(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k2580 */
static C_word C_fcall stub328(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub328(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k2487 */
static C_word C_fcall stub311(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub311(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k1079 */
static C_word C_fcall stub3(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1058)
static void C_ccall f_1058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1061)
static void C_ccall f_1061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1070)
static void C_ccall f_1070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4352)
static void C_ccall f_4352(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4318)
static void C_ccall f_4318(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4300)
static void C_ccall f_4300(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4282)
static void C_ccall f_4282(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4276)
static void C_ccall f_4276(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4258)
static void C_ccall f_4258(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4222)
static void C_ccall f_4222(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4210)
static void C_ccall f_4210(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4192)
static void C_ccall f_4192(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4138)
static void C_ccall f_4138(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4126)
static void C_ccall f_4126(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4120)
static void C_ccall f_4120(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4102)
static void C_ccall f_4102(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4021)
static void C_fcall f_4021(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4016)
static void C_fcall f_4016(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4011)
static void C_fcall f_4011(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3866)
static void C_fcall f_3866(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3998)
static void C_ccall f_3998(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3873)
static void C_fcall f_3873(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3885)
static void C_fcall f_3885(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3966)
static void C_ccall f_3966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3953)
static void C_ccall f_3953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3844)
static void C_ccall f_3844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3651)
static void C_ccall f_3651(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3651)
static void C_ccall f_3651r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3668)
static void C_fcall f_3668(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3663)
static void C_fcall f_3663(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3658)
static void C_fcall f_3658(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3653)
static void C_fcall f_3653(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3588)
static void C_fcall f_3588(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3583)
static void C_fcall f_3583(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3578)
static void C_fcall f_3578(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3573)
static void C_fcall f_3573(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3509)
static void C_fcall f_3509(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3533)
static void C_ccall f_3533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_fcall f_3511(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3390)
static void C_ccall f_3390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...) C_noret;
C_noret_decl(f_3390)
static void C_ccall f_3390r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t10) C_noret;
C_noret_decl(f_3394)
static void C_ccall f_3394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3397)
static void C_ccall f_3397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3461)
static void C_ccall f_3461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3289)
static void C_ccall f_3289(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3202)
static void C_fcall f_3202(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3197)
static void C_fcall f_3197(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3192)
static void C_fcall f_3192(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3180)
static void C_fcall f_3180(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3115)
static void C_fcall f_3115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3110)
static void C_fcall f_3110(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3105)
static void C_fcall f_3105(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3093)
static void C_fcall f_3093(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3076)
static void C_fcall f_3076(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3043)
static void C_fcall f_3043(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_fcall f_2993(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3005)
static void C_fcall f_3005(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2880)
static void C_fcall f_2880(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2923)
static void C_fcall f_2923(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2885)
static void C_fcall f_2885(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_fcall f_2894(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2771)
static void C_fcall f_2771(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2811)
static void C_fcall f_2811(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_fcall f_2496(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_fcall f_2508(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2468)
static void C_ccall f_2468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2430)
static void C_fcall f_2430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static void C_fcall f_2342(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_fcall f_2305(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2260)
static void C_fcall f_2260(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2152)
static void C_ccall f_2152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1969)
static void C_ccall f_1969(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_fcall f_1879(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_fcall f_1873(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static C_word C_fcall f_1861(C_word t0);
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1813)
static void C_ccall f_1813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_ccall f_1809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1736)
static void C_fcall f_1736(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1731)
static void C_fcall f_1731(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1630)
static void C_fcall f_1630(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1640)
static void C_ccall f_1640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1647)
static void C_ccall f_1647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1664)
static void C_fcall f_1664(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1674)
static void C_ccall f_1674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1686)
static void C_fcall f_1686(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1626)
static void C_ccall f_1626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_ccall f_1547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1572)
static void C_ccall f_1572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1560)
static void C_ccall f_1560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1486)
static void C_ccall f_1486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1486)
static void C_ccall f_1486r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1514)
static void C_ccall f_1514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1424)
static void C_ccall f_1424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static void C_ccall f_1411(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1391)
static void C_ccall f_1391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1381)
static void C_ccall f_1381(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1354)
static void C_ccall f_1354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_fcall f_1312(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1341)
static void C_ccall f_1341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1316)
static void C_ccall f_1316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1274)
static void C_ccall f_1274(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1284)
static void C_ccall f_1284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1304)
static void C_ccall f_1304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1287)
static void C_ccall f_1287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1232)
static void C_ccall f_1232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1232)
static void C_ccall f_1232r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1254)
static void C_ccall f_1254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1248)
static void C_ccall f_1248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1182)
static void C_ccall f_1182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1145)
static void C_ccall f_1145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1148)
static void C_ccall f_1148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1082)
static void C_ccall f_1082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1082)
static void C_ccall f_1082r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1093)
static void C_ccall f_1093(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_4021)
static void C_fcall trf_4021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4021(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4021(t0,t1);}

C_noret_decl(trf_4016)
static void C_fcall trf_4016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4016(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4016(t0,t1,t2);}

C_noret_decl(trf_4011)
static void C_fcall trf_4011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4011(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4011(t0,t1,t2,t3);}

C_noret_decl(trf_3866)
static void C_fcall trf_3866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3866(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3866(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3873)
static void C_fcall trf_3873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3873(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3873(t0,t1);}

C_noret_decl(trf_3885)
static void C_fcall trf_3885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3885(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3885(t0,t1,t2,t3);}

C_noret_decl(trf_3668)
static void C_fcall trf_3668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3668(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3668(t0,t1);}

C_noret_decl(trf_3663)
static void C_fcall trf_3663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3663(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3663(t0,t1,t2);}

C_noret_decl(trf_3658)
static void C_fcall trf_3658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3658(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3658(t0,t1,t2,t3);}

C_noret_decl(trf_3653)
static void C_fcall trf_3653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3653(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3653(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3588)
static void C_fcall trf_3588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3588(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3588(t0,t1);}

C_noret_decl(trf_3583)
static void C_fcall trf_3583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3583(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3583(t0,t1,t2);}

C_noret_decl(trf_3578)
static void C_fcall trf_3578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3578(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3578(t0,t1,t2,t3);}

C_noret_decl(trf_3573)
static void C_fcall trf_3573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3573(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3573(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3509)
static void C_fcall trf_3509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3509(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3509(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3511)
static void C_fcall trf_3511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3511(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3511(t0,t1,t2);}

C_noret_decl(trf_3202)
static void C_fcall trf_3202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3202(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3202(t0,t1);}

C_noret_decl(trf_3197)
static void C_fcall trf_3197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3197(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3197(t0,t1,t2);}

C_noret_decl(trf_3192)
static void C_fcall trf_3192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3192(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3192(t0,t1,t2,t3);}

C_noret_decl(trf_3180)
static void C_fcall trf_3180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3180(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3180(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3115)
static void C_fcall trf_3115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3115(t0,t1);}

C_noret_decl(trf_3110)
static void C_fcall trf_3110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3110(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3110(t0,t1,t2);}

C_noret_decl(trf_3105)
static void C_fcall trf_3105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3105(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3105(t0,t1,t2,t3);}

C_noret_decl(trf_3093)
static void C_fcall trf_3093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3093(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3093(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3076)
static void C_fcall trf_3076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3076(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3076(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3043)
static void C_fcall trf_3043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3043(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3043(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2993)
static void C_fcall trf_2993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2993(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2993(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3005)
static void C_fcall trf_3005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3005(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3005(t0,t1,t2,t3);}

C_noret_decl(trf_2880)
static void C_fcall trf_2880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2880(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2880(t0,t1,t2,t3);}

C_noret_decl(trf_2923)
static void C_fcall trf_2923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2923(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2923(t0,t1,t2,t3);}

C_noret_decl(trf_2885)
static void C_fcall trf_2885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2885(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2885(t0,t1,t2);}

C_noret_decl(trf_2894)
static void C_fcall trf_2894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2894(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2894(t0,t1,t2);}

C_noret_decl(trf_2771)
static void C_fcall trf_2771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2771(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2771(t0,t1,t2);}

C_noret_decl(trf_2811)
static void C_fcall trf_2811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2811(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2811(t0,t1,t2);}

C_noret_decl(trf_2496)
static void C_fcall trf_2496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2496(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2496(t0,t1,t2);}

C_noret_decl(trf_2508)
static void C_fcall trf_2508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2508(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2508(t0,t1,t2);}

C_noret_decl(trf_2430)
static void C_fcall trf_2430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2430(t0,t1);}

C_noret_decl(trf_2342)
static void C_fcall trf_2342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2342(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2342(t0,t1,t2,t3);}

C_noret_decl(trf_2305)
static void C_fcall trf_2305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2305(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2305(t0,t1,t2);}

C_noret_decl(trf_2260)
static void C_fcall trf_2260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2260(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2260(t0,t1,t2,t3);}

C_noret_decl(trf_1879)
static void C_fcall trf_1879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1879(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1879(t0,t1,t2,t3);}

C_noret_decl(trf_1873)
static void C_fcall trf_1873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1873(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1873(t0,t1);}

C_noret_decl(trf_1736)
static void C_fcall trf_1736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1736(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1736(t0,t1);}

C_noret_decl(trf_1731)
static void C_fcall trf_1731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1731(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1731(t0,t1,t2);}

C_noret_decl(trf_1630)
static void C_fcall trf_1630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1630(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1630(t0,t1,t2,t3);}

C_noret_decl(trf_1664)
static void C_fcall trf_1664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1664(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1664(t0,t1);}

C_noret_decl(trf_1686)
static void C_fcall trf_1686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1686(t0,t1);}

C_noret_decl(trf_1312)
static void C_fcall trf_1312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1312(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1312(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr9r)
static void C_fcall tr9r(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9r(C_proc9 k){
int n;
C_word *a,t9;
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
n=C_rest_count(0);
a=C_alloc(n*3);
t9=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2910)){
C_save(t1);
C_rereclaim2(2910*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,363);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000/this function is not available on this platform");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[4]=C_h_intern(&lf[4],13,"string-append");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[8]=C_h_intern(&lf[8],17,"\003syspeek-c-string");
lf[9]=C_h_intern(&lf[9],16,"\003sysupdate-errno");
lf[10]=C_h_intern(&lf[10],15,"\003sysposix-error");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"open/rdonly");
lf[13]=C_h_intern(&lf[13],11,"open/wronly");
lf[14]=C_h_intern(&lf[14],9,"open/rdwr");
lf[15]=C_h_intern(&lf[15],9,"open/read");
lf[16]=C_h_intern(&lf[16],10,"open/write");
lf[17]=C_h_intern(&lf[17],10,"open/creat");
lf[18]=C_h_intern(&lf[18],11,"open/append");
lf[19]=C_h_intern(&lf[19],9,"open/excl");
lf[20]=C_h_intern(&lf[20],10,"open/trunc");
lf[21]=C_h_intern(&lf[21],11,"open/binary");
lf[22]=C_h_intern(&lf[22],9,"open/text");
lf[23]=C_h_intern(&lf[23],14,"open/noinherit");
lf[24]=C_h_intern(&lf[24],10,"perm/irusr");
lf[25]=C_h_intern(&lf[25],10,"perm/iwusr");
lf[26]=C_h_intern(&lf[26],10,"perm/ixusr");
lf[27]=C_h_intern(&lf[27],10,"perm/irgrp");
lf[28]=C_h_intern(&lf[28],10,"perm/iwgrp");
lf[29]=C_h_intern(&lf[29],10,"perm/ixgrp");
lf[30]=C_h_intern(&lf[30],10,"perm/iroth");
lf[31]=C_h_intern(&lf[31],10,"perm/iwoth");
lf[32]=C_h_intern(&lf[32],10,"perm/ixoth");
lf[33]=C_h_intern(&lf[33],10,"perm/irwxu");
lf[34]=C_h_intern(&lf[34],10,"perm/irwxg");
lf[35]=C_h_intern(&lf[35],10,"perm/irwxo");
lf[36]=C_h_intern(&lf[36],9,"file-open");
lf[37]=C_h_intern(&lf[37],11,"\000file-error");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[39]=C_h_intern(&lf[39],17,"\003sysmake-c-string");
lf[40]=C_h_intern(&lf[40],20,"\003sysexpand-home-path");
lf[41]=C_h_intern(&lf[41],10,"file-close");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[43]=C_h_intern(&lf[43],11,"make-string");
lf[44]=C_h_intern(&lf[44],9,"file-read");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[46]=C_h_intern(&lf[46],11,"\000type-error");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[48]=C_h_intern(&lf[48],10,"file-write");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[51]=C_h_intern(&lf[51],13,"string-length");
lf[52]=C_h_intern(&lf[52],12,"file-mkstemp");
lf[53]=C_h_intern(&lf[53],13,"\003syssubstring");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[55]=C_h_intern(&lf[55],8,"seek/set");
lf[56]=C_h_intern(&lf[56],8,"seek/end");
lf[57]=C_h_intern(&lf[57],8,"seek/cur");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[61]=C_h_intern(&lf[61],9,"file-stat");
lf[62]=C_h_intern(&lf[62],9,"\003syserror");
lf[63]=C_h_intern(&lf[63],9,"file-size");
lf[64]=C_h_intern(&lf[64],22,"file-modification-time");
lf[65]=C_h_intern(&lf[65],16,"file-access-time");
lf[66]=C_h_intern(&lf[66],16,"file-change-time");
lf[67]=C_h_intern(&lf[67],10,"file-owner");
lf[68]=C_h_intern(&lf[68],16,"file-permissions");
lf[69]=C_h_intern(&lf[69],13,"regular-file\077");
lf[70]=C_h_intern(&lf[70],13,"\003sysfile-info");
lf[71]=C_h_intern(&lf[71],14,"symbolic-link\077");
lf[72]=C_h_intern(&lf[72],13,"file-position");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[74]=C_h_intern(&lf[74],6,"stream");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[76]=C_h_intern(&lf[76],5,"port\077");
lf[77]=C_h_intern(&lf[77],18,"set-file-position!");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[80]=C_h_intern(&lf[80],13,"\000bounds-error");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[82]=C_h_intern(&lf[82],16,"create-directory");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[84]=C_h_intern(&lf[84],16,"change-directory");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[86]=C_h_intern(&lf[86],16,"delete-directory");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[88]=C_h_intern(&lf[88],6,"string");
lf[89]=C_h_intern(&lf[89],9,"directory");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[91]=C_h_intern(&lf[91],16,"\003sysmake-pointer");
lf[92]=C_h_intern(&lf[92],17,"current-directory");
lf[93]=C_h_intern(&lf[93],10,"directory\077");
lf[94]=C_h_intern(&lf[94],27,"\003sysplatform-fixup-pathname");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[96]=C_h_intern(&lf[96],5,"\000text");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[99]=C_h_intern(&lf[99],13,"\003sysmake-port");
lf[100]=C_h_intern(&lf[100],21,"\003sysstream-port-class");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[102]=C_h_intern(&lf[102],15,"open-input-pipe");
lf[103]=C_h_intern(&lf[103],7,"\000binary");
lf[104]=C_h_intern(&lf[104],16,"open-output-pipe");
lf[105]=C_h_intern(&lf[105],16,"close-input-pipe");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[107]=C_h_intern(&lf[107],14,"\003syscheck-port");
lf[108]=C_h_intern(&lf[108],17,"close-output-pipe");
lf[109]=C_h_intern(&lf[109],20,"call-with-input-pipe");
lf[110]=C_h_intern(&lf[110],21,"call-with-output-pipe");
lf[111]=C_h_intern(&lf[111],20,"with-input-from-pipe");
lf[112]=C_h_intern(&lf[112],18,"\003sysstandard-input");
lf[113]=C_h_intern(&lf[113],19,"with-output-to-pipe");
lf[114]=C_h_intern(&lf[114],19,"\003sysstandard-output");
lf[115]=C_h_intern(&lf[115],11,"create-pipe");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[117]=C_h_intern(&lf[117],11,"signal/term");
lf[118]=C_h_intern(&lf[118],10,"signal/int");
lf[119]=C_h_intern(&lf[119],10,"signal/fpe");
lf[120]=C_h_intern(&lf[120],10,"signal/ill");
lf[121]=C_h_intern(&lf[121],11,"signal/segv");
lf[122]=C_h_intern(&lf[122],11,"signal/abrt");
lf[123]=C_h_intern(&lf[123],12,"signal/break");
lf[124]=C_h_intern(&lf[124],11,"signal/alrm");
lf[125]=C_h_intern(&lf[125],11,"signal/chld");
lf[126]=C_h_intern(&lf[126],11,"signal/cont");
lf[127]=C_h_intern(&lf[127],10,"signal/hup");
lf[128]=C_h_intern(&lf[128],9,"signal/io");
lf[129]=C_h_intern(&lf[129],11,"signal/kill");
lf[130]=C_h_intern(&lf[130],11,"signal/pipe");
lf[131]=C_h_intern(&lf[131],11,"signal/prof");
lf[132]=C_h_intern(&lf[132],11,"signal/quit");
lf[133]=C_h_intern(&lf[133],11,"signal/stop");
lf[134]=C_h_intern(&lf[134],11,"signal/trap");
lf[135]=C_h_intern(&lf[135],11,"signal/tstp");
lf[136]=C_h_intern(&lf[136],10,"signal/urg");
lf[137]=C_h_intern(&lf[137],11,"signal/usr1");
lf[138]=C_h_intern(&lf[138],11,"signal/usr2");
lf[139]=C_h_intern(&lf[139],13,"signal/vtalrm");
lf[140]=C_h_intern(&lf[140],12,"signal/winch");
lf[141]=C_h_intern(&lf[141],11,"signal/xcpu");
lf[142]=C_h_intern(&lf[142],11,"signal/xfsz");
lf[143]=C_h_intern(&lf[143],12,"signals-list");
lf[144]=C_h_intern(&lf[144],18,"\003sysinterrupt-hook");
lf[145]=C_h_intern(&lf[145],14,"signal-handler");
lf[146]=C_h_intern(&lf[146],19,"set-signal-handler!");
lf[147]=C_h_intern(&lf[147],10,"errno/perm");
lf[148]=C_h_intern(&lf[148],11,"errno/noent");
lf[149]=C_h_intern(&lf[149],10,"errno/srch");
lf[150]=C_h_intern(&lf[150],10,"errno/intr");
lf[151]=C_h_intern(&lf[151],8,"errno/io");
lf[152]=C_h_intern(&lf[152],12,"errno/noexec");
lf[153]=C_h_intern(&lf[153],10,"errno/badf");
lf[154]=C_h_intern(&lf[154],11,"errno/child");
lf[155]=C_h_intern(&lf[155],11,"errno/nomem");
lf[156]=C_h_intern(&lf[156],11,"errno/acces");
lf[157]=C_h_intern(&lf[157],11,"errno/fault");
lf[158]=C_h_intern(&lf[158],10,"errno/busy");
lf[159]=C_h_intern(&lf[159],11,"errno/exist");
lf[160]=C_h_intern(&lf[160],12,"errno/notdir");
lf[161]=C_h_intern(&lf[161],11,"errno/isdir");
lf[162]=C_h_intern(&lf[162],11,"errno/inval");
lf[163]=C_h_intern(&lf[163],11,"errno/mfile");
lf[164]=C_h_intern(&lf[164],11,"errno/nospc");
lf[165]=C_h_intern(&lf[165],11,"errno/spipe");
lf[166]=C_h_intern(&lf[166],10,"errno/pipe");
lf[167]=C_h_intern(&lf[167],11,"errno/again");
lf[168]=C_h_intern(&lf[168],10,"errno/rofs");
lf[169]=C_h_intern(&lf[169],10,"errno/nxio");
lf[170]=C_h_intern(&lf[170],10,"errno/2big");
lf[171]=C_h_intern(&lf[171],10,"errno/xdev");
lf[172]=C_h_intern(&lf[172],11,"errno/nodev");
lf[173]=C_h_intern(&lf[173],11,"errno/nfile");
lf[174]=C_h_intern(&lf[174],11,"errno/notty");
lf[175]=C_h_intern(&lf[175],10,"errno/fbig");
lf[176]=C_h_intern(&lf[176],11,"errno/mlink");
lf[177]=C_h_intern(&lf[177],9,"errno/dom");
lf[178]=C_h_intern(&lf[178],11,"errno/range");
lf[179]=C_h_intern(&lf[179],12,"errno/deadlk");
lf[180]=C_h_intern(&lf[180],17,"errno/nametoolong");
lf[181]=C_h_intern(&lf[181],11,"errno/nolck");
lf[182]=C_h_intern(&lf[182],11,"errno/nosys");
lf[183]=C_h_intern(&lf[183],14,"errno/notempty");
lf[184]=C_h_intern(&lf[184],11,"errno/ilseq");
lf[185]=C_h_intern(&lf[185],16,"change-file-mode");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[187]=C_h_intern(&lf[187],17,"file-read-access\077");
lf[188]=C_h_intern(&lf[188],18,"file-write-access\077");
lf[189]=C_h_intern(&lf[189],20,"file-execute-access\077");
lf[190]=C_h_intern(&lf[190],12,"fileno/stdin");
lf[191]=C_h_intern(&lf[191],13,"fileno/stdout");
lf[192]=C_h_intern(&lf[192],13,"fileno/stderr");
lf[193]=C_h_intern(&lf[193],7,"\000append");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[201]=C_h_intern(&lf[201],16,"open-input-file*");
lf[202]=C_h_intern(&lf[202],17,"open-output-file*");
lf[203]=C_h_intern(&lf[203],12,"port->fileno");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[206]=C_h_intern(&lf[206],25,"\003syspeek-unsigned-integer");
lf[207]=C_h_intern(&lf[207],16,"duplicate-fileno");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file descriptor");
lf[209]=C_h_intern(&lf[209],6,"setenv");
lf[210]=C_h_intern(&lf[210],8,"unsetenv");
lf[211]=C_h_intern(&lf[211],9,"substring");
lf[212]=C_h_intern(&lf[212],19,"current-environment");
lf[213]=C_h_intern(&lf[213],19,"seconds->local-time");
lf[214]=C_h_intern(&lf[214],18,"\003sysdecode-seconds");
lf[215]=C_h_intern(&lf[215],17,"seconds->utc-time");
lf[216]=C_h_intern(&lf[216],15,"seconds->string");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[218]=C_h_intern(&lf[218],12,"time->string");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot time vector to string");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[221]=C_h_intern(&lf[221],19,"local-time->seconds");
lf[222]=C_h_intern(&lf[222],15,"\003syscons-flonum");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[225]=C_h_intern(&lf[225],27,"local-timezone-abbreviation");
lf[226]=C_h_intern(&lf[226],5,"_exit");
lf[227]=C_h_intern(&lf[227],19,"set-buffering-mode!");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[229]=C_h_intern(&lf[229],5,"\000full");
lf[230]=C_h_intern(&lf[230],5,"\000line");
lf[231]=C_h_intern(&lf[231],5,"\000none");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[233]=C_h_intern(&lf[233],6,"regexp");
lf[234]=C_h_intern(&lf[234],21,"make-anchored-pattern");
lf[235]=C_h_intern(&lf[235],12,"string-match");
lf[236]=C_h_intern(&lf[236],12,"glob->regexp");
lf[237]=C_h_intern(&lf[237],13,"make-pathname");
lf[238]=C_h_intern(&lf[238],18,"decompose-pathname");
lf[239]=C_h_intern(&lf[239],4,"glob");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[242]=C_h_intern(&lf[242],13,"spawn/overlay");
lf[243]=C_h_intern(&lf[243],10,"spawn/wait");
lf[244]=C_h_intern(&lf[244],12,"spawn/nowait");
lf[245]=C_h_intern(&lf[245],13,"spawn/nowaito");
lf[246]=C_h_intern(&lf[246],12,"spawn/detach");
lf[247]=C_h_intern(&lf[247],16,"char-whitespace\077");
lf[248]=C_h_intern(&lf[248],10,"string-ref");
lf[250]=C_h_intern(&lf[250],7,"reverse");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[253]=C_h_intern(&lf[253],24,"pathname-strip-directory");
lf[256]=C_h_intern(&lf[256],15,"process-execute");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[258]=C_h_intern(&lf[258],13,"process-spawn");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot spawn process");
lf[260]=C_h_intern(&lf[260],18,"current-process-id");
lf[261]=C_h_intern(&lf[261],17,"\003sysshell-command");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve system directory");
lf[263]=C_h_intern(&lf[263],6,"getenv");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\007COMSPEC");
lf[265]=C_h_intern(&lf[265],27,"\003sysshell-command-arguments");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\002/c");
lf[267]=C_h_intern(&lf[267],11,"process-run");
lf[269]=C_h_intern(&lf[269],11,"\003sysprocess");
lf[270]=C_h_intern(&lf[270],14,"\000process-error");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[272]=C_h_intern(&lf[272],17,"\003sysmake-locative");
lf[273]=C_h_intern(&lf[273],8,"location");
lf[274]=C_h_intern(&lf[274],18,"string-intersperse");
lf[275]=C_h_intern(&lf[275],12,"\003sysfor-each");
lf[276]=C_h_intern(&lf[276],7,"process");
lf[277]=C_h_intern(&lf[277],8,"process*");
lf[278]=C_h_intern(&lf[278],16,"\003sysprocess-wait");
lf[279]=C_h_intern(&lf[279],12,"process-wait");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[281]=C_h_intern(&lf[281],5,"sleep");
lf[282]=C_h_intern(&lf[282],13,"get-host-name");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[284]=C_h_intern(&lf[284],18,"system-information");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\007windows");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system-information");
lf[287]=C_h_intern(&lf[287],17,"current-user-name");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current user-name");
lf[289]=C_h_intern(&lf[289],10,"find-files");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[292]=C_h_intern(&lf[292],19,"\003sysundefined-value");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[294]=C_h_intern(&lf[294],16,"\003sysdynamic-wind");
lf[295]=C_h_intern(&lf[295],13,"pathname-file");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[297]=C_h_intern(&lf[297],17,"change-file-owner");
lf[298]=C_h_intern(&lf[298],5,"error");
lf[299]=C_h_intern(&lf[299],11,"create-fifo");
lf[300]=C_h_intern(&lf[300],14,"create-session");
lf[301]=C_h_intern(&lf[301],20,"create-symbolic-link");
lf[302]=C_h_intern(&lf[302],26,"current-effective-group-id");
lf[303]=C_h_intern(&lf[303],25,"current-effective-user-id");
lf[304]=C_h_intern(&lf[304],27,"current-effective-user-name");
lf[305]=C_h_intern(&lf[305],16,"current-group-id");
lf[306]=C_h_intern(&lf[306],15,"current-user-id");
lf[307]=C_h_intern(&lf[307],18,"map-file-to-memory");
lf[308]=C_h_intern(&lf[308],9,"file-link");
lf[309]=C_h_intern(&lf[309],9,"file-lock");
lf[310]=C_h_intern(&lf[310],18,"file-lock/blocking");
lf[311]=C_h_intern(&lf[311],11,"file-select");
lf[312]=C_h_intern(&lf[312],14,"file-test-lock");
lf[313]=C_h_intern(&lf[313],13,"file-truncate");
lf[314]=C_h_intern(&lf[314],11,"file-unlock");
lf[315]=C_h_intern(&lf[315],10,"get-groups");
lf[316]=C_h_intern(&lf[316],17,"group-information");
lf[317]=C_h_intern(&lf[317],17,"initialize-groups");
lf[318]=C_h_intern(&lf[318],26,"memory-mapped-file-pointer");
lf[319]=C_h_intern(&lf[319],17,"parent-process-id");
lf[320]=C_h_intern(&lf[320],12,"process-fork");
lf[321]=C_h_intern(&lf[321],16,"process-group-id");
lf[322]=C_h_intern(&lf[322],14,"process-signal");
lf[323]=C_h_intern(&lf[323],18,"read-symbolic-link");
lf[324]=C_h_intern(&lf[324],10,"set-alarm!");
lf[325]=C_h_intern(&lf[325],13,"set-group-id!");
lf[326]=C_h_intern(&lf[326],11,"set-groups!");
lf[327]=C_h_intern(&lf[327],21,"set-process-group-id!");
lf[328]=C_h_intern(&lf[328],19,"set-root-directory!");
lf[329]=C_h_intern(&lf[329],16,"set-signal-mask!");
lf[330]=C_h_intern(&lf[330],12,"set-user-id!");
lf[331]=C_h_intern(&lf[331],11,"signal-mask");
lf[332]=C_h_intern(&lf[332],12,"signal-mask!");
lf[333]=C_h_intern(&lf[333],14,"signal-masked\077");
lf[334]=C_h_intern(&lf[334],14,"signal-unmask!");
lf[335]=C_h_intern(&lf[335],13,"terminal-name");
lf[336]=C_h_intern(&lf[336],14,"terminal-port\077");
lf[337]=C_h_intern(&lf[337],13,"terminal-size");
lf[338]=C_h_intern(&lf[338],22,"unmap-file-from-memory");
lf[339]=C_h_intern(&lf[339],16,"user-information");
lf[340]=C_h_intern(&lf[340],17,"utc-time->seconds");
lf[341]=C_h_intern(&lf[341],16,"errno/wouldblock");
lf[342]=C_h_intern(&lf[342],5,"fifo\077");
lf[343]=C_h_intern(&lf[343],19,"memory-mapped-file\077");
lf[344]=C_h_intern(&lf[344],13,"map/anonymous");
lf[345]=C_h_intern(&lf[345],8,"map/file");
lf[346]=C_h_intern(&lf[346],9,"map/fixed");
lf[347]=C_h_intern(&lf[347],11,"map/private");
lf[348]=C_h_intern(&lf[348],10,"map/shared");
lf[349]=C_h_intern(&lf[349],10,"open/fsync");
lf[350]=C_h_intern(&lf[350],11,"open/noctty");
lf[351]=C_h_intern(&lf[351],13,"open/nonblock");
lf[352]=C_h_intern(&lf[352],9,"open/sync");
lf[353]=C_h_intern(&lf[353],10,"perm/isgid");
lf[354]=C_h_intern(&lf[354],10,"perm/isuid");
lf[355]=C_h_intern(&lf[355],10,"perm/isvtx");
lf[356]=C_h_intern(&lf[356],9,"prot/exec");
lf[357]=C_h_intern(&lf[357],9,"prot/none");
lf[358]=C_h_intern(&lf[358],9,"prot/read");
lf[359]=C_h_intern(&lf[359],10,"prot/write");
lf[360]=C_h_intern(&lf[360],11,"make-vector");
lf[361]=C_h_intern(&lf[361],17,"register-feature!");
lf[362]=C_h_intern(&lf[362],5,"posix");
C_register_lf2(lf,363,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate(&lf[2],lf[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1058,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t4);}

/* k1056 */
static void C_ccall f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1061,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1059 in k1056 */
static void C_ccall f_1061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1064,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1062 in k1059 in k1056 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1067,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1070,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 931  register-feature! */
t3=*((C_word*)lf[361]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[362]);}

/* k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word ab[154],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1070,2,t0,t1);}
t2=*((C_word*)lf[4]+1);
t3=C_mutate(&lf[5],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1082,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[10]+1,lf[5]);
t5=C_mutate((C_word*)lf[11]+1,C_fix((C_word)PIPE_BUF));
t6=C_mutate((C_word*)lf[12]+1,C_fix((C_word)O_RDONLY));
t7=C_mutate((C_word*)lf[13]+1,C_fix((C_word)O_WRONLY));
t8=C_mutate((C_word*)lf[14]+1,C_fix((C_word)O_RDWR));
t9=C_mutate((C_word*)lf[15]+1,C_fix((C_word)O_RDWR));
t10=C_mutate((C_word*)lf[16]+1,C_fix((C_word)O_WRONLY));
t11=C_mutate((C_word*)lf[17]+1,C_fix((C_word)O_CREAT));
t12=C_mutate((C_word*)lf[18]+1,C_fix((C_word)O_APPEND));
t13=C_mutate((C_word*)lf[19]+1,C_fix((C_word)O_EXCL));
t14=C_mutate((C_word*)lf[20]+1,C_fix((C_word)O_TRUNC));
t15=C_mutate((C_word*)lf[21]+1,C_fix((C_word)O_BINARY));
t16=C_mutate((C_word*)lf[22]+1,C_fix((C_word)O_TEXT));
t17=C_mutate((C_word*)lf[23]+1,C_fix((C_word)O_NOINHERIT));
t18=C_mutate((C_word*)lf[24]+1,C_fix((C_word)S_IREAD));
t19=C_mutate((C_word*)lf[25]+1,C_fix((C_word)S_IWRITE));
t20=C_mutate((C_word*)lf[26]+1,C_fix((C_word)S_IEXEC));
t21=C_mutate((C_word*)lf[27]+1,C_fix((C_word)S_IREAD));
t22=C_mutate((C_word*)lf[28]+1,C_fix((C_word)S_IWRITE));
t23=C_mutate((C_word*)lf[29]+1,C_fix((C_word)S_IEXEC));
t24=C_mutate((C_word*)lf[30]+1,C_fix((C_word)S_IREAD));
t25=C_mutate((C_word*)lf[31]+1,C_fix((C_word)S_IWRITE));
t26=C_mutate((C_word*)lf[32]+1,C_fix((C_word)S_IEXEC));
t27=C_mutate((C_word*)lf[33]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t28=C_mutate((C_word*)lf[34]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t29=C_mutate((C_word*)lf[35]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t30=(C_word)C_fixnum_or(C_fix((C_word)S_IREAD),C_fix((C_word)S_IREAD));
t31=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC),t30);
t32=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1128,a[2]=t31,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp));
t33=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1169,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t34=*((C_word*)lf[43]+1);
t35=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1187,a[2]=t34,a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp));
t36=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1232,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t37=*((C_word*)lf[51]+1);
t38=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1274,a[2]=t37,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp));
t39=C_mutate((C_word*)lf[55]+1,C_fix((C_word)SEEK_SET));
t40=C_mutate((C_word*)lf[56]+1,C_fix((C_word)SEEK_END));
t41=C_mutate((C_word*)lf[57]+1,C_fix((C_word)SEEK_CUR));
t42=C_mutate(&lf[58],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1312,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1350,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1381,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1387,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1393,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1399,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1405,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1411,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1417,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1440,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1446,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1486,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1547,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1574,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1601,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t57=*((C_word*)lf[4]+1);
t58=*((C_word*)lf[43]+1);
t59=*((C_word*)lf[88]+1);
t60=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1628,a[2]=t58,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp));
t61=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1788,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t62=*((C_word*)lf[43]+1);
t63=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1815,a[2]=t62,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp));
t64=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1861,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp);
t65=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1873,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp);
t66=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1879,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
t67=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1897,a[2]=t65,a[3]=t66,a[4]=t64,a[5]=((C_word)li31),tmp=(C_word)a,a+=6,tmp));
t68=C_mutate((C_word*)lf[104]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1933,a[2]=t65,a[3]=t66,a[4]=t64,a[5]=((C_word)li32),tmp=(C_word)a,a+=6,tmp));
t69=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1969,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[108]+1,*((C_word*)lf[105]+1));
t71=*((C_word*)lf[102]+1);
t72=*((C_word*)lf[104]+1);
t73=*((C_word*)lf[105]+1);
t74=*((C_word*)lf[108]+1);
t75=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1988,a[2]=t71,a[3]=t73,a[4]=((C_word)li36),tmp=(C_word)a,a+=5,tmp));
t76=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2012,a[2]=t72,a[3]=t74,a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp));
t77=C_mutate((C_word*)lf[111]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2036,a[2]=t71,a[3]=t73,a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp));
t78=C_mutate((C_word*)lf[113]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2056,a[2]=t72,a[3]=t74,a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp));
t79=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2076,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t80=C_mutate((C_word*)lf[117]+1,C_fix((C_word)SIGTERM));
t81=C_mutate((C_word*)lf[118]+1,C_fix((C_word)SIGINT));
t82=C_mutate((C_word*)lf[119]+1,C_fix((C_word)SIGFPE));
t83=C_mutate((C_word*)lf[120]+1,C_fix((C_word)SIGILL));
t84=C_mutate((C_word*)lf[121]+1,C_fix((C_word)SIGSEGV));
t85=C_mutate((C_word*)lf[122]+1,C_fix((C_word)SIGABRT));
t86=C_mutate((C_word*)lf[123]+1,C_fix((C_word)SIGBREAK));
t87=C_set_block_item(lf[124],0,C_fix(0));
t88=C_set_block_item(lf[125],0,C_fix(0));
t89=C_set_block_item(lf[126],0,C_fix(0));
t90=C_set_block_item(lf[127],0,C_fix(0));
t91=C_set_block_item(lf[128],0,C_fix(0));
t92=C_set_block_item(lf[129],0,C_fix(0));
t93=C_set_block_item(lf[130],0,C_fix(0));
t94=C_set_block_item(lf[131],0,C_fix(0));
t95=C_set_block_item(lf[132],0,C_fix(0));
t96=C_set_block_item(lf[133],0,C_fix(0));
t97=C_set_block_item(lf[134],0,C_fix(0));
t98=C_set_block_item(lf[135],0,C_fix(0));
t99=C_set_block_item(lf[136],0,C_fix(0));
t100=C_set_block_item(lf[137],0,C_fix(0));
t101=C_set_block_item(lf[138],0,C_fix(0));
t102=C_set_block_item(lf[139],0,C_fix(0));
t103=C_set_block_item(lf[140],0,C_fix(0));
t104=C_set_block_item(lf[141],0,C_fix(0));
t105=C_set_block_item(lf[142],0,C_fix(0));
t106=(C_word)C_a_i_list(&a,7,*((C_word*)lf[117]+1),*((C_word*)lf[118]+1),*((C_word*)lf[119]+1),*((C_word*)lf[120]+1),*((C_word*)lf[121]+1),*((C_word*)lf[122]+1),*((C_word*)lf[123]+1));
t107=C_mutate((C_word*)lf[143]+1,t106);
t108=*((C_word*)lf[144]+1);
t109=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[2],a[3]=t108,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1349 make-vector */
t110=*((C_word*)lf[360]+1);
((C_proc4)(void*)(*((C_word*)t110+1)))(4,t110,t109,C_fix(256),C_SCHEME_FALSE);}

/* k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word ab[319],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2150,2,t0,t1);}
t2=C_mutate((C_word*)lf[145]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2152,a[2]=t1,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2161,a[2]=t1,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[144]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2174,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[147]+1,C_fix((C_word)EPERM));
t6=C_mutate((C_word*)lf[148]+1,C_fix((C_word)ENOENT));
t7=C_mutate((C_word*)lf[149]+1,C_fix((C_word)ESRCH));
t8=C_mutate((C_word*)lf[150]+1,C_fix((C_word)EINTR));
t9=C_mutate((C_word*)lf[151]+1,C_fix((C_word)EIO));
t10=C_mutate((C_word*)lf[152]+1,C_fix((C_word)ENOEXEC));
t11=C_mutate((C_word*)lf[153]+1,C_fix((C_word)EBADF));
t12=C_mutate((C_word*)lf[154]+1,C_fix((C_word)ECHILD));
t13=C_mutate((C_word*)lf[155]+1,C_fix((C_word)ENOMEM));
t14=C_mutate((C_word*)lf[156]+1,C_fix((C_word)EACCES));
t15=C_mutate((C_word*)lf[157]+1,C_fix((C_word)EFAULT));
t16=C_mutate((C_word*)lf[158]+1,C_fix((C_word)EBUSY));
t17=C_mutate((C_word*)lf[159]+1,C_fix((C_word)EEXIST));
t18=C_mutate((C_word*)lf[160]+1,C_fix((C_word)ENOTDIR));
t19=C_mutate((C_word*)lf[161]+1,C_fix((C_word)EISDIR));
t20=C_mutate((C_word*)lf[162]+1,C_fix((C_word)EINVAL));
t21=C_mutate((C_word*)lf[163]+1,C_fix((C_word)EMFILE));
t22=C_mutate((C_word*)lf[164]+1,C_fix((C_word)ENOSPC));
t23=C_mutate((C_word*)lf[165]+1,C_fix((C_word)ESPIPE));
t24=C_mutate((C_word*)lf[166]+1,C_fix((C_word)EPIPE));
t25=C_mutate((C_word*)lf[167]+1,C_fix((C_word)EAGAIN));
t26=C_mutate((C_word*)lf[168]+1,C_fix((C_word)EROFS));
t27=C_mutate((C_word*)lf[169]+1,C_fix((C_word)ENXIO));
t28=C_mutate((C_word*)lf[170]+1,C_fix((C_word)E2BIG));
t29=C_mutate((C_word*)lf[171]+1,C_fix((C_word)EXDEV));
t30=C_mutate((C_word*)lf[172]+1,C_fix((C_word)ENODEV));
t31=C_mutate((C_word*)lf[173]+1,C_fix((C_word)ENFILE));
t32=C_mutate((C_word*)lf[174]+1,C_fix((C_word)ENOTTY));
t33=C_mutate((C_word*)lf[175]+1,C_fix((C_word)EFBIG));
t34=C_mutate((C_word*)lf[176]+1,C_fix((C_word)EMLINK));
t35=C_mutate((C_word*)lf[177]+1,C_fix((C_word)EDOM));
t36=C_mutate((C_word*)lf[178]+1,C_fix((C_word)ERANGE));
t37=C_mutate((C_word*)lf[179]+1,C_fix((C_word)EDEADLK));
t38=C_mutate((C_word*)lf[180]+1,C_fix((C_word)ENAMETOOLONG));
t39=C_mutate((C_word*)lf[181]+1,C_fix((C_word)ENOLCK));
t40=C_mutate((C_word*)lf[182]+1,C_fix((C_word)ENOSYS));
t41=C_mutate((C_word*)lf[183]+1,C_fix((C_word)ENOTEMPTY));
t42=C_mutate((C_word*)lf[184]+1,C_fix((C_word)EILSEQ));
t43=C_mutate((C_word*)lf[185]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2230,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2260,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
t45=C_mutate((C_word*)lf[187]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2284,a[2]=t44,a[3]=((C_word)li50),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[188]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2290,a[2]=t44,a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[189]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2296,a[2]=t44,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp));
t48=C_mutate((C_word*)lf[190]+1,C_fix((C_word)0));
t49=C_mutate((C_word*)lf[191]+1,C_fix((C_word)1));
t50=C_mutate((C_word*)lf[192]+1,C_fix((C_word)2));
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2305,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp);
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2342,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[201]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2360,a[2]=t51,a[3]=t52,a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp));
t54=C_mutate((C_word*)lf[202]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2374,a[2]=t51,a[3]=t52,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp));
t55=C_mutate((C_word*)lf[203]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2388,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2423,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[209]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2453,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[210]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2470,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t59=*((C_word*)lf[211]+1);
t60=C_mutate((C_word*)lf[212]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2490,a[2]=t59,a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp));
t61=C_mutate((C_word*)lf[213]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2555,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[215]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2564,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[216]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2583,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[218]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2611,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[221]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2650,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[225]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2678,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[226]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2690,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[227]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2706,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t69=*((C_word*)lf[233]+1);
t70=*((C_word*)lf[234]+1);
t71=*((C_word*)lf[235]+1);
t72=*((C_word*)lf[236]+1);
t73=*((C_word*)lf[89]+1);
t74=*((C_word*)lf[237]+1);
t75=*((C_word*)lf[238]+1);
t76=C_mutate((C_word*)lf[239]+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2765,a[2]=t72,a[3]=t70,a[4]=t69,a[5]=t73,a[6]=t71,a[7]=t74,a[8]=t75,a[9]=((C_word)li76),tmp=(C_word)a,a+=10,tmp));
t77=C_mutate((C_word*)lf[242]+1,C_fix((C_word)P_OVERLAY));
t78=C_mutate((C_word*)lf[243]+1,C_fix((C_word)P_WAIT));
t79=C_mutate((C_word*)lf[244]+1,C_fix((C_word)P_NOWAIT));
t80=C_mutate((C_word*)lf[245]+1,C_fix((C_word)P_NOWAITO));
t81=C_mutate((C_word*)lf[246]+1,C_fix((C_word)P_DETACH));
t82=*((C_word*)lf[247]+1);
t83=*((C_word*)lf[51]+1);
t84=*((C_word*)lf[248]+1);
t85=*((C_word*)lf[4]+1);
t86=C_mutate(&lf[249],(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2880,a[2]=t85,a[3]=t83,a[4]=t84,a[5]=t82,a[6]=((C_word)li80),tmp=(C_word)a,a+=7,tmp));
t87=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2959,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp);
t88=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2976,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp);
t89=*((C_word*)lf[253]+1);
t90=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2993,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp);
t91=C_mutate(&lf[254],(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3043,a[2]=t89,a[3]=t87,a[4]=t88,a[5]=t90,a[6]=((C_word)li85),tmp=(C_word)a,a+=7,tmp));
t92=C_mutate(&lf[255],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3076,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t93=C_mutate((C_word*)lf[256]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3091,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t94=C_mutate((C_word*)lf[258]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3178,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t95=C_mutate((C_word*)lf[260]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3265,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t96=C_mutate((C_word*)lf[261]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3268,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t97=C_mutate((C_word*)lf[265]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3289,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t98=*((C_word*)lf[258]+1);
t99=*((C_word*)lf[263]+1);
t100=C_mutate((C_word*)lf[267]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3295,a[2]=t98,a[3]=((C_word)li100),tmp=(C_word)a,a+=4,tmp));
t101=C_mutate(&lf[268],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3324,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t102=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3390,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t103=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3509,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp);
t104=C_mutate((C_word*)lf[276]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3571,a[2]=t103,a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp));
t105=C_mutate((C_word*)lf[277]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3651,a[2]=t103,a[3]=((C_word)li117),tmp=(C_word)a,a+=4,tmp));
t106=C_mutate((C_word*)lf[278]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3731,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp));
t107=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3743,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t108=C_mutate((C_word*)lf[281]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3803,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp));
t109=C_mutate((C_word*)lf[282]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3806,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp));
t110=C_mutate((C_word*)lf[284]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3818,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp));
t111=C_mutate((C_word*)lf[287]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3849,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp));
t112=*((C_word*)lf[239]+1);
t113=*((C_word*)lf[235]+1);
t114=*((C_word*)lf[237]+1);
t115=*((C_word*)lf[93]+1);
t116=C_mutate((C_word*)lf[289]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3864,a[2]=t115,a[3]=t114,a[4]=t112,a[5]=t113,a[6]=((C_word)li138),tmp=(C_word)a,a+=7,tmp));
t117=C_mutate((C_word*)lf[297]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4090,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp));
t118=C_mutate((C_word*)lf[299]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4096,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t119=C_mutate((C_word*)lf[300]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4102,a[2]=((C_word)li141),tmp=(C_word)a,a+=3,tmp));
t120=C_mutate((C_word*)lf[301]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4108,a[2]=((C_word)li142),tmp=(C_word)a,a+=3,tmp));
t121=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4114,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp));
t122=C_mutate((C_word*)lf[303]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4120,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t123=C_mutate((C_word*)lf[304]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4126,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t124=C_mutate((C_word*)lf[305]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4132,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp));
t125=C_mutate((C_word*)lf[306]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4138,a[2]=((C_word)li147),tmp=(C_word)a,a+=3,tmp));
t126=C_mutate((C_word*)lf[307]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4144,a[2]=((C_word)li148),tmp=(C_word)a,a+=3,tmp));
t127=C_mutate((C_word*)lf[308]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4150,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp));
t128=C_mutate((C_word*)lf[309]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4156,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp));
t129=C_mutate((C_word*)lf[310]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4162,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp));
t130=C_mutate((C_word*)lf[311]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4168,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp));
t131=C_mutate((C_word*)lf[312]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4174,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));
t132=C_mutate((C_word*)lf[313]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4180,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp));
t133=C_mutate((C_word*)lf[314]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4186,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t134=C_mutate((C_word*)lf[315]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4192,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t135=C_mutate((C_word*)lf[316]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4198,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t136=C_mutate((C_word*)lf[317]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4204,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t137=C_mutate((C_word*)lf[318]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4210,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t138=C_mutate((C_word*)lf[319]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4216,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t139=C_mutate((C_word*)lf[320]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4222,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp));
t140=C_mutate((C_word*)lf[321]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4228,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp));
t141=C_mutate((C_word*)lf[322]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4234,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t142=C_mutate((C_word*)lf[323]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4240,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp));
t143=C_mutate((C_word*)lf[324]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4246,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t144=C_mutate((C_word*)lf[325]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4252,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp));
t145=C_mutate((C_word*)lf[326]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4258,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t146=C_mutate((C_word*)lf[327]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4264,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp));
t147=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4270,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp));
t148=C_mutate((C_word*)lf[329]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4276,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t149=C_mutate((C_word*)lf[330]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4282,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp));
t150=C_mutate((C_word*)lf[331]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4288,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp));
t151=C_mutate((C_word*)lf[332]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4294,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp));
t152=C_mutate((C_word*)lf[333]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4300,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp));
t153=C_mutate((C_word*)lf[334]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4306,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp));
t154=C_mutate((C_word*)lf[335]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4312,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp));
t155=C_mutate((C_word*)lf[336]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4318,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp));
t156=C_mutate((C_word*)lf[337]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4324,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp));
t157=C_mutate((C_word*)lf[338]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4330,a[2]=((C_word)li179),tmp=(C_word)a,a+=3,tmp));
t158=C_mutate((C_word*)lf[339]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4336,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp));
t159=C_mutate((C_word*)lf[340]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4342,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp));
t160=C_set_block_item(lf[341],0,C_fix(0));
t161=C_mutate((C_word*)lf[342]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4349,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp));
t162=C_mutate((C_word*)lf[343]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4352,a[2]=((C_word)li183),tmp=(C_word)a,a+=3,tmp));
t163=C_set_block_item(lf[344],0,C_fix(0));
t164=C_set_block_item(lf[345],0,C_fix(0));
t165=C_set_block_item(lf[346],0,C_fix(0));
t166=C_set_block_item(lf[347],0,C_fix(0));
t167=C_set_block_item(lf[348],0,C_fix(0));
t168=C_set_block_item(lf[349],0,C_fix(0));
t169=C_set_block_item(lf[350],0,C_fix(0));
t170=C_set_block_item(lf[351],0,C_fix(0));
t171=C_set_block_item(lf[352],0,C_fix(0));
t172=C_set_block_item(lf[353],0,C_fix(0));
t173=C_set_block_item(lf[354],0,C_fix(0));
t174=C_set_block_item(lf[355],0,C_fix(0));
t175=C_set_block_item(lf[356],0,C_fix(0));
t176=C_set_block_item(lf[357],0,C_fix(0));
t177=C_set_block_item(lf[358],0,C_fix(0));
t178=C_set_block_item(lf[359],0,C_fix(0));
t179=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t179+1)))(2,t179,C_SCHEME_UNDEFINED);}

/* memory-mapped-file? in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4352(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4352,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* fifo? in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4349,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* utc-time->seconds in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4342(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4342,2,t0,t1);}
/* posixwin.scm: 1982 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[340],lf[0]);}

/* user-information in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4336,2,t0,t1);}
/* posixwin.scm: 1981 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[339],lf[0]);}

/* unmap-file-from-memory in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4330(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4330,2,t0,t1);}
/* posixwin.scm: 1980 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[338],lf[0]);}

/* terminal-size in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4324(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4324,2,t0,t1);}
/* posixwin.scm: 1979 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[337],lf[0]);}

/* terminal-port? in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4318(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4318,2,t0,t1);}
/* posixwin.scm: 1978 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[336],lf[0]);}

/* terminal-name in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4312,2,t0,t1);}
/* posixwin.scm: 1977 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[335],lf[0]);}

/* signal-unmask! in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4306,2,t0,t1);}
/* posixwin.scm: 1976 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[334],lf[0]);}

/* signal-masked? in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4300(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4300,2,t0,t1);}
/* posixwin.scm: 1975 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[333],lf[0]);}

/* signal-mask! in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4294,2,t0,t1);}
/* posixwin.scm: 1974 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[332],lf[0]);}

/* signal-mask in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4288(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4288,2,t0,t1);}
/* posixwin.scm: 1973 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[331],lf[0]);}

/* set-user-id! in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4282(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4282,2,t0,t1);}
/* posixwin.scm: 1972 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[330],lf[0]);}

/* set-signal-mask! in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4276(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4276,2,t0,t1);}
/* posixwin.scm: 1971 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[329],lf[0]);}

/* set-root-directory! in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4270,2,t0,t1);}
/* posixwin.scm: 1970 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[328],lf[0]);}

/* set-process-group-id! in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4264,2,t0,t1);}
/* posixwin.scm: 1969 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[327],lf[0]);}

/* set-groups! in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4258(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4258,2,t0,t1);}
/* posixwin.scm: 1968 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[326],lf[0]);}

/* set-group-id! in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4252,2,t0,t1);}
/* posixwin.scm: 1967 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[325],lf[0]);}

/* set-alarm! in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4246,2,t0,t1);}
/* posixwin.scm: 1966 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[324],lf[0]);}

/* read-symbolic-link in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
/* posixwin.scm: 1965 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[323],lf[0]);}

/* process-signal in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4234,2,t0,t1);}
/* posixwin.scm: 1964 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[322],lf[0]);}

/* process-group-id in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4228,2,t0,t1);}
/* posixwin.scm: 1963 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[321],lf[0]);}

/* process-fork in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4222(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4222,2,t0,t1);}
/* posixwin.scm: 1962 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[320],lf[0]);}

/* parent-process-id in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4216(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4216,2,t0,t1);}
/* posixwin.scm: 1961 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[319],lf[0]);}

/* memory-mapped-file-pointer in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4210(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4210,2,t0,t1);}
/* posixwin.scm: 1960 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[318],lf[0]);}

/* initialize-groups in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
/* posixwin.scm: 1959 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[317],lf[0]);}

/* group-information in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
/* posixwin.scm: 1958 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[316],lf[0]);}

/* get-groups in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4192(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4192,2,t0,t1);}
/* posixwin.scm: 1957 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[315],lf[0]);}

/* file-unlock in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4186,2,t0,t1);}
/* posixwin.scm: 1956 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[314],lf[0]);}

/* file-truncate in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4180,2,t0,t1);}
/* posixwin.scm: 1955 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[313],lf[0]);}

/* file-test-lock in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
/* posixwin.scm: 1954 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[312],lf[0]);}

/* file-select in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
/* posixwin.scm: 1953 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[311],lf[0]);}

/* file-lock/blocking in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4162(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4162,2,t0,t1);}
/* posixwin.scm: 1952 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[310],lf[0]);}

/* file-lock in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4156,2,t0,t1);}
/* posixwin.scm: 1951 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[309],lf[0]);}

/* file-link in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4150,2,t0,t1);}
/* posixwin.scm: 1950 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[308],lf[0]);}

/* map-file-to-memory in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4144,2,t0,t1);}
/* posixwin.scm: 1949 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[307],lf[0]);}

/* current-user-id in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4138(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4138,2,t0,t1);}
/* posixwin.scm: 1948 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[306],lf[0]);}

/* current-group-id in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4132(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4132,2,t0,t1);}
/* posixwin.scm: 1947 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[305],lf[0]);}

/* current-effective-user-name in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4126(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4126,2,t0,t1);}
/* posixwin.scm: 1946 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[304],lf[0]);}

/* current-effective-user-id in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4120(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4120,2,t0,t1);}
/* posixwin.scm: 1945 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[303],lf[0]);}

/* current-effective-group-id in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4114,2,t0,t1);}
/* posixwin.scm: 1944 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[302],lf[0]);}

/* create-symbolic-link in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4108(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4108,2,t0,t1);}
/* posixwin.scm: 1943 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[301],lf[0]);}

/* create-session in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4102(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4102,2,t0,t1);}
/* posixwin.scm: 1942 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[300],lf[0]);}

/* create-fifo in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4096,2,t0,t1);}
/* posixwin.scm: 1941 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[299],lf[0]);}

/* change-file-owner in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4090,2,t0,t1);}
/* posixwin.scm: 1940 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[297],lf[0]);}

/* find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3864(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_3864r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3864r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3864r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li133),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4011,a[2]=t5,a[3]=((C_word)li134),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4016,a[2]=t6,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4021,a[2]=t7,a[3]=((C_word)li137),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action727761 */
t9=t8;
f_4021(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id728759 */
t11=t7;
f_4016(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit729756 */
t13=t6;
f_4011(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body725731 */
t15=t5;
f_3866(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[2],t14);}}}}}

/* def-action727 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_4021(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4021,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4027,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp);
/* def-id728759 */
t3=((C_word*)t0)[2];
f_4016(t3,t1,t2);}

/* a4026 in def-action727 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4027,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id728 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_4016(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4016,NULL,3,t0,t1,t2);}
/* def-limit729756 */
t3=((C_word*)t0)[2];
f_4011(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit729 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_4011(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4011,NULL,4,t0,t1,t2,t3);}
/* body725731 */
t4=((C_word*)t0)[2];
f_3866(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3866(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3866,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[289]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3873,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_3873(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4006,a[2]=t4,a[3]=t7,a[4]=((C_word)li131),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_3873(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3998,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp));}}

/* f_3998 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3998(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3998,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4006 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4006(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4006,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3873(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3873,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3990,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word)li126),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3883,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3986,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1918 make-pathname */
t6=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],lf[296]);}

/* k3984 in k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1918 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3881 in k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3883,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3885,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li130),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_3885(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k3881 in k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3885(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3885,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3904,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 1924 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k3902 in loop in k3881 in k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3904,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3966,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1925 pathname-file */
t3=*((C_word*)lf[295]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1931 pproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}}

/* k3970 in k3902 in loop in k3881 in k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3979,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1931 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1932 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3885(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k3977 in k3970 in k3902 in loop in k3881 in k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1931 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3885(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3964 in k3902 in loop in k3881 in k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[290]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[291]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixwin.scm: 1925 loop */
t2=((C_word*)((C_word*)t0)[10])[1];
f_3885(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3919,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 1926 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}}

/* k3917 in k3964 in k3902 in loop in k3881 in k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3919,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3929,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3931,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,a[5]=((C_word)li127),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word)li128),tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3953,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=((C_word)li129),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1928 ##sys#dynamic-wind */
t11=*((C_word*)lf[294]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
/* posixwin.scm: 1930 loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_3885(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a3952 in k3917 in k3964 in k3902 in loop in k3881 in k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3953,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[292]+1));}

/* a3938 in k3917 in k3964 in k3902 in loop in k3881 in k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3947,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3951,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1929 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[293]);}

/* k3949 in a3938 in k3917 in k3964 in k3902 in loop in k3881 in k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1929 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3945 in a3938 in k3917 in k3964 in k3902 in loop in k3881 in k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1929 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3885(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a3930 in k3917 in k3964 in k3902 in loop in k3881 in k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3931,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[292]+1));}

/* k3927 in k3917 in k3964 in k3902 in loop in k3881 in k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1927 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3885(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_3990 in k3871 in body725 in find-files in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3990,3,t0,t1,t2);}
/* posixwin.scm: 1916 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* current-user-name in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3849,2,t0,t1);}
if(C_truep((C_word)C_get_user_name())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_username),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3859,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1892 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3857 in current-user-name in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1893 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[287],lf[288]);}

/* system-information in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3818,2,t0,t1);}
if(C_truep((C_word)C_sysinfo())){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3829,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3844,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1883 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3842 in system-information in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1884 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[284],lf[286]);}

/* k3827 in system-information in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3833,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osrel),C_fix(0));}

/* k3831 in k3827 in system-information in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3837,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osver),C_fix(0));}

/* k3835 in k3831 in k3827 in system-information in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3841,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_processor),C_fix(0));}

/* k3839 in k3835 in k3831 in k3827 in system-information in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3841,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,lf[285],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* get-host-name in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3806,2,t0,t1);}
if(C_truep((C_word)C_get_hostname())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
/* posixwin.scm: 1873 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[282],lf[283]);}}

/* sleep in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3803,3,t0,t1,t2);}
t3=(C_word)C_sleep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}

/* process-wait in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3743r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3743r(t0,t1,t2,t3);}}

static void C_ccall f_3743r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_i_check_exact_2(t2,lf[279]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3764,a[2]=t5,a[3]=t2,a[4]=((C_word)li119),tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3770,a[2]=t2,a[3]=((C_word)li120),tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1852 ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}
else{
/* ##sys#error */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,lf[2],t7);}}

/* a3769 in process-wait in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3770,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3780,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1855 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* posixwin.scm: 1857 values */
C_values(5,0,t1,t2,t3,t4);}}

/* k3778 in a3769 in process-wait in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1856 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[270],lf[279],lf[280],((C_word*)t0)[2]);}

/* a3763 in process-wait in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3764,2,t0,t1);}
/* posixwin.scm: 1852 ##sys#process-wait */
t2=*((C_word*)lf[278]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3731,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_process_wait(t2,t3))){
/* posixwin.scm: 1845 values */
C_values(5,0,t1,t2,C_SCHEME_TRUE,C_fix((C_word)C_exstatus));}
else{
/* posixwin.scm: 1846 values */
C_values(5,0,t1,C_fix(-1),C_SCHEME_FALSE,C_SCHEME_FALSE);}}

/* process* in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3651(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_3651r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3651r(t0,t1,t2,t3);}}

static void C_ccall f_3651r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3653,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li113),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3658,a[2]=t4,a[3]=((C_word)li114),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3663,a[2]=t5,a[3]=((C_word)li115),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3668,a[2]=t6,a[3]=((C_word)li116),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args676689 */
t8=t7;
f_3668(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env677687 */
t10=t6;
f_3663(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf678684 */
t12=t5;
f_3658(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body674680 */
t14=t4;
f_3653(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-args676 in process* in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3668(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3668,NULL,2,t0,t1);}
/* def-env677687 */
t2=((C_word*)t0)[2];
f_3663(t2,t1,C_SCHEME_FALSE);}

/* def-env677 in process* in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3663(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3663,NULL,3,t0,t1,t2);}
/* def-exactf678684 */
t3=((C_word*)t0)[2];
f_3658(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf678 in process* in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3658(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3658,NULL,4,t0,t1,t2,t3);}
/* body674680 */
t4=((C_word*)t0)[2];
f_3653(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body674 in process* in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3653(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3653,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1839 %process */
f_3509(t1,lf[277],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3,t4);}

/* process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_3571r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3571r(t0,t1,t2,t3);}}

static void C_ccall f_3571r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3573,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li108),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3578,a[2]=t4,a[3]=((C_word)li109),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3583,a[2]=t5,a[3]=((C_word)li110),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3588,a[2]=t6,a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args648661 */
t8=t7;
f_3588(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env649659 */
t10=t6;
f_3583(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf650656 */
t12=t5;
f_3578(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body646652 */
t14=t4;
f_3573(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-args648 in process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3588(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3588,NULL,2,t0,t1);}
/* def-env649659 */
t2=((C_word*)t0)[2];
f_3583(t2,t1,C_SCHEME_FALSE);}

/* def-env649 in process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3583(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3583,NULL,3,t0,t1,t2);}
/* def-exactf650656 */
t3=((C_word*)t0)[2];
f_3578(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf650 in process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3578(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3578,NULL,4,t0,t1,t2,t3);}
/* body646652 */
t4=((C_word*)t0)[2];
f_3573(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body646 in process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3573(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3573,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1836 %process */
f_3509(t1,lf[276],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3,t4);}

/* %process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3509(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3509,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3511,a[2]=t2,a[3]=((C_word)li104),tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_check_string_2(((C_word*)t8)[1],t2);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3530,a[2]=t11,a[3]=t1,a[4]=t10,a[5]=t3,a[6]=t6,a[7]=t9,a[8]=t8,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t9)[1])){
/* posixwin.scm: 1824 chkstrlst */
t14=t11;
f_3511(t14,t13,((C_word*)t9)[1]);}
else{
t14=C_set_block_item(t10,0,C_SCHEME_TRUE);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3565,a[2]=t13,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1827 ##sys#shell-command-arguments */
t16=*((C_word*)lf[265]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,((C_word*)t8)[1]);}}

/* k3563 in %process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3565,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1828 ##sys#shell-command */
t4=*((C_word*)lf[261]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3567 in k3563 in %process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3530(2,t3,t2);}

/* k3528 in %process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3533,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
/* posixwin.scm: 1829 chkstrlst */
t3=((C_word*)t0)[2];
f_3511(t3,t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_3533(2,t3,C_SCHEME_UNDEFINED);}}

/* k3531 in k3528 in %process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3538,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li105),tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3544,a[2]=((C_word*)t0)[4],a[3]=((C_word)li106),tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1830 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3543 in k3531 in k3528 in %process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3544,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixwin.scm: 1832 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixwin.scm: 1833 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a3537 in k3531 in k3528 in %process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3538,2,t0,t1);}
/* posixwin.scm: 1830 ##sys#process */
t2=*((C_word*)lf[269]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,t1,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* chkstrlst in %process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3511(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3511,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3520,a[2]=((C_word*)t0)[2],a[3]=((C_word)li103),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a3519 in chkstrlst in %process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3520,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...){
C_word tmp;
C_word t9;
va_list v;
C_word *a,c2=c;
C_save_rest(t8,c2,9);
if(c<9) C_bad_min_argc_2(c,9,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr9r,(void*)f_3390r,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
else{
a=C_alloc((c-9)*3);
t9=C_restore_rest(a,C_rest_count(0));
f_3390r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}}

static void C_ccall f_3390r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3394,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=t7,a[6]=t8,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t9))){
t11=t10;
f_3394(2,t11,C_SCHEME_FALSE);}
else{
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
t12=t10;
f_3394(2,t12,(C_word)C_i_car(t9));}
else{
/* ##sys#error */
t12=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,lf[2],t9);}}}

/* k3392 in ##sys#process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3485,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[2]);
/* posixwin.scm: 1796 $quote-args-list */
t5=lf[249];
f_2880(t5,t3,t4,t1);}

/* k3483 in k3392 in ##sys#process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1796 string-intersperse */
t2=*((C_word*)lf[274]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3395 in k3392 in ##sys#process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3397,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t4=((*(int *)C_data_pointer(t2))=C_unfix(t3),C_SCHEME_UNDEFINED);
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t6=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t7=((*(int *)C_data_pointer(t5))=C_unfix(t6),C_SCHEME_UNDEFINED);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t9=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t10=((*(int *)C_data_pointer(t8))=C_unfix(t9),C_SCHEME_UNDEFINED);
t11=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t12=(C_word)C_i_foreign_fixnum_argumentp(C_fix(-1));
t13=((*(int *)C_data_pointer(t11))=C_unfix(t12),C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3453,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=t11,a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
/* ##sys#make-locative */
t15=*((C_word*)lf[272]+1);
((C_proc6)C_retrieve_proc(t15))(6,t15,t14,t2,C_fix(0),C_SCHEME_FALSE,lf[273]);}

/* k3451 in k3395 in k3392 in ##sys#process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[272]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[5],C_fix(0),C_SCHEME_FALSE,lf[273]);}

/* k3455 in k3451 in k3395 in k3392 in ##sys#process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3461,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[272]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[3],C_fix(0),C_SCHEME_FALSE,lf[273]);}

/* k3459 in k3455 in k3451 in k3395 in k3392 in ##sys#process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[272]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,((C_word*)t0)[7],C_fix(0),C_SCHEME_FALSE,lf[273]);}

/* k3463 in k3459 in k3455 in k3451 in k3395 in k3392 in ##sys#process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[6])?C_fix(0):C_fix(1));
t4=(C_truep(((C_word*)t0)[4])?C_fix(0):C_fix(2));
t5=(C_truep(((C_word*)t0)[8])?C_fix(0):C_fix(4));
/* posixwin.scm: 1803 + */
C_plus(5,0,t2,t3,t4,t5);}

/* k3467 in k3463 in k3459 in k3455 in k3451 in k3395 in k3392 in ##sys#process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3469,2,t0,t1);}
t2=((C_word*)t0)[16];
t3=((C_word*)t0)[15];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[13];
t6=((C_word*)t0)[12];
t7=((C_word*)t0)[11];
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3332,a[2]=t3,a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=t1,a[14]=t7,a[15]=t6,a[16]=t5,a[17]=t4,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
t9=(C_word)C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_3332(2,t9,C_SCHEME_FALSE);}}

/* k3330 in k3467 in k3463 in k3459 in k3455 in k3451 in k3395 in k3392 in ##sys#process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=t1,a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_3336(2,t3,C_SCHEME_FALSE);}}

/* k3334 in k3330 in k3467 in k3463 in k3459 in k3455 in k3451 in k3395 in k3392 in ##sys#process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3336,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[17]):C_SCHEME_FALSE);
t3=(C_truep(((C_word*)t0)[16])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[16]):C_SCHEME_FALSE);
t4=(C_truep(((C_word*)t0)[15])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[15]):C_SCHEME_FALSE);
t5=(C_truep(((C_word*)t0)[14])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[14]):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[13]);
if(C_truep((C_word)stub556(C_SCHEME_UNDEFINED,((C_word*)t0)[12],t1,C_SCHEME_FALSE,t2,t3,t4,t5,t6))){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3426,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixwin.scm: 1806 open-input-file* */
t8=*((C_word*)lf[201]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[4]))));}
else{
t8=t7;
f_3426(2,t8,C_SCHEME_FALSE);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1811 ##sys#update-errno */
t8=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k3444 in k3334 in k3330 in k3467 in k3463 in k3459 in k3455 in k3451 in k3395 in k3392 in ##sys#process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1812 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[270],((C_word*)t0)[3],lf[271],((C_word*)t0)[2]);}

/* k3424 in k3334 in k3330 in k3467 in k3463 in k3459 in k3455 in k3451 in k3395 in k3392 in ##sys#process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3430,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1807 open-output-file* */
t3=*((C_word*)lf[202]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_3430(2,t3,C_SCHEME_FALSE);}}

/* k3428 in k3424 in k3334 in k3330 in k3467 in k3463 in k3459 in k3455 in k3451 in k3395 in k3392 in ##sys#process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3434,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1809 open-input-file* */
t3=*((C_word*)lf[201]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_3434(2,t3,C_SCHEME_FALSE);}}

/* k3432 in k3428 in k3424 in k3334 in k3330 in k3467 in k3463 in k3459 in k3455 in k3451 in k3395 in k3392 in ##sys#process in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1805 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))),t1);}

/* close-handle in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3324,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub544(C_SCHEME_UNDEFINED,t2));}

/* process-run in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3295r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3295r(t0,t1,t2,t3);}}

static void C_ccall f_3295r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t5)){
/* posixwin.scm: 1764 process-spawn */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,*((C_word*)lf[244]+1),t2,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3312,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1765 ##sys#shell-command */
t7=*((C_word*)lf[261]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}}

/* k3310 in process-run in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3316,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1765 ##sys#shell-command-arguments */
t3=*((C_word*)lf[265]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3314 in k3310 in process-run in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1765 process-spawn */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[244]+1),((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3289(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3289,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[266],t2));}

/* ##sys#shell-command in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3272,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1748 getenv */
t3=*((C_word*)lf[263]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[264]);}

/* k3270 in ##sys#shell-command in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3272,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_get_shlcmd())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_shlcmd),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3284,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1752 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k3282 in k3270 in ##sys#shell-command in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1753 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[261],lf[262]);}

/* current-process-id in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3265,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub532(C_SCHEME_UNDEFINED));}

/* process-spawn in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_3178r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3178r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3178r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3180,a[2]=t3,a[3]=t2,a[4]=((C_word)li92),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3192,a[2]=t5,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3197,a[2]=t6,a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3202,a[2]=t7,a[3]=((C_word)li95),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-arglst511525 */
t9=t8;
f_3202(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-envlst512523 */
t11=t7;
f_3197(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-exactf513520 */
t13=t6;
f_3192(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body509515 */
t15=t5;
f_3180(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[2],t14);}}}}}

/* def-arglst511 in process-spawn in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3202(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3202,NULL,2,t0,t1);}
/* def-envlst512523 */
t2=((C_word*)t0)[2];
f_3197(t2,t1,C_SCHEME_FALSE);}

/* def-envlst512 in process-spawn in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3197(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3197,NULL,3,t0,t1,t2);}
/* def-exactf513520 */
t3=((C_word*)t0)[2];
f_3192(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf513 in process-spawn in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3192(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3192,NULL,4,t0,t1,t2,t3);}
/* body509515 */
t4=((C_word*)t0)[2];
f_3180(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body509 in process-spawn in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3180(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3180,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3184,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1739 $exec-setup */
t6=lf[254];
f_3043(t6,t5,lf[258],((C_word*)t0)[2],t2,t3,t4);}

/* k3182 in body509 in process-spawn in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_spawnvpe(((C_word*)t0)[4],t1):(C_word)C_spawnvp(((C_word*)t0)[4],t1));
/* posixwin.scm: 1740 $exec-teardown */
f_3076(((C_word*)t0)[3],lf[258],lf[259],((C_word*)t0)[2],t2);}

/* process-execute in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_3091r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3091r(t0,t1,t2,t3);}}

static void C_ccall f_3091r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(16);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3093,a[2]=t2,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3105,a[2]=t4,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3110,a[2]=t5,a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3115,a[2]=t6,a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglst481495 */
t8=t7;
f_3115(t8,t1);}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-envlst482493 */
t10=t6;
f_3110(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf483490 */
t12=t5;
f_3105(t12,t1,t8,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body479485 */
t14=t4;
f_3093(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[2],t13);}}}}}

/* def-arglst481 in process-execute in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3115(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3115,NULL,2,t0,t1);}
/* def-envlst482493 */
t2=((C_word*)t0)[2];
f_3110(t2,t1,C_SCHEME_FALSE);}

/* def-envlst482 in process-execute in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3110(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3110,NULL,3,t0,t1,t2);}
/* def-exactf483490 */
t3=((C_word*)t0)[2];
f_3105(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf483 in process-execute in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3105(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3105,NULL,4,t0,t1,t2,t3);}
/* body479485 */
t4=((C_word*)t0)[2];
f_3093(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body479 in process-execute in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3093(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3093,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3097,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1734 $exec-setup */
t6=lf[254];
f_3043(t6,t5,lf[256],((C_word*)t0)[2],t2,t3,t4);}

/* k3095 in body479 in process-execute in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
/* posixwin.scm: 1735 $exec-teardown */
f_3076(((C_word*)t0)[3],lf[256],lf[257],((C_word*)t0)[2],t2);}

/* $exec-teardown in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3076(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3076,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3080,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1726 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k3078 in $exec-teardown in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_free_exec_args();
t3=(C_word)C_free_exec_env();
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(-1));
if(C_truep(t4)){
/* posixwin.scm: 1730 ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[6]);}}

/* $exec-setup in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3043(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3043,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t3,t2);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3050,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=t3,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1718 pathname-strip-directory */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k3048 in $exec-setup in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_block_size(t1);
/* posixwin.scm: 1719 setarg */
t4=((C_word*)t0)[4];
f_2959(5,t4,t2,C_fix(0),t1,t3);}

/* k3051 in k3048 in $exec-setup in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3056,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3070,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1720 $quote-args-list */
t4=lf[249];
f_2880(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3068 in k3051 in k3048 in $exec-setup in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1720 build-exec-argvec */
f_2993(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_fix(1));}

/* k3054 in k3051 in k3048 in $exec-setup in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1721 build-exec-argvec */
f_2993(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k3057 in k3054 in k3051 in k3048 in $exec-setup in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3059,2,t0,t1);}
t2=(C_word)C_flushall();
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3066,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1723 ##sys#expand-home-path */
t4=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3064 in k3057 in k3054 in k3051 in k3048 in $exec-setup in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1723 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* build-exec-argvec in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2993(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2993,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep(t3)){
t6=(C_word)C_i_check_list_2(t3,t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3005,a[2]=t8,a[3]=t2,a[4]=t4,a[5]=((C_word)li83),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3005(t10,t1,t3,t5);}
else{
/* posixwin.scm: 1715 argvec-setter */
t6=t4;
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t5,C_SCHEME_FALSE,C_fix(0));}}

/* do446 in build-exec-argvec in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3005(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3005,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1711 argvec-setter */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t3,C_SCHEME_FALSE,C_fix(0));}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3024,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_block_size(t4);
/* posixwin.scm: 1714 argvec-setter */
t8=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,t3,t4,t7);}}

/* k3022 in do446 in build-exec-argvec in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3005(t4,((C_word*)t0)[2],t2,t3);}

/* setenv in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2976,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub435(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* setarg in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2959,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub425(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* $quote-args-list in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2880(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2880,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2885,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li78),tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2923,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word)li79),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2923(t8,t1,t2,C_SCHEME_END_OF_LIST);}}

/* loop in $quote-args-list in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2923(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2923,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1692 reverse */
t4=*((C_word*)lf[250]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2951,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2954,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1697 needs-quoting? */
t8=((C_word*)t0)[2];
f_2885(t8,t7,t4);}}

/* k2952 in loop in $quote-args-list in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixwin.scm: 1697 string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[251],((C_word*)t0)[2],lf[252]);}
else{
t2=((C_word*)t0)[3];
f_2951(2,t2,((C_word*)t0)[2]);}}

/* k2949 in loop in $quote-args-list in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2951,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* posixwin.scm: 1694 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2923(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* needs-quoting? in $quote-args-list in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2885(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2885,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2889,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1684 string-length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2887 in needs-quoting? in $quote-args-list in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2889,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2894,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t1,a[7]=((C_word)li77),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2894(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k2887 in needs-quoting? in $quote-args-list in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2894(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2894,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2907,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2918,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1688 string-ref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k2916 in loop in k2887 in needs-quoting? in $quote-args-list in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1688 char-whitespace? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2905 in loop in k2887 in needs-quoting? in $quote-args-list in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1689 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2894(t3,((C_word*)t0)[4],t2);}}

/* glob in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_2765r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2765r(t0,t1,t2);}}

static void C_ccall f_2765r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(13);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2771,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],a[10]=((C_word)li75),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_2771(t6,t1,t2);}

/* conc-loop in glob in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2771(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2771,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2786,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li74),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a2791 in conc-loop in glob in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2792,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2869,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[241]);
/* posixwin.scm: 1645 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k2867 in a2791 in conc-loop in glob in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1645 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2794 in a2791 in conc-loop in glob in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 1646 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2797 in k2794 in a2791 in conc-loop in glob in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2802,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1647 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2800 in k2797 in k2794 in a2791 in conc-loop in glob in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2809,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[240]);
/* posixwin.scm: 1648 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k2807 in k2800 in k2797 in k2794 in a2791 in conc-loop in glob in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2809,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2811,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li73),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_2811(t5,((C_word*)t0)[2],t1);}

/* loop in k2807 in k2800 in k2797 in k2794 in a2791 in conc-loop in glob in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2811(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2811,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixwin.scm: 1649 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_2771(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixwin.scm: 1650 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k2826 in loop in k2807 in k2800 in k2797 in k2794 in a2791 in conc-loop in glob in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2828,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2838,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixwin.scm: 1651 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixwin.scm: 1652 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2811(t3,((C_word*)t0)[6],t2);}}

/* k2836 in k2826 in loop in k2807 in k2800 in k2797 in k2794 in a2791 in conc-loop in glob in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2842,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixwin.scm: 1651 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2811(t4,t2,t3);}

/* k2840 in k2836 in k2826 in loop in k2807 in k2800 in k2797 in k2794 in a2791 in conc-loop in glob in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2842,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a2785 in conc-loop in glob in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2786,2,t0,t1);}
/* posixwin.scm: 1644 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* set-buffering-mode! in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2706r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2706r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2706r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2710,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1615 ##sys#check-port */
t6=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[227]);}

/* k2708 in set-buffering-mode! in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2710,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[229]);
if(C_truep(t6)){
t7=t5;
f_2716(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[230]);
if(C_truep(t7)){
t8=t5;
f_2716(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[231]);
if(C_truep(t8)){
t9=t5;
f_2716(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixwin.scm: 1621 ##sys#error */
t9=*((C_word*)lf[62]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[227],lf[232],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k2714 in k2708 in set-buffering-mode! in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[227]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[74],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixwin.scm: 1627 ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[227],lf[228],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* _exit in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2690r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2690r(t0,t1,t2);}}

static void C_ccall f_2690r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub354(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub349(t2),C_fix(0));}

/* local-time->seconds in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2650,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[221]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2657,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1591 ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[221],lf[224],t2);}
else{
t6=t4;
f_2657(2,t6,C_SCHEME_UNDEFINED);}}

/* k2655 in local-time->seconds in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixwin.scm: 1593 ##sys#cons-flonum */
t2=*((C_word*)lf[222]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1594 ##sys#error */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[221],lf[223],((C_word*)t0)[3]);}}

/* time->string in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2611,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[218]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2618,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1584 ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[218],lf[220],t2);}
else{
t6=t4;
f_2618(2,t6,C_SCHEME_UNDEFINED);}}

/* k2616 in time->string in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub337(t4,t3),C_fix(0));}

/* k2619 in k2616 in time->string in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2624,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2624(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1586 ##sys#error */
t3=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[218],lf[219],((C_word*)t0)[2]);}}

/* k2622 in k2619 in k2616 in time->string in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1587 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),t3);}

/* seconds->string in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2583,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2587,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub328(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k2585 in seconds->string in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2590,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2590(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1577 ##sys#error */
t3=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[216],lf[217],((C_word*)t0)[2]);}}

/* k2588 in k2585 in seconds->string in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1578 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),t3);}

/* seconds->utc-time in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2564,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[215]);
/* posixwin.scm: 1571 ##sys#decode-seconds */
t4=*((C_word*)lf[214]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2555,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[213]);
/* posixwin.scm: 1567 ##sys#decode-seconds */
t4=*((C_word*)lf[214]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* current-environment in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2490,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2496(t5,t1,C_fix(0));}

/* loop in current-environment in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2496(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2496,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2500,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub311(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k2498 in loop in current-environment in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2500,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2508,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word)li61),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2508(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k2498 in loop in current-environment in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2508(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2508,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[6],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2534,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1559 substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixwin.scm: 1560 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k2532 in scan in k2498 in loop in current-environment in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2538,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[3]);
/* posixwin.scm: 1559 substring */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,((C_word*)t0)[3],t3,t4);}

/* k2536 in k2532 in scan in k2498 in loop in current-environment in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2538,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2526,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1559 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2496(t5,t3,t4);}

/* k2524 in k2536 in k2532 in scan in k2498 in loop in current-environment in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2526,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2470,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[210]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2478,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1547 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2476 in unsetenv in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2453,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[209]);
t5=(C_word)C_i_check_string_2(t3,lf[209]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2464,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1542 ##sys#make-c-string */
t7=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k2462 in setenv in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2468,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1542 ##sys#make-c-string */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2466 in k2462 in setenv in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2423r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2423r(t0,t1,t2,t3);}}

static void C_ccall f_2423r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[207]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2430,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_2430(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[207]);
t8=t5;
f_2430(t8,(C_word)C_dup2(t2,t6));}}

/* k2428 in duplicate-fileno in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2430,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2433,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1532 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2433(2,t3,C_SCHEME_UNDEFINED);}}

/* k2437 in k2428 in duplicate-fileno in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1533 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[207],lf[208],((C_word*)t0)[2]);}

/* k2431 in k2428 in duplicate-fileno in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2388,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2392,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1514 ##sys#check-port */
t4=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[203]);}

/* k2390 in port->fileno in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1515 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k2419 in k2390 in port->fileno in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2421,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixwin.scm: 1521 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[46],lf[203],lf[204],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2401,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1518 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_2401(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2405 in k2419 in k2390 in port->fileno in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1519 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[203],lf[205],((C_word*)t0)[2]);}

/* k2399 in k2419 in k2390 in port->fileno in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2374r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2374r(t0,t1,t2,t3);}}

static void C_ccall f_2374r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[202]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2386,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1510 mode */
f_2305(t5,C_SCHEME_FALSE,t3);}

/* k2384 in open-output-file* in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2386,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1510 check */
f_2342(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2360r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2360r(t0,t1,t2,t3);}}

static void C_ccall f_2360r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[201]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2372,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1506 mode */
f_2305(t5,C_SCHEME_TRUE,t3);}

/* k2370 in open-input-file* in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2372,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1506 check */
f_2342(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2342(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2342,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2346,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1497 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2344 in check in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2346,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1499 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[199],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2358,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1500 ##sys#make-port */
t3=*((C_word*)lf[99]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[100]+1),lf[200],lf[74]);}}

/* k2356 in k2344 in check in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2305(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2305,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2313,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[193]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixwin.scm: 1492 ##sys#error */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[194],t5);}
else{
t8=t4;
f_2313(2,t8,lf[195]);}}
else{
/* posixwin.scm: 1493 ##sys#error */
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[196],t5);}}
else{
t5=t4;
f_2313(2,t5,(C_truep(t2)?lf[197]:lf[198]));}}

/* k2311 in mode in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1488 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-execute-access? in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2296,3,t0,t1,t2);}
/* posixwin.scm: 1472 check */
f_2260(t1,t2,C_fix((C_word)2),lf[189]);}

/* file-write-access? in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2290,3,t0,t1,t2);}
/* posixwin.scm: 1471 check */
f_2260(t1,t2,C_fix((C_word)4),lf[188]);}

/* file-read-access? in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2284,3,t0,t1,t2);}
/* posixwin.scm: 1470 check */
f_2260(t1,t2,C_fix((C_word)2),lf[187]);}

/* check in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2260(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2260,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2278,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2282,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1467 ##sys#expand-home-path */
t8=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k2280 in check in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1467 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2276 in check in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2278,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2270,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2270(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1468 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2268 in k2276 in check in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-mode in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2230,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[185]);
t5=(C_word)C_i_check_exact_2(t3,lf[185]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2254,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2258,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1456 ##sys#expand-home-path */
t8=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}

/* k2256 in change-file-mode in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1456 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2252 in change-file-mode in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2254,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2246,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1457 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2244 in k2252 in change-file-mode in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1458 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[185],lf[186],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#interrupt-hook in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2174,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2184,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1364 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1366 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k2182 in ##sys#interrupt-hook in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1365 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2161,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[146]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k2148 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2152,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[145]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2076r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2076r(t0,t1,t2);}}

static void C_ccall f_2076r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2080,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2080(2,t4,(C_word)C_fixnum_or(*((C_word*)lf[21]+1),*((C_word*)lf[23]+1)));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2080(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[2],t2);}}}

/* k2078 in create-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2083,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE,t1),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2092,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1301 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2083(2,t3,C_SCHEME_UNDEFINED);}}

/* k2090 in k2078 in create-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1302 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[37],lf[115],lf[116]);}

/* k2081 in k2078 in create-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1303 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2056r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2056r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2056r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[114]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2060,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2058 in with-output-to-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2060,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2066,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li42),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1286 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2065 in k2058 in with-output-to-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2066(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2066r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2066r(t0,t1,t2);}}

static void C_ccall f_2066r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2070,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1288 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2068 in a2065 in k2058 in with-output-to-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[114]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2036r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2036r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2036r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[112]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2040,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2038 in with-input-from-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2040,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2046,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li40),tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1276 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2045 in k2038 in with-input-from-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2046r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2046r(t0,t1,t2);}}

static void C_ccall f_2046r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2050,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1278 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2048 in a2045 in k2038 in with-input-from-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[112]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2012r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2012r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2012r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2016,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k2014 in call-with-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2021,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li37),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2027,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li38),tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1266 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2026 in k2014 in call-with-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2027r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2027r(t0,t1,t2);}}

static void C_ccall f_2027r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2031,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1269 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2029 in a2026 in k2014 in call-with-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2020 in k2014 in call-with-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2021,2,t0,t1);}
/* posixwin.scm: 1267 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1988r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1988r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1988r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1992,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k1990 in call-with-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1997,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li34),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2003,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li35),tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1258 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2002 in k1990 in call-with-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2003r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2003r(t0,t1,t2);}}

static void C_ccall f_2003r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2007,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1261 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2005 in a2002 in k1990 in call-with-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1996 in k1990 in call-with-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1997,2,t0,t1);}
/* posixwin.scm: 1259 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1969(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1969,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1973,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1245 ##sys#check-port */
t4=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[105]);}

/* k1971 in close-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1976,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1247 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1974 in k1971 in close-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t2)){
/* posixwin.scm: 1248 ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[37],lf[105],lf[106],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* open-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_1933r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1933r(t0,t1,t2,t3);}}

static void C_ccall f_1933r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[104]);
t5=f_1861(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1947,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[96]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1954,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1240 ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[103]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1964,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1241 ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1242 badmode */
f_1873(t6,t5);}}}

/* k1962 in open-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1947(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k1952 in open-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1954,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1947(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k1945 in open-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1237 check */
f_1879(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_1897r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1897r(t0,t1,t2,t3);}}

static void C_ccall f_1897r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[102]);
t5=f_1861(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1911,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[96]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1918,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1230 ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[103]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1928,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1231 ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1232 badmode */
f_1873(t6,t5);}}}

/* k1926 in open-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1911(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k1916 in open-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1918,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1911(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k1909 in open-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1227 check */
f_1879(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1879(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1879,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1883,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1217 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k1881 in check in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1219 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[98],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1895,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1220 ##sys#make-port */
t3=*((C_word*)lf[99]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[100]+1),lf[101],lf[74]);}}

/* k1893 in k1881 in check in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1873(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1873,NULL,2,t1,t2);}
/* posixwin.scm: 1215 ##sys#error */
t3=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[97],t2);}

/* mode in k1068 in k1065 in k1062 in k1059 in k1056 */
static C_word C_fcall f_1861(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[96]));}

/* current-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1815r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1815r(t0,t1,t2);}}

static void C_ccall f_1815r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1819,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_1819(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_1819(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[2],t2);}}}

/* k1817 in current-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1819,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1202 change-directory */
t2=*((C_word*)lf[84]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1828,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1203 make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k1826 in k1817 in current-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1828,2,t0,t1);}
t2=(C_word)C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1831,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1205 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1829 in k1826 in k1817 in current-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* posixwin.scm: 1207 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4]);}
else{
/* posixwin.scm: 1208 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[92],lf[95]);}}

/* directory? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1788,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[93]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1795,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1809,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1813,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1195 ##sys#expand-home-path */
t7=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}

/* k1811 in directory? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1195 ##sys#platform-fixup-pathname */
t2=*((C_word*)lf[94]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1807 in directory? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1194 ##sys#file-info */
t2=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1793 in directory? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_1628r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1628r(t0,t1,t2);}}

static void C_ccall f_1628r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1630,a[2]=((C_word*)t0)[2],a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1731,a[2]=t3,a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1736,a[2]=t4,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec113139 */
t6=t5;
f_1736(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?114137 */
t8=t4;
f_1731(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body111116 */
t10=t3;
f_1630(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[2],t9);}}}}

/* def-spec113 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1736(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1736,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1744,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1165 current-directory */
t3=*((C_word*)lf[92]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1742 in def-spec113 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?114137 */
t2=((C_word*)t0)[3];
f_1731(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?114 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1731(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1731,NULL,3,t0,t1,t2);}
/* body111116 */
t3=((C_word*)t0)[2];
f_1630(t3,t1,t2,C_SCHEME_FALSE);}

/* body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1630(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1630,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[89]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1637,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1167 make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k1635 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1640,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1168 ##sys#make-pointer */
t3=*((C_word*)lf[91]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1638 in k1635 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1169 ##sys#make-pointer */
t3=*((C_word*)lf[91]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1641 in k1638 in k1635 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1730,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1170 ##sys#expand-home-path */
t4=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k1728 in k1641 in k1638 in k1635 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1170 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1645 in k1641 in k1638 in k1635 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1647,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1173 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1664,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word)li21),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_1664(t6,((C_word*)t0)[6]);}}

/* loop in k1645 in k1641 in k1638 in k1635 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1664(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1664,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1674,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1182 ##sys#substring */
t5=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k1672 in loop in k1645 in k1641 in k1638 in k1635 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1674,2,t0,t1);}
t2=(C_word)C_i_string_ref(t1,C_fix(0));
t3=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(1));
t4=(C_truep(t3)?(C_word)C_i_string_ref(t1,C_fix(1)):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1686,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t2,C_make_character(46));
if(C_truep(t6)){
t7=(C_word)C_i_not(t4);
if(C_truep(t7)){
t8=t5;
f_1686(t8,t7);}
else{
t8=(C_word)C_eqp(t4,C_make_character(46));
t9=(C_truep(t8)?(C_word)C_eqp(((C_word*)t0)[5],C_fix(2)):C_SCHEME_FALSE);
t10=t5;
f_1686(t10,(C_truep(t9)?t9:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t7=t5;
f_1686(t7,C_SCHEME_FALSE);}}

/* k1684 in k1672 in loop in k1645 in k1641 in k1638 in k1635 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1686,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1189 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1664(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1190 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1664(t3,t2);}}

/* k1694 in k1684 in k1672 in loop in k1645 in k1641 in k1638 in k1635 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1654 in k1645 in k1641 in k1638 in k1635 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1174 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[89],lf[90],((C_word*)t0)[2]);}

/* delete-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1601,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1622,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1626,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1157 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1624 in delete-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1157 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1620 in delete-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1622,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1158 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1612 in k1620 in delete-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1159 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[86],lf[87],((C_word*)t0)[2]);}

/* change-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1574,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1595,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1599,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1150 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1597 in change-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1150 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1593 in change-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1595,2,t0,t1);}
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1151 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1585 in k1593 in change-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1152 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[84],lf[85],((C_word*)t0)[2]);}

/* create-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1547,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[82]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1568,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1572,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1143 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1570 in create-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1143 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1566 in create-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1568,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1144 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1558 in k1566 in create-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1145 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[82],lf[83],((C_word*)t0)[2]);}

/* set-file-position! in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1486r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1486r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1486r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[77]);
t8=(C_word)C_i_check_exact_2(t6,lf[77]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1499,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixwin.scm: 1128 ##sys#signal-hook */
t10=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[80],lf[77],lf[81],t3,t2);}
else{
t10=t9;
f_1499(2,t10,C_SCHEME_UNDEFINED);}}

/* k1497 in set-file-position! in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1129 port? */
t4=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k1512 in k1497 in set-file-position! in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[74]);
t4=((C_word*)t0)[4];
f_1505(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_1505(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixwin.scm: 1133 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[46],lf[77],lf[79],((C_word*)t0)[5]);}}}

/* k1503 in k1497 in set-file-position! in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1134 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1506 in k1503 in k1497 in set-file-position! in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1135 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[77],lf[78],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* file-position in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1446,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1450,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1465,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1112 port? */
t5=*((C_word*)lf[76]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k1463 in file-position in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[74]);
t4=((C_word*)t0)[2];
f_1450(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_1450(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixwin.scm: 1117 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[46],lf[72],lf[75],((C_word*)t0)[3]);}}}

/* k1448 in file-position in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1453,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1459,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1119 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_1453(2,t3,C_SCHEME_UNDEFINED);}}

/* k1457 in k1448 in file-position in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1120 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[72],lf[73],((C_word*)t0)[2]);}

/* k1451 in k1448 in file-position in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* symbolic-link? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1440,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* regular-file? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1417(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1417,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[69]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1424,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1438,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1103 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k1436 in regular-file? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1103 ##sys#file-info */
t2=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1422 in regular-file? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(0),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* file-permissions in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1411(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1411,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1415,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1099 ##sys#stat */
f_1312(t3,t2);}

/* k1413 in file-permissions in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1405,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1409,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1098 ##sys#stat */
f_1312(t3,t2);}

/* k1407 in file-owner in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1399,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1403,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1097 ##sys#stat */
f_1312(t3,t2);}

/* k1401 in file-change-time in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1403,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1393(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1393,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1397,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1096 ##sys#stat */
f_1312(t3,t2);}

/* k1395 in file-access-time in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1397,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1387,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1391,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1095 ##sys#stat */
f_1312(t3,t2);}

/* k1389 in file-modification-time in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1391,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1381(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1381,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1385,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1094 ##sys#stat */
f_1312(t3,t2);}

/* k1383 in file-size in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1350(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1350r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1350r(t0,t1,t2,t3);}}

static void C_ccall f_1350r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1354,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_1354(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_1354(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[2],t3);}}}

/* k1352 in file-stat in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1357,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1088 ##sys#stat */
f_1312(t2,((C_word*)t0)[2]);}

/* k1355 in k1352 in file-stat in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1357,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(0),C_fix(0),C_fix(0),C_fix(0)));}

/* ##sys#stat in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1312(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1312,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1316,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_1316(2,t4,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1341,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1345,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1081 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1082 ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[46],lf[60],t2);}}}

/* k1343 in ##sys#stat in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1081 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1339 in ##sys#stat in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1316(2,t2,(C_word)C_stat(t1));}

/* k1314 in ##sys#stat in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1316,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1084 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1323 in k1314 in ##sys#stat in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1085 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[59],((C_word*)t0)[2]);}

/* file-mkstemp in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1274(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1274,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[52]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1281,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1050 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1279 in file-mkstemp in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1281,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1284,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1052 string-length */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k1282 in k1279 in file-mkstemp in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1287,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1304,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1054 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_1287(2,t4,C_SCHEME_UNDEFINED);}}

/* k1302 in k1282 in k1279 in file-mkstemp in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1055 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[52],lf[54],((C_word*)t0)[2]);}

/* k1285 in k1282 in k1279 in file-mkstemp in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1056 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k1292 in k1285 in k1282 in k1279 in file-mkstemp in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1056 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1232r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1232r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1232r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[48]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1239,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_1239(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1037 ##sys#signal-hook */
t8=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[46],lf[48],lf[50],t3);}}

/* k1237 in file-write in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1239,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[48]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1248,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1254,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1042 ##sys#update-errno */
t9=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_1248(2,t8,C_SCHEME_UNDEFINED);}}

/* k1252 in k1237 in file-write in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1043 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[48],lf[49],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1246 in k1237 in file-write in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1187r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1187r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1187r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[44]);
t6=(C_word)C_i_check_exact_2(t3,lf[44]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1197,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_1197(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixwin.scm: 1024 make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k1195 in file-read in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1200(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1026 ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[46],lf[44],lf[47],t1);}}

/* k1198 in k1195 in file-read in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1200,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1203,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1212,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1029 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1203(2,t5,C_SCHEME_UNDEFINED);}}

/* k1210 in k1198 in k1195 in file-read in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1030 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[44],lf[45],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1201 in k1198 in k1195 in file-read in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1203,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1169,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[41]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1182,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1016 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1180 in file-close in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1017 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[41],lf[42],((C_word*)t0)[2]);}

/* file-open in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1128(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1128r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1128r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1128r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[36]);
t8=(C_word)C_i_check_exact_2(t3,lf[36]);
t9=(C_word)C_i_check_exact_2(t6,lf[36]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1145,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1161,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1006 ##sys#expand-home-path */
t12=*((C_word*)lf[40]+1);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t2);}

/* k1159 in file-open in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1006 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1143 in file-open in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1145,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1148,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1154,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1008 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1148(2,t5,C_SCHEME_UNDEFINED);}}

/* k1152 in k1143 in file-open in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1009 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],lf[37],lf[36],lf[38],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1146 in k1143 in file-open in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* posix-error in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_1082r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1082r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1082r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1086,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 937  ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1084 in posix-error in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1093,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1097,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub3(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k1095 in k1084 in posix-error in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 938  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[7],t1);}

/* k1091 in k1084 in posix-error in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[6]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[377] = {
{"toplevelposixwin.scm",(void*)C_posix_toplevel},
{"f_1058posixwin.scm",(void*)f_1058},
{"f_1061posixwin.scm",(void*)f_1061},
{"f_1064posixwin.scm",(void*)f_1064},
{"f_1067posixwin.scm",(void*)f_1067},
{"f_1070posixwin.scm",(void*)f_1070},
{"f_2150posixwin.scm",(void*)f_2150},
{"f_4352posixwin.scm",(void*)f_4352},
{"f_4349posixwin.scm",(void*)f_4349},
{"f_4342posixwin.scm",(void*)f_4342},
{"f_4336posixwin.scm",(void*)f_4336},
{"f_4330posixwin.scm",(void*)f_4330},
{"f_4324posixwin.scm",(void*)f_4324},
{"f_4318posixwin.scm",(void*)f_4318},
{"f_4312posixwin.scm",(void*)f_4312},
{"f_4306posixwin.scm",(void*)f_4306},
{"f_4300posixwin.scm",(void*)f_4300},
{"f_4294posixwin.scm",(void*)f_4294},
{"f_4288posixwin.scm",(void*)f_4288},
{"f_4282posixwin.scm",(void*)f_4282},
{"f_4276posixwin.scm",(void*)f_4276},
{"f_4270posixwin.scm",(void*)f_4270},
{"f_4264posixwin.scm",(void*)f_4264},
{"f_4258posixwin.scm",(void*)f_4258},
{"f_4252posixwin.scm",(void*)f_4252},
{"f_4246posixwin.scm",(void*)f_4246},
{"f_4240posixwin.scm",(void*)f_4240},
{"f_4234posixwin.scm",(void*)f_4234},
{"f_4228posixwin.scm",(void*)f_4228},
{"f_4222posixwin.scm",(void*)f_4222},
{"f_4216posixwin.scm",(void*)f_4216},
{"f_4210posixwin.scm",(void*)f_4210},
{"f_4204posixwin.scm",(void*)f_4204},
{"f_4198posixwin.scm",(void*)f_4198},
{"f_4192posixwin.scm",(void*)f_4192},
{"f_4186posixwin.scm",(void*)f_4186},
{"f_4180posixwin.scm",(void*)f_4180},
{"f_4174posixwin.scm",(void*)f_4174},
{"f_4168posixwin.scm",(void*)f_4168},
{"f_4162posixwin.scm",(void*)f_4162},
{"f_4156posixwin.scm",(void*)f_4156},
{"f_4150posixwin.scm",(void*)f_4150},
{"f_4144posixwin.scm",(void*)f_4144},
{"f_4138posixwin.scm",(void*)f_4138},
{"f_4132posixwin.scm",(void*)f_4132},
{"f_4126posixwin.scm",(void*)f_4126},
{"f_4120posixwin.scm",(void*)f_4120},
{"f_4114posixwin.scm",(void*)f_4114},
{"f_4108posixwin.scm",(void*)f_4108},
{"f_4102posixwin.scm",(void*)f_4102},
{"f_4096posixwin.scm",(void*)f_4096},
{"f_4090posixwin.scm",(void*)f_4090},
{"f_3864posixwin.scm",(void*)f_3864},
{"f_4021posixwin.scm",(void*)f_4021},
{"f_4027posixwin.scm",(void*)f_4027},
{"f_4016posixwin.scm",(void*)f_4016},
{"f_4011posixwin.scm",(void*)f_4011},
{"f_3866posixwin.scm",(void*)f_3866},
{"f_3998posixwin.scm",(void*)f_3998},
{"f_4006posixwin.scm",(void*)f_4006},
{"f_3873posixwin.scm",(void*)f_3873},
{"f_3986posixwin.scm",(void*)f_3986},
{"f_3883posixwin.scm",(void*)f_3883},
{"f_3885posixwin.scm",(void*)f_3885},
{"f_3904posixwin.scm",(void*)f_3904},
{"f_3972posixwin.scm",(void*)f_3972},
{"f_3979posixwin.scm",(void*)f_3979},
{"f_3966posixwin.scm",(void*)f_3966},
{"f_3919posixwin.scm",(void*)f_3919},
{"f_3953posixwin.scm",(void*)f_3953},
{"f_3939posixwin.scm",(void*)f_3939},
{"f_3951posixwin.scm",(void*)f_3951},
{"f_3947posixwin.scm",(void*)f_3947},
{"f_3931posixwin.scm",(void*)f_3931},
{"f_3929posixwin.scm",(void*)f_3929},
{"f_3990posixwin.scm",(void*)f_3990},
{"f_3849posixwin.scm",(void*)f_3849},
{"f_3859posixwin.scm",(void*)f_3859},
{"f_3818posixwin.scm",(void*)f_3818},
{"f_3844posixwin.scm",(void*)f_3844},
{"f_3829posixwin.scm",(void*)f_3829},
{"f_3833posixwin.scm",(void*)f_3833},
{"f_3837posixwin.scm",(void*)f_3837},
{"f_3841posixwin.scm",(void*)f_3841},
{"f_3806posixwin.scm",(void*)f_3806},
{"f_3803posixwin.scm",(void*)f_3803},
{"f_3743posixwin.scm",(void*)f_3743},
{"f_3770posixwin.scm",(void*)f_3770},
{"f_3780posixwin.scm",(void*)f_3780},
{"f_3764posixwin.scm",(void*)f_3764},
{"f_3731posixwin.scm",(void*)f_3731},
{"f_3651posixwin.scm",(void*)f_3651},
{"f_3668posixwin.scm",(void*)f_3668},
{"f_3663posixwin.scm",(void*)f_3663},
{"f_3658posixwin.scm",(void*)f_3658},
{"f_3653posixwin.scm",(void*)f_3653},
{"f_3571posixwin.scm",(void*)f_3571},
{"f_3588posixwin.scm",(void*)f_3588},
{"f_3583posixwin.scm",(void*)f_3583},
{"f_3578posixwin.scm",(void*)f_3578},
{"f_3573posixwin.scm",(void*)f_3573},
{"f_3509posixwin.scm",(void*)f_3509},
{"f_3565posixwin.scm",(void*)f_3565},
{"f_3569posixwin.scm",(void*)f_3569},
{"f_3530posixwin.scm",(void*)f_3530},
{"f_3533posixwin.scm",(void*)f_3533},
{"f_3544posixwin.scm",(void*)f_3544},
{"f_3538posixwin.scm",(void*)f_3538},
{"f_3511posixwin.scm",(void*)f_3511},
{"f_3520posixwin.scm",(void*)f_3520},
{"f_3390posixwin.scm",(void*)f_3390},
{"f_3394posixwin.scm",(void*)f_3394},
{"f_3485posixwin.scm",(void*)f_3485},
{"f_3397posixwin.scm",(void*)f_3397},
{"f_3453posixwin.scm",(void*)f_3453},
{"f_3457posixwin.scm",(void*)f_3457},
{"f_3461posixwin.scm",(void*)f_3461},
{"f_3465posixwin.scm",(void*)f_3465},
{"f_3469posixwin.scm",(void*)f_3469},
{"f_3332posixwin.scm",(void*)f_3332},
{"f_3336posixwin.scm",(void*)f_3336},
{"f_3446posixwin.scm",(void*)f_3446},
{"f_3426posixwin.scm",(void*)f_3426},
{"f_3430posixwin.scm",(void*)f_3430},
{"f_3434posixwin.scm",(void*)f_3434},
{"f_3324posixwin.scm",(void*)f_3324},
{"f_3295posixwin.scm",(void*)f_3295},
{"f_3312posixwin.scm",(void*)f_3312},
{"f_3316posixwin.scm",(void*)f_3316},
{"f_3289posixwin.scm",(void*)f_3289},
{"f_3268posixwin.scm",(void*)f_3268},
{"f_3272posixwin.scm",(void*)f_3272},
{"f_3284posixwin.scm",(void*)f_3284},
{"f_3265posixwin.scm",(void*)f_3265},
{"f_3178posixwin.scm",(void*)f_3178},
{"f_3202posixwin.scm",(void*)f_3202},
{"f_3197posixwin.scm",(void*)f_3197},
{"f_3192posixwin.scm",(void*)f_3192},
{"f_3180posixwin.scm",(void*)f_3180},
{"f_3184posixwin.scm",(void*)f_3184},
{"f_3091posixwin.scm",(void*)f_3091},
{"f_3115posixwin.scm",(void*)f_3115},
{"f_3110posixwin.scm",(void*)f_3110},
{"f_3105posixwin.scm",(void*)f_3105},
{"f_3093posixwin.scm",(void*)f_3093},
{"f_3097posixwin.scm",(void*)f_3097},
{"f_3076posixwin.scm",(void*)f_3076},
{"f_3080posixwin.scm",(void*)f_3080},
{"f_3043posixwin.scm",(void*)f_3043},
{"f_3050posixwin.scm",(void*)f_3050},
{"f_3053posixwin.scm",(void*)f_3053},
{"f_3070posixwin.scm",(void*)f_3070},
{"f_3056posixwin.scm",(void*)f_3056},
{"f_3059posixwin.scm",(void*)f_3059},
{"f_3066posixwin.scm",(void*)f_3066},
{"f_2993posixwin.scm",(void*)f_2993},
{"f_3005posixwin.scm",(void*)f_3005},
{"f_3024posixwin.scm",(void*)f_3024},
{"f_2976posixwin.scm",(void*)f_2976},
{"f_2959posixwin.scm",(void*)f_2959},
{"f_2880posixwin.scm",(void*)f_2880},
{"f_2923posixwin.scm",(void*)f_2923},
{"f_2954posixwin.scm",(void*)f_2954},
{"f_2951posixwin.scm",(void*)f_2951},
{"f_2885posixwin.scm",(void*)f_2885},
{"f_2889posixwin.scm",(void*)f_2889},
{"f_2894posixwin.scm",(void*)f_2894},
{"f_2918posixwin.scm",(void*)f_2918},
{"f_2907posixwin.scm",(void*)f_2907},
{"f_2765posixwin.scm",(void*)f_2765},
{"f_2771posixwin.scm",(void*)f_2771},
{"f_2792posixwin.scm",(void*)f_2792},
{"f_2869posixwin.scm",(void*)f_2869},
{"f_2796posixwin.scm",(void*)f_2796},
{"f_2799posixwin.scm",(void*)f_2799},
{"f_2802posixwin.scm",(void*)f_2802},
{"f_2809posixwin.scm",(void*)f_2809},
{"f_2811posixwin.scm",(void*)f_2811},
{"f_2828posixwin.scm",(void*)f_2828},
{"f_2838posixwin.scm",(void*)f_2838},
{"f_2842posixwin.scm",(void*)f_2842},
{"f_2786posixwin.scm",(void*)f_2786},
{"f_2706posixwin.scm",(void*)f_2706},
{"f_2710posixwin.scm",(void*)f_2710},
{"f_2716posixwin.scm",(void*)f_2716},
{"f_2690posixwin.scm",(void*)f_2690},
{"f_2678posixwin.scm",(void*)f_2678},
{"f_2650posixwin.scm",(void*)f_2650},
{"f_2657posixwin.scm",(void*)f_2657},
{"f_2611posixwin.scm",(void*)f_2611},
{"f_2618posixwin.scm",(void*)f_2618},
{"f_2621posixwin.scm",(void*)f_2621},
{"f_2624posixwin.scm",(void*)f_2624},
{"f_2583posixwin.scm",(void*)f_2583},
{"f_2587posixwin.scm",(void*)f_2587},
{"f_2590posixwin.scm",(void*)f_2590},
{"f_2564posixwin.scm",(void*)f_2564},
{"f_2555posixwin.scm",(void*)f_2555},
{"f_2490posixwin.scm",(void*)f_2490},
{"f_2496posixwin.scm",(void*)f_2496},
{"f_2500posixwin.scm",(void*)f_2500},
{"f_2508posixwin.scm",(void*)f_2508},
{"f_2534posixwin.scm",(void*)f_2534},
{"f_2538posixwin.scm",(void*)f_2538},
{"f_2526posixwin.scm",(void*)f_2526},
{"f_2470posixwin.scm",(void*)f_2470},
{"f_2478posixwin.scm",(void*)f_2478},
{"f_2453posixwin.scm",(void*)f_2453},
{"f_2464posixwin.scm",(void*)f_2464},
{"f_2468posixwin.scm",(void*)f_2468},
{"f_2423posixwin.scm",(void*)f_2423},
{"f_2430posixwin.scm",(void*)f_2430},
{"f_2439posixwin.scm",(void*)f_2439},
{"f_2433posixwin.scm",(void*)f_2433},
{"f_2388posixwin.scm",(void*)f_2388},
{"f_2392posixwin.scm",(void*)f_2392},
{"f_2421posixwin.scm",(void*)f_2421},
{"f_2407posixwin.scm",(void*)f_2407},
{"f_2401posixwin.scm",(void*)f_2401},
{"f_2374posixwin.scm",(void*)f_2374},
{"f_2386posixwin.scm",(void*)f_2386},
{"f_2360posixwin.scm",(void*)f_2360},
{"f_2372posixwin.scm",(void*)f_2372},
{"f_2342posixwin.scm",(void*)f_2342},
{"f_2346posixwin.scm",(void*)f_2346},
{"f_2358posixwin.scm",(void*)f_2358},
{"f_2305posixwin.scm",(void*)f_2305},
{"f_2313posixwin.scm",(void*)f_2313},
{"f_2296posixwin.scm",(void*)f_2296},
{"f_2290posixwin.scm",(void*)f_2290},
{"f_2284posixwin.scm",(void*)f_2284},
{"f_2260posixwin.scm",(void*)f_2260},
{"f_2282posixwin.scm",(void*)f_2282},
{"f_2278posixwin.scm",(void*)f_2278},
{"f_2270posixwin.scm",(void*)f_2270},
{"f_2230posixwin.scm",(void*)f_2230},
{"f_2258posixwin.scm",(void*)f_2258},
{"f_2254posixwin.scm",(void*)f_2254},
{"f_2246posixwin.scm",(void*)f_2246},
{"f_2174posixwin.scm",(void*)f_2174},
{"f_2184posixwin.scm",(void*)f_2184},
{"f_2161posixwin.scm",(void*)f_2161},
{"f_2152posixwin.scm",(void*)f_2152},
{"f_2076posixwin.scm",(void*)f_2076},
{"f_2080posixwin.scm",(void*)f_2080},
{"f_2092posixwin.scm",(void*)f_2092},
{"f_2083posixwin.scm",(void*)f_2083},
{"f_2056posixwin.scm",(void*)f_2056},
{"f_2060posixwin.scm",(void*)f_2060},
{"f_2066posixwin.scm",(void*)f_2066},
{"f_2070posixwin.scm",(void*)f_2070},
{"f_2036posixwin.scm",(void*)f_2036},
{"f_2040posixwin.scm",(void*)f_2040},
{"f_2046posixwin.scm",(void*)f_2046},
{"f_2050posixwin.scm",(void*)f_2050},
{"f_2012posixwin.scm",(void*)f_2012},
{"f_2016posixwin.scm",(void*)f_2016},
{"f_2027posixwin.scm",(void*)f_2027},
{"f_2031posixwin.scm",(void*)f_2031},
{"f_2021posixwin.scm",(void*)f_2021},
{"f_1988posixwin.scm",(void*)f_1988},
{"f_1992posixwin.scm",(void*)f_1992},
{"f_2003posixwin.scm",(void*)f_2003},
{"f_2007posixwin.scm",(void*)f_2007},
{"f_1997posixwin.scm",(void*)f_1997},
{"f_1969posixwin.scm",(void*)f_1969},
{"f_1973posixwin.scm",(void*)f_1973},
{"f_1976posixwin.scm",(void*)f_1976},
{"f_1933posixwin.scm",(void*)f_1933},
{"f_1964posixwin.scm",(void*)f_1964},
{"f_1954posixwin.scm",(void*)f_1954},
{"f_1947posixwin.scm",(void*)f_1947},
{"f_1897posixwin.scm",(void*)f_1897},
{"f_1928posixwin.scm",(void*)f_1928},
{"f_1918posixwin.scm",(void*)f_1918},
{"f_1911posixwin.scm",(void*)f_1911},
{"f_1879posixwin.scm",(void*)f_1879},
{"f_1883posixwin.scm",(void*)f_1883},
{"f_1895posixwin.scm",(void*)f_1895},
{"f_1873posixwin.scm",(void*)f_1873},
{"f_1861posixwin.scm",(void*)f_1861},
{"f_1815posixwin.scm",(void*)f_1815},
{"f_1819posixwin.scm",(void*)f_1819},
{"f_1828posixwin.scm",(void*)f_1828},
{"f_1831posixwin.scm",(void*)f_1831},
{"f_1788posixwin.scm",(void*)f_1788},
{"f_1813posixwin.scm",(void*)f_1813},
{"f_1809posixwin.scm",(void*)f_1809},
{"f_1795posixwin.scm",(void*)f_1795},
{"f_1628posixwin.scm",(void*)f_1628},
{"f_1736posixwin.scm",(void*)f_1736},
{"f_1744posixwin.scm",(void*)f_1744},
{"f_1731posixwin.scm",(void*)f_1731},
{"f_1630posixwin.scm",(void*)f_1630},
{"f_1637posixwin.scm",(void*)f_1637},
{"f_1640posixwin.scm",(void*)f_1640},
{"f_1643posixwin.scm",(void*)f_1643},
{"f_1730posixwin.scm",(void*)f_1730},
{"f_1647posixwin.scm",(void*)f_1647},
{"f_1664posixwin.scm",(void*)f_1664},
{"f_1674posixwin.scm",(void*)f_1674},
{"f_1686posixwin.scm",(void*)f_1686},
{"f_1696posixwin.scm",(void*)f_1696},
{"f_1656posixwin.scm",(void*)f_1656},
{"f_1601posixwin.scm",(void*)f_1601},
{"f_1626posixwin.scm",(void*)f_1626},
{"f_1622posixwin.scm",(void*)f_1622},
{"f_1614posixwin.scm",(void*)f_1614},
{"f_1574posixwin.scm",(void*)f_1574},
{"f_1599posixwin.scm",(void*)f_1599},
{"f_1595posixwin.scm",(void*)f_1595},
{"f_1587posixwin.scm",(void*)f_1587},
{"f_1547posixwin.scm",(void*)f_1547},
{"f_1572posixwin.scm",(void*)f_1572},
{"f_1568posixwin.scm",(void*)f_1568},
{"f_1560posixwin.scm",(void*)f_1560},
{"f_1486posixwin.scm",(void*)f_1486},
{"f_1499posixwin.scm",(void*)f_1499},
{"f_1514posixwin.scm",(void*)f_1514},
{"f_1505posixwin.scm",(void*)f_1505},
{"f_1508posixwin.scm",(void*)f_1508},
{"f_1446posixwin.scm",(void*)f_1446},
{"f_1465posixwin.scm",(void*)f_1465},
{"f_1450posixwin.scm",(void*)f_1450},
{"f_1459posixwin.scm",(void*)f_1459},
{"f_1453posixwin.scm",(void*)f_1453},
{"f_1440posixwin.scm",(void*)f_1440},
{"f_1417posixwin.scm",(void*)f_1417},
{"f_1438posixwin.scm",(void*)f_1438},
{"f_1424posixwin.scm",(void*)f_1424},
{"f_1411posixwin.scm",(void*)f_1411},
{"f_1415posixwin.scm",(void*)f_1415},
{"f_1405posixwin.scm",(void*)f_1405},
{"f_1409posixwin.scm",(void*)f_1409},
{"f_1399posixwin.scm",(void*)f_1399},
{"f_1403posixwin.scm",(void*)f_1403},
{"f_1393posixwin.scm",(void*)f_1393},
{"f_1397posixwin.scm",(void*)f_1397},
{"f_1387posixwin.scm",(void*)f_1387},
{"f_1391posixwin.scm",(void*)f_1391},
{"f_1381posixwin.scm",(void*)f_1381},
{"f_1385posixwin.scm",(void*)f_1385},
{"f_1350posixwin.scm",(void*)f_1350},
{"f_1354posixwin.scm",(void*)f_1354},
{"f_1357posixwin.scm",(void*)f_1357},
{"f_1312posixwin.scm",(void*)f_1312},
{"f_1345posixwin.scm",(void*)f_1345},
{"f_1341posixwin.scm",(void*)f_1341},
{"f_1316posixwin.scm",(void*)f_1316},
{"f_1325posixwin.scm",(void*)f_1325},
{"f_1274posixwin.scm",(void*)f_1274},
{"f_1281posixwin.scm",(void*)f_1281},
{"f_1284posixwin.scm",(void*)f_1284},
{"f_1304posixwin.scm",(void*)f_1304},
{"f_1287posixwin.scm",(void*)f_1287},
{"f_1294posixwin.scm",(void*)f_1294},
{"f_1232posixwin.scm",(void*)f_1232},
{"f_1239posixwin.scm",(void*)f_1239},
{"f_1254posixwin.scm",(void*)f_1254},
{"f_1248posixwin.scm",(void*)f_1248},
{"f_1187posixwin.scm",(void*)f_1187},
{"f_1197posixwin.scm",(void*)f_1197},
{"f_1200posixwin.scm",(void*)f_1200},
{"f_1212posixwin.scm",(void*)f_1212},
{"f_1203posixwin.scm",(void*)f_1203},
{"f_1169posixwin.scm",(void*)f_1169},
{"f_1182posixwin.scm",(void*)f_1182},
{"f_1128posixwin.scm",(void*)f_1128},
{"f_1161posixwin.scm",(void*)f_1161},
{"f_1145posixwin.scm",(void*)f_1145},
{"f_1154posixwin.scm",(void*)f_1154},
{"f_1148posixwin.scm",(void*)f_1148},
{"f_1082posixwin.scm",(void*)f_1082},
{"f_1086posixwin.scm",(void*)f_1086},
{"f_1097posixwin.scm",(void*)f_1097},
{"f_1093posixwin.scm",(void*)f_1093},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
