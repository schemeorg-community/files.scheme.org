/* Generated from csc.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-07 01:29
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-07 on galinha (Linux)
   command line: csc.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -output-file csc.c
   used units: library eval extras extras srfi_1 srfi_13 utils
*/

#include "chicken.h"


#ifndef C_TARGET_CC
# define C_TARGET_CC  C_INSTALL_CC
#endif

#ifndef C_TARGET_CXX
# define C_TARGET_CXX  C_INSTALL_CXX
#endif

#ifndef C_TARGET_CFLAGS
# define C_TARGET_CFLAGS  C_INSTALL_CFLAGS
#endif

#ifndef C_TARGET_LDFLAGS
# define C_TARGET_LDFLAGS  C_INSTALL_LDFLAGS
#endif

#ifndef C_TARGET_BIN_HOME
# define C_TARGET_BIN_HOME  C_INSTALL_BIN_HOME
#endif

#ifndef C_TARGET_LIB_HOME
# define C_TARGET_LIB_HOME  C_INSTALL_LIB_HOME
#endif

#ifndef C_TARGET_STATIC_LIB_HOME
# define C_TARGET_STATIC_LIB_HOME  C_INSTALL_STATIC_LIB_HOME
#endif

#ifndef C_TARGET_INCLUDE_HOME
# define C_TARGET_INCLUDE_HOME  C_INSTALL_INCLUDE_HOME
#endif

#ifndef C_TARGET_SHARE_HOME
# define C_TARGET_SHARE_HOME  C_INSTALL_SHARE_HOME
#endif

#ifndef C_TARGET_RUN_LIB_HOME
# define C_TARGET_RUN_LIB_HOME    C_TARGET_LIB_HOME
#endif

#ifndef C_CHICKEN_PROGRAM
# define C_CHICKEN_PROGRAM     "chicken"
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[343];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_374)
static void C_ccall f_374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_377)
static void C_ccall f_377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_380)
static void C_ccall f_380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_383)
static void C_ccall f_383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_386)
static void C_ccall f_386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3173)
static void C_ccall f_3173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3165)
static void C_ccall f_3165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_404)
static void C_fcall f_404(C_word t0,C_word t1) C_noret;
C_noret_decl(f_421)
static void C_ccall f_421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_425)
static void C_ccall f_425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3145)
static void C_ccall f_3145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_462)
static void C_ccall f_462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_466)
static void C_ccall f_466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_470)
static void C_ccall f_470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_474)
static void C_ccall f_474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3089)
static void C_ccall f_3089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_478)
static void C_ccall f_478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_482)
static void C_ccall f_482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_502)
static void C_ccall f_502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_507)
static void C_ccall f_507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_533)
static void C_ccall f_533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_537)
static void C_ccall f_537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_556)
static void C_ccall f_556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2942)
static void C_ccall f_2942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_571)
static void C_fcall f_571(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_666)
static void C_fcall f_666(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_840)
static void C_ccall f_840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1304)
static void C_fcall f_1304(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static void C_fcall f_1545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1548)
static void C_fcall f_1548(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1551)
static void C_fcall f_1551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1602)
static void C_fcall f_1602(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_fcall f_1611(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_fcall f_1837(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_fcall f_1689(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1649)
static void C_ccall f_1649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1522)
static void C_ccall f_1522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1514)
static void C_ccall f_1514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1429)
static void C_ccall f_1429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1400)
static void C_ccall f_1400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1362)
static void C_ccall f_1362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1287)
static void C_ccall f_1287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1267)
static void C_ccall f_1267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1247)
static void C_ccall f_1247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_ccall f_1237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1216)
static void C_ccall f_1216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1195)
static void C_fcall f_1195(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1179)
static void C_ccall f_1179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1139)
static void C_ccall f_1139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1143)
static void C_ccall f_1143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1058)
static void C_ccall f_1058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1062)
static void C_ccall f_1062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1001)
static void C_ccall f_1001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_977)
static void C_ccall f_977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_932)
static void C_ccall f_932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_890)
static void C_ccall f_890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_883)
static void C_ccall f_883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_874)
static void C_ccall f_874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_867)
static void C_ccall f_867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_855)
static void C_ccall f_855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_843)
static void C_ccall f_843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_831)
static void C_ccall f_831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_798)
static void C_ccall f_798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_824)
static void C_ccall f_824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_801)
static void C_ccall f_801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_817)
static void C_ccall f_817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_804)
static void C_ccall f_804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_807)
static void C_ccall f_807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_676)
static void C_ccall f_676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_761)
static void C_fcall f_761(C_word t0,C_word t1) C_noret;
C_noret_decl(f_771)
static void C_ccall f_771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_764)
static void C_fcall f_764(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_fcall f_2256(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_fcall f_2201(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_fcall f_2216(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2205)
static void C_ccall f_2205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2124)
static void C_fcall f_2124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2131)
static void C_ccall f_2131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_fcall f_2057(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2041)
static void C_ccall f_2041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_723)
static void C_ccall f_723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_726)
static void C_ccall f_726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_733)
static void C_ccall f_733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_679)
static void C_ccall f_679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2345)
static void C_ccall f_2345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2294)
static void C_ccall f_2294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_685)
static void C_ccall f_685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_700)
static void C_ccall f_700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_717)
static void C_ccall f_717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_713)
static void C_ccall f_713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_691)
static void C_ccall f_691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2473)
static void C_ccall f_2473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2465)
static void C_ccall f_2465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2449)
static void C_ccall f_2449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2394)
static void C_fcall f_2394(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_640)
static void C_fcall f_640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_645)
static void C_ccall f_645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_649)
static void C_ccall f_649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_601)
static void C_fcall f_601(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_619)
static void C_ccall f_619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_594)
static void C_fcall f_594(C_word t0,C_word t1) C_noret;
C_noret_decl(f_599)
static void C_ccall f_599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_fcall f_2830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_ccall f_2833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2746)
static void C_fcall f_2746(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2776)
static void C_fcall f_2776(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2783)
static void C_ccall f_2783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2740)
static void C_ccall f_2740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2736)
static void C_ccall f_2736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_fcall f_2646(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2600)
static void C_fcall f_2600(C_word t0) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2628)
static void C_ccall f_2628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2503)
static void C_fcall f_2503(C_word t0) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_fcall f_2513(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2518)
static void C_fcall f_2518(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_fcall f_2559(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2563)
static void C_fcall f_2563(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_fcall f_2351(C_word t0) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_448)
static void C_fcall f_448(C_word t0,C_word t1) C_noret;
C_noret_decl(f_455)
static void C_ccall f_455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_435)
static void C_fcall f_435(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_406)
static void C_fcall f_406(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_417)
static void C_ccall f_417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_404)
static void C_fcall trf_404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_404(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_404(t0,t1);}

C_noret_decl(trf_571)
static void C_fcall trf_571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_571(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_571(t0,t1);}

C_noret_decl(trf_666)
static void C_fcall trf_666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_666(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_666(t0,t1,t2);}

C_noret_decl(trf_1304)
static void C_fcall trf_1304(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1304(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1304(t0,t1);}

C_noret_decl(trf_1545)
static void C_fcall trf_1545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1545(t0,t1);}

C_noret_decl(trf_1548)
static void C_fcall trf_1548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1548(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1548(t0,t1);}

C_noret_decl(trf_1551)
static void C_fcall trf_1551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1551(t0,t1);}

C_noret_decl(trf_1602)
static void C_fcall trf_1602(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1602(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1602(t0,t1);}

C_noret_decl(trf_1611)
static void C_fcall trf_1611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1611(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1611(t0,t1);}

C_noret_decl(trf_1837)
static void C_fcall trf_1837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1837(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1837(t0,t1);}

C_noret_decl(trf_1689)
static void C_fcall trf_1689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1689(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1689(t0,t1);}

C_noret_decl(trf_1195)
static void C_fcall trf_1195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1195(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1195(t0,t1);}

C_noret_decl(trf_761)
static void C_fcall trf_761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_761(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_761(t0,t1);}

C_noret_decl(trf_764)
static void C_fcall trf_764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_764(t0,t1);}

C_noret_decl(trf_2256)
static void C_fcall trf_2256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2256(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2256(t0,t1);}

C_noret_decl(trf_2201)
static void C_fcall trf_2201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2201(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2201(t0,t1);}

C_noret_decl(trf_2216)
static void C_fcall trf_2216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2216(t0,t1);}

C_noret_decl(trf_2124)
static void C_fcall trf_2124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2124(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2124(t0,t1);}

C_noret_decl(trf_2057)
static void C_fcall trf_2057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2057(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2057(t0,t1);}

C_noret_decl(trf_2394)
static void C_fcall trf_2394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2394(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2394(t0,t1);}

C_noret_decl(trf_640)
static void C_fcall trf_640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_640(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_640(t0,t1);}

C_noret_decl(trf_601)
static void C_fcall trf_601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_601(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_601(t0,t1,t2,t3);}

C_noret_decl(trf_594)
static void C_fcall trf_594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_594(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_594(t0,t1);}

C_noret_decl(trf_2830)
static void C_fcall trf_2830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2830(t0,t1);}

C_noret_decl(trf_2746)
static void C_fcall trf_2746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2746(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2746(t0,t1,t2);}

C_noret_decl(trf_2776)
static void C_fcall trf_2776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2776(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2776(t0,t1);}

C_noret_decl(trf_2646)
static void C_fcall trf_2646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2646(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2646(t0,t1);}

C_noret_decl(trf_2600)
static void C_fcall trf_2600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2600(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2600(t0);}

C_noret_decl(trf_2503)
static void C_fcall trf_2503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2503(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2503(t0);}

C_noret_decl(trf_2513)
static void C_fcall trf_2513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2513(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2513(t0,t1);}

C_noret_decl(trf_2518)
static void C_fcall trf_2518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2518(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2518(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2559)
static void C_fcall trf_2559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2559(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2559(t0,t1);}

C_noret_decl(trf_2563)
static void C_fcall trf_2563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2563(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2563(t0,t1);}

C_noret_decl(trf_2351)
static void C_fcall trf_2351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2351(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2351(t0);}

C_noret_decl(trf_448)
static void C_fcall trf_448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_448(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_448(t0,t1);}

C_noret_decl(trf_435)
static void C_fcall trf_435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_435(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_435(t0,t1,t2,t3);}

C_noret_decl(trf_406)
static void C_fcall trf_406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_406(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_406(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2478)){
C_save(t1);
C_rereclaim2(2478*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,343);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"mingw32");
lf[4]=C_h_intern(&lf[4],6,"macosx");
lf[8]=C_h_intern(&lf[8],4,"exit");
lf[9]=C_h_intern(&lf[9],7,"fprintf");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\011csc: ~\077~%");
lf[11]=C_h_intern(&lf[11],18,"current-error-port");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[18]=C_h_intern(&lf[18],13,"make-pathname");
lf[20]=C_h_intern(&lf[20],13,"string-append");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[23]=C_h_intern(&lf[23],10,"string-any");
lf[24]=C_h_intern(&lf[24],16,"char-whitespace\077");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[36]=C_h_intern(&lf[36],26,"\003sysload-dynamic-extension");
lf[37]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[38]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\011-lchicken\376\377\016");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-luchicken\376\377\016");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[72]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014/usr/include\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[92]=C_h_intern(&lf[92],18,"string-intersperse");
lf[93]=C_h_intern(&lf[93],7,"\003sysmap");
lf[95]=C_h_intern(&lf[95],6,"append");
lf[97]=C_h_intern(&lf[97],7,"reverse");
lf[98]=C_h_intern(&lf[98],6,"static");
lf[99]=C_h_intern(&lf[99],14,"static-options");
lf[100]=C_h_intern(&lf[100],21,"extension-information");
lf[101]=C_h_intern(&lf[101],15,"repository-path");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\010 -static");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[106]=C_h_intern(&lf[106],9,"\003syserror");
lf[108]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000#\376\377\016");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[111]=C_h_intern(&lf[111],17,"string-translate*");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\042\376B\000\000\002\134\042\376\377\016");
lf[113]=C_h_intern(&lf[113],16,"\003syslist->string");
lf[114]=C_h_intern(&lf[114],5,"cons*");
lf[115]=C_h_intern(&lf[115],16,"\003sysstring->list");
lf[116]=C_h_intern(&lf[116],3,"any");
lf[119]=C_h_intern(&lf[119],6,"printf");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\0006*** Shell command terminated with exit status ~S: ~A~%");
lf[121]=C_h_intern(&lf[121],6,"system");
lf[122]=C_h_intern(&lf[122],5,"print");
lf[124]=C_h_intern(&lf[124],11,"delete-file");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\003rm ");
lf[126]=C_h_intern(&lf[126],25,"\003sysimplicit-exit-handler");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000#not enough arguments to option `~A\047");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\013-dynamiclib");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\007-bundle");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\007-shared");
lf[131]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-DC_SHARED\376\377\016");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-shared");
lf[134]=C_h_intern(&lf[134],12,"\003sysfor-each");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000+install_name_tool -change libchicken.dylib ");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\020libchicken.dylib");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[140]=C_h_intern(&lf[140],17,"\003syspeek-c-string");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[142]=C_h_intern(&lf[142],7,"sprintf");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\014mv ~A ~A.old");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000TWarning: output file will overwrite source file `~A\047 - renaming source to `"
"~A.old\047~%");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[147]=C_h_intern(&lf[147],26,"pathname-replace-extension");
lf[148]=C_h_intern(&lf[148],4,"last");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\031no source files specified");
lf[150]=C_h_intern(&lf[150],5,"error");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000!invalid entry in csc control file");
lf[152]=C_h_intern(&lf[152],12,"post-process");
lf[153]=C_h_intern(&lf[153],9,"c-options");
lf[154]=C_h_intern(&lf[154],12,"link-options");
lf[155]=C_h_intern(&lf[155],9,"read-file");
lf[156]=C_h_intern(&lf[156],9,"read-line");
lf[157]=C_h_intern(&lf[157],20,"with-input-from-file");
lf[158]=C_h_intern(&lf[158],12,"file-exists\077");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[160]=C_h_intern(&lf[160],4,"conc");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\006-uses ");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-to-stdout\376\377\016");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\014-output-file");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\005#%eof");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\010-dynamic");
lf[170]=C_h_intern(&lf[170],7,"newline");
lf[171]=C_h_intern(&lf[171],6,"print*");
lf[172]=C_h_intern(&lf[172],5,"-help");
lf[173]=C_h_intern(&lf[173],6,"--help");
lf[174]=C_h_intern(&lf[174],7,"display");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\036\343Usage: csc FILENAME | OPTION ...\012\012  `csc\047 is a driver program for the CHICK"
"EN compiler. Any Scheme, C or object\012  files and all libraries given on the comm"
"and line are translated, compiled or\012  linked as needed.\012\012  General options:\012\012  "
"  -h  -help                   display this text and exit\012    -v                 "
"         show intermediate compilation stages\012    -v2  -verbose               di"
"splay information about translation progress\012    -v3                         dis"
"play information about all compilation stages\012    -V  -version                di"
"splay Scheme compiler version and exit\012    -release                    display r"
"elease number and exit\012\012  File and pathname options:\012\012    -o -output-file FILENA"
"ME    specifies target executable name\012    -I -include-path PATHNAME   specifies"
" alternative path for included files\012    -to-stdout                  write compi"
"ler to stdout (implies -t)\012    -s -shared -dynamic         generate dynamically "
"loadable shared object file\012\012  Language options:\012\012    -D  -DSYMBOL  -feature SYM"
"BOL \012                                register feature identifier\012    -c++       "
"                 Compile via a C++ source file (.cpp) \012    -objc                "
"       Compile via Objective-C source file (.m)\012\012  Syntax related options:\012\012    "
"-i -case-insensitive        don\047t preserve case of read symbols    \012    -K -keyw"
"ord-style STYLE     allow alternative keyword syntax (prefix, suffix or none)\012  "
"  -run-time-macros            macros are made available at run-time\012\012  Translati"
"on options:\012\012    -x  -explicit-use           do not use units `library\047 and `eva"
"l\047 by default\012    -P  -check-syntax           stop compilation after macro-expan"
"sion\012    -A  -analyze-only           stop compilation after first analysis pass\012"
"\012  Debugging options:\012\012    -w  -no-warnings            disable warnings\012    -dis"
"able-warning CLASS      disable specific class of warnings\012    -d0 -d1 -d2 -debu"
"g-level NUMBER\012                                set level of available debugging "
"information\012    -no-trace                   disable rudimentary debugging inform"
"ation\012    -profile                    executable emits profiling information \012  "
"  -accumulate-profile         executable emits profiling information in append m"
"ode\012    -profile-name FILENAME      name of the generated profile information fi"
"le\012    -emit-debug-info            emit additional debug-information\012    -emit-e"
"xports FILENAME      write exported toplevel variables to FILENAME\012    -G  -chec"
"k-imports          look for undefined toplevel variables\012    -import FILENAME   "
"         read externally exported symbols from FILENAME\012\012  Optimization options:"
"\012\012    -O -O1 -O2 -O3 -optimize-level NUMBER\012\011\011\011        enable certain sets of op"
"timization options\012    -optimize-leaf-routines     enable leaf routine optimizat"
"ion\012    -N  -no-usual-integrations  standard procedures may be redefined\012    -u "
" -unsafe                 disable safety checks\012    -b  -block                  e"
"nable block-compilation\012    -disable-interrupts         disable interrupts in co"
"mpiled code\012    -f  -fixnum-arithmetic      assume all numbers are fixnums\012    -"
"Ob  -benchmark-mode        equivalent to \047-block -optimize-level 3 \012            "
"                     -debug-level 0 -fixnum-arithmetic -lambda-lift \012           "
"                      -disable-interrupts\047\012    -lambda-lift                perfo"
"rm lambda-lifting\012    -unsafe-libraries           link with unsafe runtime syste"
"m\012    -disable-stack-overflow-checks  disables detection of stack-overflows\012    "
"-inline                     enable inlining\012    -inline-limit               set "
"inlining threshold\012    -disable-compiler-macros    disable expansion of compiler"
" macros\012\012  Configuration options:\012\012    -unit NAME                  compile file "
"as a library unit\012    -uses NAME                  declare library unit as used.\012"
"    -heap-size NUMBER           specifies heap-size of compiled executable\012    -"
"heap-initial-size NUMBER   specifies heap-size at startup time\012    -heap-growth "
"PERCENTAGE     specifies growth-rate of expanding heap\012    -heap-shrinkage PERCE"
"NTAGE  specifies shrink-rate of contracting heap\012    -nursery NUMBER  -stack-siz"
"e NUMBER\012\011\011                specifies nursery size of compiled executable\012    -X "
"-extend FILENAME         load file before compilation commences\012    -prelude EXP"
"RESSION         add expression to beginning of source file\012    -postlude EXPRESS"
"ION        add expression to end of source file\012    -prologue FILENAME          "
"include file before main source file\012    -epilogue FILENAME          include fil"
"e after main source file\012\012    -e  -embedded               compile as embedded (d"
"on\047t generate `main()\047)\012    -W  -windows                compile as Windows GUI a"
"pplication (MSVC only)\012    -R  -require-extension NAME require extension in comp"
"iled code\012    -E  -extension              compile as extension (dynamic or stati"
"c)\012    -dll -library               compile multiple units into a dynamic library"
"\012\012  Options to other passes:\012\012    -C OPTION                   pass option to C c"
"ompiler\012    -L OPTION                   pass option to linker\012    -I<DIR>       "
"              pass \042-I<DIR>\042 to C compiler (add include path)\012    -L<DIR>       "
"              pass \042-L<DIR>\042 to linker (add library path)\012    -k                "
"          keep intermediate files\012    -c                          stop after com"
"pilation to object files\012    -t                          stop after translation "
"to C\012    -cc COMPILER                select other C compiler than the default on"
"e\012    -cxx COMPILER               select other C++ compiler than the default one"
"\012    -ld COMPILER                select other linker than the default one\012    -l"
"LIBNAME                   link with given library (`libLIBNAME\047 on UNIX,\012       "
"                          `LIBNAME.lib\047 on Windows)                             "
"   \012    -static-libs                link with static CHICKEN libraries\012    -stat"
"ic                     generate completely statically linked executable\012    -sta"
"tic-extensions          link with static extensions (if available)\012    -F<DIR>  "
"                   pass \042-F<DIR>\042 to C compiler (add framework \012                "
"                 header path on Mac OS X)\012    -framework NAME             passed"
" to linker on Mac OS X\012    -rpath PATHNAME             add directory to runtime "
"library search path\012    -Wl,...                     pass linker options\012    -str"
"ip                      strip resulting binary\012\012  Inquiry options:\012\012    -home   "
"                    show home-directory (where support files go)\012    -cflags    "
"                 show required C-compiler flags and exit\012    -ldflags           "
"         show required linker flags and exit\012    -libs                       sho"
"w required libraries and exit\012    -cc-name                    show name of defau"
"lt C compiler used\012    -cxx-name                   show name of default C++ comp"
"iler used\012    -ld-name                    show name of default linker used\012    -"
"dry-run                    just show commands executed, don\047t run them \012        "
"                         (implies `-v\047)\012\012  Obscure options:\012\012    -debug MODES   "
"             display debugging output for the given modes\012    -compiler PATHNAME"
"          use other compiler than default `chicken\047\012    -disable-c-syntax-checks"
"    disable syntax checks of C code fragments\012    -raw                        do"
" not generate implicit init- and exit code\011\011\011       \012    -emit-external-prototyp"
"es-first  emit protoypes for callbacks before foreign\012                          "
"       declarations\012    -keep-shadowed-macros       do not remove shadowed macro"
"\012    -host                       compile for host when configured for cross-comp"
"iling\012\012  Options can be collapsed if unambiguous, so\012\012    -vkfO\012\012  is the same a"
"s\012\012    -v -k -fixnum-arithmetic -optimize\012\012  The contents of the environment var"
"iable CSC_OPTIONS are implicitly\012  passed to every invocation of `csc\047.\012");
lf[176]=C_h_intern(&lf[176],8,"-release");
lf[177]=C_h_intern(&lf[177],15,"chicken-version");
lf[178]=C_h_intern(&lf[178],8,"-version");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\011 -version");
lf[180]=C_h_intern(&lf[180],4,"-c++");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[182]=C_h_intern(&lf[182],5,"-objc");
lf[183]=C_h_intern(&lf[183],7,"-static");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[186]=C_h_intern(&lf[186],12,"-static-libs");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[189]=C_h_intern(&lf[189],18,"-static-extensions");
lf[190]=C_h_intern(&lf[190],7,"-cflags");
lf[191]=C_h_intern(&lf[191],8,"-ldflags");
lf[192]=C_h_intern(&lf[192],8,"-cc-name");
lf[193]=C_h_intern(&lf[193],9,"-cxx-name");
lf[194]=C_h_intern(&lf[194],8,"-ld-name");
lf[195]=C_h_intern(&lf[195],5,"-home");
lf[196]=C_h_intern(&lf[196],5,"-libs");
lf[197]=C_h_intern(&lf[197],2,"-v");
lf[198]=C_h_intern(&lf[198],3,"-v2");
lf[199]=C_h_intern(&lf[199],8,"-verbose");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[201]=C_h_intern(&lf[201],2,"-w");
lf[202]=C_h_intern(&lf[202],12,"-no-warnings");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\002-w");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\014-no-warnings");
lf[205]=C_h_intern(&lf[205],3,"-v3");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\002-Q");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[210]=C_h_intern(&lf[210],2,"-A");
lf[211]=C_h_intern(&lf[211],13,"-analyze-only");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\015-analyze-only");
lf[213]=C_h_intern(&lf[213],2,"-P");
lf[214]=C_h_intern(&lf[214],13,"-check-syntax");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\015-check-syntax");
lf[216]=C_h_intern(&lf[216],2,"-k");
lf[217]=C_h_intern(&lf[217],2,"-c");
lf[218]=C_h_intern(&lf[218],2,"-t");
lf[219]=C_h_intern(&lf[219],2,"-e");
lf[220]=C_h_intern(&lf[220],9,"-embedded");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\014-DC_EMBEDDED");
lf[222]=C_h_intern(&lf[222],18,"-require-extension");
lf[223]=C_h_intern(&lf[223],2,"-R");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[225]=C_h_intern(&lf[225],8,"-windows");
lf[226]=C_h_intern(&lf[226],2,"-W");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\017-DC_WINDOWS_GUI");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\012-lkernel32");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\014-luser32.lib");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\007-lgdi32");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\011-mwindows");
lf[232]=C_h_intern(&lf[232],10,"-framework");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\012-framework");
lf[234]=C_h_intern(&lf[234],2,"-o");
lf[235]=C_h_intern(&lf[235],2,"-O");
lf[236]=C_h_intern(&lf[236],3,"-O1");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[239]=C_h_intern(&lf[239],3,"-O2");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[242]=C_h_intern(&lf[242],3,"-O3");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\0013");
lf[245]=C_h_intern(&lf[245],3,"-d0");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[248]=C_h_intern(&lf[248],3,"-d1");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[251]=C_h_intern(&lf[251],3,"-d2");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[254]=C_h_intern(&lf[254],8,"-dry-run");
lf[255]=C_h_intern(&lf[255],2,"-s");
lf[256]=C_h_intern(&lf[256],4,"-dll");
lf[257]=C_h_intern(&lf[257],8,"-library");
lf[258]=C_h_intern(&lf[258],9,"-compiler");
lf[259]=C_h_intern(&lf[259],3,"-cc");
lf[260]=C_h_intern(&lf[260],4,"-cxx");
lf[261]=C_h_intern(&lf[261],3,"-ld");
lf[262]=C_h_intern(&lf[262],2,"-I");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[264]=C_h_intern(&lf[264],2,"-C");
lf[265]=C_h_intern(&lf[265],12,"string-split");
lf[266]=C_h_intern(&lf[266],6,"-strip");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[268]=C_h_intern(&lf[268],2,"-L");
lf[269]=C_h_intern(&lf[269],17,"-unsafe-libraries");
lf[270]=C_h_intern(&lf[270],6,"-rpath");
lf[271]=C_h_intern(&lf[271],3,"gnu");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\006-Wl,-R");
lf[273]=C_h_intern(&lf[273],14,"build-platform");
lf[274]=C_h_intern(&lf[274],5,"-host");
lf[275]=C_h_intern(&lf[275],1,"-");
lf[276]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001-\376\377\016");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[278]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-s\376\003\000\000\002\376B\000\000\007-shared\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\002-E\376\003\000\000\002\376B\000\000\012-extension\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-P\376\003\000\000\002\376B\000\000\015-check-syntax\376\377\016\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\002-V\376\003\000\000\002\376B\000\000\010-version\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003-Ob\376\003\000\000\002\376B\000\000\017-benchmark-mode\376\377\016\376"
"\003\000\000\002\376\003\000\000\002\376\001\000\000\002-f\376\003\000\000\002\376B\000\000\022-fixnum-arithmetic\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-D\376\003\000\000\002\376B\000\000\010-featu"
"re\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-K\376\003\000\000\002\376B\000\000\016-"
"keyword-style\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-X\376\003\000\000\002\376B\000\000\007-extend\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-N\376\003\000\000\002\376B\000\000\026"
"-no-usual-integrations\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-G\376\003\000\000\002\376B\000\000\016-check-imports\376\377\016\376\003\000\000\002\376\003\000\000\002\376"
"\001\000\000\002-x\376\003\000\000\002\376B\000\000\015-explicit-use\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-u\376\003\000\000\002\376B\000\000\007-unsafe\376\377\016\376\003\000\000\002\376\003\000\000\002\376"
"\001\000\000\002-b\376\003\000\000\002\376B\000\000\006-block\376\377\016\376\377\016");
lf[279]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015-explicit-use\376\003\000\000\002\376\001\000\000\011-no-trace\376\003\000\000\002\376\001\000\000\014-no-warnings\376\003\000\000\002\376\001\000\000\026-no-us"
"ual-integrations\376\003\000\000\002\376\001\000\000\027-optimize-leaf-routines\376\003\000\000\002\376\001\000\000\007-unsafe\376\003\000\000\002\376\001\000\000\006-blo"
"ck\376\003\000\000\002\376\001\000\000\023-disable-interrupts\376\003\000\000\002\376\001\000\000\022-fixnum-arithmetic\376\003\000\000\002\376\001\000\000\012-to-stdout\376"
"\003\000\000\002\376\001\000\000\010-profile\376\003\000\000\002\376\001\000\000\004-raw\376\003\000\000\002\376\001\000\000\023-accumulate-profile\376\003\000\000\002\376\001\000\000\015-check-syn"
"tax\376\003\000\000\002\376\001\000\000\021-case-insensitive\376\003\000\000\002\376\001\000\000\017-benchmark-mode\376\003\000\000\002\376\001\000\000\007-shared\376\003\000\000\002\376\001\000"
"\000\020-run-time-macros\376\003\000\000\002\376\001\000\000\017-no-lambda-info\376\003\000\000\002\376\001\000\000\014-lambda-lift\376\003\000\000\002\376\001\000\000\010-dyna"
"mic\376\003\000\000\002\376\001\000\000\036-disable-stack-overflow-checks\376\003\000\000\002\376\001\000\000\020-emit-debug-info\376\003\000\000\002\376\001\000\000\016-"
"check-imports\376\003\000\000\002\376\001\000\000\037-emit-external-prototypes-first\376\003\000\000\002\376\001\000\000\007-inline\376\003\000\000\002\376\001\000\000"
"\012-extension\376\003\000\000\002\376\001\000\000\010-release\376\003\000\000\002\376\001\000\000\022-static-extensions\376\003\000\000\002\376\001\000\000\015-analyze-only"
"\376\003\000\000\002\376\001\000\000\025-keep-shadowed-macros\376\003\000\000\002\376\001\000\000\030-disable-compiler-macros\376\377\016");
lf[280]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006-debug\376\003\000\000\002\376\001\000\000\014-output-file\376\003\000\000\002\376\001\000\000\012-heap-size\376\003\000\000\002\376\001\000\000\010-nursery\376\003\000\000"
"\002\376\001\000\000\013-stack-size\376\003\000\000\002\376\001\000\000\011-compiler\376\003\000\000\002\376\001\000\000\005-unit\376\003\000\000\002\376\001\000\000\005-uses\376\003\000\000\002\376\001\000\000\016-key"
"word-style\376\003\000\000\002\376\001\000\000\017-optimize-level\376\003\000\000\002\376\001\000\000\015-include-path\376\003\000\000\002\376\001\000\000\016-database-si"
"ze\376\003\000\000\002\376\001\000\000\007-extend\376\003\000\000\002\376\001\000\000\010-prelude\376\003\000\000\002\376\001\000\000\011-postlude\376\003\000\000\002\376\001\000\000\011-prologue\376\003\000\000\002"
"\376\001\000\000\011-epilogue\376\003\000\000\002\376\001\000\000\015-inline-limit\376\003\000\000\002\376\001\000\000\015-profile-name\376\003\000\000\002\376\001\000\000\020-disable-w"
"arning\376\003\000\000\002\376\001\000\000\007-import\376\003\000\000\002\376\001\000\000\031-require-static-extension\376\003\000\000\002\376\001\000\000\010-feature\376\003\000\000"
"\002\376\001\000\000\014-debug-level\376\003\000\000\002\376\001\000\000\014-heap-growth\376\003\000\000\002\376\001\000\000\017-heap-shrinkage\376\003\000\000\002\376\001\000\000\022-heap"
"-initial-size\376\003\000\000\002\376\001\000\000\015-emit-exports\376\003\000\000\002\376\001\000\000\022-compress-literals\376\377\016");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[282]=C_h_intern(&lf[282],9,"substring");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[285]=C_h_intern(&lf[285],15,"lset-difference");
lf[286]=C_h_intern(&lf[286],6,"char=\077");
lf[287]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000P\376\003\000\000\002\376\377\012\000\000H\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000f\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000E\376\003\000"
"\000\002\376\377\012\000\000N\376\003\000\000\002\376\377\012\000\000x\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000A\376\003\000\000\002\376"
"\377\012\000\000O\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000W\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000c\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000g\376\003\000\000\002\376\377\012\000"
"\000G\376\377\016");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\004-Wl,");
lf[290]=C_h_intern(&lf[290],18,"decompose-pathname");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\001h");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\001C");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\002cc");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\003cxx");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\003hpp");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\001M");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\002mm");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\030file `~A\047 does not exist");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\002-:");
lf[306]=C_h_intern(&lf[306],15,"-optimize-level");
lf[307]=C_h_intern(&lf[307],15,"-benchmark-mode");
lf[308]=C_h_intern(&lf[308],10,"-to-stdout");
lf[309]=C_h_intern(&lf[309],7,"-unsafe");
lf[310]=C_h_intern(&lf[310],7,"-shared");
lf[311]=C_h_intern(&lf[311],8,"-dynamic");
lf[312]=C_h_intern(&lf[312],14,"string->symbol");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[314]=C_h_intern(&lf[314],6,"getenv");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\013CSC_OPTIONS");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\007 -Wl,-R");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\007include");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\015libuchicken.a");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\016/libuchicken.a");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\014libchicken.a");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\015/libchicken.a");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\005share");
lf[337]=C_h_intern(&lf[337],22,"command-line-arguments");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[339]=C_h_intern(&lf[339],4,"hpux");
lf[340]=C_h_intern(&lf[340],4,"hppa");
lf[341]=C_h_intern(&lf[341],12,"machine-type");
lf[342]=C_h_intern(&lf[342],16,"software-version");
C_register_lf2(lf,343,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_374,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k372 */
static void C_ccall f_374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_377,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k375 in k372 */
static void C_ccall f_377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k378 in k375 in k372 */
static void C_ccall f_380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_383,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k381 in k378 in k375 in k372 */
static void C_ccall f_383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3173,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 114  build-platform */
t3=C_retrieve(lf[273]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3173,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[2]);
t3=C_mutate(&lf[3],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3169,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 115  software-version */
t5=C_retrieve(lf[342]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3169,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[4]);
t3=C_mutate(&lf[5],t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_404,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3165,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 116  software-version */
t6=C_retrieve(lf[342]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3163 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3165,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[339]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3161,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 117  machine-type */
t4=C_retrieve(lf[341]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_404(t3,C_SCHEME_FALSE);}}

/* k3159 in k3163 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_404(t2,(C_word)C_eqp(t1,lf[340]));}

/* k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_404(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_404,NULL,2,t0,t1);}
t2=C_mutate(&lf[6],t1);
t3=C_mutate(&lf[7],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_406,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 123  getenv */
t5=C_retrieve(lf[314]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[338]);}

/* k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_421,2,t0,t1);}
t2=C_mutate(&lf[12],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_425,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 124  command-line-arguments */
t4=C_retrieve(lf[337]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_425,2,t0,t1);}
t2=C_mutate(&lf[13],t1);
t3=(C_word)C_i_member(lf[14],C_retrieve2(lf[13],"arguments"));
t4=C_mutate(&lf[15],t3);
t5=(C_word)C_fudge(C_fix(39));
t6=C_mutate(&lf[16],t5);
t7=C_mutate(&lf[17],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_435,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[19],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_448,tmp=(C_word)a,a+=2,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_462,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3141,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3145,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t12=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t12=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_TARGET_SHARE_HOME),C_fix(0));}}

/* k3143 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 140  prefix */
f_435(((C_word*)t0)[2],lf[335],lf[336],t1);}

/* k3139 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 139  quotewrap */
f_448(((C_word*)t0)[2],t1);}

/* k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_462,2,t0,t1);}
t2=C_mutate(&lf[25],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_466,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3119,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3123,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3127,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_BIN_HOME),C_fix(0));}}

/* k3125 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3131,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k3129 in k3125 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 145  make-pathname */
t2=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3121 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 144  prefix */
f_435(((C_word*)t0)[2],lf[333],lf[334],t1);}

/* k3117 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 143  quotewrap */
f_448(((C_word*)t0)[2],t1);}

/* k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_466,2,t0,t1);}
t2=C_mutate(&lf[26],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_470,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3109,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* k3107 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 149  quotewrap */
f_448(((C_word*)t0)[2],t1);}

/* k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_470,2,t0,t1);}
t2=C_mutate(&lf[27],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_474,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3099,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k3097 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 150  quotewrap */
f_448(((C_word*)t0)[2],t1);}

/* k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_474,2,t0,t1);}
t2=C_mutate(&lf[28],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_478,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3089,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* k3087 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 151  quotewrap */
f_448(((C_word*)t0)[2],t1);}

/* k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_478,2,t0,t1);}
t2=C_mutate(&lf[29],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_482,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3079,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k3077 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 152  quotewrap */
f_448(((C_word*)t0)[2],t1);}

/* k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_482,2,t0,t1);}
t2=C_mutate(&lf[30],t1);
t3=C_mutate(&lf[31],lf[32]);
t4=C_mutate(&lf[33],lf[34]);
t5=C_mutate(&lf[35],C_retrieve(lf[36]));
t6=(C_truep(lf[3])?lf[37]:lf[38]);
t7=C_mutate(&lf[39],t6);
t8=(C_truep(lf[3])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3074,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3069,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[40],t8);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_502,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3059,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t12=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_INSTALL_CFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t12=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}}

/* k3057 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 168  string-split */
t2=C_retrieve(lf[265]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_502,2,t0,t1);}
t2=C_mutate(&lf[41],t1);
t3=C_mutate(&lf[42],C_retrieve2(lf[41],"default-compilation-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_507,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3049,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LDFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_LDFLAGS),C_fix(0));}}

/* k3047 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 170  string-split */
t2=C_retrieve(lf[265]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_507,2,t0,t1);}
t2=C_mutate(&lf[43],t1);
t3=C_mutate(&lf[44],C_retrieve2(lf[43],"default-linking-optimization-options"));
t4=lf[45]=C_SCHEME_END_OF_LIST;;
t5=lf[46]=C_SCHEME_END_OF_LIST;;
t6=lf[47]=C_SCHEME_END_OF_LIST;;
t7=lf[48]=C_SCHEME_END_OF_LIST;;
t8=lf[49]=C_SCHEME_END_OF_LIST;;
t9=lf[50]=C_SCHEME_FALSE;;
t10=lf[51]=C_SCHEME_FALSE;;
t11=lf[52]=C_SCHEME_FALSE;;
t12=lf[53]=C_SCHEME_FALSE;;
t13=lf[54]=C_SCHEME_FALSE;;
t14=lf[55]=C_SCHEME_FALSE;;
t15=lf[56]=C_SCHEME_FALSE;;
t16=lf[57]=C_SCHEME_FALSE;;
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_533,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t18=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_INSTALL_MORE_STATIC_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t18=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_TARGET_MORE_STATIC_LIBS),C_fix(0));}}

/* k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_533,2,t0,t1);}
t2=C_mutate(&lf[58],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_537,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t4=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_MORE_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t4=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}}

/* k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_537,2,t0,t1);}
t2=C_mutate(&lf[59],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3015,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3019,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3023,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3027,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3025 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 239  string-append */
t2=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[332]);}

/* k3021 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 238  prefix */
f_435(((C_word*)t0)[2],lf[330],lf[331],t1);}

/* k3017 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 237  quotewrap */
f_448(((C_word*)t0)[2],t1);}

/* k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3015,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[60],t2);
t4=C_mutate(&lf[61],lf[62]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2993,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2997,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3001,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3005,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t9=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t9=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3003 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 247  string-append */
t2=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[329]);}

/* k2999 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 246  prefix */
f_435(((C_word*)t0)[2],lf[327],lf[328],t1);}

/* k2995 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 245  quotewrap */
f_448(((C_word*)t0)[2],t1);}

/* k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2993,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[63],t2);
t4=C_mutate(&lf[64],lf[65]);
t5=C_mutate(&lf[66],C_retrieve2(lf[60],"default-library-files"));
t6=C_mutate(&lf[67],C_retrieve2(lf[61],"default-shared-library-files"));
t7=C_mutate(&lf[68],C_retrieve2(lf[60],"default-library-files"));
t8=C_mutate(&lf[69],C_retrieve2(lf[61],"default-shared-library-files"));
t9=C_mutate(&lf[70],lf[71]);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_556,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2983,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t12=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t12=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_TARGET_INCLUDE_HOME),C_fix(0));}}

/* k2981 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 259  prefix */
f_435(((C_word*)t0)[2],lf[325],lf[326],t1);}

/* k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[45],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_556,2,t0,t1);}
t2=(C_word)C_i_member(t1,lf[72]);
t3=(C_truep(t2)?C_SCHEME_FALSE:t1);
t4=C_mutate(&lf[73],t3);
t5=(C_truep(C_retrieve2(lf[73],"include-dir"))?(C_word)C_a_i_list(&a,2,lf[74],C_retrieve2(lf[73],"include-dir")):C_SCHEME_END_OF_LIST);
t6=C_mutate(&lf[75],t5);
t7=C_mutate(&lf[76],C_retrieve2(lf[41],"default-compilation-optimization-options"));
t8=C_mutate(&lf[77],C_retrieve2(lf[43],"default-linking-optimization-options"));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_571,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(C_truep(C_retrieve2(lf[5],"osx"))?C_retrieve2(lf[5],"osx"):(C_truep(C_retrieve2(lf[6],"hpux-hppa"))?C_retrieve2(lf[6],"hpux-hppa"):lf[3]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2901,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2905,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2909,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2913,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t15=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t15=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2926,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2952,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2956,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2960,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t15=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t15=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}}

/* k2958 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 281  prefix */
f_435(((C_word*)t0)[2],lf[323],lf[324],t1);}

/* k2954 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 281  quotewrap */
f_448(((C_word*)t0)[2],t1);}

/* k2950 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 281  conc */
t2=C_retrieve(lf[160]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[322],t1);}

/* k2924 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2930,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2934,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2938,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2942,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}

/* k2940 in k2924 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 285  prefix */
f_435(((C_word*)t0)[2],lf[320],lf[321],t1);}

/* k2936 in k2924 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 285  quotewrap */
f_448(((C_word*)t0)[2],t1);}

/* k2932 in k2924 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 285  conc */
t2=C_retrieve(lf[160]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[319],t1);}

/* k2928 in k2924 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2930,2,t0,t1);}
t2=((C_word*)t0)[3];
f_571(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2911 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 275  prefix */
f_435(((C_word*)t0)[2],lf[317],lf[318],t1);}

/* k2907 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 274  quotewrap */
f_448(((C_word*)t0)[2],t1);}

/* k2903 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 274  conc */
t2=C_retrieve(lf[160]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[316],t1);}

/* k2899 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2901,2,t0,t1);}
t2=((C_word*)t0)[2];
f_571(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_571(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_571,NULL,2,t0,t1);}
t2=C_mutate(&lf[78],t1);
t3=lf[79]=C_SCHEME_FALSE;;
t4=lf[80]=C_SCHEME_FALSE;;
t5=lf[81]=C_SCHEME_FALSE;;
t6=lf[82]=C_SCHEME_FALSE;;
t7=lf[83]=C_SCHEME_FALSE;;
t8=lf[84]=C_SCHEME_FALSE;;
t9=lf[85]=C_SCHEME_FALSE;;
t10=lf[86]=C_SCHEME_FALSE;;
t11=lf[87]=C_SCHEME_FALSE;;
t12=lf[88]=C_SCHEME_FALSE;;
t13=lf[89]=C_SCHEME_END_OF_LIST;;
t14=lf[90]=C_SCHEME_FALSE;;
t15=C_mutate(&lf[91],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2351,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[96],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2503,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[102],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2600,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[105],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2646,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[107],lf[108]);
t20=C_mutate(&lf[94],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2793,tmp=(C_word)a,a+=2,tmp));
t21=lf[117]=C_SCHEME_FALSE;;
t22=C_mutate(&lf[118],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2822,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate(&lf[123],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2854,tmp=(C_word)a,a+=2,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2870,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2880,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2884,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2888,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 932  getenv */
t28=C_retrieve(lf[314]);
((C_proc3)C_retrieve_proc(t28))(3,t28,t27,lf[315]);}

/* k2886 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[313]);
/* csc.scm: 932  string-split */
t3=C_retrieve(lf[265]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2882 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 932  append */
t2=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[13],"arguments"));}

/* k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_594,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_601,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_640,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_666,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_666(t8,((C_word*)t0)[2],t1);}

/* loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_666(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_666,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_676,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[53],"inquiry-only"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_798,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[54],"show-cflags"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_831,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 488  compiler-options */
f_2351(t5);}
else{
t5=t4;
f_798(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_676(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_840,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* csc.scm: 526  string->symbol */
t8=*((C_word*)lf[312]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word ab[114],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_843,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[172]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t1,lf[173]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_855,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 307  display */
t6=*((C_word*)lf[174]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[175]);}
else{
t5=(C_word)C_eqp(t1,lf[176]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_867,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_874,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 532  chicken-version */
t8=C_retrieve(lf[177]);
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t6=(C_word)C_eqp(t1,lf[178]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_883,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_890,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 535  sprintf */
t9=C_retrieve(lf[142]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,C_retrieve2(lf[26],"translator"),lf[179]);}
else{
t7=(C_word)C_eqp(t1,lf[180]);
if(C_truep(t7)){
t8=lf[50]=C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[5],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[181],C_retrieve2(lf[75],"compile-options"));
t10=C_mutate(&lf[75],t9);
t11=t2;
f_843(2,t11,t10);}
else{
t9=t2;
f_843(2,t9,C_SCHEME_UNDEFINED);}}
else{
t8=(C_word)C_eqp(t1,lf[182]);
if(C_truep(t8)){
t9=lf[51]=C_SCHEME_TRUE;;
t10=t2;
f_843(2,t10,t9);}
else{
t9=(C_word)C_eqp(t1,lf[183]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_921,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 543  cons* */
t11=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,lf[184],lf[185],C_retrieve2(lf[70],"translate-options"));}
else{
t10=(C_word)C_eqp(t1,lf[186]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_932,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 546  cons* */
t12=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[187],lf[188],C_retrieve2(lf[70],"translate-options"));}
else{
t11=(C_word)C_eqp(t1,lf[189]);
if(C_truep(t11)){
t12=lf[88]=C_SCHEME_TRUE;;
t13=t2;
f_843(2,t13,t12);}
else{
t12=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t12)){
t13=lf[53]=C_SCHEME_TRUE;;
t14=lf[54]=C_SCHEME_TRUE;;
t15=t2;
f_843(2,t15,t14);}
else{
t13=(C_word)C_eqp(t1,lf[191]);
if(C_truep(t13)){
t14=lf[53]=C_SCHEME_TRUE;;
t15=lf[55]=C_SCHEME_TRUE;;
t16=t2;
f_843(2,t16,t15);}
else{
t14=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_965,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 556  print */
t16=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,C_retrieve2(lf[27],"compiler"));}
else{
t15=(C_word)C_eqp(t1,lf[193]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_977,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 557  print */
t17=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,C_retrieve2(lf[28],"c++-compiler"));}
else{
t16=(C_word)C_eqp(t1,lf[194]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_989,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 558  print */
t18=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,C_retrieve2(lf[29],"linker"));}
else{
t17=(C_word)C_eqp(t1,lf[195]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1001,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 559  print */
t19=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,C_retrieve2(lf[25],"home"));}
else{
t18=(C_word)C_eqp(t1,lf[196]);
if(C_truep(t18)){
t19=lf[53]=C_SCHEME_TRUE;;
t20=lf[56]=C_SCHEME_TRUE;;
t21=t2;
f_843(2,t21,t20);}
else{
t19=(C_word)C_eqp(t1,lf[197]);
if(C_truep(t19)){
t20=lf[80]=C_SCHEME_TRUE;;
t21=t2;
f_843(2,t21,t20);}
else{
t20=(C_word)C_eqp(t1,lf[198]);
t21=(C_truep(t20)?t20:(C_word)C_eqp(t1,lf[199]));
if(C_truep(t21)){
t22=lf[80]=C_SCHEME_TRUE;;
/* csc.scm: 567  t-options */
f_594(t2,(C_word)C_a_i_list(&a,1,lf[200]));}
else{
t22=(C_word)C_eqp(t1,lf[201]);
t23=(C_truep(t22)?t22:(C_word)C_eqp(t1,lf[202]));
if(C_truep(t23)){
t24=(C_word)C_a_i_cons(&a,2,lf[203],C_retrieve2(lf[75],"compile-options"));
t25=C_mutate(&lf[75],t24);
/* csc.scm: 570  t-options */
f_594(t2,(C_word)C_a_i_list(&a,1,lf[204]));}
else{
t24=(C_word)C_eqp(t1,lf[205]);
if(C_truep(t24)){
t25=lf[80]=C_SCHEME_TRUE;;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1058,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 573  t-options */
f_594(t26,(C_word)C_a_i_list(&a,1,lf[209]));}
else{
t25=(C_word)C_eqp(t1,lf[210]);
t26=(C_truep(t25)?t25:(C_word)C_eqp(t1,lf[211]));
if(C_truep(t26)){
t27=lf[82]=C_SCHEME_TRUE;;
/* csc.scm: 578  t-options */
f_594(t2,(C_word)C_a_i_list(&a,1,lf[212]));}
else{
t27=(C_word)C_eqp(t1,lf[213]);
t28=(C_truep(t27)?t27:(C_word)C_eqp(t1,lf[214]));
if(C_truep(t28)){
t29=lf[82]=C_SCHEME_TRUE;;
/* csc.scm: 581  t-options */
f_594(t2,(C_word)C_a_i_list(&a,1,lf[215]));}
else{
t29=(C_word)C_eqp(t1,lf[216]);
if(C_truep(t29)){
t30=lf[81]=C_SCHEME_TRUE;;
t31=t2;
f_843(2,t31,t30);}
else{
t30=(C_word)C_eqp(t1,lf[217]);
if(C_truep(t30)){
t31=lf[83]=C_SCHEME_TRUE;;
t32=t2;
f_843(2,t32,t31);}
else{
t31=(C_word)C_eqp(t1,lf[218]);
if(C_truep(t31)){
t32=lf[82]=C_SCHEME_TRUE;;
t33=t2;
f_843(2,t33,t32);}
else{
t32=(C_word)C_eqp(t1,lf[219]);
t33=(C_truep(t32)?t32:(C_word)C_eqp(t1,lf[220]));
if(C_truep(t33)){
t34=lf[52]=C_SCHEME_TRUE;;
t35=(C_word)C_a_i_cons(&a,2,lf[221],C_retrieve2(lf[75],"compile-options"));
t36=C_mutate(&lf[75],t35);
t37=t2;
f_843(2,t37,t36);}
else{
t34=(C_word)C_eqp(t1,lf[222]);
t35=(C_truep(t34)?t34:(C_word)C_eqp(t1,lf[223]));
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1139,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 589  check */
f_601(t36,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t36=(C_word)C_eqp(t1,lf[225]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t1,lf[226]));
if(C_truep(t37)){
t38=lf[90]=C_SCHEME_TRUE;;
if(C_truep(lf[3])){
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1179,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 597  cons* */
t40=C_retrieve(lf[114]);
((C_proc7)C_retrieve_proc(t40))(7,t40,t39,lf[228],lf[229],lf[230],lf[231],C_retrieve2(lf[78],"link-options"));}
else{
t39=t2;
f_843(2,t39,C_SCHEME_UNDEFINED);}}
else{
t38=(C_word)C_eqp(t1,lf[232]);
if(C_truep(t38)){
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1192,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 601  check */
f_601(t39,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t39=(C_word)C_eqp(t1,lf[234]);
if(C_truep(t39)){
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1216,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 606  check */
f_601(t40,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t40=(C_word)C_eqp(t1,lf[235]);
t41=(C_truep(t40)?t40:(C_word)C_eqp(t1,lf[236]));
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1237,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 610  cons* */
t43=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t43))(5,t43,t42,lf[237],lf[238],((C_word*)((C_word*)t0)[6])[1]);}
else{
t42=(C_word)C_eqp(t1,lf[239]);
if(C_truep(t42)){
t43=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1247,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 611  cons* */
t44=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t44))(5,t44,t43,lf[240],lf[241],((C_word*)((C_word*)t0)[6])[1]);}
else{
t43=(C_word)C_eqp(t1,lf[242]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1257,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 612  cons* */
t45=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t45))(5,t45,t44,lf[243],lf[244],((C_word*)((C_word*)t0)[6])[1]);}
else{
t44=(C_word)C_eqp(t1,lf[245]);
if(C_truep(t44)){
t45=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1267,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 613  cons* */
t46=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t45,lf[246],lf[247],((C_word*)((C_word*)t0)[6])[1]);}
else{
t45=(C_word)C_eqp(t1,lf[248]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1277,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 614  cons* */
t47=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t47))(5,t47,t46,lf[249],lf[250],((C_word*)((C_word*)t0)[6])[1]);}
else{
t46=(C_word)C_eqp(t1,lf[251]);
if(C_truep(t46)){
t47=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1287,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 615  cons* */
t48=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t48))(5,t48,t47,lf[252],lf[253],((C_word*)((C_word*)t0)[6])[1]);}
else{
t47=(C_word)C_eqp(t1,lf[254]);
if(C_truep(t47)){
t48=lf[80]=C_SCHEME_TRUE;;
t49=lf[57]=C_SCHEME_TRUE;;
t50=t2;
f_843(2,t50,t49);}
else{
t48=(C_word)C_eqp(t1,lf[255]);
t49=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t48)){
t50=t49;
f_1304(t50,t48);}
else{
t50=(C_word)C_eqp(t1,lf[310]);
t51=t49;
f_1304(t51,(C_truep(t50)?t50:(C_word)C_eqp(t1,lf[311])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_1304(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[55],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1304,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 620  shared-build */
f_640(((C_word*)t0)[7],C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[256]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[6],lf[257]));
if(C_truep(t3)){
/* csc.scm: 622  shared-build */
f_640(((C_word*)t0)[7],C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[258]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1328,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 624  check */
f_601(t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[259]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1345,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 628  check */
f_601(t6,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[260]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1362,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 632  check */
f_601(t7,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[261]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1379,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 636  check */
f_601(t8,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[6],lf[262]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1396,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 640  check */
f_601(t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[264]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1417,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 643  check */
f_601(t10,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[266]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1443,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,lf[267]);
/* csc.scm: 647  append */
t13=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[78],"link-options"),t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[268]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1456,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 649  check */
f_601(t12,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[269]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1481,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 653  t-options */
f_594(t13,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[270]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1492,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 657  check */
f_601(t14,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[274]);
if(C_truep(t14)){
t15=((C_word*)t0)[7];
f_843(2,t15,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[6],lf[275]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1538,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 663  make-pathname */
t17=C_retrieve(lf[18]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,C_SCHEME_FALSE,lf[277],C_retrieve2(lf[33],"executable-extension"));}
else{
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1545,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t17=((C_word*)t0)[6];
if(C_truep((C_truep((C_word)C_eqp(t17,lf[309]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t17,lf[307]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t18=(C_word)C_eqp(((C_word*)t0)[6],lf[307]);
if(C_truep(t18)){
t19=C_mutate(&lf[68],C_retrieve2(lf[63],"unsafe-library-files"));
t20=C_mutate(&lf[69],C_retrieve2(lf[64],"unsafe-shared-library-files"));
t21=t16;
f_1545(t21,t20);}
else{
t19=t16;
f_1545(t19,C_SCHEME_UNDEFINED);}}
else{
t18=t16;
f_1545(t18,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}}}}

/* k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_1545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1545,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[308]);
if(C_truep(t3)){
t4=lf[84]=C_SCHEME_TRUE;;
t5=lf[82]=C_SCHEME_TRUE;;
t6=t2;
f_1548(t6,t5);}
else{
t4=t2;
f_1548(t4,C_SCHEME_UNDEFINED);}}

/* k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_1548(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1548,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t3,lf[306]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[307]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=C_mutate(&lf[76],C_retrieve2(lf[42],"best-compilation-optimization-options"));
t5=C_mutate(&lf[77],C_retrieve2(lf[44],"best-linking-optimization-options"));
t6=t2;
f_1551(t6,t5);}
else{
t4=t2;
f_1551(t4,C_SCHEME_UNDEFINED);}}

/* k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_1551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1551,NULL,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[7],lf[278]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=((C_word*)t0)[5];
f_843(2,t6,t5);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[279]))){
/* csc.scm: 677  t-options */
f_594(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[280]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 679  check */
f_601(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1602,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_greaterp(t4,C_fix(2)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1933,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 684  substring */
t6=*((C_word*)lf[282]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],C_fix(0),C_fix(2));}
else{
t5=t3;
f_1602(t5,C_SCHEME_FALSE);}}}}}

/* k1931 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1602(t2,(C_word)C_i_string_equal_p(lf[305],t1));}

/* k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_1602(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1602,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 685  t-options */
f_594(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t3,C_fix(1)))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],C_fix(0));
t5=t2;
f_1611(t5,(C_word)C_eqp(C_make_character(45),t4));}
else{
t4=t2;
f_1611(t4,C_SCHEME_FALSE);}}}

/* k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_1611(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1611,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_eqp(C_make_character(108),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1621,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 689  append */
t6=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_retrieve2(lf[78],"link-options"),t5);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_eqp(C_make_character(76),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1635,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 691  append */
t8=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,C_retrieve2(lf[78],"link-options"),t7);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t7=(C_word)C_eqp(C_make_character(73),t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1649,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 693  append */
t10=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,C_retrieve2(lf[75],"compile-options"),t9);}
else{
t8=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t9=(C_word)C_eqp(C_make_character(68),t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1666,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 695  substring */
t11=*((C_word*)lf[282]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,((C_word*)t0)[6],C_fix(2));}
else{
t10=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t11=(C_word)C_eqp(C_make_character(70),t10);
if(C_truep(t11)){
if(C_truep(C_retrieve2(lf[5],"osx"))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1679,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t13=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* csc.scm: 698  append */
t14=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,t12,C_retrieve2(lf[75],"compile-options"),t13);}
else{
t12=((C_word*)t0)[5];
f_843(2,t12,C_SCHEME_UNDEFINED);}}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t13,C_fix(3)))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1758,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 699  substring */
t15=*((C_word*)lf[282]+1);
((C_proc5)C_retrieve_proc(t15))(5,t15,t14,((C_word*)t0)[6],C_fix(0),C_fix(4));}
else{
t14=t12;
f_1689(t14,C_SCHEME_FALSE);}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1788,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 708  file-exists? */
t3=C_retrieve(lf[158]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k1786 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1788,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1793,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1799,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 709  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 725  string-append */
t3=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],lf[304]);}}

/* k1894 in k1786 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 726  file-exists? */
t3=C_retrieve(lf[158]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1900 in k1894 in k1786 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_843(2,t4,t3);}
else{
/* csc.scm: 728  quit */
f_406(((C_word*)t0)[3],lf[303],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a1798 in k1786 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[37],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1799,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep(t5)){
t6=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t6,lf[291]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t6,lf[292]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1824,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 712  append */
t9=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve2(lf[46],"c-files"),t8);}
else{
t7=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t7,lf[293]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[294]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[295]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[296]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[297]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1837,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[5],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[298],C_retrieve2(lf[75],"compile-options"));
t10=C_mutate(&lf[75],t9);
t11=t8;
f_1837(t11,t10);}
else{
t9=t8;
f_1837(t9,C_SCHEME_UNDEFINED);}}
else{
t8=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t8,lf[299]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[300]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[301]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t9=lf[51]=C_SCHEME_TRUE;;
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1861,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 719  append */
t12=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,C_retrieve2(lf[46],"c-files"),t11);}
else{
t9=(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[31],"object-extension"));
t10=(C_truep(t9)?t9:(C_word)C_i_string_equal_p(t4,lf[302]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1878,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 722  append */
t13=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[48],"object-files"),t12);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1886,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 723  append */
t13=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[45],"scheme-files"),t12);}}}}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1810,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 710  append */
t8=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,C_retrieve2(lf[45],"scheme-files"),t7);}}

/* k1808 in a1798 in k1786 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[45],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1884 in a1798 in k1786 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[45],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1876 in a1798 in k1786 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[48],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1859 in a1798 in k1786 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[46],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1835 in a1798 in k1786 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_1837(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1837,NULL,2,t0,t1);}
t2=lf[50]=C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1842,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 716  append */
t5=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,C_retrieve2(lf[46],"c-files"),t4);}

/* k1840 in k1835 in a1798 in k1786 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[46],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1822 in a1798 in k1786 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[46],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1792 in k1786 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1793,2,t0,t1);}
/* csc.scm: 709  decompose-pathname */
t2=C_retrieve(lf[290]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1756 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1689(t2,(C_word)C_i_string_equal_p(lf[289],t1));}

/* k1687 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_1689(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1689,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1693,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* csc.scm: 700  append */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve2(lf[78],"link-options"),t3);}
else{
t2=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1741,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* string->list */
t4=C_retrieve(lf[115]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
/* csc.scm: 707  quit */
f_406(((C_word*)t0)[5],lf[288],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}}

/* k1739 in k1687 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1741,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1737,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 703  lset-difference */
t4=C_retrieve(lf[285]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[286]+1),t2,lf[287]);}

/* k1735 in k1739 in k1687 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1737,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1716,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1720,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1722,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}
else{
/* csc.scm: 706  quit */
f_406(((C_word*)t0)[4],lf[284],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a1721 in k1735 in k1739 in k1687 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1722,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* csc.scm: 705  string-append */
t4=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,lf[283],t3);}

/* k1718 in k1735 in k1739 in k1687 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 705  append */
t2=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k1714 in k1735 in k1739 in k1687 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_843(2,t3,t2);}

/* k1691 in k1687 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[78],t1);
t3=((C_word*)t0)[2];
f_843(2,t3,t2);}

/* k1677 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[75],t1);
t3=((C_word*)t0)[2];
f_843(2,t3,t2);}

/* k1664 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1666,2,t0,t1);}
/* csc.scm: 695  t-options */
f_594(((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,lf[281],t1));}

/* k1647 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[75],t1);
t3=((C_word*)t0)[2];
f_843(2,t3,t2);}

/* k1633 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[78],t1);
t3=((C_word*)t0)[2];
f_843(2,t3,t2);}

/* k1619 in k1609 in k1600 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[78],t1);
t3=((C_word*)t0)[2];
f_843(2,t3,t2);}

/* k1581 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1583,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1589,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 681  string->number */
C_string_to_number(3,0,t3,t2);}

/* k1587 in k1581 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 682  t-options */
f_594(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k1590 in k1587 in k1581 in k1549 in k1546 in k1543 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_843(2,t4,t3);}

/* k1536 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1538,2,t0,t1);}
t2=C_mutate(&lf[79],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1542,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 664  append */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[45],"scheme-files"),lf[276]);}

/* k1540 in k1536 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[45],t1);
t3=((C_word*)t0)[2];
f_843(2,t3,t2);}

/* k1490 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 658  build-platform */
t3=C_retrieve(lf[273]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1520 in k1490 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1522,2,t0,t1);}
t2=(C_word)C_eqp(lf[271],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1514,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 659  string-append */
t6=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[272],t5);}
else{
t3=((C_word*)t0)[2];
f_843(2,t3,C_SCHEME_UNDEFINED);}}

/* k1512 in k1520 in k1490 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1514,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* csc.scm: 659  append */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[78],"link-options"),t2);}

/* k1500 in k1520 in k1490 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[78],t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_843(2,t5,t4);}

/* k1479 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[68],C_retrieve2(lf[63],"unsafe-library-files"));
t3=C_mutate(&lf[69],C_retrieve2(lf[64],"unsafe-shared-library-files"));
t4=((C_word*)t0)[2];
f_843(2,t4,t3);}

/* k1454 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1468,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 650  string-split */
t5=C_retrieve(lf[265]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1466 in k1454 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 650  append */
t2=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[78],"link-options"),t1);}

/* k1458 in k1454 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[78],t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_843(2,t5,t4);}

/* k1441 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[78],t1);
t3=((C_word*)t0)[2];
f_843(2,t3,t2);}

/* k1415 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1429,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 644  string-split */
t5=C_retrieve(lf[265]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1427 in k1415 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 644  append */
t2=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[75],"compile-options"),t1);}

/* k1419 in k1415 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[75],t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_843(2,t5,t4);}

/* k1394 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 641  cons* */
t5=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[263],t3,t4);}

/* k1398 in k1394 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_843(2,t3,t2);}

/* k1377 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[29],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_843(2,t6,t5);}

/* k1360 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[28],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_843(2,t6,t5);}

/* k1343 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[27],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_843(2,t6,t5);}

/* k1326 in k1302 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[26],t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_843(2,t6,t5);}

/* k1285 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_843(2,t3,t2);}

/* k1275 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_843(2,t3,t2);}

/* k1265 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_843(2,t3,t2);}

/* k1255 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_843(2,t3,t2);}

/* k1245 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_843(2,t3,t2);}

/* k1235 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_843(2,t3,t2);}

/* k1214 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=C_mutate(&lf[79],t2);
t6=((C_word*)t0)[2];
f_843(2,t6,t5);}

/* k1190 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[5],"osx"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1203,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* csc.scm: 603  cons* */
t5=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,lf[233],t4,C_retrieve2(lf[78],"link-options"));}
else{
t3=t2;
f_1195(t3,C_SCHEME_UNDEFINED);}}

/* k1201 in k1190 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[78],t1);
t3=((C_word*)t0)[2];
f_1195(t3,t2);}

/* k1193 in k1190 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_1195(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_843(2,t4,t3);}

/* k1177 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1179,2,t0,t1);}
t2=C_mutate(&lf[78],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[227],C_retrieve2(lf[75],"compile-options"));
t4=C_mutate(&lf[75],t3);
t5=((C_word*)t0)[2];
f_843(2,t5,t4);}

/* k1137 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* csc.scm: 590  append */
t5=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_retrieve2(lf[89],"required-extensions"),t4);}

/* k1141 in k1137 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1143,2,t0,t1);}
t2=C_mutate(&lf[89],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1146,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 591  t-options */
f_594(t3,(C_word)C_a_i_list(&a,2,lf[224],t4));}

/* k1144 in k1141 in k1137 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_843(2,t4,t3);}

/* k1056 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1062,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 574  cons* */
t3=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[207],lf[208],C_retrieve2(lf[75],"compile-options"));}

/* k1060 in k1056 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1062,2,t0,t1);}
t2=C_mutate(&lf[75],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[206],C_retrieve2(lf[78],"link-options"));
t4=C_mutate(&lf[78],t3);
t5=((C_word*)t0)[2];
f_843(2,t5,t4);}

/* k999 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_1001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 559  exit */
t2=C_retrieve(lf[8]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k987 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 558  exit */
t2=C_retrieve(lf[8]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k975 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 557  exit */
t2=C_retrieve(lf[8]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k963 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 556  exit */
t2=C_retrieve(lf[8]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k930 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[70],t1);
t3=lf[87]=C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_843(2,t4,t3);}

/* k919 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[70],t1);
t3=lf[86]=C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_843(2,t4,t3);}

/* k888 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 535  system */
t2=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k881 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 536  exit */
t2=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k872 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 532  print */
t2=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k865 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 533  exit */
t2=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k853 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 530  exit */
t2=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k841 in k838 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 729  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_666(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k829 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 488  print* */
t2=*((C_word*)lf[171]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k796 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_801,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[55],"show-ldflags"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_824,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 489  linker-options */
f_2600(t3);}
else{
t3=t2;
f_801(2,t3,C_SCHEME_UNDEFINED);}}

/* k822 in k796 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 489  print* */
t2=*((C_word*)lf[171]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k799 in k796 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_804,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[56],"show-libs"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_817,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 490  linker-libraries */
f_2646(t3,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}
else{
t3=t2;
f_804(2,t3,C_SCHEME_UNDEFINED);}}

/* k815 in k799 in k796 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 490  print* */
t2=*((C_word*)lf[171]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k802 in k799 in k796 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_807,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 491  newline */
t3=*((C_word*)lf[170]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k805 in k802 in k799 in k796 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 492  exit */
t2=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_679,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(C_retrieve2(lf[45],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_723,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_nullp(C_retrieve2(lf[46],"c-files"));
t5=(C_truep(t4)?(C_word)C_i_nullp(C_retrieve2(lf[48],"object-files")):C_SCHEME_FALSE);
if(C_truep(t5)){
/* csc.scm: 498  quit */
f_406(t3,lf[149],C_SCHEME_END_OF_LIST);}
else{
t6=t3;
f_723(2,t6,C_SCHEME_UNDEFINED);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_761,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[85],"shared"))?(C_word)C_i_not(C_retrieve2(lf[52],"embedded")):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[169],C_retrieve2(lf[70],"translate-options"));
t6=C_mutate(&lf[70],t5);
t7=t3;
f_761(t7,t6);}
else{
t5=t3;
f_761(t5,C_SCHEME_UNDEFINED);}}}

/* k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_761(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_761,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_764,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[79],"target-filename"))){
t3=t2;
f_764(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_771,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[85],"shared"))){
t4=(C_word)C_i_car(C_retrieve2(lf[45],"scheme-files"));
/* csc.scm: 511  pathname-replace-extension */
t5=C_retrieve(lf[147]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[35],"shared-library-extension"));}
else{
t4=(C_word)C_i_car(C_retrieve2(lf[45],"scheme-files"));
/* csc.scm: 512  pathname-replace-extension */
t5=C_retrieve(lf[147]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[33],"executable-extension"));}}}

/* k769 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[79],t1);
t3=((C_word*)t0)[2];
f_764(t3,t2);}

/* k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_764,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2011,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[45],"scheme-files"));}

/* a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2011,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2015,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 737  pathname-replace-extension */
t4=C_retrieve(lf[147]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[168]);}

/* k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2256,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2262,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 738  file-exists? */
t5=C_retrieve(lf[158]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k2260 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2262,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2265,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 739  with-input-from-file */
t3=C_retrieve(lf[157]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_retrieve(lf[156]));}
else{
t2=((C_word*)t0)[3];
f_2256(t2,C_SCHEME_FALSE);}}

/* k2263 in k2260 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eofp(t1);
t3=((C_word*)t0)[2];
f_2256(t3,(C_truep(t2)?t2:(C_word)C_i_string_equal_p(lf[167],t1)));}

/* k2254 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2256(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csc.scm: 741  $delete-file */
t2=C_retrieve2(lf[123],"$delete-file");
f_2854(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2018(2,t2,C_SCHEME_UNDEFINED);}}

/* k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_length(C_retrieve2(lf[45],"scheme-files"));
t4=(C_word)C_i_nequalp(C_fix(1),t3);
t5=(C_truep(t4)?C_retrieve2(lf[79],"target-filename"):((C_word*)t0)[2]);
t6=(C_truep(C_retrieve2(lf[50],"cpp-mode"))?lf[164]:(C_truep(C_retrieve2(lf[51],"objc-mode"))?lf[165]:lf[166]));
/* csc.scm: 742  pathname-replace-extension */
t7=C_retrieve(lf[147]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,t5,t6);}

/* k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2024,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2181,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2185,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2189,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2193,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 752  cleanup-filename */
t7=C_retrieve2(lf[40],"cleanup-filename");
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2191 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2197,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2201,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[84],"to-stdout"))){
t4=t3;
f_2201(t4,lf[162]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2235,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 756  cleanup-filename */
t5=C_retrieve2(lf[40],"cleanup-filename");
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k2233 in k2191 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2235,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2201(t2,(C_word)C_a_i_list(&a,2,lf[163],t1));}

/* k2199 in k2191 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2201(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2201,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2205,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve2(lf[86],"static");
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2216,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_2216(t5,t3);}
else{
t5=C_retrieve2(lf[87],"static-libs");
t6=t4;
f_2216(t6,(C_truep(t5)?t5:C_retrieve2(lf[88],"static-extensions")));}}

/* k2214 in k2199 in k2191 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2216,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2221,tmp=(C_word)a,a+=2,tmp);
/* map */
t3=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve2(lf[89],"required-extensions"));}
else{
t2=((C_word*)t0)[2];
f_2205(2,t2,C_SCHEME_END_OF_LIST);}}

/* a2220 in k2214 in k2199 in k2191 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2221,3,t0,t1,t2);}
/* csc.scm: 758  conc */
t3=C_retrieve(lf[160]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[161],t2);}

/* k2203 in k2199 in k2191 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2209,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2213,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 760  append */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[70],"translate-options"),C_SCHEME_END_OF_LIST);}

/* k2211 in k2203 in k2199 in k2191 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[94],"quote-option"),t1);}

/* k2207 in k2203 in k2199 in k2191 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 753  append */
t2=*((C_word*)lf[95]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2195 in k2191 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 752  cons* */
t2=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve2(lf[26],"translator"),((C_word*)t0)[2],t1);}

/* k2187 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 751  string-intersperse */
t2=C_retrieve(lf[92]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[159]);}

/* k2183 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 750  $system */
t2=C_retrieve2(lf[118],"$system");
f_2822(3,t2,((C_word*)t0)[2],t1);}

/* k2179 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2024(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 762  exit */
t2=C_retrieve(lf[8]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[117],"last-exit-code"));}}

/* k2022 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 763  append */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_retrieve2(lf[46],"c-files"));}

/* k2026 in k2022 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2028,2,t0,t1);}
t2=C_mutate(&lf[46],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2032,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 764  append */
t5=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[47],"generated-c-files"));}

/* k2030 in k2026 in k2022 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2032,2,t0,t1);}
t2=C_mutate(&lf[47],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2038,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 765  file-exists? */
t4=C_retrieve(lf[158]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2036 in k2030 in k2026 in k2022 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2038,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2046,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 766  with-input-from-file */
t4=C_retrieve(lf[157]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a2045 in k2036 in k2030 in k2026 in k2022 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2050,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 768  read-line */
t3=C_retrieve(lf[156]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2048 in a2045 in k2036 in k2030 in k2026 in k2022 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2055,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2163,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 778  read-file */
t4=C_retrieve(lf[155]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2161 in k2048 in a2045 in k2036 in k2030 in k2026 in k2022 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2054 in k2048 in a2045 in k2036 in k2030 in k2026 in k2022 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2055,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2057,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[152]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(t2);
/* for-each */
t8=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,C_retrieve2(lf[118],"$system"),t7);}
else{
/* g187189 */
f_2057(t1,t2);}}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[153]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_listp(t8))){
t9=(C_word)C_i_cdr(t2);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2111,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* append */
t11=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,C_retrieve2(lf[75],"compile-options"),t9);}
else{
/* g187189 */
f_2057(t1,t2);}}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2124,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_eqp(t9,lf[154]);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t2);
t12=t8;
f_2124(t12,(C_word)C_i_listp(t11));}
else{
t11=t8;
f_2124(t11,C_SCHEME_FALSE);}}}}
else{
/* g187189 */
f_2057(t1,t2);}}

/* k2122 in a2054 in k2048 in a2045 in k2036 in k2030 in k2026 in k2022 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2124,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2131,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* append */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[78],"link-options"),t2);}
else{
/* g187189 */
f_2057(((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k2129 in k2122 in a2054 in k2048 in a2045 in k2036 in k2030 in k2026 in k2022 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[78],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2109 in a2054 in k2048 in a2045 in k2036 in k2030 in k2026 in k2022 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[75],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* g187 in a2054 in k2048 in a2045 in k2036 in k2030 in k2026 in k2022 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2057(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2057,NULL,2,t1,t2);}
/* csc.scm: 777  error */
t3=*((C_word*)lf[150]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[151],t2);}

/* k2039 in k2036 in k2030 in k2026 in k2022 in k2019 in k2016 in k2013 in a2010 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 779  $delete-file */
t2=C_retrieve2(lf[123],"$delete-file");
f_2854(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2001 in k762 in k759 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[81],"keep-files"))){
t2=((C_word*)t0)[2];
f_679(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[123],"$delete-file"),C_SCHEME_END_OF_LIST);}}

/* k721 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_726,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_nullp(C_retrieve2(lf[46],"c-files"));
t4=(C_truep(t3)?C_retrieve2(lf[48],"object-files"):C_retrieve2(lf[46],"c-files"));
/* csc.scm: 499  last */
t5=C_retrieve(lf[148]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}

/* k724 in k721 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_726,2,t0,t1);}
if(C_truep(C_retrieve2(lf[79],"target-filename"))){
t2=((C_word*)t0)[2];
f_679(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_733,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[85],"shared"))){
/* csc.scm: 503  pathname-replace-extension */
t3=C_retrieve(lf[147]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_retrieve2(lf[35],"shared-library-extension"));}
else{
/* csc.scm: 504  pathname-replace-extension */
t3=C_retrieve(lf[147]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_retrieve2(lf[33],"executable-extension"));}}}

/* k731 in k724 in k721 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[79],t1);
t3=((C_word*)t0)[2];
f_679(2,t3,t2);}

/* k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_679,2,t0,t1);}
if(C_truep(C_retrieve2(lf[82],"translate-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_685,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2280,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2296,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_retrieve2(lf[46],"c-files"));}}

/* a2295 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2296,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2300,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 790  pathname-replace-extension */
t4=C_retrieve(lf[147]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_retrieve2(lf[31],"object-extension"));}

/* k2298 in a2295 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2303,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2321,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2325,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[50],"cpp-mode"))?C_retrieve2(lf[28],"c++-compiler"):C_retrieve2(lf[27],"compiler"));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2337,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 796  cleanup-filename */
t7=C_retrieve2(lf[40],"cleanup-filename");
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2335 in k2298 in a2295 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2349,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 797  cleanup-filename */
t4=C_retrieve2(lf[40],"cleanup-filename");
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2347 in k2335 in k2298 in a2295 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 797  string-append */
t2=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[146],t1);}

/* k2339 in k2335 in k2298 in a2295 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2345,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 799  compiler-options */
f_2351(t2);}

/* k2343 in k2339 in k2335 in k2298 in a2295 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2345,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[145],t1);
/* csc.scm: 793  string-intersperse */
t3=C_retrieve(lf[92]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2323 in k2298 in a2295 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 792  $system */
t2=C_retrieve2(lf[118],"$system");
f_2822(3,t2,((C_word*)t0)[2],t1);}

/* k2319 in k2298 in a2295 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2303(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 800  exit */
t2=C_retrieve(lf[8]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[117],"last-exit-code"));}}

/* k2301 in k2298 in a2295 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2303,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_retrieve2(lf[49],"generated-object-files"));
t3=C_mutate(&lf[49],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2278 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2284,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2294,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 804  reverse */
t4=*((C_word*)lf[97]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2292 in k2278 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 804  append */
t2=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[48],"object-files"));}

/* k2282 in k2278 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[48],t1);
if(C_truep(C_retrieve2(lf[81],"keep-files"))){
t3=((C_word*)t0)[2];
f_685(2,t3,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t3=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[123],"$delete-file"),C_retrieve2(lf[47],"generated-c-files"));}}

/* k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_685,2,t0,t1);}
if(C_truep(C_retrieve2(lf[83],"compile-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_691,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_member(C_retrieve2(lf[79],"target-filename"),C_retrieve2(lf[45],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_700,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 518  printf */
t4=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[144],C_retrieve2(lf[79],"target-filename"),C_retrieve2(lf[79],"target-filename"));}
else{
t3=t2;
f_691(2,t3,C_SCHEME_UNDEFINED);}}}

/* k698 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_713,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_717,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 520  sprintf */
t4=C_retrieve(lf[142]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[143],C_retrieve2(lf[79],"target-filename"),C_retrieve2(lf[79],"target-filename"));}

/* k715 in k698 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 520  $system */
t2=C_retrieve2(lf[118],"$system");
f_2822(3,t2,((C_word*)t0)[2],t1);}

/* k711 in k698 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_691(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 521  exit */
t2=C_retrieve(lf[8]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[117],"last-exit-code"));}}

/* k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_691,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2376,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2485,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2489,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2491,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2497,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 821  ##sys#call-with-values */
C_call_with_values(4,0,t5,t6,t7);}

/* a2496 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2497(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2497r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2497r(t0,t1,t2);}}

static void C_ccall f_2497r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a2490 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2491,2,t0,t1);}
/* csc.scm: 821  static-extension-info */
f_2503(t1);}

/* k2487 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 820  append */
t2=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[48],"object-files"),t1);}

/* k2483 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[40],"cleanup-filename"),t1);}

/* k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2379,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 822  cleanup-filename */
t3=C_retrieve2(lf[40],"cleanup-filename");
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve2(lf[79],"target-filename"));}

/* k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2382,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2449,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2453,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2457,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_truep(C_retrieve2(lf[50],"cpp-mode"))?C_retrieve2(lf[30],"c++-linker"):C_retrieve2(lf[29],"linker"));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2465,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2473,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 830  string-append */
t9=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,lf[141],t1);}

/* k2471 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 831  linker-options */
f_2600(t2);}

/* k2475 in k2471 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 832  linker-libraries */
f_2646(t2,(C_word)C_a_i_list(&a,1,C_SCHEME_FALSE));}

/* k2479 in k2475 in k2471 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2481,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],t1);
/* csc.scm: 828  append */
t3=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2463 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 826  cons* */
t2=C_retrieve(lf[114]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2455 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 825  string-intersperse */
t2=C_retrieve(lf[92]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2451 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 824  $system */
t2=C_retrieve2(lf[118],"$system");
f_2822(3,t2,((C_word*)t0)[2],t1);}

/* k2447 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2382(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 833  exit */
t2=C_retrieve(lf[8]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[117],"last-exit-code"));}}

/* k2380 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2385,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2394,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[5],"osx"))){
t4=(C_word)C_i_not(C_retrieve2(lf[16],"cross-chicken"));
t5=t3;
f_2394(t5,(C_truep(t4)?t4:C_retrieve2(lf[15],"host-mode")));}
else{
t4=t3;
f_2394(t4,C_SCHEME_FALSE);}}

/* k2392 in k2380 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2394(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2394,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2411,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2415,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2419,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2423,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2427,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[15],"host-mode"))){
/* ##sys#peek-c-string */
t8=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t8=*((C_word*)lf[140]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}
else{
t2=((C_word*)t0)[3];
f_2385(2,t2,C_SCHEME_UNDEFINED);}}

/* k2425 in k2392 in k2380 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 840  prefix */
f_435(((C_word*)t0)[2],lf[138],lf[139],t1);}

/* k2421 in k2392 in k2380 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 839  make-pathname */
t2=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[137]);}

/* k2417 in k2392 in k2380 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 838  quotewrap */
f_448(((C_word*)t0)[2],t1);}

/* k2413 in k2392 in k2380 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 836  string-append */
t2=*((C_word*)lf[20]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[135],t1,lf[136],((C_word*)t0)[2]);}

/* k2409 in k2392 in k2380 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 835  $system */
t2=C_retrieve2(lf[118],"$system");
f_2822(3,t2,((C_word*)t0)[2],t1);}

/* k2405 in k2392 in k2380 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2385(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 847  exit */
t2=C_retrieve(lf[8]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[117],"last-exit-code"));}}

/* k2383 in k2380 in k2377 in k2374 in k689 in k683 in k677 in k674 in loop in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[81],"keep-files"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[123],"$delete-file"),C_retrieve2(lf[49],"generated-object-files"));}}

/* shared-build in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_640(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_640,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_645,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 479  cons* */
t4=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[132],lf[133],C_retrieve2(lf[70],"translate-options"));}

/* k643 in shared-build in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_645,2,t0,t1);}
t2=C_mutate(&lf[70],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 480  append */
t4=*((C_word*)lf[95]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[39],"pic-options"),lf[131],C_retrieve2(lf[75],"compile-options"));}

/* k647 in k643 in shared-build in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_649,2,t0,t1);}
t2=C_mutate(&lf[75],t1);
t3=(C_truep(C_retrieve2(lf[5],"osx"))?(C_truep(((C_word*)t0)[3])?lf[128]:lf[129]):lf[130]);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[78],"link-options"));
t5=C_mutate(&lf[78],t4);
t6=lf[85]=C_SCHEME_TRUE;;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* check in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_601(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_601,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_619,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t7=t6;
f_619(2,t7,C_fix(1));}
else{
t7=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_619(2,t8,(C_word)C_i_car(t4));}
else{
/* csc.scm: 475  ##sys#error */
t8=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t4);}}}

/* k617 in check in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_619,2,t0,t1);}
if(C_truep((C_word)C_i_greater_or_equalp(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 476  quit */
f_406(((C_word*)t0)[3],lf[127],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* t-options in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_594(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_594,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_599,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 472  append */
t4=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[70],"translate-options"),t2);}

/* k597 in t-options in k2878 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[70],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2868 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2873,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2876,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[126]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2874 in k2868 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2871 in k2868 in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* $delete-file in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2854,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2858,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[80],"verbose"))){
/* csc.scm: 926  print */
t4=*((C_word*)lf[122]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[125],t2);}
else{
t4=t3;
f_2858(2,t4,C_SCHEME_UNDEFINED);}}

/* k2856 in $delete-file in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[57],"dry-run"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 927  delete-file */
t2=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* $system in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2822,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2826,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[80],"verbose"))){
/* csc.scm: 913  print */
t4=*((C_word*)lf[122]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2826(2,t4,C_SCHEME_UNDEFINED);}}

/* k2824 in $system in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[57],"dry-run"))){
t3=t2;
f_2830(t3,C_fix(0));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2849,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 917  system */
t4=C_retrieve(lf[121]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k2847 in k2824 in $system in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_zerop(t1);
t3=((C_word*)t0)[2];
f_2830(t3,(C_truep(t2)?C_fix(0):C_fix(1)));}

/* k2828 in k2824 in $system in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2830,NULL,2,t0,t1);}
t2=C_mutate(&lf[117],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2833,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_zerop(C_retrieve2(lf[117],"last-exit-code")))){
t4=t3;
f_2833(2,t4,C_SCHEME_UNDEFINED);}
else{
/* csc.scm: 921  printf */
t4=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[120],C_retrieve2(lf[117],"last-exit-code"),((C_word*)t0)[2]);}}

/* k2831 in k2828 in k2824 in $system in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve2(lf[117],"last-exit-code"));}

/* quote-option in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2793(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2793,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2800,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2805,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2819,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t6=C_retrieve(lf[115]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2817 in quote-option in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 904  any */
t2=C_retrieve(lf[116]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2804 in quote-option in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2805,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_whitespacep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,lf[107])));}

/* k2798 in quote-option in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2800,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2726,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2740,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2744,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=C_retrieve(lf[115]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k2742 in k2798 in quote-option in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2744,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2746,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2746(t5,((C_word*)t0)[2],t1);}

/* fold in k2742 in k2798 in quote-option in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2746(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2746,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_memq(t3,lf[107]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2769,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* csc.scm: 895  fold */
t9=t4;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2776,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_whitespacep(t3))){
t5=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t6=t4;
f_2776(t6,t5);}
else{
t5=t4;
f_2776(t5,C_SCHEME_UNDEFINED);}}}}

/* k2774 in fold in k2742 in k2798 in quote-option in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2776(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2776,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2783,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csc.scm: 898  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2746(t4,t2,t3);}

/* k2781 in k2774 in fold in k2742 in k2798 in quote-option in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2783,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2767 in fold in k2742 in k2798 in quote-option in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 895  cons* */
t2=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_make_character(92),((C_word*)t0)[2],t1);}

/* k2738 in k2798 in quote-option in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=C_retrieve(lf[113]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2724 in k2798 in quote-option in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2726,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2736,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 900  string-translate* */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,lf[112]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k2734 in k2724 in k2798 in quote-option in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 900  string-append */
t2=*((C_word*)lf[20]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[109],t1,lf[110]);}

/* linker-libraries in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2646(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2646,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2650,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_2650(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2650(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k2648 in linker-libraries in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2657,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2661,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2690,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2696,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 876  ##sys#call-with-values */
C_call_with_values(4,0,t3,t4,t5);}
else{
t4=t3;
f_2661(2,t4,C_SCHEME_END_OF_LIST);}}

/* a2695 in k2648 in linker-libraries in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2696r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2696r(t0,t1,t2);}}

static void C_ccall f_2696r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a2689 in k2648 in linker-libraries in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2690,2,t0,t1);}
/* csc.scm: 876  static-extension-info */
f_2503(t1);}

/* k2659 in k2648 in linker-libraries in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2661,2,t0,t1);}
t2=C_retrieve2(lf[86],"static");
t3=(C_truep(t2)?t2:C_retrieve2(lf[87],"static-libs"));
t4=(C_truep(t3)?C_retrieve2(lf[58],"extra-libraries"):C_retrieve2(lf[59],"extra-shared-libraries"));
t5=C_retrieve2(lf[86],"static");
t6=(C_truep(t5)?t5:C_retrieve2(lf[87],"static-libs"));
t7=(C_truep(t6)?(C_truep(C_retrieve2(lf[90],"gui"))?C_retrieve2(lf[66],"gui-library-files"):C_retrieve2(lf[68],"library-files")):(C_truep(C_retrieve2(lf[90],"gui"))?C_retrieve2(lf[67],"gui-shared-library-files"):C_retrieve2(lf[69],"shared-library-files")));
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
/* csc.scm: 875  append */
t9=*((C_word*)lf[95]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[2],t1,t8);}

/* k2655 in k2648 in linker-libraries in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 874  string-intersperse */
t2=C_retrieve(lf[92]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* linker-options in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2600(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2600,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2608,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2628,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2632,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2634,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2640,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 870  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a2639 in linker-options in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2640r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2640r(t0,t1,t2);}}

static void C_ccall f_2640r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(1)));}

/* a2633 in linker-options in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2634,2,t0,t1);}
/* csc.scm: 870  static-extension-info */
f_2503(t1);}

/* k2630 in linker-options in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 869  append */
t2=*((C_word*)lf[95]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_retrieve2(lf[77],"linking-optimization-options"),C_retrieve2(lf[78],"link-options"),t1);}

/* k2626 in linker-options in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 868  string-intersperse */
t2=C_retrieve(lf[92]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2606 in linker-options in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(C_retrieve2(lf[86],"static"))?(C_truep(lf[3])?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve2(lf[5],"osx"))):C_SCHEME_FALSE);
t3=(C_truep(t2)?lf[103]:lf[104]);
/* csc.scm: 867  string-append */
t4=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t1,t3);}

/* static-extension-info in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2503(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2503,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2507,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 851  repository-path */
t3=C_retrieve(lf[101]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2505 in static-extension-info in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2507,2,t0,t1);}
t2=C_retrieve2(lf[86],"static");
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_2513(t4,t2);}
else{
t4=C_retrieve2(lf[87],"static-libs");
t5=t3;
f_2513(t5,(C_truep(t4)?t4:C_retrieve2(lf[88],"static-extensions")));}}

/* k2511 in k2505 in static-extension-info in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2513(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2513,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2518,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2518(t5,((C_word*)t0)[2],C_retrieve2(lf[89],"required-extensions"),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
/* csc.scm: 864  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* loop in k2511 in k2505 in static-extension-info in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2518(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2518,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2532,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 855  reverse */
t6=*((C_word*)lf[97]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2539,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
/* csc.scm: 856  extension-information */
t7=C_retrieve(lf[100]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k2537 in loop in k2511 in k2505 in static-extension-info in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2539,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[98],t1);
t3=(C_word)C_i_assq(lf[99],t1);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2577,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* csc.scm: 861  make-pathname */
t8=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}
else{
t6=t5;
f_2559(t6,((C_word*)t0)[3]);}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* csc.scm: 863  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2518(t3,((C_word*)t0)[5],t2,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k2575 in k2537 in loop in k2511 in k2505 in static-extension-info in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2577,2,t0,t1);}
t2=((C_word*)t0)[3];
f_2559(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2557 in k2537 in loop in k2511 in k2505 in static-extension-info in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2559(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2559,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2563,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=t2;
f_2563(t4,(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]));}
else{
t3=t2;
f_2563(t3,((C_word*)t0)[2]);}}

/* k2561 in k2557 in k2537 in loop in k2511 in k2505 in static-extension-info in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2563(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 860  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2518(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2530 in loop in k2511 in k2505 in static-extension-info in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2536,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 855  reverse */
t3=*((C_word*)lf[97]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2534 in k2530 in loop in k2511 in k2505 in static-extension-info in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 855  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* compiler-options in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_2351(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2351,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2363,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve2(lf[86],"static");
t5=(C_truep(t4)?t4:C_retrieve2(lf[87],"static-libs"));
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_END_OF_LIST);
/* csc.scm: 810  append */
t7=*((C_word*)lf[95]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t3,t6,C_retrieve2(lf[76],"compilation-optimization-options"),C_retrieve2(lf[75],"compile-options"));}

/* k2361 in compiler-options in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[94],"quote-option"),t1);}

/* k2357 in compiler-options in k569 in k554 in k2991 in k3013 in k535 in k531 in k505 in k500 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 808  string-intersperse */
t2=C_retrieve(lf[92]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_3069 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3069,3,t0,t1,t2);}
/* csc.scm: 165  quotewrap */
f_448(t1,t2);}

/* f_3074 in k480 in k476 in k472 in k468 in k464 in k460 in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3074,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* quotewrap in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_448(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_448,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_455,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 134  string-any */
t4=C_retrieve(lf[23]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,*((C_word*)lf[24]+1),t2);}

/* k453 in quotewrap in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csc.scm: 135  string-append */
t2=*((C_word*)lf[20]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[21],((C_word*)t0)[2],lf[22]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* prefix in k423 in k419 in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_435(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_435,NULL,4,t1,t2,t3,t4);}
if(C_truep(C_retrieve2(lf[12],"chicken-prefix"))){
t5=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[12],"chicken-prefix"),t3);
/* csc.scm: 130  make-pathname */
t6=C_retrieve(lf[18]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t5,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* quit in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_fcall f_406(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_406,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_410,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_417,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 120  current-error-port */
t6=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k415 in quit in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 120  fprintf */
t2=C_retrieve(lf[9]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],t1,lf[10],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k408 in quit in k402 in k3167 in k3171 in k390 in k387 in k384 in k381 in k378 in k375 in k372 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 121  exit */
t2=C_retrieve(lf[8]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[298] = {
{"toplevelcsc.scm",(void*)C_toplevel},
{"f_374csc.scm",(void*)f_374},
{"f_377csc.scm",(void*)f_377},
{"f_380csc.scm",(void*)f_380},
{"f_383csc.scm",(void*)f_383},
{"f_386csc.scm",(void*)f_386},
{"f_389csc.scm",(void*)f_389},
{"f_392csc.scm",(void*)f_392},
{"f_3173csc.scm",(void*)f_3173},
{"f_3169csc.scm",(void*)f_3169},
{"f_3165csc.scm",(void*)f_3165},
{"f_3161csc.scm",(void*)f_3161},
{"f_404csc.scm",(void*)f_404},
{"f_421csc.scm",(void*)f_421},
{"f_425csc.scm",(void*)f_425},
{"f_3145csc.scm",(void*)f_3145},
{"f_3141csc.scm",(void*)f_3141},
{"f_462csc.scm",(void*)f_462},
{"f_3127csc.scm",(void*)f_3127},
{"f_3131csc.scm",(void*)f_3131},
{"f_3123csc.scm",(void*)f_3123},
{"f_3119csc.scm",(void*)f_3119},
{"f_466csc.scm",(void*)f_466},
{"f_3109csc.scm",(void*)f_3109},
{"f_470csc.scm",(void*)f_470},
{"f_3099csc.scm",(void*)f_3099},
{"f_474csc.scm",(void*)f_474},
{"f_3089csc.scm",(void*)f_3089},
{"f_478csc.scm",(void*)f_478},
{"f_3079csc.scm",(void*)f_3079},
{"f_482csc.scm",(void*)f_482},
{"f_3059csc.scm",(void*)f_3059},
{"f_502csc.scm",(void*)f_502},
{"f_3049csc.scm",(void*)f_3049},
{"f_507csc.scm",(void*)f_507},
{"f_533csc.scm",(void*)f_533},
{"f_537csc.scm",(void*)f_537},
{"f_3027csc.scm",(void*)f_3027},
{"f_3023csc.scm",(void*)f_3023},
{"f_3019csc.scm",(void*)f_3019},
{"f_3015csc.scm",(void*)f_3015},
{"f_3005csc.scm",(void*)f_3005},
{"f_3001csc.scm",(void*)f_3001},
{"f_2997csc.scm",(void*)f_2997},
{"f_2993csc.scm",(void*)f_2993},
{"f_2983csc.scm",(void*)f_2983},
{"f_556csc.scm",(void*)f_556},
{"f_2960csc.scm",(void*)f_2960},
{"f_2956csc.scm",(void*)f_2956},
{"f_2952csc.scm",(void*)f_2952},
{"f_2926csc.scm",(void*)f_2926},
{"f_2942csc.scm",(void*)f_2942},
{"f_2938csc.scm",(void*)f_2938},
{"f_2934csc.scm",(void*)f_2934},
{"f_2930csc.scm",(void*)f_2930},
{"f_2913csc.scm",(void*)f_2913},
{"f_2909csc.scm",(void*)f_2909},
{"f_2905csc.scm",(void*)f_2905},
{"f_2901csc.scm",(void*)f_2901},
{"f_571csc.scm",(void*)f_571},
{"f_2888csc.scm",(void*)f_2888},
{"f_2884csc.scm",(void*)f_2884},
{"f_2880csc.scm",(void*)f_2880},
{"f_666csc.scm",(void*)f_666},
{"f_840csc.scm",(void*)f_840},
{"f_1304csc.scm",(void*)f_1304},
{"f_1545csc.scm",(void*)f_1545},
{"f_1548csc.scm",(void*)f_1548},
{"f_1551csc.scm",(void*)f_1551},
{"f_1933csc.scm",(void*)f_1933},
{"f_1602csc.scm",(void*)f_1602},
{"f_1611csc.scm",(void*)f_1611},
{"f_1788csc.scm",(void*)f_1788},
{"f_1896csc.scm",(void*)f_1896},
{"f_1902csc.scm",(void*)f_1902},
{"f_1799csc.scm",(void*)f_1799},
{"f_1810csc.scm",(void*)f_1810},
{"f_1886csc.scm",(void*)f_1886},
{"f_1878csc.scm",(void*)f_1878},
{"f_1861csc.scm",(void*)f_1861},
{"f_1837csc.scm",(void*)f_1837},
{"f_1842csc.scm",(void*)f_1842},
{"f_1824csc.scm",(void*)f_1824},
{"f_1793csc.scm",(void*)f_1793},
{"f_1758csc.scm",(void*)f_1758},
{"f_1689csc.scm",(void*)f_1689},
{"f_1741csc.scm",(void*)f_1741},
{"f_1737csc.scm",(void*)f_1737},
{"f_1722csc.scm",(void*)f_1722},
{"f_1720csc.scm",(void*)f_1720},
{"f_1716csc.scm",(void*)f_1716},
{"f_1693csc.scm",(void*)f_1693},
{"f_1679csc.scm",(void*)f_1679},
{"f_1666csc.scm",(void*)f_1666},
{"f_1649csc.scm",(void*)f_1649},
{"f_1635csc.scm",(void*)f_1635},
{"f_1621csc.scm",(void*)f_1621},
{"f_1583csc.scm",(void*)f_1583},
{"f_1589csc.scm",(void*)f_1589},
{"f_1592csc.scm",(void*)f_1592},
{"f_1538csc.scm",(void*)f_1538},
{"f_1542csc.scm",(void*)f_1542},
{"f_1492csc.scm",(void*)f_1492},
{"f_1522csc.scm",(void*)f_1522},
{"f_1514csc.scm",(void*)f_1514},
{"f_1502csc.scm",(void*)f_1502},
{"f_1481csc.scm",(void*)f_1481},
{"f_1456csc.scm",(void*)f_1456},
{"f_1468csc.scm",(void*)f_1468},
{"f_1460csc.scm",(void*)f_1460},
{"f_1443csc.scm",(void*)f_1443},
{"f_1417csc.scm",(void*)f_1417},
{"f_1429csc.scm",(void*)f_1429},
{"f_1421csc.scm",(void*)f_1421},
{"f_1396csc.scm",(void*)f_1396},
{"f_1400csc.scm",(void*)f_1400},
{"f_1379csc.scm",(void*)f_1379},
{"f_1362csc.scm",(void*)f_1362},
{"f_1345csc.scm",(void*)f_1345},
{"f_1328csc.scm",(void*)f_1328},
{"f_1287csc.scm",(void*)f_1287},
{"f_1277csc.scm",(void*)f_1277},
{"f_1267csc.scm",(void*)f_1267},
{"f_1257csc.scm",(void*)f_1257},
{"f_1247csc.scm",(void*)f_1247},
{"f_1237csc.scm",(void*)f_1237},
{"f_1216csc.scm",(void*)f_1216},
{"f_1192csc.scm",(void*)f_1192},
{"f_1203csc.scm",(void*)f_1203},
{"f_1195csc.scm",(void*)f_1195},
{"f_1179csc.scm",(void*)f_1179},
{"f_1139csc.scm",(void*)f_1139},
{"f_1143csc.scm",(void*)f_1143},
{"f_1146csc.scm",(void*)f_1146},
{"f_1058csc.scm",(void*)f_1058},
{"f_1062csc.scm",(void*)f_1062},
{"f_1001csc.scm",(void*)f_1001},
{"f_989csc.scm",(void*)f_989},
{"f_977csc.scm",(void*)f_977},
{"f_965csc.scm",(void*)f_965},
{"f_932csc.scm",(void*)f_932},
{"f_921csc.scm",(void*)f_921},
{"f_890csc.scm",(void*)f_890},
{"f_883csc.scm",(void*)f_883},
{"f_874csc.scm",(void*)f_874},
{"f_867csc.scm",(void*)f_867},
{"f_855csc.scm",(void*)f_855},
{"f_843csc.scm",(void*)f_843},
{"f_831csc.scm",(void*)f_831},
{"f_798csc.scm",(void*)f_798},
{"f_824csc.scm",(void*)f_824},
{"f_801csc.scm",(void*)f_801},
{"f_817csc.scm",(void*)f_817},
{"f_804csc.scm",(void*)f_804},
{"f_807csc.scm",(void*)f_807},
{"f_676csc.scm",(void*)f_676},
{"f_761csc.scm",(void*)f_761},
{"f_771csc.scm",(void*)f_771},
{"f_764csc.scm",(void*)f_764},
{"f_2011csc.scm",(void*)f_2011},
{"f_2015csc.scm",(void*)f_2015},
{"f_2262csc.scm",(void*)f_2262},
{"f_2265csc.scm",(void*)f_2265},
{"f_2256csc.scm",(void*)f_2256},
{"f_2018csc.scm",(void*)f_2018},
{"f_2021csc.scm",(void*)f_2021},
{"f_2193csc.scm",(void*)f_2193},
{"f_2235csc.scm",(void*)f_2235},
{"f_2201csc.scm",(void*)f_2201},
{"f_2216csc.scm",(void*)f_2216},
{"f_2221csc.scm",(void*)f_2221},
{"f_2205csc.scm",(void*)f_2205},
{"f_2213csc.scm",(void*)f_2213},
{"f_2209csc.scm",(void*)f_2209},
{"f_2197csc.scm",(void*)f_2197},
{"f_2189csc.scm",(void*)f_2189},
{"f_2185csc.scm",(void*)f_2185},
{"f_2181csc.scm",(void*)f_2181},
{"f_2024csc.scm",(void*)f_2024},
{"f_2028csc.scm",(void*)f_2028},
{"f_2032csc.scm",(void*)f_2032},
{"f_2038csc.scm",(void*)f_2038},
{"f_2046csc.scm",(void*)f_2046},
{"f_2050csc.scm",(void*)f_2050},
{"f_2163csc.scm",(void*)f_2163},
{"f_2055csc.scm",(void*)f_2055},
{"f_2124csc.scm",(void*)f_2124},
{"f_2131csc.scm",(void*)f_2131},
{"f_2111csc.scm",(void*)f_2111},
{"f_2057csc.scm",(void*)f_2057},
{"f_2041csc.scm",(void*)f_2041},
{"f_2003csc.scm",(void*)f_2003},
{"f_723csc.scm",(void*)f_723},
{"f_726csc.scm",(void*)f_726},
{"f_733csc.scm",(void*)f_733},
{"f_679csc.scm",(void*)f_679},
{"f_2296csc.scm",(void*)f_2296},
{"f_2300csc.scm",(void*)f_2300},
{"f_2337csc.scm",(void*)f_2337},
{"f_2349csc.scm",(void*)f_2349},
{"f_2341csc.scm",(void*)f_2341},
{"f_2345csc.scm",(void*)f_2345},
{"f_2325csc.scm",(void*)f_2325},
{"f_2321csc.scm",(void*)f_2321},
{"f_2303csc.scm",(void*)f_2303},
{"f_2280csc.scm",(void*)f_2280},
{"f_2294csc.scm",(void*)f_2294},
{"f_2284csc.scm",(void*)f_2284},
{"f_685csc.scm",(void*)f_685},
{"f_700csc.scm",(void*)f_700},
{"f_717csc.scm",(void*)f_717},
{"f_713csc.scm",(void*)f_713},
{"f_691csc.scm",(void*)f_691},
{"f_2497csc.scm",(void*)f_2497},
{"f_2491csc.scm",(void*)f_2491},
{"f_2489csc.scm",(void*)f_2489},
{"f_2485csc.scm",(void*)f_2485},
{"f_2376csc.scm",(void*)f_2376},
{"f_2379csc.scm",(void*)f_2379},
{"f_2473csc.scm",(void*)f_2473},
{"f_2477csc.scm",(void*)f_2477},
{"f_2481csc.scm",(void*)f_2481},
{"f_2465csc.scm",(void*)f_2465},
{"f_2457csc.scm",(void*)f_2457},
{"f_2453csc.scm",(void*)f_2453},
{"f_2449csc.scm",(void*)f_2449},
{"f_2382csc.scm",(void*)f_2382},
{"f_2394csc.scm",(void*)f_2394},
{"f_2427csc.scm",(void*)f_2427},
{"f_2423csc.scm",(void*)f_2423},
{"f_2419csc.scm",(void*)f_2419},
{"f_2415csc.scm",(void*)f_2415},
{"f_2411csc.scm",(void*)f_2411},
{"f_2407csc.scm",(void*)f_2407},
{"f_2385csc.scm",(void*)f_2385},
{"f_640csc.scm",(void*)f_640},
{"f_645csc.scm",(void*)f_645},
{"f_649csc.scm",(void*)f_649},
{"f_601csc.scm",(void*)f_601},
{"f_619csc.scm",(void*)f_619},
{"f_594csc.scm",(void*)f_594},
{"f_599csc.scm",(void*)f_599},
{"f_2870csc.scm",(void*)f_2870},
{"f_2876csc.scm",(void*)f_2876},
{"f_2873csc.scm",(void*)f_2873},
{"f_2854csc.scm",(void*)f_2854},
{"f_2858csc.scm",(void*)f_2858},
{"f_2822csc.scm",(void*)f_2822},
{"f_2826csc.scm",(void*)f_2826},
{"f_2849csc.scm",(void*)f_2849},
{"f_2830csc.scm",(void*)f_2830},
{"f_2833csc.scm",(void*)f_2833},
{"f_2793csc.scm",(void*)f_2793},
{"f_2819csc.scm",(void*)f_2819},
{"f_2805csc.scm",(void*)f_2805},
{"f_2800csc.scm",(void*)f_2800},
{"f_2744csc.scm",(void*)f_2744},
{"f_2746csc.scm",(void*)f_2746},
{"f_2776csc.scm",(void*)f_2776},
{"f_2783csc.scm",(void*)f_2783},
{"f_2769csc.scm",(void*)f_2769},
{"f_2740csc.scm",(void*)f_2740},
{"f_2726csc.scm",(void*)f_2726},
{"f_2736csc.scm",(void*)f_2736},
{"f_2646csc.scm",(void*)f_2646},
{"f_2650csc.scm",(void*)f_2650},
{"f_2696csc.scm",(void*)f_2696},
{"f_2690csc.scm",(void*)f_2690},
{"f_2661csc.scm",(void*)f_2661},
{"f_2657csc.scm",(void*)f_2657},
{"f_2600csc.scm",(void*)f_2600},
{"f_2640csc.scm",(void*)f_2640},
{"f_2634csc.scm",(void*)f_2634},
{"f_2632csc.scm",(void*)f_2632},
{"f_2628csc.scm",(void*)f_2628},
{"f_2608csc.scm",(void*)f_2608},
{"f_2503csc.scm",(void*)f_2503},
{"f_2507csc.scm",(void*)f_2507},
{"f_2513csc.scm",(void*)f_2513},
{"f_2518csc.scm",(void*)f_2518},
{"f_2539csc.scm",(void*)f_2539},
{"f_2577csc.scm",(void*)f_2577},
{"f_2559csc.scm",(void*)f_2559},
{"f_2563csc.scm",(void*)f_2563},
{"f_2532csc.scm",(void*)f_2532},
{"f_2536csc.scm",(void*)f_2536},
{"f_2351csc.scm",(void*)f_2351},
{"f_2363csc.scm",(void*)f_2363},
{"f_2359csc.scm",(void*)f_2359},
{"f_3069csc.scm",(void*)f_3069},
{"f_3074csc.scm",(void*)f_3074},
{"f_448csc.scm",(void*)f_448},
{"f_455csc.scm",(void*)f_455},
{"f_435csc.scm",(void*)f_435},
{"f_406csc.scm",(void*)f_406},
{"f_417csc.scm",(void*)f_417},
{"f_410csc.scm",(void*)f_410},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
