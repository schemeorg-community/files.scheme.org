/* Generated from eval.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-07 01:28
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-07 on galinha (Linux)
   command line: eval.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -unsafe -no-lambda-info -output-file ueval.c
   unit: eval
*/

#include "chicken.h"


#ifndef C_INSTALL_EGG_HOME
# define C_INSTALL_EGG_HOME    "."
#endif

#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif


#define C_store_result(x, ptr)   (*((C_word *)C_block_item(ptr, 0)) = (x), C_SCHEME_TRUE)


#define C_copy_result_string(str, buf, n)  (C_memcpy((char *)C_block_item(buf, 0), C_c_string(str), C_unfix(n)), ((char *)C_block_item(buf, 0))[ C_unfix(n) ] = '\0', C_SCHEME_TRUE)


C_externexport  void  CHICKEN_get_error_message(char *t0,int t1);

C_externexport  int  CHICKEN_load(char * t0);

C_externexport  int  CHICKEN_read(char * t0,C_word *t1);

C_externexport  int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3);

C_externexport  int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2);

C_externexport  int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_string(char * t0,C_word *t1);

C_externexport  int  CHICKEN_eval(C_word t0,C_word *t1);

C_externexport  int  CHICKEN_yield();

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[517];
static double C_possibly_force_alignment;


/* from ##sys#clear-trace-buffer in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static C_word C_fcall stub1336(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1336(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_clear_trace_buffer();
return C_r;}

C_noret_decl(C_eval_toplevel)
C_externexport void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11305)
static void C_ccall f_11305(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11305)
static void C_ccall f_11305r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11309)
static void C_fcall f_11309(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11333)
static void C_ccall f_11333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11327)
static void C_ccall f_11327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11317)
static void C_ccall f_11317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11315)
static void C_ccall f_11315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5940)
static void C_ccall f_5940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6039)
static void C_ccall f_6039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6119)
static void C_ccall f_6119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11299)
static void C_ccall f_11299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11295)
static void C_ccall f_11295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11291)
static void C_ccall f_11291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11287)
static void C_ccall f_11287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11277)
static void C_fcall f_11277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_fcall f_6638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6643)
static void C_ccall f_6643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11255)
static void C_ccall f_11255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11247)
static void C_ccall f_11247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11249)
static void C_ccall f_11249(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6650)
static void C_ccall f_6650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11237)
static void C_ccall f_11237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11240)
static void C_ccall f_11240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7003)
static void C_ccall f_7003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11183)
static void C_ccall f_11183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11197)
static void C_fcall f_11197(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11233)
static void C_ccall f_11233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11229)
static void C_ccall f_11229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11217)
static void C_ccall f_11217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11221)
static void C_ccall f_11221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11191)
static void C_ccall f_11191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7722)
static void C_ccall f_7722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11062)
static void C_ccall f_11062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11099)
static void C_fcall f_11099(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11108)
static void C_ccall f_11108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11127)
static void C_ccall f_11127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11131)
static void C_ccall f_11131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11117)
static void C_ccall f_11117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11114)
static void C_ccall f_11114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11065)
static void C_fcall f_11065(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7725)
static void C_ccall f_7725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7783)
static void C_ccall f_7783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11060)
static void C_ccall f_11060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8118)
static void C_ccall f_8118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8122)
static void C_ccall f_8122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11056)
static void C_ccall f_11056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8125)
static void C_ccall f_8125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8129)
static void C_ccall f_8129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10959)
static void C_ccall f_10959(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10965)
static void C_fcall f_10965(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10981)
static void C_ccall f_10981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10984)
static void C_ccall f_10984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11019)
static void C_ccall f_11019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11022)
static void C_ccall f_11022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11006)
static void C_ccall f_11006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11009)
static void C_ccall f_11009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11016)
static void C_ccall f_11016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8812)
static void C_ccall f_8812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10931)
static void C_ccall f_10931(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8815)
static void C_ccall f_8815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10888)
static void C_ccall f_10888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10910)
static void C_ccall f_10910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8818)
static void C_ccall f_8818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10691)
static void C_ccall f_10691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10697)
static void C_fcall f_10697(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10713)
static void C_ccall f_10713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10789)
static void C_fcall f_10789(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10846)
static void C_ccall f_10846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10792)
static void C_ccall f_10792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10819)
static void C_ccall f_10819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10752)
static void C_ccall f_10752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10771)
static void C_ccall f_10771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10743)
static void C_ccall f_10743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8821)
static void C_ccall f_8821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10588)
static void C_ccall f_10588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10598)
static void C_ccall f_10598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10611)
static void C_fcall f_10611(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10627)
static void C_ccall f_10627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10665)
static void C_ccall f_10665(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10663)
static void C_ccall f_10663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10655)
static void C_ccall f_10655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10609)
static void C_ccall f_10609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8824)
static void C_ccall f_8824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10535)
static void C_ccall f_10535(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10545)
static void C_ccall f_10545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10548)
static void C_ccall f_10548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10553)
static void C_fcall f_10553(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10578)
static void C_ccall f_10578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8827)
static void C_ccall f_8827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10465)
static void C_ccall f_10465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10475)
static void C_ccall f_10475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10478)
static void C_ccall f_10478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10525)
static void C_ccall f_10525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10489)
static void C_ccall f_10489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10511)
static void C_ccall f_10511(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10497)
static void C_ccall f_10497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10493)
static void C_ccall f_10493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8830)
static void C_ccall f_8830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10346)
static void C_ccall f_10346(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10346)
static void C_ccall f_10346r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10350)
static void C_ccall f_10350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10353)
static void C_ccall f_10353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10356)
static void C_ccall f_10356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10447)
static void C_ccall f_10447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10363)
static void C_ccall f_10363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10386)
static void C_fcall f_10386(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10400)
static void C_ccall f_10400(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10398)
static void C_ccall f_10398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8833)
static void C_ccall f_8833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10054)
static void C_ccall f_10054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10264)
static void C_fcall f_10264(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10268)
static void C_ccall f_10268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10289)
static void C_ccall f_10289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10331)
static void C_ccall f_10331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10067)
static void C_fcall f_10067(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10255)
static void C_ccall f_10255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10259)
static void C_ccall f_10259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10238)
static void C_ccall f_10238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10242)
static void C_ccall f_10242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10227)
static void C_ccall f_10227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10219)
static void C_ccall f_10219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10208)
static void C_ccall f_10208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10174)
static void C_ccall f_10174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10155)
static void C_ccall f_10155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10128)
static void C_ccall f_10128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10085)
static void C_ccall f_10085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10081)
static void C_ccall f_10081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10057)
static void C_fcall f_10057(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10065)
static void C_ccall f_10065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8836)
static void C_ccall f_8836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10044)
static void C_ccall f_10044(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8839)
static void C_ccall f_8839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9798)
static void C_ccall f_9798(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9953)
static void C_fcall f_9953(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10024)
static void C_ccall f_10024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9969)
static void C_ccall f_9969(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9967)
static void C_ccall f_9967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9811)
static void C_fcall f_9811(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9937)
static void C_ccall f_9937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9899)
static void C_ccall f_9899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9860)
static void C_ccall f_9860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9801)
static void C_fcall f_9801(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8842)
static void C_ccall f_8842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8846)
static void C_ccall f_8846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9795)
static void C_ccall f_9795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8868)
static void C_ccall f_8868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9228)
static void C_ccall f_9228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9653)
static void C_ccall f_9653(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9653)
static void C_ccall f_9653r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9771)
static void C_ccall f_9771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9774)
static void C_ccall f_9774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9761)
static void C_ccall f_9761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9656)
static void C_fcall f_9656(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9660)
static void C_fcall f_9660(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9671)
static void C_fcall f_9671(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9314)
static void C_ccall f_9314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9634)
static void C_ccall f_9634(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9634)
static void C_ccall f_9634r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9638)
static void C_ccall f_9638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9647)
static void C_ccall f_9647(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9645)
static void C_ccall f_9645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9317)
static void C_ccall f_9317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9628)
static void C_ccall f_9628(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9320)
static void C_ccall f_9320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9622)
static void C_ccall f_9622(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9323)
static void C_ccall f_9323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9613)
static void C_ccall f_9613(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9620)
static void C_ccall f_9620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9603)
static void C_ccall f_9603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9588)
static void C_ccall f_9588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9592)
static void C_ccall f_9592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9597)
static void C_ccall f_9597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9601)
static void C_ccall f_9601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9566)
static void C_ccall f_9566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9570)
static void C_ccall f_9570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9575)
static void C_ccall f_9575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9579)
static void C_ccall f_9579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9586)
static void C_ccall f_9586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9540)
static void C_ccall f_9540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9546)
static void C_ccall f_9546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9550)
static void C_ccall f_9550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9564)
static void C_ccall f_9564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9553)
static void C_ccall f_9553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9560)
static void C_ccall f_9560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9524)
static void C_ccall f_9524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9530)
static void C_ccall f_9530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9538)
static void C_ccall f_9538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9487)
static void C_ccall f_9487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9491)
static void C_ccall f_9491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9496)
static void C_ccall f_9496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9500)
static void C_ccall f_9500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9522)
static void C_ccall f_9522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9518)
static void C_ccall f_9518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9514)
static void C_ccall f_9514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9503)
static void C_ccall f_9503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9510)
static void C_ccall f_9510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9461)
static void C_ccall f_9461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9467)
static void C_ccall f_9467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9471)
static void C_ccall f_9471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9485)
static void C_ccall f_9485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9474)
static void C_ccall f_9474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9481)
static void C_ccall f_9481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9448)
static C_word C_fcall f_9448(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9422)
static void C_ccall f_9422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9426)
static void C_ccall f_9426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9431)
static void C_ccall f_9431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9435)
static void C_ccall f_9435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9446)
static void C_ccall f_9446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9442)
static void C_ccall f_9442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9406)
static void C_ccall f_9406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9412)
static void C_ccall f_9412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9420)
static void C_ccall f_9420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9394)
static void C_ccall f_9394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9400)
static void C_ccall f_9400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9404)
static void C_ccall f_9404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9385)
static void C_fcall f_9385(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9389)
static void C_ccall f_9389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9326)
static void C_fcall f_9326(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9336)
static void C_ccall f_9336(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9361)
static void C_ccall f_9361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9373)
static void C_ccall f_9373(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9373)
static void C_ccall f_9373r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9379)
static void C_ccall f_9379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9367)
static void C_ccall f_9367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9342)
static void C_ccall f_9342(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9348)
static void C_ccall f_9348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9352)
static void C_ccall f_9352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9355)
static void C_ccall f_9355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9359)
static void C_ccall f_9359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9334)
static void C_ccall f_9334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9239)
static void C_ccall f_9239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9249)
static void C_ccall f_9249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9252)
static void C_ccall f_9252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9266)
static void C_fcall f_9266(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9284)
static void C_ccall f_9284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9253)
static void C_fcall f_9253(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9230)
static void C_ccall f_9230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8889)
static void C_ccall f_8889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8933)
static void C_ccall f_8933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8936)
static void C_ccall f_8936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9213)
static void C_ccall f_9213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9217)
static void C_ccall f_9217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9221)
static void C_ccall f_9221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9018)
static void C_ccall f_9018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9024)
static void C_fcall f_9024(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9196)
static void C_ccall f_9196(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9202)
static void C_ccall f_9202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9031)
static void C_ccall f_9031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9034)
static void C_ccall f_9034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9037)
static void C_ccall f_9037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9191)
static void C_ccall f_9191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9046)
static void C_ccall f_9046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9049)
static void C_ccall f_9049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9064)
static void C_ccall f_9064(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9064)
static void C_ccall f_9064r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9082)
static void C_fcall f_9082(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9145)
static void C_ccall f_9145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9098)
static void C_ccall f_9098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9103)
static void C_ccall f_9103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9107)
static void C_ccall f_9107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9110)
static void C_ccall f_9110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9122)
static void C_ccall f_9122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9125)
static void C_ccall f_9125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9113)
static void C_ccall f_9113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9068)
static void C_ccall f_9068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8914)
static void C_fcall f_8914(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8919)
static void C_ccall f_8919(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9071)
static void C_ccall f_9071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9055)
static void C_ccall f_9055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8953)
static void C_ccall f_8953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8958)
static void C_ccall f_8958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8961)
static void C_ccall f_8961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8966)
static void C_ccall f_8966(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8966)
static void C_ccall f_8966r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8973)
static void C_ccall f_8973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9013)
static void C_ccall f_9013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8976)
static void C_ccall f_8976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8988)
static void C_fcall f_8988(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8997)
static void C_ccall f_8997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8991)
static void C_ccall f_8991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8979)
static void C_ccall f_8979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8982)
static void C_ccall f_8982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8944)
static C_word C_fcall f_8944(C_word t0);
C_noret_decl(f_8938)
static C_word C_fcall f_8938(C_word t0);
C_noret_decl(f_8892)
static void C_fcall f_8892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8898)
static void C_ccall f_8898(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8886)
static void C_ccall f_8886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8870)
static void C_ccall f_8870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8884)
static void C_ccall f_8884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8881)
static void C_ccall f_8881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8874)
static void C_ccall f_8874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8851)
static void C_ccall f_8851(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8860)
static void C_ccall f_8860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8855)
static void C_ccall f_8855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8420)
static void C_ccall f_8420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_8420)
static void C_ccall f_8420r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_8557)
static void C_fcall f_8557(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8562)
static void C_fcall f_8562(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8780)
static void C_ccall f_8780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8761)
static void C_ccall f_8761(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8707)
static void C_ccall f_8707(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8578)
static void C_fcall f_8578(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8583)
static void C_fcall f_8583(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8602)
static void C_ccall f_8602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8528)
static void C_ccall f_8528(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8534)
static C_word C_fcall f_8534(C_word t0);
C_noret_decl(f_8466)
static void C_ccall f_8466(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8470)
static void C_ccall f_8470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8478)
static void C_fcall f_8478(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8501)
static void C_ccall f_8501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8423)
static void C_fcall f_8423(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8430)
static void C_ccall f_8430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8435)
static void C_fcall f_8435(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8439)
static void C_ccall f_8439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8464)
static void C_ccall f_8464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8453)
static void C_ccall f_8453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8457)
static void C_ccall f_8457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8446)
static void C_ccall f_8446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8384)
static void C_ccall f_8384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8406)
static void C_ccall f_8406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8376)
static void C_ccall f_8376(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8376)
static void C_ccall f_8376r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8322)
static void C_ccall f_8322(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8326)
static void C_ccall f_8326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8329)
static void C_ccall f_8329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8332)
static void C_ccall f_8332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8335)
static void C_ccall f_8335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8338)
static void C_ccall f_8338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8341)
static void C_ccall f_8341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8344)
static void C_ccall f_8344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8347)
static void C_ccall f_8347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8350)
static void C_ccall f_8350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8301)
static void C_fcall f_8301(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8305)
static void C_ccall f_8305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8308)
static void C_ccall f_8308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8277)
static void C_fcall f_8277(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8283)
static void C_fcall f_8283(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8293)
static void C_ccall f_8293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8154)
static void C_ccall f_8154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8154)
static void C_ccall f_8154r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8212)
static void C_ccall f_8212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8263)
static void C_ccall f_8263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8222)
static void C_ccall f_8222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8224)
static void C_fcall f_8224(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8248)
static void C_ccall f_8248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8234)
static void C_ccall f_8234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8195)
static void C_fcall f_8195(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8160)
static void C_fcall f_8160(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8176)
static void C_ccall f_8176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8182)
static void C_ccall f_8182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8173)
static void C_ccall f_8173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8135)
static void C_fcall f_8135(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8139)
static void C_ccall f_8139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8102)
static void C_fcall f_8102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8104)
static void C_ccall f_8104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8108)
static void C_ccall f_8108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8064)
static void C_ccall f_8064(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8064)
static void C_ccall f_8064r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8071)
static void C_ccall f_8071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8078)
static void C_ccall f_8078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8020)
static void C_ccall f_8020(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8020)
static void C_ccall f_8020r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8053)
static void C_ccall f_8053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8040)
static void C_ccall f_8040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8017)
static void C_ccall f_8017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7898)
static void C_ccall f_7898(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7898)
static void C_ccall f_7898r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7992)
static void C_ccall f_7992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8002)
static void C_ccall f_8002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7990)
static void C_ccall f_7990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7919)
static void C_fcall f_7919(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7943)
static void C_fcall f_7943(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7962)
static void C_ccall f_7962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7937)
static void C_ccall f_7937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7790)
static void C_ccall f_7790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_7790)
static void C_ccall f_7790r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_7800)
static void C_ccall f_7800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7805)
static void C_fcall f_7805(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7832)
static void C_fcall f_7832(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7865)
static void C_ccall f_7865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7826)
static void C_ccall f_7826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7727)
static void C_ccall f_7727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7731)
static void C_ccall f_7731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7739)
static void C_fcall f_7739(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7759)
static void C_fcall f_7759(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7683)
static void C_ccall f_7683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7715)
static void C_ccall f_7715(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7701)
static void C_ccall f_7701(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7284)
static void C_ccall f_7284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7559)
static void C_fcall f_7559(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7568)
static void C_ccall f_7568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7594)
static void C_ccall f_7594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7596)
static void C_fcall f_7596(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7629)
static void C_ccall f_7629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7619)
static void C_ccall f_7619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7614)
static void C_ccall f_7614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7308)
static void C_fcall f_7308(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7318)
static void C_ccall f_7318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7452)
static void C_ccall f_7452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7533)
static void C_ccall f_7533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7464)
static void C_ccall f_7464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7479)
static void C_fcall f_7479(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7499)
static void C_ccall f_7499(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7497)
static void C_ccall f_7497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7483)
static void C_fcall f_7483(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7475)
static void C_ccall f_7475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7394)
static void C_ccall f_7394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7412)
static void C_fcall f_7412(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7420)
static void C_fcall f_7420(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_ccall f_7408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7367)
static void C_fcall f_7367(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7330)
static void C_ccall f_7330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7354)
static void C_ccall f_7354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7350)
static void C_ccall f_7350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7342)
static void C_ccall f_7342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7333)
static void C_fcall f_7333(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7287)
static void C_fcall f_7287(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7302)
static void C_ccall f_7302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7296)
static void C_ccall f_7296(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7235)
static void C_ccall f_7235(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7241)
static void C_fcall f_7241(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7255)
static void C_ccall f_7255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7258)
static void C_fcall f_7258(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7265)
static void C_ccall f_7265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7198)
static void C_ccall f_7198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7202)
static void C_ccall f_7202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7227)
static void C_ccall f_7227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7205)
static void C_ccall f_7205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7223)
static void C_ccall f_7223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7215)
static void C_ccall f_7215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7185)
static void C_ccall f_7185(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7185)
static void C_ccall f_7185r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7191)
static void C_ccall f_7191(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7171)
static void C_ccall f_7171(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7182)
static void C_ccall f_7182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7151)
static void C_ccall f_7151(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7151)
static void C_ccall f_7151r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7157)
static void C_ccall f_7157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7164)
static void C_ccall f_7164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7083)
static void C_ccall f_7083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7083)
static void C_ccall f_7083r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7146)
static void C_ccall f_7146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7087)
static void C_fcall f_7087(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7090)
static void C_ccall f_7090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7108)
static void C_ccall f_7108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7114)
static void C_ccall f_7114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7006)
static void C_ccall f_7006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7080)
static void C_ccall f_7080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7073)
static void C_ccall f_7073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7040)
static void C_ccall f_7040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7042)
static void C_fcall f_7042(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7055)
static void C_ccall f_7055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7009)
static void C_fcall f_7009(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7013)
static void C_ccall f_7013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7033)
static void C_ccall f_7033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7019)
static void C_ccall f_7019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7029)
static void C_ccall f_7029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6843)
static void C_ccall f_6843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6948)
static void C_fcall f_6948(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6965)
static void C_ccall f_6965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6973)
static void C_ccall f_6973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6870)
static void C_fcall f_6870(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6909)
static void C_ccall f_6909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6896)
static void C_ccall f_6896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6852)
static C_word C_fcall f_6852(C_word t0);
C_noret_decl(f_6846)
static void C_fcall f_6846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6796)
static void C_fcall f_6796(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6834)
static void C_ccall f_6834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6814)
static void C_ccall f_6814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6758)
static void C_ccall f_6758(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6758)
static void C_ccall f_6758r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6765)
static void C_ccall f_6765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6775)
static void C_ccall f_6775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6652)
static void C_ccall f_6652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6656)
static void C_ccall f_6656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6748)
static void C_ccall f_6748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6752)
static void C_ccall f_6752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6665)
static void C_fcall f_6665(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6734)
static void C_ccall f_6734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6668)
static void C_ccall f_6668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6717)
static void C_ccall f_6717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6720)
static void C_ccall f_6720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6723)
static void C_ccall f_6723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6671)
static void C_ccall f_6671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6676)
static void C_fcall f_6676(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6710)
static void C_ccall f_6710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6689)
static void C_ccall f_6689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6692)
static void C_fcall f_6692(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6612)
static void C_ccall f_6612(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6612)
static void C_ccall f_6612r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6633)
static void C_ccall f_6633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6616)
static void C_ccall f_6616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6630)
static void C_ccall f_6630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6619)
static void C_ccall f_6619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6627)
static void C_ccall f_6627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6622)
static void C_ccall f_6622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6576)
static void C_ccall f_6576(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6576)
static void C_ccall f_6576r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6584)
static void C_ccall f_6584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6554)
static void C_ccall f_6554(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6554)
static void C_ccall f_6554r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6167)
static void C_ccall f_6167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6167)
static void C_ccall f_6167r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6509)
static void C_fcall f_6509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6504)
static void C_fcall f_6504(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6169)
static void C_fcall f_6169(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6173)
static void C_fcall f_6173(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6437)
static void C_ccall f_6437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6452)
static void C_ccall f_6452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6455)
static void C_fcall f_6455(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6458)
static void C_ccall f_6458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6464)
static void C_ccall f_6464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6467)
static void C_ccall f_6467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6473)
static void C_ccall f_6473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6176)
static void C_ccall f_6176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6182)
static void C_ccall f_6182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6404)
static void C_ccall f_6404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6376)
static void C_ccall f_6376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6400)
static void C_ccall f_6400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6185)
static void C_ccall f_6185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6197)
static void C_ccall f_6197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6348)
static void C_ccall f_6348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6221)
static void C_ccall f_6221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6233)
static void C_ccall f_6233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6237)
static void C_ccall f_6237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6240)
static void C_ccall f_6240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6243)
static void C_ccall f_6243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6248)
static void C_fcall f_6248(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6258)
static void C_ccall f_6258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6313)
static void C_ccall f_6313(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6317)
static void C_ccall f_6317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6270)
static void C_ccall f_6270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6277)
static void C_ccall f_6277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6288)
static void C_ccall f_6288(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6288)
static void C_ccall f_6288r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6299)
static void C_ccall f_6299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6292)
static void C_ccall f_6292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6261)
static void C_ccall f_6261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6268)
static void C_ccall f_6268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6230)
static void C_ccall f_6230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6207)
static void C_ccall f_6207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6121)
static void C_fcall f_6121(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6131)
static C_word C_fcall f_6131(C_word t0,C_word t1);
C_noret_decl(f_6046)
static void C_ccall f_6046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6058)
static void C_fcall f_6058(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6071)
static void C_ccall f_6071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5957)
static void C_ccall f_5957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5970)
static void C_fcall f_5970(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6003)
static void C_ccall f_6003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5984)
static void C_ccall f_5984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5960)
static void C_fcall f_5960(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5943)
static void C_ccall f_5943(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5943)
static void C_ccall f_5943r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5951)
static void C_ccall f_5951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3704)
static void C_ccall f_3704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3704)
static void C_ccall f_3704r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5688)
static void C_fcall f_5688(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5905)
static void C_ccall f_5905(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5881)
static void C_ccall f_5881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5882)
static void C_ccall f_5882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5893)
static void C_ccall f_5893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5897)
static void C_ccall f_5897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5838)
static void C_ccall f_5838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5844)
static void C_ccall f_5844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5847)
static void C_ccall f_5847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5848)
static void C_ccall f_5848(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5867)
static void C_ccall f_5867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5871)
static void C_ccall f_5871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5874)
static void C_ccall f_5874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5799)
static void C_ccall f_5799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5803)
static void C_ccall f_5803(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5814)
static void C_ccall f_5814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5822)
static void C_ccall f_5822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5761)
static void C_ccall f_5761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5764)
static void C_ccall f_5764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5765)
static void C_ccall f_5765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5776)
static void C_ccall f_5776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5780)
static void C_ccall f_5780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5734)
static void C_ccall f_5734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5745)
static void C_ccall f_5745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5748)
static void C_ccall f_5748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5714)
static void C_ccall f_5714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5662)
static C_word C_fcall f_5662(C_word t0,C_word t1);
C_noret_decl(f_3932)
static void C_fcall f_3932(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4091)
static void C_fcall f_4091(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4120)
static void C_ccall f_4120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4126)
static void C_ccall f_4126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5495)
static void C_fcall f_5495(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5482)
static void C_ccall f_5482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5443)
static void C_ccall f_5443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5388)
static void C_ccall f_5388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5342)
static void C_fcall f_5342(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5364)
static void C_ccall f_5364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5372)
static void C_ccall f_5372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5319)
static void C_ccall f_5319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5281)
static void C_ccall f_5281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5284)
static void C_ccall f_5284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5287)
static void C_ccall f_5287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5304)
static void C_ccall f_5304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5294)
static void C_fcall f_5294(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4879)
static void C_ccall f_4879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5216)
static void C_ccall f_5216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5227)
static void C_ccall f_5227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5221)
static void C_ccall f_5221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5199)
static void C_ccall f_5199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4903)
static void C_ccall f_4903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5191)
static void C_ccall f_5191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5629)
static void C_fcall f_5629(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5116)
static void C_ccall f_5116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_5069)
static void C_ccall f_5069(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5056)
static void C_ccall f_5056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5056)
static void C_ccall f_5056r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4956)
static void C_ccall f_4956(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4932)
static void C_ccall f_4932(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4938)
static void C_ccall f_4938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4854)
static void C_ccall f_4854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4556)
static void C_ccall f_4556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4792)
static void C_ccall f_4792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4808)
static void C_fcall f_4808(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_ccall f_4752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4756)
static void C_ccall f_4756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4682)
static void C_ccall f_4682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4599)
static void C_ccall f_4599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4627)
static void C_ccall f_4627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4603)
static void C_ccall f_4603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4450)
static void C_ccall f_4450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4459)
static void C_ccall f_4459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4492)
static void C_ccall f_4492(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4465)
static void C_ccall f_4465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4484)
static void C_ccall f_4484(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4528)
static void C_ccall f_4528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4507)
static void C_ccall f_4507(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4386)
static void C_ccall f_4386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4390)
static void C_ccall f_4390(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4394)
static void C_ccall f_4394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4273)
static void C_ccall f_4273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4276)
static void C_ccall f_4276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4284)
static void C_ccall f_4284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4141)
static void C_ccall f_4141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_ccall f_4201(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4167)
static void C_ccall f_4167(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4081)
static void C_ccall f_4081(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_fcall f_3994(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3989)
static void C_fcall f_3989(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3966)
static void C_ccall f_3966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_ccall f_3970(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3926)
static void C_fcall f_3926(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3920)
static C_word C_fcall f_3920(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3914)
static C_word C_fcall f_3914(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3861)
static void C_fcall f_3861(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3880)
static void C_fcall f_3880(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3889)
static void C_fcall f_3889(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3749)
static void C_fcall f_3749(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3707)
static void C_fcall f_3707(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3713)
static void C_fcall f_3713(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3831)
static C_word C_fcall f_3831(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3698)
static void C_ccall f_3698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3663)
static void C_ccall f_3663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3597)
static void C_ccall f_3597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_fcall f_3609(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3551)
static void C_ccall f_3551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3557)
static void C_fcall f_3557(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3500)
static void C_ccall f_3500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_fcall f_3508(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static C_word C_fcall f_3464(C_word t0,C_word t1);
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_fcall f_3379(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3288)
static void C_fcall f_3288(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3240)
static void C_fcall f_3240(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_fcall f_3235(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2804)
static void C_fcall f_2804(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2987)
static void C_fcall f_2987(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2993)
static void C_fcall f_2993(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3192)
static void C_ccall f_3192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_fcall f_3044(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2807)
static void C_fcall f_2807(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2819)
static void C_fcall f_2819(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2838)
static void C_fcall f_2838(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2305)
static void C_fcall f_2305(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2745)
static void C_fcall f_2745(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_fcall f_2664(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2618)
static void C_fcall f_2618(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_fcall f_2621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2581)
static void C_fcall f_2581(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2549)
static void C_fcall f_2549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_fcall f_2491(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2323)
static void C_fcall f_2323(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2335)
static void C_fcall f_2335(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2326)
static void C_fcall f_2326(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_fcall f_2286(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2246)
static void C_fcall f_2246(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2265)
static void C_fcall f_2265(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2197)
static void C_fcall f_2197(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2115)
static void C_fcall f_2115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_fcall f_1954(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_fcall f_1982(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1808)
static void C_fcall f_1808(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_fcall f_1840(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1857)
static void C_fcall f_1857(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1876)
static void C_fcall f_1876(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_fcall f_1837(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1796)
static void C_ccall f_1796(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1736)
static void C_ccall f_1736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1695)
static void C_ccall f_1695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1699)
static void C_ccall f_1699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1702)
static void C_ccall f_1702(C_word c,C_word t0,C_word t1) C_noret;

/* from CHICKEN_get_error_message */
 void  CHICKEN_get_error_message(char *t0,int t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer_or_false(&a,(void*)t0);
C_save(x);
x=C_fix((C_word)t1);
C_save(x);C_callback_wrapper((void *)f_9603,2);}

/* from CHICKEN_load */
 int  CHICKEN_load(char * t0){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0))),*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9588,1));}

/* from CHICKEN_read */
 int  CHICKEN_read(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9566,2));}

/* from CHICKEN_apply_to_string */
 int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
x=C_fix((C_word)t3);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9540,4));}

/* from CHICKEN_apply */
 int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9524,3));}

/* from CHICKEN_eval_string_to_string */
 int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9487,3));}

/* from CHICKEN_eval_to_string */
 int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9461,3));}

/* from CHICKEN_eval_string */
 int  CHICKEN_eval_string(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9422,2));}

/* from CHICKEN_eval */
 int  CHICKEN_eval(C_word t0,C_word *t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9406,2));}

/* from CHICKEN_yield */
 int  CHICKEN_yield(){
C_word x,s=0,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
return C_truep(C_callback_wrapper((void *)f_9394,0));}

C_noret_decl(trf_11309)
static void C_fcall trf_11309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11309(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11309(t0,t1);}

C_noret_decl(trf_11277)
static void C_fcall trf_11277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11277(t0,t1);}

C_noret_decl(trf_6638)
static void C_fcall trf_6638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6638(t0,t1);}

C_noret_decl(trf_11197)
static void C_fcall trf_11197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11197(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11197(t0,t1,t2);}

C_noret_decl(trf_11099)
static void C_fcall trf_11099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11099(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11099(t0,t1);}

C_noret_decl(trf_11065)
static void C_fcall trf_11065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11065(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11065(t0,t1);}

C_noret_decl(trf_10965)
static void C_fcall trf_10965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10965(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10965(t0,t1,t2);}

C_noret_decl(trf_10697)
static void C_fcall trf_10697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10697(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10697(t0,t1,t2);}

C_noret_decl(trf_10789)
static void C_fcall trf_10789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10789(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10789(t0,t1);}

C_noret_decl(trf_10611)
static void C_fcall trf_10611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10611(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10611(t0,t1,t2);}

C_noret_decl(trf_10553)
static void C_fcall trf_10553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10553(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10553(t0,t1,t2);}

C_noret_decl(trf_10386)
static void C_fcall trf_10386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10386(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10386(t0,t1);}

C_noret_decl(trf_10264)
static void C_fcall trf_10264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10264(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10264(t0,t1,t2);}

C_noret_decl(trf_10067)
static void C_fcall trf_10067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10067(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10067(t0,t1,t2,t3);}

C_noret_decl(trf_10057)
static void C_fcall trf_10057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10057(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10057(t0,t1,t2,t3);}

C_noret_decl(trf_9953)
static void C_fcall trf_9953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9953(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9953(t0,t1,t2);}

C_noret_decl(trf_9811)
static void C_fcall trf_9811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9811(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9811(t0,t1,t2);}

C_noret_decl(trf_9801)
static void C_fcall trf_9801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9801(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9801(t0,t1,t2);}

C_noret_decl(trf_9656)
static void C_fcall trf_9656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9656(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9656(t0,t1,t2);}

C_noret_decl(trf_9660)
static void C_fcall trf_9660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9660(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9660(t0,t1);}

C_noret_decl(trf_9671)
static void C_fcall trf_9671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9671(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9671(t0,t1);}

C_noret_decl(trf_9385)
static void C_fcall trf_9385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9385(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9385(t0,t1,t2);}

C_noret_decl(trf_9326)
static void C_fcall trf_9326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9326(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9326(t0,t1);}

C_noret_decl(trf_9266)
static void C_fcall trf_9266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9266(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9266(t0,t1);}

C_noret_decl(trf_9253)
static void C_fcall trf_9253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9253(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9253(t0,t1);}

C_noret_decl(trf_9024)
static void C_fcall trf_9024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9024(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9024(t0,t1);}

C_noret_decl(trf_9082)
static void C_fcall trf_9082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9082(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9082(t0,t1,t2,t3);}

C_noret_decl(trf_8914)
static void C_fcall trf_8914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8914(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8914(t0,t1);}

C_noret_decl(trf_8988)
static void C_fcall trf_8988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8988(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8988(t0,t1);}

C_noret_decl(trf_8892)
static void C_fcall trf_8892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8892(t0,t1);}

C_noret_decl(trf_8557)
static void C_fcall trf_8557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8557(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8557(t0,t1);}

C_noret_decl(trf_8562)
static void C_fcall trf_8562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8562(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8562(t0,t1,t2,t3);}

C_noret_decl(trf_8578)
static void C_fcall trf_8578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8578(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8578(t0,t1);}

C_noret_decl(trf_8583)
static void C_fcall trf_8583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8583(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8583(t0,t1,t2,t3);}

C_noret_decl(trf_8478)
static void C_fcall trf_8478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8478(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8478(t0,t1,t2);}

C_noret_decl(trf_8423)
static void C_fcall trf_8423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8423(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8423(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8435)
static void C_fcall trf_8435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8435(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8435(t0,t1,t2);}

C_noret_decl(trf_8301)
static void C_fcall trf_8301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8301(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8301(t0,t1,t2,t3);}

C_noret_decl(trf_8277)
static void C_fcall trf_8277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8277(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8277(t0,t1,t2);}

C_noret_decl(trf_8283)
static void C_fcall trf_8283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8283(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8283(t0,t1,t2);}

C_noret_decl(trf_8224)
static void C_fcall trf_8224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8224(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8224(t0,t1,t2);}

C_noret_decl(trf_8195)
static void C_fcall trf_8195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8195(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8195(t0,t1,t2);}

C_noret_decl(trf_8160)
static void C_fcall trf_8160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8160(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8160(t0,t1,t2,t3);}

C_noret_decl(trf_8135)
static void C_fcall trf_8135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8135(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8135(t0,t1);}

C_noret_decl(trf_8102)
static void C_fcall trf_8102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8102(t0,t1);}

C_noret_decl(trf_7919)
static void C_fcall trf_7919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7919(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7919(t0,t1,t2,t3);}

C_noret_decl(trf_7943)
static void C_fcall trf_7943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7943(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7943(t0,t1,t2,t3);}

C_noret_decl(trf_7805)
static void C_fcall trf_7805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7805(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7805(t0,t1,t2);}

C_noret_decl(trf_7832)
static void C_fcall trf_7832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7832(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7832(t0,t1,t2);}

C_noret_decl(trf_7739)
static void C_fcall trf_7739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7739(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7739(t0,t1,t2);}

C_noret_decl(trf_7759)
static void C_fcall trf_7759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7759(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7759(t0,t1);}

C_noret_decl(trf_7559)
static void C_fcall trf_7559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7559(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7559(t0,t1);}

C_noret_decl(trf_7596)
static void C_fcall trf_7596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7596(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7596(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7308)
static void C_fcall trf_7308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7308(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7308(t0,t1,t2);}

C_noret_decl(trf_7479)
static void C_fcall trf_7479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7479(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7479(t0,t1);}

C_noret_decl(trf_7483)
static void C_fcall trf_7483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7483(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7483(t0,t1);}

C_noret_decl(trf_7412)
static void C_fcall trf_7412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7412(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7412(t0,t1);}

C_noret_decl(trf_7420)
static void C_fcall trf_7420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7420(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7420(t0,t1);}

C_noret_decl(trf_7367)
static void C_fcall trf_7367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7367(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7367(t0,t1);}

C_noret_decl(trf_7333)
static void C_fcall trf_7333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7333(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7333(t0,t1);}

C_noret_decl(trf_7287)
static void C_fcall trf_7287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7287(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7287(t0,t1,t2);}

C_noret_decl(trf_7241)
static void C_fcall trf_7241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7241(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7241(t0,t1,t2);}

C_noret_decl(trf_7258)
static void C_fcall trf_7258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7258(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7258(t0,t1);}

C_noret_decl(trf_7087)
static void C_fcall trf_7087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7087(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7087(t0,t1);}

C_noret_decl(trf_7042)
static void C_fcall trf_7042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7042(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7042(t0,t1,t2);}

C_noret_decl(trf_7009)
static void C_fcall trf_7009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7009(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7009(t0,t1,t2);}

C_noret_decl(trf_6948)
static void C_fcall trf_6948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6948(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6948(t0,t1,t2);}

C_noret_decl(trf_6870)
static void C_fcall trf_6870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6870(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6870(t0,t1,t2);}

C_noret_decl(trf_6846)
static void C_fcall trf_6846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6846(t0,t1);}

C_noret_decl(trf_6796)
static void C_fcall trf_6796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6796(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6796(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6665)
static void C_fcall trf_6665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6665(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6665(t0,t1);}

C_noret_decl(trf_6676)
static void C_fcall trf_6676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6676(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6676(t0,t1,t2);}

C_noret_decl(trf_6692)
static void C_fcall trf_6692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6692(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6692(t0,t1);}

C_noret_decl(trf_6509)
static void C_fcall trf_6509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6509(t0,t1);}

C_noret_decl(trf_6504)
static void C_fcall trf_6504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6504(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6504(t0,t1,t2);}

C_noret_decl(trf_6169)
static void C_fcall trf_6169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6169(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6169(t0,t1,t2,t3);}

C_noret_decl(trf_6173)
static void C_fcall trf_6173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6173(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6173(t0,t1);}

C_noret_decl(trf_6455)
static void C_fcall trf_6455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6455(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6455(t0,t1);}

C_noret_decl(trf_6248)
static void C_fcall trf_6248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6248(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6248(t0,t1,t2);}

C_noret_decl(trf_6121)
static void C_fcall trf_6121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6121(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6121(t0,t1);}

C_noret_decl(trf_6058)
static void C_fcall trf_6058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6058(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6058(t0,t1,t2);}

C_noret_decl(trf_5970)
static void C_fcall trf_5970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5970(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5970(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5960)
static void C_fcall trf_5960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5960(t0,t1);}

C_noret_decl(trf_5688)
static void C_fcall trf_5688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5688(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5688(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3932)
static void C_fcall trf_3932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3932(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3932(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4091)
static void C_fcall trf_4091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4091(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4091(t0,t1);}

C_noret_decl(trf_5495)
static void C_fcall trf_5495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5495(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5495(t0,t1);}

C_noret_decl(trf_5342)
static void C_fcall trf_5342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5342(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5342(t0,t1,t2);}

C_noret_decl(trf_5294)
static void C_fcall trf_5294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5294(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5294(t0,t1);}

C_noret_decl(trf_5629)
static void C_fcall trf_5629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5629(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5629(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4808)
static void C_fcall trf_4808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4808(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4808(t0,t1,t2,t3);}

C_noret_decl(trf_3994)
static void C_fcall trf_3994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3994(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3994(t0,t1);}

C_noret_decl(trf_3989)
static void C_fcall trf_3989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3989(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3989(t0,t1);}

C_noret_decl(trf_3926)
static void C_fcall trf_3926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3926(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3926(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3861)
static void C_fcall trf_3861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3861(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3861(t0,t1,t2,t3);}

C_noret_decl(trf_3880)
static void C_fcall trf_3880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3880(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3880(t0,t1);}

C_noret_decl(trf_3889)
static void C_fcall trf_3889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3889(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3889(t0,t1);}

C_noret_decl(trf_3749)
static void C_fcall trf_3749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3749(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3749(t0,t1,t2,t3);}

C_noret_decl(trf_3707)
static void C_fcall trf_3707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3707(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3707(t0,t1,t2);}

C_noret_decl(trf_3713)
static void C_fcall trf_3713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3713(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3713(t0,t1,t2,t3);}

C_noret_decl(trf_3609)
static void C_fcall trf_3609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3609(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3609(t0,t1,t2);}

C_noret_decl(trf_3557)
static void C_fcall trf_3557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3557(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3557(t0,t1,t2);}

C_noret_decl(trf_3508)
static void C_fcall trf_3508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3508(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3508(t0,t1,t2);}

C_noret_decl(trf_3379)
static void C_fcall trf_3379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3379(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3379(t0,t1,t2,t3);}

C_noret_decl(trf_3288)
static void C_fcall trf_3288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3288(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3288(t0,t1,t2,t3);}

C_noret_decl(trf_3240)
static void C_fcall trf_3240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3240(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3240(t0,t1);}

C_noret_decl(trf_3235)
static void C_fcall trf_3235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3235(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3235(t0,t1,t2);}

C_noret_decl(trf_2804)
static void C_fcall trf_2804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2804(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2804(t0,t1,t2);}

C_noret_decl(trf_2987)
static void C_fcall trf_2987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2987(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2987(t0,t1,t2);}

C_noret_decl(trf_2993)
static void C_fcall trf_2993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2993(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2993(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3044)
static void C_fcall trf_3044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3044(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3044(t0,t1,t2);}

C_noret_decl(trf_2807)
static void C_fcall trf_2807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2807(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2807(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2819)
static void C_fcall trf_2819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2819(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2819(t0,t1,t2,t3);}

C_noret_decl(trf_2838)
static void C_fcall trf_2838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2838(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2838(t0,t1);}

C_noret_decl(trf_2305)
static void C_fcall trf_2305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2305(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2305(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2745)
static void C_fcall trf_2745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2745(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2745(t0,t1);}

C_noret_decl(trf_2664)
static void C_fcall trf_2664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2664(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2664(t0,t1);}

C_noret_decl(trf_2618)
static void C_fcall trf_2618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2618(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2618(t0,t1);}

C_noret_decl(trf_2621)
static void C_fcall trf_2621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2621(t0,t1);}

C_noret_decl(trf_2581)
static void C_fcall trf_2581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2581(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2581(t0,t1);}

C_noret_decl(trf_2549)
static void C_fcall trf_2549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2549(t0,t1);}

C_noret_decl(trf_2491)
static void C_fcall trf_2491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2491(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2491(t0,t1);}

C_noret_decl(trf_2323)
static void C_fcall trf_2323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2323(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2323(t0,t1);}

C_noret_decl(trf_2335)
static void C_fcall trf_2335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2335(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2335(t0,t1);}

C_noret_decl(trf_2326)
static void C_fcall trf_2326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2326(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2326(t0,t1);}

C_noret_decl(trf_2286)
static void C_fcall trf_2286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2286(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2286(t0,t1,t2);}

C_noret_decl(trf_2246)
static void C_fcall trf_2246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2246(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2246(t0,t1,t2);}

C_noret_decl(trf_2265)
static void C_fcall trf_2265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2265(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2265(t0,t1);}

C_noret_decl(trf_2197)
static void C_fcall trf_2197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2197(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2197(t0,t1,t2);}

C_noret_decl(trf_2115)
static void C_fcall trf_2115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2115(t0,t1);}

C_noret_decl(trf_1954)
static void C_fcall trf_1954(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1954(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1954(t0,t1,t2,t3);}

C_noret_decl(trf_1982)
static void C_fcall trf_1982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1982(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1982(t0,t1,t2);}

C_noret_decl(trf_1808)
static void C_fcall trf_1808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1808(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1808(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1840)
static void C_fcall trf_1840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1840(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1840(t0,t1);}

C_noret_decl(trf_1857)
static void C_fcall trf_1857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1857(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1857(t0,t1,t2);}

C_noret_decl(trf_1876)
static void C_fcall trf_1876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1876(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1876(t0,t1);}

C_noret_decl(trf_1837)
static void C_fcall trf_1837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1837(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1837(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_eval_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("eval_toplevel"));
C_check_nursery_minimum(6);
if(!C_demand(6)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(7626)){
C_save(t1);
C_rereclaim2(7626*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(6);
C_initialize_lf(lf,517);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],24,"\003syscore-library-modules");
lf[3]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006extras\376\003\000\000\002\376\001\000\000\007lolevel\376\003\000\000\002\376\001\000\000\005utils\376\003\000\000\002\376\001\000\000\003tcp\376\003\000\000\002\376\001\000\000\005regex\376\003\000\000"
"\002\376\001\000\000\014regex-extras\376\003\000\000\002\376\001\000\000\005posix\376\003\000\000\002\376\001\000\000\005match\376\003\000\000\002\376\001\000\000\006srfi-1\376\003\000\000\002\376\001\000\000\006srfi-4"
"\376\003\000\000\002\376\001\000\000\007srfi-13\376\003\000\000\002\376\001\000\000\007srfi-14\376\003\000\000\002\376\001\000\000\007srfi-18\376\377\016");
lf[4]=C_h_intern(&lf[4],28,"\003sysexplicit-library-modules");
lf[6]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012libchicken\376\377\016");
lf[8]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014cygchicken-0\376\377\016");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\006.dylib");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\004.dll");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\003.sl");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\003.so");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\022CHICKEN_REPOSITORY");
lf[24]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022chicken-ffi-macros\376\003\000\000\002\376\001\000\000\023chicken-more-macros\376\377\016");
lf[26]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007chicken\376\003\000\000\002\376\001\000\000\006srfi-2\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\007srfi-10\376\003\000\000\002\376\001\000\000\007srfi"
"-12\376\003\000\000\002\376\001\000\000\007srfi-23\376\003\000\000\002\376\001\000\000\007srfi-28\376\003\000\000\002\376\001\000\000\007srfi-30\376\003\000\000\002\376\001\000\000\007srfi-31\376\003\000\000\002\376\001\000\000"
"\007srfi-39\376\003\000\000\002\376\001\000\000\007srfi-69\376\377\016");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\006srfi-8\376\003\000\000\002\376\001\000\000\006srfi-9\376\003\000\000\002\376\001\000\000\007srfi-11\376\003\000\000\002\376\001\000\000\007srfi-"
"15\376\003\000\000\002\376\001\000\000\007srfi-16\376\003\000\000\002\376\001\000\000\007srfi-17\376\003\000\000\002\376\001\000\000\007srfi-26\376\003\000\000\002\376\001\000\000\007srfi-55\376\377\016");
lf[29]=C_h_intern(&lf[29],6,"getenv");
lf[30]=C_h_intern(&lf[30],12,"chicken-home");
lf[31]=C_h_intern(&lf[31],17,"\003syspeek-c-string");
lf[32]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\005share");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\006/share");
lf[35]=C_h_intern(&lf[35],17,"\003sysstring-append");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[37]=C_h_intern(&lf[37],21,"\003sysmacro-environment");
lf[38]=C_h_intern(&lf[38],20,"\003sysregister-macro-2");
lf[39]=C_h_intern(&lf[39],19,"\003syshash-table-set!");
lf[40]=C_h_intern(&lf[40],18,"\003sysregister-macro");
lf[41]=C_h_intern(&lf[41],14,"\003syscopy-macro");
lf[42]=C_h_intern(&lf[42],18,"\003syshash-table-ref");
lf[43]=C_h_intern(&lf[43],6,"macro\077");
lf[44]=C_h_intern(&lf[44],15,"undefine-macro!");
lf[45]=C_h_intern(&lf[45],13,"string-append");
lf[46]=C_h_intern(&lf[46],17,"\003sysmacroexpand-0");
lf[47]=C_h_intern(&lf[47],9,"\003sysabort");
lf[48]=C_h_intern(&lf[48],9,"condition");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\025during expansion of (");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\010 ...) - ");
lf[52]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003exn\376\001\000\000\007message");
lf[53]=C_h_intern(&lf[53],3,"exn");
lf[54]=C_h_intern(&lf[54],22,"with-exception-handler");
lf[55]=C_h_intern(&lf[55],30,"call-with-current-continuation");
lf[56]=C_h_intern(&lf[56],21,"\003syssyntax-error-hook");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid syntax in macro form");
lf[58]=C_h_intern(&lf[58],3,"let");
lf[59]=C_h_intern(&lf[59],16,"\004coreloop-lambda");
lf[60]=C_h_intern(&lf[60],6,"letrec");
lf[61]=C_h_intern(&lf[61],8,"\004coreapp");
lf[62]=C_h_intern(&lf[62],7,"\003sysmap");
lf[63]=C_h_intern(&lf[63],4,"cadr");
lf[64]=C_h_intern(&lf[64],16,"\003syscheck-syntax");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[66]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[67]=C_h_intern(&lf[67],10,"\003syssetter");
lf[68]=C_h_intern(&lf[68],6,"append");
lf[69]=C_h_intern(&lf[69],4,"set!");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[71]=C_h_intern(&lf[71],9,"\004coreset!");
lf[72]=C_h_intern(&lf[72],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[73]=C_h_intern(&lf[73],41,"\003sysinterpreter-toplevel-macroexpand-hook");
lf[74]=C_h_intern(&lf[74],23,"\003sysmacroexpand-1-local");
lf[75]=C_h_intern(&lf[75],25,"\003sysenable-runtime-macros");
lf[76]=C_h_intern(&lf[76],11,"macroexpand");
lf[77]=C_h_intern(&lf[77],13,"macroexpand-1");
lf[78]=C_h_intern(&lf[78],25,"\003sysextended-lambda-list\077");
lf[79]=C_h_intern(&lf[79],6,"#!rest");
lf[80]=C_h_intern(&lf[80],10,"#!optional");
lf[81]=C_h_intern(&lf[81],5,"#!key");
lf[82]=C_h_intern(&lf[82],7,"reverse");
lf[83]=C_h_intern(&lf[83],6,"gensym");
lf[84]=C_h_intern(&lf[84],31,"\003sysexpand-extended-lambda-list");
lf[85]=C_h_intern(&lf[85],9,":optional");
lf[86]=C_h_intern(&lf[86],13,"let-optionals");
lf[87]=C_h_intern(&lf[87],14,"let-optionals*");
lf[88]=C_h_intern(&lf[88],10,"\003sysappend");
lf[89]=C_h_intern(&lf[89],4,"let*");
lf[90]=C_h_intern(&lf[90],5,"quote");
lf[91]=C_h_intern(&lf[91],15,"\003sysget-keyword");
lf[92]=C_h_intern(&lf[92],6,"lambda");
lf[93]=C_h_intern(&lf[93],15,"string->keyword");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000+rest argument list specified more than once");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000-`#!optional\047 argument marker in wrong context");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000#invalid syntax of `#!rest\047 argument");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000)`#!rest\047 argument marker in wrong context");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000(`#!key\047 argument marker in wrong context");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000 invalid required argument syntax");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\0000invalid lambda list syntax after `#!rest\047 marker");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid lambda list syntax");
lf[104]=C_h_intern(&lf[104],3,"map");
lf[105]=C_h_intern(&lf[105],21,"\003syscanonicalize-body");
lf[106]=C_h_intern(&lf[106],5,"begin");
lf[107]=C_h_intern(&lf[107],6,"define");
lf[108]=C_h_intern(&lf[108],13,"define-values");
lf[109]=C_h_intern(&lf[109],20,"\003syscall-with-values");
lf[110]=C_h_intern(&lf[110],14,"\004coreundefined");
lf[111]=C_h_intern(&lf[111],25,"\003sysexpand-curried-define");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[113]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006define\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015define-values\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[119]=C_h_intern(&lf[119],20,"\003sysmatch-expression");
lf[120]=C_h_intern(&lf[120],15,"\003syshash-symbol");
lf[121]=C_h_intern(&lf[121],23,"\003syshash-table-for-each");
lf[122]=C_h_intern(&lf[122],12,"\003sysfor-each");
lf[123]=C_h_intern(&lf[123],28,"\003sysarbitrary-unbound-symbol");
lf[124]=C_h_intern(&lf[124],23,"\003syshash-table-location");
lf[125]=C_h_intern(&lf[125],20,"\003syseval-environment");
lf[126]=C_h_intern(&lf[126],26,"\003sysenvironment-is-mutable");
lf[127]=C_h_intern(&lf[127],18,"\003syseval-decorator");
lf[128]=C_h_intern(&lf[128],20,"\003sysmake-lambda-info");
lf[129]=C_h_intern(&lf[129],17,"get-output-string");
lf[130]=C_h_intern(&lf[130],5,"write");
lf[131]=C_h_intern(&lf[131],18,"open-output-string");
lf[132]=C_h_intern(&lf[132],19,"\003sysdecorate-lambda");
lf[133]=C_h_intern(&lf[133],19,"\003sysunbound-in-eval");
lf[134]=C_h_intern(&lf[134],20,"\003syseval-debug-level");
lf[135]=C_h_intern(&lf[135],21,"\003sysalias-global-hook");
lf[136]=C_h_intern(&lf[136],6,"cadadr");
lf[137]=C_h_intern(&lf[137],20,"with-input-from-file");
lf[138]=C_h_intern(&lf[138],7,"display");
lf[139]=C_h_intern(&lf[139],22,"\003syscompile-to-closure");
lf[140]=C_h_intern(&lf[140],18,"\003syscurrent-thread");
lf[141]=C_h_intern(&lf[141],9,"\003syserror");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\020unbound variable");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000!reference to undefined identifier");
lf[144]=C_h_intern(&lf[144],32,"\003syssymbol-has-toplevel-binding\077");
lf[145]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[146]=C_h_intern(&lf[146],15,"\004coreglobal-ref");
lf[147]=C_h_intern(&lf[147],10,"\004corecheck");
lf[148]=C_h_intern(&lf[148],14,"\004coreimmutable");
lf[149]=C_h_intern(&lf[149],2,"if");
lf[150]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[151]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[152]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000 assignment to immutable variable");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\042assignment of undefined identifier");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[157]=C_h_intern(&lf[157],15,"\003sysmake-vector");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003let\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001"
);
lf[159]=C_h_intern(&lf[159],1,"\077");
lf[160]=C_h_intern(&lf[160],10,"\003sysvector");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[162]=C_h_intern(&lf[162],25,"\003sysdecompose-lambda-list");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[164]=C_h_intern(&lf[164],17,"\004corenamed-lambda");
lf[165]=C_h_intern(&lf[165],23,"\004corerequire-for-syntax");
lf[166]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[167]=C_h_intern(&lf[167],11,"\003sysrequire");
lf[168]=C_h_intern(&lf[168],31,"\003syslookup-runtime-requirements");
lf[169]=C_h_intern(&lf[169],22,"\004corerequire-extension");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[171]=C_h_intern(&lf[171],22,"\003sysdo-the-right-thing");
lf[172]=C_h_intern(&lf[172],24,"\004coreelaborationtimeonly");
lf[173]=C_h_intern(&lf[173],23,"\004coreelaborationtimetoo");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[175]=C_h_intern(&lf[175],19,"\004corecompiletimetoo");
lf[176]=C_h_intern(&lf[176],20,"\004corecompiletimeonly");
lf[177]=C_h_intern(&lf[177],13,"\004corecallunit");
lf[178]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[179]=C_h_intern(&lf[179],12,"\004coredeclare");
lf[180]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[181]=C_h_intern(&lf[181],10,"\000compiling");
lf[182]=C_h_intern(&lf[182],12,"\003sysfeatures");
lf[183]=C_h_intern(&lf[183],28,"\010compilerprocess-declaration");
lf[184]=C_h_intern(&lf[184],8,"\003syswarn");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000,declarations are ignored in interpreted code");
lf[186]=C_h_intern(&lf[186],18,"\004coredefine-inline");
lf[187]=C_h_intern(&lf[187],20,"\004coredefine-constant");
lf[188]=C_h_intern(&lf[188],14,"\004coreprimitive");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000&can not evaluate compiler-special-form");
lf[190]=C_h_intern(&lf[190],8,"location");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000&can not evaluate compiler-special-form");
lf[192]=C_h_intern(&lf[192],11,"\004coreinline");
lf[193]=C_h_intern(&lf[193],20,"\004coreinline_allocate");
lf[194]=C_h_intern(&lf[194],19,"\004coreforeign-lambda");
lf[195]=C_h_intern(&lf[195],28,"\004coredefine-foreign-variable");
lf[196]=C_h_intern(&lf[196],29,"\004coredefine-external-variable");
lf[197]=C_h_intern(&lf[197],17,"\004corelet-location");
lf[198]=C_h_intern(&lf[198],22,"\004coreforeign-primitive");
lf[199]=C_h_intern(&lf[199],20,"\004coreforeign-lambda*");
lf[200]=C_h_intern(&lf[200],24,"\004coredefine-foreign-type");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal non-atomic object");
lf[202]=C_h_intern(&lf[202],11,"\003sysnumber\077");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[204]=C_h_intern(&lf[204],16,"\003syseval-handler");
lf[205]=C_h_intern(&lf[205],12,"eval-handler");
lf[206]=C_h_intern(&lf[206],4,"eval");
lf[207]=C_h_intern(&lf[207],24,"\003syssyntax-error-culprit");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\032illegal lambda-list syntax");
lf[209]=C_h_intern(&lf[209],12,"load-verbose");
lf[210]=C_h_intern(&lf[210],14,"\003sysabort-load");
lf[211]=C_h_intern(&lf[211],27,"\003syscurrent-source-filename");
lf[212]=C_h_intern(&lf[212],21,"\003syscurrent-load-path");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[214]=C_h_intern(&lf[214],22,"set-dynamic-load-mode!");
lf[215]=C_h_intern(&lf[215],21,"\003sysset-dlopen-flags!");
lf[216]=C_h_intern(&lf[216],6,"global");
lf[217]=C_h_intern(&lf[217],5,"local");
lf[218]=C_h_intern(&lf[218],4,"lazy");
lf[219]=C_h_intern(&lf[219],3,"now");
lf[220]=C_h_intern(&lf[220],15,"\003syssignal-hook");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid dynamic-load mode");
lf[222]=C_h_intern(&lf[222],4,"read");
lf[223]=C_h_intern(&lf[223],7,"newline");
lf[224]=C_h_intern(&lf[224],15,"open-input-file");
lf[225]=C_h_intern(&lf[225],16,"close-input-port");
lf[226]=C_h_intern(&lf[226],8,"\003sysload");
lf[227]=C_h_intern(&lf[227],31,"\003sysread-error-with-line-number");
lf[228]=C_h_intern(&lf[228],19,"\003sysundefined-value");
lf[229]=C_h_intern(&lf[229],17,"\003sysdisplay-times");
lf[230]=C_h_intern(&lf[230],14,"\003sysstop-timer");
lf[231]=C_h_intern(&lf[231],15,"\003sysstart-timer");
lf[232]=C_h_intern(&lf[232],4,"load");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\036unable to load compiled module");
lf[234]=C_h_intern(&lf[234],9,"peek-char");
lf[235]=C_h_intern(&lf[235],16,"\003sysdynamic-wind");
lf[236]=C_h_intern(&lf[236],13,"\003syssubstring");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[238]=C_h_intern(&lf[238],9,"\003sysdload");
lf[239]=C_h_intern(&lf[239],17,"\003sysmake-c-string");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[241]=C_h_intern(&lf[241],11,"\000file-error");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\021can not open file");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\012; loading ");
lf[245]=C_h_intern(&lf[245],13,"\003sysfile-info");
lf[246]=C_h_intern(&lf[246],26,"\003sysload-dynamic-extension");
lf[247]=C_h_intern(&lf[247],11,"\000type-error");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a port or string");
lf[249]=C_h_intern(&lf[249],5,"port\077");
lf[250]=C_h_intern(&lf[250],20,"\003sysexpand-home-path");
lf[251]=C_h_intern(&lf[251],13,"load-relative");
lf[252]=C_h_intern(&lf[252],12,"load-noisily");
lf[253]=C_h_intern(&lf[253],8,"\000printer");
lf[254]=C_h_intern(&lf[254],5,"\000time");
lf[255]=C_h_intern(&lf[255],10,"\000evaluator");
lf[256]=C_h_intern(&lf[256],26,"\003sysload-library-extension");
lf[257]=C_h_intern(&lf[257],6,"cygwin");
lf[258]=C_h_intern(&lf[258],34,"\003sysdefault-dynamic-load-libraries");
lf[259]=C_h_intern(&lf[259],22,"dynamic-load-libraries");
lf[260]=C_h_intern(&lf[260],16,"\003sysload-library");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\022; loading library ");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[265]=C_h_intern(&lf[265],24,"\003sysstring->c-identifier");
lf[266]=C_h_intern(&lf[266],16,"\003sys->feature-id");
lf[267]=C_h_intern(&lf[267],12,"load-library");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\026unable to load library");
lf[270]=C_h_intern(&lf[270],31,"\003syscanonicalize-extension-path");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid extension path");
lf[272]=C_h_intern(&lf[272],18,"\003syssymbol->string");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[276]=C_h_intern(&lf[276],19,"\003sysrepository-path");
lf[277]=C_h_intern(&lf[277],15,"repository-path");
lf[278]=C_h_intern(&lf[278],12,"file-exists\077");
lf[279]=C_h_intern(&lf[279],18,"\003sysfind-extension");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[281]=C_h_intern(&lf[281],21,"\003sysinclude-pathnames");
lf[282]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001.\376\377\016");
lf[283]=C_h_intern(&lf[283],21,"\003sysloaded-extensions");
lf[284]=C_h_intern(&lf[284],14,"string->symbol");
lf[285]=C_h_intern(&lf[285],18,"\003sysload-extension");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\026can not load extension");
lf[287]=C_h_intern(&lf[287],11,"\003sysprovide");
lf[288]=C_h_intern(&lf[288],7,"provide");
lf[289]=C_h_intern(&lf[289],13,"\003sysprovided\077");
lf[290]=C_h_intern(&lf[290],9,"provided\077");
lf[291]=C_h_intern(&lf[291],7,"require");
lf[292]=C_h_intern(&lf[292],25,"\003sysextension-information");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[295]=C_h_intern(&lf[295],21,"extension-information");
lf[296]=C_h_intern(&lf[296],18,"require-at-runtime");
lf[297]=C_h_intern(&lf[297],12,"vector->list");
lf[298]=C_h_intern(&lf[298],11,"lset-adjoin");
lf[299]=C_h_intern(&lf[299],3,"eq\077");
lf[300]=C_h_intern(&lf[300],18,"hash-table-update!");
lf[301]=C_h_intern(&lf[301],26,"\010compilerfile-requirements");
lf[302]=C_h_intern(&lf[302],19,"syntax-requirements");
lf[303]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[304]=C_h_intern(&lf[304],18,"chicken-ffi-macros");
lf[305]=C_h_intern(&lf[305],19,"chicken-more-macros");
lf[306]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[307]=C_h_intern(&lf[307],28,"\003sysresolve-include-filename");
lf[308]=C_h_intern(&lf[308],4,"uses");
lf[309]=C_h_intern(&lf[309],6,"syntax");
lf[310]=C_h_intern(&lf[310],17,"require-extension");
lf[311]=C_h_intern(&lf[311],12,"\003sysfeature\077");
lf[312]=C_h_intern(&lf[312],24,"\003sysextension-specifiers");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\035undefined extension specifier");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid extension specifier");
lf[315]=C_h_intern(&lf[315],24,"set-extension-specifier!");
lf[316]=C_h_intern(&lf[316],11,"string-copy");
lf[319]=C_h_intern(&lf[319],11,"environment");
lf[321]=C_h_intern(&lf[321],18,"\003syscopy-env-table");
lf[322]=C_h_intern(&lf[322],23,"\003sysenvironment-symbols");
lf[323]=C_h_intern(&lf[323],18,"\003syswalk-namespace");
lf[324]=C_h_intern(&lf[324],23,"interaction-environment");
lf[325]=C_h_intern(&lf[325],25,"scheme-report-environment");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[327]=C_h_intern(&lf[327],11,"make-vector");
lf[328]=C_h_intern(&lf[328],16,"null-environment");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\013 major GCs\012");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\013 minor GCs\012");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\013 mutations\012");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\027 seconds in (major) GC\012");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\021 seconds elapsed\012");
lf[337]=C_h_intern(&lf[337],24,"\003sysline-number-database");
lf[338]=C_h_intern(&lf[338],13,"\000syntax-error");
lf[339]=C_h_intern(&lf[339],12,"syntax-error");
lf[340]=C_h_intern(&lf[340],15,"get-line-number");
lf[341]=C_h_intern(&lf[341],8,"keyword\077");
lf[342]=C_h_intern(&lf[342],14,"symbol->string");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\012) in line ");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\024not enough arguments");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\022too many arguments");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\021not a proper list");
lf[351]=C_h_intern(&lf[351],1,"_");
lf[352]=C_h_intern(&lf[352],4,"pair");
lf[353]=C_h_intern(&lf[353],5,"pair\077");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\015pair expected");
lf[355]=C_h_intern(&lf[355],8,"variable");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\023identifier expected");
lf[357]=C_h_intern(&lf[357],6,"symbol");
lf[358]=C_h_intern(&lf[358],7,"symbol\077");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\017symbol expected");
lf[360]=C_h_intern(&lf[360],4,"list");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\024proper list expected");
lf[362]=C_h_intern(&lf[362],6,"number");
lf[363]=C_h_intern(&lf[363],7,"number\077");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\017number expected");
lf[365]=C_h_intern(&lf[365],6,"string");
lf[366]=C_h_intern(&lf[366],7,"string\077");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\017string expected");
lf[368]=C_h_intern(&lf[368],11,"lambda-list");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\024lambda-list expected");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\017incomplete form");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\021unexpected object");
lf[373]=C_h_intern(&lf[373],18,"\003sysrepl-eval-hook");
lf[374]=C_h_intern(&lf[374],27,"\003sysrepl-print-length-limit");
lf[375]=C_h_intern(&lf[375],18,"\003sysrepl-read-hook");
lf[376]=C_h_intern(&lf[376],19,"\003sysrepl-print-hook");
lf[377]=C_h_intern(&lf[377],16,"\003syswrite-char-0");
lf[378]=C_h_intern(&lf[378],9,"\003sysprint");
lf[379]=C_h_intern(&lf[379],27,"\003syswith-print-length-limit");
lf[380]=C_h_intern(&lf[380],11,"repl-prompt");
lf[381]=C_h_intern(&lf[381],20,"\003sysread-prompt-hook");
lf[382]=C_h_intern(&lf[382],16,"\003sysflush-output");
lf[383]=C_h_intern(&lf[383],19,"\003sysstandard-output");
lf[384]=C_h_intern(&lf[384],22,"\003sysclear-trace-buffer");
lf[385]=C_h_intern(&lf[385],16,"print-call-chain");
lf[386]=C_h_intern(&lf[386],12,"flush-output");
lf[387]=C_h_intern(&lf[387],5,"reset");
lf[388]=C_h_intern(&lf[388],4,"repl");
lf[389]=C_h_intern(&lf[389],18,"\003sysstandard-error");
lf[390]=C_h_intern(&lf[390],18,"\003sysstandard-input");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\005Error");
lf[394]=C_h_intern(&lf[394],17,"\003syserror-handler");
lf[395]=C_h_intern(&lf[395],20,"\003syswarnings-enabled");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\005 (in ");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000FWarning: the following toplevel variables are referenced but unbound:\012");
lf[399]=C_h_intern(&lf[399],15,"\003sysread-char-0");
lf[400]=C_h_intern(&lf[400],15,"\003syspeek-char-0");
lf[401]=C_h_intern(&lf[401],21,"\003sysenable-qualifiers");
lf[402]=C_h_intern(&lf[402],17,"\003sysreset-handler");
lf[403]=C_h_intern(&lf[403],28,"\003syssharp-comma-reader-ctors");
lf[404]=C_h_intern(&lf[404],18,"define-reader-ctor");
lf[405]=C_h_intern(&lf[405],18,"\003sysuser-read-hook");
lf[406]=C_h_intern(&lf[406],9,"read-char");
lf[407]=C_h_intern(&lf[407],14,"\003sysread-error");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000!invalid sharp-comma external form");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000!undefined sharp-comma constructor");
lf[412]=C_h_intern(&lf[412],19,"print-error-message");
lf[414]=C_h_intern(&lf[414],6,"\003sysgc");
lf[416]=C_h_intern(&lf[416],13,"thread-yield!");
lf[419]=C_h_intern(&lf[419],17,"open-input-string");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000(Error: not enough room for result string");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\010No error");
lf[430]=C_h_intern(&lf[430],15,"\003sysmake-string");
lf[431]=C_h_intern(&lf[431],6,"module");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\031modules are not supported");
lf[433]=C_h_intern(&lf[433],13,"define-syntax");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\042highlevel macros are not supported");
lf[435]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[436]=C_h_intern(&lf[436],12,"define-macro");
lf[437]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[438]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[439]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\004#;> ");
lf[441]=C_h_intern(&lf[441],14,"make-parameter");
lf[442]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007\000srfi-8\376\003\000\000\002\376\001\000\000\007\000srfi-6\376\003\000\000\002\376\001\000\000\007\000srfi-2\376\003\000\000\002\376\001\000\000\007\000srfi-0\376\003\000\000\002\376\001\000\000\010\000s"
"rfi-10\376\003\000\000\002\376\001\000\000\007\000srfi-9\376\003\000\000\002\376\001\000\000\010\000srfi-55\376\003\000\000\002\376\001\000\000\010\000srfi-61\376\377\016");
lf[443]=C_h_intern(&lf[443],11,"cond-expand");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\042syntax error in `cond-expand\047 form");
lf[445]=C_h_intern(&lf[445],3,"and");
lf[446]=C_h_intern(&lf[446],2,"or");
lf[447]=C_h_intern(&lf[447],3,"not");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000(no matching clause in `cond-expand\047 form");
lf[449]=C_h_intern(&lf[449],4,"else");
lf[450]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[451]=C_h_intern(&lf[451],16,"\003sysmake-promise");
lf[452]=C_h_intern(&lf[452],5,"delay");
lf[453]=C_h_intern(&lf[453],16,"\003syslist->vector");
lf[454]=C_h_intern(&lf[454],7,"unquote");
lf[455]=C_h_intern(&lf[455],8,"\003syslist");
lf[456]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\007unquote\376\377\016");
lf[457]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\007unquote\376\377\016");
lf[458]=C_h_intern(&lf[458],10,"quasiquote");
lf[459]=C_h_intern(&lf[459],8,"\003syscons");
lf[460]=C_h_intern(&lf[460],16,"unquote-splicing");
lf[461]=C_h_intern(&lf[461],1,"a");
lf[462]=C_h_intern(&lf[462],1,"b");
lf[463]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[464]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[465]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010\003syslist\376\001\000\000\001b\376\377\016");
lf[466]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\001\000\000\001b\376\377\016");
lf[467]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\001a\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[468]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001a\376\377\016");
lf[469]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[470]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\002do");
lf[472]=C_h_intern(&lf[472],2,"do");
lf[473]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[474]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[475]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[476]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[477]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[478]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[479]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[480]=C_h_intern(&lf[480],4,"eqv\077");
lf[481]=C_h_intern(&lf[481],4,"case");
lf[482]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[483]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[484]=C_h_intern(&lf[484],2,"=>");
lf[485]=C_h_intern(&lf[485],9,"\003sysapply");
lf[486]=C_h_intern(&lf[486],4,"cond");
lf[487]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[488]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[489]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[490]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\013lambda-list");
lf[491]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[492]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\013lambda-list");
lf[493]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[494]=C_decode_literal(C_heaptop,"\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[495]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\014dynamic-wind\376\003\000\000\002\376\001\000\000\006values\376\003\000\000\002\376\001\000\000\020call-with-values\376\003\000\000\002\376\001\000\000\004eval\376\003"
"\000\000\002\376\001\000\000\031scheme-report-environment\376\003\000\000\002\376\001\000\000\020null-environment\376\003\000\000\002\376\001\000\000\027interaction"
"-environment\376\377\016");
lf[496]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003not\376\003\000\000\002\376\001\000\000\010boolean\077\376\003\000\000\002\376\001\000\000\003eq\077\376\003\000\000\002\376\001\000\000\004eqv\077\376\003\000\000\002\376\001\000\000\006equal\077\376\003\000\000\002\376"
"\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\004cons\376\003\000\000\002\376\001\000\000\003car\376\003\000\000\002\376\001\000\000\003cdr\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\004cadr\376\003\000"
"\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\004cddr\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\005caadr\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\005"
"caddr\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\005cddar\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376\001\000\000\006caaaa"
"r\376\003\000\000\002\376\001\000\000\006caaadr\376\003\000\000\002\376\001\000\000\006caadar\376\003\000\000\002\376\001\000\000\006caaddr\376\003\000\000\002\376\001\000\000\006cadaar\376\003\000\000\002\376\001\000\000\006cadad"
"r\376\003\000\000\002\376\001\000\000\006cadddr\376\003\000\000\002\376\001\000\000\006cdaaar\376\003\000\000\002\376\001\000\000\006cdaadr\376\003\000\000\002\376\001\000\000\006cdadar\376\003\000\000\002\376\001\000\000\006cdadd"
"r\376\003\000\000\002\376\001\000\000\006cddaar\376\003\000\000\002\376\001\000\000\006cddadr\376\003\000\000\002\376\001\000\000\006cdddar\376\003\000\000\002\376\001\000\000\006cddddr\376\003\000\000\002\376\001\000\000\010set-c"
"ar!\376\003\000\000\002\376\001\000\000\010set-cdr!\376\003\000\000\002\376\001\000\000\005null\077\376\003\000\000\002\376\001\000\000\005list\077\376\003\000\000\002\376\001\000\000\004list\376\003\000\000\002\376\001\000\000\006lengt"
"h\376\003\000\000\002\376\001\000\000\011list-tail\376\003\000\000\002\376\001\000\000\010list-ref\376\003\000\000\002\376\001\000\000\006append\376\003\000\000\002\376\001\000\000\007reverse\376\003\000\000\002\376\001\000\000"
"\004memq\376\003\000\000\002\376\001\000\000\004memv\376\003\000\000\002\376\001\000\000\006member\376\003\000\000\002\376\001\000\000\004assq\376\003\000\000\002\376\001\000\000\004assv\376\003\000\000\002\376\001\000\000\005assoc\376\003"
"\000\000\002\376\001\000\000\007symbol\077\376\003\000\000\002\376\001\000\000\016symbol->string\376\003\000\000\002\376\001\000\000\016string->symbol\376\003\000\000\002\376\001\000\000\007number\077"
"\376\003\000\000\002\376\001\000\000\010integer\077\376\003\000\000\002\376\001\000\000\006exact\077\376\003\000\000\002\376\001\000\000\005real\077\376\003\000\000\002\376\001\000\000\010complex\077\376\003\000\000\002\376\001\000\000\010ine"
"xact\077\376\003\000\000\002\376\001\000\000\011rational\077\376\003\000\000\002\376\001\000\000\005zero\077\376\003\000\000\002\376\001\000\000\004odd\077\376\003\000\000\002\376\001\000\000\005even\077\376\003\000\000\002\376\001\000\000\011po"
"sitive\077\376\003\000\000\002\376\001\000\000\011negative\077\376\003\000\000\002\376\001\000\000\003max\376\003\000\000\002\376\001\000\000\003min\376\003\000\000\002\376\001\000\000\001+\376\003\000\000\002\376\001\000\000\001-\376\003\000\000\002\376"
"\001\000\000\001*\376\003\000\000\002\376\001\000\000\001/\376\003\000\000\002\376\001\000\000\001=\376\003\000\000\002\376\001\000\000\001>\376\003\000\000\002\376\001\000\000\001<\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\002<=\376\003\000\000\002\376\001"
"\000\000\010quotient\376\003\000\000\002\376\001\000\000\011remainder\376\003\000\000\002\376\001\000\000\006modulo\376\003\000\000\002\376\001\000\000\003gcd\376\003\000\000\002\376\001\000\000\003lcm\376\003\000\000\002\376\001\000"
"\000\003abs\376\003\000\000\002\376\001\000\000\005floor\376\003\000\000\002\376\001\000\000\007ceiling\376\003\000\000\002\376\001\000\000\010truncate\376\003\000\000\002\376\001\000\000\005round\376\003\000\000\002\376\001\000\000\016"
"exact->inexact\376\003\000\000\002\376\001\000\000\016inexact->exact\376\003\000\000\002\376\001\000\000\003exp\376\003\000\000\002\376\001\000\000\003log\376\003\000\000\002\376\001\000\000\004expt\376\003"
"\000\000\002\376\001\000\000\004sqrt\376\003\000\000\002\376\001\000\000\003sin\376\003\000\000\002\376\001\000\000\003cos\376\003\000\000\002\376\001\000\000\003tan\376\003\000\000\002\376\001\000\000\004asin\376\003\000\000\002\376\001\000\000\004acos\376"
"\003\000\000\002\376\001\000\000\004atan\376\003\000\000\002\376\001\000\000\016number->string\376\003\000\000\002\376\001\000\000\016string->number\376\003\000\000\002\376\001\000\000\005char\077\376\003\000\000"
"\002\376\001\000\000\006char=\077\376\003\000\000\002\376\001\000\000\006char>\077\376\003\000\000\002\376\001\000\000\006char<\077\376\003\000\000\002\376\001\000\000\007char>=\077\376\003\000\000\002\376\001\000\000\007char<=\077\376\003"
"\000\000\002\376\001\000\000\011char-ci=\077\376\003\000\000\002\376\001\000\000\011char-ci<\077\376\003\000\000\002\376\001\000\000\011char-ci>\077\376\003\000\000\002\376\001\000\000\012char-ci>=\077\376\003\000\000\002"
"\376\001\000\000\012char-ci<=\077\376\003\000\000\002\376\001\000\000\020char-alphabetic\077\376\003\000\000\002\376\001\000\000\020char-whitespace\077\376\003\000\000\002\376\001\000\000\015cha"
"r-numeric\077\376\003\000\000\002\376\001\000\000\020char-upper-case\077\376\003\000\000\002\376\001\000\000\020char-lower-case\077\376\003\000\000\002\376\001\000\000\013char-upc"
"ase\376\003\000\000\002\376\001\000\000\015char-downcase\376\003\000\000\002\376\001\000\000\015char->integer\376\003\000\000\002\376\001\000\000\015integer->char\376\003\000\000\002\376\001\000"
"\000\007string\077\376\003\000\000\002\376\001\000\000\010string=\077\376\003\000\000\002\376\001\000\000\010string>\077\376\003\000\000\002\376\001\000\000\010string<\077\376\003\000\000\002\376\001\000\000\011string>"
"=\077\376\003\000\000\002\376\001\000\000\011string<=\077\376\003\000\000\002\376\001\000\000\013string-ci=\077\376\003\000\000\002\376\001\000\000\013string-ci<\077\376\003\000\000\002\376\001\000\000\013string-"
"ci>\077\376\003\000\000\002\376\001\000\000\014string-ci>=\077\376\003\000\000\002\376\001\000\000\014string-ci<=\077\376\003\000\000\002\376\001\000\000\013make-string\376\003\000\000\002\376\001\000\000\015s"
"tring-length\376\003\000\000\002\376\001\000\000\012string-ref\376\003\000\000\002\376\001\000\000\013string-set!\376\003\000\000\002\376\001\000\000\015string-append\376\003\000\000"
"\002\376\001\000\000\013string-copy\376\003\000\000\002\376\001\000\000\014string->list\376\003\000\000\002\376\001\000\000\014list->string\376\003\000\000\002\376\001\000\000\011substring"
"\376\003\000\000\002\376\001\000\000\014string-fill!\376\003\000\000\002\376\001\000\000\007vector\077\376\003\000\000\002\376\001\000\000\013make-vector\376\003\000\000\002\376\001\000\000\012vector-ref"
"\376\003\000\000\002\376\001\000\000\013vector-set!\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006vector\376\003\000\000\002\376\001\000\000\015vector-length\376\003\000\000"
"\002\376\001\000\000\014vector->list\376\003\000\000\002\376\001\000\000\014list->vector\376\003\000\000\002\376\001\000\000\014vector-fill!\376\003\000\000\002\376\001\000\000\012procedur"
"e\077\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\005apply\376\003\000\000\002\376\001\000\000\005force\376\003\000\000\002\376\001\000\000\036call-wi"
"th-current-continuation\376\003\000\000\002\376\001\000\000\013input-port\077\376\003\000\000\002\376\001\000\000\014output-port\077\376\003\000\000\002\376\001\000\000\022curr"
"ent-input-port\376\003\000\000\002\376\001\000\000\023current-output-port\376\003\000\000\002\376\001\000\000\024call-with-input-file\376\003\000\000\002\376\001"
"\000\000\025call-with-output-file\376\003\000\000\002\376\001\000\000\017open-input-file\376\003\000\000\002\376\001\000\000\020open-output-file\376\003\000\000\002"
"\376\001\000\000\020close-input-port\376\003\000\000\002\376\001\000\000\021close-output-port\376\003\000\000\002\376\001\000\000\004load\376\003\000\000\002\376\001\000\000\004read\376\003\000\000"
"\002\376\001\000\000\013eof-object\077\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000\002\376\001\000\000\011peek-char\376\003\000\000\002\376\001\000\000\005write\376\003\000\000\002\376\001\000\000\007"
"display\376\003\000\000\002\376\001\000\000\012write-char\376\003\000\000\002\376\001\000\000\007newline\376\003\000\000\002\376\001\000\000\024with-input-from-file\376\003\000\000\002\376"
"\001\000\000\023with-output-to-file\376\003\000\000\002\376\001\000\000\024\003syscall-with-values\376\003\000\000\002\376\001\000\000\012\003sysvalues\376\003\000\000\002\376\001"
"\000\000\020\003sysdynamic-wind\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\003\000\000\002\376\001\000\000\020\003syslist->vector\376\003\000\000\002\376\001\000\000\010\003syslis"
"t\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\020\003sysmake-promise\376\377\016");
lf[497]=C_h_intern(&lf[497],18,"\003sysnumber->string");
lf[498]=C_h_intern(&lf[498],5,"error");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid extension version");
lf[500]=C_h_intern(&lf[500],7,"version");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\0003installed extension does not match required version");
lf[502]=C_h_intern(&lf[502],9,"string>=\077");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\035invalid version specification");
lf[504]=C_h_intern(&lf[504],12,"list->vector");
lf[505]=C_h_intern(&lf[505],18,"\003sysstring->symbol");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\005srfi-");
lf[507]=C_h_intern(&lf[507],4,"srfi");
lf[508]=C_h_intern(&lf[508],14,"build-platform");
lf[509]=C_h_intern(&lf[509],7,"windows");
lf[510]=C_h_intern(&lf[510],6,"macosx");
lf[511]=C_h_intern(&lf[511],4,"hpux");
lf[512]=C_h_intern(&lf[512],4,"hppa");
lf[513]=C_h_intern(&lf[513],12,"machine-type");
lf[514]=C_h_intern(&lf[514],16,"software-version");
lf[515]=C_h_intern(&lf[515],13,"software-type");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\012C_toplevel");
C_register_lf2(lf,517,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate((C_word*)lf[2]+1,lf[3]);
t4=C_set_block_item(lf[4],0,C_SCHEME_END_OF_LIST);
t5=C_mutate(&lf[5],lf[6]);
t6=C_mutate(&lf[7],lf[8]);
t7=C_mutate(&lf[9],lf[10]);
t8=C_mutate(&lf[11],lf[12]);
t9=C_mutate(&lf[13],lf[14]);
t10=C_mutate(&lf[15],lf[16]);
t11=C_mutate(&lf[17],lf[18]);
t12=C_mutate(&lf[19],lf[20]);
t13=C_mutate(&lf[21],lf[22]);
t14=C_mutate(&lf[23],lf[24]);
t15=C_mutate(&lf[25],lf[26]);
t16=C_mutate(&lf[27],lf[28]);
t17=*((C_word*)lf[29]+1);
t18=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1695,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1734,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 157  make-vector */
t20=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t19,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k1732 */
static void C_ccall f_1734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word ab[67],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1734,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1,t1);
t3=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1736,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1752,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1768,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1778,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1796,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[45]+1);
t9=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1805,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2175,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2178,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2181,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(lf[75],0,C_SCHEME_FALSE);
t14=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2188,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2224,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2240,tmp=(C_word)a,a+=2,tmp));
t17=*((C_word*)lf[82]+1);
t18=*((C_word*)lf[83]+1);
t19=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2283,a[2]=t18,a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[82]+1);
t21=*((C_word*)lf[104]+1);
t22=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2802,a[2]=t21,a[3]=t20,tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[119]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3285,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[111]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3376,tmp=(C_word)a,a+=2,tmp));
t25=C_SCHEME_FALSE;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_FALSE;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_mutate((C_word*)lf[120]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3436,a[2]=t28,a[3]=t26,tmp=(C_word)a,a+=4,tmp));
t30=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3451,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3496,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[121]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3551,tmp=(C_word)a,a+=2,tmp));
t33=(C_word)C_slot(lf[123],C_fix(0));
t34=C_mutate((C_word*)lf[124]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3597,a[2]=t33,tmp=(C_word)a,a+=3,tmp));
t35=C_set_block_item(lf[125],0,C_SCHEME_FALSE);
t36=C_set_block_item(lf[126],0,C_SCHEME_FALSE);
t37=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3657,tmp=(C_word)a,a+=2,tmp));
t38=C_set_block_item(lf[133],0,C_SCHEME_FALSE);
t39=C_set_block_item(lf[134],0,C_fix(1));
t40=C_mutate((C_word*)lf[135]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3698,tmp=(C_word)a,a+=2,tmp));
t41=*((C_word*)lf[43]+1);
t42=*((C_word*)lf[130]+1);
t43=*((C_word*)lf[136]+1);
t44=*((C_word*)lf[82]+1);
t45=*((C_word*)lf[131]+1);
t46=*((C_word*)lf[129]+1);
t47=*((C_word*)lf[137]+1);
t48=(C_word)C_slot(lf[123],C_fix(0));
t49=*((C_word*)lf[138]+1);
t50=C_mutate((C_word*)lf[139]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3704,a[2]=t43,a[3]=t48,tmp=(C_word)a,a+=4,tmp));
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5940,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11305,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1038 make-parameter */
t53=*((C_word*)lf[441]+1);
((C_proc3)(void*)(*((C_word*)t53+1)))(3,t53,t51,t52);}

/* a11304 in k1732 */
static void C_ccall f_11305(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_11305r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_11305r(t0,t1,t2,t3);}}

static void C_ccall f_11305r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(10);
t4=*((C_word*)lf[126]+1);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11309,a[2]=t2,a[3]=t1,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t9=(C_word)C_slot(t3,C_fix(0));
if(C_truep(t9)){
t10=(C_word)C_i_check_structure(t9,lf[319]);
t11=(C_word)C_slot(t9,C_fix(1));
t12=C_set_block_item(t7,0,t11);
t13=(C_word)C_slot(t9,C_fix(2));
t14=C_set_block_item(t5,0,t13);
t15=t8;
f_11309(t15,t14);}
else{
t10=t8;
f_11309(t10,C_SCHEME_UNDEFINED);}}
else{
t9=t8;
f_11309(t9,C_SCHEME_UNDEFINED);}}

/* k11307 in a11304 in k1732 */
static void C_fcall f_11309(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11309,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11315,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11317,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11333,a[2]=t9,a[3]=t7,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1048 ##sys#dynamic-wind */
t14=*((C_word*)lf[235]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t10,t11,t12,t13);}

/* a11332 in k11307 in a11304 in k1732 */
static void C_ccall f_11333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11333,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[126]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[125]+1));
t4=C_mutate((C_word*)lf[126]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[125]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[228]+1));}

/* a11326 in k11307 in a11304 in k1732 */
static void C_ccall f_11327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11327,2,t0,t1);}
/* eval.scm: 1050 ##sys#compile-to-closure */
t2=*((C_word*)lf[139]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* a11316 in k11307 in a11304 in k1732 */
static void C_ccall f_11317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11317,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[126]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[125]+1));
t4=C_mutate((C_word*)lf[126]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[125]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[228]+1));}

/* k11313 in k11307 in a11304 in k1732 */
static void C_ccall f_11315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5938 in k1732 */
static void C_ccall f_5940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5940,2,t0,t1);}
t2=C_mutate((C_word*)lf[204]+1,t1);
t3=C_mutate((C_word*)lf[205]+1,*((C_word*)lf[204]+1));
t4=C_mutate((C_word*)lf[206]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5943,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[82]+1);
t6=C_mutate((C_word*)lf[162]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5957,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6039,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fudge(C_fix(13));
/* eval.scm: 1082 make-parameter */
t9=*((C_word*)lf[441]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k6037 in k5938 in k1732 */
static void C_ccall f_6039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6039,2,t0,t1);}
t2=C_mutate((C_word*)lf[209]+1,t1);
t3=C_mutate((C_word*)lf[210]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6041,tmp=(C_word)a,a+=2,tmp));
t4=C_set_block_item(lf[211],0,C_SCHEME_FALSE);
t5=C_mutate((C_word*)lf[212]+1,lf[213]);
t6=C_mutate((C_word*)lf[214]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6046,tmp=(C_word)a,a+=2,tmp));
t7=*((C_word*)lf[222]+1);
t8=*((C_word*)lf[130]+1);
t9=*((C_word*)lf[138]+1);
t10=*((C_word*)lf[223]+1);
t11=*((C_word*)lf[206]+1);
t12=*((C_word*)lf[224]+1);
t13=*((C_word*)lf[225]+1);
t14=*((C_word*)lf[45]+1);
t15=*((C_word*)lf[209]+1);
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6119,a[2]=((C_word*)t0)[2],a[3]=t15,a[4]=t9,a[5]=t12,a[6]=t13,a[7]=t8,a[8]=t10,a[9]=t7,a[10]=t11,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1114 ##sys#make-c-string */
t17=*((C_word*)lf[239]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,lf[516]);}

/* k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6121,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[226]+1,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6167,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp));
t4=C_mutate((C_word*)lf[232]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6554,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[251]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6576,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[252]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6612,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6638,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11299,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1204 software-type */
t9=*((C_word*)lf[515]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}

/* k11297 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11299,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[509]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6638(t3,lf[12]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11295,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1205 software-version */
t4=*((C_word*)lf[514]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11293 in k11297 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11295,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[510]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6638(t3,lf[10]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11277,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11291,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1206 software-version */
t5=*((C_word*)lf[514]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k11289 in k11293 in k11297 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11291,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[511]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11287,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1207 machine-type */
t4=*((C_word*)lf[513]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_11277(t3,C_SCHEME_FALSE);}}

/* k11285 in k11289 in k11293 in k11297 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_11277(t2,(C_word)C_eqp(t1,lf[512]));}

/* k11275 in k11293 in k11297 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_11277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6638(t2,(C_truep(t1)?lf[14]:lf[15]));}

/* k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_6638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6638,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[256]+1,t1);
t3=C_mutate((C_word*)lf[246]+1,lf[15]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6643,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1213 build-platform */
t5=*((C_word*)lf[508]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6643,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[257]);
t3=(C_truep(t2)?lf[8]:lf[6]);
t4=C_mutate((C_word*)lf[258]+1,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6650,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11247,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11255,tmp=(C_word)a,a+=2,tmp);
/* map */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,*((C_word*)lf[258]+1));}

/* a11254 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11255,3,t0,t1,t2);}
/* ##sys#string-append */
t3=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[256]+1));}

/* k11245 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11249,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1218 make-parameter */
t3=*((C_word*)lf[441]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a11248 in k11245 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11249(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11249,3,t0,t1,t2);}
t3=(C_word)C_i_check_list(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6650,2,t0,t1);}
t2=C_mutate((C_word*)lf[259]+1,t1);
t3=*((C_word*)lf[209]+1);
t4=*((C_word*)lf[45]+1);
t5=*((C_word*)lf[259]+1);
t6=*((C_word*)lf[138]+1);
t7=C_mutate((C_word*)lf[260]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6652,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[267]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6758,tmp=(C_word)a,a+=2,tmp));
t9=*((C_word*)lf[82]+1);
t10=C_mutate(&lf[269],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6787,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[45]+1);
t12=C_mutate((C_word*)lf[270]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6843,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7003,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11237,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1306 getenv */
t15=*((C_word*)lf[29]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,lf[22]);}

/* k11235 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11240,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_11240(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_EGG_HOME),C_fix(0));}}

/* k11238 in k11235 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1305 make-parameter */
t2=*((C_word*)lf[441]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7003,2,t0,t1);}
t2=C_mutate((C_word*)lf[276]+1,t1);
t3=C_mutate((C_word*)lf[277]+1,*((C_word*)lf[276]+1));
t4=*((C_word*)lf[278]+1);
t5=*((C_word*)lf[45]+1);
t6=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7006,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t7=C_set_block_item(lf[283],0,C_SCHEME_END_OF_LIST);
t8=*((C_word*)lf[284]+1);
t9=C_mutate((C_word*)lf[285]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7083,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[287]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7151,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[288]+1,*((C_word*)lf[287]+1));
t12=C_mutate((C_word*)lf[289]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7171,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[290]+1,*((C_word*)lf[289]+1));
t14=C_mutate((C_word*)lf[167]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7185,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[291]+1,*((C_word*)lf[167]+1));
t16=*((C_word*)lf[137]+1);
t17=*((C_word*)lf[278]+1);
t18=*((C_word*)lf[45]+1);
t19=*((C_word*)lf[222]+1);
t20=C_mutate((C_word*)lf[292]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7198,a[2]=t18,a[3]=t17,a[4]=t19,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t21=C_mutate((C_word*)lf[295]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7229,tmp=(C_word)a,a+=2,tmp));
t22=*((C_word*)lf[137]+1);
t23=*((C_word*)lf[222]+1);
t24=C_mutate((C_word*)lf[168]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7235,tmp=(C_word)a,a+=2,tmp));
t25=*((C_word*)lf[297]+1);
t26=C_mutate((C_word*)lf[171]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7284,a[2]=t25,tmp=(C_word)a,a+=3,tmp));
t27=C_set_block_item(lf[312],0,C_SCHEME_END_OF_LIST);
t28=C_mutate((C_word*)lf[315]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7683,tmp=(C_word)a,a+=2,tmp));
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7722,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t30=*((C_word*)lf[504]+1);
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11183,a[2]=t30,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1493 set-extension-specifier! */
t32=*((C_word*)lf[315]+1);
((C_proc4)(void*)(*((C_word*)t32+1)))(4,t32,t29,lf[507],t31);}

/* a11182 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11183,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11191,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11197,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_11197(t9,t4,t5);}

/* loop in a11182 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_11197(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11197,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_check_exact_2(t3,lf[310]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11217,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11229,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11233,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1503 number->string */
C_number_to_string(3,0,t7,t3);}}

/* k11231 in loop in a11182 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1503 ##sys#string-append */
t2=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[506],t1);}

/* k11227 in loop in a11182 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1503 ##sys#string->symbol */
t2=*((C_word*)lf[505]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k11215 in loop in a11182 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11221,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1504 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_11197(t4,t2,t3);}

/* k11219 in k11215 in loop in a11182 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11221,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k11189 in a11182 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1497 list->vector */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7725,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11062,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1509 set-extension-specifier! */
t4=*((C_word*)lf[315]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[500],t3);}

/* a11061 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11062,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11065,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11099,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[500]);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_u_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_u_i_cdddr(t2);
t11=t5;
f_11099(t11,(C_word)C_i_nullp(t10));}
else{
t10=t5;
f_11099(t10,C_SCHEME_FALSE);}}
else{
t9=t5;
f_11099(t9,C_SCHEME_FALSE);}}
else{
t8=t5;
f_11099(t8,C_SCHEME_FALSE);}}
else{
t6=t5;
f_11099(t6,C_SCHEME_FALSE);}}

/* k11097 in a11061 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_11099(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11099,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11108,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1519 extension-information */
t5=*((C_word*)lf[295]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
/* syntax-error */
t2=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[310],lf[503],((C_word*)t0)[4]);}}

/* k11106 in k11097 in a11061 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11108,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_assq(lf[500],t1):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11114,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11117,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11127,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* eval.scm: 1521 ->string */
f_11065(t5,t6);}
else{
t5=t4;
f_11117(2,t5,C_SCHEME_FALSE);}}

/* k11125 in k11106 in k11097 in a11061 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11131,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1521 ->string */
f_11065(t2,((C_word*)t0)[2]);}

/* k11129 in k11125 in k11106 in k11097 in a11061 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1521 string>=? */
t2=*((C_word*)lf[502]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11115 in k11106 in k11097 in a11061 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_11114(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1522 error */
t2=*((C_word*)lf[498]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[501],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11112 in k11106 in k11097 in a11061 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ->string in a11061 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_11065(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11065,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* eval.scm: 1515 ##sys#number->string */
t3=*((C_word*)lf[497]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
/* eval.scm: 1516 error */
t3=*((C_word*)lf[498]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[499],t2);}}}}

/* k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7725,2,t0,t1);}
t2=*((C_word*)lf[316]+1);
t3=C_mutate((C_word*)lf[265]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7727,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7783,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1543 make-vector */
t5=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7783,2,t0,t1);}
t2=C_mutate(&lf[317],t1);
t3=lf[318]=C_SCHEME_FALSE;;
t4=(C_word)C_a_i_record(&a,3,lf[319],C_SCHEME_FALSE,C_SCHEME_TRUE);
t5=C_mutate(&lf[320],t4);
t6=C_mutate((C_word*)lf[321]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7790,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[322]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7898,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[324]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8017,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[325]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8020,tmp=(C_word)a,a+=2,tmp));
t10=*((C_word*)lf[327]+1);
t11=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8064,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8102,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8118,a[2]=t12,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11060,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1624 initb */
f_8102(t14,lf[317]);}

/* k11058 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[496]);}

/* k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1645 ##sys#copy-env-table */
t3=*((C_word*)lf[321]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[317],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8122,2,t0,t1);}
t2=C_mutate(&lf[318],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8125,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11056,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1647 initb */
f_8102(t4,lf[318]);}

/* k11054 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[495]);}

/* k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8129,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1654 chicken-home */
t3=*((C_word*)lf[30]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8129,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):C_SCHEME_END_OF_LIST);
t3=C_mutate((C_word*)lf[281]+1,t2);
t4=*((C_word*)lf[45]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8135,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[307]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8154,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[138]+1);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8277,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8301,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=C_mutate((C_word*)lf[229]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8322,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(lf[337],0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8376,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(lf[207],0,C_SCHEME_FALSE);
t14=C_mutate((C_word*)lf[339]+1,*((C_word*)lf[56]+1));
t15=C_mutate((C_word*)lf[340]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8384,tmp=(C_word)a,a+=2,tmp));
t16=*((C_word*)lf[45]+1);
t17=*((C_word*)lf[341]+1);
t18=*((C_word*)lf[340]+1);
t19=*((C_word*)lf[342]+1);
t20=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8420,a[2]=t17,a[3]=t18,a[4]=t19,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8812,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10959,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1815 ##sys#register-macro-2 */
t23=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t21,lf[107],t22);}

/* a10958 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10959(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10959,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10965,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10965(t6,t1,t2);}

/* loop in a10958 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_10965(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10965,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11006,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1826 ##sys#check-syntax */
t7=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[107],t3,lf[490]);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11019,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1830 ##sys#check-syntax */
t7=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[107],t3,lf[492]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10981,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1822 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[107],t3,lf[357]);}}

/* k10979 in loop in a10958 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1823 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[4],lf[494]);}

/* k10982 in k10979 in loop in a10958 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10984,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[4]):lf[493]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[71],((C_word*)t0)[2],t3));}

/* k11017 in loop in a10958 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1831 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[3],lf[491]);}

/* k11020 in k11017 in loop in a10958 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11022,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,lf[92],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[71],t2,t5));}

/* k11004 in loop in a10958 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1827 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[107],((C_word*)t0)[2],lf[489]);}

/* k11007 in k11004 in loop in a10958 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11016,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1828 ##sys#expand-curried-define */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11014 in k11007 in k11004 in loop in a10958 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_11016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1828 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10965(t2,((C_word*)t0)[2],t1);}

/* k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8815,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10931,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1834 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[445],t3);}

/* a10930 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10931(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10931,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(C_word)C_a_i_cons(&a,2,lf[445],t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,4,lf[149],t5,t7,C_SCHEME_FALSE));}}}

/* k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8818,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10888,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1845 ##sys#register-macro-2 */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[446],t4);}

/* a10887 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10888,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10910,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1855 gensym */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}}

/* k10908 in a10887 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10910,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[446],((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,4,lf[149],t1,t1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[58],t3,t5));}

/* k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8821,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10691,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1859 ##sys#register-macro-2 */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[486],t4);}

/* a10690 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10691,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10697,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10697(t6,t1,t2);}

/* expand in a10690 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_10697(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10697,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10713,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1868 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[486],t3,lf[487]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[488]);}}

/* k10711 in expand in a10690 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10713,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[449],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[106],t4));}
else{
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10743,a[2]=t6,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1870 expand */
t8=((C_word*)((C_word*)t0)[4])[1];
f_10697(t8,t7,((C_word*)t0)[3]);}
else{
t6=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_eqp(lf[484],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10752,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1872 gensym */
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[6]))){
t9=(C_word)C_i_length(((C_word*)t0)[6]);
t10=(C_word)C_eqp(t9,C_fix(4));
if(C_truep(t10)){
t11=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
t12=t8;
f_10789(t12,(C_word)C_eqp(lf[484],t11));}
else{
t11=t8;
f_10789(t11,C_SCHEME_FALSE);}}
else{
t9=t8;
f_10789(t9,C_SCHEME_FALSE);}}}}}

/* k10787 in k10711 in expand in a10690 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_10789(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10789,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1878 gensym */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,lf[106],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10846,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1887 expand */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10697(t6,t5,((C_word*)t0)[3]);}}

/* k10844 in k10787 in k10711 in expand in a10690 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10846,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[149],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10790 in k10787 in k10711 in expand in a10690 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10792,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,3,lf[92],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,3,lf[485],t4,t1);
t6=(C_word)C_u_i_cadddr(((C_word*)t0)[5]);
t7=(C_word)C_a_i_list(&a,3,lf[485],t6,t1);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10819,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1884 expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_10697(t9,t8,((C_word*)t0)[2]);}

/* k10817 in k10790 in k10787 in k10711 in expand in a10690 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10819,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[149],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,3,lf[92],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[2],t3));}

/* k10750 in k10711 in expand in a10690 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10752,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,t5,t1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10771,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1876 expand */
t8=((C_word*)((C_word*)t0)[3])[1];
f_10697(t8,t7,((C_word*)t0)[2]);}

/* k10769 in k10750 in k10711 in expand in a10690 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10771,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[149],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t2));}

/* k10741 in k10711 in expand in a10690 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10743,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[446],((C_word*)t0)[2],t1));}

/* k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8824,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10588,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1889 ##sys#register-macro-2 */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[481],t4);}

/* a10587 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10588,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10598,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1895 gensym */
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k10596 in a10587 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10598,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10609,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10611,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10611(t8,t4,((C_word*)t0)[2]);}

/* expand in k10596 in a10587 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_10611(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10611,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10627,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1902 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[481],t3,lf[482]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[483]);}}

/* k10625 in expand in k10596 in a10587 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10627,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[449],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[106],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10663,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10665,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* eval.scm: 1905 ##sys#map */
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a10664 in k10625 in expand in k10596 in a10587 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10665(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10665,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[90],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[480],((C_word*)t0)[2],t3));}

/* k10661 in k10625 in expand in k10596 in a10587 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10663,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[446],t1);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,lf[106],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10655,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1907 expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_10611(t6,t5,((C_word*)t0)[2]);}

/* k10653 in k10661 in k10625 in expand in k10596 in a10587 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10655,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[149],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10607 in k10596 in a10587 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10609,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t1));}

/* k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8827,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10535,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1909 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[89],t3);}

/* a10534 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10535(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10535,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10545,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1914 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[89],t3,lf[479]);}

/* k10543 in a10534 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1915 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[89],((C_word*)t0)[4],lf[478]);}

/* k10546 in k10543 in a10534 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10548,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10553,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_10553(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k10546 in k10543 in a10534 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_10553(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10553,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[58],t4));}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10578,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1919 expand */
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k10576 in expand in k10546 in k10543 in a10534 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10578,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[58],((C_word*)t0)[2],t1));}

/* k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8830,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10465,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1921 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[60],t3);}

/* a10464 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10465,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10475,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1926 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],t3,lf[477]);}

/* k10473 in a10464 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1927 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[60],((C_word*)t0)[3],lf[476]);}

/* k10476 in k10473 in a10464 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10525,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1928 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10524 in k10476 in k10473 in a10464 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10525,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t3,lf[475]));}

/* k10487 in k10476 in k10473 in a10464 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10493,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10497,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10511,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1929 ##sys#map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a10510 in k10487 in k10476 in k10473 in a10464 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10511(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10511,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[71],t3,t4));}

/* k10495 in k10487 in k10476 in k10473 in a10464 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10497,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[58],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k10491 in k10487 in k10476 in k10473 in a10464 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10493,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[58],t2));}

/* k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8833,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[83]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10346,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1932 ##sys#register-macro */
t5=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[472],t4);}

/* a10345 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10346(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_10346r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10346r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10346r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10350,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1936 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[472],t2,lf[474]);}

/* k10348 in a10345 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1937 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[472],((C_word*)t0)[6],lf[473]);}

/* k10351 in k10348 in a10345 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10356,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1938 gensym */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[471]);}

/* k10354 in k10351 in k10348 in a10345 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10447,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1939 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a10446 in k10354 in k10351 in k10348 in a10345 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10447,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k10361 in k10354 in k10351 in k10348 in a10345 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10363,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
t5=(C_truep(t4)?lf[469]:(C_word)C_a_i_cons(&a,2,lf[106],t3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10386,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t7)){
t8=t6;
f_10386(t8,lf[470]);}
else{
t8=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t9=t6;
f_10386(t9,(C_word)C_a_i_cons(&a,2,lf[58],t8));}}

/* k10384 in k10361 in k10354 in k10351 in k10348 in a10345 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_10386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10386,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10398,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10400,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1950 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a10399 in k10384 in k10361 in k10354 in k10351 in k10348 in a10345 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10400(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10400,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_u_i_car(t2));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t6,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_u_i_car(t7));}}

/* k10396 in k10384 in k10361 in k10354 in k10351 in k10348 in a10345 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10398,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[61],t2);
t4=(C_word)C_a_i_list(&a,3,lf[106],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,4,lf[149],((C_word*)t0)[5],((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[58],((C_word*)t0)[7],((C_word*)t0)[2],t5));}

/* k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8836,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[297]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10054,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1956 ##sys#register-macro */
t5=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[458],t4);}

/* a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10054,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10057,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10067,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10264,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
/* eval.scm: 2017 walk */
t12=((C_word*)t4)[1];
f_10057(t12,t1,t2,C_fix(0));}

/* simplify in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_10264(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10264,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10268,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2004 ##sys#match-expression */
t4=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[467],lf[468]);}

/* k10266 in simplify in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10268,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[461],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_list(&a,2,lf[455],t3);
/* eval.scm: 2005 simplify */
t5=((C_word*)((C_word*)t0)[4])[1];
f_10264(t5,((C_word*)t0)[3],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2006 ##sys#match-expression */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[465],lf[466]);}}

/* k10287 in k10266 in simplify in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10289,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[462],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(C_word)C_u_i_assq(lf[461],t1);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[455],t7);
/* eval.scm: 2010 simplify */
t9=((C_word*)((C_word*)t0)[4])[1];
f_10264(t9,((C_word*)t0)[3],t8);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2013 ##sys#match-expression */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[463],lf[464]);}}

/* k10329 in k10287 in k10266 in simplify in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[461],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* walk1 in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_10067(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[72],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10067,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10081,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10085,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1966 vector->list */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_eqp(t4,lf[454]);
if(C_truep(t6)){
t7=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_slot(t5,C_fix(0));
t9=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10128,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1978 walk */
t12=((C_word*)((C_word*)t0)[3])[1];
f_10057(t12,t10,t8,t11);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[457]);}}
else{
t7=(C_word)C_eqp(t4,lf[458]);
if(C_truep(t7)){
t8=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_a_i_list(&a,2,lf[90],lf[458]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10155,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t5,C_fix(0));
t12=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 1983 walk */
t13=((C_word*)((C_word*)t0)[3])[1];
f_10057(t13,t10,t11,t12);}
else{
t9=(C_word)C_a_i_list(&a,2,lf[90],lf[458]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10174,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1984 walk */
t11=((C_word*)((C_word*)t0)[3])[1];
f_10057(t11,t10,t5,t3);}}
else{
t8=(C_truep((C_word)C_blockp(t4))?(C_word)C_pairp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_slot(t4,C_fix(0));
t10=(C_word)C_slot(t4,C_fix(1));
t11=(C_word)C_eqp(t9,lf[460]);
t12=(C_truep(t11)?(C_truep((C_word)C_blockp(t10))?(C_word)C_pairp(t10):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=(C_word)C_slot(t10,C_fix(0));
t14=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10208,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1995 walk */
t16=((C_word*)((C_word*)t0)[3])[1];
f_10057(t16,t15,t5,t3);}
else{
t15=(C_word)C_a_i_list(&a,2,lf[90],lf[460]);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10227,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t15,tmp=(C_word)a,a+=7,tmp);
t17=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1997 walk */
t18=((C_word*)((C_word*)t0)[3])[1];
f_10057(t18,t16,t13,t17);}}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10238,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1999 walk */
t14=((C_word*)((C_word*)t0)[3])[1];
f_10057(t14,t13,t4,t3);}}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10255,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2000 walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_10057(t10,t9,t4,t3);}}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[90],t2));}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[90],t2));}}

/* k10253 in walk1 in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10259,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2000 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10057(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10257 in k10253 in walk1 in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10259,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[459],((C_word*)t0)[2],t1));}

/* k10236 in walk1 in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10242,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1999 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10057(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10240 in k10236 in walk1 in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10242,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[459],((C_word*)t0)[2],t1));}

/* k10225 in walk1 in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10227,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[455],((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10219,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1998 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_10057(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10217 in k10225 in walk1 in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10219,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[459],((C_word*)t0)[2],t1));}

/* k10206 in walk1 in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10208,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[88],((C_word*)t0)[2],t1));}

/* k10172 in walk1 in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10174,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[459],((C_word*)t0)[2],t1));}

/* k10153 in walk1 in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10155,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[455],((C_word*)t0)[2],t1));}

/* k10126 in walk1 in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10128,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[455],lf[456],t1));}

/* k10083 in walk1 in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1966 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10057(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10079 in walk1 in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10081,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[453],t1));}

/* walk in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_10057(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10057,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10065,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1961 walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10067(t5,t4,t2,t3);}

/* k10063 in walk in a10053 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1961 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10264(t2,((C_word*)t0)[2],t1);}

/* k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8839,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10044,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2019 ##sys#register-macro */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[452],t3);}

/* a10043 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10044(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10044,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,3,lf[92],C_SCHEME_END_OF_LIST,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[451],t3));}

/* k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8842,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9798,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2023 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[443],t3);}

/* a9797 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9798(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9798,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9801,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9811,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9953,a[2]=t3,a[3]=t5,a[4]=t8,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_9953(t10,t1,t2);}

/* expand in a9797 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_9953(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9953,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9967,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9969,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(0));
t7=(C_word)C_eqp(t6,lf[449]);
if(C_truep(t7)){
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_eqp(t8,C_SCHEME_END_OF_LIST);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_truep(t9)?lf[450]:(C_word)C_a_i_cons(&a,2,lf[106],t8)));}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10024,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2068 test */
t9=((C_word*)((C_word*)t0)[3])[1];
f_9811(t9,t8,t6);}}
else{
/* eval.scm: 2061 err */
t6=((C_word*)t0)[2];
f_9801(t6,t1,t4);}}
else{
/* eval.scm: 2056 err */
t4=((C_word*)t0)[2];
f_9801(t4,t1,t2);}}}

/* k10022 in expand in a9797 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_10024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10024,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[106],t2));}
else{
/* eval.scm: 2069 expand */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9953(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a9968 in expand in a9797 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9969(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9969,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k9965 in expand in a9797 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[141]+1),lf[448],t1);}

/* test in a9797 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_9811(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9811,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 2031 ##sys#feature? */
t3=*((C_word*)lf[311]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_eqp(t4,lf[445]);
if(C_truep(t5)){
t6=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9860,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 2039 test */
t17=t7;
t18=t8;
t1=t17;
t2=t18;
goto loop;}
else{
/* eval.scm: 2041 err */
t7=((C_word*)t0)[2];
f_9801(t7,t1,t2);}}}
else{
t6=(C_word)C_eqp(t4,lf[446]);
if(C_truep(t6)){
t7=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9899,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 2045 test */
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
/* eval.scm: 2047 err */
t8=((C_word*)t0)[2];
f_9801(t8,t1,t2);}}}
else{
t7=(C_word)C_eqp(t4,lf[447]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9937,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_u_i_cadr(t2);
/* eval.scm: 2048 test */
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
/* eval.scm: 2049 err */
t8=((C_word*)t0)[2];
f_9801(t8,t1,t2);}}}}
else{
/* eval.scm: 2032 err */
t3=((C_word*)t0)[2];
f_9801(t3,t1,t2);}}}

/* k9935 in test in a9797 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* k9897 in test in a9797 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9899,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,lf[446],t2);
/* eval.scm: 2046 test */
t4=((C_word*)((C_word*)t0)[2])[1];
f_9811(t4,((C_word*)t0)[4],t3);}}

/* k9858 in test in a9797 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9860,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,lf[445],t2);
/* eval.scm: 2040 test */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9811(t4,((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* err in a9797 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_9801(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9801,NULL,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,lf[443],((C_word*)t0)[2]);
/* eval.scm: 2028 ##sys#error */
t4=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[444],t2,t3);}

/* k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8846,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2075 append */
t3=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[442],*((C_word*)lf[182]+1));}

/* k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8846,2,t0,t1);}
t2=C_mutate((C_word*)lf[182]+1,t1);
t3=C_set_block_item(lf[373],0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[374],0,C_SCHEME_FALSE);
t5=C_set_block_item(lf[375],0,C_SCHEME_FALSE);
t6=C_mutate((C_word*)lf[376]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8851,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8868,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9795,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2089 make-parameter */
t9=*((C_word*)lf[441]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a9794 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9795,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[440]);}

/* k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8868,2,t0,t1);}
t2=C_mutate((C_word*)lf[380]+1,t1);
t3=*((C_word*)lf[380]+1);
t4=C_mutate((C_word*)lf[381]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8870,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[384]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8886,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[206]+1);
t7=*((C_word*)lf[222]+1);
t8=*((C_word*)lf[55]+1);
t9=*((C_word*)lf[385]+1);
t10=*((C_word*)lf[386]+1);
t11=*((C_word*)lf[209]+1);
t12=*((C_word*)lf[387]+1);
t13=C_mutate((C_word*)lf[388]+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8889,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t11,a[6]=t9,a[7]=t10,tmp=(C_word)a,a+=8,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9228,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2205 make-vector */
t15=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9228,2,t0,t1);}
t2=C_mutate((C_word*)lf[403]+1,t1);
t3=C_mutate((C_word*)lf[404]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9230,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[405]+1);
t5=*((C_word*)lf[406]+1);
t6=*((C_word*)lf[222]+1);
t7=C_mutate((C_word*)lf[405]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9239,a[2]=t4,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9653,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2234 ##sys#register-macro */
t10=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,lf[436],t9);}

/* a9652 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9653(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_9653r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9653r(t0,t1,t2,t3);}}

static void C_ccall f_9653r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(14);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9656,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9761,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2245 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[436],t3,lf[437]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9771,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2248 ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[436],t2,lf[439]);}}

/* k9769 in a9652 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2249 ##sys#check-syntax */
t3=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[436],((C_word*)t0)[4],lf[438]);}

/* k9772 in k9769 in a9652 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9774,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[92],t4);
/* eval.scm: 2250 expand */
f_9656(((C_word*)t0)[2],t2,t5);}

/* k9759 in a9652 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
/* eval.scm: 2246 expand */
f_9656(((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* expand in a9652 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_9656(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9656,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9660,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(lf[92],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_u_i_cadr(t3);
t9=t4;
f_9660(t9,(C_word)C_i_symbolp(t8));}
else{
t8=t4;
f_9660(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_9660(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_9660(t5,C_SCHEME_FALSE);}}

/* k9658 in expand in a9652 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_9660(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[64],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9660,NULL,2,t0,t1);}
t2=(C_truep(*((C_word*)lf[75]+1))?lf[173]:lf[172]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9671,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[92],t8);
t10=t3;
f_9671(t10,(C_word)C_a_i_list(&a,3,lf[38],t4,t9));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t6=t3;
f_9671(t6,(C_word)C_a_i_list(&a,3,lf[41],t4,t5));}
else{
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t5=t3;
f_9671(t5,(C_word)C_a_i_list(&a,3,lf[40],t4,((C_word*)t0)[2]));}}}

/* k9669 in k9658 in expand in a9652 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_9671(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9671,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9317,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9634,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2252 ##sys#register-macro */
t4=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[310],t3);}

/* a9633 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9634(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_9634r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9634r(t0,t1,t2);}}

static void C_ccall f_9634r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9638,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2255 ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[310],t2,lf[435]);}

/* k9636 in a9633 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9645,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9647,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9646 in k9636 in a9633 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9647(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9647,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[90],t2));}

/* k9643 in k9636 in a9633 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9645,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[169],t1));}

/* k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9320,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9628,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2261 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[433],t3);}

/* a9627 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9628(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9628,3,t0,t1,t2);}
/* eval.scm: 2264 ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[433],lf[434]);}

/* k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9323,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9622,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2266 ##sys#register-macro-2 */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[431],t3);}

/* a9621 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9622(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9622,3,t0,t1,t2);}
/* eval.scm: 2269 ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[431],lf[432]);}

/* k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9323,2,t0,t1);}
t2=lf[410]=C_SCHEME_FALSE;;
t3=C_mutate(&lf[411],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9326,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[413],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9385,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[415],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9394,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[417],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9406,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[418],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9422,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[420],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9448,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[422],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9461,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[423],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9487,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[424],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9524,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[425],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9540,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[426],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9566,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[427],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9588,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[428],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9603,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[128]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9613,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##sys#make-lambda-info in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9613(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9613,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9620,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2376 ##sys#make-string */
t5=*((C_word*)lf[430]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k9618 in ##sys#make-lambda-info in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_string_to_lambdainfo(t1);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* CHICKEN_get_error_message in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9603,4,t0,t1,t2,t3);}
t4=lf[410];
t5=(C_truep(t4)?t4:lf[429]);
/* eval.scm: 2369 store-string */
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_9448(t5,t3,t2));}

/* CHICKEN_load in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9588,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9592,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k9590 in CHICKEN_load in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9597,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2366 run-safe */
f_9326(((C_word*)t0)[2],t2);}

/* a9596 in k9590 in CHICKEN_load in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9601,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2366 load */
t3=*((C_word*)lf[232]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9599 in a9596 in k9590 in CHICKEN_load in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* CHICKEN_read in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9566,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9570,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9568 in CHICKEN_read in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9570,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9575,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2360 run-safe */
f_9326(((C_word*)t0)[2],t3);}

/* a9574 in k9568 in CHICKEN_read in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9579,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2362 open-input-string */
t3=*((C_word*)lf[419]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9577 in a9574 in k9568 in CHICKEN_read in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2363 read */
t3=*((C_word*)lf[222]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k9584 in k9577 in a9574 in k9568 in CHICKEN_read in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2363 store-result */
f_9385(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_apply_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9540,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9546,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2353 run-safe */
f_9326(t1,t6);}

/* a9545 in CHICKEN_apply_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2355 open-output-string */
t3=*((C_word*)lf[131]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9548 in a9545 in CHICKEN_apply_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9553,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9564,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9562 in k9548 in a9545 in CHICKEN_apply_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2356 write */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9551 in k9548 in a9545 in CHICKEN_apply_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9560,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2357 get-output-string */
t3=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9558 in k9551 in k9548 in a9545 in CHICKEN_apply_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2357 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9448(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_apply in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9524,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9530,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2348 run-safe */
f_9326(t1,t5);}

/* a9529 in CHICKEN_apply in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9538,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9536 in a9529 in CHICKEN_apply in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2348 store-result */
f_9385(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval_string_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9487,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9491,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_fix(0));}

/* k9489 in CHICKEN_eval_string_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9491,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9496,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2339 run-safe */
f_9326(((C_word*)t0)[2],t4);}

/* a9495 in k9489 in CHICKEN_eval_string_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2341 open-output-string */
t3=*((C_word*)lf[131]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9498 in a9495 in k9489 in CHICKEN_eval_string_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9503,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9514,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9518,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9522,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2342 open-input-string */
t6=*((C_word*)lf[419]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k9520 in k9498 in a9495 in k9489 in CHICKEN_eval_string_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2342 read */
t2=*((C_word*)lf[222]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9516 in k9498 in a9495 in k9489 in CHICKEN_eval_string_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2342 eval */
t2=*((C_word*)lf[206]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9512 in k9498 in a9495 in k9489 in CHICKEN_eval_string_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2342 write */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9501 in k9498 in a9495 in k9489 in CHICKEN_eval_string_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2343 get-output-string */
t3=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9508 in k9501 in k9498 in a9495 in k9489 in CHICKEN_eval_string_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2343 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9448(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_eval_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9461,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9467,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2330 run-safe */
f_9326(t1,t5);}

/* a9466 in CHICKEN_eval_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2332 open-output-string */
t3=*((C_word*)lf[131]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9469 in a9466 in CHICKEN_eval_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9474,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9485,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2333 eval */
t4=*((C_word*)lf[206]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9483 in k9469 in a9466 in CHICKEN_eval_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2333 write */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9472 in k9469 in a9466 in CHICKEN_eval_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9481,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2334 get-output-string */
t3=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9479 in k9472 in k9469 in a9466 in CHICKEN_eval_to_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2334 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9448(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* store-string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static C_word C_fcall f_9448(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t2))){
t5=C_mutate(&lf[410],lf[421]);
return(C_SCHEME_FALSE);}
else{
return((C_word)C_copy_result_string(t1,t3,t4));}}

/* CHICKEN_eval_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9422,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9426,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9424 in CHICKEN_eval_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9426,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9431,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2311 run-safe */
f_9326(((C_word*)t0)[2],t3);}

/* a9430 in k9424 in CHICKEN_eval_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9435,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2313 open-input-string */
t3=*((C_word*)lf[419]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9433 in a9430 in k9424 in CHICKEN_eval_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9446,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2314 read */
t4=*((C_word*)lf[222]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k9444 in k9433 in a9430 in k9424 in CHICKEN_eval_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2314 eval */
t2=*((C_word*)lf[206]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9440 in k9433 in a9430 in k9424 in CHICKEN_eval_string in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2314 store-result */
f_9385(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9406,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9412,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2306 run-safe */
f_9326(t1,t4);}

/* a9411 in CHICKEN_eval in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9420,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2308 eval */
t3=*((C_word*)lf[206]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9418 in a9411 in CHICKEN_eval in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2308 store-result */
f_9385(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_yield in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9400,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2303 run-safe */
f_9326(t1,t2);}

/* a9399 in CHICKEN_yield in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9404,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2303 thread-yield! */
t3=*((C_word*)lf[416]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9402 in a9399 in CHICKEN_yield in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* store-result in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_9385(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9385,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9389,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2297 ##sys#gc */
t5=*((C_word*)lf[414]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_FALSE);}

/* k9387 in store-result in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_store_result(((C_word*)t0)[3],((C_word*)t0)[4]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* run-safe in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_9326(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9326,NULL,2,t1,t2);}
t3=lf[410]=C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9334,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9336,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2285 call-with-current-continuation */
t6=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a9335 in run-safe in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9336(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9336,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9342,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9361,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2285 with-exception-handler */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a9360 in a9335 in run-safe in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9367,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2285 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a9372 in a9360 in a9335 in run-safe in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9373(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_9373r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9373r(t0,t1,t2);}}

static void C_ccall f_9373r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9379,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2285 g1452 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9378 in a9372 in a9360 in a9335 in run-safe in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9379,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a9366 in a9360 in a9335 in run-safe in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9367,2,t0,t1);}
/* eval.scm: 2290 thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a9341 in a9335 in run-safe in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9342(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9342,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9348,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2285 g1452 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9347 in a9341 in a9335 in run-safe in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9352,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2286 open-output-string */
t3=*((C_word*)lf[131]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9350 in a9347 in a9341 in a9335 in run-safe in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9355,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2287 print-error-message */
t3=*((C_word*)lf[412]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k9353 in k9350 in a9347 in a9341 in a9335 in run-safe in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9359,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2288 get-output-string */
t3=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9357 in k9353 in k9350 in a9347 in a9341 in a9335 in run-safe in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[410],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k9332 in run-safe in k9321 in k9318 in k9315 in k9312 in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9239,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_make_character(44));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9249,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2217 read-char */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* eval.scm: 2229 old */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k9247 in ##sys#user-read-hook in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2218 read */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9250 in k9247 in ##sys#user-read-hook in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9253,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_nullp(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9266,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_9266(t5,t3);}
else{
t5=(C_word)C_i_listp(t1);
t6=t4;
f_9266(t6,(C_word)C_i_not(t5));}}

/* k9264 in k9250 in k9247 in ##sys#user-read-hook in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_9266(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9266,NULL,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 2221 err */
t2=((C_word*)t0)[5];
f_9253(t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9284,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2225 ##sys#hash-table-ref */
t4=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[403]+1),t2);}
else{
/* eval.scm: 2224 err */
t3=((C_word*)t0)[5];
f_9253(t3,((C_word*)t0)[4]);}}}

/* k9282 in k9264 in k9250 in k9247 in ##sys#user-read-hook in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_apply(4,0,((C_word*)t0)[4],t1,t2);}
else{
/* eval.scm: 2228 ##sys#read-error */
t2=*((C_word*)lf[407]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[409],((C_word*)t0)[2]);}}

/* err in k9250 in k9247 in ##sys#user-read-hook in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_9253(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9253,NULL,2,t0,t1);}
/* eval.scm: 2219 ##sys#read-error */
t2=*((C_word*)lf[407]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[408],((C_word*)t0)[2]);}

/* define-reader-ctor in k9226 in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9230,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[404]);
/* eval.scm: 2209 ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[403]+1),t2,t3);}

/* repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8892,tmp=(C_word)a,a+=2,tmp);
t3=*((C_word*)lf[390]+1);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[383]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[389]+1);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8933,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t8,a[11]=t6,a[12]=t4,tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 2119 ##sys#error-handler */
t10=*((C_word*)lf[394]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}

/* k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8936,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 2120 ##sys#reset-handler */
t3=*((C_word*)lf[402]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8936,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[133]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8938,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8944,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8953,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t6,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9018,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9213,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2134 ##sys#dynamic-wind */
t10=*((C_word*)lf[235]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[2],t7,t8,t9);}

/* a9212 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9217,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2197 load-verbose */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k9215 in a9212 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9217,2,t0,t1);}
t2=C_mutate((C_word*)lf[133]+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2199 ##sys#error-handler */
t4=*((C_word*)lf[394]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9219 in k9215 in a9212 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2200 ##sys#reset-handler */
t2=*((C_word*)lf[402]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9018,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_9024(t5,t1);}

/* loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_9024(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9024,NULL,2,t0,t1);}
t2=f_8938(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9031,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9196,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2157 call-with-current-continuation */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9195 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9196(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9196,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9202,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2159 ##sys#reset-handler */
t4=*((C_word*)lf[402]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9201 in a9195 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9202,2,t0,t1);}
t2=C_set_block_item(lf[227],0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[401],0,C_SCHEME_TRUE);
t4=f_8944(((C_word*)t0)[3]);
/* eval.scm: 2164 c */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,C_SCHEME_FALSE);}

/* k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2165 ##sys#read-prompt-hook */
t3=*((C_word*)lf[381]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9037,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[375]+1);
t4=(C_truep(t3)?t3:((C_word*)t0)[2]);
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9037,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9046,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9191,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2168 ##sys#peek-char-0 */
t4=*((C_word*)lf[400]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[390]+1));}}

/* k9189 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(10),t1);
if(C_truep(t2)){
/* eval.scm: 2169 ##sys#read-char-0 */
t3=*((C_word*)lf[399]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],*((C_word*)lf[390]+1));}
else{
t3=((C_word*)t0)[2];
f_9046(2,t3,C_SCHEME_UNDEFINED);}}

/* k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2170 ##sys#clear-trace-buffer */
t3=*((C_word*)lf[384]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9049,2,t0,t1);}
t2=C_set_block_item(lf[133],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9055,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9064,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2172 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a9063 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9064(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_9064r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9064r(t0,t1,t2);}}

static void C_ccall f_9064r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9068,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(*((C_word*)lf[395]+1))?(C_word)C_i_pairp(*((C_word*)lf[133]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9082,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_9082(t8,t3,*((C_word*)lf[133]+1),C_SCHEME_END_OF_LIST);}
else{
t5=t3;
f_9068(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a9063 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_9082(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9082,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9086,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9098,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2177 ##sys#print */
t6=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[398],C_SCHEME_FALSE,*((C_word*)lf[389]+1));}
else{
t5=t4;
f_9086(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_u_i_caar(t2);
t6=(C_word)C_u_i_memq(t5,t3);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9145,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9145(2,t8,t6);}
else{
t8=(C_word)C_u_i_caar(t2);
/* eval.scm: 2191 ##sys#symbol-has-toplevel-binding? */
t9=*((C_word*)lf[144]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}}

/* k9143 in loop in a9063 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9145,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 2192 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9082(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* eval.scm: 2193 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_9082(t5,((C_word*)t0)[3],t2,t4);}}

/* k9096 in loop in a9063 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9103,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9102 in k9096 in loop in a9063 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9103,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9107,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2182 ##sys#print */
t4=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[397],C_SCHEME_FALSE,*((C_word*)lf[389]+1));}

/* k9105 in a9102 in k9096 in loop in a9063 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* eval.scm: 2183 ##sys#print */
t4=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[389]+1));}

/* k9108 in k9105 in a9102 in k9096 in loop in a9063 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9113,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(1)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9122,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2185 ##sys#print */
t4=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[396],C_SCHEME_FALSE,*((C_word*)lf[389]+1));}
else{
t3=t2;
f_9113(2,t3,C_SCHEME_UNDEFINED);}}

/* k9120 in k9108 in k9105 in a9102 in k9096 in loop in a9063 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9125,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 2186 ##sys#print */
t4=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[389]+1));}

/* k9123 in k9120 in k9108 in k9105 in a9102 in k9096 in loop in a9063 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2187 ##sys#write-char-0 */
t2=*((C_word*)lf[377]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(41),*((C_word*)lf[389]+1));}

/* k9111 in k9108 in k9105 in a9102 in k9096 in loop in a9063 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2188 ##sys#write-char-0 */
t2=*((C_word*)lf[377]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[389]+1));}

/* k9084 in loop in a9063 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(9));}

/* k9066 in a9063 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9071,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_i_nullp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8914,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_8914(t6,t4);}
else{
t6=(C_word)C_u_i_car(t3);
t7=t5;
f_8914(t7,(C_word)C_eqp(C_SCHEME_UNDEFINED,t6));}}

/* k8912 in k9066 in a9063 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8914(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8914,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_9071(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8919,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* a8918 in k8912 in k9066 in a9063 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8919(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8919,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[376]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[383]+1));}

/* k9069 in k9066 in a9063 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2195 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9024(t2,((C_word*)t0)[2]);}

/* a9054 in k9047 in k9044 in k9035 in k9032 in k9029 in loop in a9017 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9055,2,t0,t1);}
t2=*((C_word*)lf[373]+1);
t3=(C_truep(t2)?t2:((C_word*)t0)[3]);
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,((C_word*)t0)[2]);}

/* a8952 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8958,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 2136 load-verbose */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8956 in a8952 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8958,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8961,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2137 load-verbose */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}

/* k8959 in k8956 in a8952 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8966,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2138 ##sys#error-handler */
t3=*((C_word*)lf[394]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* a8965 in k8959 in k8956 in a8952 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8966(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_8966r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8966r(t0,t1,t2,t3);}}

static void C_ccall f_8966r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=f_8944(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8973,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 2141 ##sys#print */
t6=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[393],C_SCHEME_FALSE,*((C_word*)lf[389]+1));}

/* k8971 in a8965 in k8959 in k8956 in a8952 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8976,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9013,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2143 ##sys#print */
t4=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[392],C_SCHEME_FALSE,*((C_word*)lf[389]+1));}
else{
t3=t2;
f_8976(2,t3,C_SCHEME_UNDEFINED);}}

/* k9011 in k8971 in a8965 in k8959 in k8956 in a8952 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_9013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2144 ##sys#print */
t2=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[389]+1));}

/* k8974 in k8971 in a8965 in k8959 in k8956 in a8952 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8979,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8988,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=t3;
f_8988(t5,(C_word)C_i_nullp(t4));}
else{
t4=t3;
f_8988(t4,C_SCHEME_FALSE);}}

/* k8986 in k8974 in k8971 in a8965 in k8959 in k8956 in a8952 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8988(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8988,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2147 ##sys#print */
t3=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[391],C_SCHEME_FALSE,*((C_word*)lf[389]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2150 ##sys#write-char-0 */
t3=*((C_word*)lf[377]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),*((C_word*)lf[389]+1));}}

/* k8995 in k8986 in k8974 in k8971 in a8965 in k8959 in k8956 in a8952 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2151 write-err */
f_8892(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8989 in k8986 in k8974 in k8971 in a8965 in k8959 in k8956 in a8952 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2148 write-err */
f_8892(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8977 in k8974 in k8971 in a8965 in k8959 in k8956 in a8952 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2152 print-call-chain */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[389]+1));}

/* k8980 in k8977 in k8974 in k8971 in a8965 in k8959 in k8956 in a8952 in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2153 flush-output */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[389]+1));}

/* resetports in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static C_word C_fcall f_8944(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate((C_word*)lf[390]+1,((C_word*)((C_word*)t0)[4])[1]);
t2=C_mutate((C_word*)lf[383]+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate((C_word*)lf[389]+1,((C_word*)((C_word*)t0)[2])[1]);
return(t3);}

/* saveports in k8934 in k8931 in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static C_word C_fcall f_8938(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[390]+1));
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[383]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[389]+1));
return(t3);}

/* write-err in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8892(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8892,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8898,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a8897 in write-err in repl in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8898(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8898,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[376]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[389]+1));}

/* ##sys#clear-trace-buffer in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8886,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1336(C_SCHEME_UNDEFINED));}

/* ##sys#read-prompt-hook in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8874,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8881,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8884,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2094 repl-prompt */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k8882 in ##sys#read-prompt-hook in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k8879 in ##sys#read-prompt-hook in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2094 ##sys#print */
t2=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,*((C_word*)lf[383]+1));}

/* k8872 in ##sys#read-prompt-hook in k8866 in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2095 ##sys#flush-output */
t2=*((C_word*)lf[382]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[383]+1));}

/* ##sys#repl-print-hook in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8851(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8851,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8855,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8860,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2086 ##sys#with-print-length-limit */
t6=*((C_word*)lf[379]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[374]+1),t5);}

/* a8859 in ##sys#repl-print-hook in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8860,2,t0,t1);}
/* ##sys#print */
t2=*((C_word*)lf[378]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* k8853 in ##sys#repl-print-hook in k8844 in k8840 in k8837 in k8834 in k8831 in k8828 in k8825 in k8822 in k8819 in k8816 in k8813 in k8810 in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2087 ##sys#write-char-0 */
t2=*((C_word*)lf[377]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5rv,(void*)f_8420r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_8420r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_8420r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8435,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8423,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8466,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8528,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8557,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t8,a[6]=t9,a[7]=t7,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_notvemptyp(t5))){
t11=(C_word)C_slot(t5,C_fix(0));
t12=C_mutate((C_word*)lf[207]+1,t11);
t13=t10;
f_8557(t13,t12);}
else{
t11=t10;
f_8557(t11,C_SCHEME_UNDEFINED);}}

/* k8555 in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8557(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8557,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8562,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t3,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_8562(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k8555 in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8562(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word *a;
loop:
a=C_alloc(19);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8562,NULL,4,t0,t1,t2,t3);}
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_vectorp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_block_size(t3);
t7=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t8=(C_truep(t7)?(C_word)C_slot(t3,C_fix(1)):C_fix(0));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8578,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_eqp(t6,C_fix(1));
if(C_truep(t10)){
t11=t9;
f_8578(t11,C_fix(1));}
else{
t11=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t12=t9;
f_8578(t12,(C_truep(t11)?(C_word)C_slot(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_blockp(t3))){
if(C_truep((C_word)C_symbolp(t3))){
t5=t3;
t6=(C_word)C_eqp(t5,lf[351]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_eqp(t5,lf[352]);
if(C_truep(t7)){
/* eval.scm: 1798 test */
t8=((C_word*)t0)[4];
f_8423(t8,t1,t2,*((C_word*)lf[353]+1),lf[354]);}
else{
t8=(C_word)C_eqp(t5,lf[355]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8707,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1799 test */
t10=((C_word*)t0)[4];
f_8423(t10,t1,t2,t9,lf[356]);}
else{
t9=(C_word)C_eqp(t5,lf[357]);
if(C_truep(t9)){
/* eval.scm: 1800 test */
t10=((C_word*)t0)[4];
f_8423(t10,t1,t2,*((C_word*)lf[358]+1),lf[359]);}
else{
t10=(C_word)C_eqp(t5,lf[360]);
if(C_truep(t10)){
/* eval.scm: 1801 test */
t11=((C_word*)t0)[4];
f_8423(t11,t1,t2,((C_word*)t0)[3],lf[361]);}
else{
t11=(C_word)C_eqp(t5,lf[362]);
if(C_truep(t11)){
/* eval.scm: 1802 test */
t12=((C_word*)t0)[4];
f_8423(t12,t1,t2,*((C_word*)lf[363]+1),lf[364]);}
else{
t12=(C_word)C_eqp(t5,lf[365]);
if(C_truep(t12)){
/* eval.scm: 1803 test */
t13=((C_word*)t0)[4];
f_8423(t13,t1,t2,*((C_word*)lf[366]+1),lf[367]);}
else{
t13=(C_word)C_eqp(t5,lf[368]);
if(C_truep(t13)){
/* eval.scm: 1804 test */
t14=((C_word*)t0)[4];
f_8423(t14,t1,t2,((C_word*)t0)[2],lf[369]);}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8761,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1805 test */
t15=((C_word*)t0)[4];
f_8423(t15,t1,t2,t14,lf[370]);}}}}}}}}}
else{
t5=(C_word)C_i_not((C_word)C_blockp(t2));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t6)){
/* eval.scm: 1807 err */
t7=((C_word*)t0)[6];
f_8435(t7,t1,lf[371]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8780,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 1809 walk */
t30=t7;
t31=t8;
t32=t9;
t1=t30;
t2=t31;
t3=t32;
goto loop;}}}
else{
t5=(C_word)C_eqp(t3,t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1794 err */
t6=((C_word*)t0)[6];
f_8435(t6,t1,lf[372]);}}}}

/* k8778 in walk in k8555 in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1810 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8562(t4,((C_word*)t0)[2],t2,t3);}

/* a8760 in walk in k8555 in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8761(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8761,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* a8706 in walk in k8555 in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8707(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8707,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_symbolp(t2));}

/* k8576 in walk in k8555 in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8578,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8583,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_8583(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* do1189 in k8576 in walk in k8555 in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8583(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8583,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
/* eval.scm: 1787 err */
t5=((C_word*)t0)[6];
f_8435(t5,t1,lf[348]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8602,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
/* eval.scm: 1789 err */
t6=((C_word*)t0)[6];
f_8435(t6,t5,lf[349]);}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* eval.scm: 1791 err */
t8=((C_word*)t0)[6];
f_8435(t8,t5,lf[350]);}
else{
t8=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1792 walk */
t9=((C_word*)((C_word*)t0)[3])[1];
f_8562(t9,t5,t8,((C_word*)t0)[2]);}}}}

/* k8600 in do1189 in k8576 in walk in k8555 in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8583(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8528(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8528,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8534,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_8534(t2));}

/* loop in proper-list? in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static C_word C_fcall f_8534(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_pairp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8466(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8466,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8470,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1754 ##sys#extended-lambda-list? */
t4=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8468 in lambda-list? in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8470,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8478,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_8478(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k8468 in lambda-list? in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8478(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8478,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8501,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1758 keyword? */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_not((C_word)C_blockp(t4));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_symbolp(t4)));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1763 loop */
t10=t1;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k8499 in loop in k8468 in lambda-list? in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8423(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8423,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8430,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1742 pred */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k8428 in test in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1742 err */
t2=((C_word*)t0)[3];
f_8435(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8435(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8435,NULL,3,t0,t1,t2);}
t3=*((C_word*)lf[207]+1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8439,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1746 get-line-number */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k8437 in err in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8446,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8453,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1749 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8464,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1750 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k8462 in k8437 in err in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1750 string-append */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[346],t1,lf[347],((C_word*)t0)[2]);}

/* k8451 in k8437 in err in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8457,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1749 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k8455 in k8451 in k8437 in err in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1749 string-append */
t2=((C_word*)t0)[5];
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[4],lf[343],((C_word*)t0)[3],lf[344],t1,lf[345],((C_word*)t0)[2]);}

/* k8444 in k8437 in err in ##sys#check-syntax in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1747 ##sys#syntax-error-hook */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8384,3,t0,t1,t2);}
if(C_truep(*((C_word*)lf[337]+1))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8406,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1728 ##sys#hash-table-ref */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[337]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k8404 in get-line-number in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-error-hook in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8376(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_8376r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8376r(t0,t1,t2);}}

static void C_ccall f_8376r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[220]+1),lf[338],t2);}

/* ##sys#display-times in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8322(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8322,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8326,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1703 display-rj */
t5=((C_word*)t0)[2];
f_8301(t5,t3,t4,C_fix(8));}

/* k8324 in ##sys#display-times in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1704 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[336]);}

/* k8327 in k8324 in ##sys#display-times in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1705 display-rj */
t4=((C_word*)t0)[2];
f_8301(t4,t2,t3,C_fix(8));}

/* k8330 in k8327 in k8324 in ##sys#display-times in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1706 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[335]);}

/* k8333 in k8330 in k8327 in k8324 in ##sys#display-times in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
/* eval.scm: 1707 display-rj */
t4=((C_word*)t0)[2];
f_8301(t4,t2,t3,C_fix(8));}

/* k8336 in k8333 in k8330 in k8327 in k8324 in ##sys#display-times in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1708 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[334]);}

/* k8339 in k8336 in k8333 in k8330 in k8327 in k8324 in ##sys#display-times in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
/* eval.scm: 1709 display-rj */
t4=((C_word*)t0)[2];
f_8301(t4,t2,t3,C_fix(8));}

/* k8342 in k8339 in k8336 in k8333 in k8330 in k8327 in k8324 in ##sys#display-times in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1710 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[333]);}

/* k8345 in k8342 in k8339 in k8336 in k8333 in k8330 in k8327 in k8324 in ##sys#display-times in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8350,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* eval.scm: 1711 display-rj */
t4=((C_word*)t0)[2];
f_8301(t4,t2,t3,C_fix(8));}

/* k8348 in k8345 in k8342 in k8339 in k8336 in k8333 in k8330 in k8327 in k8324 in ##sys#display-times in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1712 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[332]);}

/* display-rj in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8301(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8301,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8305,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_zerop(t2))){
t5=t4;
f_8305(2,t5,lf[331]);}
else{
/* eval.scm: 1698 number->string */
C_number_to_string(3,0,t4,t2);}}

/* k8303 in display-rj in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8305,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8308,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],t2);
/* eval.scm: 1700 spaces */
t5=((C_word*)t0)[2];
f_8277(t5,t3,t4);}

/* k8306 in k8303 in display-rj in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1701 display */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* spaces in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8277(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8277,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8283,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_8283(t6,t1,t2);}

/* do1119 in spaces in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8283(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8283,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8293,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1695 display */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k8291 in do1119 in spaces in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8283(t3,((C_word*)t0)[2],t2);}

/* ##sys#resolve-include-filename in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4rv,(void*)f_8154r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_8154r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8154r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t4,C_fix(0)));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8160,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8195,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8212,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1676 test */
t12=t10;
f_8195(t12,t11,t2);}

/* k8210 in ##sys#resolve-include-filename in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8212,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8222,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8263,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1678 ##sys#repository-path */
t4=*((C_word*)lf[276]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_8222(2,t3,*((C_word*)lf[281]+1));}}}

/* k8261 in k8210 in ##sys#resolve-include-filename in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8263,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 1678 ##sys#append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],*((C_word*)lf[281]+1),t2);}

/* k8220 in k8210 in ##sys#resolve-include-filename in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8222,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8224,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_8224(t5,((C_word*)t0)[2],t1);}

/* loop in k8220 in k8210 in ##sys#resolve-include-filename in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8224(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8224,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8234,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8248,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1681 string-append */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,lf[330],((C_word*)t0)[5]);}}

/* k8246 in loop in k8220 in k8210 in ##sys#resolve-include-filename in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1681 test */
t2=((C_word*)t0)[3];
f_8195(t2,((C_word*)t0)[2],t1);}

/* k8232 in loop in k8220 in k8210 in ##sys#resolve-include-filename in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1684 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8224(t3,((C_word*)t0)[4],t2);}}

/* test in ##sys#resolve-include-filename in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8195(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8195,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_list(&a,2,lf[17],*((C_word*)lf[246]+1)):(C_word)C_a_i_list(&a,2,*((C_word*)lf[246]+1),lf[17]));
/* eval.scm: 1671 test2 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8160(t4,t1,t2,t3);}

/* test2 in ##sys#resolve-include-filename in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8160(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8160,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8173,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1665 exists? */
f_8135(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8176,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_i_car(t3);
/* eval.scm: 1666 ##sys#string-append */
t6=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}}

/* k8174 in test2 in ##sys#resolve-include-filename in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8182,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1667 exists? */
f_8135(t2,t1);}

/* k8180 in k8174 in test2 in ##sys#resolve-include-filename in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1669 test2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8160(t3,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k8171 in test2 in ##sys#resolve-include-filename in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* exists? in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8135(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8135,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8139,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1660 ##sys#file-info */
t4=*((C_word*)lf[245]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8137 in exists? in k8127 in k8123 in k8120 in k8116 in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=(C_word)C_eqp(C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* initb in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_8102(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8102,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8104,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_8104 in initb in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8104,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8108,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1621 ##sys#hash-table-location */
t4=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k8106 */
static void C_ccall f_8108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t1,C_fix(1),t2));}

/* null-environment in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8064(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8064r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8064r(t0,t1,t2,t3);}}

static void C_ccall f_8064r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[328]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8071,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t2,C_fix(4));
t7=(C_truep(t6)?t6:(C_word)C_fixnum_greaterp(t2,C_fix(5)));
if(C_truep(t7)){
/* eval.scm: 1612 ##sys#error */
t8=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[328],lf[329],t2);}
else{
t8=t5;
f_8071(2,t8,C_SCHEME_UNDEFINED);}}

/* k8069 in null-environment in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8078,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1615 make-vector */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8076 in k8069 in null-environment in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8078,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(0)):C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,3,lf[319],t1,t3));}

/* scheme-report-environment in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8020(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8020r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8020r(t0,t1,t2,t3);}}

static void C_ccall f_8020r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_exact_2(t2,lf[325]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=t2;
switch(t7){
case C_fix(4):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8040,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1603 ##sys#copy-env-table */
t9=*((C_word*)lf[321]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[317],C_SCHEME_TRUE,t6);
case C_fix(5):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8053,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1604 ##sys#copy-env-table */
t9=*((C_word*)lf[321]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[318],C_SCHEME_TRUE,t6);
default:
/* eval.scm: 1605 ##sys#error */
t8=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[325],lf[326],t2);}}

/* k8051 in scheme-report-environment in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8053,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[319],t1,((C_word*)t0)[2]));}

/* k8038 in scheme-report-environment in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8040,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[319],t1,((C_word*)t0)[2]));}

/* interaction-environment in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8017,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[320]);}

/* ##sys#environment-symbols in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7898(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7898r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7898r(t0,t1,t2,t3);}}

static void C_ccall f_7898r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(18);
t4=(C_word)C_i_check_structure(t2,lf[319]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep(t7)){
t8=(C_word)C_fix((C_word)C_header_size(t7));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7919,a[2]=t6,a[3]=t7,a[4]=t10,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_7919(t12,t1,C_fix(0),C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7990,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7992,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1590 ##sys#walk-namespace */
t12=*((C_word*)lf[323]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}

/* a7991 in ##sys#environment-symbols in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7992,3,t0,t1,t2);}
t3=(C_word)C_i_not(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8002,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_8002(2,t5,t3);}
else{
/* eval.scm: 1592 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k8000 in a7991 in ##sys#environment-symbols in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_8002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8002,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7988 in ##sys#environment-symbols in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* do1050 in ##sys#environment-symbols in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7919(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7919,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7937,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_slot(((C_word*)t0)[3],t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7943,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_7943(t10,t5,t6,t3);}}

/* loop in do1050 in ##sys#environment-symbols in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7943(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7943,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_i_not(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7962,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_7962(2,t8,t6);}
else{
/* eval.scm: 1584 pred */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t5);}}}

/* k7960 in loop in do1050 in ##sys#environment-symbols in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7962,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* eval.scm: 1585 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7943(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1586 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7943(t3,((C_word*)t0)[2],t2,((C_word*)t0)[4]);}}

/* k7935 in do1050 in ##sys#environment-symbols in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_7919(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#copy-env-table in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5rv,(void*)f_7790r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_7790r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_7790r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7800,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t2,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1551 ##sys#make-vector */
t10=*((C_word*)lf[157]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t8,C_SCHEME_END_OF_LIST);}

/* k7798 in ##sys#copy-env-table in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7800,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_7805(t5,((C_word*)t0)[2],C_fix(0));}

/* do1033 in k7798 in ##sys#copy-env-table in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7805(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7805,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[7]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7826,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7832,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_7832(t8,t3,t4);}}

/* copy in do1033 in k7798 in ##sys#copy-env-table in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7832(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7832,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_i_not(((C_word*)t0)[5]);
t6=(C_truep(t5)?t5:(C_word)C_u_i_memq(t4,((C_word*)t0)[5]));
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:(C_word)C_slot(t3,C_fix(2)));
t9=(C_word)C_a_i_vector(&a,3,t4,t7,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7865,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1566 copy */
t14=t10;
t15=t11;
t1=t14;
t2=t15;
goto loop;}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1567 copy */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k7863 in copy in do1033 in k7798 in ##sys#copy-env-table in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7865,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7824 in do1033 in k7798 in ##sys#copy-env-table in k7781 in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7805(t4,((C_word*)t0)[2],t3);}

/* ##sys#string->c-identifier in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7727,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7731,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1532 string-copy */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k7729 in ##sys#string->c-identifier in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7731,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7739,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7739(t6,((C_word*)t0)[2],C_fix(0));}

/* do1018 in k7729 in ##sys#string->c-identifier in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7739(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7739,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7759,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_alphabeticp(t3))){
t5=t4;
f_7759(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_u_i_char_numericp(t3);
t6=(C_word)C_i_not(t5);
t7=t4;
f_7759(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,C_fix(0))));}}}

/* k7757 in do1018 in k7729 in ##sys#string->c-identifier in k7723 in k7720 in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7759(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],C_make_character(95)):C_SCHEME_UNDEFINED);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7739(t4,((C_word*)t0)[2],t3);}

/* set-extension-specifier! in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7683,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[315]);
t5=(C_word)C_u_i_assq(t2,*((C_word*)lf[312]+1));
if(C_truep(t5)){
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7701,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t5,C_fix(1),t7));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7715,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,*((C_word*)lf[312]+1));
t9=C_mutate((C_word*)lf[312]+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* a7714 in set-extension-specifier! in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7715(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7715,3,t0,t1,t2);}
/* eval.scm: 1487 proc */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* a7700 in set-extension-specifier! in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7701(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7701,3,t0,t1,t2);}
/* eval.scm: 1485 proc */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7284,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7287,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7308,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7559,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_u_i_car(t2);
t8=t6;
f_7559(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_7559(t7,C_SCHEME_FALSE);}}

/* k7557 in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7559(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7559,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_u_i_assq(t2,*((C_word*)lf[312]+1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7568,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[6]);}
else{
/* eval.scm: 1473 ##sys#error */
t4=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],lf[313],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
/* eval.scm: 1475 doit */
t2=((C_word*)t0)[2];
f_7308(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
/* eval.scm: 1476 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[314],((C_word*)t0)[6]);}}}

/* k7566 in k7557 in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7568,2,t0,t1);}
if(C_truep((C_word)C_i_stringp(t1))){
t2=(C_word)C_a_i_list(&a,2,lf[232],t1);
/* eval.scm: 1461 values */
C_values(4,0,((C_word*)t0)[4],t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7594,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1463 vector->list */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
/* eval.scm: 1472 ##sys#do-the-right-thing */
t2=*((C_word*)lf[171]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3]);}}}

/* k7592 in k7566 in k7557 in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7594,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7596,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7596(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k7592 in k7566 in k7557 in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7596(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7596,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7614,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1467 reverse */
t6=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7619,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7629,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1468 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a7628 in loop in k7592 in k7566 in k7557 in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7629,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t6=(C_truep(t3)?t3:((C_word*)t0)[3]);
/* eval.scm: 1469 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7596(t7,t1,t4,t5,t6);}

/* a7618 in loop in k7592 in k7566 in k7557 in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7619,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* eval.scm: 1468 ##sys#do-the-right-thing */
t3=*((C_word*)lf[171]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k7612 in loop in k7592 in k7566 in k7557 in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7614,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* eval.scm: 1467 values */
C_values(4,0,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7308(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7308,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_memq(t2,lf[26]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_7318(2,t5,t3);}
else{
if(C_truep(((C_word*)t0)[3])){
t5=t4;
f_7318(2,t5,(C_word)C_u_i_memq(t2,lf[28]));}
else{
/* eval.scm: 1414 ##sys#feature? */
t5=*((C_word*)lf[311]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}}

/* k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[47],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7318,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1415 values */
C_values(4,0,((C_word*)t0)[5],lf[303],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[304]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[305]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7330,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1417 ##sys#->feature-id */
t4=*((C_word*)lf[266]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[2]+1)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7367,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_list(&a,2,lf[308],((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,lf[90],t4);
t6=t3;
f_7367(t6,(C_word)C_a_i_list(&a,2,lf[179],t5));}
else{
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[4]);
t5=t3;
f_7367(t5,(C_word)C_a_i_list(&a,2,lf[267],t4));}}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[4]+1)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7394,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1429 ##sys#extension-information */
t4=*((C_word*)lf[292]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[310]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1439 ##sys#extension-information */
t4=*((C_word*)lf[292]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[310]);}}}}}

/* k7450 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7452,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[309],t1);
t3=(C_word)C_u_i_assq(lf[296],t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7464,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
/* eval.scm: 1443 add-req */
t5=((C_word*)t0)[2];
f_7287(t5,t4,((C_word*)t0)[3]);}
else{
t5=t4;
f_7464(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7533,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1455 add-req */
t3=((C_word*)t0)[2];
f_7287(t3,t2,((C_word*)t0)[3]);}}

/* k7531 in k7450 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7533,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[167],t2);
/* eval.scm: 1456 values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_FALSE);}

/* k7462 in k7450 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7475,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,lf[165],t4);
t6=t3;
f_7479(t6,(C_word)C_a_i_list(&a,1,t5));}
else{
t4=t3;
f_7479(t4,C_SCHEME_END_OF_LIST);}}

/* k7477 in k7462 in k7450 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7479(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7479,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7483,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[4])?C_SCHEME_FALSE:((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_7483(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7497,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7499,tmp=(C_word)a,a+=2,tmp);
t6=(C_truep(((C_word*)t0)[4])?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* map */
t7=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a7498 in k7477 in k7462 in k7450 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7499(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7499,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[90],t2));}

/* k7495 in k7477 in k7462 in k7450 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7497,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[167],t1);
t3=((C_word*)t0)[2];
f_7483(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k7481 in k7477 in k7462 in k7450 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7483(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1400 ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7473 in k7462 in k7450 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7475,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* eval.scm: 1444 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k7392 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7394,2,t0,t1);}
t2=(C_word)C_u_i_assq(lf[309],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7408,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t5=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,lf[165],t5);
t7=t4;
f_7412(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t4;
f_7412(t5,C_SCHEME_END_OF_LIST);}}

/* k7410 in k7392 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7412(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7412,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7420,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_list(&a,2,lf[308],((C_word*)t0)[2]);
t4=(C_word)C_a_i_list(&a,2,lf[90],t3);
t5=t2;
f_7420(t5,(C_word)C_a_i_list(&a,2,lf[179],t4));}
else{
t3=(C_word)C_a_i_list(&a,2,lf[90],((C_word*)t0)[2]);
t4=t2;
f_7420(t4,(C_word)C_a_i_list(&a,2,lf[267],t3));}}

/* k7418 in k7410 in k7392 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7420,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 1400 ##sys#append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7406 in k7392 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7408,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[106],t1);
/* eval.scm: 1431 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k7365 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7367(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1423 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7328 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7333,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(t1,*((C_word*)lf[182]+1)))){
t3=t2;
f_7333(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7342,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7350,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7354,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1419 ##sys#symbol->string */
t6=*((C_word*)lf[272]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k7352 in k7328 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1419 ##sys#resolve-include-filename */
t2=*((C_word*)lf[307]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7348 in k7328 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1419 ##sys#load */
t2=*((C_word*)lf[226]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k7340 in k7328 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7342,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[182]+1));
t3=C_mutate((C_word*)lf[182]+1,t2);
t4=((C_word*)t0)[2];
f_7333(t4,t3);}

/* k7331 in k7328 in k7316 in doit in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7333(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1421 values */
C_values(4,0,((C_word*)t0)[2],lf[306],C_SCHEME_TRUE);}

/* add-req in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7287(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7287,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7296,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7302,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1405 hash-table-update! */
t5=*((C_word*)lf[300]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,*((C_word*)lf[301]+1),lf[302],t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a7301 in add-req in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7302,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* a7295 in add-req in ##sys#do-the-right-thing in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7296(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7296,3,t0,t1,t2);}
/* lset-adjoin */
t3=*((C_word*)lf[298]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[299]+1),t2,((C_word*)t0)[2]);}

/* ##sys#lookup-runtime-requirements in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7235(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7235,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7241,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7241(t6,t1,t2);}

/* loop1 in ##sys#lookup-runtime-requirements in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7241(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7241,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7255,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 1394 ##sys#extension-information */
t5=*((C_word*)lf[292]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_FALSE);}}

/* k7253 in loop1 in ##sys#lookup-runtime-requirements in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_assq(lf[296],t1);
t4=t2;
f_7258(t4,(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE));}
else{
t3=t2;
f_7258(t3,C_SCHEME_FALSE);}}

/* k7256 in k7253 in loop1 in ##sys#lookup-runtime-requirements in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7258(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7258,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7265,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1398 loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7241(t5,t3,t4);}

/* k7263 in k7256 in k7253 in loop1 in ##sys#lookup-runtime-requirements in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1393 append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extension-information in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7229,3,t0,t1,t2);}
/* eval.scm: 1384 ##sys#extension-information */
t3=*((C_word*)lf[292]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[295]);}

/* ##sys#extension-information in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7198,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1377 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[270]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k7200 in ##sys#extension-information in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7227,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1378 ##sys#repository-path */
t4=*((C_word*)lf[276]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7225 in k7200 in ##sys#extension-information in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1378 string-append */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],t1,lf[293],((C_word*)t0)[2],lf[294]);}

/* k7203 in k7200 in ##sys#extension-information in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7208,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7223,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1379 string-append */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[20]);}

/* k7221 in k7203 in k7200 in ##sys#extension-information in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1379 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7206 in k7203 in k7200 in ##sys#extension-information in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7208,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7215,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7215 in k7206 in k7203 in k7200 in ##sys#extension-information in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7215,3,t0,t1,t2);}
/* with-input-from-file923 */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#require in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7185(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7185r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7185r(t0,t1,t2);}}

static void C_ccall f_7185r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7191,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7190 in ##sys#require in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7191(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7191,3,t0,t1,t2);}
/* ##sys#load-extension */
t3=*((C_word*)lf[285]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[291]);}

/* ##sys#provided? in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7171(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7171,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7182,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1358 ##sys#canonicalize-extension-path */
t4=*((C_word*)lf[270]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[290]);}

/* k7180 in ##sys#provided? in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_member(t1,*((C_word*)lf[283]+1));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#provide in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7151(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7151r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7151r(t0,t1,t2);}}

static void C_ccall f_7151r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7157,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7156 in ##sys#provide in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7157,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[288]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7164,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1351 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[270]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[288]);}

/* k7162 in a7156 in ##sys#provide in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7164,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,*((C_word*)lf[283]+1));
t3=C_mutate((C_word*)lf[283]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#load-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_7083r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7083r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7083r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7087,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t5)[1]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7146,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1332 string->symbol */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t5)[1]);}
else{
t7=t6;
f_7087(t7,(C_word)C_i_check_symbol_2(((C_word*)t5)[1],t3));}}

/* k7144 in ##sys#load-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7087(t3,t2);}

/* k7085 in ##sys#load-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7087(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7087,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7090,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1334 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[270]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}

/* k7088 in k7085 in ##sys#load-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7090,2,t0,t1);}
t2=(C_word)C_i_member(t1,*((C_word*)lf[283]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[2]+1)))){
/* eval.scm: 1337 ##sys#load-library */
t3=*((C_word*)lf[260]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7108,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1339 ##sys#find-extension */
t4=*((C_word*)lf[279]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_TRUE);}}}

/* k7106 in k7088 in k7085 in ##sys#load-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7108,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7114,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1341 ##sys#load */
t3=*((C_word*)lf[226]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[4];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_u_i_car(t2));
if(C_truep(t4)){
/* eval.scm: 1344 ##sys#error */
t5=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[3],lf[286],((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}

/* k7112 in k7106 in k7088 in k7085 in ##sys#load-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7114,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[283]+1));
t3=C_mutate((C_word*)lf[283]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}

/* ##sys#find-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7006,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7009,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7040,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7080,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1320 ##sys#repository-path */
t7=*((C_word*)lf[276]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k7078 in ##sys#find-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7080,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7073,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1321 ##sys#append */
t4=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[281]+1),lf[282]);}
else{
t4=t3;
f_7073(2,t4,C_SCHEME_END_OF_LIST);}}

/* k7071 in k7078 in ##sys#find-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1320 ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7038 in ##sys#find-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7040,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7042,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7042(t5,((C_word*)t0)[2],t1);}

/* loop in k7038 in ##sys#find-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7042(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7042,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7055,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1324 check */
t5=((C_word*)t0)[2];
f_7009(t5,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7053 in loop in k7038 in ##sys#find-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1325 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7042(t3,((C_word*)t0)[4],t2);}}

/* check in ##sys#find-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_7009(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7009,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7013,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1316 string-append */
t4=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[280],((C_word*)t0)[2]);}

/* k7011 in check in ##sys#find-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7019,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7033,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1317 ##sys#string-append */
t4=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,*((C_word*)lf[246]+1));}

/* k7031 in k7011 in check in ##sys#find-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1317 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7017 in k7011 in check in ##sys#find-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7022(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7029,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1318 ##sys#string-append */
t4=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[17]);}}

/* k7027 in k7017 in k7011 in check in ##sys#find-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1318 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7020 in k7017 in k7011 in check in ##sys#find-extension in k7001 in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##sys#canonicalize-extension-path in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6843,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6846,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6852,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6865,a[2]=t1,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t7=t6;
f_6865(2,t7,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 1281 ##sys#symbol->string */
t7=*((C_word*)lf[272]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6948,a[2]=t4,a[3]=t8,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_6948(t10,t6,t2);}
else{
t7=t6;
f_6865(2,t7,C_SCHEME_UNDEFINED);}}}}

/* loop in ##sys#canonicalize-extension-path in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_6948(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6948,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[273]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6965,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
/* eval.scm: 1288 ##sys#symbol->string */
t5=*((C_word*)lf[272]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_stringp(t3))){
t5=t4;
f_6965(2,t5,t3);}
else{
/* eval.scm: 1290 err */
t5=((C_word*)t0)[2];
f_6846(t5,t4);}}}}

/* k6963 in loop in ##sys#canonicalize-extension-path in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6965,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?lf[274]:lf[275]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6973,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1294 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6948(t7,t5,t6);}

/* k6971 in k6963 in loop in ##sys#canonicalize-extension-path in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1286 string-append */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6863 in ##sys#canonicalize-extension-path in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6865,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6870,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6870(t5,((C_word*)t0)[2],t1);}

/* check in k6863 in ##sys#canonicalize-extension-path in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_6870(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6870,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
/* eval.scm: 1297 err */
t5=((C_word*)t0)[4];
f_6846(t5,t1);}
else{
t5=(C_word)C_subchar(t2,C_fix(0));
t6=f_6852(t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6896,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1299 ##sys#substring */
t8=*((C_word*)lf[236]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(1),t3);}
else{
t7=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t8=(C_word)C_subchar(t2,t7);
t9=f_6852(t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6909,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1301 ##sys#substring */
t12=*((C_word*)lf[236]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t10,t2,C_fix(0),t11);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t2);}}}}

/* k6907 in check in k6863 in ##sys#canonicalize-extension-path in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1301 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6870(t2,((C_word*)t0)[2],t1);}

/* k6894 in check in k6863 in ##sys#canonicalize-extension-path in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1299 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6870(t2,((C_word*)t0)[2],t1);}

/* sep? in ##sys#canonicalize-extension-path in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static C_word C_fcall f_6852(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_eqp(C_make_character(92),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(47),t1)));}

/* err in ##sys#canonicalize-extension-path in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_6846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6846,NULL,2,t0,t1);}
/* eval.scm: 1278 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[271],((C_word*)t0)[2]);}

/* ##sys#split-at-separator in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6787,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6796,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_6796(t8,t1,C_SCHEME_END_OF_LIST,C_fix(0),C_fix(0));}

/* loop in ##sys#split-at-separator in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_6796(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6796,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6814,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1266 ##sys#substring */
t6=*((C_word*)lf[236]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[4],t4,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[4],t3),((C_word*)t0)[3]);
if(C_truep(t5)){
t6=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6834,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1269 ##sys#substring */
t8=*((C_word*)lf[236]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[4],t4,t3);}
else{
t6=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 1270 loop */
t11=t1;
t12=t2;
t13=t6;
t14=t4;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}}

/* k6832 in loop in ##sys#split-at-separator in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6834,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* eval.scm: 1269 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6796(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2],((C_word*)t0)[2]);}

/* k6812 in loop in ##sys#split-at-separator in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6814,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* eval.scm: 1266 reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6758(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6758r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6758r(t0,t1,t2,t3);}}

static void C_ccall f_6758r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_symbol_2(t2,lf[267]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6765,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
/* eval.scm: 1257 ##sys#load-library */
t8=*((C_word*)lf[260]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t2,t7);}

/* k6763 in load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6765,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}}

/* k6773 in k6763 in load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1258 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[267],lf[268],((C_word*)t0)[2],t1);}

/* ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6652,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6656,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1230 ##sys#->feature-id */
t5=*((C_word*)lf[266]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6654 in ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6656,2,t0,t1);}
t2=(C_word)C_u_i_memq(t1,*((C_word*)lf[182]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6665,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_6665(t4,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6748,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1235 ##sys#string-append */
t6=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[256]+1));}}}

/* k6746 in k6654 in ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6752,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1236 dynamic-load-libraries */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6750 in k6746 in k6654 in ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6752,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6665(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6663 in k6654 in ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_6665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6665,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6668,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6730,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6734,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1241 ##sys#string->c-identifier */
t6=*((C_word*)lf[265]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k6732 in k6663 in k6654 in ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1239 string-append */
t2=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[263],t1,lf[264]);}

/* k6728 in k6663 in k6654 in ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1238 ##sys#make-c-string */
t2=*((C_word*)lf[239]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6666 in k6663 in k6654 in ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6671,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6717,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1243 load-verbose */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6715 in k6666 in k6663 in k6654 in ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6717,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1244 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[262]);}
else{
t2=((C_word*)t0)[3];
f_6671(2,t2,C_SCHEME_UNDEFINED);}}

/* k6718 in k6715 in k6666 in k6663 in k6654 in ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6723,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1245 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6721 in k6718 in k6715 in k6666 in k6663 in k6654 in ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1246 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[261]);}

/* k6669 in k6666 in k6663 in k6654 in ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6671,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6676,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6676(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6669 in k6666 in k6663 in k6654 in ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_6676(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6676,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6689,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6710,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1249 ##sys#make-c-string */
t6=*((C_word*)lf[239]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k6708 in loop in k6669 in k6666 in k6663 in k6654 in ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1249 ##sys#dload */
t2=*((C_word*)lf[238]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k6687 in loop in k6669 in k6666 in k6663 in k6654 in ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6689,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6692,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[182]+1)))){
t3=t2;
f_6692(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],*((C_word*)lf[182]+1));
t4=C_mutate((C_word*)lf[182]+1,t3);
t5=t2;
f_6692(t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1252 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6676(t3,((C_word*)t0)[5],t2);}}

/* k6690 in k6687 in loop in k6669 in k6666 in k6663 in k6654 in ##sys#load-library in k6648 in k6641 in k6636 in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_6692(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* load-noisily in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6612(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6612r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6612r(t0,t1,t2,t3);}}

static void C_ccall f_6612r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6616,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6633,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t6=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[255],t3,t5);}

/* a6632 in load-noisily in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6633,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6614 in load-noisily in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6619,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6630,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[254],((C_word*)t0)[2],t3);}

/* a6629 in k6614 in load-noisily in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6630,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6617 in k6614 in load-noisily in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6622,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6627,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[91]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[253],((C_word*)t0)[2],t3);}

/* a6626 in k6617 in k6614 in load-noisily in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6627,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6620 in k6617 in k6614 in load-noisily in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1201 ##sys#load */
t2=*((C_word*)lf[226]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1);}

/* load-relative in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6576(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6576r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6576r(t0,t1,t2,t3);}}

static void C_ccall f_6576r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6584,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_subchar(t2,C_fix(0));
if(C_truep((C_truep((C_word)C_eqp(t5,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t6=t4;
f_6584(2,t6,t2);}
else{
/* eval.scm: 1197 ##sys#string-append */
t6=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[212]+1),t2);}}

/* k6582 in load-relative in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
/* eval.scm: 1194 ##sys#load */
t5=*((C_word*)lf[226]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t1,t4,C_SCHEME_FALSE);}

/* load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6554(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6554r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6554r(t0,t1,t2,t3);}}

static void C_ccall f_6554r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
/* eval.scm: 1191 ##sys#load */
t6=*((C_word*)lf[226]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t5,C_SCHEME_FALSE);}

/* ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr5r,(void*)f_6167r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6167r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6167r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(23);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t4,a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=t3,tmp=(C_word)a,a+=15,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6504,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6509,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-timer724802 */
t10=t9;
f_6509(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-printer725800 */
t12=t8;
f_6504(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body722727 */
t14=t7;
f_6169(t14,t1,t10,t12);}}}

/* def-timer724 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_6509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6509,NULL,2,t0,t1);}
/* def-printer725800 */
t2=((C_word*)t0)[2];
f_6504(t2,t1,C_SCHEME_FALSE);}

/* def-printer725 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_6504(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6504,NULL,3,t0,t1,t2);}
/* body722727 */
t3=((C_word*)t0)[2];
f_6169(t3,t1,t2,C_SCHEME_FALSE);}

/* body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_6169(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6169,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t2,a[14]=((C_word*)t0)[12],a[15]=t1,a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[14],tmp=(C_word)a,a+=18,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6503,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1126 ##sys#expand-home-path */
t6=*((C_word*)lf[250]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}
else{
t5=t4;
f_6173(t5,C_SCHEME_UNDEFINED);}}

/* k6501 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6173(t3,t2);}

/* k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_6173(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6173,NULL,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6437,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1129 port? */
t6=*((C_word*)lf[249]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}

/* k6435 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6437,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6176(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1131 ##sys#file-info */
t3=*((C_word*)lf[245]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
/* eval.scm: 1122 ##sys#signal-hook */
t3=*((C_word*)lf[220]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[247],lf[232],lf[248],t2);}}}

/* k6450 in k6435 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(4));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t2;
f_6455(t6,(C_word)C_i_not(t3));}
else{
t4=t2;
f_6455(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6455(t3,C_SCHEME_FALSE);}}

/* k6453 in k6450 in k6435 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_6455(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6455,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6176(2,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6458,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1137 ##sys#string-append */
t3=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[246]+1));}}

/* k6456 in k6453 in k6450 in k6435 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1138 ##sys#file-info */
t3=*((C_word*)lf[245]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6462 in k6456 in k6453 in k6450 in k6435 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6464,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6176(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1140 ##sys#string-append */
t3=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[17]);}}

/* k6465 in k6462 in k6456 in k6453 in k6450 in k6435 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1141 ##sys#file-info */
t3=*((C_word*)lf[245]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6471 in k6465 in k6462 in k6456 in k6453 in k6450 in k6435 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6176(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[5];
f_6176(2,t3,(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[2])[1]));}}

/* k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6176,2,t0,t1);}
t2=((C_word*)t0)[17];
t3=(C_truep(t2)?t2:((C_word*)t0)[16]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6182,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t3,a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t1,a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]);
t6=(C_truep(t5)?(C_word)C_i_not(t1):C_SCHEME_FALSE);
if(C_truep(t6)){
/* eval.scm: 1146 ##sys#signal-hook */
t7=*((C_word*)lf[220]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,lf[241],lf[232],lf[242],((C_word*)((C_word*)t0)[6])[1]);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6428,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1147 load-verbose */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k6426 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6428,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6419,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1148 display */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[244]);}
else{
t3=((C_word*)t0)[2];
f_6182(2,t3,C_SCHEME_UNDEFINED);}}

/* k6417 in k6426 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6422,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1149 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6420 in k6417 in k6426 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1150 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[243]);}

/* k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6185,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[14])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6404,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1152 ##sys#make-c-string */
t5=*((C_word*)lf[239]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[14]);}
else{
t3=t2;
f_6185(2,t3,C_SCHEME_FALSE);}}

/* k6402 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1152 ##sys#dload */
t2=*((C_word*)lf[238]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6374 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6376,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6185(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6400,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1153 has-sep? */
f_6121(t2,((C_word*)t0)[3]);}}

/* k6398 in k6374 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6400,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6185(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6396,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1154 ##sys#string-append */
t4=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[240],((C_word*)t0)[2]);}}

/* k6394 in k6398 in k6374 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1154 ##sys#make-c-string */
t2=*((C_word*)lf[239]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6390 in k6398 in k6374 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1154 ##sys#dload */
t2=*((C_word*)lf[238]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6188,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_6188(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 1155 call-with-current-continuation */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6193,3,t0,t1,t2);}
t3=C_SCHEME_TRUE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[13];
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6197,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t6,a[15]=t4,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[13])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1161 has-sep? */
f_6121(t8,((C_word*)t0)[13]);}
else{
t8=t7;
f_6197(2,t8,C_SCHEME_FALSE);}}

/* k6361 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(t1,C_fix(1));
/* eval.scm: 1162 ##sys#substring */
t3=*((C_word*)lf[236]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
f_6197(2,t2,lf[237]);}}

/* k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6197,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6198,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6207,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t13,a[7]=t11,a[8]=t9,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t15=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6348,a[2]=t13,a[3]=t11,a[4]=t9,a[5]=t7,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* ##sys#dynamic-wind */
t17=*((C_word*)lf[235]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,((C_word*)t0)[2],t14,t15,t16);}

/* a6347 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6348,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[227]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[211]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[212]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[210]+1));
t6=C_mutate((C_word*)lf[227]+1,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[211]+1,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[212]+1,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[210]+1,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,*((C_word*)lf[228]+1));}

/* a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6225,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[5])){
/* eval.scm: 1164 open-input-file */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6225(2,t3,((C_word*)((C_word*)t0)[2])[1]);}}

/* k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6230,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6233,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6339,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1165 ##sys#dynamic-wind */
t5=*((C_word*)lf[235]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t2,t3,t4);}

/* a6338 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6339,2,t0,t1);}
/* eval.scm: 1187 close-input-port */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6237,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1168 peek-char */
t3=*((C_word*)lf[234]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(t1,C_make_character(127));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6333,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}
else{
t4=t2;
f_6240(2,t4,C_SCHEME_UNDEFINED);}}

/* k6331 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1170 ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[232],lf[233],((C_word*)t0)[2],t1);}

/* k6238 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1171 read */
t3=((C_word*)t0)[10];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6241 in k6238 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6243,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6248,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6248(t5,((C_word*)t0)[2],t1);}

/* do775 in k6241 in k6238 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_6248(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6248,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6258,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1174 printer */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_6258(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6256 in do775 in k6241 in k6238 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6261,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6270,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1175 ##sys#call-with-values */
C_u_call_with_values(4,0,t2,t3,t4);}

/* a6303 in k6256 in do775 in k6241 in k6238 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6304(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_6304r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6304r(t0,t1,t2);}}

static void C_ccall f_6304r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a6312 in a6303 in k6256 in do775 in k6241 in k6238 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6313(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6313,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6317,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1184 write */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k6315 in a6312 in a6303 in k6256 in do775 in k6241 in k6238 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1185 newline */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6269 in k6256 in do775 in k6241 in k6238 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6270,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6277,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1178 ##sys#start-timer */
t3=*((C_word*)lf[231]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* eval.scm: 1179 evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}}

/* k6275 in a6269 in k6256 in do775 in k6241 in k6238 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6288,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1178 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6287 in k6275 in a6269 in k6256 in do775 in k6241 in k6238 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6288(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_6288r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6288r(t0,t1,t2);}}

static void C_ccall f_6288r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6292,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6299,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1178 ##sys#stop-timer */
t5=*((C_word*)lf[230]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6297 in a6287 in k6275 in a6269 in k6256 in do775 in k6241 in k6238 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1178 ##sys#display-times */
t2=*((C_word*)lf[229]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6290 in a6287 in k6275 in a6269 in k6256 in do775 in k6241 in k6238 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6281 in k6275 in a6269 in k6256 in do775 in k6241 in k6238 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6282,2,t0,t1);}
/* eval.scm: 1178 evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k6259 in k6256 in do775 in k6241 in k6238 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6268,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1172 read */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6266 in k6259 in k6256 in do775 in k6241 in k6238 in k6235 in a6232 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_6248(t2,((C_word*)t0)[2],t1);}

/* a6229 in k6223 in a6220 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6230,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* a6206 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6207,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[227]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[211]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[212]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[210]+1));
t6=C_mutate((C_word*)lf[227]+1,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[211]+1,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[212]+1,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[210]+1,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,*((C_word*)lf[228]+1));}

/* f_6198 in k6195 in a6192 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6198,2,t0,t1);}
/* eval.scm: 1163 abrt */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* k6186 in k6183 in k6180 in k6174 in k6171 in body722 in ##sys#load in k6117 in k6037 in k5938 in k1732 */
static void C_ccall f_6188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* has-sep? in k6117 in k6037 in k5938 in k1732 */
static void C_fcall f_6121(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6121,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6131,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6131(t5,t4));}

/* loop in has-sep? in k6117 in k6037 in k5938 in k1732 */
static C_word C_fcall f_6131(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_i_zerop(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
if(C_truep((C_truep((C_word)C_eqp(t2,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
return(t1);}
else{
t3=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* set-dynamic-load-mode! in k6037 in k5938 in k1732 */
static void C_ccall f_6046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6046,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?t2:(C_word)C_a_i_list(&a,1,t2));
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6053,a[2]=t8,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6058,a[2]=t6,a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_6058(t13,t9,t4);}

/* loop in set-dynamic-load-mode! in k6037 in k5938 in k1732 */
static void C_fcall f_6058(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6058,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6071,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[216]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=t4;
f_6071(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[217]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t8=t4;
f_6071(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[218]);
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t9=t4;
f_6071(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[219]);
if(C_truep(t8)){
t9=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t10=t4;
f_6071(2,t10,t9);}
else{
t9=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1101 ##sys#signal-hook */
t10=*((C_word*)lf[220]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t4,lf[214],lf[221],t9);}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6069 in loop in set-dynamic-load-mode! in k6037 in k5938 in k1732 */
static void C_ccall f_6071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1102 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6058(t3,((C_word*)t0)[2],t2);}

/* k6051 in set-dynamic-load-mode! in k6037 in k5938 in k1732 */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1103 ##sys#set-dlopen-flags! */
t2=*((C_word*)lf[215]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* f_6041 in k6037 in k5938 in k1732 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6041,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* ##sys#decompose-lambda-list in k5938 in k1732 */
static void C_ccall f_5957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5957,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5960,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5970,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5970(t8,t1,t2,C_SCHEME_END_OF_LIST,C_fix(0));}

/* loop in ##sys#decompose-lambda-list in k5938 in k1732 */
static void C_fcall f_5970(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(17);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5970,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5984,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1071 reverse */
t7=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6003,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
/* eval.scm: 1073 reverse */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
if(C_truep((C_word)C_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_u_fixnum_plus(t4,C_fix(1));
/* eval.scm: 1075 loop */
t14=t1;
t15=t6;
t16=t8;
t17=t9;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}
else{
/* eval.scm: 1074 err */
t6=((C_word*)t0)[2];
f_5960(t6,t1);}}}
else{
/* eval.scm: 1072 err */
t6=((C_word*)t0)[2];
f_5960(t6,t1);}}}

/* k6001 in loop in ##sys#decompose-lambda-list in k5938 in k1732 */
static void C_ccall f_6003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1073 k */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5982 in loop in ##sys#decompose-lambda-list in k5938 in k1732 */
static void C_ccall f_5984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1071 k */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* err in ##sys#decompose-lambda-list in k5938 in k1732 */
static void C_fcall f_5960(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5960,NULL,2,t0,t1);}
t2=C_set_block_item(lf[207],0,C_SCHEME_FALSE);
/* eval.scm: 1068 ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[208],((C_word*)t0)[2]);}

/* eval in k5938 in k1732 */
static void C_ccall f_5943(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5943r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5943r(t0,t1,t2,t3);}}

static void C_ccall f_5943r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5951,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1056 ##sys#eval-handler */
t5=*((C_word*)lf[204]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k5949 in eval in k5938 in k1732 */
static void C_ccall f_5951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5955,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1057 ##sys#interpreter-toplevel-macroexpand-hook */
t3=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5953 in k5949 in eval in k5938 in k1732 */
static void C_ccall f_5955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#compile-to-closure in k1732 */
static void C_ccall f_3704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+37)){
C_save_and_reclaim((void*)tr5r,(void*)f_3704r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3704r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3704r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a=C_alloc(37);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3707,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3749,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3861,a[2]=t7,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3914,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3920,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3926,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3932,a[2]=t9,a[3]=t13,a[4]=t7,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=t15,a[8]=t17,a[9]=t12,a[10]=((C_word*)t0)[3],a[11]=t6,tmp=(C_word)a,a+=12,tmp));
t19=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5688,a[2]=t15,a[3]=t11,tmp=(C_word)a,a+=4,tmp));
t20=(C_word)C_fixnum_greaterp(*((C_word*)lf[134]+1),C_fix(0));
t21=(C_word)C_i_nullp(t5);
t22=(C_truep(t21)?C_SCHEME_FALSE:(C_word)C_u_i_car(t5));
/* eval.scm: 1035 compile */
t23=((C_word*)t15)[1];
f_3932(t23,t1,t2,t3,C_SCHEME_FALSE,t20,t22);}

/* compile-call in ##sys#compile-to-closure in k1732 */
static void C_fcall f_5688(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5688,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5692,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 999  compile */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3932(t8,t6,t7,t3,C_SCHEME_FALSE,t4,t5);}

/* k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[64],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5692,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5662,tmp=(C_word)a,a+=2,tmp);
t4=f_5662(t2,C_fix(0));
t5=((C_word*)t0)[8];
switch(t4){
case C_SCHEME_FALSE:
/* eval.scm: 1004 ##sys#syntax-error-hook */
t6=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[7],lf[203],((C_word*)t0)[8]);
case C_fix(0):
t6=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5714,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
case C_fix(1):
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5733,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1008 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3932(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(2):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5761,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1012 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3932(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(3):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5796,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1017 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3932(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(4):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5838,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1023 compile */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3932(t8,t6,t7,((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
default:
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5881,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5905,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1030 ##sys#map */
t8=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}}

/* a5904 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5905(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5905,3,t0,t1,t2);}
/* eval.scm: 1030 compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3932(t3,t1,t2,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5879 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5881,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5882,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_5882 in k5879 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5882,3,t0,t1,t2);}
t3=f_3914(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5893,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5891 */
static void C_ccall f_5893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5897,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5899,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1033 ##sys#map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5898 in k5891 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5899,3,t0,t1,t2);}
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* k5895 in k5891 */
static void C_ccall f_5897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5836 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1024 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3932(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5839 in k5836 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 1025 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3932(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(2)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7]);}

/* k5842 in k5839 in k5836 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5847,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1026 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3932(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(3)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[10],((C_word*)t0)[8]);}

/* k5845 in k5842 in k5839 in k5836 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5847,2,t0,t1);}
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp));}

/* f_5848 in k5845 in k5842 in k5839 in k5836 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5848(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5848,3,t0,t1,t2);}
t3=f_3914(((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5857 */
static void C_ccall f_5859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k5861 in k5857 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5865 in k5861 in k5857 */
static void C_ccall f_5867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5871,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5869 in k5865 in k5861 in k5857 */
static void C_ccall f_5871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5874,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5872 in k5869 in k5865 in k5861 in k5857 */
static void C_ccall f_5874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5794 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1018 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3932(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5797 in k5794 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5802,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 1019 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3932(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(2)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7]);}

/* k5800 in k5797 in k5794 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5802,2,t0,t1);}
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));}

/* f_5803 in k5800 in k5797 in k5794 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5803(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5803,3,t0,t1,t2);}
t3=f_3914(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5814,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5812 */
static void C_ccall f_5814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5818,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5816 in k5812 */
static void C_ccall f_5818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5822,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5820 in k5816 in k5812 */
static void C_ccall f_5822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5825,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5823 in k5820 in k5816 in k5812 */
static void C_ccall f_5825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5759 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5764,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1013 compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3932(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[3],C_fix(1)),((C_word*)t0)[2],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[6]);}

/* k5762 in k5759 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5764,2,t0,t1);}
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5765,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));}

/* f_5765 in k5762 in k5759 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5765,3,t0,t1,t2);}
t3=f_3914(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5776,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5774 */
static void C_ccall f_5776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5780,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5778 in k5774 */
static void C_ccall f_5780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5783,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5781 in k5778 in k5774 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5731 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5733,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5734,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_5734 in k5731 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5734,3,t0,t1,t2);}
t3=f_3914(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5745,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5743 */
static void C_ccall f_5745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5748,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5746 in k5743 */
static void C_ccall f_5748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_5714 in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5714,3,t0,t1,t2);}
t3=f_3914(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5724,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1007 fn */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5722 */
static void C_ccall f_5724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in k5690 in compile-call in ##sys#compile-to-closure in k1732 */
static C_word C_fcall f_5662(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* compile in ##sys#compile-to-closure in k1732 */
static void C_fcall f_3932(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3932,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_symbolp(t2))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3944,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3950,a[2]=t2,a[3]=t6,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 648  ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t7,t8);}
else{
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[11],a[8]=t4,a[9]=((C_word*)t0)[7],a[10]=t3,a[11]=((C_word*)t0)[8],a[12]=t6,a[13]=t5,a[14]=((C_word*)t0)[9],a[15]=t1,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 670  ##sys#number? */
t8=*((C_word*)lf[202]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}}

/* k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4035,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4042,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4050,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4058,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_fix(2));
t4=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4066,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4068,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp)));}}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[16]))){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[16])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4079,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4081,tmp=(C_word)a,a+=2,tmp)));}
else{
t2=(C_word)C_charp(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=t3;
f_4091(t4,t2);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[16]);
t5=t3;
f_4091(t5,(C_truep(t4)?t4:(C_word)C_i_stringp(((C_word*)t0)[16])));}}}}

/* k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_fcall f_4091(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4091,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4092,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_3920(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[11],tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 689  defined? */
t6=((C_word*)t0)[4];
f_3749(t6,t5,t4,((C_word*)t0)[10]);}
else{
t3=f_3920(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
/* eval.scm: 980  compile-call */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5688(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[10],((C_word*)t0)[13],((C_word*)t0)[12]);}}
else{
/* eval.scm: 685  ##sys#syntax-error-hook */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[16],lf[201],((C_word*)t0)[15]);}}}

/* k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4120,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 690  compile-call */
t2=((C_word*)((C_word*)t0)[16])[1];
f_5688(t2,((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11]);}
else{
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4126,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* eval.scm: 691  macroexpand-1-checked */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3861(t3,t2,((C_word*)t0)[14],((C_word*)t0)[13]);}}

/* k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word ab[121],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4126,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[15]);
if(C_truep(t2)){
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[90]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4141,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 696  ##sys#check-syntax */
t5=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[90],((C_word*)t0)[15],lf[145],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[146]);
if(C_truep(t4)){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
if(C_truep(*((C_word*)lf[125]+1))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4217,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 711  ##sys#hash-table-location */
t7=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,*((C_word*)lf[125]+1),t5,C_SCHEME_TRUE);}
else{
t6=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4223,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[14],lf[147]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 716  compile */
t7=((C_word*)((C_word*)t0)[12])[1];
f_3932(t7,((C_word*)t0)[13],t6,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[148]);
if(C_truep(t6)){
t7=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 719  compile */
t8=((C_word*)((C_word*)t0)[12])[1];
f_3932(t8,((C_word*)t0)[13],t7,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[110]);
if(C_truep(t7)){
t8=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4257,tmp=(C_word)a,a+=2,tmp));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[149]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4267,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 724  ##sys#check-syntax */
t10=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,lf[149],((C_word*)t0)[15],lf[151],C_SCHEME_FALSE);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[106]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4324,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 733  ##sys#check-syntax */
t11=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t10,lf[106],((C_word*)t0)[15],lf[153],C_SCHEME_FALSE);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[14],lf[69]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[14],lf[71]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4432,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 749  ##sys#check-syntax */
t13=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t12,lf[69],((C_word*)t0)[15],lf[156],C_SCHEME_FALSE);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[58]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4541,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 773  ##sys#check-syntax */
t14=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t13,lf[58],((C_word*)t0)[15],lf[158],C_SCHEME_FALSE);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[14],lf[92]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4879,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 823  ##sys#check-syntax */
t15=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t15+1)))(6,t15,t14,lf[92],((C_word*)t0)[15],lf[163],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[14],lf[59]);
if(C_truep(t14)){
t15=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t16=(C_word)C_a_i_cons(&a,2,lf[92],t15);
/* eval.scm: 917  compile */
t17=((C_word*)((C_word*)t0)[12])[1];
f_3932(t17,((C_word*)t0)[13],t16,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[14],lf[164]);
if(C_truep(t15)){
t16=(C_word)C_u_i_cddr(((C_word*)t0)[15]);
t17=(C_word)C_a_i_cons(&a,2,lf[92],t16);
t18=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 920  compile */
t19=((C_word*)((C_word*)t0)[12])[1];
f_3932(t19,((C_word*)t0)[13],t17,((C_word*)t0)[11],t18,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[14],lf[165]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5281,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5312,tmp=(C_word)a,a+=2,tmp);
t19=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
/* map */
t20=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t17,t18,t19);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[14],lf[169]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5336,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t19=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5342,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=((C_word*)t21)[1];
f_5342(t23,t18,t19);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[14],lf[172]);
t19=(C_truep(t18)?t18:(C_word)C_eqp(((C_word*)t0)[14],lf[173]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5388,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5394,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 942  ##sys#compile-to-closure */
t23=*((C_word*)lf[139]+1);
((C_proc6)(void*)(*((C_word*)t23+1)))(6,t23,t21,t22,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[14],lf[175]);
if(C_truep(t20)){
t21=(C_word)C_u_i_cadr(((C_word*)t0)[15]);
/* eval.scm: 946  compile */
t22=((C_word*)((C_word*)t0)[12])[1];
f_3932(t22,((C_word*)t0)[13],t21,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[14],lf[176]);
t22=(C_truep(t21)?t21:(C_word)C_eqp(((C_word*)t0)[14],lf[177]));
if(C_truep(t22)){
/* eval.scm: 949  compile */
t23=((C_word*)((C_word*)t0)[12])[1];
f_3932(t23,((C_word*)t0)[13],lf[178],((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[14],lf[179]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5432,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_u_i_memq(lf[181],*((C_word*)lf[182]+1)))){
t25=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5443,tmp=(C_word)a,a+=2,tmp);
t26=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
/* for-each */
t27=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t27+1)))(4,t27,t24,t25,t26);}
else{
/* eval.scm: 954  ##sys#warn */
t25=*((C_word*)lf[184]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t24,lf[185],((C_word*)t0)[15]);}}
else{
t24=(C_word)C_eqp(((C_word*)t0)[14],lf[186]);
t25=(C_truep(t24)?t24:(C_word)C_eqp(((C_word*)t0)[14],lf[187]));
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5482,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[15],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 958  cadadr */
t27=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t27+1)))(3,t27,t26,((C_word*)t0)[15]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[14],lf[188]);
t27=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5495,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t26)){
t28=t27;
f_5495(t28,t26);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[14],lf[192]);
if(C_truep(t28)){
t29=t27;
f_5495(t29,t28);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[14],lf[193]);
if(C_truep(t29)){
t30=t27;
f_5495(t30,t29);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[14],lf[194]);
if(C_truep(t30)){
t31=t27;
f_5495(t31,t30);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[14],lf[195]);
if(C_truep(t31)){
t32=t27;
f_5495(t32,t31);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[14],lf[196]);
if(C_truep(t32)){
t33=t27;
f_5495(t33,t32);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[14],lf[197]);
if(C_truep(t33)){
t34=t27;
f_5495(t34,t33);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[14],lf[198]);
if(C_truep(t34)){
t35=t27;
f_5495(t35,t34);}
else{
t35=(C_word)C_eqp(((C_word*)t0)[14],lf[199]);
t36=t27;
f_5495(t36,(C_truep(t35)?t35:(C_word)C_eqp(((C_word*)t0)[14],lf[200])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}
else{
/* eval.scm: 976  compile */
t3=((C_word*)((C_word*)t0)[12])[1];
f_3932(t3,((C_word*)t0)[13],t1,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* k5493 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_fcall f_5495(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 965  ##sys#syntax-error-hook */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],lf[189],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[61]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* eval.scm: 968  compile-call */
t4=((C_word*)((C_word*)t0)[5])[1];
f_5688(t4,((C_word*)t0)[8],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[190]);
if(C_truep(t3)){
/* eval.scm: 972  ##sys#syntax-error-hook */
t4=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[8],lf[191],((C_word*)t0)[7]);}
else{
/* eval.scm: 974  compile-call */
t4=((C_word*)((C_word*)t0)[5])[1];
f_5688(t4,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}}}

/* k5480 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5482,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[69],t3);
/* eval.scm: 958  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3932(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5442 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5443,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
/* eval.scm: 953  ##compiler#process-declaration */
t4=*((C_word*)lf[183]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* k5430 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 955  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3932(t2,((C_word*)t0)[5],lf[180],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5392 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5386 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 943  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3932(t2,((C_word*)t0)[5],lf[174],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_fcall f_5342(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5342,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[170]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5354,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5364,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 937  ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}}

/* a5363 in loop in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5364(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5364,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5372,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 938  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5342(t6,t4,t5);}

/* k5370 in a5363 in loop in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5372,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[106],((C_word*)t0)[2],t1));}

/* a5353 in loop in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5354,2,t0,t1);}
t2=(C_word)C_u_i_cadar(((C_word*)t0)[2]);
/* eval.scm: 937  ##sys#do-the-right-thing */
t3=*((C_word*)lf[171]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* k5334 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 933  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3932(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5311 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5312,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5319,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 923  ##sys#compile-to-closure */
t4=*((C_word*)lf[139]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k5317 in a5311 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k5279 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5284,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_apply(4,0,t2,*((C_word*)lf[167]+1),t1);}

/* k5282 in k5279 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5287,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 925  ##sys#lookup-runtime-requirements */
t3=*((C_word*)lf[168]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5285 in k5282 in k5279 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5294,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_5294(t3,lf[166]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5304,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5306,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}}

/* a5305 in k5285 in k5282 in k5279 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5306,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[90],t2));}

/* k5302 in k5285 in k5282 in k5279 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5304,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5294(t2,(C_word)C_a_i_cons(&a,2,lf[167],t1));}

/* k5292 in k5285 in k5282 in k5279 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_fcall f_5294(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 926  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3932(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4879,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[8];
t9=(C_truep(t8)?t8:lf[159]);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t4)[1]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4891,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[8],a[9]=t10,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5216,a[2]=t11,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 827  ##sys#extended-lambda-list? */
t13=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t4)[1]);}

/* k5214 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5216,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5227,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 828  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_4891(2,t2,C_SCHEME_UNDEFINED);}}

/* a5226 in k5214 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5227,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a5220 in k5214 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5221,2,t0,t1);}
/* eval.scm: 830  ##sys#expand-extended-lambda-list */
t2=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[56]+1));}

/* k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 833  ##sys#decompose-lambda-list */
t3=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4896,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4903,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t4,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5199,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5205,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=((C_word*)t0)[6];
t10=(C_truep(t9)?t9:((C_word*)t0)[5]);
/* eval.scm: 839  ##sys#canonicalize-body */
t11=*((C_word*)lf[105]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t7,((C_word*)((C_word*)t0)[2])[1],t8,((C_word*)t0)[4],t10);}

/* a5204 in a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5205,3,t0,t1,t2);}
/* defined?299 */
t3=((C_word*)t0)[3];
f_3749(t3,t1,t2,((C_word*)t0)[2]);}

/* k5197 in a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[6];
t3=(C_truep(t2)?t2:((C_word*)t0)[5]);
/* eval.scm: 838  ##sys#compile-to-closure */
t4=*((C_word*)lf[139]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4901 in a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[86],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4903,2,t0,t1);}
t2=((C_word*)t0)[8];
switch(t2){
case C_fix(0):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(1):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(2):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(3):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
default:
t3=(C_word)C_eqp(t2,C_fix(4));
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5097,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)):(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp):(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp))));}}

/* f_5161 in k4901 in a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5161,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5167,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 908  decorate */
f_3926(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5166 */
static void C_ccall f_5167(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5167r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5167r(t0,t1,t2);}}

static void C_ccall f_5167r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(t3,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5191,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,*((C_word*)lf[160]+1),t2);}
else{
/* eval.scm: 912  ##sys#error */
t5=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[161],((C_word*)t0)[4],t3);}}

/* k5189 in a5166 */
static void C_ccall f_5191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5191,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5138 in k4901 in a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5138,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5144,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 901  decorate */
f_3926(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5143 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr2r,(void*)f_5144r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5144r(t0,t1,t2);}}

static void C_ccall f_5144r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(17);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5156,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5160,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t2))){
t6=t4;
f_5160(2,t6,(C_word)C_a_i_list(&a,1,t2));}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5629,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5629(t9,t4,t5,t2,C_SCHEME_FALSE);}}

/* do589 in a5143 */
static void C_fcall f_5629(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5629,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,1,t3);
t7=(C_word)C_i_setslot(t4,C_fix(1),t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)t0)[3]);}
else{
t6=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
t11=t1;
t12=t6;
t13=t7;
t14=t3;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}

/* k5158 in a5143 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[160]+1),t1);}

/* k5154 in a5143 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5156,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5116 in k4901 in a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5116,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5122,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 894  decorate */
f_3926(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5121 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5122,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5134,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 896  ##sys#vector */
t7=*((C_word*)lf[160]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k5132 in a5121 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5134,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5097 in k4901 in a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5097(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5097,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5103,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 889  decorate */
f_3926(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5102 */
static void C_ccall f_5103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6r,(void*)f_5103r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_5103r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_5103r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t7=(C_word)C_a_i_vector(&a,5,t2,t3,t4,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t8);}

/* f_5069 in k4901 in a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5069(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5069,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5075,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 883  decorate */
f_3926(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5074 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5075,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5050 in k4901 in a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5050,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5056,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 878  decorate */
f_3926(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5055 */
static void C_ccall f_5056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_5056r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5056r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5056r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_a_i_vector(&a,4,t2,t3,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,t7);}

/* f_5022 in k4901 in a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5022,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5028,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 872  decorate */
f_3926(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5027 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5028,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_5003 in k4901 in a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_5003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5003,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5009,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 867  decorate */
f_3926(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5008 */
static void C_ccall f_5009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_5009r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5009r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5009r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_4975 in k4901 in a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4975,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4981,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 861  decorate */
f_3926(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4980 */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4981,3,t0,t1,t2);}
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* f_4956 in k4901 in a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4956(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4956,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4962,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 856  decorate */
f_3926(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4961 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_4962r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4962r(t0,t1,t2,t3);}}

static void C_ccall f_4962r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_4932 in k4901 in a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4932(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4932,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4938,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 851  decorate */
f_3926(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4937 */
static void C_ccall f_4938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4938,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f_4913 in k4901 in a4895 in k4889 in k4877 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4913,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4919,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 846  decorate */
f_3926(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4918 */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4919r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4919r(t0,t1,t2);}}

static void C_ccall f_4919r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4541,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[10]);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],a[11]=t3,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4866,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a4865 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4866,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4550,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4556,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4854,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4860,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 779  ##sys#canonicalize-body */
t7=*((C_word*)lf[105]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,t5,t6,((C_word*)t0)[4],((C_word*)t0)[6]);}

/* a4859 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4860,3,t0,t1,t2);}
/* defined?299 */
t3=((C_word*)t0)[3];
f_3749(t3,t1,t2,((C_word*)t0)[2]);}

/* k4852 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 778  ##sys#compile-to-closure */
t2=*((C_word*)lf[139]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4556,2,t0,t1);}
switch(((C_word*)t0)[10]){
case C_fix(1):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4565,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 784  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3932(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4599,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 787  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3932(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(3):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 791  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3932(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
case C_fix(4):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 799  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3932(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);
default:
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4791,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4838,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* map */
t4=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}}

/* a4837 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4838,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 813  compile */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3932(t5,t1,t3,((C_word*)t0)[4],t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4789 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4791,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4792,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4792 in k4789 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4792,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 815  ##sys#make-vector */
t4=*((C_word*)lf[157]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k4794 */
static void C_ccall f_4796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4799,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4808,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4808(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* do471 in k4794 */
static void C_fcall f_4808(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4808,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4833,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k4831 in do471 in k4794 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_4808(t5,((C_word*)t0)[2],t3,t4);}

/* k4797 in k4794 */
static void C_ccall f_4799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4799,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k4713 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4776,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 800  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}

/* k4774 in k4713 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 800  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3932(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4716 in k4713 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4718,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4724,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 802  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3932(t6,t3,t4,((C_word*)t0)[5],t5,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k4722 in k4716 in k4713 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4760,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 803  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4758 in k4722 in k4716 in k4713 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 803  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3932(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4725 in k4722 in k4716 in k4713 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4727,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));}

/* f_4728 in k4725 in k4722 in k4716 in k4713 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4728,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4742 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4748,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k4746 in k4742 */
static void C_ccall f_4748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4752,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4750 in k4746 in k4742 */
static void C_ccall f_4752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4756,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4754 in k4750 in k4746 in k4742 */
static void C_ccall f_4756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4756,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4646 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4651,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4694,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 792  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}

/* k4692 in k4646 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 792  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3932(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4649 in k4646 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4651,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4657,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 794  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3932(t6,t3,t4,((C_word*)t0)[4],t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4655 in k4649 in k4646 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4657,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));}

/* f_4658 in k4655 in k4649 in k4646 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4658,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4674,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4672 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4676 in k4672 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4682,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4680 in k4676 in k4672 */
static void C_ccall f_4682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4682,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4597 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4602,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4627,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 788  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4625 in k4597 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 788  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3932(t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4600 in k4597 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4602,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4603,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4603 in k4600 in k4597 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4603,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4619,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4617 */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4623,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4621 in k4617 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4623,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4563 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4565,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4566,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_4566 in k4563 in k4554 in k4548 in k4539 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4566,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4582,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4580 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4582,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,1,t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4430 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4432,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4440,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4446,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4445 in k4430 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4446,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4450,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 752  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3932(t6,t4,t5,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4448 in a4445 in k4430 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4450,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_zerop(((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4507,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4520,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp)));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4459,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 754  ##sys#alias-global-hook */
t4=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k4457 in k4448 in a4445 in k4430 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4459,2,t0,t1);}
if(C_truep(*((C_word*)lf[125]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4465,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 756  ##sys#hash-table-location */
t3=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[125]+1),t1,*((C_word*)lf[126]+1));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4492,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}}

/* f_4492 in k4457 in k4448 in a4445 in k4430 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4492(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4492,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4500,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4498 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k4463 in k4457 in k4448 in a4445 in k4430 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4468(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 760  ##sys#error */
t3=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[155],((C_word*)t0)[2]);}}

/* k4466 in k4463 in k4457 in k4448 in a4445 in k4430 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4468,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4475,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4484,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}

/* f_4484 in k4466 in k4463 in k4457 in k4448 in a4445 in k4430 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4484(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4484,2,t0,t1);}
/* eval.scm: 763  ##sys#error */
t2=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[154],((C_word*)t0)[2]);}

/* f_4475 in k4466 in k4463 in k4457 in k4448 in a4445 in k4430 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4475,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4483,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4481 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* f_4520 in k4448 in a4445 in k4430 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4520(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4520,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4528,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4526 */
static void C_ccall f_4528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot((C_word)C_u_i_list_ref(((C_word*)t0)[4],((C_word*)t0)[3]),((C_word*)t0)[2],t1));}

/* f_4507 in k4448 in a4445 in k4430 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4507(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4507,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4517 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4439 in k4430 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4440,2,t0,t1);}
/* eval.scm: 751  lookup */
f_3707(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4322 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4324,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(0):
/* eval.scm: 737  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3932(t4,((C_word*)t0)[5],lf[152],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(1):
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 738  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3932(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 739  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3932(t6,t4,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
default:
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 743  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3932(t6,t4,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4381 in k4322 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 744  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3932(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4384 in k4381 in k4322 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4389,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,lf[106],t4);
/* eval.scm: 745  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3932(t6,t2,t5,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4387 in k4384 in k4381 in k4322 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4389,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp));}

/* f_4390 in k4387 in k4384 in k4381 in k4322 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4390(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4390,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4394,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4392 */
static void C_ccall f_4394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4395 in k4392 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4359 in k4322 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4364,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 740  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3932(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4362 in k4359 in k4322 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4364,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4365,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_4365 in k4362 in k4359 in k4322 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4365,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4369,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4367 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4265 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 725  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3932(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4268 in k4265 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[6]);
/* eval.scm: 726  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3932(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4271 in k4268 in k4265 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4276,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cdddr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[6]);
/* eval.scm: 728  compile */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3932(t5,t2,t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* eval.scm: 729  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3932(t4,t2,lf[150],((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4274 in k4271 in k4268 in k4265 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4276,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4277,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4277 in k4274 in k4271 in k4268 in k4265 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4277,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4284,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4282 */
static void C_ccall f_4284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* f_4257 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4257,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* f_4223 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4223,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* k4215 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4217,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4218,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_4218 in k4215 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4218,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* k4139 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4141,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4151,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4159,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4167,tmp=(C_word)a,a+=2,tmp));
case C_fix(2):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4175,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_TRUE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4183,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_FALSE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4191,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4199,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4201,a[2]=t2,tmp=(C_word)a,a+=3,tmp)));}}

/* f_4201 in k4139 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4201(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4201,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4199 in k4139 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4199,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* f_4191 in k4139 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4191(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4191,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4183 in k4139 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4183,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4175 in k4139 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4175(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4175,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4167 in k4139 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4167(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4167,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4159 in k4139 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4159,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4151 in k4139 in k4124 in k4118 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4151,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* f_4092 in k4089 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4092(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4092,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4081 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4081(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4081,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4079 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4079(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4079,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4068 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4068,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4066 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4066,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4058 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4058,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4050 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4050,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4042 in k4033 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4042,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* a3949 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_3950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3950,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(t4)){
t5=(C_word)C_i_zerop(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4016,a[2]=t3,tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4025,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp)));}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3960,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 650  ##sys#alias-global-hook */
t6=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k3958 in a3949 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_3960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3960,2,t0,t1);}
if(C_truep(*((C_word*)lf[125]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3966,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 652  ##sys#hash-table-location */
t3=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[125]+1),t1,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3989,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3994,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[133]+1))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4009,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 665  ##sys#symbol-has-toplevel-binding? */
t5=*((C_word*)lf[144]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}
else{
t4=t3;
f_3994(t4,C_SCHEME_FALSE);}}}

/* k4007 in k3958 in a3949 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3994(t2,(C_word)C_i_not(t1));}

/* k3992 in k3958 in a3949 in compile in ##sys#compile-to-closure in k1732 */
static void C_fcall f_3994(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3994,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,*((C_word*)lf[133]+1));
t4=C_mutate((C_word*)lf[133]+1,t3);
t5=((C_word*)t0)[2];
f_3989(t5,t4);}
else{
t2=((C_word*)t0)[2];
f_3989(t2,C_SCHEME_UNDEFINED);}}

/* k3987 in k3958 in a3949 in compile in ##sys#compile-to-closure in k1732 */
static void C_fcall f_3989(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3989,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3990,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));}

/* f_3990 in k3987 in k3958 in a3949 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3990,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_retrieve(((C_word*)t0)[2]));}

/* k3964 in k3958 in a3949 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_3969(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 653  ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[143],((C_word*)t0)[2]);}}

/* k3967 in k3964 in k3958 in a3949 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3969,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));}

/* f_3970 in k3967 in k3964 in k3958 in a3949 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_3970(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3970,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
if(C_truep(t3)){
/* eval.scm: 660  ##sys#error */
t4=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[142],((C_word*)t0)[2]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* f_4025 in a3949 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4025,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot((C_word)C_u_i_list_ref(t2,((C_word*)t0)[3]),((C_word*)t0)[2]));}

/* f_4016 in a3949 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4016,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,((C_word*)t0)[2]));}

/* a3943 in compile in ##sys#compile-to-closure in k1732 */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3944,2,t0,t1);}
/* eval.scm: 648  lookup */
f_3707(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* decorate in ##sys#compile-to-closure in k1732 */
static void C_fcall f_3926(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3926,NULL,5,t1,t2,t3,t4,t5);}
/* eval.scm: 644  ##sys#eval-decorator */
t6=*((C_word*)lf[127]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t3,t4,t5);}

/* emit-syntax-trace-info in ##sys#compile-to-closure in k1732 */
static C_word C_fcall f_3920(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_syntax_trace_info(t2,t3,*((C_word*)lf[140]+1)):C_SCHEME_UNDEFINED));}

/* emit-trace-info in ##sys#compile-to-closure in k1732 */
static C_word C_fcall f_3914(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_eval_trace_info(t2,t3,*((C_word*)lf[140]+1)):C_SCHEME_UNDEFINED));}

/* macroexpand-1-checked in ##sys#compile-to-closure in k1732 */
static void C_fcall f_3861(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3861,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3865,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 624  ##sys#macroexpand-1-local */
t5=*((C_word*)lf[74]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}

/* k3863 in macroexpand-1-checked in ##sys#compile-to-closure in k1732 */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3865,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,lf[58]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3912,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 627  defined? */
t6=((C_word*)t0)[2];
f_3749(t6,t5,lf[58],((C_word*)t0)[3]);}
else{
t5=t3;
f_3880(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k3910 in k3863 in macroexpand-1-checked in ##sys#compile-to-closure in k1732 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3880(t2,(C_word)C_i_not(t1));}

/* k3878 in k3863 in macroexpand-1-checked in ##sys#compile-to-closure in k1732 */
static void C_fcall f_3880(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3880,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_3889(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_3889(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* k3887 in k3878 in k3863 in macroexpand-1-checked in ##sys#compile-to-closure in k1732 */
static void C_fcall f_3889(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 630  macroexpand-1-checked */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3861(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* defined? in ##sys#compile-to-closure in k1732 */
static void C_fcall f_3749(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3749,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3755,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3761,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3760 in defined? in ##sys#compile-to-closure in k1732 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3761,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* a3754 in defined? in ##sys#compile-to-closure in k1732 */
static void C_ccall f_3755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3755,2,t0,t1);}
/* eval.scm: 599  lookup */
f_3707(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lookup in ##sys#compile-to-closure in k1732 */
static void C_fcall f_3707(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3707,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3713,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3713(t7,t1,t3,C_fix(0));}

/* loop in lookup in ##sys#compile-to-closure in k1732 */
static void C_fcall f_3713(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3713,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* eval.scm: 594  values */
C_values(4,0,t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3831,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=f_3831(t6,t4,C_fix(0));
if(C_truep(t7)){
/* eval.scm: 595  values */
C_values(4,0,t1,t3,t7);}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 596  loop */
t11=t1;
t12=t8;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* loop in loop in lookup in ##sys#compile-to-closure in k1732 */
static C_word C_fcall f_3831(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##sys#alias-global-hook in k1732 */
static void C_ccall f_3698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3698,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#eval-decorator in k1732 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3657,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3663,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3676,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 564  ##sys#decorate-lambda */
t8=*((C_word*)lf[132]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,t6,t7);}

/* a3675 in ##sys#eval-decorator in k1732 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3676,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3684,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 571  open-output-string */
t6=*((C_word*)lf[131]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3686 in a3675 in ##sys#eval-decorator in k1732 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3691,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 572  write */
t3=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3689 in k3686 in a3675 in ##sys#eval-decorator in k1732 */
static void C_ccall f_3691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3694,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 573  get-output-string */
t3=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3692 in k3689 in k3686 in a3675 in ##sys#eval-decorator in k1732 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 570  ##sys#make-lambda-info */
t2=*((C_word*)lf[128]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3682 in a3675 in ##sys#eval-decorator in k1732 */
static void C_ccall f_3684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}

/* a3662 in ##sys#eval-decorator in k1732 */
static void C_ccall f_3663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3663,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_lambdainfop(t2)));}

/* ##sys#hash-table-location in k1732 */
static void C_ccall f_3597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3597,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3601,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_block_size(t2);
/* eval.scm: 544  ##sys#hash-symbol */
t7=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t3,t6);}

/* k3599 in ##sys#hash-table-location in k1732 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3601,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3609,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3609(t6,((C_word*)t0)[2],t2);}

/* loop in k3599 in ##sys#hash-table-location in k1732 */
static void C_fcall f_3609(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3609,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[8])){
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[7],((C_word*)t0)[6],C_SCHEME_TRUE);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[7],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 555  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-for-each in k1732 */
static void C_ccall f_3551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3551,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3557,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3557(t8,t1,C_fix(0));}

/* do256 in ##sys#hash-table-for-each in k1732 */
static void C_fcall f_3557(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3557,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3567,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3576,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* eval.scm: 536  ##sys#for-each */
t6=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a3575 in do256 in ##sys#hash-table-for-each in k1732 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3576,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 537  p */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k3565 in do256 in ##sys#hash-table-for-each in k1732 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3557(t3,((C_word*)t0)[2],t2);}

/* ##sys#hash-table-set! in k1732 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3496,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3500,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 522  ##sys#hash-symbol */
t6=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,(C_word)C_block_size(t2));}

/* k3498 in ##sys#hash-table-set! in k1732 */
static void C_ccall f_3500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3500,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3508,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3508(t6,((C_word*)t0)[2],t2);}

/* loop in k3498 in ##sys#hash-table-set! in k1732 */
static void C_fcall f_3508(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3508,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t5));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),((C_word*)t0)[6]));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 530  loop */
t11=t1;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-ref in k1732 */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3451,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3455,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 511  ##sys#hash-symbol */
t5=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,(C_word)C_block_size(t2));}

/* k3453 in ##sys#hash-table-ref in k1732 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3455,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3464,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3464(t3,t2));}

/* loop in k3453 in ##sys#hash-table-ref in k1732 */
static C_word C_fcall f_3464(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return((C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}}

/* ##sys#hash-symbol in k1732 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3436,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_hash_string(t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_modulo(t6,t3));}}

/* ##sys#expand-curried-define in k1732 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3376,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3379,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3431,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 493  loop */
t10=((C_word*)t7)[1];
f_3379(t10,t9,t2,t3);}

/* k3429 in ##sys#expand-curried-define in k1732 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3431,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k1732 */
static void C_fcall f_3379(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(15);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3379,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[92],t8));}
else{
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
t8=(C_word)C_a_i_cons(&a,2,lf[92],t7);
t9=(C_word)C_a_i_list(&a,1,t8);
/* eval.scm: 492  loop */
t15=t1;
t16=t5;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* ##sys#match-expression in k1732 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3285,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3288,a[2]=t8,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3374,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 480  mwalk */
t11=((C_word*)t8)[1];
f_3288(t11,t10,t2,t3);}

/* k3372 in ##sys#match-expression in k1732 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}

/* mwalk in ##sys#match-expression in k1732 */
static void C_fcall f_3288(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3288,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not((C_word)C_blockp(t3));
t5=(C_truep(t4)?t4:(C_word)C_i_not((C_word)C_pairp(t3)));
if(C_truep(t5)){
t6=(C_word)C_u_i_assq(t3,((C_word*)((C_word*)t0)[4])[1]);
if(C_truep(t6)){
t7=(C_word)C_slot(t6,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_equalp(t2,t7));}
else{
if(C_truep((C_word)C_u_i_memq(t3,((C_word*)t0)[3]))){
t7=(C_word)C_a_i_cons(&a,2,t3,t2);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)((C_word*)t0)[4])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_TRUE);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_eqp(t2,t3));}}}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3343,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(t2,C_fix(0));
t10=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 477  mwalk */
t17=t8;
t18=t9;
t19=t10;
t1=t17;
t2=t18;
t3=t19;
goto loop;}}}

/* k3341 in mwalk in ##sys#match-expression in k1732 */
static void C_ccall f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 478  mwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3288(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k1732 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_2802r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2802r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2802r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(12);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2804,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3235,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3240,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-me146199 */
t8=t7;
f_3240(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-container147197 */
t10=t6;
f_3235(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body144149 */
t12=t5;
f_2804(t12,t1,t8);}}}

/* def-me146 in ##sys#canonicalize-body in k1732 */
static void C_fcall f_3240(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3240,NULL,2,t0,t1);}
/* def-container147197 */
t2=((C_word*)t0)[2];
f_3235(t2,t1,C_SCHEME_FALSE);}

/* def-container147 in ##sys#canonicalize-body in k1732 */
static void C_fcall f_3235(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3235,NULL,3,t0,t1,t2);}
/* body144149 */
t3=((C_word*)t0)[2];
f_2804(t3,t1,t2);}

/* body144 in ##sys#canonicalize-body in k1732 */
static void C_fcall f_2804(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2804,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2807,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
/* eval.scm: 461  expand */
t9=((C_word*)t6)[1];
f_2987(t9,t1,((C_word*)t0)[2]);}

/* expand in body144 in ##sys#canonicalize-body in k1732 */
static void C_fcall f_2987(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2987,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2993(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in body144 in ##sys#canonicalize-body in k1732 */
static void C_fcall f_2993(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2993,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_slot(t7,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3027,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t10,a[7]=t2,a[8]=t6,a[9]=t5,a[10]=t4,a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[5],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t10))){
/* eval.scm: 427  lookup */
t12=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t10);}
else{
t12=t11;
f_3027(2,t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 426  fini */
t11=((C_word*)((C_word*)t0)[5])[1];
f_2807(t11,t1,t3,t4,t5,t6,t2);}}
else{
/* eval.scm: 422  fini */
t7=((C_word*)((C_word*)t0)[5])[1];
f_2807(t7,t1,t3,t4,t5,t6,t2);}}

/* k3025 in loop in expand in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3027,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 428  fini */
t2=((C_word*)((C_word*)t0)[13])[1];
f_2807(t2,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(lf[107],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3039,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 430  ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[107],((C_word*)t0)[3],lf[116],C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(lf[108],((C_word*)t0)[6]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3157,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 451  ##sys#check-syntax */
t5=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[108],((C_word*)t0)[3],lf[117],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(lf[106],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3185,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 454  ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[106],((C_word*)t0)[3],lf[118],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3199,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 457  ##sys#macroexpand-0 */
t6=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}}}}}

/* k3197 in k3025 in loop in expand in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3199,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
/* eval.scm: 459  fini */
t3=((C_word*)((C_word*)t0)[10])[1];
f_2807(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* eval.scm: 460  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2993(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k3183 in k3025 in loop in expand in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3192,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 455  ##sys#append */
t4=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k3190 in k3183 in k3025 in loop in expand in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_3192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 455  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2993(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3155 in k3025 in loop in expand in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3157,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_u_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* eval.scm: 452  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2993(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k3037 in k3025 in loop in expand in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3039,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3044,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t3,tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3044(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k3037 in k3025 in loop in expand in body144 in ##sys#canonicalize-body in k1732 */
static void C_fcall f_3044(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3044,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3091,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 442  ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[107],t2,lf[112],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 445  ##sys#check-syntax */
t6=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[107],t2,lf[113],C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 434  ##sys#check-syntax */
t5=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[107],t2,lf[115],C_SCHEME_FALSE);}}

/* k3055 in loop2 in k3037 in k3025 in loop in expand in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3057,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_caddr(((C_word*)t0)[8]):lf[114]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
/* eval.scm: 435  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_2993(t7,((C_word*)t0)[5],((C_word*)t0)[4],t2,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3107 in loop2 in k3037 in k3025 in loop in expand in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3109,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(0));
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
t5=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[92],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[7]);
/* eval.scm: 446  loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_2993(t9,((C_word*)t0)[5],((C_word*)t0)[4],t3,t8,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3089 in loop2 in k3037 in k3025 in loop in expand in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3102,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* eval.scm: 443  ##sys#expand-curried-define */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k3100 in k3089 in loop2 in k3037 in k3025 in loop in expand in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3102,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[107],t1);
/* eval.scm: 443  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3044(t3,((C_word*)t0)[2],t2);}

/* fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_fcall f_2807(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2807,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2819,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_2819(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2889,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 406  reverse */
t10=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}}

/* k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2967,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2979,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[88]+1),t1,((C_word*)t0)[3]);}

/* k2977 in k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 407  ##sys#map */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2966 in k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2967,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[110]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k2898 in k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2904,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2908,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2957,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 409  reverse */
t6=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2963 in k2898 in k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 409  map */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2956 in k2898 in k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2957,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[71],t2,t3));}

/* k2906 in k2898 in k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2912,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2918,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 416  reverse */
t6=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2949 in k2906 in k2898 in k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2955,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 417  reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2953 in k2949 in k2906 in k2898 in k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 410  map */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2917 in k2906 in k2898 in k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2918,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2922,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 411  ##sys#map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[83]+1),t2);}

/* k2920 in a2917 in k2906 in k2898 in k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2922,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[92],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2941,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2943,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 415  map */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a2942 in k2920 in a2917 in k2906 in k2898 in k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2943,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[71],t2,t3));}

/* k2939 in k2920 in a2917 in k2906 in k2898 in k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2941,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[92],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[109],((C_word*)t0)[2],t3));}

/* k2914 in k2906 in k2898 in k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2910 in k2906 in k2898 in k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2902 in k2898 in k2887 in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2904,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[58],t2));}

/* loop in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_fcall f_2819(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2819,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2838,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(0));
t7=(C_word)C_a_i_list(&a,2,lf[107],lf[108]);
t8=t5;
f_2838(t8,(C_word)C_u_i_memq(t6,t7));}
else{
t6=t5;
f_2838(t6,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[106],((C_word*)t0)[2]));}}

/* k2836 in loop in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_fcall f_2838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2838,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2845,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2849,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 404  reverse */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
/* eval.scm: 405  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2819(t4,((C_word*)t0)[8],t2,t3);}}

/* k2847 in k2836 in loop in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2857,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 404  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2987(t3,t2,((C_word*)t0)[2]);}

/* k2855 in k2847 in k2836 in loop in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2857,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 404  ##sys#append */
t3=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2843 in k2836 in loop in fini in body144 in ##sys#canonicalize-body in k1732 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2845,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[106],t1));}

/* ##sys#expand-extended-lambda-list in k1732 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2283,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2286,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2305,a[2]=((C_word*)t0)[2],a[3]=t11,a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t9,a[8]=t7,tmp=(C_word)a,a+=9,tmp));
t13=((C_word*)t11)[1];
f_2305(t13,t1,C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_fcall f_2305(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word *a;
loop:
a=C_alloc(85);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2305,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2319,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2528,a[2]=((C_word*)t0)[8],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 322  reverse */
t9=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
/* eval.scm: 322  reverse */
t8=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
/* eval.scm: 345  err */
t7=((C_word*)t0)[4];
f_2286(t7,t1,lf[94]);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2549,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t8)){
t9=t7;
f_2549(t9,C_SCHEME_UNDEFINED);}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[8])+1,t6);
t10=t7;
f_2549(t10,t9);}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_slot(t6,C_fix(0));
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(t7,lf[80]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2581,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t11)){
t12=t10;
f_2581(t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2600,a[2]=t10,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 357  gensym */
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}}
else{
t10=(C_word)C_eqp(t7,lf[79]);
if(C_truep(t10)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(1)))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2618,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[7],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t8))){
t12=(C_word)C_slot(t8,C_fix(0));
t13=t11;
f_2618(t13,(C_word)C_i_symbolp(t12));}
else{
t12=t11;
f_2618(t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 369  err */
t11=((C_word*)t0)[4];
f_2286(t11,t1,lf[97]);}}
else{
t11=(C_word)C_eqp(t7,lf[81]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2664,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t13=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t13)){
t14=t12;
f_2664(t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2683,a[2]=t12,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 371  gensym */
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}}
else{
if(C_truep((C_word)C_i_symbolp(t7))){
t12=t2;
switch(t12){
case C_fix(0):
t13=(C_word)C_a_i_cons(&a,2,t7,t3);
/* eval.scm: 378  loop */
t34=t1;
t35=C_fix(0);
t36=t13;
t37=C_SCHEME_END_OF_LIST;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(1):
t13=(C_word)C_a_i_list(&a,2,t7,C_SCHEME_FALSE);
t14=(C_word)C_a_i_cons(&a,2,t13,t4);
/* eval.scm: 379  loop */
t34=t1;
t35=C_fix(1);
t36=t3;
t37=t14;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(2):
/* eval.scm: 380  err */
t13=((C_word*)t0)[4];
f_2286(t13,t1,lf[99]);
default:
t13=(C_word)C_a_i_list(&a,1,t7);
t14=(C_word)C_a_i_cons(&a,2,t13,t5);
/* eval.scm: 381  loop */
t34=t1;
t35=C_fix(3);
t36=t3;
t37=t4;
t38=t14;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;}}
else{
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2745,a[2]=t5,a[3]=t8,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t7,a[8]=t1,a[9]=((C_word*)t0)[4],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t7))){
t13=(C_word)C_i_length(t7);
t14=t12;
f_2745(t14,(C_word)C_eqp(C_fix(2),t13));}
else{
t13=t12;
f_2745(t13,C_SCHEME_FALSE);}}}}}}
else{
/* eval.scm: 351  err */
t7=((C_word*)t0)[4];
f_2286(t7,t1,lf[103]);}}}}

/* k2743 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_fcall f_2745(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2745,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
/* eval.scm: 384  err */
t3=((C_word*)t0)[9];
f_2286(t3,((C_word*)t0)[8],lf[100]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* eval.scm: 385  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2305(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
/* eval.scm: 386  err */
t3=((C_word*)t0)[9];
f_2286(t3,((C_word*)t0)[8],lf[101]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
/* eval.scm: 387  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2305(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
/* eval.scm: 388  err */
t2=((C_word*)t0)[9];
f_2286(t2,((C_word*)t0)[8],lf[102]);}}

/* k2681 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_ccall f_2683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2664(t3,t2);}

/* k2662 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_fcall f_2664(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
/* eval.scm: 373  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2305(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 374  err */
t2=((C_word*)t0)[2];
f_2286(t2,((C_word*)t0)[6],lf[98]);}}

/* k2616 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_fcall f_2618(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2618,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_2621(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[9],C_fix(0));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_2621(t6,t5);}}
else{
/* eval.scm: 368  err */
t2=((C_word*)t0)[2];
f_2286(t2,((C_word*)t0)[6],lf[96]);}}

/* k2619 in k2616 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_fcall f_2621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* eval.scm: 367  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2305(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k2598 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2581(t3,t2);}

/* k2579 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_fcall f_2581(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
/* eval.scm: 359  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2305(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 360  err */
t3=((C_word*)t0)[2];
f_2286(t3,((C_word*)t0)[5],lf[95]);}}

/* k2547 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_fcall f_2549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
/* eval.scm: 349  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2305(t3,((C_word*)t0)[4],C_fix(4),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k2526 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 322  ##sys#append */
t2=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k2317 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2323,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t3=t2;
f_2323(t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2462,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2464,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2521,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 333  reverse */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}}

/* k2519 in k2317 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2463 in k2317 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2464,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2517,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
/* eval.scm: 312  string->keyword */
t6=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k2515 in a2463 in k2317 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2517,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[90],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[92],t6);
t8=t3;
f_2491(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
t5=t3;
f_2491(t5,C_SCHEME_END_OF_LIST);}}

/* k2489 in k2515 in a2463 in k2317 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_fcall f_2491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2491,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[91],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t4));}

/* k2460 in k2317 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_ccall f_2462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2462,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[89],t2);
t4=((C_word*)t0)[2];
f_2323(t4,(C_word)C_a_i_list(&a,1,t3));}

/* k2321 in k2317 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_fcall f_2323(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2323,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2326,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t3=t2;
f_2326(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=t3;
f_2335(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t6=t3;
f_2335(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_2335(t5,C_SCHEME_FALSE);}}}}

/* k2333 in k2321 in k2317 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_fcall f_2335(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2335,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_caar(((C_word*)t0)[8]);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[85],((C_word*)((C_word*)t0)[7])[1],t3);
t5=(C_word)C_a_i_list(&a,2,t2,t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,lf[58],t7);
t9=((C_word*)t0)[5];
f_2326(t9,(C_word)C_a_i_list(&a,1,t8));}
else{
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[3]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2391,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 339  reverse */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[8]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2410,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2414,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 341  reverse */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[8]);}}}

/* k2412 in k2333 in k2321 in k2317 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2414,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* eval.scm: 341  ##sys#append */
t5=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k2408 in k2333 in k2321 in k2317 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2410,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[87],t3);
t5=((C_word*)t0)[2];
f_2326(t5,(C_word)C_a_i_list(&a,1,t4));}

/* k2389 in k2333 in k2321 in k2317 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_ccall f_2391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2391,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[3])[1],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[86],t3);
t5=((C_word*)t0)[2];
f_2326(t5,(C_word)C_a_i_list(&a,1,t4));}

/* k2324 in k2321 in k2317 in loop in ##sys#expand-extended-lambda-list in k1732 */
static void C_fcall f_2326(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 321  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* err in ##sys#expand-extended-lambda-list in k1732 */
static void C_fcall f_2286(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2286,NULL,3,t0,t1,t2);}
/* eval.scm: 311  errh */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k1732 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2240,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2246,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2246(t6,t1,t2);}

/* loop in ##sys#extended-lambda-list? in k1732 */
static void C_fcall f_2246(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2246,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,lf[79]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2265,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2265(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[80]);
t7=t5;
f_2265(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[81])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2263 in loop in ##sys#extended-lambda-list? in k1732 */
static void C_fcall f_2265(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 305  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2246(t3,((C_word*)t0)[4],t2);}}

/* macroexpand-1 in k1732 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2224r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2224r(t0,t1,t2,t3);}}

static void C_ccall f_2224r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
/* eval.scm: 285  ##sys#macroexpand-0 */
t6=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t5);}

/* macroexpand in k1732 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2188r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2188r(t0,t1,t2,t3);}}

static void C_ccall f_2188r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2197,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2197(t9,t1,t2);}

/* loop in macroexpand in k1732 */
static void C_fcall f_2197(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2197,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2203,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2209,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a2208 in loop in macroexpand in k1732 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2209,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* eval.scm: 281  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2197(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a2202 in loop in macroexpand in k1732 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2203,2,t0,t1);}
/* eval.scm: 279  ##sys#macroexpand-0 */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#macroexpand-1-local in k1732 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2181,4,t0,t1,t2,t3);}
/* eval.scm: 266  ##sys#macroexpand-0 */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* ##sys#interpreter-toplevel-macroexpand-hook in k1732 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2178,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#compiler-toplevel-macroexpand-hook in k1732 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2175,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#macroexpand-0 in k1732 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1805,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1954,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(0));
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_symbolp(t6))){
t8=(C_word)C_eqp(t6,lf[58]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2042,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 235  ##sys#check-syntax */
t10=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,lf[58],t7,lf[66]);}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2115,a[2]=t6,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_truep((C_word)C_eqp(t6,lf[69]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t6,lf[71]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(t7))){
t10=(C_word)C_slot(t7,C_fix(0));
t11=t9;
f_2115(t11,(C_word)C_i_pairp(t10));}
else{
t10=t9;
f_2115(t10,C_SCHEME_FALSE);}}
else{
t10=t9;
f_2115(t10,C_SCHEME_FALSE);}}}
else{
/* eval.scm: 258  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* eval.scm: 259  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k2113 in ##sys#macroexpand-0 in k1732 */
static void C_fcall f_2115(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2115,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 251  ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[69],((C_word*)t0)[6],lf[70]);}
else{
/* eval.scm: 257  expand */
t2=((C_word*)t0)[4];
f_1954(t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2119 in k2113 in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_a_i_list(&a,2,lf[67],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 253  append */
t8=*((C_word*)lf[68]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t2,t5,t6,t7);}

/* k2126 in k2119 in k2113 in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 252  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k2040 in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2042,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 238  ##sys#check-syntax */
t4=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[58],((C_word*)t0)[4],lf[65]);}
else{
/* eval.scm: 246  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k2052 in k2040 in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2096,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2102,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a2101 in k2052 in k2040 in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2102,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k2094 in k2052 in k2040 in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2096,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[59],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,3,lf[60],t6,((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[3],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 244  ##sys#map */
t9=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,*((C_word*)lf[63]+1),((C_word*)t0)[2]);}

/* k2074 in k2094 in k2052 in k2040 in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2076,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[61],t2);
/* eval.scm: 240  values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_TRUE);}

/* expand in ##sys#macroexpand-0 in k1732 */
static void C_fcall f_1954(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1954,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_assq(t3,((C_word*)t0)[3]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1968,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t4,C_fix(1));
t7=t6;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1974,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 219  ##sys#hash-table-ref */
t6=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[37]+1),t3);}}

/* k1972 in expand in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1974,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1982,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1982(t5,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
/* eval.scm: 228  values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* scan in k1972 in expand in ##sys#macroexpand-0 in k1732 */
static void C_fcall f_1982(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1982,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1996,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 225  call-handler */
t4=((C_word*)t0)[6];
f_1808(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 226  scan */
t6=t1;
t7=t3;
t1=t6;
t2=t7;
goto loop;}
else{
/* eval.scm: 227  ##sys#syntax-error-hook */
t3=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[57],((C_word*)t0)[3]);}}}

/* k1994 in scan in k1972 in expand in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 225  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k1966 in expand in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 218  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#macroexpand-0 in k1732 */
static void C_fcall f_1808(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1808,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1815,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1817,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
t7=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a1816 in call-handler in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1817,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1823,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1930,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a1929 in a1816 in call-handler in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1936,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a1941 in a1929 in a1816 in call-handler in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1942r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1942r(t0,t1,t2);}}

static void C_ccall f_1942r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1948,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g3739 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1947 in a1941 in a1929 in a1816 in call-handler in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1935 in a1929 in a1816 in call-handler in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1936,2,t0,t1);}
/* eval.scm: 215  handler */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1822 in a1816 in call-handler in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1823,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1829,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* g3739 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1828 in a1822 in a1816 in call-handler in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1837,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[4],lf[48]))){
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=t3;
f_1840(t5,(C_word)C_i_memv(lf[53],t4));}
else{
t4=t3;
f_1840(t4,C_SCHEME_FALSE);}}

/* k1838 in a1828 in a1822 in a1816 in call-handler in ##sys#macroexpand-0 in k1732 */
static void C_fcall f_1840(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1840,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1851,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1857,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_1857(t8,t3,t4);}
else{
t2=((C_word*)t0)[4];
f_1837(t2,((C_word*)t0)[5]);}}

/* copy in k1838 in a1828 in a1822 in a1816 in call-handler in ##sys#macroexpand-0 in k1732 */
static void C_fcall f_1857(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1857,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_equalp(lf[52],t3))){
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_u_i_car(t4);
t7=t5;
f_1876(t7,(C_word)C_i_stringp(t6));}
else{
t6=t5;
f_1876(t6,C_SCHEME_FALSE);}}
else{
t6=t5;
f_1876(t6,C_SCHEME_FALSE);}}}

/* k1874 in copy in k1838 in a1828 in a1822 in a1816 in call-handler in ##sys#macroexpand-0 in k1732 */
static void C_fcall f_1876(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1876,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1887,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* eval.scm: 209  string-append */
t5=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,lf[50],t3,lf[51],t4);}
else{
/* eval.scm: 213  copy */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1857(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* k1885 in k1874 in copy in k1838 in a1828 in a1822 in a1816 in call-handler in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1887,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[49],t3));}

/* k1849 in k1838 in a1828 in a1822 in a1816 in call-handler in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1837(t2,(C_word)C_a_i_record(&a,3,lf[48],((C_word*)t0)[2],t1));}

/* k1835 in a1828 in a1822 in a1816 in call-handler in ##sys#macroexpand-0 in k1732 */
static void C_fcall f_1837(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 193  ##sys#abort */
t2=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1813 in call-handler in ##sys#macroexpand-0 in k1732 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* undefine-macro! in k1732 */
static void C_ccall f_1796(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1796,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[44]);
t4=t2;
/* eval.scm: 178  ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[37]+1),t4,C_SCHEME_FALSE);}

/* macro? in k1732 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1778,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[43]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1788,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 175  ##sys#hash-table-ref */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[37]+1),t2);}

/* k1786 in macro? in k1732 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#copy-macro in k1732 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1768,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1776,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 171  ##sys#hash-table-ref */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[37]+1),t2);}

/* k1774 in ##sys#copy-macro in k1732 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 171  ##sys#hash-table-set! */
t2=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[37]+1),((C_word*)t0)[2],t1);}

/* ##sys#register-macro in k1732 */
static void C_ccall f_1752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1752,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1758,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 166  ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[37]+1),t2,t4);}

/* a1757 in ##sys#register-macro in k1732 */
static void C_ccall f_1758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1758,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
C_apply(4,0,t1,((C_word*)t0)[2],t3);}

/* ##sys#register-macro-2 in k1732 */
static void C_ccall f_1736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1736,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1742,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 160  ##sys#hash-table-set! */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[37]+1),t2,t4);}

/* a1741 in ##sys#register-macro-2 in k1732 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1742,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 162  handler */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* chicken-home */
static void C_ccall f_1695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1699,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 146  getenv */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[36]);}

/* k1697 in chicken-home */
static void C_ccall f_1699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1702,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(C_word)C_block_size(t1);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_subchar(t1,t4);
t6=(C_word)C_u_i_memq(t5,lf[32]);
t7=(C_truep(t6)?lf[33]:lf[34]);
/* eval.scm: 147  ##sys#string-append */
t8=*((C_word*)lf[35]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t2,t1,t7);}
else{
t3=t2;
f_1702(2,t3,C_SCHEME_FALSE);}}

/* k1700 in k1697 in chicken-home */
static void C_ccall f_1702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1702,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[925] = {
{"topleveleval.scm",(void*)C_eval_toplevel},
{"f_1734eval.scm",(void*)f_1734},
{"f_11305eval.scm",(void*)f_11305},
{"f_11309eval.scm",(void*)f_11309},
{"f_11333eval.scm",(void*)f_11333},
{"f_11327eval.scm",(void*)f_11327},
{"f_11317eval.scm",(void*)f_11317},
{"f_11315eval.scm",(void*)f_11315},
{"f_5940eval.scm",(void*)f_5940},
{"f_6039eval.scm",(void*)f_6039},
{"f_6119eval.scm",(void*)f_6119},
{"f_11299eval.scm",(void*)f_11299},
{"f_11295eval.scm",(void*)f_11295},
{"f_11291eval.scm",(void*)f_11291},
{"f_11287eval.scm",(void*)f_11287},
{"f_11277eval.scm",(void*)f_11277},
{"f_6638eval.scm",(void*)f_6638},
{"f_6643eval.scm",(void*)f_6643},
{"f_11255eval.scm",(void*)f_11255},
{"f_11247eval.scm",(void*)f_11247},
{"f_11249eval.scm",(void*)f_11249},
{"f_6650eval.scm",(void*)f_6650},
{"f_11237eval.scm",(void*)f_11237},
{"f_11240eval.scm",(void*)f_11240},
{"f_7003eval.scm",(void*)f_7003},
{"f_11183eval.scm",(void*)f_11183},
{"f_11197eval.scm",(void*)f_11197},
{"f_11233eval.scm",(void*)f_11233},
{"f_11229eval.scm",(void*)f_11229},
{"f_11217eval.scm",(void*)f_11217},
{"f_11221eval.scm",(void*)f_11221},
{"f_11191eval.scm",(void*)f_11191},
{"f_7722eval.scm",(void*)f_7722},
{"f_11062eval.scm",(void*)f_11062},
{"f_11099eval.scm",(void*)f_11099},
{"f_11108eval.scm",(void*)f_11108},
{"f_11127eval.scm",(void*)f_11127},
{"f_11131eval.scm",(void*)f_11131},
{"f_11117eval.scm",(void*)f_11117},
{"f_11114eval.scm",(void*)f_11114},
{"f_11065eval.scm",(void*)f_11065},
{"f_7725eval.scm",(void*)f_7725},
{"f_7783eval.scm",(void*)f_7783},
{"f_11060eval.scm",(void*)f_11060},
{"f_8118eval.scm",(void*)f_8118},
{"f_8122eval.scm",(void*)f_8122},
{"f_11056eval.scm",(void*)f_11056},
{"f_8125eval.scm",(void*)f_8125},
{"f_8129eval.scm",(void*)f_8129},
{"f_10959eval.scm",(void*)f_10959},
{"f_10965eval.scm",(void*)f_10965},
{"f_10981eval.scm",(void*)f_10981},
{"f_10984eval.scm",(void*)f_10984},
{"f_11019eval.scm",(void*)f_11019},
{"f_11022eval.scm",(void*)f_11022},
{"f_11006eval.scm",(void*)f_11006},
{"f_11009eval.scm",(void*)f_11009},
{"f_11016eval.scm",(void*)f_11016},
{"f_8812eval.scm",(void*)f_8812},
{"f_10931eval.scm",(void*)f_10931},
{"f_8815eval.scm",(void*)f_8815},
{"f_10888eval.scm",(void*)f_10888},
{"f_10910eval.scm",(void*)f_10910},
{"f_8818eval.scm",(void*)f_8818},
{"f_10691eval.scm",(void*)f_10691},
{"f_10697eval.scm",(void*)f_10697},
{"f_10713eval.scm",(void*)f_10713},
{"f_10789eval.scm",(void*)f_10789},
{"f_10846eval.scm",(void*)f_10846},
{"f_10792eval.scm",(void*)f_10792},
{"f_10819eval.scm",(void*)f_10819},
{"f_10752eval.scm",(void*)f_10752},
{"f_10771eval.scm",(void*)f_10771},
{"f_10743eval.scm",(void*)f_10743},
{"f_8821eval.scm",(void*)f_8821},
{"f_10588eval.scm",(void*)f_10588},
{"f_10598eval.scm",(void*)f_10598},
{"f_10611eval.scm",(void*)f_10611},
{"f_10627eval.scm",(void*)f_10627},
{"f_10665eval.scm",(void*)f_10665},
{"f_10663eval.scm",(void*)f_10663},
{"f_10655eval.scm",(void*)f_10655},
{"f_10609eval.scm",(void*)f_10609},
{"f_8824eval.scm",(void*)f_8824},
{"f_10535eval.scm",(void*)f_10535},
{"f_10545eval.scm",(void*)f_10545},
{"f_10548eval.scm",(void*)f_10548},
{"f_10553eval.scm",(void*)f_10553},
{"f_10578eval.scm",(void*)f_10578},
{"f_8827eval.scm",(void*)f_8827},
{"f_10465eval.scm",(void*)f_10465},
{"f_10475eval.scm",(void*)f_10475},
{"f_10478eval.scm",(void*)f_10478},
{"f_10525eval.scm",(void*)f_10525},
{"f_10489eval.scm",(void*)f_10489},
{"f_10511eval.scm",(void*)f_10511},
{"f_10497eval.scm",(void*)f_10497},
{"f_10493eval.scm",(void*)f_10493},
{"f_8830eval.scm",(void*)f_8830},
{"f_10346eval.scm",(void*)f_10346},
{"f_10350eval.scm",(void*)f_10350},
{"f_10353eval.scm",(void*)f_10353},
{"f_10356eval.scm",(void*)f_10356},
{"f_10447eval.scm",(void*)f_10447},
{"f_10363eval.scm",(void*)f_10363},
{"f_10386eval.scm",(void*)f_10386},
{"f_10400eval.scm",(void*)f_10400},
{"f_10398eval.scm",(void*)f_10398},
{"f_8833eval.scm",(void*)f_8833},
{"f_10054eval.scm",(void*)f_10054},
{"f_10264eval.scm",(void*)f_10264},
{"f_10268eval.scm",(void*)f_10268},
{"f_10289eval.scm",(void*)f_10289},
{"f_10331eval.scm",(void*)f_10331},
{"f_10067eval.scm",(void*)f_10067},
{"f_10255eval.scm",(void*)f_10255},
{"f_10259eval.scm",(void*)f_10259},
{"f_10238eval.scm",(void*)f_10238},
{"f_10242eval.scm",(void*)f_10242},
{"f_10227eval.scm",(void*)f_10227},
{"f_10219eval.scm",(void*)f_10219},
{"f_10208eval.scm",(void*)f_10208},
{"f_10174eval.scm",(void*)f_10174},
{"f_10155eval.scm",(void*)f_10155},
{"f_10128eval.scm",(void*)f_10128},
{"f_10085eval.scm",(void*)f_10085},
{"f_10081eval.scm",(void*)f_10081},
{"f_10057eval.scm",(void*)f_10057},
{"f_10065eval.scm",(void*)f_10065},
{"f_8836eval.scm",(void*)f_8836},
{"f_10044eval.scm",(void*)f_10044},
{"f_8839eval.scm",(void*)f_8839},
{"f_9798eval.scm",(void*)f_9798},
{"f_9953eval.scm",(void*)f_9953},
{"f_10024eval.scm",(void*)f_10024},
{"f_9969eval.scm",(void*)f_9969},
{"f_9967eval.scm",(void*)f_9967},
{"f_9811eval.scm",(void*)f_9811},
{"f_9937eval.scm",(void*)f_9937},
{"f_9899eval.scm",(void*)f_9899},
{"f_9860eval.scm",(void*)f_9860},
{"f_9801eval.scm",(void*)f_9801},
{"f_8842eval.scm",(void*)f_8842},
{"f_8846eval.scm",(void*)f_8846},
{"f_9795eval.scm",(void*)f_9795},
{"f_8868eval.scm",(void*)f_8868},
{"f_9228eval.scm",(void*)f_9228},
{"f_9653eval.scm",(void*)f_9653},
{"f_9771eval.scm",(void*)f_9771},
{"f_9774eval.scm",(void*)f_9774},
{"f_9761eval.scm",(void*)f_9761},
{"f_9656eval.scm",(void*)f_9656},
{"f_9660eval.scm",(void*)f_9660},
{"f_9671eval.scm",(void*)f_9671},
{"f_9314eval.scm",(void*)f_9314},
{"f_9634eval.scm",(void*)f_9634},
{"f_9638eval.scm",(void*)f_9638},
{"f_9647eval.scm",(void*)f_9647},
{"f_9645eval.scm",(void*)f_9645},
{"f_9317eval.scm",(void*)f_9317},
{"f_9628eval.scm",(void*)f_9628},
{"f_9320eval.scm",(void*)f_9320},
{"f_9622eval.scm",(void*)f_9622},
{"f_9323eval.scm",(void*)f_9323},
{"f_9613eval.scm",(void*)f_9613},
{"f_9620eval.scm",(void*)f_9620},
{"f_9603eval.scm",(void*)f_9603},
{"f_9588eval.scm",(void*)f_9588},
{"f_9592eval.scm",(void*)f_9592},
{"f_9597eval.scm",(void*)f_9597},
{"f_9601eval.scm",(void*)f_9601},
{"f_9566eval.scm",(void*)f_9566},
{"f_9570eval.scm",(void*)f_9570},
{"f_9575eval.scm",(void*)f_9575},
{"f_9579eval.scm",(void*)f_9579},
{"f_9586eval.scm",(void*)f_9586},
{"f_9540eval.scm",(void*)f_9540},
{"f_9546eval.scm",(void*)f_9546},
{"f_9550eval.scm",(void*)f_9550},
{"f_9564eval.scm",(void*)f_9564},
{"f_9553eval.scm",(void*)f_9553},
{"f_9560eval.scm",(void*)f_9560},
{"f_9524eval.scm",(void*)f_9524},
{"f_9530eval.scm",(void*)f_9530},
{"f_9538eval.scm",(void*)f_9538},
{"f_9487eval.scm",(void*)f_9487},
{"f_9491eval.scm",(void*)f_9491},
{"f_9496eval.scm",(void*)f_9496},
{"f_9500eval.scm",(void*)f_9500},
{"f_9522eval.scm",(void*)f_9522},
{"f_9518eval.scm",(void*)f_9518},
{"f_9514eval.scm",(void*)f_9514},
{"f_9503eval.scm",(void*)f_9503},
{"f_9510eval.scm",(void*)f_9510},
{"f_9461eval.scm",(void*)f_9461},
{"f_9467eval.scm",(void*)f_9467},
{"f_9471eval.scm",(void*)f_9471},
{"f_9485eval.scm",(void*)f_9485},
{"f_9474eval.scm",(void*)f_9474},
{"f_9481eval.scm",(void*)f_9481},
{"f_9448eval.scm",(void*)f_9448},
{"f_9422eval.scm",(void*)f_9422},
{"f_9426eval.scm",(void*)f_9426},
{"f_9431eval.scm",(void*)f_9431},
{"f_9435eval.scm",(void*)f_9435},
{"f_9446eval.scm",(void*)f_9446},
{"f_9442eval.scm",(void*)f_9442},
{"f_9406eval.scm",(void*)f_9406},
{"f_9412eval.scm",(void*)f_9412},
{"f_9420eval.scm",(void*)f_9420},
{"f_9394eval.scm",(void*)f_9394},
{"f_9400eval.scm",(void*)f_9400},
{"f_9404eval.scm",(void*)f_9404},
{"f_9385eval.scm",(void*)f_9385},
{"f_9389eval.scm",(void*)f_9389},
{"f_9326eval.scm",(void*)f_9326},
{"f_9336eval.scm",(void*)f_9336},
{"f_9361eval.scm",(void*)f_9361},
{"f_9373eval.scm",(void*)f_9373},
{"f_9379eval.scm",(void*)f_9379},
{"f_9367eval.scm",(void*)f_9367},
{"f_9342eval.scm",(void*)f_9342},
{"f_9348eval.scm",(void*)f_9348},
{"f_9352eval.scm",(void*)f_9352},
{"f_9355eval.scm",(void*)f_9355},
{"f_9359eval.scm",(void*)f_9359},
{"f_9334eval.scm",(void*)f_9334},
{"f_9239eval.scm",(void*)f_9239},
{"f_9249eval.scm",(void*)f_9249},
{"f_9252eval.scm",(void*)f_9252},
{"f_9266eval.scm",(void*)f_9266},
{"f_9284eval.scm",(void*)f_9284},
{"f_9253eval.scm",(void*)f_9253},
{"f_9230eval.scm",(void*)f_9230},
{"f_8889eval.scm",(void*)f_8889},
{"f_8933eval.scm",(void*)f_8933},
{"f_8936eval.scm",(void*)f_8936},
{"f_9213eval.scm",(void*)f_9213},
{"f_9217eval.scm",(void*)f_9217},
{"f_9221eval.scm",(void*)f_9221},
{"f_9018eval.scm",(void*)f_9018},
{"f_9024eval.scm",(void*)f_9024},
{"f_9196eval.scm",(void*)f_9196},
{"f_9202eval.scm",(void*)f_9202},
{"f_9031eval.scm",(void*)f_9031},
{"f_9034eval.scm",(void*)f_9034},
{"f_9037eval.scm",(void*)f_9037},
{"f_9191eval.scm",(void*)f_9191},
{"f_9046eval.scm",(void*)f_9046},
{"f_9049eval.scm",(void*)f_9049},
{"f_9064eval.scm",(void*)f_9064},
{"f_9082eval.scm",(void*)f_9082},
{"f_9145eval.scm",(void*)f_9145},
{"f_9098eval.scm",(void*)f_9098},
{"f_9103eval.scm",(void*)f_9103},
{"f_9107eval.scm",(void*)f_9107},
{"f_9110eval.scm",(void*)f_9110},
{"f_9122eval.scm",(void*)f_9122},
{"f_9125eval.scm",(void*)f_9125},
{"f_9113eval.scm",(void*)f_9113},
{"f_9086eval.scm",(void*)f_9086},
{"f_9068eval.scm",(void*)f_9068},
{"f_8914eval.scm",(void*)f_8914},
{"f_8919eval.scm",(void*)f_8919},
{"f_9071eval.scm",(void*)f_9071},
{"f_9055eval.scm",(void*)f_9055},
{"f_8953eval.scm",(void*)f_8953},
{"f_8958eval.scm",(void*)f_8958},
{"f_8961eval.scm",(void*)f_8961},
{"f_8966eval.scm",(void*)f_8966},
{"f_8973eval.scm",(void*)f_8973},
{"f_9013eval.scm",(void*)f_9013},
{"f_8976eval.scm",(void*)f_8976},
{"f_8988eval.scm",(void*)f_8988},
{"f_8997eval.scm",(void*)f_8997},
{"f_8991eval.scm",(void*)f_8991},
{"f_8979eval.scm",(void*)f_8979},
{"f_8982eval.scm",(void*)f_8982},
{"f_8944eval.scm",(void*)f_8944},
{"f_8938eval.scm",(void*)f_8938},
{"f_8892eval.scm",(void*)f_8892},
{"f_8898eval.scm",(void*)f_8898},
{"f_8886eval.scm",(void*)f_8886},
{"f_8870eval.scm",(void*)f_8870},
{"f_8884eval.scm",(void*)f_8884},
{"f_8881eval.scm",(void*)f_8881},
{"f_8874eval.scm",(void*)f_8874},
{"f_8851eval.scm",(void*)f_8851},
{"f_8860eval.scm",(void*)f_8860},
{"f_8855eval.scm",(void*)f_8855},
{"f_8420eval.scm",(void*)f_8420},
{"f_8557eval.scm",(void*)f_8557},
{"f_8562eval.scm",(void*)f_8562},
{"f_8780eval.scm",(void*)f_8780},
{"f_8761eval.scm",(void*)f_8761},
{"f_8707eval.scm",(void*)f_8707},
{"f_8578eval.scm",(void*)f_8578},
{"f_8583eval.scm",(void*)f_8583},
{"f_8602eval.scm",(void*)f_8602},
{"f_8528eval.scm",(void*)f_8528},
{"f_8534eval.scm",(void*)f_8534},
{"f_8466eval.scm",(void*)f_8466},
{"f_8470eval.scm",(void*)f_8470},
{"f_8478eval.scm",(void*)f_8478},
{"f_8501eval.scm",(void*)f_8501},
{"f_8423eval.scm",(void*)f_8423},
{"f_8430eval.scm",(void*)f_8430},
{"f_8435eval.scm",(void*)f_8435},
{"f_8439eval.scm",(void*)f_8439},
{"f_8464eval.scm",(void*)f_8464},
{"f_8453eval.scm",(void*)f_8453},
{"f_8457eval.scm",(void*)f_8457},
{"f_8446eval.scm",(void*)f_8446},
{"f_8384eval.scm",(void*)f_8384},
{"f_8406eval.scm",(void*)f_8406},
{"f_8376eval.scm",(void*)f_8376},
{"f_8322eval.scm",(void*)f_8322},
{"f_8326eval.scm",(void*)f_8326},
{"f_8329eval.scm",(void*)f_8329},
{"f_8332eval.scm",(void*)f_8332},
{"f_8335eval.scm",(void*)f_8335},
{"f_8338eval.scm",(void*)f_8338},
{"f_8341eval.scm",(void*)f_8341},
{"f_8344eval.scm",(void*)f_8344},
{"f_8347eval.scm",(void*)f_8347},
{"f_8350eval.scm",(void*)f_8350},
{"f_8301eval.scm",(void*)f_8301},
{"f_8305eval.scm",(void*)f_8305},
{"f_8308eval.scm",(void*)f_8308},
{"f_8277eval.scm",(void*)f_8277},
{"f_8283eval.scm",(void*)f_8283},
{"f_8293eval.scm",(void*)f_8293},
{"f_8154eval.scm",(void*)f_8154},
{"f_8212eval.scm",(void*)f_8212},
{"f_8263eval.scm",(void*)f_8263},
{"f_8222eval.scm",(void*)f_8222},
{"f_8224eval.scm",(void*)f_8224},
{"f_8248eval.scm",(void*)f_8248},
{"f_8234eval.scm",(void*)f_8234},
{"f_8195eval.scm",(void*)f_8195},
{"f_8160eval.scm",(void*)f_8160},
{"f_8176eval.scm",(void*)f_8176},
{"f_8182eval.scm",(void*)f_8182},
{"f_8173eval.scm",(void*)f_8173},
{"f_8135eval.scm",(void*)f_8135},
{"f_8139eval.scm",(void*)f_8139},
{"f_8102eval.scm",(void*)f_8102},
{"f_8104eval.scm",(void*)f_8104},
{"f_8108eval.scm",(void*)f_8108},
{"f_8064eval.scm",(void*)f_8064},
{"f_8071eval.scm",(void*)f_8071},
{"f_8078eval.scm",(void*)f_8078},
{"f_8020eval.scm",(void*)f_8020},
{"f_8053eval.scm",(void*)f_8053},
{"f_8040eval.scm",(void*)f_8040},
{"f_8017eval.scm",(void*)f_8017},
{"f_7898eval.scm",(void*)f_7898},
{"f_7992eval.scm",(void*)f_7992},
{"f_8002eval.scm",(void*)f_8002},
{"f_7990eval.scm",(void*)f_7990},
{"f_7919eval.scm",(void*)f_7919},
{"f_7943eval.scm",(void*)f_7943},
{"f_7962eval.scm",(void*)f_7962},
{"f_7937eval.scm",(void*)f_7937},
{"f_7790eval.scm",(void*)f_7790},
{"f_7800eval.scm",(void*)f_7800},
{"f_7805eval.scm",(void*)f_7805},
{"f_7832eval.scm",(void*)f_7832},
{"f_7865eval.scm",(void*)f_7865},
{"f_7826eval.scm",(void*)f_7826},
{"f_7727eval.scm",(void*)f_7727},
{"f_7731eval.scm",(void*)f_7731},
{"f_7739eval.scm",(void*)f_7739},
{"f_7759eval.scm",(void*)f_7759},
{"f_7683eval.scm",(void*)f_7683},
{"f_7715eval.scm",(void*)f_7715},
{"f_7701eval.scm",(void*)f_7701},
{"f_7284eval.scm",(void*)f_7284},
{"f_7559eval.scm",(void*)f_7559},
{"f_7568eval.scm",(void*)f_7568},
{"f_7594eval.scm",(void*)f_7594},
{"f_7596eval.scm",(void*)f_7596},
{"f_7629eval.scm",(void*)f_7629},
{"f_7619eval.scm",(void*)f_7619},
{"f_7614eval.scm",(void*)f_7614},
{"f_7308eval.scm",(void*)f_7308},
{"f_7318eval.scm",(void*)f_7318},
{"f_7452eval.scm",(void*)f_7452},
{"f_7533eval.scm",(void*)f_7533},
{"f_7464eval.scm",(void*)f_7464},
{"f_7479eval.scm",(void*)f_7479},
{"f_7499eval.scm",(void*)f_7499},
{"f_7497eval.scm",(void*)f_7497},
{"f_7483eval.scm",(void*)f_7483},
{"f_7475eval.scm",(void*)f_7475},
{"f_7394eval.scm",(void*)f_7394},
{"f_7412eval.scm",(void*)f_7412},
{"f_7420eval.scm",(void*)f_7420},
{"f_7408eval.scm",(void*)f_7408},
{"f_7367eval.scm",(void*)f_7367},
{"f_7330eval.scm",(void*)f_7330},
{"f_7354eval.scm",(void*)f_7354},
{"f_7350eval.scm",(void*)f_7350},
{"f_7342eval.scm",(void*)f_7342},
{"f_7333eval.scm",(void*)f_7333},
{"f_7287eval.scm",(void*)f_7287},
{"f_7302eval.scm",(void*)f_7302},
{"f_7296eval.scm",(void*)f_7296},
{"f_7235eval.scm",(void*)f_7235},
{"f_7241eval.scm",(void*)f_7241},
{"f_7255eval.scm",(void*)f_7255},
{"f_7258eval.scm",(void*)f_7258},
{"f_7265eval.scm",(void*)f_7265},
{"f_7229eval.scm",(void*)f_7229},
{"f_7198eval.scm",(void*)f_7198},
{"f_7202eval.scm",(void*)f_7202},
{"f_7227eval.scm",(void*)f_7227},
{"f_7205eval.scm",(void*)f_7205},
{"f_7223eval.scm",(void*)f_7223},
{"f_7208eval.scm",(void*)f_7208},
{"f_7215eval.scm",(void*)f_7215},
{"f_7185eval.scm",(void*)f_7185},
{"f_7191eval.scm",(void*)f_7191},
{"f_7171eval.scm",(void*)f_7171},
{"f_7182eval.scm",(void*)f_7182},
{"f_7151eval.scm",(void*)f_7151},
{"f_7157eval.scm",(void*)f_7157},
{"f_7164eval.scm",(void*)f_7164},
{"f_7083eval.scm",(void*)f_7083},
{"f_7146eval.scm",(void*)f_7146},
{"f_7087eval.scm",(void*)f_7087},
{"f_7090eval.scm",(void*)f_7090},
{"f_7108eval.scm",(void*)f_7108},
{"f_7114eval.scm",(void*)f_7114},
{"f_7006eval.scm",(void*)f_7006},
{"f_7080eval.scm",(void*)f_7080},
{"f_7073eval.scm",(void*)f_7073},
{"f_7040eval.scm",(void*)f_7040},
{"f_7042eval.scm",(void*)f_7042},
{"f_7055eval.scm",(void*)f_7055},
{"f_7009eval.scm",(void*)f_7009},
{"f_7013eval.scm",(void*)f_7013},
{"f_7033eval.scm",(void*)f_7033},
{"f_7019eval.scm",(void*)f_7019},
{"f_7029eval.scm",(void*)f_7029},
{"f_7022eval.scm",(void*)f_7022},
{"f_6843eval.scm",(void*)f_6843},
{"f_6948eval.scm",(void*)f_6948},
{"f_6965eval.scm",(void*)f_6965},
{"f_6973eval.scm",(void*)f_6973},
{"f_6865eval.scm",(void*)f_6865},
{"f_6870eval.scm",(void*)f_6870},
{"f_6909eval.scm",(void*)f_6909},
{"f_6896eval.scm",(void*)f_6896},
{"f_6852eval.scm",(void*)f_6852},
{"f_6846eval.scm",(void*)f_6846},
{"f_6787eval.scm",(void*)f_6787},
{"f_6796eval.scm",(void*)f_6796},
{"f_6834eval.scm",(void*)f_6834},
{"f_6814eval.scm",(void*)f_6814},
{"f_6758eval.scm",(void*)f_6758},
{"f_6765eval.scm",(void*)f_6765},
{"f_6775eval.scm",(void*)f_6775},
{"f_6652eval.scm",(void*)f_6652},
{"f_6656eval.scm",(void*)f_6656},
{"f_6748eval.scm",(void*)f_6748},
{"f_6752eval.scm",(void*)f_6752},
{"f_6665eval.scm",(void*)f_6665},
{"f_6734eval.scm",(void*)f_6734},
{"f_6730eval.scm",(void*)f_6730},
{"f_6668eval.scm",(void*)f_6668},
{"f_6717eval.scm",(void*)f_6717},
{"f_6720eval.scm",(void*)f_6720},
{"f_6723eval.scm",(void*)f_6723},
{"f_6671eval.scm",(void*)f_6671},
{"f_6676eval.scm",(void*)f_6676},
{"f_6710eval.scm",(void*)f_6710},
{"f_6689eval.scm",(void*)f_6689},
{"f_6692eval.scm",(void*)f_6692},
{"f_6612eval.scm",(void*)f_6612},
{"f_6633eval.scm",(void*)f_6633},
{"f_6616eval.scm",(void*)f_6616},
{"f_6630eval.scm",(void*)f_6630},
{"f_6619eval.scm",(void*)f_6619},
{"f_6627eval.scm",(void*)f_6627},
{"f_6622eval.scm",(void*)f_6622},
{"f_6576eval.scm",(void*)f_6576},
{"f_6584eval.scm",(void*)f_6584},
{"f_6554eval.scm",(void*)f_6554},
{"f_6167eval.scm",(void*)f_6167},
{"f_6509eval.scm",(void*)f_6509},
{"f_6504eval.scm",(void*)f_6504},
{"f_6169eval.scm",(void*)f_6169},
{"f_6503eval.scm",(void*)f_6503},
{"f_6173eval.scm",(void*)f_6173},
{"f_6437eval.scm",(void*)f_6437},
{"f_6452eval.scm",(void*)f_6452},
{"f_6455eval.scm",(void*)f_6455},
{"f_6458eval.scm",(void*)f_6458},
{"f_6464eval.scm",(void*)f_6464},
{"f_6467eval.scm",(void*)f_6467},
{"f_6473eval.scm",(void*)f_6473},
{"f_6176eval.scm",(void*)f_6176},
{"f_6428eval.scm",(void*)f_6428},
{"f_6419eval.scm",(void*)f_6419},
{"f_6422eval.scm",(void*)f_6422},
{"f_6182eval.scm",(void*)f_6182},
{"f_6404eval.scm",(void*)f_6404},
{"f_6376eval.scm",(void*)f_6376},
{"f_6400eval.scm",(void*)f_6400},
{"f_6396eval.scm",(void*)f_6396},
{"f_6392eval.scm",(void*)f_6392},
{"f_6185eval.scm",(void*)f_6185},
{"f_6193eval.scm",(void*)f_6193},
{"f_6363eval.scm",(void*)f_6363},
{"f_6197eval.scm",(void*)f_6197},
{"f_6348eval.scm",(void*)f_6348},
{"f_6221eval.scm",(void*)f_6221},
{"f_6225eval.scm",(void*)f_6225},
{"f_6339eval.scm",(void*)f_6339},
{"f_6233eval.scm",(void*)f_6233},
{"f_6237eval.scm",(void*)f_6237},
{"f_6333eval.scm",(void*)f_6333},
{"f_6240eval.scm",(void*)f_6240},
{"f_6243eval.scm",(void*)f_6243},
{"f_6248eval.scm",(void*)f_6248},
{"f_6258eval.scm",(void*)f_6258},
{"f_6304eval.scm",(void*)f_6304},
{"f_6313eval.scm",(void*)f_6313},
{"f_6317eval.scm",(void*)f_6317},
{"f_6270eval.scm",(void*)f_6270},
{"f_6277eval.scm",(void*)f_6277},
{"f_6288eval.scm",(void*)f_6288},
{"f_6299eval.scm",(void*)f_6299},
{"f_6292eval.scm",(void*)f_6292},
{"f_6282eval.scm",(void*)f_6282},
{"f_6261eval.scm",(void*)f_6261},
{"f_6268eval.scm",(void*)f_6268},
{"f_6230eval.scm",(void*)f_6230},
{"f_6207eval.scm",(void*)f_6207},
{"f_6198eval.scm",(void*)f_6198},
{"f_6188eval.scm",(void*)f_6188},
{"f_6121eval.scm",(void*)f_6121},
{"f_6131eval.scm",(void*)f_6131},
{"f_6046eval.scm",(void*)f_6046},
{"f_6058eval.scm",(void*)f_6058},
{"f_6071eval.scm",(void*)f_6071},
{"f_6053eval.scm",(void*)f_6053},
{"f_6041eval.scm",(void*)f_6041},
{"f_5957eval.scm",(void*)f_5957},
{"f_5970eval.scm",(void*)f_5970},
{"f_6003eval.scm",(void*)f_6003},
{"f_5984eval.scm",(void*)f_5984},
{"f_5960eval.scm",(void*)f_5960},
{"f_5943eval.scm",(void*)f_5943},
{"f_5951eval.scm",(void*)f_5951},
{"f_5955eval.scm",(void*)f_5955},
{"f_3704eval.scm",(void*)f_3704},
{"f_5688eval.scm",(void*)f_5688},
{"f_5692eval.scm",(void*)f_5692},
{"f_5905eval.scm",(void*)f_5905},
{"f_5881eval.scm",(void*)f_5881},
{"f_5882eval.scm",(void*)f_5882},
{"f_5893eval.scm",(void*)f_5893},
{"f_5899eval.scm",(void*)f_5899},
{"f_5897eval.scm",(void*)f_5897},
{"f_5838eval.scm",(void*)f_5838},
{"f_5841eval.scm",(void*)f_5841},
{"f_5844eval.scm",(void*)f_5844},
{"f_5847eval.scm",(void*)f_5847},
{"f_5848eval.scm",(void*)f_5848},
{"f_5859eval.scm",(void*)f_5859},
{"f_5863eval.scm",(void*)f_5863},
{"f_5867eval.scm",(void*)f_5867},
{"f_5871eval.scm",(void*)f_5871},
{"f_5874eval.scm",(void*)f_5874},
{"f_5796eval.scm",(void*)f_5796},
{"f_5799eval.scm",(void*)f_5799},
{"f_5802eval.scm",(void*)f_5802},
{"f_5803eval.scm",(void*)f_5803},
{"f_5814eval.scm",(void*)f_5814},
{"f_5818eval.scm",(void*)f_5818},
{"f_5822eval.scm",(void*)f_5822},
{"f_5825eval.scm",(void*)f_5825},
{"f_5761eval.scm",(void*)f_5761},
{"f_5764eval.scm",(void*)f_5764},
{"f_5765eval.scm",(void*)f_5765},
{"f_5776eval.scm",(void*)f_5776},
{"f_5780eval.scm",(void*)f_5780},
{"f_5783eval.scm",(void*)f_5783},
{"f_5733eval.scm",(void*)f_5733},
{"f_5734eval.scm",(void*)f_5734},
{"f_5745eval.scm",(void*)f_5745},
{"f_5748eval.scm",(void*)f_5748},
{"f_5714eval.scm",(void*)f_5714},
{"f_5724eval.scm",(void*)f_5724},
{"f_5662eval.scm",(void*)f_5662},
{"f_3932eval.scm",(void*)f_3932},
{"f_4035eval.scm",(void*)f_4035},
{"f_4091eval.scm",(void*)f_4091},
{"f_4120eval.scm",(void*)f_4120},
{"f_4126eval.scm",(void*)f_4126},
{"f_5495eval.scm",(void*)f_5495},
{"f_5482eval.scm",(void*)f_5482},
{"f_5443eval.scm",(void*)f_5443},
{"f_5432eval.scm",(void*)f_5432},
{"f_5394eval.scm",(void*)f_5394},
{"f_5388eval.scm",(void*)f_5388},
{"f_5342eval.scm",(void*)f_5342},
{"f_5364eval.scm",(void*)f_5364},
{"f_5372eval.scm",(void*)f_5372},
{"f_5354eval.scm",(void*)f_5354},
{"f_5336eval.scm",(void*)f_5336},
{"f_5312eval.scm",(void*)f_5312},
{"f_5319eval.scm",(void*)f_5319},
{"f_5281eval.scm",(void*)f_5281},
{"f_5284eval.scm",(void*)f_5284},
{"f_5287eval.scm",(void*)f_5287},
{"f_5306eval.scm",(void*)f_5306},
{"f_5304eval.scm",(void*)f_5304},
{"f_5294eval.scm",(void*)f_5294},
{"f_4879eval.scm",(void*)f_4879},
{"f_5216eval.scm",(void*)f_5216},
{"f_5227eval.scm",(void*)f_5227},
{"f_5221eval.scm",(void*)f_5221},
{"f_4891eval.scm",(void*)f_4891},
{"f_4896eval.scm",(void*)f_4896},
{"f_5205eval.scm",(void*)f_5205},
{"f_5199eval.scm",(void*)f_5199},
{"f_4903eval.scm",(void*)f_4903},
{"f_5161eval.scm",(void*)f_5161},
{"f_5167eval.scm",(void*)f_5167},
{"f_5191eval.scm",(void*)f_5191},
{"f_5138eval.scm",(void*)f_5138},
{"f_5144eval.scm",(void*)f_5144},
{"f_5629eval.scm",(void*)f_5629},
{"f_5160eval.scm",(void*)f_5160},
{"f_5156eval.scm",(void*)f_5156},
{"f_5116eval.scm",(void*)f_5116},
{"f_5122eval.scm",(void*)f_5122},
{"f_5134eval.scm",(void*)f_5134},
{"f_5097eval.scm",(void*)f_5097},
{"f_5103eval.scm",(void*)f_5103},
{"f_5069eval.scm",(void*)f_5069},
{"f_5075eval.scm",(void*)f_5075},
{"f_5050eval.scm",(void*)f_5050},
{"f_5056eval.scm",(void*)f_5056},
{"f_5022eval.scm",(void*)f_5022},
{"f_5028eval.scm",(void*)f_5028},
{"f_5003eval.scm",(void*)f_5003},
{"f_5009eval.scm",(void*)f_5009},
{"f_4975eval.scm",(void*)f_4975},
{"f_4981eval.scm",(void*)f_4981},
{"f_4956eval.scm",(void*)f_4956},
{"f_4962eval.scm",(void*)f_4962},
{"f_4932eval.scm",(void*)f_4932},
{"f_4938eval.scm",(void*)f_4938},
{"f_4913eval.scm",(void*)f_4913},
{"f_4919eval.scm",(void*)f_4919},
{"f_4541eval.scm",(void*)f_4541},
{"f_4866eval.scm",(void*)f_4866},
{"f_4550eval.scm",(void*)f_4550},
{"f_4860eval.scm",(void*)f_4860},
{"f_4854eval.scm",(void*)f_4854},
{"f_4556eval.scm",(void*)f_4556},
{"f_4838eval.scm",(void*)f_4838},
{"f_4791eval.scm",(void*)f_4791},
{"f_4792eval.scm",(void*)f_4792},
{"f_4796eval.scm",(void*)f_4796},
{"f_4808eval.scm",(void*)f_4808},
{"f_4833eval.scm",(void*)f_4833},
{"f_4799eval.scm",(void*)f_4799},
{"f_4715eval.scm",(void*)f_4715},
{"f_4776eval.scm",(void*)f_4776},
{"f_4718eval.scm",(void*)f_4718},
{"f_4724eval.scm",(void*)f_4724},
{"f_4760eval.scm",(void*)f_4760},
{"f_4727eval.scm",(void*)f_4727},
{"f_4728eval.scm",(void*)f_4728},
{"f_4744eval.scm",(void*)f_4744},
{"f_4748eval.scm",(void*)f_4748},
{"f_4752eval.scm",(void*)f_4752},
{"f_4756eval.scm",(void*)f_4756},
{"f_4648eval.scm",(void*)f_4648},
{"f_4694eval.scm",(void*)f_4694},
{"f_4651eval.scm",(void*)f_4651},
{"f_4657eval.scm",(void*)f_4657},
{"f_4658eval.scm",(void*)f_4658},
{"f_4674eval.scm",(void*)f_4674},
{"f_4678eval.scm",(void*)f_4678},
{"f_4682eval.scm",(void*)f_4682},
{"f_4599eval.scm",(void*)f_4599},
{"f_4627eval.scm",(void*)f_4627},
{"f_4602eval.scm",(void*)f_4602},
{"f_4603eval.scm",(void*)f_4603},
{"f_4619eval.scm",(void*)f_4619},
{"f_4623eval.scm",(void*)f_4623},
{"f_4565eval.scm",(void*)f_4565},
{"f_4566eval.scm",(void*)f_4566},
{"f_4582eval.scm",(void*)f_4582},
{"f_4432eval.scm",(void*)f_4432},
{"f_4446eval.scm",(void*)f_4446},
{"f_4450eval.scm",(void*)f_4450},
{"f_4459eval.scm",(void*)f_4459},
{"f_4492eval.scm",(void*)f_4492},
{"f_4500eval.scm",(void*)f_4500},
{"f_4465eval.scm",(void*)f_4465},
{"f_4468eval.scm",(void*)f_4468},
{"f_4484eval.scm",(void*)f_4484},
{"f_4475eval.scm",(void*)f_4475},
{"f_4483eval.scm",(void*)f_4483},
{"f_4520eval.scm",(void*)f_4520},
{"f_4528eval.scm",(void*)f_4528},
{"f_4507eval.scm",(void*)f_4507},
{"f_4519eval.scm",(void*)f_4519},
{"f_4440eval.scm",(void*)f_4440},
{"f_4324eval.scm",(void*)f_4324},
{"f_4383eval.scm",(void*)f_4383},
{"f_4386eval.scm",(void*)f_4386},
{"f_4389eval.scm",(void*)f_4389},
{"f_4390eval.scm",(void*)f_4390},
{"f_4394eval.scm",(void*)f_4394},
{"f_4397eval.scm",(void*)f_4397},
{"f_4361eval.scm",(void*)f_4361},
{"f_4364eval.scm",(void*)f_4364},
{"f_4365eval.scm",(void*)f_4365},
{"f_4369eval.scm",(void*)f_4369},
{"f_4267eval.scm",(void*)f_4267},
{"f_4270eval.scm",(void*)f_4270},
{"f_4273eval.scm",(void*)f_4273},
{"f_4276eval.scm",(void*)f_4276},
{"f_4277eval.scm",(void*)f_4277},
{"f_4284eval.scm",(void*)f_4284},
{"f_4257eval.scm",(void*)f_4257},
{"f_4223eval.scm",(void*)f_4223},
{"f_4217eval.scm",(void*)f_4217},
{"f_4218eval.scm",(void*)f_4218},
{"f_4141eval.scm",(void*)f_4141},
{"f_4201eval.scm",(void*)f_4201},
{"f_4199eval.scm",(void*)f_4199},
{"f_4191eval.scm",(void*)f_4191},
{"f_4183eval.scm",(void*)f_4183},
{"f_4175eval.scm",(void*)f_4175},
{"f_4167eval.scm",(void*)f_4167},
{"f_4159eval.scm",(void*)f_4159},
{"f_4151eval.scm",(void*)f_4151},
{"f_4092eval.scm",(void*)f_4092},
{"f_4081eval.scm",(void*)f_4081},
{"f_4079eval.scm",(void*)f_4079},
{"f_4068eval.scm",(void*)f_4068},
{"f_4066eval.scm",(void*)f_4066},
{"f_4058eval.scm",(void*)f_4058},
{"f_4050eval.scm",(void*)f_4050},
{"f_4042eval.scm",(void*)f_4042},
{"f_3950eval.scm",(void*)f_3950},
{"f_3960eval.scm",(void*)f_3960},
{"f_4009eval.scm",(void*)f_4009},
{"f_3994eval.scm",(void*)f_3994},
{"f_3989eval.scm",(void*)f_3989},
{"f_3990eval.scm",(void*)f_3990},
{"f_3966eval.scm",(void*)f_3966},
{"f_3969eval.scm",(void*)f_3969},
{"f_3970eval.scm",(void*)f_3970},
{"f_4025eval.scm",(void*)f_4025},
{"f_4016eval.scm",(void*)f_4016},
{"f_3944eval.scm",(void*)f_3944},
{"f_3926eval.scm",(void*)f_3926},
{"f_3920eval.scm",(void*)f_3920},
{"f_3914eval.scm",(void*)f_3914},
{"f_3861eval.scm",(void*)f_3861},
{"f_3865eval.scm",(void*)f_3865},
{"f_3912eval.scm",(void*)f_3912},
{"f_3880eval.scm",(void*)f_3880},
{"f_3889eval.scm",(void*)f_3889},
{"f_3749eval.scm",(void*)f_3749},
{"f_3761eval.scm",(void*)f_3761},
{"f_3755eval.scm",(void*)f_3755},
{"f_3707eval.scm",(void*)f_3707},
{"f_3713eval.scm",(void*)f_3713},
{"f_3831eval.scm",(void*)f_3831},
{"f_3698eval.scm",(void*)f_3698},
{"f_3657eval.scm",(void*)f_3657},
{"f_3676eval.scm",(void*)f_3676},
{"f_3688eval.scm",(void*)f_3688},
{"f_3691eval.scm",(void*)f_3691},
{"f_3694eval.scm",(void*)f_3694},
{"f_3684eval.scm",(void*)f_3684},
{"f_3663eval.scm",(void*)f_3663},
{"f_3597eval.scm",(void*)f_3597},
{"f_3601eval.scm",(void*)f_3601},
{"f_3609eval.scm",(void*)f_3609},
{"f_3551eval.scm",(void*)f_3551},
{"f_3557eval.scm",(void*)f_3557},
{"f_3576eval.scm",(void*)f_3576},
{"f_3567eval.scm",(void*)f_3567},
{"f_3496eval.scm",(void*)f_3496},
{"f_3500eval.scm",(void*)f_3500},
{"f_3508eval.scm",(void*)f_3508},
{"f_3451eval.scm",(void*)f_3451},
{"f_3455eval.scm",(void*)f_3455},
{"f_3464eval.scm",(void*)f_3464},
{"f_3436eval.scm",(void*)f_3436},
{"f_3376eval.scm",(void*)f_3376},
{"f_3431eval.scm",(void*)f_3431},
{"f_3379eval.scm",(void*)f_3379},
{"f_3285eval.scm",(void*)f_3285},
{"f_3374eval.scm",(void*)f_3374},
{"f_3288eval.scm",(void*)f_3288},
{"f_3343eval.scm",(void*)f_3343},
{"f_2802eval.scm",(void*)f_2802},
{"f_3240eval.scm",(void*)f_3240},
{"f_3235eval.scm",(void*)f_3235},
{"f_2804eval.scm",(void*)f_2804},
{"f_2987eval.scm",(void*)f_2987},
{"f_2993eval.scm",(void*)f_2993},
{"f_3027eval.scm",(void*)f_3027},
{"f_3199eval.scm",(void*)f_3199},
{"f_3185eval.scm",(void*)f_3185},
{"f_3192eval.scm",(void*)f_3192},
{"f_3157eval.scm",(void*)f_3157},
{"f_3039eval.scm",(void*)f_3039},
{"f_3044eval.scm",(void*)f_3044},
{"f_3057eval.scm",(void*)f_3057},
{"f_3109eval.scm",(void*)f_3109},
{"f_3091eval.scm",(void*)f_3091},
{"f_3102eval.scm",(void*)f_3102},
{"f_2807eval.scm",(void*)f_2807},
{"f_2889eval.scm",(void*)f_2889},
{"f_2979eval.scm",(void*)f_2979},
{"f_2967eval.scm",(void*)f_2967},
{"f_2900eval.scm",(void*)f_2900},
{"f_2965eval.scm",(void*)f_2965},
{"f_2957eval.scm",(void*)f_2957},
{"f_2908eval.scm",(void*)f_2908},
{"f_2951eval.scm",(void*)f_2951},
{"f_2955eval.scm",(void*)f_2955},
{"f_2918eval.scm",(void*)f_2918},
{"f_2922eval.scm",(void*)f_2922},
{"f_2943eval.scm",(void*)f_2943},
{"f_2941eval.scm",(void*)f_2941},
{"f_2916eval.scm",(void*)f_2916},
{"f_2912eval.scm",(void*)f_2912},
{"f_2904eval.scm",(void*)f_2904},
{"f_2819eval.scm",(void*)f_2819},
{"f_2838eval.scm",(void*)f_2838},
{"f_2849eval.scm",(void*)f_2849},
{"f_2857eval.scm",(void*)f_2857},
{"f_2845eval.scm",(void*)f_2845},
{"f_2283eval.scm",(void*)f_2283},
{"f_2305eval.scm",(void*)f_2305},
{"f_2745eval.scm",(void*)f_2745},
{"f_2683eval.scm",(void*)f_2683},
{"f_2664eval.scm",(void*)f_2664},
{"f_2618eval.scm",(void*)f_2618},
{"f_2621eval.scm",(void*)f_2621},
{"f_2600eval.scm",(void*)f_2600},
{"f_2581eval.scm",(void*)f_2581},
{"f_2549eval.scm",(void*)f_2549},
{"f_2528eval.scm",(void*)f_2528},
{"f_2319eval.scm",(void*)f_2319},
{"f_2521eval.scm",(void*)f_2521},
{"f_2464eval.scm",(void*)f_2464},
{"f_2517eval.scm",(void*)f_2517},
{"f_2491eval.scm",(void*)f_2491},
{"f_2462eval.scm",(void*)f_2462},
{"f_2323eval.scm",(void*)f_2323},
{"f_2335eval.scm",(void*)f_2335},
{"f_2414eval.scm",(void*)f_2414},
{"f_2410eval.scm",(void*)f_2410},
{"f_2391eval.scm",(void*)f_2391},
{"f_2326eval.scm",(void*)f_2326},
{"f_2286eval.scm",(void*)f_2286},
{"f_2240eval.scm",(void*)f_2240},
{"f_2246eval.scm",(void*)f_2246},
{"f_2265eval.scm",(void*)f_2265},
{"f_2224eval.scm",(void*)f_2224},
{"f_2188eval.scm",(void*)f_2188},
{"f_2197eval.scm",(void*)f_2197},
{"f_2209eval.scm",(void*)f_2209},
{"f_2203eval.scm",(void*)f_2203},
{"f_2181eval.scm",(void*)f_2181},
{"f_2178eval.scm",(void*)f_2178},
{"f_2175eval.scm",(void*)f_2175},
{"f_1805eval.scm",(void*)f_1805},
{"f_2115eval.scm",(void*)f_2115},
{"f_2121eval.scm",(void*)f_2121},
{"f_2128eval.scm",(void*)f_2128},
{"f_2042eval.scm",(void*)f_2042},
{"f_2054eval.scm",(void*)f_2054},
{"f_2102eval.scm",(void*)f_2102},
{"f_2096eval.scm",(void*)f_2096},
{"f_2076eval.scm",(void*)f_2076},
{"f_1954eval.scm",(void*)f_1954},
{"f_1974eval.scm",(void*)f_1974},
{"f_1982eval.scm",(void*)f_1982},
{"f_1996eval.scm",(void*)f_1996},
{"f_1968eval.scm",(void*)f_1968},
{"f_1808eval.scm",(void*)f_1808},
{"f_1817eval.scm",(void*)f_1817},
{"f_1930eval.scm",(void*)f_1930},
{"f_1942eval.scm",(void*)f_1942},
{"f_1948eval.scm",(void*)f_1948},
{"f_1936eval.scm",(void*)f_1936},
{"f_1823eval.scm",(void*)f_1823},
{"f_1829eval.scm",(void*)f_1829},
{"f_1840eval.scm",(void*)f_1840},
{"f_1857eval.scm",(void*)f_1857},
{"f_1876eval.scm",(void*)f_1876},
{"f_1887eval.scm",(void*)f_1887},
{"f_1851eval.scm",(void*)f_1851},
{"f_1837eval.scm",(void*)f_1837},
{"f_1815eval.scm",(void*)f_1815},
{"f_1796eval.scm",(void*)f_1796},
{"f_1778eval.scm",(void*)f_1778},
{"f_1788eval.scm",(void*)f_1788},
{"f_1768eval.scm",(void*)f_1768},
{"f_1776eval.scm",(void*)f_1776},
{"f_1752eval.scm",(void*)f_1752},
{"f_1758eval.scm",(void*)f_1758},
{"f_1736eval.scm",(void*)f_1736},
{"f_1742eval.scm",(void*)f_1742},
{"f_1695eval.scm",(void*)f_1695},
{"f_1699eval.scm",(void*)f_1699},
{"f_1702eval.scm",(void*)f_1702},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
