/* Generated from chicken-profile.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-07 01:29
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-07 on galinha (Linux)
   command line: chicken-profile.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -output-file chicken-profile.c
   used units: library eval extras srfi_1 srfi_13 posix utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[92];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_160)
static void C_ccall f_160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_163)
static void C_ccall f_163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_166)
static void C_ccall f_166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_169)
static void C_ccall f_169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_172)
static void C_ccall f_172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_175)
static void C_ccall f_175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_178)
static void C_ccall f_178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_234)
static void C_fcall f_234(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_473)
static void C_fcall f_473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_467)
static void C_ccall f_467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_659)
static void C_ccall f_659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_663)
static void C_ccall f_663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_667)
static void C_ccall f_667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_624)
static void C_fcall f_624(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_634)
static void C_ccall f_634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_426)
static void C_ccall f_426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_409)
static void C_ccall f_409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_402)
static void C_ccall f_402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_348)
static void C_ccall f_348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_341)
static void C_fcall f_341(C_word t0) C_noret;
C_noret_decl(f_329)
static void C_fcall f_329(C_word t0) C_noret;
C_noret_decl(f_340)
static void C_ccall f_340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_333)
static void C_ccall f_333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_308)
static void C_fcall f_308(C_word t0,C_word t1) C_noret;
C_noret_decl(f_328)
static void C_ccall f_328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_312)
static void C_ccall f_312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_289)
static void C_fcall f_289(C_word t0,C_word t1) C_noret;
C_noret_decl(f_251)
static void C_ccall f_251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_269)
static void C_ccall f_269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_277)
static void C_ccall f_277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_281)
static void C_ccall f_281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_267)
static void C_ccall f_267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_254)
static void C_ccall f_254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_244)
static void C_fcall f_244(C_word t0,C_word t1) C_noret;
C_noret_decl(f_883)
static void C_ccall f_883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_886)
static void C_ccall f_886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1090)
static void C_fcall f_1090(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1097)
static void C_fcall f_1097(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1070)
static void C_ccall f_1070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_892)
static void C_ccall f_892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1058)
static void C_ccall f_1058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1062)
static void C_ccall f_1062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_895)
static void C_fcall f_895(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1038)
static void C_ccall f_1038(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_899)
static void C_ccall f_899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_908)
static void C_ccall f_908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_960)
static void C_ccall f_960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_968)
static void C_ccall f_968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_911)
static void C_ccall f_911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_928)
static void C_ccall f_928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_946)
static void C_ccall f_946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_938)
static void C_ccall f_938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_931)
static void C_ccall f_931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_913)
static void C_ccall f_913(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_925)
static void C_ccall f_925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1138)
static void C_ccall f_1138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_823)
static void C_fcall f_823(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_834)
static void C_ccall f_834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_866)
static void C_ccall f_866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_870)
static void C_ccall f_870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_858)
static void C_ccall f_858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_846)
static void C_ccall f_846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_842)
static void C_ccall f_842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_743)
static void C_ccall f_743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_743)
static void C_ccall f_743r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_775)
static void C_fcall f_775(C_word t0,C_word t1) C_noret;
C_noret_decl(f_770)
static void C_fcall f_770(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_745)
static void C_fcall f_745(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_752)
static void C_ccall f_752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_676)
static void C_ccall f_676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_680)
static void C_ccall f_680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_690)
static void C_ccall f_690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_692)
static void C_fcall f_692(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_733)
static void C_ccall f_733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_719)
static void C_ccall f_719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_717)
static void C_ccall f_717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_702)
static void C_ccall f_702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_709)
static void C_ccall f_709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_683)
static void C_ccall f_683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_592)
static void C_ccall f_592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_600)
static void C_ccall f_600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_604)
static void C_ccall f_604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_563)
static void C_ccall f_563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_534)
static void C_ccall f_534(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_499)
static void C_ccall f_499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_187)
static void C_fcall f_187(C_word t0) C_noret;
C_noret_decl(f_198)
static void C_ccall f_198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_191)
static void C_ccall f_191(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_234)
static void C_fcall trf_234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_234(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_234(t0,t1,t2);}

C_noret_decl(trf_473)
static void C_fcall trf_473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_473(t0,t1);}

C_noret_decl(trf_624)
static void C_fcall trf_624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_624(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_624(t0,t1,t2);}

C_noret_decl(trf_341)
static void C_fcall trf_341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_341(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_341(t0);}

C_noret_decl(trf_329)
static void C_fcall trf_329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_329(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_329(t0);}

C_noret_decl(trf_308)
static void C_fcall trf_308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_308(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_308(t0,t1);}

C_noret_decl(trf_289)
static void C_fcall trf_289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_289(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_289(t0,t1);}

C_noret_decl(trf_244)
static void C_fcall trf_244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_244(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_244(t0,t1);}

C_noret_decl(trf_1090)
static void C_fcall trf_1090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1090(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1090(t0,t1);}

C_noret_decl(trf_1097)
static void C_fcall trf_1097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1097(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1097(t0,t1);}

C_noret_decl(trf_895)
static void C_fcall trf_895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_895(t0,t1);}

C_noret_decl(trf_823)
static void C_fcall trf_823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_823(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_823(t0,t1,t2);}

C_noret_decl(trf_775)
static void C_fcall trf_775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_775(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_775(t0,t1);}

C_noret_decl(trf_770)
static void C_fcall trf_770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_770(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_770(t0,t1,t2);}

C_noret_decl(trf_745)
static void C_fcall trf_745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_745(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_745(t0,t1,t2,t3);}

C_noret_decl(trf_692)
static void C_fcall trf_692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_692(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_692(t0,t1,t2);}

C_noret_decl(trf_187)
static void C_fcall trf_187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_187(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_187(t0);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(396)){
C_save(t1);
C_rereclaim2(396*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,92);
lf[8]=C_h_intern(&lf[8],4,"exit");
lf[9]=C_h_intern(&lf[9],7,"display");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\001\242)\012 -no-unused                remove procedures that are never called\012 -top "
"N                    display only the top N entries\012 -help                     s"
"how this text and exit\012 -version                  show version and exit\012 -releas"
"e                  show release number and exit\012\012 FILENAME defaults to the `PROF"
"ILE.<number>\047, selecting the one with\012 the highest modification time, in case mu"
"ltiple profiles exist.\012");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\001\315Usage: chicken-profile [FILENAME | OPTION] ...\012\012 -sort-by-calls            "
"sort output by call frequency\012 -sort-by-time             sort output by procedur"
"e execution time\012 -sort-by-avg              sort output by average procedure exe"
"cution time\012 -sort-by-name             sort output alphabetically by procedure n"
"ame\012 -decimals DDD             set number of decimals for seconds, average and\012 "
"                          percent columns (three digits, default: ");
lf[14]=C_h_intern(&lf[14],19,"\003sysprint-to-string");
lf[19]=C_h_intern(&lf[19],8,"string<\077");
lf[20]=C_h_intern(&lf[20],14,"symbol->string");
lf[22]=C_h_intern(&lf[22],17,"hash-table->alist");
lf[23]=C_h_intern(&lf[23],4,"read");
lf[24]=C_h_intern(&lf[24],15,"hash-table-set!");
lf[25]=C_h_intern(&lf[25],3,"map");
lf[26]=C_h_intern(&lf[26],22,"hash-table-ref/default");
lf[27]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\000\376\003\000\000\002\376\377\001\000\000\000\000\376\377\016");
lf[28]=C_h_intern(&lf[28],15,"make-hash-table");
lf[29]=C_h_intern(&lf[29],3,"eq\077");
lf[31]=C_h_intern(&lf[31],13,"string-append");
lf[32]=C_h_intern(&lf[32],11,"make-string");
lf[33]=C_h_intern(&lf[33],9,"\003syserror");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[38]=C_h_intern(&lf[38],9,"substring");
lf[39]=C_h_intern(&lf[39],8,"truncate");
lf[40]=C_h_intern(&lf[40],4,"expt");
lf[41]=C_h_intern(&lf[41],25,"\003sysimplicit-exit-handler");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\011procedure");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005calls");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\007seconds");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\007average");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\007percent");
lf[47]=C_h_intern(&lf[47],5,"print");
lf[48]=C_h_intern(&lf[48],11,"string-join");
lf[49]=C_h_intern(&lf[49],12,"\003sysfor-each");
lf[50]=C_h_intern(&lf[50],6,"reduce");
lf[51]=C_h_intern(&lf[51],1,"+");
lf[52]=C_h_intern(&lf[52],3,"max");
lf[53]=C_h_intern(&lf[53],7,"\003sysmap");
lf[54]=C_h_intern(&lf[54],13,"string-length");
lf[55]=C_h_intern(&lf[55],4,"fold");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\010overflow");
lf[57]=C_h_intern(&lf[57],28,"\003syssymbol->qualified-string");
lf[58]=C_h_intern(&lf[58],6,"remove");
lf[59]=C_h_intern(&lf[59],4,"take");
lf[60]=C_h_intern(&lf[60],4,"sort");
lf[61]=C_h_intern(&lf[61],6,"append");
lf[62]=C_h_intern(&lf[62],20,"with-input-from-file");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\011reading `");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\006\047 ...\012");
lf[65]=C_h_intern(&lf[65],5,"error");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\021no PROFILEs found");
lf[67]=C_h_intern(&lf[67],22,"file-modification-time");
lf[68]=C_h_intern(&lf[68],4,"glob");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\011PROFILE.*");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\032missing argument to option");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid argument to option");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\032chicken-profile - Version ");
lf[73]=C_h_intern(&lf[73],15,"chicken-version");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\012-no-unused");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\004-top");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\016-sort-by-calls");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-time");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\014-sort-by-avg");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-name");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\011-decimals");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[91]=C_h_intern(&lf[91],22,"command-line-arguments");
C_register_lf2(lf,92,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_160,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k158 */
static void C_ccall f_160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_163,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k161 in k158 */
static void C_ccall f_163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_166,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k164 in k161 in k158 */
static void C_ccall f_166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_169,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k167 in k164 in k161 in k158 */
static void C_ccall f_169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_172,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_175,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_178,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_178,2,t0,t1);}
t2=lf[0]=C_SCHEME_FALSE;;
t3=lf[1]=C_SCHEME_FALSE;;
t4=lf[2]=C_SCHEME_FALSE;;
t5=lf[3]=C_fix(3);;
t6=lf[4]=C_fix(3);;
t7=lf[5]=C_fix(3);;
t8=lf[6]=C_fix(0);;
t9=C_mutate(&lf[7],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_187,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[15],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_499,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[16],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_534,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[17],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_563,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[18],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_592,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[0],lf[16]);
t15=C_mutate(&lf[21],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_676,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[30],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_743,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[35],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_823,tmp=(C_word)a,a+=2,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1132,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1142,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 241  command-line-arguments */
t20=C_retrieve(lf[91]);
((C_proc2)C_retrieve_proc(t20))(2,t20,t19);}

/* k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1142,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_234,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_234(t5,((C_word*)t0)[2],t1);}

/* loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_234(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[41],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_234,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_244,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(lf[1])){
t4=t3;
f_244(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_251,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 80   glob */
t5=C_retrieve(lf[68]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[69]);}}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_289,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_308,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_329,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_341,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_348,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_equalp(t3,lf[74]))){
/* g1129 */
f_341(t11);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[75]))){
/* g1129 */
f_341(t11);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[76]))){
/* g1129 */
f_341(t11);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[77]))){
/* g1228 */
f_329(t11);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[78]))){
/* g1228 */
f_329(t11);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[79]))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_402,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_409,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 105  chicken-version */
t14=C_retrieve(lf[73]);
((C_proc2)C_retrieve_proc(t14))(2,t14,t13);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[80]))){
t12=lf[2]=C_SCHEME_TRUE;;
t13=t11;
f_348(2,t13,t12);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[81]))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_426,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* next-number24 */
t13=t8;
f_308(t13,t12);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[82]))){
t12=C_mutate(&lf[0],lf[15]);
t13=t11;
f_348(2,t13,t12);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[83]))){
t12=C_mutate(&lf[0],lf[16]);
t13=t11;
f_348(2,t13,t12);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[84]))){
t12=C_mutate(&lf[0],lf[17]);
t13=t11;
f_348(2,t13,t12);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[85]))){
t12=C_mutate(&lf[0],lf[18]);
t13=t11;
f_348(2,t13,t12);}
else{
if(C_truep((C_word)C_i_equalp(t3,lf[86]))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_467,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* next-arg23 */
t13=t7;
f_289(t13,t12);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_473,a[2]=t3,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_i_string_length(t3);
if(C_truep((C_word)C_i_greaterp(t13,C_fix(1)))){
t14=(C_word)C_i_string_ref(t3,C_fix(0));
t15=t12;
f_473(t15,(C_word)C_eqp(C_make_character(45),t14));}
else{
t14=t12;
f_473(t14,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}

/* k471 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_473(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[90],((C_word*)t0)[2]);}
else{
if(C_truep(lf[1])){
/* print-usage */
f_187(((C_word*)t0)[3]);}
else{
t2=C_mutate(&lf[1],((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_348(2,t3,t2);}}}

/* k465 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_467,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_nequalp(t2,C_fix(3)))){
t3=C_mutate(&lf[87],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_624,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_659,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 155  arg-digit */
t5=C_retrieve2(lf[87],"arg-digit");
f_624(t5,t4,C_fix(0));}
else{
/* chicken-profile.scm: 158  error */
t3=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[89],t1);}}

/* k657 in k465 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_659,2,t0,t1);}
t2=C_mutate(&lf[3],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_663,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 156  arg-digit */
t4=C_retrieve2(lf[87],"arg-digit");
f_624(t4,t3,C_fix(1));}

/* k661 in k657 in k465 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_663,2,t0,t1);}
t2=C_mutate(&lf[4],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_667,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 157  arg-digit */
t4=C_retrieve2(lf[87],"arg-digit");
f_624(t4,t3,C_fix(2));}

/* k665 in k661 in k657 in k465 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[5],t1);
t3=((C_word*)t0)[2];
f_348(2,t3,t2);}

/* arg-digit in k465 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_624(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_624,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_a_i_minus(&a,2,t4,C_fix(48));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_634,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 152  <= */
C_less_or_equal_p(5,0,t6,C_fix(0),t5,C_fix(9));}

/* k632 in arg-digit in k465 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_nequalp(((C_word*)t0)[4],C_fix(9));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_fix(8):((C_word*)t0)[4]));}
else{
/* chicken-profile.scm: 154  error */
t2=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[88],((C_word*)t0)[2]);}}

/* k424 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[6],t1);
t3=((C_word*)t0)[2];
f_348(2,t3,t2);}

/* k407 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 105  print */
t2=*((C_word*)lf[47]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k400 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 106  exit */
t2=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k346 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 118  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_234(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* g11 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_341(C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_341,NULL,1,t1);}
/* chicken-profile.scm: 100  print-usage */
f_187(t1);}

/* g12 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_329(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_329,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_333,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_340,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 102  chicken-version */
t4=C_retrieve(lf[73]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k338 in g12 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 102  print */
t2=*((C_word*)lf[47]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[72],t1);}

/* k331 in g12 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 103  exit */
t2=C_retrieve(lf[8]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* next-number in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_308(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_308,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_312,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_328,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 97   next-arg */
t4=((C_word*)t0)[2];
f_289(t4,t3);}

/* k326 in next-number in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 97   string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k310 in next-number in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_greaterp(t1,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* chicken-profile.scm: 98   error */
t3=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],lf[71],((C_word*)t0)[2]);}}

/* next-arg in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_289,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
/* chicken-profile.scm: 92   error */
t2=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[70],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k249 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_254,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
/* chicken-profile.scm: 82   error */
t3=*((C_word*)lf[65]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[66]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_267,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_269,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 83   sort */
t5=C_retrieve(lf[60]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t1,t4);}}

/* a268 in k249 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_269,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_277,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 85   file-modification-time */
t5=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k275 in a268 in k249 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_281,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 86   file-modification-time */
t3=C_retrieve(lf[67]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k279 in k275 in a268 in k249 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_greaterp(((C_word*)t0)[2],t1));}

/* k265 in k249 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_254(2,t2,(C_word)C_i_car(t1));}

/* k252 in k249 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[1],t1);
t3=((C_word*)t0)[2];
f_244(t3,t2);}

/* k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_244(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_244,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_883,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 191  print */
t4=*((C_word*)lf[47]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[63],lf[1],lf[64]);}

/* k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_886,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 192  with-input-from-file */
t3=C_retrieve(lf[62]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[1],lf[21]);}

/* k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_889,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1121,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 193  fold */
t4=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,C_fix(0),t1);}

/* a1120 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1121,4,t0,t1,t2,t3);}
t4=(C_word)C_i_caddr(t2);
/* chicken-profile.scm: 194  max */
t5=*((C_word*)lf[52]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_892,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1070,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1072,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1071 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_1072(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1072,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_caddr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1090,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_greaterp(t3,C_fix(0));
t7=t5;
f_1090(t7,(C_truep(t6)?(C_word)C_a_i_divide(&a,2,t4,t3):C_SCHEME_FALSE));}
else{
t6=t5;
f_1090(t6,C_SCHEME_FALSE);}}

/* k1088 in a1071 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_1090(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1090,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1097,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_greaterp(((C_word*)t0)[3],C_fix(0)))){
t4=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t5=t3;
f_1097(t5,(C_word)C_a_i_times(&a,2,t4,C_fix(100)));}
else{
t4=t3;
f_1097(t4,C_SCHEME_FALSE);}}

/* k1095 in k1088 in a1071 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_1097(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1097,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t2);
/* chicken-profile.scm: 198  append */
t4=*((C_word*)lf[61]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1068 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_1070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 197  sort */
t2=C_retrieve(lf[60]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[0]);}

/* k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_892,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_895,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1058,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_length(((C_word*)t3)[1]);
/* chicken-profile.scm: 207  < */
C_lessp(5,0,t5,C_fix(0),lf[6],t6);}

/* k1056 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1058,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 208  take */
t3=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],lf[6]);}
else{
t2=((C_word*)t0)[2];
f_895(t2,C_SCHEME_UNDEFINED);}}

/* k1060 in k1056 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_1062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_895(t3,t2);}

/* k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_895,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_978,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1036,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1038,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 219  remove */
t6=C_retrieve(lf[58]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)((C_word*)t0)[3])[1]);}

/* a1037 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_1038(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1038,3,t0,t1,t2);}
if(C_truep((C_word)C_i_cadr(t2))){
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_zerop(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?lf[2]:C_SCHEME_FALSE));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1034 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_1036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a977 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_978(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_978,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_caddr(t2);
t5=(C_word)C_i_cadddr(t2);
t6=(C_word)C_i_list_ref(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_998,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_car(t2);
/* chicken-profile.scm: 214  ##sys#symbol->qualified-string */
t9=C_retrieve(lf[57]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}

/* k996 in a977 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1002,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
/* chicken-profile.scm: 215  number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_1002(2,t3,lf[56]);}}

/* k1000 in k996 in a977 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
/* chicken-profile.scm: 216  format-real */
f_823(t2,t3,lf[3]);}

/* k1004 in k1000 in k996 in a977 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1010,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
/* chicken-profile.scm: 217  format-real */
f_823(t2,t3,lf[4]);}

/* k1008 in k1004 in k1000 in k996 in a977 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1014,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-profile.scm: 218  format-real */
f_823(t2,((C_word*)t0)[2],lf[5]);}

/* k1012 in k1008 in k1004 in k1000 in k996 in a977 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_1014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1014,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k897 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_899,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_a_i_list(&a,5,lf[42],lf[43],lf[44],lf[45],lf[46]);
t4=(C_word)C_a_i_list(&a,5,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_908,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm: 227  make-string */
t6=*((C_word*)lf[32]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_fix(2),C_make_character(32));}

/* k906 in k897 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_960,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_a_i_list(&a,5,C_fix(0),C_fix(0),C_fix(0),C_fix(0),C_fix(0));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
/* chicken-profile.scm: 228  fold */
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t2,t3,t4,t5);}

/* a959 in k906 in k897 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_960,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_968,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[54]+1),t2);}

/* k966 in a959 in k906 in k897 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 230  map */
t2=*((C_word*)lf[25]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[52]+1),t1,((C_word*)t0)[2]);}

/* k909 in k906 in k897 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_913,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_928,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-profile.scm: 235  print-row */
t4=t2;
f_913(3,t4,t3,((C_word*)t0)[2]);}

/* k926 in k909 in k906 in k897 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_931,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_938,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_946,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 236  reduce */
t5=C_retrieve(lf[50]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,*((C_word*)lf[51]+1),C_fix(0),((C_word*)t0)[2]);}

/* k944 in k926 in k909 in k906 in k897 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_946,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t4=(C_word)C_a_i_times(&a,2,C_fix(2),t3);
t5=(C_word)C_a_i_plus(&a,2,t1,t4);
/* chicken-profile.scm: 236  make-string */
t6=*((C_word*)lf[32]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],t5,C_make_character(45));}

/* k936 in k926 in k909 in k906 in k897 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 236  print */
t2=*((C_word*)lf[47]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k929 in k926 in k909 in k906 in k897 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* print-row in k909 in k906 in k897 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_913(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_913,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_921,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_925,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 234  map */
t5=*((C_word*)lf[25]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[30],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k923 in print-row in k909 in k906 in k897 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 234  string-join */
t2=C_retrieve(lf[48]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k919 in print-row in k909 in k906 in k897 in k893 in k890 in k887 in k884 in k881 in k242 in loop in k1140 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 234  print */
t2=*((C_word*)lf[47]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1130 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1135,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1138,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[41]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1136 in k1130 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_1138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1133 in k1130 in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* format-real in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_823(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_823,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_877,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 179  truncate */
t5=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k875 in format-real in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_877,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_834,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm: 181  number->string */
C_number_to_string(3,0,t3,t2);}

/* k832 in k875 in format-real in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_834,2,t0,t1);}
t2=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(0));
t3=(C_truep(t2)?lf[36]:lf[37]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_842,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_846,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_858,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_866,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 187  - */
C_minus(5,0,t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(-1));}

/* k864 in k832 in k875 in format-real in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_870,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 187  expt */
t3=*((C_word*)lf[40]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(10),((C_word*)t0)[2]);}

/* k868 in k864 in k832 in k875 in format-real in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_870,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],t1);
/* chicken-profile.scm: 186  truncate */
t3=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k856 in k832 in k875 in format-real in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(t1);
/* chicken-profile.scm: 184  number->string */
C_number_to_string(3,0,((C_word*)t0)[2],t2);}

/* k844 in k832 in k875 in format-real in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_846,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* chicken-profile.scm: 183  substring */
t3=*((C_word*)lf[38]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t1,C_fix(1),t2);}

/* k840 in k832 in k875 in format-real in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 180  string-append */
t2=*((C_word*)lf[31]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* format-string in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_743(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_743r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_743r(t0,t1,t2,t3,t4);}}

static void C_ccall f_743r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_745,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_770,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_775,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-right7383 */
t8=t7;
f_775(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-padc7481 */
t10=t6;
f_770(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body7176 */
t12=t5;
f_745(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[34],t11);}}}}

/* def-right73 in format-string in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_775,NULL,2,t0,t1);}
/* def-padc7481 */
t2=((C_word*)t0)[2];
f_770(t2,t1,C_SCHEME_FALSE);}

/* def-padc74 in format-string in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_770(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_770,NULL,3,t0,t1,t2);}
/* body7176 */
t3=((C_word*)t0)[2];
f_745(t3,t1,t2,C_make_character(32));}

/* body71 in format-string in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_745(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_745,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_752,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[2],t4);
t7=(C_word)C_i_fixnum_max(C_fix(0),t6);
/* chicken-profile.scm: 173  make-string */
t8=*((C_word*)lf[32]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t7,t3);}

/* k750 in body71 in format-string in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* chicken-profile.scm: 175  string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
/* chicken-profile.scm: 176  string-append */
t2=*((C_word*)lf[31]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}}

/* read-profile in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_680,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 161  make-hash-table */
t3=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,*((C_word*)lf[29]+1));}

/* k678 in read-profile in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_683,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_690,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 162  read */
t4=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k688 in k678 in read-profile in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_690,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_692,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_692(t5,((C_word*)t0)[2],t1);}

/* do57 in k688 in k678 in read-profile in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_692(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_692,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_702,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_717,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_719,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_733,a[2]=t6,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_car(t2);
/* chicken-profile.scm: 167  hash-table-ref/default */
t9=C_retrieve(lf[26]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,((C_word*)t0)[2],t8,lf[27]);}}

/* k731 in do57 in k688 in k678 in read-profile in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-profile.scm: 166  map */
t3=*((C_word*)lf[25]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* a718 in do57 in k688 in k678 in read-profile in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_719,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t2)?(C_truep(t3)?(C_word)C_a_i_plus(&a,2,t2,t3):C_SCHEME_FALSE):C_SCHEME_FALSE));}

/* k715 in do57 in k688 in k678 in read-profile in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 164  hash-table-set! */
t2=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k700 in do57 in k688 in k678 in read-profile in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 162  read */
t3=*((C_word*)lf[23]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k707 in k700 in do57 in k688 in k678 in read-profile in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_692(t2,((C_word*)t0)[2],t1);}

/* k681 in k678 in read-profile in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 169  hash-table->alist */
t2=C_retrieve(lf[22]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* sort-by-name in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_592,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_600,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* chicken-profile.scm: 142  symbol->string */
t6=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k598 in sort-by-name in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_604,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-profile.scm: 142  symbol->string */
t4=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k602 in k598 in sort-by-name in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 142  string<? */
t2=*((C_word*)lf[19]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sort-by-avg in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_563,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadddr(t2);
t5=(C_word)C_i_cadddr(t3);
if(C_truep((C_word)C_i_eqvp(t4,t5))){
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_caddr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_greaterp(t4,t5));}}

/* sort-by-time in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_534(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_534,4,t0,t1,t2,t3);}
t4=(C_word)C_i_caddr(t2);
t5=(C_word)C_i_caddr(t3);
if(C_truep((C_word)C_i_nequalp(t4,t5))){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_i_cadr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_greaterp(t4,t5));}}

/* sort-by-calls in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_499,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_cadr(t3);
if(C_truep((C_word)C_i_eqvp(t4,t5))){
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_caddr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t4)?(C_truep(t5)?(C_word)C_i_greaterp(t4,t5):C_SCHEME_TRUE):C_SCHEME_TRUE));}}

/* print-usage in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_fcall f_187(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_187,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_191,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_198,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[10],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[5],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[11],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[4],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[12],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[3],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[13],t9);
/* chicken-profile.scm: 51   ##sys#print-to-string */
t11=C_retrieve(lf[14]);
((C_proc3)C_retrieve_proc(t11))(3,t11,t3,t10);}

/* k196 in print-usage in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 52   display */
t2=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k189 in print-usage in k176 in k173 in k170 in k167 in k164 in k161 in k158 */
static void C_ccall f_191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 72   exit */
t2=C_retrieve(lf[8]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[104] = {
{"toplevelchicken-profile.scm",(void*)C_toplevel},
{"f_160chicken-profile.scm",(void*)f_160},
{"f_163chicken-profile.scm",(void*)f_163},
{"f_166chicken-profile.scm",(void*)f_166},
{"f_169chicken-profile.scm",(void*)f_169},
{"f_172chicken-profile.scm",(void*)f_172},
{"f_175chicken-profile.scm",(void*)f_175},
{"f_178chicken-profile.scm",(void*)f_178},
{"f_1142chicken-profile.scm",(void*)f_1142},
{"f_234chicken-profile.scm",(void*)f_234},
{"f_473chicken-profile.scm",(void*)f_473},
{"f_467chicken-profile.scm",(void*)f_467},
{"f_659chicken-profile.scm",(void*)f_659},
{"f_663chicken-profile.scm",(void*)f_663},
{"f_667chicken-profile.scm",(void*)f_667},
{"f_624chicken-profile.scm",(void*)f_624},
{"f_634chicken-profile.scm",(void*)f_634},
{"f_426chicken-profile.scm",(void*)f_426},
{"f_409chicken-profile.scm",(void*)f_409},
{"f_402chicken-profile.scm",(void*)f_402},
{"f_348chicken-profile.scm",(void*)f_348},
{"f_341chicken-profile.scm",(void*)f_341},
{"f_329chicken-profile.scm",(void*)f_329},
{"f_340chicken-profile.scm",(void*)f_340},
{"f_333chicken-profile.scm",(void*)f_333},
{"f_308chicken-profile.scm",(void*)f_308},
{"f_328chicken-profile.scm",(void*)f_328},
{"f_312chicken-profile.scm",(void*)f_312},
{"f_289chicken-profile.scm",(void*)f_289},
{"f_251chicken-profile.scm",(void*)f_251},
{"f_269chicken-profile.scm",(void*)f_269},
{"f_277chicken-profile.scm",(void*)f_277},
{"f_281chicken-profile.scm",(void*)f_281},
{"f_267chicken-profile.scm",(void*)f_267},
{"f_254chicken-profile.scm",(void*)f_254},
{"f_244chicken-profile.scm",(void*)f_244},
{"f_883chicken-profile.scm",(void*)f_883},
{"f_886chicken-profile.scm",(void*)f_886},
{"f_1121chicken-profile.scm",(void*)f_1121},
{"f_889chicken-profile.scm",(void*)f_889},
{"f_1072chicken-profile.scm",(void*)f_1072},
{"f_1090chicken-profile.scm",(void*)f_1090},
{"f_1097chicken-profile.scm",(void*)f_1097},
{"f_1070chicken-profile.scm",(void*)f_1070},
{"f_892chicken-profile.scm",(void*)f_892},
{"f_1058chicken-profile.scm",(void*)f_1058},
{"f_1062chicken-profile.scm",(void*)f_1062},
{"f_895chicken-profile.scm",(void*)f_895},
{"f_1038chicken-profile.scm",(void*)f_1038},
{"f_1036chicken-profile.scm",(void*)f_1036},
{"f_978chicken-profile.scm",(void*)f_978},
{"f_998chicken-profile.scm",(void*)f_998},
{"f_1002chicken-profile.scm",(void*)f_1002},
{"f_1006chicken-profile.scm",(void*)f_1006},
{"f_1010chicken-profile.scm",(void*)f_1010},
{"f_1014chicken-profile.scm",(void*)f_1014},
{"f_899chicken-profile.scm",(void*)f_899},
{"f_908chicken-profile.scm",(void*)f_908},
{"f_960chicken-profile.scm",(void*)f_960},
{"f_968chicken-profile.scm",(void*)f_968},
{"f_911chicken-profile.scm",(void*)f_911},
{"f_928chicken-profile.scm",(void*)f_928},
{"f_946chicken-profile.scm",(void*)f_946},
{"f_938chicken-profile.scm",(void*)f_938},
{"f_931chicken-profile.scm",(void*)f_931},
{"f_913chicken-profile.scm",(void*)f_913},
{"f_925chicken-profile.scm",(void*)f_925},
{"f_921chicken-profile.scm",(void*)f_921},
{"f_1132chicken-profile.scm",(void*)f_1132},
{"f_1138chicken-profile.scm",(void*)f_1138},
{"f_1135chicken-profile.scm",(void*)f_1135},
{"f_823chicken-profile.scm",(void*)f_823},
{"f_877chicken-profile.scm",(void*)f_877},
{"f_834chicken-profile.scm",(void*)f_834},
{"f_866chicken-profile.scm",(void*)f_866},
{"f_870chicken-profile.scm",(void*)f_870},
{"f_858chicken-profile.scm",(void*)f_858},
{"f_846chicken-profile.scm",(void*)f_846},
{"f_842chicken-profile.scm",(void*)f_842},
{"f_743chicken-profile.scm",(void*)f_743},
{"f_775chicken-profile.scm",(void*)f_775},
{"f_770chicken-profile.scm",(void*)f_770},
{"f_745chicken-profile.scm",(void*)f_745},
{"f_752chicken-profile.scm",(void*)f_752},
{"f_676chicken-profile.scm",(void*)f_676},
{"f_680chicken-profile.scm",(void*)f_680},
{"f_690chicken-profile.scm",(void*)f_690},
{"f_692chicken-profile.scm",(void*)f_692},
{"f_733chicken-profile.scm",(void*)f_733},
{"f_719chicken-profile.scm",(void*)f_719},
{"f_717chicken-profile.scm",(void*)f_717},
{"f_702chicken-profile.scm",(void*)f_702},
{"f_709chicken-profile.scm",(void*)f_709},
{"f_683chicken-profile.scm",(void*)f_683},
{"f_592chicken-profile.scm",(void*)f_592},
{"f_600chicken-profile.scm",(void*)f_600},
{"f_604chicken-profile.scm",(void*)f_604},
{"f_563chicken-profile.scm",(void*)f_563},
{"f_534chicken-profile.scm",(void*)f_534},
{"f_499chicken-profile.scm",(void*)f_499},
{"f_187chicken-profile.scm",(void*)f_187},
{"f_198chicken-profile.scm",(void*)f_198},
{"f_191chicken-profile.scm",(void*)f_191},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
