/* Generated from csi.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-07 01:29
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-07 on galinha (Linux)
   command line: csi.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -output-file csi.c -extend private-namespace.scm
   used units: library eval extras match
*/

#include "chicken.h"

#if (defined(_MSC_VER) && defined(_WIN32)) || defined(HAVE_DIRECT_H)
# include <direct.h>
#else
# define _getcwd(buf, len)       NULL
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_match_toplevel)
C_externimport void C_ccall C_match_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[561];
static double C_possibly_force_alignment;


/* from k1486 */
static C_word C_fcall stub488(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub488(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mpointer(&C_a,(void*)_getcwd(t0,t1));
return C_r;}

C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1078)
static void C_ccall f_1078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1081)
static void C_ccall f_1081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1084)
static void C_ccall f_1084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8723)
static void C_ccall f_8723(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8723)
static void C_ccall f_8723r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8727)
static void C_ccall f_8727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8730)
static void C_ccall f_8730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8733)
static void C_ccall f_8733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8739)
static void C_ccall f_8739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8945)
static void C_ccall f_8945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8925)
static void C_ccall f_8925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8921)
static void C_ccall f_8921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8901)
static void C_ccall f_8901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8764)
static void C_fcall f_8764(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8774)
static void C_ccall f_8774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8893)
static void C_ccall f_8893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8777)
static void C_ccall f_8777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8889)
static void C_ccall f_8889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8780)
static void C_ccall f_8780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8811)
static void C_fcall f_8811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8791)
static void C_ccall f_8791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8762)
static void C_ccall f_8762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1087)
static void C_ccall f_1087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8635)
static void C_ccall f_8635(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8635)
static void C_ccall f_8635r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8652)
static void C_ccall f_8652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8655)
static void C_ccall f_8655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8661)
static void C_fcall f_8661(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1090)
static void C_ccall f_1090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8594)
static void C_ccall f_8594(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8594)
static void C_ccall f_8594r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8598)
static void C_ccall f_8598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1093)
static void C_ccall f_1093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8578)
static void C_ccall f_8578(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8578)
static void C_ccall f_8578r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8588)
static void C_ccall f_8588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8586)
static void C_ccall f_8586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1096)
static void C_ccall f_1096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8501)
static void C_ccall f_8501(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8505)
static void C_ccall f_8505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8573)
static void C_ccall f_8573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8508)
static void C_ccall f_8508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8517)
static void C_ccall f_8517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8564)
static void C_ccall f_8564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8531)
static void C_ccall f_8531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8539)
static void C_ccall f_8539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8541)
static void C_fcall f_8541(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8558)
static void C_ccall f_8558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8523)
static void C_ccall f_8523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8515)
static void C_ccall f_8515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8441)
static void C_ccall f_8441(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8441)
static void C_ccall f_8441r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8445)
static void C_fcall f_8445(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1102)
static void C_ccall f_1102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8382)
static void C_ccall f_8382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8382)
static void C_ccall f_8382r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8386)
static void C_ccall f_8386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8413)
static void C_fcall f_8413(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1105)
static void C_ccall f_1105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8208)
static void C_ccall f_8208(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8208)
static void C_ccall f_8208r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8212)
static void C_ccall f_8212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8215)
static void C_ccall f_8215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8376)
static void C_ccall f_8376(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8218)
static void C_ccall f_8218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8370)
static void C_ccall f_8370(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8221)
static void C_ccall f_8221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8368)
static void C_ccall f_8368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8332)
static void C_ccall f_8332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8346)
static void C_fcall f_8346(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8360)
static void C_ccall f_8360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8340)
static void C_ccall f_8340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8336)
static void C_ccall f_8336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8228)
static void C_ccall f_8228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8324)
static void C_ccall f_8324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8300)
static void C_ccall f_8300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8318)
static void C_ccall f_8318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8308)
static void C_ccall f_8308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8304)
static void C_ccall f_8304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8296)
static void C_ccall f_8296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8280)
static void C_ccall f_8280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8256)
static void C_ccall f_8256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8274)
static void C_ccall f_8274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8264)
static void C_ccall f_8264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8260)
static void C_ccall f_8260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8252)
static void C_ccall f_8252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1108)
static void C_ccall f_1108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8113)
static void C_ccall f_8113(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8113)
static void C_ccall f_8113r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8149)
static void C_fcall f_8149(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8162)
static void C_ccall f_8162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8120)
static void C_ccall f_8120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8003)
static void C_ccall f_8003(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8003)
static void C_ccall f_8003r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8007)
static void C_ccall f_8007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8010)
static void C_ccall f_8010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8013)
static void C_ccall f_8013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8016)
static void C_ccall f_8016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8107)
static void C_ccall f_8107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8019)
static void C_ccall f_8019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8101)
static void C_ccall f_8101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8022)
static void C_ccall f_8022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8095)
static void C_ccall f_8095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8099)
static void C_ccall f_8099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8029)
static void C_ccall f_8029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8067)
static void C_ccall f_8067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8065)
static void C_ccall f_8065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7993)
static void C_ccall f_7993(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7993)
static void C_ccall f_7993r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7979)
static void C_ccall f_7979(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7979)
static void C_ccall f_7979r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1120)
static void C_ccall f_1120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1194)
static void C_ccall f_1194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7717)
static void C_ccall f_7717(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7721)
static void C_ccall f_7721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7730)
static void C_ccall f_7730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7939)
static void C_fcall f_7939(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7952)
static void C_ccall f_7952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7733)
static void C_ccall f_7733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7929)
static void C_ccall f_7929(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7937)
static void C_ccall f_7937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7736)
static void C_ccall f_7736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7883)
static void C_fcall f_7883(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7916)
static void C_ccall f_7916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7923)
static void C_ccall f_7923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7899)
static void C_fcall f_7899(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7748)
static void C_ccall f_7748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7877)
static void C_ccall f_7877(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7755)
static void C_ccall f_7755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7757)
static void C_fcall f_7757(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7871)
static void C_ccall f_7871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7791)
static void C_fcall f_7791(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7845)
static void C_ccall f_7845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7822)
static void C_ccall f_7822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7777)
static void C_ccall f_7777(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7785)
static void C_ccall f_7785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7775)
static void C_ccall f_7775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7737)
static void C_ccall f_7737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7677)
static void C_fcall f_7677(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7700)
static void C_ccall f_7700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7704)
static void C_ccall f_7704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7646)
static void C_fcall f_7646(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7667)
static void C_ccall f_7667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7595)
static void C_ccall f_7595(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7599)
static void C_ccall f_7599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7610)
static void C_fcall f_7610(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7635)
static void C_ccall f_7635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7475)
static void C_ccall f_7475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7479)
static void C_ccall f_7479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7589)
static void C_ccall f_7589(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7587)
static void C_ccall f_7587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7488)
static void C_ccall f_7488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7575)
static void C_ccall f_7575(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7583)
static void C_ccall f_7583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7491)
static void C_ccall f_7491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7569)
static void C_ccall f_7569(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7511)
static void C_ccall f_7511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7521)
static void C_ccall f_7521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7541)
static void C_ccall f_7541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7547)
static void C_ccall f_7547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7555)
static void C_ccall f_7555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7545)
static void C_ccall f_7545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7519)
static void C_ccall f_7519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7515)
static void C_ccall f_7515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7492)
static void C_ccall f_7492(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1206)
static void C_ccall f_1206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7454)
static void C_ccall f_7454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7458)
static void C_ccall f_7458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1209)
static void C_ccall f_1209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7444)
static void C_ccall f_7444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1215)
static void C_ccall f_1215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_fcall f_1224(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1240)
static void C_fcall f_1240(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1227)
static void C_ccall f_1227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7423)
static void C_ccall f_7423(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7427)
static void C_ccall f_7427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7307)
static void C_ccall f_7307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7311)
static void C_ccall f_7311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7320)
static void C_fcall f_7320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7334)
static void C_fcall f_7334(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7398)
static void C_ccall f_7398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7380)
static void C_ccall f_7380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7363)
static void C_ccall f_7363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7218)
static void C_ccall f_7218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7231)
static void C_fcall f_7231(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7247)
static void C_ccall f_7247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7285)
static void C_ccall f_7285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7283)
static void C_ccall f_7283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7275)
static void C_ccall f_7275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7119)
static void C_ccall f_7119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7129)
static void C_ccall f_7129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7142)
static void C_fcall f_7142(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7158)
static void C_ccall f_7158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7186)
static void C_ccall f_7186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7140)
static void C_ccall f_7140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6833)
static void C_ccall f_6833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6833)
static void C_ccall f_6833r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7030)
static void C_ccall f_7030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7033)
static void C_ccall f_7033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7036)
static void C_ccall f_7036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7109)
static void C_ccall f_7109(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7117)
static void C_ccall f_7117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7052)
static void C_ccall f_7052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7055)
static void C_ccall f_7055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7061)
static void C_ccall f_7061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7099)
static void C_ccall f_7099(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7107)
static void C_ccall f_7107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7064)
static void C_ccall f_7064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6844)
static void C_ccall f_6844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6848)
static void C_ccall f_6848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6854)
static void C_fcall f_6854(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6899)
static void C_ccall f_6899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6911)
static void C_ccall f_6911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6907)
static void C_ccall f_6907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6875)
static void C_ccall f_6875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7067)
static void C_ccall f_7067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6927)
static void C_fcall f_6927(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7027)
static void C_ccall f_7027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6991)
static void C_ccall f_6991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6961)
static void C_ccall f_6961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7070)
static void C_ccall f_7070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7037)
static void C_fcall f_7037(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7049)
static void C_ccall f_7049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7045)
static void C_ccall f_7045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6776)
static void C_ccall f_6776(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6780)
static void C_ccall f_6780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6770)
static void C_ccall f_6770(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6617)
static void C_ccall f_6617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6617)
static void C_ccall f_6617r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6621)
static void C_ccall f_6621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_ccall f_6624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6627)
static void C_ccall f_6627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6640)
static void C_fcall f_6640(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6690)
static void C_ccall f_6690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6701)
static void C_ccall f_6701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6341)
static void C_ccall f_6341(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6378)
static void C_ccall f_6378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6604)
static void C_ccall f_6604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6614)
static void C_ccall f_6614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6602)
static void C_ccall f_6602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6350)
static void C_fcall f_6350(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6364)
static void C_ccall f_6364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6368)
static void C_ccall f_6368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6397)
static void C_ccall f_6397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6421)
static void C_ccall f_6421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6425)
static void C_ccall f_6425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6435)
static void C_fcall f_6435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6451)
static void C_ccall f_6451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6470)
static void C_fcall f_6470(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6537)
static void C_ccall f_6537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6455)
static void C_ccall f_6455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6468)
static void C_ccall f_6468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6441)
static void C_ccall f_6441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6449)
static void C_ccall f_6449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6439)
static void C_ccall f_6439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6409)
static void C_ccall f_6409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6284)
static void C_ccall f_6284(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6284)
static void C_ccall f_6284r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6294)
static void C_ccall f_6294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6208)
static void C_ccall f_6208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6208)
static void C_ccall f_6208r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6215)
static void C_ccall f_6215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6031)
static void C_ccall f_6031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6174)
static void C_ccall f_6174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6170)
static void C_ccall f_6170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6033)
static void C_ccall f_6033(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6121)
static void C_ccall f_6121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6119)
static void C_ccall f_6119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6089)
static void C_fcall f_6089(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6056)
static void C_fcall f_6056(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1324)
static void C_ccall f_1324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6015)
static void C_ccall f_6015(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6013)
static void C_ccall f_6013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5866)
static void C_fcall f_5866(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5892)
static void C_fcall f_5892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5920)
static void C_fcall f_5920(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5912)
static void C_ccall f_5912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5904)
static void C_ccall f_5904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5864)
static void C_ccall f_5864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5829)
static void C_ccall f_5829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1330)
static void C_ccall f_1330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5806)
static void C_ccall f_5806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5810)
static void C_ccall f_5810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5817)
static void C_ccall f_5817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1333)
static void C_ccall f_1333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5791)
static void C_ccall f_5791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5800)
static void C_ccall f_5800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5798)
static void C_ccall f_5798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5659)
static void C_ccall f_5659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5665)
static void C_fcall f_5665(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5678)
static void C_ccall f_5678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5684)
static void C_ccall f_5684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5691)
static void C_ccall f_5691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5707)
static void C_ccall f_5707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1339)
static void C_ccall f_1339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5522)
static void C_fcall f_5522(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5634)
static void C_ccall f_5634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5607)
static void C_ccall f_5607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5532)
static void C_ccall f_5532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5541)
static void C_ccall f_5541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5457)
static void C_ccall f_5457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_5457)
static void C_ccall f_5457r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5292)
static void C_fcall f_5292(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5366)
static void C_fcall f_5366(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5369)
static void C_ccall f_5369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5435)
static void C_ccall f_5435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5393)
static void C_ccall f_5393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5302)
static void C_fcall f_5302(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5235)
static void C_ccall f_5235(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5235)
static void C_ccall f_5235r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1351)
static void C_ccall f_1351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5185)
static void C_fcall f_5185(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5204)
static void C_ccall f_5204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1354)
static void C_ccall f_1354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5169)
static void C_ccall f_5169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5155)
static void C_ccall f_5155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4427)
static void C_ccall f_4427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5094)
static void C_fcall f_5094(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5044)
static void C_ccall f_5044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5053)
static void C_ccall f_5053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_fcall f_4436(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_fcall f_4442(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5029)
static void C_ccall f_5029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5025)
static void C_ccall f_5025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4603)
static void C_fcall f_4603(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5014)
static void C_ccall f_5014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5017)
static void C_ccall f_5017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5005)
static void C_ccall f_5005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4609)
static void C_ccall f_4609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4612)
static void C_ccall f_4612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_fcall f_4615(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_ccall f_4621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4627)
static void C_ccall f_4627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4938)
static void C_ccall f_4938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4528)
static void C_ccall f_4528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4515)
static void C_ccall f_4515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4649)
static void C_fcall f_4649(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4807)
static void C_fcall f_4807(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4833)
static void C_fcall f_4833(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4820)
static void C_ccall f_4820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4794)
static void C_ccall f_4794(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4794)
static void C_ccall f_4794r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4768)
static void C_ccall f_4768(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4768)
static void C_ccall f_4768r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_fcall f_4533(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4580)
static void C_ccall f_4580(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4549)
static void C_fcall f_4549(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4572)
static void C_ccall f_4572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4453)
static void C_fcall f_4453(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4459)
static void C_fcall f_4459(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4486)
static void C_ccall f_4486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4277)
static void C_fcall f_4277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4283)
static void C_fcall f_4283(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4305)
static void C_fcall f_4305(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4362)
static void C_ccall f_4362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4355)
static void C_ccall f_4355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4321)
static void C_ccall f_4321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4334)
static void C_ccall f_4334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4394)
static C_word C_fcall f_4394(C_word t0);
C_noret_decl(f_4220)
static void C_fcall f_4220(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4226)
static void C_fcall f_4226(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4238)
static void C_fcall f_4238(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4170)
static void C_fcall f_4170(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3984)
static void C_fcall f_3984(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4069)
static void C_fcall f_4069(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4130)
static void C_ccall f_4130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_fcall f_4106(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_fcall f_4018(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3955)
static void C_fcall f_3955(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3975)
static void C_ccall f_3975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3791)
static void C_ccall f_3791(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3791)
static void C_ccall f_3791r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3904)
static void C_fcall f_3904(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_fcall f_3899(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3793)
static void C_fcall f_3793(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3861)
static void C_fcall f_3861(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3796)
static void C_fcall f_3796(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3031)
static void C_ccall f_3031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3536)
static void C_ccall f_3536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3608)
static void C_ccall f_3608(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3621)
static void C_fcall f_3621(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3648)
static void C_ccall f_3648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3570)
static void C_ccall f_3570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3542)
static void C_ccall f_3542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_fcall f_3460(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_fcall f_3365(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_fcall f_3301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3045)
static void C_fcall f_3045(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3077)
static void C_fcall f_3077(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2871)
static void C_ccall f_2871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2853)
static void C_fcall f_2853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2762)
static void C_ccall f_2762(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_fcall f_2796(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2813)
static void C_ccall f_2813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2750)
static void C_ccall f_2750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static void C_fcall f_2371(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2381)
static void C_ccall f_2381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2327)
static void C_fcall f_2327(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1800)
static void C_fcall f_1800(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2302)
static void C_ccall f_2302(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2302)
static void C_ccall f_2302r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2242)
static void C_ccall f_2242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2679)
static void C_ccall f_2679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_ccall f_2663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_fcall f_2617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2472)
static void C_ccall f_2472(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1995)
static void C_ccall f_1995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1647)
static void C_ccall f_1647(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1671)
static void C_ccall f_1671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_fcall f_1657(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1541)
static void C_ccall f_1541(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_fcall f_1601(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1520)
static C_word C_fcall f_1520(C_word t0,C_word t1);
C_noret_decl(f_1493)
static void C_fcall f_1493(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1503)
static void C_ccall f_1503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1447)
static void C_ccall f_1447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1431)
static C_word C_fcall f_1431(C_word t0);
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1429)
static void C_ccall f_1429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1382)
static void C_ccall f_1382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1370)
static void C_ccall f_1370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1374)
static void C_ccall f_1374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1125)
static void C_ccall f_1125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1162)
static void C_ccall f_1162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8764)
static void C_fcall trf_8764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8764(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8764(t0,t1,t2,t3);}

C_noret_decl(trf_8811)
static void C_fcall trf_8811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8811(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8811(t0,t1);}

C_noret_decl(trf_8661)
static void C_fcall trf_8661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8661(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8661(t0,t1);}

C_noret_decl(trf_8541)
static void C_fcall trf_8541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8541(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8541(t0,t1,t2,t3);}

C_noret_decl(trf_8445)
static void C_fcall trf_8445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8445(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8445(t0,t1);}

C_noret_decl(trf_8413)
static void C_fcall trf_8413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8413(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8413(t0,t1);}

C_noret_decl(trf_8346)
static void C_fcall trf_8346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8346(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8346(t0,t1,t2);}

C_noret_decl(trf_8149)
static void C_fcall trf_8149(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8149(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8149(t0,t1,t2);}

C_noret_decl(trf_7939)
static void C_fcall trf_7939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7939(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7939(t0,t1,t2,t3);}

C_noret_decl(trf_7883)
static void C_fcall trf_7883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7883(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7883(t0,t1,t2,t3);}

C_noret_decl(trf_7899)
static void C_fcall trf_7899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7899(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7899(t0,t1);}

C_noret_decl(trf_7757)
static void C_fcall trf_7757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7757(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7757(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7791)
static void C_fcall trf_7791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7791(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7791(t0,t1);}

C_noret_decl(trf_7677)
static void C_fcall trf_7677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7677(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7677(t0,t1,t2,t3);}

C_noret_decl(trf_7646)
static void C_fcall trf_7646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7646(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7646(t0,t1,t2,t3);}

C_noret_decl(trf_7610)
static void C_fcall trf_7610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7610(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7610(t0,t1,t2);}

C_noret_decl(trf_1224)
static void C_fcall trf_1224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1224(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1224(t0,t1);}

C_noret_decl(trf_1240)
static void C_fcall trf_1240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1240(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1240(t0,t1);}

C_noret_decl(trf_7320)
static void C_fcall trf_7320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7320(t0,t1);}

C_noret_decl(trf_7334)
static void C_fcall trf_7334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7334(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7334(t0,t1,t2);}

C_noret_decl(trf_7231)
static void C_fcall trf_7231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7231(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7231(t0,t1,t2);}

C_noret_decl(trf_7142)
static void C_fcall trf_7142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7142(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7142(t0,t1,t2);}

C_noret_decl(trf_6854)
static void C_fcall trf_6854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6854(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6854(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6927)
static void C_fcall trf_6927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6927(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6927(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7037)
static void C_fcall trf_7037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7037(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7037(t0,t1,t2);}

C_noret_decl(trf_6640)
static void C_fcall trf_6640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6640(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6640(t0,t1,t2,t3);}

C_noret_decl(trf_6350)
static void C_fcall trf_6350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6350(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6350(t0,t1,t2);}

C_noret_decl(trf_6435)
static void C_fcall trf_6435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6435(t0,t1);}

C_noret_decl(trf_6470)
static void C_fcall trf_6470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6470(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6470(t0,t1,t2,t3);}

C_noret_decl(trf_6089)
static void C_fcall trf_6089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6089(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6089(t0,t1);}

C_noret_decl(trf_6056)
static void C_fcall trf_6056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6056(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6056(t0,t1);}

C_noret_decl(trf_5866)
static void C_fcall trf_5866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5866(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5866(t0,t1,t2,t3);}

C_noret_decl(trf_5892)
static void C_fcall trf_5892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5892(t0,t1);}

C_noret_decl(trf_5920)
static void C_fcall trf_5920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5920(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5920(t0,t1);}

C_noret_decl(trf_5665)
static void C_fcall trf_5665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5665(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5665(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5522)
static void C_fcall trf_5522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5522(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5522(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5292)
static void C_fcall trf_5292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5292(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5292(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5366)
static void C_fcall trf_5366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5366(t0,t1);}

C_noret_decl(trf_5302)
static void C_fcall trf_5302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5302(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5302(t0,t1);}

C_noret_decl(trf_5185)
static void C_fcall trf_5185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5185(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5185(t0,t1);}

C_noret_decl(trf_5094)
static void C_fcall trf_5094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5094(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5094(t0,t1);}

C_noret_decl(trf_4436)
static void C_fcall trf_4436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4436(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4436(t0,t1);}

C_noret_decl(trf_4442)
static void C_fcall trf_4442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4442(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4442(t0,t1);}

C_noret_decl(trf_4603)
static void C_fcall trf_4603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4603(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4603(t0,t1);}

C_noret_decl(trf_4615)
static void C_fcall trf_4615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4615(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4615(t0,t1);}

C_noret_decl(trf_4649)
static void C_fcall trf_4649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4649(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4649(t0,t1,t2);}

C_noret_decl(trf_4807)
static void C_fcall trf_4807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4807(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4807(t0,t1);}

C_noret_decl(trf_4833)
static void C_fcall trf_4833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4833(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4833(t0,t1);}

C_noret_decl(trf_4533)
static void C_fcall trf_4533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4533(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4533(t0,t1,t2);}

C_noret_decl(trf_4549)
static void C_fcall trf_4549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4549(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4549(t0,t1,t2);}

C_noret_decl(trf_4453)
static void C_fcall trf_4453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4453(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4453(t0,t1,t2);}

C_noret_decl(trf_4459)
static void C_fcall trf_4459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4459(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4459(t0,t1,t2);}

C_noret_decl(trf_4277)
static void C_fcall trf_4277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4277(t0,t1);}

C_noret_decl(trf_4283)
static void C_fcall trf_4283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4283(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4283(t0,t1,t2);}

C_noret_decl(trf_4305)
static void C_fcall trf_4305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4305(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4305(t0,t1);}

C_noret_decl(trf_4220)
static void C_fcall trf_4220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4220(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4220(t0,t1,t2);}

C_noret_decl(trf_4226)
static void C_fcall trf_4226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4226(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4226(t0,t1,t2);}

C_noret_decl(trf_4238)
static void C_fcall trf_4238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4238(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4238(t0,t1,t2);}

C_noret_decl(trf_4170)
static void C_fcall trf_4170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4170(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4170(t0,t1,t2);}

C_noret_decl(trf_3984)
static void C_fcall trf_3984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3984(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3984(t0,t1,t2);}

C_noret_decl(trf_4069)
static void C_fcall trf_4069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4069(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4069(t0,t1,t2,t3);}

C_noret_decl(trf_4106)
static void C_fcall trf_4106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4106(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4106(t0,t1,t2);}

C_noret_decl(trf_4018)
static void C_fcall trf_4018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4018(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4018(t0,t1,t2,t3);}

C_noret_decl(trf_3955)
static void C_fcall trf_3955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3955(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3955(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3904)
static void C_fcall trf_3904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3904(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3904(t0,t1);}

C_noret_decl(trf_3899)
static void C_fcall trf_3899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3899(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3899(t0,t1,t2);}

C_noret_decl(trf_3793)
static void C_fcall trf_3793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3793(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3793(t0,t1,t2,t3);}

C_noret_decl(trf_3861)
static void C_fcall trf_3861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3861(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3861(t0,t1);}

C_noret_decl(trf_3796)
static void C_fcall trf_3796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3796(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3796(t0,t1,t2);}

C_noret_decl(trf_3621)
static void C_fcall trf_3621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3621(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3621(t0,t1,t2);}

C_noret_decl(trf_3460)
static void C_fcall trf_3460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3460(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3460(t0,t1);}

C_noret_decl(trf_3365)
static void C_fcall trf_3365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3365(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3365(t0,t1);}

C_noret_decl(trf_3301)
static void C_fcall trf_3301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3301(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3301(t0,t1);}

C_noret_decl(trf_3045)
static void C_fcall trf_3045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3045(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3045(t0,t1,t2);}

C_noret_decl(trf_3077)
static void C_fcall trf_3077(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3077(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3077(t0,t1,t2,t3);}

C_noret_decl(trf_2853)
static void C_fcall trf_2853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2853(t0,t1);}

C_noret_decl(trf_2796)
static void C_fcall trf_2796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2796(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2796(t0,t1,t2,t3);}

C_noret_decl(trf_2371)
static void C_fcall trf_2371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2371(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2371(t0,t1,t2);}

C_noret_decl(trf_2327)
static void C_fcall trf_2327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2327(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2327(t0,t1,t2);}

C_noret_decl(trf_1800)
static void C_fcall trf_1800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1800(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1800(t0,t1);}

C_noret_decl(trf_2617)
static void C_fcall trf_2617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2617(t0,t1);}

C_noret_decl(trf_1657)
static void C_fcall trf_1657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1657(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1657(t0,t1);}

C_noret_decl(trf_1601)
static void C_fcall trf_1601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1601(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1601(t0,t1,t2);}

C_noret_decl(trf_1493)
static void C_fcall trf_1493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1493(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1493(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(4678)){
C_save(t1);
C_rereclaim2(4678*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,561);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],3,"map");
lf[3]=C_h_intern(&lf[3],6,"lambda");
lf[4]=C_h_intern(&lf[4],14,"\004coreundefined");
lf[5]=C_h_intern(&lf[5],20,"\003syscall-with-values");
lf[6]=C_h_intern(&lf[6],9,"\004coreset!");
lf[7]=C_h_intern(&lf[7],6,"gensym");
lf[8]=C_h_intern(&lf[8],16,"\003syscheck-syntax");
lf[9]=C_h_intern(&lf[9],25,"set!-values/define-values");
lf[10]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\011\012CHICKEN\012");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000 (c)2000-2008 Felix L. Winkelmann");
lf[15]=C_h_intern(&lf[15],19,"\003sysundefined-value");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\006.csirc");
lf[18]=C_h_intern(&lf[18],27,"\003sysrepl-print-length-limit");
lf[19]=C_h_intern(&lf[19],4,"\000csi");
lf[20]=C_h_intern(&lf[20],12,"\003sysfeatures");
lf[21]=C_h_intern(&lf[21],15,"\003csiprint-usage");
lf[22]=C_h_intern(&lf[22],7,"display");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\002\042\047\012    -b  -batch                  terminate after command-line processing\012 "
"   -w  -no-warnings            disable all warnings\012    -k  -keyword-style STYLE"
"    enable alternative keyword-syntax (none, prefix or suffix)\012    -s  -script P"
"ATHNAME        use interpreter for shell scripts\012        -ss PATHNAME           "
" shell script with `main\047 procedure\012    -R  -require-extension NAME require exte"
"nsion before executing code\012    -I  -include-path PATHNAME  add PATHNAME to incl"
"ude path\012    --                          ignore all following options\012\012");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\002\257Usage: csi {FILENAME | OPTION}\012\012  where OPTION may be one of the following:"
"\012\012    -h  -help  --help           display this text and exit\012    -v  -version   "
"             display version and exit\012        -release                print rele"
"ase number and exit\012    -i  -case-insensitive       enable case-insensitive read"
"ing\012    -e  -eval EXPRESSION        evaluate given expression\012    -p  -print EXP"
"RESSION       evaluate and print result(s)\012    -P  -pretty-print EXPRESSION  eva"
"luate and print result(s) prettily\012    -D  -feature SYMBOL         register feat"
"ure identifier\012    -q  -quiet                  do not print banner\012    -n  -no-i"
"nit                do not load initialization file `");
lf[25]=C_h_intern(&lf[25],16,"\003csiprint-banner");
lf[26]=C_h_intern(&lf[26],5,"print");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[28]=C_h_intern(&lf[28],15,"chicken-version");
lf[29]=C_h_intern(&lf[29],9,"read-char");
lf[30]=C_h_intern(&lf[30],4,"read");
lf[31]=C_h_intern(&lf[31],18,"\003sysuser-read-hook");
lf[32]=C_h_intern(&lf[32],5,"quote");
lf[33]=C_h_intern(&lf[33],17,"\003csihistory-count");
lf[34]=C_h_intern(&lf[34],15,"\003csihistory-ref");
lf[35]=C_h_intern(&lf[35],21,"\003syssharp-number-hook");
lf[37]=C_h_intern(&lf[37],9,"substring");
lf[38]=C_h_intern(&lf[38],18,"\003csichop-separator");
lf[39]=C_h_intern(&lf[39],4,"sub1");
lf[40]=C_h_intern(&lf[40],1,"@");
lf[41]=C_h_intern(&lf[41],12,"file-exists\077");
lf[42]=C_h_intern(&lf[42],13,"string-append");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\004.bat");
lf[44]=C_h_intern(&lf[44],22,"\003csilookup-script-file");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[46]=C_h_intern(&lf[46],25,"\003syspeek-nonnull-c-string");
lf[47]=C_h_intern(&lf[47],12,"string-split");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[50]=C_h_intern(&lf[50],6,"getenv");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\004PATH");
lf[52]=C_h_intern(&lf[52],16,"\003csihistory-list");
lf[53]=C_h_intern(&lf[53],13,"vector-resize");
lf[54]=C_h_intern(&lf[54],15,"\003csihistory-add");
lf[55]=C_h_intern(&lf[55],9,"\003syserror");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000 history entry index out of range");
lf[57]=C_h_intern(&lf[57],14,"\003csitty-input\077");
lf[58]=C_h_intern(&lf[58],13,"\003systty-port\077");
lf[59]=C_h_intern(&lf[59],18,"\003sysstandard-input");
lf[60]=C_h_intern(&lf[60],18,"\003sysbreak-on-error");
lf[61]=C_h_intern(&lf[61],20,"\003sysread-prompt-hook");
lf[63]=C_h_intern(&lf[63],15,"hash-table-set!");
lf[64]=C_h_intern(&lf[64],16,"toplevel-command");
lf[65]=C_h_intern(&lf[65],4,"eval");
lf[66]=C_h_intern(&lf[66],12,"load-noisily");
lf[67]=C_h_intern(&lf[67],10,"singlestep");
lf[68]=C_h_intern(&lf[68],14,"hash-table-ref");
lf[69]=C_h_intern(&lf[69],15,"hash-table-walk");
lf[70]=C_h_intern(&lf[70],9,"read-line");
lf[71]=C_h_intern(&lf[71],6,"length");
lf[72]=C_h_intern(&lf[72],5,"write");
lf[73]=C_h_intern(&lf[73],6,"printf");
lf[74]=C_h_intern(&lf[74],12,"pretty-print");
lf[75]=C_h_intern(&lf[75],8,"integer\077");
lf[76]=C_h_intern(&lf[76],6,"values");
lf[77]=C_h_intern(&lf[77],18,"\003sysrepl-eval-hook");
lf[78]=C_h_intern(&lf[78],22,"\003csitrace-indent-level");
lf[79]=C_h_intern(&lf[79],4,"exit");
lf[80]=C_h_intern(&lf[80],1,"x");
lf[81]=C_h_intern(&lf[81],11,"macroexpand");
lf[82]=C_h_intern(&lf[82],1,"p");
lf[83]=C_h_intern(&lf[83],1,"d");
lf[84]=C_h_intern(&lf[84],12,"\003csidescribe");
lf[85]=C_h_intern(&lf[85],2,"du");
lf[86]=C_h_intern(&lf[86],8,"\003csidump");
lf[87]=C_h_intern(&lf[87],3,"dur");
lf[88]=C_h_intern(&lf[88],1,"r");
lf[89]=C_h_intern(&lf[89],10,"\003csireport");
lf[90]=C_h_intern(&lf[90],1,"q");
lf[91]=C_h_intern(&lf[91],1,"l");
lf[92]=C_h_intern(&lf[92],12,"\003sysfor-each");
lf[93]=C_h_intern(&lf[93],4,"load");
lf[94]=C_h_intern(&lf[94],2,"ln");
lf[95]=C_h_intern(&lf[95],6,"print*");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\004==> ");
lf[97]=C_h_intern(&lf[97],8,"\000printer");
lf[98]=C_h_intern(&lf[98],1,"t");
lf[99]=C_h_intern(&lf[99],17,"\003sysdisplay-times");
lf[100]=C_h_intern(&lf[100],14,"\003sysstop-timer");
lf[101]=C_h_intern(&lf[101],15,"\003sysstart-timer");
lf[102]=C_h_intern(&lf[102],2,"tr");
lf[104]=C_h_intern(&lf[104],8,"\003syswarn");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\030procedure already traced");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000 procedure already has breakpoint");
lf[108]=C_h_intern(&lf[108],25,"\003csitraced-procedure-exit");
lf[109]=C_h_intern(&lf[109],26,"\003csitraced-procedure-entry");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\033can not trace non-procedure");
lf[111]=C_h_intern(&lf[111],7,"\003sysmap");
lf[112]=C_h_intern(&lf[112],14,"string->symbol");
lf[113]=C_h_intern(&lf[113],3,"utr");
lf[114]=C_h_intern(&lf[114],7,"\003csidel");
lf[115]=C_h_intern(&lf[115],3,"eq\077");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\024procedure not traced");
lf[117]=C_h_intern(&lf[117],2,"br");
lf[118]=C_h_intern(&lf[118],1,"a");
lf[119]=C_h_intern(&lf[119],15,"\003sysbreak-entry");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\047can not set breakpoint on non-procedure");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\024un-tracing procedure");
lf[122]=C_h_intern(&lf[122],3,"ubr");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\033procedure has no breakpoint");
lf[124]=C_h_intern(&lf[124],3,"uba");
lf[125]=C_h_intern(&lf[125],14,"do-unbreak-all");
lf[126]=C_h_intern(&lf[126],8,"breakall");
lf[127]=C_h_intern(&lf[127],19,"\003sysbreak-in-thread");
lf[128]=C_h_intern(&lf[128],9,"breakonly");
lf[129]=C_h_intern(&lf[129],4,"info");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\021Breakpoints: ~s~%");
lf[131]=C_h_intern(&lf[131],3,"car");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\014Traced: ~s~%");
lf[133]=C_h_intern(&lf[133],1,"c");
lf[134]=C_h_intern(&lf[134],19,"\003syslast-breakpoint");
lf[135]=C_h_intern(&lf[135],16,"\003sysbreak-resume");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\026no breakpoint pending\012");
lf[137]=C_h_intern(&lf[137],3,"exn");
lf[138]=C_h_intern(&lf[138],18,"\003syslast-exception");
lf[139]=C_h_intern(&lf[139],4,"step");
lf[140]=C_h_intern(&lf[140],1,"s");
lf[141]=C_h_intern(&lf[141],6,"system");
lf[142]=C_h_intern(&lf[142],1,"\077");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\002 ,");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\004TToplevel commands:\012\012 ,\077                Show this text\012 ,p EXP            Pr"
"etty print evaluated expression EXP\012 ,d EXP            Describe result of evalua"
"ted expression EXP\012 ,du EXP           Dump data of expression EXP\012 ,dur EXP N   "
"     Dump range\012 ,q                Quit interpreter\012 ,l FILENAME ...   Load one "
"or more files\012 ,ln FILENAME ...  Load one or more files and print result of each"
" top-level expression\012 ,r                Show system information\012 ,s TEXT ...   "
"    Execute shell-command\012 ,tr NAME ...      Trace procedures\012 ,utr NAME ...    "
" Untrace procedures\012 ,br NAME ...      Set breakpoints\012 ,ubr NAME ...     Remove"
" breakpoints\012 ,uba              Remove all breakpoints\012 ,breakall         Break "
"in all threads (default)\012 ,breakonly THREAD Break only in specified thread\012 ,c  "
"              Continue from breakpoint\012 ,info             List traced procedures"
" and breakpoints\012 ,step EXPR        Execute EXPR in single-stepping mode\012 ,exn  "
"            Describe last exception\012 ,t EXP            Evaluate form and print e"
"lapsed time\012 ,x EXP            Pretty print macroexpanded expression EXP\012");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\0005Undefined toplevel command ~s - enter `,\077\047 for help~%");
lf[146]=C_h_intern(&lf[146],22,"hash-table-ref/default");
lf[147]=C_h_intern(&lf[147],7,"unquote");
lf[148]=C_h_intern(&lf[148],16,"\003csitrace-indent");
lf[149]=C_h_intern(&lf[149],19,"\003syswrite-char/port");
lf[150]=C_h_intern(&lf[150],19,"\003sysstandard-output");
lf[151]=C_h_intern(&lf[151],12,"flush-output");
lf[152]=C_h_intern(&lf[152],16,"\003syswrite-char-0");
lf[153]=C_h_intern(&lf[153],4,"add1");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[155]=C_h_intern(&lf[155],23,"\003csiparse-option-string");
lf[156]=C_h_intern(&lf[156],17,"get-output-string");
lf[157]=C_h_intern(&lf[157],18,"open-output-string");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid option syntax");
lf[159]=C_h_intern(&lf[159],7,"reverse");
lf[160]=C_h_intern(&lf[160],22,"with-exception-handler");
lf[161]=C_h_intern(&lf[161],30,"call-with-current-continuation");
lf[162]=C_h_intern(&lf[162],17,"open-input-string");
lf[163]=C_h_intern(&lf[163],4,"chop");
lf[164]=C_h_intern(&lf[164],4,"sort");
lf[165]=C_h_intern(&lf[165],19,"with-output-to-port");
lf[166]=C_h_intern(&lf[166],19,"current-output-port");
lf[167]=C_h_intern(&lf[167],8,"truncate");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol gc is enabled\012");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\027interrupts are enabled\012");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\010(64-bit)");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\010 (fixed)");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\010downward");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\006upward");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\001\374~%~\012                   Machine type:    \011~A ~A~%~\012                   Softwa"
"re type:   \011~A~%~\012                   Software version:\011~A~%~\012                   "
"Build platform:  \011~A~%~\012                   Include path:    \011~A~%~\012             "
"      Symbol-table load:\011~S~%  ~\012                     Avg bucket length:\011~S~%  ~"
"\012                     Total symbols:\011~S~%~\012                   Memory:\011heap size "
"is ~S bytes~A with ~S bytes currently in use~%~  \012                     nursery s"
"ize is ~S bytes, stack grows ~A~%");
lf[177]=C_h_intern(&lf[177],21,"\003sysinclude-pathnames");
lf[178]=C_h_intern(&lf[178],14,"build-platform");
lf[179]=C_h_intern(&lf[179],16,"software-version");
lf[180]=C_h_intern(&lf[180],13,"software-type");
lf[181]=C_h_intern(&lf[181],12,"machine-type");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[183]=C_h_intern(&lf[183],11,"make-string");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[185]=C_h_intern(&lf[185],8,"string<\077");
lf[186]=C_h_intern(&lf[186],15,"keyword->string");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[188]=C_h_intern(&lf[188],17,"memory-statistics");
lf[189]=C_h_intern(&lf[189],21,"\003syssymbol-table-info");
lf[190]=C_h_intern(&lf[190],2,"gc");
lf[191]=C_h_intern(&lf[191],19,"\003csibytevector-data");
lf[192]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376B\000\000\030vector of unsigned bytes\376\003\000\000\002\376\001\000\000\017u8vector-leng"
"th\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376B\000\000\026vector of signed byt"
"es\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000"
"\002\376B\000\000\037vector of unsigned 16-bit words\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\015u16vect"
"or-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376B\000\000\035vector of signed 16-bit words\376\003\000\000\002\376\001\000"
"\000\020s16vector-length\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376B\000\000\037ve"
"ctor of unsigned 32-bit words\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\015u32vector-ref\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376B\000\000\035vector of signed 32-bit words\376\003\000\000\002\376\001\000\000\020s32vec"
"tor-length\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376B\000\000\027vector of "
"32-bit floats\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"f64vector\376\003\000\000\002\376B\000\000\027vector of 64-bit floats\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\015f6"
"4vector-ref\376\377\016\376\377\016");
lf[194]=C_h_intern(&lf[194],7,"sprintf");
lf[195]=C_h_intern(&lf[195],7,"fprintf");
lf[196]=C_h_intern(&lf[196],8,"list-ref");
lf[197]=C_h_intern(&lf[197],10,"string-ref");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000 ~% (~A elements not displayed)~%");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000.\011(followed by ~A identical instance~a)~% ...~%");
lf[202]=C_h_intern(&lf[202],7,"newline");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\007 ~S: ~S");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\021~A of length ~S~%");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000$character ~S, code: ~S, #x~X, #o~O~%");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\016boolean true~%");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\017boolean false~%");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\014empty list~%");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\024end-of-file object~%");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\024unspecified object~%");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\016, character ~S");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\042exact integer ~S, #x~X, #o~O, #b~B");
lf[213]=C_h_intern(&lf[213],28,"\003sysarbitrary-unbound-symbol");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\017unbound value~%");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\013number ~S~%");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\006string");
lf[217]=C_h_intern(&lf[217],8,"\003syssize");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\006vector");
lf[219]=C_h_intern(&lf[219],8,"\003sysslot");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol with name ~S~%");
lf[221]=C_h_intern(&lf[221],18,"\003syssymbol->string");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\010keyword ");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\010unbound ");
lf[224]=C_h_intern(&lf[224],32,"\003syssymbol-has-toplevel-binding\077");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\004list");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\035pair with car ~S and cdr ~S~%");
lf[227]=C_h_intern(&lf[227],15,"describe-object");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\036procedure with code pointer ~X");
lf[229]=C_h_intern(&lf[229],25,"\003syspeek-unsigned-integer");
lf[230]=C_h_intern(&lf[230],9,"\000tinyclos");
lf[231]=C_h_intern(&lf[231],19,"\010tinyclosentity-tag");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\005input");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\006output");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\0005~A port of type ~A with name ~S and file pointer ~X~%");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000/locative~%  pointer ~X~%  index ~A~%  type ~A~%");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\004slot");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\010u8vector");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\010s8vector");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\011u16vector");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\011s16vector");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\011u32vector");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\011s32vector");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\011f32vector");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\011f64vector");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\024machine pointer ~X~%");
lf[247]=C_h_intern(&lf[247],11,"\003csihexdump");
lf[248]=C_h_intern(&lf[248],8,"\003sysbyte");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\022blob of size ~S:~%");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\030lambda information: ~s~%");
lf[251]=C_h_intern(&lf[251],23,"\003syslambda-info->string");
lf[252]=C_h_intern(&lf[252],10,"hash-table");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\013 ~S\011-> ~S~%");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\025  hash function: ~a~%");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000:hash-table with ~S element~a~%  comparison procedure: ~A~%");
lf[258]=C_h_intern(&lf[258],9,"condition");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\011\011~s: ~s~%");
lf[260]=C_h_intern(&lf[260],4,"cdar");
lf[261]=C_h_intern(&lf[261],4,"caar");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\005 ~s~%");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\017condition: ~s~%");
lf[264]=C_h_intern(&lf[264],6,"unveil");
lf[265]=C_h_intern(&lf[265],6,"append");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\031structure of type `~S\047:~%");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\020unknown object~%");
lf[268]=C_h_intern(&lf[268],15,"meroon-instance");
lf[269]=C_h_intern(&lf[269],9,"provided\077");
lf[270]=C_h_intern(&lf[270],6,"meroon");
lf[271]=C_h_intern(&lf[271],15,"\003sysbytevector\077");
lf[272]=C_h_intern(&lf[272],13,"\003syslocative\077");
lf[273]=C_h_intern(&lf[273],9,"instance\077");
lf[274]=C_h_intern(&lf[274],5,"port\077");
lf[275]=C_h_intern(&lf[275],11,"\003sysnumber\077");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\034statically allocated (0x~X) ");
lf[277]=C_h_intern(&lf[277],17,"\003sysblock-address");
lf[278]=C_h_intern(&lf[278],14,"set-describer!");
lf[279]=C_h_intern(&lf[279],3,"min");
lf[280]=C_h_intern(&lf[280],4,"dump");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\035can not dump immediate object");
lf[282]=C_h_intern(&lf[282],13,"\003syspeek-byte");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\023can not dump object");
lf[284]=C_h_intern(&lf[284],10,"write-char");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[286]=C_h_intern(&lf[286],5,"fxmod");
lf[287]=C_h_intern(&lf[287],11,"\003csideldups");
lf[288]=C_h_intern(&lf[288],6,"equal\077");
lf[291]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000D\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000i\376\003\000"
"\000\002\376\377\012\000\000R\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000n\376\003\000\000\002\376\377\012\000\000q\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000-\376\003\000\000\002\376\377\012\000\000I\376\003\000\000\002\376"
"\377\012\000\000p\376\003\000\000\002\376\377\012\000\000P\376\377\016");
lf[293]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\016-keyword-style\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\010-version\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376"
"B\000\000\006--help\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\021-case-insensiti"
"ve\376\003\000\000\002\376B\000\000\022-require-extension\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\014-no-warn"
"ings\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\015-include-path\376\003\000\000\002\376B\000\000\010-release\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000"
"\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pretty-print\376\377\016");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\007-script");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[300]=C_h_intern(&lf[300],16,"\003sysstring->list");
lf[301]=C_h_intern(&lf[301],7,"\003csirun");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\047missing argument to command-line option");
lf[303]=C_h_intern(&lf[303],8,"\003syslist");
lf[304]=C_h_intern(&lf[304],6,"\000match");
lf[305]=C_h_intern(&lf[305],4,"repl");
lf[306]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\014-no-warn"
"ings\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\002-"
"s\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\003\000\000\002\376B\000\000\003-ss\376\377\016");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\016-keyword-style");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\002-R");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[315]=C_h_intern(&lf[315],22,"\004corerequire-extension");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\002-e");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\005-eval");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\006-print");
lf[320]=C_h_intern(&lf[320],8,"for-each");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\002-P");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\015-pretty-print");
lf[323]=C_h_intern(&lf[323],4,"main");
lf[324]=C_h_intern(&lf[324],22,"command-line-arguments");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[329]=C_h_intern(&lf[329],17,"\003sysstring-append");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[331]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\010-no-init\376\377\016");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[333]=C_h_intern(&lf[333],13,"keyword-style");
lf[334]=C_h_intern(&lf[334],7,"\000prefix");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[336]=C_h_intern(&lf[336],5,"\000none");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[338]=C_h_intern(&lf[338],7,"\000suffix");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000+missing argument to `-keyword-style\047 option");
lf[340]=C_h_intern(&lf[340],7,"provide");
lf[341]=C_h_intern(&lf[341],5,"match");
lf[342]=C_h_intern(&lf[342],8,"string=\077");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[345]=C_h_intern(&lf[345],17,"register-feature!");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[348]=C_h_intern(&lf[348],14,"case-sensitive");
lf[349]=C_h_intern(&lf[349],16,"case-insensitive");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000-Identifiers and symbols are case insensitive\012");
lf[351]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016");
lf[352]=C_h_intern(&lf[352],12,"load-verbose");
lf[353]=C_h_intern(&lf[353],20,"\003syswarnings-enabled");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\026Warnings are disabled\012");
lf[355]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\377\016");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[357]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-v\376\003\000\000\002\376B\000\000\010-version\376\377\016");
lf[358]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376B\000\000\006--help\376\377\016");
lf[359]=C_h_intern(&lf[359],20,"\003syseval-debug-level");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[363]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[364]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\377\016");
lf[365]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-e\376\003\000\000\002\376B\000\000\002-p\376\003\000\000\002\376B\000\000\002-P\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pr"
"etty-print\376\377\016");
lf[366]=C_h_intern(&lf[366],20,"\003syswindows-platform");
lf[367]=C_h_intern(&lf[367],6,"script");
lf[368]=C_h_intern(&lf[368],12,"program-name");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\042missing or invalid script argument");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[371]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[372]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-k\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\013CSI_OPTIONS");
lf[375]=C_h_intern(&lf[375],25,"\003sysimplicit-exit-handler");
lf[376]=C_h_intern(&lf[376],15,"make-hash-table");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\006#;~A> ");
lf[378]=C_h_intern(&lf[378],11,"repl-prompt");
lf[379]=C_h_intern(&lf[379],6,"srfi-8");
lf[380]=C_h_intern(&lf[380],7,"srfi-16");
lf[381]=C_h_intern(&lf[381],7,"srfi-26");
lf[382]=C_h_intern(&lf[382],7,"srfi-31");
lf[383]=C_h_intern(&lf[383],7,"srfi-15");
lf[384]=C_h_intern(&lf[384],7,"srfi-11");
lf[385]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004void\376\377\016\376\377\016");
lf[386]=C_h_intern(&lf[386],25,"\003sysenable-runtime-macros");
lf[387]=C_h_intern(&lf[387],6,"define");
lf[388]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[389]=C_h_intern(&lf[389],12,"syntax-error");
lf[390]=C_h_intern(&lf[390],17,"define-for-syntax");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\022invalid identifier");
lf[392]=C_h_intern(&lf[392],18,"\003sysregister-macro");
lf[393]=C_h_intern(&lf[393],6,"letrec");
lf[394]=C_h_intern(&lf[394],3,"rec");
lf[395]=C_h_intern(&lf[395],22,"chicken-compile-shared");
lf[396]=C_h_intern(&lf[396],3,"not");
lf[397]=C_h_intern(&lf[397],9,"compiling");
lf[398]=C_h_intern(&lf[398],4,"unit");
lf[399]=C_h_intern(&lf[399],7,"declare");
lf[400]=C_h_intern(&lf[400],4,"else");
lf[401]=C_h_intern(&lf[401],11,"cond-expand");
lf[402]=C_h_intern(&lf[402],6,"export");
lf[403]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005begin\376\377\016");
lf[404]=C_h_intern(&lf[404],6,"static");
lf[405]=C_h_intern(&lf[405],5,"begin");
lf[406]=C_h_intern(&lf[406],7,"dynamic");
lf[407]=C_h_intern(&lf[407],16,"define-extension");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid clause specifier");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid clause syntax");
lf[410]=C_h_intern(&lf[410],22,"string-parse-start+end");
lf[411]=C_h_intern(&lf[411],7,"receive");
lf[412]=C_h_intern(&lf[412],28,"string-parse-final-start+end");
lf[413]=C_h_intern(&lf[413],20,"let-string-start+end");
lf[414]=C_h_intern(&lf[414],5,"apply");
lf[415]=C_h_intern(&lf[415],3,"let");
lf[416]=C_h_intern(&lf[416],10,"\003sysappend");
lf[417]=C_h_intern(&lf[417],2,"<>");
lf[418]=C_h_intern(&lf[418],5,"<...>");
lf[419]=C_h_intern(&lf[419],20,"\003sysregister-macro-2");
lf[420]=C_h_intern(&lf[420],4,"cute");
lf[421]=C_h_intern(&lf[421],3,"cut");
lf[422]=C_h_intern(&lf[422],3,"use");
lf[423]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[424]=C_h_intern(&lf[424],17,"require-extension");
lf[425]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[426]=C_h_intern(&lf[426],23,"\004corerequire-for-syntax");
lf[427]=C_h_intern(&lf[427],18,"require-for-syntax");
lf[428]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[429]=C_h_intern(&lf[429],18,"\003sysmake-structure");
lf[430]=C_h_intern(&lf[430],14,"\003sysstructure\077");
lf[431]=C_h_intern(&lf[431],15,"\000record-setters");
lf[432]=C_h_intern(&lf[432],19,"\003syscheck-structure");
lf[433]=C_h_intern(&lf[433],10,"\004corecheck");
lf[434]=C_h_intern(&lf[434],13,"\003sysblock-ref");
lf[435]=C_h_intern(&lf[435],18,"getter-with-setter");
lf[436]=C_h_intern(&lf[436],1,"y");
lf[437]=C_h_intern(&lf[437],14,"\003sysblock-set!");
lf[438]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[439]=C_h_intern(&lf[439],18,"define-record-type");
lf[440]=C_h_intern(&lf[440],3,"and");
lf[441]=C_h_intern(&lf[441],4,"memv");
lf[442]=C_h_intern(&lf[442],4,"cond");
lf[443]=C_h_intern(&lf[443],17,"handle-exceptions");
lf[444]=C_h_intern(&lf[444],10,"\003syssignal");
lf[445]=C_h_intern(&lf[445],14,"condition-case");
lf[446]=C_h_intern(&lf[446],9,"\003sysapply");
lf[447]=C_h_intern(&lf[447],10,"\003sysvalues");
lf[448]=C_h_intern(&lf[448],27,"\003sysregister-record-printer");
lf[449]=C_h_intern(&lf[449],21,"define-record-printer");
lf[450]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[451]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[452]=C_h_intern(&lf[452],2,"if");
lf[453]=C_h_intern(&lf[453],9,"split-at!");
lf[454]=C_h_intern(&lf[454],4,"take");
lf[455]=C_h_intern(&lf[455],4,"list");
lf[456]=C_h_intern(&lf[456],3,"cdr");
lf[457]=C_h_intern(&lf[457],4,"fx>=");
lf[458]=C_h_intern(&lf[458],3,"fx=");
lf[459]=C_h_intern(&lf[459],11,"case-lambda");
lf[460]=C_h_intern(&lf[460],11,"lambda-list");
lf[461]=C_h_intern(&lf[461],25,"\003sysdecompose-lambda-list");
lf[462]=C_h_intern(&lf[462],10,"fold-right");
lf[463]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[464]=C_h_intern(&lf[464],7,"require");
lf[465]=C_h_intern(&lf[465],6,"srfi-1");
lf[466]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[467]=C_h_intern(&lf[467],5,"null\077");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[469]=C_h_intern(&lf[469],14,"\004coreimmutable");
lf[470]=C_h_intern(&lf[470],14,"let-optionals*");
lf[471]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[472]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[473]=C_h_intern(&lf[473],8,"optional");
lf[474]=C_h_intern(&lf[474],9,":optional");
lf[475]=C_h_intern(&lf[475],14,"symbol->string");
lf[476]=C_h_intern(&lf[476],4,"let*");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[479]=C_h_intern(&lf[479],5,"%rest");
lf[480]=C_h_intern(&lf[480],4,"body");
lf[481]=C_h_intern(&lf[481],4,"cadr");
lf[482]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[483]=C_h_intern(&lf[483],13,"let-optionals");
lf[484]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[485]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[486]=C_h_intern(&lf[486],4,"eqv\077");
lf[487]=C_h_intern(&lf[487],6,"switch");
lf[488]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[489]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[490]=C_h_intern(&lf[490],2,"or");
lf[491]=C_h_intern(&lf[491],6,"select");
lf[492]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[493]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[494]=C_h_intern(&lf[494],21,"\003syssyntax-error-hook");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\037syntax error in \047and-let*\047 form");
lf[496]=C_h_intern(&lf[496],8,"and-let*");
lf[497]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[498]=C_h_intern(&lf[498],20,"\004coredefine-constant");
lf[499]=C_h_intern(&lf[499],15,"define-constant");
lf[500]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[501]=C_h_intern(&lf[501],18,"\004coredefine-inline");
lf[502]=C_h_intern(&lf[502],13,"define-inline");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[504]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[505]=C_h_intern(&lf[505],9,"nth-value");
lf[506]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[507]=C_h_intern(&lf[507],13,"letrec-values");
lf[508]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[509]=C_h_intern(&lf[509],10,"let-values");
lf[510]=C_h_intern(&lf[510],11,"let*-values");
lf[511]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[512]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[513]=C_h_intern(&lf[513],13,"define-values");
lf[514]=C_h_intern(&lf[514],11,"set!-values");
lf[515]=C_h_intern(&lf[515],6,"unless");
lf[516]=C_h_intern(&lf[516],4,"when");
lf[517]=C_h_intern(&lf[517],16,"\003sysdynamic-wind");
lf[518]=C_h_intern(&lf[518],12,"parameterize");
lf[519]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[520]=C_h_intern(&lf[520],10,"\000compiling");
lf[521]=C_h_intern(&lf[521],19,"\004corecompiletimetoo");
lf[522]=C_h_intern(&lf[522],20,"\004corecompiletimeonly");
lf[523]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[524]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[525]=C_h_intern(&lf[525],8,"run-time");
lf[526]=C_h_intern(&lf[526],7,"compile");
lf[527]=C_h_intern(&lf[527],12,"compile-time");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[529]=C_h_intern(&lf[529],9,"eval-when");
lf[530]=C_h_intern(&lf[530],8,"\003sysvoid");
lf[531]=C_h_intern(&lf[531],9,"fluid-let");
lf[532]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[533]=C_h_intern(&lf[533],11,"\000type-error");
lf[534]=C_h_intern(&lf[534],15,"\003syssignal-hook");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[536]=C_h_intern(&lf[536],6,"ensure");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[538]=C_h_intern(&lf[538],6,"assert");
lf[539]=C_h_intern(&lf[539],20,"with-input-from-file");
lf[540]=C_h_intern(&lf[540],27,"\003syscurrent-source-filename");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\014; including ");
lf[542]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[543]=C_h_intern(&lf[543],28,"\003sysresolve-include-filename");
lf[544]=C_h_intern(&lf[544],7,"include");
lf[545]=C_h_intern(&lf[545],12,"\004coredeclare");
lf[546]=C_h_intern(&lf[546],4,"time");
lf[547]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[548]=C_h_intern(&lf[548],3,"val");
lf[549]=C_h_intern(&lf[549],28,"\003sysstring->qualified-symbol");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[553]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[554]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[555]=C_h_intern(&lf[555],27,"\003sysqualified-symbol-prefix");
lf[556]=C_h_intern(&lf[556],13,"define-record");
lf[557]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[558]=C_h_intern(&lf[558],6,"symbol");
lf[559]=C_h_intern(&lf[559],11,"\003sysprovide");
lf[560]=C_h_intern(&lf[560],19,"chicken-more-macros");
C_register_lf2(lf,561,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1072,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1070 */
static void C_ccall f_1072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1075,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1073 in k1070 */
static void C_ccall f_1075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1078,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1076 in k1073 in k1070 */
static void C_ccall f_1078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1081,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_match_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1084,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 52   ##sys#provide */
t3=C_retrieve(lf[559]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[560]);}

/* k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1087,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[475]+1);
t4=*((C_word*)lf[112]+1);
t5=*((C_word*)lf[42]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8723,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   ##sys#register-macro */
t7=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[556],t6);}

/* a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8723(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_8723r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8723r(t0,t1,t2,t3);}}

static void C_ccall f_8723r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[556],t2,lf[558]);}

/* k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[556],((C_word*)t0)[5],lf[557]);}

/* k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 52   symbol->string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k8731 in k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8733,2,t0,t1);}
t2=(C_word)C_i_memq(lf[431],C_retrieve(lf[20]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8739,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 52   ##sys#qualified-symbol-prefix */
t4=C_retrieve(lf[555]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}

/* k8737 in k8731 in k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8945,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   string-append */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[554],((C_word*)t0)[3]);}

/* k8943 in k8737 in k8731 in k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[549]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8923 in k8737 in k8731 in k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8925,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[32],((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,lf[429],t3);
t5=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_list(&a,3,lf[387],t1,t5);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8901,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t6,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8921,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   string-append */
t9=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,((C_word*)t0)[3],lf[553]);}

/* k8919 in k8923 in k8737 in k8731 in k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[549]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8899 in k8923 in k8737 in k8731 in k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8901,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[80]);
t3=(C_word)C_a_i_list(&a,2,lf[32],((C_word*)t0)[10]);
t4=(C_word)C_a_i_list(&a,3,lf[430],lf[80],t3);
t5=(C_word)C_a_i_list(&a,3,lf[3],t2,t4);
t6=(C_word)C_a_i_list(&a,3,lf[387],t1,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8762,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8764,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t9,a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_8764(t11,t7,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k8899 in k8923 in k8737 in k8731 in k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_8764(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8764,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8774,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=t1,a[9]=t3,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 52   symbol->string */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k8772 in mapslots in k8899 in k8923 in k8737 in k8731 in k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8777,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8893,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   string-append */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[2],lf[551],t1,lf[552]);}

/* k8891 in k8772 in mapslots in k8899 in k8923 in k8737 in k8731 in k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[549]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8775 in k8772 in mapslots in k8899 in k8923 in k8737 in k8731 in k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8780,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8889,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   string-append */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[3],lf[550],((C_word*)t0)[2]);}

/* k8887 in k8775 in k8772 in mapslots in k8899 in k8923 in k8737 in k8731 in k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   ##sys#string->qualified-symbol */
t2=C_retrieve(lf[549]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8778 in k8775 in k8772 in mapslots in k8899 in k8923 in k8737 in k8731 in k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[167],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8780,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[80],lf[548]);
t3=(C_word)C_a_i_list(&a,2,lf[32],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[432],lf[80],t3);
t5=(C_word)C_a_i_list(&a,2,lf[433],t4);
t6=(C_word)C_a_i_list(&a,4,lf[437],lf[80],((C_word*)t0)[7],lf[548]);
t7=(C_word)C_a_i_list(&a,4,lf[3],t2,t5,t6);
t8=(C_word)C_a_i_list(&a,3,lf[387],((C_word*)t0)[6],t7);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8811,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t8,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t10=(C_word)C_a_i_list(&a,1,lf[80]);
t11=(C_word)C_a_i_list(&a,2,lf[32],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[432],lf[80],t11);
t13=(C_word)C_a_i_list(&a,2,lf[433],t12);
t14=(C_word)C_a_i_list(&a,3,lf[434],lf[80],((C_word*)t0)[7]);
t15=(C_word)C_a_i_list(&a,4,lf[3],t10,t13,t14);
t16=t9;
f_8811(t16,(C_word)C_a_i_list(&a,3,lf[435],t15,((C_word*)t0)[6]));}
else{
t10=(C_word)C_a_i_list(&a,1,lf[80]);
t11=(C_word)C_a_i_list(&a,2,lf[32],((C_word*)t0)[8]);
t12=(C_word)C_a_i_list(&a,3,lf[432],lf[80],t11);
t13=(C_word)C_a_i_list(&a,2,lf[433],t12);
t14=(C_word)C_a_i_list(&a,3,lf[434],lf[80],((C_word*)t0)[7]);
t15=t9;
f_8811(t15,(C_word)C_a_i_list(&a,4,lf[3],t10,t13,t14));}}

/* k8809 in k8778 in k8775 in k8772 in mapslots in k8899 in k8923 in k8737 in k8731 in k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_8811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8811,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[387],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,3,lf[405],((C_word*)t0)[6],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8791,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 52   mapslots */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8764(t7,t4,t5,t6);}

/* k8789 in k8809 in k8778 in k8775 in k8772 in mapslots in k8899 in k8923 in k8737 in k8731 in k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8791,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8760 in k8899 in k8923 in k8737 in k8731 in k8728 in k8725 in a8722 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8762,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[405],t3));}

/* k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1090,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8635,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[411],t3);}

/* a8634 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8635(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr3r,(void*)f_8635r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8635r(t0,t1,t2,t3);}}

static void C_ccall f_8635r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(23);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[5],t4,lf[303]));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8652,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[411],t2,lf[460]);}}

/* k8650 in a8634 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[411],((C_word*)t0)[3],lf[547]);}

/* k8653 in k8650 in a8634 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=t2;
f_8661(t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
f_8661(t3,C_SCHEME_FALSE);}}

/* k8659 in k8653 in k8650 in a8634 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_8661(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8661,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[415],t7));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[5],t3,t6));}}

/* k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1093,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8594,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 52   ##sys#register-macro */
t5=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[546],t4);}

/* a8593 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8594(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_8594r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8594r(t0,t1,t2);}}

static void C_ccall f_8594r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8598,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   gensym */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[98]);}

/* k8596 in a8593 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8598,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[101]);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[3],t3);
t5=(C_word)C_a_i_list(&a,1,lf[100]);
t6=(C_word)C_a_i_list(&a,2,lf[99],t5);
t7=(C_word)C_a_i_list(&a,3,lf[446],lf[447],t1);
t8=(C_word)C_a_i_list(&a,4,lf[3],t1,t6,t7);
t9=(C_word)C_a_i_list(&a,3,lf[5],t4,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[405],t2,t9));}

/* k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1096,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8578,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[399],t3);}

/* a8577 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8578(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_8578r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8578r(t0,t1,t2);}}

static void C_ccall f_8578r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8586,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8588,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#map */
t5=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a8587 in a8577 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8588,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[32],t2));}

/* k8584 in a8577 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8586,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[545],t1));}

/* k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1099,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[539]);
t4=*((C_word*)lf[30]+1);
t5=*((C_word*)lf[159]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8501,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   ##sys#register-macro */
t7=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[544],t6);}

/* a8500 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8501(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8501,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   ##sys#resolve-include-filename */
t4=C_retrieve(lf[543]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_SCHEME_TRUE);}

/* k8503 in a8500 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8573,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   load-verbose */
t4=C_retrieve(lf[352]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k8571 in k8503 in a8500 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 52   print */
t2=*((C_word*)lf[26]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[541],((C_word*)t0)[2],lf[542]);}
else{
t2=((C_word*)t0)[3];
f_8508(2,t2,C_SCHEME_UNDEFINED);}}

/* k8506 in k8503 in a8500 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8515,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   with-input-from-file */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[5],t3);}

/* a8516 in k8506 in k8503 in a8500 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8517,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8523,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8564,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[517]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t1,t6,t7,t8);}

/* a8563 in a8516 in k8506 in k8503 in a8500 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8564,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[540]));
t3=C_mutate((C_word*)lf[540]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[15]));}

/* a8530 in a8516 in k8506 in k8503 in a8500 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8539,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8537 in a8530 in a8516 in k8506 in k8503 in a8500 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8539,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8541,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8541(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* do38 in k8537 in a8530 in a8516 in k8506 in k8503 in a8500 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_8541(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8541,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 52   reverse */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8558,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   read */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k8556 in do38 in k8537 in a8530 in a8516 in k8506 in k8503 in a8500 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8558,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_8541(t3,((C_word*)t0)[2],t1,t2);}

/* a8522 in a8516 in k8506 in k8503 in a8500 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8523,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[540]));
t3=C_mutate((C_word*)lf[540]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(lf[15]));}

/* k8513 in k8506 in k8503 in a8500 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8515,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[405],t1));}

/* k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1102,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8441,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[538],t3);}

/* a8440 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8441(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_8441r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8441r(t0,t1,t2,t3);}}

static void C_ccall f_8441r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8445,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t3);
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,2,lf[32],lf[537]);
t7=t4;
f_8445(t7,(C_word)C_a_i_list(&a,2,lf[469],t6));}
else{
t6=t4;
f_8445(t6,(C_word)C_slot(t3,C_fix(0)));}}

/* k8443 in a8440 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_8445(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8445,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[433],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[4]);
t4=(C_word)C_a_i_list(&a,2,lf[32],((C_word*)t0)[4]);
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_slot(((C_word*)t0)[3],C_fix(1)):C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_cons(&a,2,t1,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[55],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[452],t2,t3,t10));}

/* k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1105,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8382,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[536],t3);}

/* a8381 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_8382r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8382r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8382r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8386,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   gensym */
t6=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k8384 in a8381 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8386,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t5=(C_word)C_a_i_list(&a,2,lf[433],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8413,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t7=t6;
f_8413(t7,((C_word*)t0)[2]);}
else{
t7=(C_word)C_a_i_list(&a,2,lf[32],lf[535]);
t8=(C_word)C_a_i_list(&a,2,lf[469],t7);
t9=(C_word)C_a_i_list(&a,2,lf[32],((C_word*)t0)[4]);
t10=t6;
f_8413(t10,(C_word)C_a_i_list(&a,3,t8,t1,t9));}}

/* k8411 in k8384 in a8381 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_8413(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8413,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[533],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[534],t2);
t4=(C_word)C_a_i_list(&a,4,lf[452],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[415],((C_word*)t0)[2],t4));}

/* k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1108,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8208,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 52   ##sys#register-macro */
t5=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[531],t4);}

/* a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8208(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_8208r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8208r(t0,t1,t2,t3);}}

static void C_ccall f_8208r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8212,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[531],t2,lf[532]);}

/* k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   ##sys#map */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[131]+1),((C_word*)t0)[3]);}

/* k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8218,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 52   ##sys#map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8375 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8376(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8376,3,t0,t1,t2);}
/* csi.scm: 52   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8221,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8370,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 52   ##sys#map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a8369 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8370(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8370,3,t0,t1,t2);}
/* csi.scm: 52   gensym */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8228,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8332,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8368,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   ##sys#map */
t5=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[481]+1),((C_word*)t0)[2]);}

/* k8366 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   map */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[303]+1),((C_word*)t0)[2],t1);}

/* k8330 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8336,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8340,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(((C_word*)t0)[2]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8346,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_8346(t8,t3,t4);}

/* loop in k8330 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_8346(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8346,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8360,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
/* csi.scm: 52   loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k8358 in loop in k8330 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8360,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k8338 in k8330 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   map */
t2=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[303]+1),((C_word*)t0)[2],t1);}

/* k8334 in k8330 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[416]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8226 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8296,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8324,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   map */
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* a8323 in k8226 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8324,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8298 in k8226 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8304,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8308,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8318,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   map */
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8317 in k8298 in k8226 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8318,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8306 in k8298 in k8226 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8308,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[530]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[416]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8302 in k8298 in k8226 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[416]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8294 in k8226 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8296,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[7]);
t5=(C_word)C_a_i_cons(&a,2,lf[3],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8252,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8256,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8280,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   map */
t9=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a8279 in k8294 in k8226 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8280,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8254 in k8294 in k8226 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8260,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8264,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8274,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   map */
t5=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8273 in k8254 in k8294 in k8226 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8274,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k8262 in k8254 in k8294 in k8226 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8264,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[530]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[416]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8258 in k8254 in k8294 in k8226 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[416]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8250 in k8294 in k8226 in k8219 in k8216 in k8213 in k8210 in a8207 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8252,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=(C_word)C_a_i_list(&a,4,lf[517],((C_word*)t0)[5],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[415],((C_word*)t0)[2],t4));}

/* k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1111,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8113,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[529],t3);}

/* a8112 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8113(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr3r,(void*)f_8113r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8113r(t0,t1,t2,t3);}}

static void C_ccall f_8113r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(24);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(C_word)C_a_i_cons(&a,2,lf[405],t3);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8120,a[2]=t5,a[3]=t10,a[4]=t1,a[5]=t9,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8149,a[2]=t7,a[3]=t9,a[4]=t5,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_8149(t15,t11,t2);}

/* loop in a8112 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_8149(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8149,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8162,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[65]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t7=t4;
f_8162(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[93]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[525]));
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t9=t4;
f_8162(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[526]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[527]));
if(C_truep(t9)){
t10=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t11=t4;
f_8162(2,t11,t10);}
else{
t10=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 52   ##sys#error */
t11=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t4,lf[528],t10);}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8160 in loop in a8112 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* csi.scm: 52   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8149(t3,((C_word*)t0)[2],t2);}

/* k8118 in a8112 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8120,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[520],C_retrieve(lf[20])))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_a_i_list(&a,2,lf[521],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_a_i_list(&a,2,lf[522],((C_word*)t0)[3]):(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[3]:lf[523]))));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[3]:lf[524]));}}

/* k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[131]+1);
t4=*((C_word*)lf[481]+1);
t5=*((C_word*)lf[2]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8003,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   ##sys#register-macro */
t7=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,lf[518],t6);}

/* a8002 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8003(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_8003r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8003r(t0,t1,t2,t3);}}

static void C_ccall f_8003r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8007,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[518],t2,lf[519]);}

/* k8005 in a8002 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 52   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8008 in k8005 in a8002 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 52   ##sys#map */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8011 in k8008 in k8005 in a8002 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8016,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 52   ##sys#map */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8014 in k8011 in k8008 in k8005 in a8002 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8019,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8107,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8106 in k8014 in k8011 in k8008 in k8005 in a8002 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8107,3,t0,t1,t2);}
/* csi.scm: 52   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8017 in k8014 in k8011 in k8008 in k8005 in a8002 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8101,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8100 in k8017 in k8014 in k8011 in k8008 in k8005 in a8002 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8101,3,t0,t1,t2);}
/* csi.scm: 52   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k8020 in k8017 in k8014 in k8011 in k8008 in k8005 in a8002 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8029,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8095,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   map */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[303]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k8093 in k8020 in k8017 in k8014 in k8011 in k8008 in k8005 in a8002 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8099,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   map */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[303]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8097 in k8093 in k8020 in k8017 in k8014 in k8011 in k8008 in k8005 in a8002 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   ##sys#append */
t2=*((C_word*)lf[416]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8027 in k8020 in k8017 in k8014 in k8011 in k8008 in k8005 in a8002 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8065,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8067,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   map */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8066 in k8027 in k8020 in k8017 in k8014 in k8011 in k8008 in k8005 in a8002 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[39],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8067,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_list(&a,2,lf[98],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t3);
t8=(C_word)C_a_i_list(&a,3,lf[6],t3,lf[98]);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,4,lf[415],t6,t7,t8));}

/* k8063 in k8027 in k8020 in k8017 in k8014 in k8011 in k8008 in k8005 in a8002 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_8065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8065,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,lf[3],t6);
t8=(C_word)C_a_i_list(&a,4,lf[517],((C_word*)t0)[5],t7,((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,3,lf[415],t5,t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,3,lf[415],((C_word*)t0)[2],t9));}

/* k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1117,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7993,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[516],t3);}

/* a7992 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7993(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_7993r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7993r(t0,t1,t2,t3);}}

static void C_ccall f_7993r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(12);
t4=(C_word)C_a_i_cons(&a,2,lf[405],t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[452],t2,t4));}

/* k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1120,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7979,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[515],t3);}

/* a7978 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7979(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_7979r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7979r(t0,t1,t2,t3);}}

static void C_ccall f_7979r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(18);
t4=(C_word)C_a_i_list(&a,1,lf[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[405],t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[452],t2,t4,t5));}

/* k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1120,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1121,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1194,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   ##sys#register-macro */
t5=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[514],t3);}

/* k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1197,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 52   ##sys#register-macro */
t3=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[513],((C_word*)t0)[2]);}

/* k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1200,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7646,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7677,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7717,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   ##sys#register-macro-2 */
t10=C_retrieve(lf[419]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t2,lf[509],t9);}

/* a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7717(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7717,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[509],t2,lf[512]);}

/* k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7721,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* map */
t5=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[131]+1),t2);}

/* k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7733,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7939,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7939(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_7939(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7939,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7952,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t4))){
/* csi.scm: 52   append */
t6=*((C_word*)lf[265]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t4))){
/* csi.scm: 52   append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_7646(t6,t5,t4,t3);}
else{
t6=t5;
f_7952(2,t6,(C_word)C_a_i_cons(&a,2,t4,t3));}}}}

/* k7950 in loop in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 52   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7939(t3,((C_word*)t0)[2],t2,t1);}

/* k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7929,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a7928 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7929(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7929,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7937,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   gensym */
t4=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7935 in a7928 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7937,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7737,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7748,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7883,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_7883(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_7883(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7883,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* csi.scm: 52   reverse */
t4=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7899,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7923,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   map* */
t7=((C_word*)((C_word*)t0)[3])[1];
f_7677(t7,t6,((C_word*)t0)[2],t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7916,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   lookup */
t7=((C_word*)t0)[2];
f_7737(3,t7,t6,t4);}}}

/* k7914 in loop in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7916,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7899(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7921 in loop in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7923,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7899(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7897 in loop in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_7899(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 52   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7883(t3,((C_word*)t0)[2],t2,t1);}

/* k7746 in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7755,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7877,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7876 in k7746 in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7877(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7877,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_cadr(t2));}

/* k7753 in k7746 in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7755,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7757,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7757(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k7753 in k7746 in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_7757(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7757,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7775,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7777,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7791,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7871,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 52   cdar */
t8=*((C_word*)lf[260]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t7=t5;
f_7791(t7,C_SCHEME_FALSE);}}}

/* k7869 in fold in k7753 in k7746 in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7791(t2,(C_word)C_i_nullp(t1));}

/* k7789 in fold in k7753 in k7746 in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_7791(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7791,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 52   caar */
t3=*((C_word*)lf[261]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7845,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 52   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_7757(t9,t5,t6,t7,t8);}}

/* k7843 in k7789 in fold in k7753 in k7746 in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7845,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t2));}

/* k7820 in k7789 in fold in k7753 in k7746 in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7822,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7802,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[4]);
t7=(C_word)C_i_cdr(((C_word*)t0)[6]);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 52   fold */
t9=((C_word*)((C_word*)t0)[2])[1];
f_7757(t9,t5,t6,t7,t8);}

/* k7800 in k7820 in k7789 in fold in k7753 in k7746 in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7802,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[415],((C_word*)t0)[2],t1));}

/* a7776 in fold in k7753 in k7746 in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7777(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7777,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7785,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   lookup */
t4=((C_word*)t0)[2];
f_7737(3,t4,t3,t2);}

/* k7783 in a7776 in fold in k7753 in k7746 in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7785,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k7773 in fold in k7753 in k7746 in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7775,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[415],t2));}

/* lookup in k7734 in k7731 in k7728 in k7719 in a7644 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7737,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* map* in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_7677(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7677,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7700,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* csi.scm: 52   proc */
t6=t2;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
/* csi.scm: 52   proc */
t4=t2;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}}}

/* k7698 in map* in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7704,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 52   map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7677(t4,t2,((C_word*)t0)[2],t3);}

/* k7702 in k7698 in map* in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7704,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_7646(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7646,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7667,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* csi.scm: 52   append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}}

/* k7665 in append* in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7667,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7595,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro-2 */
t4=C_retrieve(lf[419]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[510],t3);}

/* a7594 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7595(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7595,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7599,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[510],t2,lf[511]);}

/* k7597 in a7594 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7599,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7610,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7610(t7,((C_word*)t0)[2],t2);}

/* fold in k7597 in a7594 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_7610(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7610,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[415],t3));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7635,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* csi.scm: 52   fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k7633 in fold in k7597 in a7594 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7635,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[509],((C_word*)t0)[2],t1));}

/* k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1206,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7475,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro-2 */
t4=C_retrieve(lf[419]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[507],t3);}

/* a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7475,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7479,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[507],t2,lf[508]);}

/* k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7479,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7488,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7587,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7589,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a7588 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7589(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7589,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k7585 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[416]+1),t1);}

/* k7486 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7491,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7575,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a7574 in k7486 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7575(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7575,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7583,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   gensym */
t4=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7581 in a7574 in k7486 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7583,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7489 in k7486 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7492,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7511,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7569,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7568 in k7489 in k7486 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7569(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7569,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,lf[506]));}

/* k7509 in k7489 in k7486 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7515,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7519,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7521,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7520 in k7509 in k7489 in k7486 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7521,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7541,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
/* map */
t7=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}

/* k7539 in a7520 in k7509 in k7489 in k7486 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7545,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7547,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7546 in k7539 in a7520 in k7509 in k7489 in k7486 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7547,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7555,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   lookup */
t4=((C_word*)t0)[2];
f_7492(3,t4,t3,t2);}

/* k7553 in a7546 in k7539 in a7520 in k7509 in k7489 in k7486 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7555,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[6],((C_word*)t0)[2],t1));}

/* k7543 in k7539 in a7520 in k7509 in k7489 in k7486 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7545,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t3));}

/* k7517 in k7509 in k7489 in k7486 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[416]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7513 in k7509 in k7489 in k7486 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7515,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[415],t2));}

/* lookup in k7489 in k7486 in k7477 in a7474 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7492(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7492,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1209,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7454,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[505],t3);}

/* a7453 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7454,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7458,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k7456 in a7453 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7458,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,3,lf[196],t1,((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[3],t1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[5],t2,t4));}

/* k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1288,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7444,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro-2 */
t4=C_retrieve(lf[419]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[502],t3);}

/* a7443 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7444,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1215,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[502],t2,lf[504]);}

/* k1213 in a7443 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1215,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1224,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=t5;
f_1224(t9,(C_word)C_a_i_cons(&a,2,lf[3],t8));}
else{
t6=t5;
f_1224(t6,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k1222 in k1213 in a7443 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_1224(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1224,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1227,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_pairp(t1);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1240,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_1240(t6,t4);}
else{
t6=(C_word)C_i_car(t1);
t7=(C_word)C_eqp(lf[3],t6);
t8=t5;
f_1240(t8,(C_word)C_i_not(t7));}}

/* k1238 in k1222 in k1213 in a7443 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_1240(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 52   syntax-error */
t2=C_retrieve(lf[389]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[502],lf[503],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1227(2,t2,C_SCHEME_UNDEFINED);}}

/* k1225 in k1222 in k1213 in a7443 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1227,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[32],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[501],t3));}

/* k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1291,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7423,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro-2 */
t4=C_retrieve(lf[419]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[499],t3);}

/* a7422 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7423(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7423,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7427,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[499],t2,lf[500]);}

/* k7425 in a7422 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7427,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[32],t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[498],t3,t4));}

/* k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7307,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro-2 */
t4=C_retrieve(lf[419]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[496],t3);}

/* a7306 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7307,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7311,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[496],t2,lf[497]);}

/* k7309 in a7306 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7311,2,t0,t1);}
t2=(C_word)C_i_listp(((C_word*)t0)[3]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_7320(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=t4;
f_7320(t6,(C_word)C_fixnum_lessp(t5,C_fix(2)));}}

/* k7318 in k7309 in a7306 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_7320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7320,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 52   ##sys#syntax-error-hook */
t2=C_retrieve(lf[494]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[495],((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7334,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7334(t7,((C_word*)t0)[3],t2);}}

/* fold in k7318 in k7309 in a7306 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_7334(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7334,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[405],((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_not_pair_p(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7363,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   fold */
t15=t5;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t5=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_slot(t3,C_fix(0));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7380,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   fold */
t15=t7;
t16=t4;
t1=t15;
t2=t16;
goto loop;}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_cadr(t3);
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7398,a[2]=t9,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   fold */
t15=t10;
t16=t4;
t1=t15;
t2=t16;
goto loop;}}}}

/* k7396 in fold in k7318 in k7309 in a7306 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7398,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[452],((C_word*)t0)[4],t1,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[415],((C_word*)t0)[2],t2));}

/* k7378 in fold in k7318 in k7309 in a7306 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7380,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[452],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k7361 in fold in k7318 in k7309 in a7306 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7363,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[452],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1297,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7208,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 52   ##sys#register-macro-2 */
t5=C_retrieve(lf[419]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[491],t4);}

/* a7207 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7208,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7218,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7216 in a7207 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7218,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7229,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7231,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7231(t8,t4,((C_word*)t0)[2]);}

/* expand in k7216 in a7207 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_7231(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7231,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7247,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[491],t3,lf[492]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[493]);}}

/* k7245 in expand in k7216 in a7207 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7247,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[400],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[405],t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7283,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7285,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
/* map */
t7=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* a7284 in k7245 in expand in k7216 in a7207 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7285,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[486],((C_word*)t0)[2],t2));}

/* k7281 in k7245 in expand in k7216 in a7207 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7283,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[490],t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[405],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7275,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   expand */
t6=((C_word*)((C_word*)t0)[3])[1];
f_7231(t6,t5,((C_word*)t0)[2]);}

/* k7273 in k7281 in k7245 in expand in k7216 in a7207 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7275,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[452],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k7227 in k7216 in a7207 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7229,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[415],((C_word*)t0)[2],t1));}

/* k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve(lf[7]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7119,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 52   ##sys#register-macro-2 */
t5=C_retrieve(lf[419]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,lf[487],t4);}

/* a7118 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7119,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7129,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k7127 in a7118 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7129,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7140,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7142,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7142(t8,t4,((C_word*)t0)[2]);}

/* expand in k7127 in a7118 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_7142(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7142,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7158,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[487],t3,lf[488]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[489]);}}

/* k7156 in expand in k7127 in a7118 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7158,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[400],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[405],t4));}
else{
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,3,lf[486],((C_word*)t0)[4],t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,lf[405],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7186,a[2]=t7,a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   expand */
t9=((C_word*)((C_word*)t0)[3])[1];
f_7142(t9,t8,((C_word*)t0)[2]);}}

/* k7184 in k7156 in expand in k7127 in a7118 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7186,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[452],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k7138 in k7127 in a7118 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7140,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[415],((C_word*)t0)[2],t1));}

/* k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1303,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6833,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[483],t3);}

/* a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6833r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6833r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6833r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7030,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[483],t3,lf[485]);}

/* k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[483],((C_word*)t0)[4],lf[484]);}

/* k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7036,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* map */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[131]+1),((C_word*)t0)[2]);}

/* k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7037,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7052,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7109,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a7108 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7109(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7109,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7117,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 52   prefix-sym */
f_7037(t3,lf[482],t2);}

/* k7115 in a7108 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   gensym */
t2=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7055,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* map */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[481]+1),((C_word*)t0)[2]);}

/* k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7058,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 52   gensym */
t3=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[480]);}

/* k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 52   gensym */
t3=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[479]);}

/* k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7099,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}

/* a7098 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7099(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7099,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7107,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 52   prefix-sym */
f_7037(t3,lf[478],t2);}

/* k7105 in a7098 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   gensym */
t2=C_retrieve(lf[7]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7062 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7067,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[5];
t5=t1;
t6=((C_word*)t0)[2];
t7=C_retrieve(lf[7]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6844,a[2]=t5,a[3]=t6,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   reverse */
t9=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}

/* k6842 in k7062 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   reverse */
t3=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6846 in k6842 in k7062 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6852,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   reverse */
t3=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6850 in k6846 in k6842 in k7062 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6852,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6854,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6854(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k6850 in k6846 in k6842 in k7062 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_6854(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6854,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6899,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 52   reverse */
t9=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t6);}}

/* k6897 in recur in k6850 in k6846 in k6842 in k7062 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6911,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   reverse */
t4=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k6909 in k6897 in recur in k6850 in k6846 in k6842 in k7062 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6911,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* ##sys#append */
t4=*((C_word*)lf[416]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k6905 in k6897 in recur in k6850 in k6846 in k6842 in k7062 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6907,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6875,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
t7=(C_word)C_i_cdr(((C_word*)t0)[4]);
t8=(C_word)C_i_car(((C_word*)t0)[5]);
/* csi.scm: 52   recur */
t9=((C_word*)((C_word*)t0)[3])[1];
f_6854(t9,t5,((C_word*)t0)[2],t6,t7,t8);}

/* k6873 in k6905 in k6897 in recur in k6850 in k6846 in k6842 in k7062 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6875,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7070,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[9];
t7=C_retrieve(lf[7]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6927,a[2]=t9,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_6927(t11,t2,t3,t4,C_SCHEME_END_OF_LIST);}

/* recur in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_6927(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6927,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_a_i_list(&a,2,lf[467],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,lf[433],t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6961,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   reverse */
t8=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,lf[467],((C_word*)t0)[4]);
t7=(C_word)C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7027,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t6,a[7]=t1,a[8]=t5,a[9]=((C_word*)t0)[4],a[10]=t7,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 52   reverse */
t9=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t4);}}

/* k7025 in recur in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7027,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_list(&a,2,lf[131],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_list(&a,2,lf[456],((C_word*)t0)[9]);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6991,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
t11=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[3]);
/* csi.scm: 52   recur */
t12=((C_word*)((C_word*)t0)[2])[1];
f_6927(t12,t8,t9,t10,t11);}

/* k6989 in k7025 in recur in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6991,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[415],((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[452],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k6959 in recur in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6961,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,2,lf[32],lf[477]);
t4=(C_word)C_a_i_list(&a,2,lf[469],t3);
t5=(C_word)C_a_i_list(&a,3,lf[55],t4,((C_word*)t0)[4]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,4,lf[452],((C_word*)t0)[2],t2,t5));}

/* k7068 in k7065 in k7062 in k7059 in k7056 in k7053 in k7050 in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7070,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,lf[3],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[476],t7,t1));}

/* prefix-sym in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_7037(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7037,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7045,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7049,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   symbol->string */
t6=*((C_word*)lf[475]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}

/* k7047 in prefix-sym in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   string-append */
t2=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7043 in prefix-sym in k7034 in k7031 in k7028 in a6832 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_7045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   string->symbol */
t2=*((C_word*)lf[112]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6776,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[473],t3);}

/* a6775 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6776(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6776,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6780,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6778 in a6775 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6780,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,2,lf[467],t1);
t5=(C_word)C_a_i_list(&a,2,lf[456],t1);
t6=(C_word)C_a_i_list(&a,2,lf[467],t5);
t7=(C_word)C_a_i_list(&a,2,lf[433],t6);
t8=(C_word)C_a_i_list(&a,2,lf[131],t1);
t9=(C_word)C_a_i_list(&a,2,lf[32],lf[1]);
t10=(C_word)C_a_i_list(&a,2,lf[469],t9);
t11=(C_word)C_a_i_list(&a,3,lf[55],t10,t1);
t12=(C_word)C_a_i_list(&a,4,lf[452],t7,t8,t11);
t13=(C_word)C_a_i_list(&a,4,lf[452],t4,((C_word*)t0)[3],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[415],t3,t13));}

/* k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6770,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro-2 */
t4=C_retrieve(lf[419]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[474],t3);}

/* a6769 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6770(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6770,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[473],t2));}

/* k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6617,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[470],t3);}

/* a6616 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6617r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6617r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6617r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6621,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[470],t3,lf[472]);}

/* k6619 in a6616 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t3=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[470],((C_word*)t0)[3],lf[471]);}

/* k6622 in k6619 in a6616 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6625 in k6622 in k6619 in a6616 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6627,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6638,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6640,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_6640(t8,t4,t1,((C_word*)t0)[2]);}

/* loop in k6625 in k6622 in k6619 in a6616 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_6640(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6640,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_a_i_list(&a,2,lf[467],t2);
t5=(C_word)C_a_i_list(&a,2,lf[433],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,lf[415],t6);
t8=(C_word)C_a_i_list(&a,2,lf[32],lf[468]);
t9=(C_word)C_a_i_list(&a,2,lf[469],t8);
t10=(C_word)C_a_i_list(&a,3,lf[55],t9,t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,4,lf[452],t5,t7,t10));}
else{
t4=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6690,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 52   gensym */
t6=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_a_i_list(&a,2,t4,t2);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[415],t7));}}}

/* k6688 in loop in k6625 in k6622 in k6619 in a6616 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6690,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,lf[467],((C_word*)t0)[5]);
t4=(C_word)C_i_cadr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_list(&a,2,lf[131],((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,4,lf[452],t3,t4,t5);
t7=(C_word)C_a_i_list(&a,2,t2,t6);
t8=(C_word)C_a_i_list(&a,2,lf[467],((C_word*)t0)[5]);
t9=(C_word)C_a_i_list(&a,2,lf[32],C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_list(&a,2,lf[456],((C_word*)t0)[5]);
t11=(C_word)C_a_i_list(&a,4,lf[452],t8,t9,t10);
t12=(C_word)C_a_i_list(&a,2,t1,t11);
t13=(C_word)C_a_i_list(&a,2,t7,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6701,a[2]=t13,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 52   loop */
t16=((C_word*)((C_word*)t0)[2])[1];
f_6640(t16,t14,t1,t15);}

/* k6699 in k6688 in loop in k6625 in k6622 in k6619 in a6616 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6701,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[415],((C_word*)t0)[2],t1));}

/* k6636 in k6625 in k6622 in k6619 in a6616 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6638,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[415],((C_word*)t0)[2],t1));}

/* k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6341,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro-2 */
t4=C_retrieve(lf[419]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[459],t3);}

/* a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6341(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6341,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6375,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[459],t2,lf[466]);}

/* k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   require */
t3=C_retrieve(lf[464]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[465]);}

/* k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6602,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6604,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6603 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6604,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6614,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#decompose-lambda-list */
t5=C_retrieve(lf[461]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a6613 in a6603 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6614,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k6600 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[279]+1),t1);}

/* k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6384,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6350,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6350(t7,t2,C_fix(0));}

/* loop in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_6350(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6350,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6364,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   gensym */
t4=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k6362 in loop in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6368,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 52   loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6350(t4,t2,t3);}

/* k6366 in k6362 in loop in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6368,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 52   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 52   append */
t3=*((C_word*)lf[265]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[6]);}

/* k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6397,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[71],((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6409,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6411,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   fold-right */
t7=C_retrieve(lf[462]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,lf[463],((C_word*)t0)[2]);}

/* a6410 in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6411,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 52   ##sys#decompose-lambda-list */
t6=C_retrieve(lf[461]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t4,t5);}

/* a6420 in a6410 in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6421,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6425,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* csi.scm: 52   ##sys#check-syntax */
t7=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,lf[459],t6,lf[460]);}

/* k6423 in a6420 in a6410 in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6425,2,t0,t1);}
t2=(C_word)C_fixnum_difference(((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6435,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=(C_word)C_i_zerop(t2);
t5=t3;
f_6435(t5,(C_truep(t4)?C_SCHEME_TRUE:(C_word)C_a_i_list(&a,3,lf[457],((C_word*)t0)[2],t2)));}
else{
t4=t3;
f_6435(t4,(C_word)C_a_i_list(&a,3,lf[458],((C_word*)t0)[2],t2));}}

/* k6433 in k6423 in a6420 in a6410 in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_6435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6435,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6439,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6441,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a6450 in k6433 in k6423 in a6420 in a6410 in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6451,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6455,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6470,a[2]=t6,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_6470(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a6450 in k6433 in k6423 in a6420 in a6410 in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_6470(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6470,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[4])){
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[415],t7));}
else{
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_cadr(((C_word*)t0)[3]));}
else{
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[415],t6));}}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6526,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k6524 in build in a6450 in k6433 in k6423 in a6420 in a6410 in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6526,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,lf[131],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,2,lf[456],((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t1,t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6537,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* csi.scm: 52   build */
t11=((C_word*)((C_word*)t0)[2])[1];
f_6470(t11,t8,t10,t1);}
else{
/* csi.scm: 52   build */
t10=((C_word*)((C_word*)t0)[2])[1];
f_6470(t10,t8,C_SCHEME_END_OF_LIST,t1);}}

/* k6535 in k6524 in build in a6450 in k6433 in k6423 in a6420 in a6410 in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6537,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[415],((C_word*)t0)[2],t1));}

/* k6453 in a6450 in k6433 in k6423 in a6420 in a6410 in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6455,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6468,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   map */
t3=*((C_word*)lf[2]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[455]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k6466 in k6453 in a6450 in k6433 in k6423 in a6420 in a6410 in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6468,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[415],t1,((C_word*)t0)[2]));}

/* a6440 in k6433 in k6423 in a6420 in a6410 in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6449,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   take */
t3=C_retrieve(lf[454]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6447 in a6440 in k6433 in k6423 in a6420 in a6410 in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   split-at! */
t2=C_retrieve(lf[453]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6437 in k6433 in k6423 in a6420 in a6410 in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6439,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[452],((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k6407 in k6395 in k6388 in k6385 in k6382 in k6379 in k6376 in k6373 in a6340 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6409,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[415],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t2));}

/* k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6284,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[449],t3);}

/* a6283 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6284(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_6284r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6284r(t0,t1,t2,t3);}}

static void C_ccall f_6284r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(16);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6294,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* csi.scm: 52   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[449],t5,lf[450]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6324,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
/* csi.scm: 52   ##sys#check-syntax */
t6=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[449],t5,lf[451]);}}

/* k6322 in a6283 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6324,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[32],((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[448],t3));}

/* k6292 in a6283 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6294,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t3=(C_word)C_a_i_list(&a,2,lf[32],t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=(C_word)C_a_i_cons(&a,2,lf[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[448],t3,t6));}

/* k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6208,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[443],t3);}

/* a6207 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6208r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6208r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6208r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6212,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   gensym */
t6=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k6210 in a6207 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 52   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6213 in k6210 in a6207 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6215,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_list(&a,3,lf[3],t3,t5);
t7=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t8=(C_word)C_a_i_cons(&a,2,lf[3],t7);
t9=(C_word)C_a_i_list(&a,3,lf[446],lf[447],t1);
t10=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t9);
t11=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t10);
t12=(C_word)C_a_i_list(&a,3,lf[3],t1,t11);
t13=(C_word)C_a_i_list(&a,3,lf[5],t8,t12);
t14=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t13);
t15=(C_word)C_a_i_list(&a,3,lf[160],t6,t14);
t16=(C_word)C_a_i_list(&a,3,lf[3],t2,t15);
t17=(C_word)C_a_i_list(&a,2,lf[161],t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,(C_word)C_a_i_list(&a,1,t17));}

/* k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6024,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[445],t3);}

/* a6023 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6024r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6024r(t0,t1,t2,t3);}}

static void C_ccall f_6024r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6028,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   gensym */
t5=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6026 in a6023 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6029 in k6026 in a6023 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6033,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[32],lf[258]);
t4=(C_word)C_a_i_list(&a,3,lf[430],((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,3,lf[219],((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_a_i_list(&a,3,lf[440],t4,t5);
t7=(C_word)C_a_i_list(&a,2,t1,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6170,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6174,a[2]=t9,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t11=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t2,((C_word*)t0)[2]);}

/* k6172 in k6029 in k6026 in a6023 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6174,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[444],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[400],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* ##sys#append */
t5=*((C_word*)lf[416]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k6168 in k6029 in k6026 in a6023 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6170,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[442],t1);
t3=(C_word)C_a_i_list(&a,3,lf[415],((C_word*)t0)[5],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,4,lf[443],((C_word*)t0)[3],t3,((C_word*)t0)[2]));}

/* parse-clause in k6029 in k6026 in a6023 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6033(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[34],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6033,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_symbolp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_i_cadr(t2):(C_word)C_i_car(t2));
t7=(C_truep(t5)?(C_word)C_i_cddr(t2):(C_word)C_i_cdr(t2));
if(C_truep((C_word)C_i_nullp(t6))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6056,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
t9=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,1,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,t7);
t12=t8;
f_6056(t12,(C_word)C_a_i_cons(&a,2,lf[415],t11));}
else{
t9=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t10=t8;
f_6056(t10,(C_word)C_a_i_cons(&a,2,lf[415],t9));}}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6119,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6121,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t10=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,t6);}}

/* a6120 in parse-clause in k6029 in k6026 in a6023 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6121,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[32],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[441],t3,((C_word*)t0)[2]));}

/* k6117 in parse-clause in k6029 in k6026 in a6023 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6119,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[440],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6089,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[2]);
t8=t4;
f_6089(t8,(C_word)C_a_i_cons(&a,2,lf[415],t7));}
else{
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t6=t4;
f_6089(t6,(C_word)C_a_i_cons(&a,2,lf[415],t5));}}

/* k6087 in k6117 in parse-clause in k6029 in k6026 in a6023 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_6089(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6089,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k6054 in parse-clause in k6029 in k6026 in a6023 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_6056(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6056,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[400],t1));}

/* k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5834,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[439],t3);}

/* a5833 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_5834r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5834r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5834r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_i_cdr(t3);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5841,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* map */
t8=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[131]+1),t5);}

/* k5839 in a5833 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5841,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[32],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6015,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* a6014 in k5839 in a5833 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6015(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6015,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:lf[438]));}

/* k6011 in k5839 in a5833 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_6013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6013,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[429],t2);
t4=(C_word)C_a_i_list(&a,3,lf[387],((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],lf[80]);
t6=(C_word)C_a_i_list(&a,2,lf[32],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,3,lf[430],lf[80],t6);
t8=(C_word)C_a_i_list(&a,3,lf[387],t5,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5864,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5866,a[2]=t11,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_5866(t13,t9,((C_word*)t0)[2],C_fix(1));}

/* loop in k6011 in k5839 in a5833 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_5866(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[112],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5866,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_memq(lf[431],C_retrieve(lf[20]));
t6=(C_word)C_i_cddr(t4);
t7=(C_word)C_i_pairp(t6);
t8=(C_word)C_a_i_list(&a,1,lf[80]);
t9=(C_word)C_a_i_list(&a,2,lf[32],((C_word*)t0)[3]);
t10=(C_word)C_a_i_list(&a,3,lf[432],lf[80],t9);
t11=(C_word)C_a_i_list(&a,2,lf[433],t10);
t12=(C_word)C_a_i_list(&a,3,lf[434],lf[80],t3);
t13=(C_word)C_a_i_list(&a,4,lf[3],t8,t11,t12);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5892,a[2]=t13,a[3]=t5,a[4]=t7,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=t2,a[8]=t1,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t7)){
t15=(C_word)C_i_caddr(t4);
t16=(C_word)C_a_i_list(&a,3,t15,lf[80],lf[436]);
t17=(C_word)C_a_i_list(&a,2,lf[32],((C_word*)t0)[3]);
t18=(C_word)C_a_i_list(&a,3,lf[432],lf[80],t17);
t19=(C_word)C_a_i_list(&a,2,lf[433],t18);
t20=(C_word)C_a_i_list(&a,4,lf[437],lf[80],t3,lf[436]);
t21=(C_word)C_a_i_list(&a,4,lf[387],t16,t19,t20);
t22=t14;
f_5892(t22,(C_word)C_a_i_list(&a,1,t21));}
else{
t15=t14;
f_5892(t15,C_SCHEME_END_OF_LIST);}}}

/* k5890 in loop in k6011 in k5839 in a5833 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_5892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5892,NULL,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5920,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[9]);
t6=t3;
f_5920(t6,(C_word)C_a_i_list(&a,3,lf[435],((C_word*)t0)[2],t5));}
else{
t5=t3;
f_5920(t5,((C_word*)t0)[2]);}}

/* k5918 in k5890 in loop in k6011 in k5839 in a5833 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_5920(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5920,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[387],((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5904,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5912,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   add1 */
t6=*((C_word*)lf[153]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k5910 in k5918 in k5890 in loop in k6011 in k5839 in a5833 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5866(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5902 in k5918 in k5890 in loop in k6011 in k5839 in a5833 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5904,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[416]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5862 in k6011 in k5839 in a5833 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5864,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[405],t3));}

/* k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5825,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro-2 */
t4=C_retrieve(lf[419]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[427],t3);}

/* a5824 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5825,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5829,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[427],t2,lf[428]);}

/* k5827 in a5824 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5829,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[426],((C_word*)t0)[2]));}

/* k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5806,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro-2 */
t4=C_retrieve(lf[419]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[424],t3);}

/* a5805 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5806,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5810,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[424],t2,lf[425]);}

/* k5808 in a5805 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5817,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5819,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5818 in k5808 in a5805 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5819,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[32],t2));}

/* k5815 in k5808 in a5805 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5817,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[315],t1));}

/* k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5787,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro-2 */
t4=C_retrieve(lf[419]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[422],t3);}

/* a5786 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5787,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5791,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t4=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[422],t2,lf[423]);}

/* k5789 in a5786 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5798,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5800,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5799 in k5789 in a5786 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5800,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[32],t2));}

/* k5796 in k5789 in a5786 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5798,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[315],t1));}

/* k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1339,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5659,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro-2 */
t4=C_retrieve(lf[419]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[421],t3);}

/* a5658 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5659,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5665,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5665(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a5658 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_5665(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5665,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5675,a[2]=t4,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   reverse */
t7=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[417]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5746,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 52   gensym */
t9=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}
else{
t8=(C_word)C_eqp(t6,lf[418]);
if(C_truep(t8)){
/* csi.scm: 52   loop */
t15=t1;
t16=C_SCHEME_END_OF_LIST;
t17=t3;
t18=t4;
t19=C_SCHEME_TRUE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}
else{
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_car(t2);
t11=(C_word)C_a_i_cons(&a,2,t10,t4);
/* csi.scm: 52   loop */
t15=t1;
t16=t9;
t17=t3;
t18=t11;
t19=C_SCHEME_FALSE;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}}}}

/* k5744 in loop in a5658 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5746,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* csi.scm: 52   loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5665(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k5673 in loop in a5658 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5678,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   reverse */
t3=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5676 in k5673 in loop in a5658 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5678,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 52   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_list(&a,2,lf[405],t2);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t5));}}

/* k5682 in k5676 in k5673 in loop in a5658 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5691,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t3=*((C_word*)lf[416]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k5689 in k5682 in k5676 in k5673 in loop in a5658 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5691,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5707,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[416]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k5705 in k5689 in k5682 in k5676 in k5673 in loop in a5658 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5707,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[414],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t3));}

/* k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1342,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5516,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro-2 */
t4=C_retrieve(lf[419]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[420],t3);}

/* a5515 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5516,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5522,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5522(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in a5515 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_5522(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5522,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5532,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   reverse */
t8=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[417]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5607,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 52   gensym */
t10=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t10))(2,t10,t9);}
else{
t9=(C_word)C_eqp(t7,lf[418]);
if(C_truep(t9)){
/* csi.scm: 52   loop */
t14=t1;
t15=C_SCHEME_END_OF_LIST;
t16=t3;
t17=t4;
t18=t5;
t19=C_SCHEME_TRUE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
t5=t18;
t6=t19;
goto loop;}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5634,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 52   gensym */
t11=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t11))(2,t11,t10);}}}}

/* k5632 in loop in a5515 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5634,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* csi.scm: 52   loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5522(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k5605 in loop in a5515 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5607,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* csi.scm: 52   loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5522(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k5530 in loop in a5515 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5535,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   reverse */
t3=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5533 in k5530 in loop in a5515 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5535,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   gensym */
t3=C_retrieve(lf[7]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[2],t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[415],((C_word*)t0)[3],t5));}}

/* k5539 in k5533 in k5530 in loop in a5515 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5552,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[416]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k5550 in k5539 in k5533 in k5530 in loop in a5515 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5552,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5568,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[416]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k5566 in k5550 in k5539 in k5533 in k5530 in loop in a5515 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5568,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[414],t2);
t4=(C_word)C_a_i_list(&a,3,lf[3],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[415],((C_word*)t0)[2],t4));}

/* k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1345,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5457,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[413],t3);}

/* a5456 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc_2(c,6,t0);
if(!C_demand(c*C_SIZEOF_PAIR+51)){
C_save_and_reclaim((void*)tr6r,(void*)f_5457r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_5457r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_5457r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(51);
t7=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_caddr(t2);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_a_i_list(&a,3,t8,t9,t10);
t12=(C_word)C_a_i_list(&a,4,lf[410],t3,t4,t5);
t13=(C_word)C_a_i_cons(&a,2,t12,t6);
t14=(C_word)C_a_i_cons(&a,2,t11,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[411],t14));}
else{
t8=(C_word)C_a_i_list(&a,4,lf[412],t3,t4,t5);
t9=(C_word)C_a_i_cons(&a,2,t8,t6);
t10=(C_word)C_a_i_cons(&a,2,t2,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_cons(&a,2,lf[411],t10));}}

/* k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1348,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5286,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[407],t3);}

/* a5285 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5286r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5286r(t0,t1,t2,t3);}}

static void C_ccall f_5286r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5292,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5292(t7,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t3,C_SCHEME_FALSE);}

/* loop in a5285 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_5292(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5292,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t4))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5302,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=(C_word)C_a_i_cons(&a,2,lf[402],t5);
t8=t6;
f_5302(t8,(C_word)C_a_i_list(&a,2,lf[399],t7));}
else{
t7=t6;
f_5302(t7,lf[403]);}}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5366,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t6;
f_5366(t8,(C_word)C_i_pairp(t7));}
else{
t7=t6;
f_5366(t7,C_SCHEME_FALSE);}}}

/* k5364 in loop in a5285 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_5366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5366,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 52   caar */
t3=*((C_word*)lf[261]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
/* csi.scm: 52   syntax-error */
t2=C_retrieve(lf[389]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[407],lf[409],((C_word*)t0)[7]);}}

/* k5367 in k5364 in loop in a5285 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5369,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(lf[404],t1);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5393,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 52   cdar */
t5=*((C_word*)lf[260]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(lf[406],t1);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5414,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 52   cdar */
t6=*((C_word*)lf[260]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[7]);}
else{
t5=(C_word)C_eqp(lf[402],t1);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5427,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[2];
t8=(C_truep(t7)?t7:C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5435,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   cdar */
t10=*((C_word*)lf[260]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,((C_word*)t0)[7]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 52   caar */
t7=*((C_word*)lf[261]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[7]);}}}}

/* k5440 in k5367 in k5364 in loop in a5285 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   syntax-error */
t2=C_retrieve(lf[389]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[407],lf[408],t1);}

/* k5433 in k5367 in k5364 in loop in a5285 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   append */
t2=*((C_word*)lf[265]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5425 in k5367 in k5364 in loop in a5285 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 52   loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5292(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5412 in k5367 in k5364 in loop in a5285 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5414,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[405],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* csi.scm: 52   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5292(t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5391 in k5367 in k5364 in loop in a5285 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5393,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[405],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
/* csi.scm: 52   loop */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5292(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5300 in loop in a5285 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_5302(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[63],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5302,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,lf[395],t2);
t4=(C_word)C_a_i_list(&a,2,lf[396],lf[397]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,lf[398],((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,2,lf[399],t6);
t8=(C_word)C_a_i_list(&a,2,lf[32],((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,2,lf[340],t8);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t0)[3]);
t11=(C_word)C_a_i_cons(&a,2,t1,t10);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[400],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,4,lf[401],t3,t5,t13));}

/* k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1351,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5235,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[394],t3);}

/* a5234 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5235(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+39)){
C_save_and_reclaim((void*)tr3r,(void*)f_5235r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5235r(t0,t1,t2,t3);}}

static void C_ccall f_5235r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(39);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,t3);
t7=(C_word)C_a_i_cons(&a,2,lf[3],t6);
t8=(C_word)C_a_i_list(&a,2,t4,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_i_car(t2);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_list(&a,3,lf[393],t9,t10));}
else{
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[393],t5,t2));}}

/* k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1354,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5175,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   ##sys#register-macro */
t4=C_retrieve(lf[392]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[390],t3);}

/* a5174 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5175(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_5175r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5175r(t0,t1,t2,t3);}}

static void C_ccall f_5175r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[385]:t3);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_car(t2):t2);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5185,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t5);
t11=t8;
f_5185(t11,(C_word)C_a_i_cons(&a,2,lf[3],t10));}
else{
t9=t8;
f_5185(t9,(C_word)C_i_car(t5));}}

/* k5183 in a5174 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_5185(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5185,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5188,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5204,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 52   eval */
t4=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
/* csi.scm: 52   syntax-error */
t3=C_retrieve(lf[389]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[390],lf[391],((C_word*)t0)[2]);}}

/* k5202 in k5183 in a5174 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5188(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k5186 in k5183 in a5174 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5188,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_retrieve(lf[386]))?(C_word)C_a_i_list(&a,3,lf[387],((C_word*)t0)[3],((C_word*)t0)[2]):lf[388]));}

/* k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1357,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 52   register-feature! */
t3=C_retrieve(lf[345]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,lf[379],lf[380],lf[381],lf[382],lf[383],lf[384]);}

/* k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1357,2,t0,t1);}
t2=C_mutate(&lf[11],lf[12]);
t3=C_mutate(&lf[13],lf[14]);
t4=C_retrieve(lf[15]);
t5=C_mutate(&lf[16],lf[17]);
t6=C_set_block_item(lf[18],0,C_fix(2048));
t7=(C_word)C_a_i_cons(&a,2,lf[19],C_retrieve(lf[20]));
t8=C_mutate((C_word*)lf[20]+1,t7);
t9=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1370,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1382,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[29]+1);
t12=*((C_word*)lf[30]+1);
t13=C_retrieve(lf[31]);
t14=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1392,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[35]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1421,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[36],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1431,tmp=(C_word)a,a+=2,tmp));
t17=*((C_word*)lf[37]+1);
t18=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1443,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t19=C_set_block_item(lf[40],0,C_SCHEME_FALSE);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1474,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 152  make-string */
t21=*((C_word*)lf[183]+1);
((C_proc3)C_retrieve_proc(t21))(3,t21,t20,C_fix(256));}

/* k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1493,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1541,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t4=C_SCHEME_UNDEFINED;
t5=(C_word)C_a_i_vector(&a,32,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4);
t6=C_mutate((C_word*)lf[52]+1,t5);
t7=C_set_block_item(lf[33],0,C_fix(1));
t8=C_retrieve(lf[53]);
t9=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1647,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1686,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1711,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=C_retrieve(lf[194]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5169,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 204  repl-prompt */
t14=C_retrieve(lf[378]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t11,t13);}

/* a5168 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5169,2,t0,t1);}
/* csi.scm: 207  sprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[377],C_retrieve(lf[33]));}

/* k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1711,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1713,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[60],0,C_SCHEME_FALSE);
t4=C_retrieve(lf[61]);
t5=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1726,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1740,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 219  make-hash-table */
t7=C_retrieve(lf[376]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,*((C_word*)lf[115]+1));}

/* k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1740,2,t0,t1);}
t2=C_mutate(&lf[62],t1);
t3=C_retrieve(lf[63]);
t4=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1742,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_retrieve(lf[65]);
t6=C_retrieve(lf[66]);
t7=*((C_word*)lf[30]+1);
t8=C_retrieve(lf[67]);
t9=*((C_word*)lf[68]+1);
t10=C_retrieve(lf[69]);
t11=C_retrieve(lf[70]);
t12=*((C_word*)lf[71]+1);
t13=*((C_word*)lf[22]+1);
t14=*((C_word*)lf[72]+1);
t15=C_retrieve(lf[47]);
t16=C_retrieve(lf[73]);
t17=C_retrieve(lf[74]);
t18=*((C_word*)lf[75]+1);
t19=*((C_word*)lf[76]+1);
t20=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1783,a[2]=t10,a[3]=t8,a[4]=t13,a[5]=t16,a[6]=t19,a[7]=t6,a[8]=t11,a[9]=t15,a[10]=t5,a[11]=t7,a[12]=t17,tmp=(C_word)a,a+=13,tmp));
t21=C_mutate((C_word*)lf[114]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2321,tmp=(C_word)a,a+=2,tmp));
t22=C_set_block_item(lf[78],0,C_fix(0));
t23=lf[103]=C_SCHEME_END_OF_LIST;;
t24=lf[106]=C_SCHEME_END_OF_LIST;;
t25=C_mutate((C_word*)lf[148]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2362,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2390,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2413,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[125]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2704,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[155]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2728,tmp=(C_word)a,a+=2,tmp));
t30=C_retrieve(lf[73]);
t31=C_retrieve(lf[163]);
t32=C_retrieve(lf[164]);
t33=C_retrieve(lf[165]);
t34=*((C_word*)lf[166]+1);
t35=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2831,a[2]=t34,a[3]=t33,a[4]=t32,a[5]=t31,a[6]=t30,tmp=(C_word)a,a+=7,tmp));
t36=C_mutate((C_word*)lf[191]+1,lf[192]);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 582  make-hash-table */
t38=C_retrieve(lf[376]);
((C_proc3)C_retrieve_proc(t38))(3,t38,t37,*((C_word*)lf[115]+1));}

/* k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3025,2,t0,t1);}
t2=C_mutate(&lf[193],t1);
t3=C_retrieve(lf[194]);
t4=C_retrieve(lf[73]);
t5=C_retrieve(lf[195]);
t6=*((C_word*)lf[71]+1);
t7=*((C_word*)lf[196]+1);
t8=*((C_word*)lf[197]+1);
t9=C_retrieve(lf[146]);
t10=C_retrieve(lf[69]);
t11=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3027,a[2]=t9,a[3]=t10,a[4]=t3,a[5]=t7,a[6]=t6,a[7]=t8,a[8]=t5,tmp=(C_word)a,a+=9,tmp));
t12=C_retrieve(lf[63]);
t13=C_mutate((C_word*)lf[278]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3785,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3791,tmp=(C_word)a,a+=2,tmp));
t15=*((C_word*)lf[22]+1);
t16=*((C_word*)lf[42]+1);
t17=*((C_word*)lf[183]+1);
t18=*((C_word*)lf[284]+1);
t19=C_mutate((C_word*)lf[247]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3952,a[2]=t15,a[3]=t18,a[4]=t17,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t20=C_mutate((C_word*)lf[287]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4161,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[289],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4220,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate(&lf[290],lf[291]);
t23=C_mutate(&lf[292],lf[293]);
t24=C_mutate(&lf[294],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4277,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[301]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4420,tmp=(C_word)a,a+=2,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5161,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 963  run */
t27=C_retrieve(lf[301]);
((C_proc2)C_retrieve_proc(t27))(2,t27,t26);}

/* k5159 in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5164,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5167,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[375]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5165 in k5159 in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5162 in k5159 in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4424,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5155,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 835  getenv */
t4=C_retrieve(lf[50]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[374]);}

/* k5153 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[373]);
/* csi.scm: 835  parse-option-string */
t3=C_retrieve(lf[155]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4427,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5151,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 836  command-line-arguments */
t4=C_retrieve(lf[324]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k5149 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 836  canonicalize-args */
f_4277(((C_word*)t0)[2],t1);}

/* k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4427,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 837  member* */
f_4220(t4,lf[372],((C_word*)t3)[1]);}

/* k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4433,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 838  member* */
f_4220(t2,lf[371],((C_word*)((C_word*)t0)[4])[1]);}

/* k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4436,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5044,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_i_pairp(t4);
t6=(C_word)C_i_not(t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5094,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t6)){
t8=t7;
f_5094(t8,t6);}
else{
t8=(C_word)C_i_cadr(t1);
t9=(C_word)C_i_string_length(t8);
t10=(C_word)C_i_zerop(t9);
if(C_truep(t10)){
t11=t7;
f_5094(t11,t10);}
else{
t11=(C_word)C_i_cadr(t1);
t12=(C_word)C_i_string_ref(t11,C_fix(0));
t13=t7;
f_5094(t13,(C_word)C_eqp(C_make_character(45),t12));}}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5134,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5147,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 852  canonicalize-args */
f_4277(t4,((C_word*)t0)[2]);}}

/* k5145 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 852  append */
t2=*((C_word*)lf[265]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5132 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_i_member(lf[370],((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
f_4436(t4,(C_truep(t3)?(C_word)C_i_set_cdr(t3,C_SCHEME_END_OF_LIST):C_SCHEME_FALSE));}

/* k5092 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_5094(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 843  ##sys#error */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[369]);}
else{
t2=((C_word*)t0)[2];
f_5044(2,t2,C_SCHEME_UNDEFINED);}}

/* k5042 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 844  program-name */
t4=C_retrieve(lf[368]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k5045 in k5042 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* csi.scm: 845  command-line-arguments */
t4=C_retrieve(lf[324]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k5048 in k5045 in k5042 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 846  register-feature! */
t3=C_retrieve(lf[345]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[367]);}

/* k5051 in k5048 in k5045 in k5042 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5053,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[366]+1))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 849  lookup-script-file */
t6=C_retrieve(lf[44]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=((C_word*)t0)[2];
f_4436(t4,C_SCHEME_UNDEFINED);}}

/* k5060 in k5051 in k5048 in k5045 in k5042 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4436(t3,(C_word)C_i_set_car(t2,t1));}
else{
t2=((C_word*)t0)[2];
f_4436(t2,C_SCHEME_FALSE);}}

/* k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4436(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4436,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 855  member* */
f_4220(t2,lf[365],((C_word*)((C_word*)t0)[4])[1]);}

/* k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_4442(t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5038,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 856  member* */
f_4220(t3,lf[364],((C_word*)((C_word*)t0)[4])[1]);}}

/* k5036 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4442(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4442(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4442,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 857  member* */
f_4220(t2,lf[363],((C_word*)((C_word*)t0)[4])[1]);}

/* k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[7])?((C_word*)t0)[7]:(C_truep(t1)?t1:((C_word*)t0)[6]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4451,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5025,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5029,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 859  getenv */
t6=C_retrieve(lf[50]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[362]);}

/* k5027 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[360]);
/* csi.scm: 859  string-split */
t3=C_retrieve(lf[47]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[361]);}

/* k5023 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[38]),t1);}

/* k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4453,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4533,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4603,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=C_set_block_item(lf[359],0,C_fix(0));
t6=t4;
f_4603(t6,t5);}
else{
t5=t4;
f_4603(t5,C_SCHEME_UNDEFINED);}}

/* k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4603(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4603,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5014,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 882  member* */
f_4220(t3,lf[358],((C_word*)((C_word*)t0)[6])[1]);}

/* k5012 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5014,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5017,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 883  print-usage */
t3=C_retrieve(lf[21]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_4606(2,t2,C_SCHEME_UNDEFINED);}}

/* k5015 in k5012 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 884  exit */
t2=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5005,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 885  member* */
f_4220(t3,lf[357],((C_word*)((C_word*)t0)[6])[1]);}

/* k5003 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5005,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5008,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 886  print-banner */
t3=C_retrieve(lf[25]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
f_4609(2,t2,C_SCHEME_UNDEFINED);}}

/* k5006 in k5003 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 887  exit */
t2=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_member(lf[356],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4995,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5002,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 889  chicken-version */
t5=C_retrieve(lf[28]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=t2;
f_4612(2,t3,C_SCHEME_UNDEFINED);}}

/* k5000 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 889  print */
t2=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4993 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 890  exit */
t2=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4982,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 891  member* */
f_4220(t3,lf[355],((C_word*)((C_word*)t0)[6])[1]);}

/* k4980 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4982,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4985,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4985(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 892  display */
t3=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[354]);}}
else{
t2=((C_word*)t0)[3];
f_4615(t2,C_SCHEME_UNDEFINED);}}

/* k4983 in k4980 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[353],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_4615(t3,t2);}

/* k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4615(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4615,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4618(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4976,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 895  load-verbose */
t4=C_retrieve(lf[352]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}}

/* k4974 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 896  print-banner */
t2=C_retrieve(lf[25]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4621,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4961,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 897  member* */
f_4220(t3,lf[351],((C_word*)((C_word*)t0)[6])[1]);}

/* k4959 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4961,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4964,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4964(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 898  display */
t3=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[350]);}}
else{
t2=((C_word*)t0)[3];
f_4621(2,t2,C_SCHEME_UNDEFINED);}}

/* k4962 in k4959 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4967,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 899  register-feature! */
t3=C_retrieve(lf[345]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[349]);}

/* k4965 in k4962 in k4959 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 900  case-sensitive */
t2=C_retrieve(lf[348]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4958,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 901  collect-options */
t4=((C_word*)t0)[2];
f_4453(t4,t3,lf[347]);}

/* k4956 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[345]),t1);}

/* k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4954,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 902  collect-options */
t4=((C_word*)t0)[2];
f_4453(t4,t3,lf[346]);}

/* k4952 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[345]),t1);}

/* k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4631,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4934,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4950,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 905  collect-options */
t6=((C_word*)t0)[2];
f_4453(t6,t5,lf[344]);}

/* k4948 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[38]),t1);}

/* k4936 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4942,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4946,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 906  collect-options */
t4=((C_word*)t0)[2];
f_4453(t4,t3,lf[343]);}

/* k4944 in k4936 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[38]),t1);}

/* k4940 in k4936 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 905  append */
t2=*((C_word*)lf[265]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,C_retrieve(lf[177]),((C_word*)t0)[2]);}

/* k4932 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 904  deldups */
t2=C_retrieve(lf[287]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[342]+1));}

/* k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
t2=C_mutate((C_word*)lf[177]+1,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[304],C_retrieve(lf[20]));
t4=C_mutate((C_word*)lf[20]+1,t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 911  provide */
t6=C_retrieve(lf[340]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[341]);}

/* k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[332],t4))){
/* csi.scm: 916  keyword-style */
t5=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,lf[334]);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[335],t5))){
/* csi.scm: 918  keyword-style */
t6=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,lf[336]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[337],t6))){
/* csi.scm: 920  keyword-style */
t7=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t2,lf[338]);}
else{
t7=t2;
f_4641(2,t7,C_SCHEME_UNDEFINED);}}}}
else{
/* csi.scm: 914  ##sys#error */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,lf[339]);}}
else{
t3=t2;
f_4641(2,t3,C_SCHEME_UNDEFINED);}}

/* k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4868,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 921  member* */
f_4220(t3,lf[331],((C_word*)((C_word*)t0)[2])[1]);}

/* k4866 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4868,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_4644(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4500,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 869  ##sys#string-append */
t4=C_retrieve(lf[329]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[330],lf[16]);}}

/* k4498 in k4866 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4506,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 870  file-exists? */
t3=C_retrieve(lf[41]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4504 in k4498 in k4866 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4506,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 871  load */
t2=C_retrieve(lf[93]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4512,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4528,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 872  getenv */
t4=C_retrieve(lf[50]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[328]);}}

/* k4526 in k4504 in k4498 in k4866 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[327]);
/* csi.scm: 872  chop-separator */
t3=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k4510 in k4504 in k4498 in k4866 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4515,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 873  string-append */
t3=*((C_word*)lf[42]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,t1,lf[326],lf[16]);}

/* k4513 in k4510 in k4504 in k4498 in k4866 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4521,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 874  file-exists? */
t3=C_retrieve(lf[41]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4519 in k4513 in k4510 in k4504 in k4498 in k4866 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 875  load */
t2=C_retrieve(lf[93]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4644(2,t2,C_SCHEME_UNDEFINED);}}

/* k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4644,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4649,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4649(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4649(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4649,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t3)[1]))){
if(C_truep(((C_word*)t0)[5])){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4662,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 925  repl */
t5=C_retrieve(lf[305]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}
else{
t4=(C_word)C_i_car(((C_word*)t3)[1]);
t5=(C_word)C_i_string_length(t4);
t6=(C_word)C_i_member(t4,lf[306]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4677,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_4677(2,t8,t6);}
else{
if(C_truep((C_truep((C_word)C_i_equalp(t4,lf[307]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[308]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[309]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[310]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[311]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[312]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t8=(C_word)C_i_cdr(((C_word*)t3)[1]);
t9=C_set_block_item(t3,0,t8);
t10=t7;
f_4677(2,t10,t9);}
else{
t8=(C_word)C_i_string_equal_p(lf[313],t4);
t9=(C_truep(t8)?t8:(C_word)C_i_string_equal_p(lf[314],t4));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4706,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4722,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 938  string->symbol */
t13=*((C_word*)lf[112]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t11,t12);}
else{
t10=(C_word)C_i_string_equal_p(lf[316],t4);
t11=(C_truep(t10)?t10:(C_word)C_i_string_equal_p(lf[317],t4));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4738,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 941  evalstring */
f_4533(t12,t13,C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_i_string_equal_p(lf[318],t4);
t13=(C_truep(t12)?t12:(C_word)C_i_string_equal_p(lf[319],t4));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4758,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_i_cadr(((C_word*)t3)[1]);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4768,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 944  evalstring */
f_4533(t14,t15,(C_word)C_a_i_list(&a,1,t16));}
else{
t14=(C_word)C_i_string_equal_p(lf[321],t4);
t15=(C_truep(t14)?t14:(C_word)C_i_string_equal_p(lf[322],t4));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4784,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t17=(C_word)C_i_cadr(((C_word*)t3)[1]);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4794,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 949  evalstring */
f_4533(t16,t17,(C_word)C_a_i_list(&a,1,t18));}
else{
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4801,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 954  load */
t17=C_retrieve(lf[93]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,t4);}}}}}}}}

/* k4799 in do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4807,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=t2;
f_4807(t4,(C_word)C_i_string_equal_p(lf[325],t3));}
else{
t3=t2;
f_4807(t3,C_SCHEME_FALSE);}}

/* k4805 in k4799 in do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4807,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4812,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4822,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 956  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_4677(2,t2,C_SCHEME_UNDEFINED);}}

/* a4821 in k4805 in k4799 in do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4822(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4822r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4822r(t0,t1,t2);}}

static void C_ccall f_4822r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4833,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
t5=t3;
f_4833(t5,(C_word)C_fixnump(t4));}
else{
t4=t3;
f_4833(t4,C_SCHEME_FALSE);}}

/* k4831 in a4821 in k4805 in k4799 in do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4833(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)):C_fix(0));
/* csi.scm: 958  exit */
t3=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* a4811 in k4805 in k4799 in do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4820,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 956  command-line-arguments */
t3=C_retrieve(lf[324]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4818 in a4811 in k4805 in k4799 in do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main */
t2=C_retrieve(lf[323]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* a4793 in do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4794(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4794r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4794r(t0,t1,t2);}}

static void C_ccall f_4794r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[320]+1),C_retrieve(lf[74]),t2);}

/* k4782 in do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4677(2,t4,t3);}

/* a4767 in do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4768(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4768r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4768r(t0,t1,t2);}}

static void C_ccall f_4768r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[320]+1),*((C_word*)lf[26]+1),t2);}

/* k4756 in do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4677(2,t4,t3);}

/* k4736 in do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4677(2,t4,t3);}

/* k4720 in do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4722,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[32],t1);
t3=(C_word)C_a_i_list(&a,2,lf[315],t2);
/* csi.scm: 938  eval */
t4=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* k4704 in do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_4677(2,t4,t3);}

/* k4675 in do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4649(t3,((C_word*)t0)[2],t2);}

/* k4660 in do961 in k4642 in k4639 in k4636 in k4629 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 in k4604 in k4601 in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 926  ##sys#write-char-0 */
t2=C_retrieve(lf[152]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[150]+1));}

/* evalstring in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4533(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4533,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4537,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4537(2,t5,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4580,tmp=(C_word)a,a+=2,tmp));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4537(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* f_4580 in evalstring in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4580(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4580,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[15]));}

/* k4535 in evalstring in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4540,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 877  open-input-string */
t3=C_retrieve(lf[162]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4538 in k4535 in evalstring in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 878  read */
t3=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k4545 in k4538 in k4535 in evalstring in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4547,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4549(t5,((C_word*)t0)[2],t1);}

/* do947 in k4545 in k4538 in k4535 in evalstring in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4549(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4549,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4570,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4572,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 880  ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,*((C_word*)lf[303]+1));}}

/* a4571 in do947 in k4545 in k4538 in k4535 in evalstring in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4572,2,t0,t1);}
/* csi.scm: 880  eval */
t2=C_retrieve(lf[65]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k4568 in do947 in k4545 in k4538 in k4535 in evalstring in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 880  rec */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4557 in do947 in k4545 in k4538 in k4535 in evalstring in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 878  read */
t3=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4564 in k4557 in do947 in k4545 in k4538 in k4535 in evalstring in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4549(t2,((C_word*)t0)[2],t1);}

/* collect-options in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4453(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4453,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4459,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4459(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in collect-options in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4459(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4459,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_member(((C_word*)t0)[3],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
/* csi.scm: 865  ##sys#error */
t5=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[302],((C_word*)t0)[3]);}
else{
t5=(C_word)C_i_cadr(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4486,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cddr(t3);
/* csi.scm: 866  loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k4484 in loop in collect-options in k4449 in k4443 in k4440 in k4437 in k4434 in k4431 in k4428 in k4425 in k4422 in ##csi#run in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4486,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* canonicalize-args in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4277(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4277,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4283,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4283(t6,t1,t2);}

/* loop in canonicalize-args in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4283(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4283,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[295]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[296]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[297]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[298]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4305,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(2)))){
t6=(C_word)C_eqp(C_make_character(45),(C_word)C_subchar(t3,C_fix(0)));
if(C_truep(t6)){
t7=(C_word)C_i_member(t3,lf[293]);
t8=t4;
f_4305(t8,(C_word)C_i_not(t7));}
else{
t7=t4;
f_4305(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_4305(t6,C_SCHEME_FALSE);}}}}

/* k4303 in loop in canonicalize-args in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4305(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4305,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(C_make_character(58),(C_word)C_subchar(((C_word*)t0)[5],C_fix(1)));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 821  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4283(t4,((C_word*)t0)[2],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4321,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4355,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 822  substring */
t5=*((C_word*)lf[37]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4362,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 826  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4283(t4,t2,t3);}}

/* k4360 in k4303 in loop in canonicalize-args in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4362,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4353 in k4303 in loop in canonicalize-args in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[300]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4319 in k4303 in loop in canonicalize-args in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4321,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4394,tmp=(C_word)a,a+=2,tmp);
t4=f_4394(t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4334,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4344,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}
else{
/* csi.scm: 825  ##sys#error */
t5=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[299],((C_word*)t0)[2]);}}

/* a4343 in k4319 in k4303 in loop in canonicalize-args in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4344,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k4332 in k4319 in k4303 in loop in canonicalize-args in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4338,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 824  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4283(t4,t2,t3);}

/* k4336 in k4332 in k4319 in k4303 in loop in canonicalize-args in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 824  append */
t2=*((C_word*)lf[265]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4319 in k4303 in loop in canonicalize-args in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static C_word C_fcall f_4394(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_i_car(t1);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(107)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(118)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(104)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(68)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(101)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(105)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(82)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(98)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(110)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(113)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(119)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(45)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(73)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(112)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(80)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))))){
t4=(C_word)C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* member* in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4220(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4220,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4226,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4226(t7,t1,t3);}

/* loop in member* in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4226(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4226,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4238,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4238(t6,t1,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* find in loop in member* in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4238(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4238,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 796  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4226(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_equalp(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_i_cdr(t2);
/* csi.scm: 798  find */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}}

/* ##csi#deldups in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4161r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4161r(t0,t1,t2,t3);}}

static void C_ccall f_4161r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4165,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4165(2,t5,*((C_word*)lf[288]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4165(2,t6,(C_word)C_i_car(t3));}
else{
/* csi.scm: 784  ##sys#error */
t6=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4163 in ##csi#deldups in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4165,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4170,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4170(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* recur in k4163 in ##csi#deldups in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4170(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4170,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4186,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4199,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 789  del */
t7=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t3,t4,((C_word*)t0)[2]);}}

/* k4197 in recur in k4163 in ##csi#deldups in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 789  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4170(t2,((C_word*)t0)[2],t1);}

/* k4184 in recur in k4163 in ##csi#deldups in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4186,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3952,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3955,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3984,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t8,a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_3984(t10,t1,C_fix(0));}

/* do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_3984(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3984,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4159,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 757  justify */
t5=((C_word*)t0)[2];
f_3955(t5,t4,t2,C_fix(4),C_fix(10),C_make_character(32));}}

/* k4157 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 757  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm: 758  write-char */
t3=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(58),((C_word*)t0)[8]);}

/* k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4069,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_4069(t6,t2,C_fix(0),((C_word*)t0)[11]);}

/* do823 in k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4069(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4069,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]));
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 763  fxmod */
t7=*((C_word*)lf[286]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[9],C_fix(16));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4130,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 768  write-char */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_make_character(32),((C_word*)t0)[7]);}}

/* k4128 in do823 in k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4133,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4148,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4152,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 769  ref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[9]);}

/* k4150 in k4128 in do823 in k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 769  justify */
t2=((C_word*)t0)[3];
f_3955(t2,((C_word*)t0)[2],t1,C_fix(2),C_fix(16),C_make_character(48));}

/* k4146 in k4128 in do823 in k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 769  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4131 in k4128 in do823 in k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4069(t4,((C_word*)t0)[2],t2,t3);}

/* k4086 in do823 in k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4088,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_fixnum_difference(C_fix(16),t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4106(t7,((C_word*)t0)[4],t3);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* do830 in k4086 in do823 in k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4106(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4106,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4116,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 767  display */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[285],((C_word*)t0)[2]);}}

/* k4114 in do830 in k4086 in do823 in k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4106(t3,((C_word*)t0)[2],t2);}

/* k3998 in k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 770  write-char */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(32),((C_word*)t0)[6]);}

/* k4001 in k3998 in k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4006,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4018(t6,t2,C_fix(0),((C_word*)t0)[9]);}

/* do838 in k4001 in k3998 in k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_4018(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4018,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[7]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4031,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 774  ref */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t3);}}

/* k4029 in do838 in k4001 in k3998 in k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4034,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greater_or_equal_p(t1,C_fix(32));
t4=(C_truep(t3)?(C_word)C_fixnum_lessp(t1,C_fix(128)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_make_character((C_word)C_unfix(t1));
/* csi.scm: 776  write-char */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,t5,((C_word*)t0)[2]);}
else{
/* csi.scm: 777  write-char */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(46),((C_word*)t0)[2]);}}

/* k4032 in k4029 in do838 in k4001 in k3998 in k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4018(t4,((C_word*)t0)[2],t2,t3);}

/* k4004 in k4001 in k3998 in k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 778  ##sys#write-char-0 */
t3=C_retrieve(lf[152]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4007 in k4004 in k4001 in k3998 in k3995 in k3992 in do813 in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(16));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3984(t3,((C_word*)t0)[2],t2);}

/* justify in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_3955(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3955,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3959,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 749  number->string */
C_number_to_string(4,0,t6,t2,t4);}

/* k3957 in justify in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3959,2,t0,t1);}
t2=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[6]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3975,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[6],t2);
/* csi.scm: 752  make-string */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k3973 in k3957 in justify in ##csi#hexdump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 752  string-append */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##csi#dump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3791(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3791r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3791r(t0,t1,t2,t3);}}

static void C_ccall f_3791r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3793,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3899,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3904,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-len788800 */
t7=t6;
f_3904(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-out789798 */
t9=t5;
f_3899(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body786791 */
t11=t4;
f_3793(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-len788 in ##csi#dump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_3904(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3904,NULL,2,t0,t1);}
/* def-out789798 */
t2=((C_word*)t0)[2];
f_3899(t2,t1,C_SCHEME_FALSE);}

/* def-out789 in ##csi#dump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_3899(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3899,NULL,3,t0,t1,t2);}
/* body786791 */
t3=((C_word*)t0)[2];
f_3793(t3,t1,t2,*((C_word*)lf[150]+1));}

/* body786 in ##csi#dump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_3793(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3793,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3796,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_immp(((C_word*)t0)[2]))){
/* csi.scm: 731  ##sys#error */
t5=*((C_word*)lf[55]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[280],lf[281],((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3818,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 732  ##sys#bytevector? */
t6=*((C_word*)lf[271]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}}

/* k3816 in body786 in ##csi#dump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3818,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3825,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 732  bestlen */
t4=((C_word*)t0)[2];
f_3796(t4,t2,t3);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3842,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 733  bestlen */
t4=((C_word*)t0)[2];
f_3796(t4,t2,t3);}
else{
t2=(C_word)C_immp(((C_word*)t0)[4]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_pointerp(((C_word*)t0)[4]));
if(C_truep(t3)){
/* csi.scm: 735  hexdump */
t4=C_retrieve(lf[247]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[5],((C_word*)t0)[4],C_fix(32),*((C_word*)lf[282]+1),((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t6=t4;
f_3861(t6,(C_word)C_i_assq(t5,C_retrieve(lf[191])));}
else{
t5=t4;
f_3861(t5,C_SCHEME_FALSE);}}}}}

/* k3859 in k3816 in body786 in ##csi#dump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_3861(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3861,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3871,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 738  bestlen */
t5=((C_word*)t0)[2];
f_3796(t5,t3,t4);}
else{
/* csi.scm: 739  ##sys#error */
t2=*((C_word*)lf[55]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[280],lf[283],((C_word*)t0)[5]);}}

/* k3869 in k3859 in k3816 in body786 in ##csi#dump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 738  hexdump */
t2=C_retrieve(lf[247]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[248]+1),((C_word*)t0)[2]);}

/* k3840 in k3816 in body786 in ##csi#dump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 733  hexdump */
t2=C_retrieve(lf[247]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[248]+1),((C_word*)t0)[2]);}

/* k3823 in k3816 in body786 in ##csi#dump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 732  hexdump */
t2=C_retrieve(lf[247]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[248]+1),((C_word*)t0)[2]);}

/* bestlen in body786 in ##csi#dump in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_3796(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3796,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 730  min */
t3=*((C_word*)lf[279]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-describer! in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3785,4,t0,t1,t2,t3);}
/* csi.scm: 720  hash-table-set! */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve2(lf[193],"describer-table"),t2,t3);}

/* ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_3027r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3027r(t0,t1,t2,t3);}}

static void C_ccall f_3027r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=t2,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3031(2,t5,*((C_word*)lf[150]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3031(2,t6,(C_word)C_i_car(t3));}
else{
/* csi.scm: 594  ##sys#error */
t6=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3764,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 618  ##sys#block-address */
t5=C_retrieve(lf[277]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[9]);}
else{
t4=t3;
f_3159(2,t4,C_SCHEME_UNDEFINED);}}

/* k3762 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 618  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[276],t1);}

/* k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3162,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_charp(((C_word*)t0)[11]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[11]));
/* csi.scm: 621  fprintf */
t4=((C_word*)t0)[10];
((C_proc8)C_retrieve_proc(t4))(8,t4,t2,((C_word*)t0)[9],lf[205],((C_word*)t0)[11],t3,t3,t3);}
else{
switch(((C_word*)t0)[11]){
case C_SCHEME_TRUE:
/* csi.scm: 622  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[206]);
case C_SCHEME_FALSE:
/* csi.scm: 623  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[207]);
default:
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[11]))){
/* csi.scm: 624  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[208]);}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[11]))){
/* csi.scm: 625  fprintf */
t3=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[209]);}
else{
t3=C_retrieve(lf[15]);
t4=(C_word)C_eqp(t3,((C_word*)t0)[11]);
if(C_truep(t4)){
/* csi.scm: 626  fprintf */
t5=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[9],lf[210]);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[11]))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3228,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t2,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 628  fprintf */
t6=((C_word*)t0)[10];
((C_proc8)C_retrieve_proc(t6))(8,t6,t5,((C_word*)t0)[9],lf[212],((C_word*)t0)[11],((C_word*)t0)[11],((C_word*)t0)[11],((C_word*)t0)[11]);}
else{
t5=(C_word)C_slot(lf[213],C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[11],t5);
if(C_truep(t6)){
/* csi.scm: 633  fprintf */
t7=((C_word*)t0)[10];
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[9],lf[214]);}
else{
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[9],a[11]=t2,a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
/* csi.scm: 634  ##sys#number? */
t8=C_retrieve(lf[275]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[11]);}}}}}}}}

/* k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3258,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 634  fprintf */
t2=((C_word*)t0)[12];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[11],((C_word*)t0)[10],lf[215],((C_word*)t0)[9]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[9]))){
/* csi.scm: 635  descseq */
t2=((C_word*)t0)[8];
f_3033(6,t2,((C_word*)t0)[11],lf[216],*((C_word*)lf[217]+1),((C_word*)t0)[7],C_fix(0));}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[9]))){
/* csi.scm: 636  descseq */
t2=((C_word*)t0)[8];
f_3033(6,t2,((C_word*)t0)[11],lf[218],*((C_word*)lf[217]+1),*((C_word*)lf[219]+1),C_fix(0));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[9]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3288,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3321,a[2]=((C_word*)t0)[10],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 638  ##sys#symbol-has-toplevel-binding? */
t4=C_retrieve(lf[224]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[9]))){
/* csi.scm: 642  descseq */
t2=((C_word*)t0)[8];
f_3033(6,t2,((C_word*)t0)[11],lf[225],((C_word*)t0)[6],((C_word*)t0)[5],C_fix(0));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
/* csi.scm: 643  fprintf */
t4=((C_word*)t0)[12];
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[11],((C_word*)t0)[10],lf[226],t2,t3);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[9]))){
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3365,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(3)))){
if(C_truep((C_word)C_i_memq(lf[230],C_retrieve(lf[20])))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[9],t4);
t6=t3;
f_3365(t6,(C_word)C_eqp(C_retrieve(lf[231]),t5));}
else{
t4=t3;
f_3365(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_3365(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3405,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 653  port? */
t3=C_retrieve(lf[274]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}}}}}}}}

/* k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3405,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_truep(t2)?lf[232]:lf[233]);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(7));
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3424,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 659  ##sys#peek-unsigned-integer */
t7=C_retrieve(lf[229]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_memq(lf[230],C_retrieve(lf[20])))){
/* csi.scm: 660  instance? */
t3=C_retrieve(lf[273]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t3=t2;
f_3433(2,t3,C_SCHEME_FALSE);}}}

/* k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3433,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 661  describe-object */
t2=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 662  ##sys#locative? */
t3=C_retrieve(lf[272]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}}

/* k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 664  ##sys#peek-unsigned-integer */
t3=C_retrieve(lf[229]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_fix(0));}
else{
if(C_truep((C_word)C_pointerp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3530,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 677  ##sys#peek-unsigned-integer */
t3=C_retrieve(lf[229]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 678  ##sys#bytevector? */
t3=*((C_word*)lf[271]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}}}

/* k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3536,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3542,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 680  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],lf[249],t2);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3555,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 683  ##sys#lambda-info->string */
t3=C_retrieve(lf[251]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[8],lf[252]))){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3567,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_eqp(t2,C_fix(1));
t5=(C_truep(t4)?lf[255]:lf[256]);
t6=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
/* csi.scm: 686  fprintf */
t7=((C_word*)t0)[5];
((C_proc7)C_retrieve_proc(t7))(7,t7,t3,((C_word*)t0)[6],lf[257],t2,t5,t6);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[8],lf[258]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3603,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* csi.scm: 693  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],lf[263],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[8],lf[268]))){
/* csi.scm: 703  provided? */
t3=C_retrieve(lf[269]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[270]);}
else{
t3=t2;
f_3670(2,t3,C_SCHEME_FALSE);}}}}}}

/* k3668 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3670,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 704  unveil */
t2=C_retrieve(lf[264]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[6]))){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 707  hash-table-ref/default */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[193],"describer-table"),t2,C_SCHEME_FALSE);}
else{
/* csi.scm: 714  fprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[5],lf[267]);}}}

/* k3683 in k3668 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3685,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3692,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],t1);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[4],C_retrieve(lf[191]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3709,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3713,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* map */
t6=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[65]),t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3724,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
/* csi.scm: 712  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],lf[266],t4);}}}

/* k3722 in k3683 in k3668 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 713  descseq */
t2=((C_word*)t0)[3];
f_3033(6,t2,((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[217]+1),*((C_word*)lf[219]+1),C_fix(1));}

/* k3711 in k3683 in k3668 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3713,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,C_fix(0));
/* csi.scm: 710  append */
t3=*((C_word*)lf[265]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k3707 in k3683 in k3668 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_3692 in k3683 in k3668 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3692,3,t0,t1,t2);}
/* g771772 */
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3601 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3608,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* for-each */
t4=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a3607 in k3601 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3608(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3608,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3612,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 696  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[262],t2);}

/* k3610 in a3607 in k3601 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3612,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3621,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3621(t6,((C_word*)t0)[2],t2);}

/* loop in k3610 in a3607 in k3601 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_3621(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3621,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3631,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3656,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 699  caar */
t5=*((C_word*)lf[261]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k3654 in loop in k3610 in a3607 in k3601 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3656,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 700  cdar */
t4=*((C_word*)lf[260]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[3];
f_3631(2,t3,C_SCHEME_UNDEFINED);}}

/* k3646 in k3654 in loop in k3610 in a3607 in k3601 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* csi.scm: 700  fprintf */
t3=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[259],t1,t2);}

/* k3629 in loop in k3610 in a3607 in k3601 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* csi.scm: 701  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3621(t3,((C_word*)t0)[2],t2);}

/* k3565 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
/* csi.scm: 688  fprintf */
t4=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[5],lf[254],t3);}

/* k3568 in k3565 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3575,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 689  hash-table-walk */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3574 in k3568 in k3565 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3575,4,t0,t1,t2,t3);}
/* csi.scm: 691  fprintf */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],lf[253],t2,t3);}

/* k3553 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 683  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[250],t1);}

/* k3540 in k3534 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 681  hexdump */
t2=C_retrieve(lf[247]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],*((C_word*)lf[248]+1),((C_word*)t0)[2]);}

/* k3528 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 677  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[246],t1);}

/* k3447 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3449,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3460,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_3460(t5,lf[236]);
case C_fix(1):
t5=t4;
f_3460(t5,lf[237]);
case C_fix(2):
t5=t4;
f_3460(t5,lf[238]);
case C_fix(3):
t5=t4;
f_3460(t5,lf[239]);
case C_fix(4):
t5=t4;
f_3460(t5,lf[240]);
case C_fix(5):
t5=t4;
f_3460(t5,lf[241]);
case C_fix(6):
t5=t4;
f_3460(t5,lf[242]);
case C_fix(7):
t5=t4;
f_3460(t5,lf[243]);
case C_fix(8):
t5=t4;
f_3460(t5,lf[244]);
default:
t5=(C_word)C_eqp(t3,C_fix(9));
t6=t4;
f_3460(t6,(C_truep(t5)?lf[245]:C_SCHEME_UNDEFINED));}}

/* k3458 in k3447 in k3440 in k3431 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_3460(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 663  fprintf */
t2=((C_word*)t0)[6];
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[235],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3422 in k3403 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 654  fprintf */
t2=((C_word*)t0)[7];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[234],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3363 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_3365(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3365,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 649  describe-object */
t2=C_retrieve(lf[227]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3375,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3379,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 651  ##sys#peek-unsigned-integer */
t4=C_retrieve(lf[229]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[5],C_fix(0));}}

/* k3377 in k3363 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 651  sprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[228],t1);}

/* k3373 in k3363 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 650  descseq */
t2=((C_word*)t0)[3];
f_3033(6,t2,((C_word*)t0)[2],t1,*((C_word*)lf[217]+1),*((C_word*)lf[219]+1),C_fix(1));}

/* k3319 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_3288(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 638  display */
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[223],((C_word*)t0)[2]);}}

/* k3286 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(C_word)C_subbyte(t4,C_fix(0));
t6=t3;
f_3301(t6,(C_word)C_eqp(C_fix(0),t5));}
else{
t4=t3;
f_3301(t4,C_SCHEME_FALSE);}}

/* k3299 in k3286 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_3301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 640  display */
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[222],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3291(2,t2,C_SCHEME_UNDEFINED);}}

/* k3289 in k3286 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3298,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 641  ##sys#symbol->string */
t3=C_retrieve(lf[221]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3296 in k3289 in k3286 in k3256 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 641  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[220],t1);}

/* k3226 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3228,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3234,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(65536)))){
/* csi.scm: 630  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[211],t2);}
else{
t4=t3;
f_3234(2,t4,C_SCHEME_UNDEFINED);}}

/* k3232 in k3226 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 631  ##sys#write-char-0 */
t2=C_retrieve(lf[152]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[150]+1));}

/* k3160 in k3157 in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[15]));}

/* descseq in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3033,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3156,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 597  plen */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k3154 in descseq in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3156,2,t0,t1);}
t2=(C_word)C_fixnum_difference(t1,((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3040,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 598  fprintf */
t4=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[6],lf[204],((C_word*)t0)[2],t2);}
else{
t4=t3;
f_3040(2,t4,C_SCHEME_UNDEFINED);}}

/* k3038 in k3154 in descseq in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3045,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3045(t5,((C_word*)t0)[2],C_fix(0));}

/* loop1 in k3038 in k3154 in descseq in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_3045(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3045,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(40)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[8],t2);
/* csi.scm: 602  fprintf */
t5=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[6],lf[198],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3068,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],t2);
/* csi.scm: 604  pref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}}

/* k3066 in loop1 in k3038 in k3154 in descseq in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3068,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[9],t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3077,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_3077(t7,((C_word*)t0)[2],C_fix(1),t3);}

/* loop2 in k3066 in loop1 in k3038 in k3154 in descseq in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_3077(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3077,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[10]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3087,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 607  fprintf */
t5=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[6],lf[203],((C_word*)t0)[9],((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3141,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 614  pref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k3139 in loop2 in k3066 in loop1 in k3038 in k3154 in descseq in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* csi.scm: 614  loop2 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3077(t5,((C_word*)t0)[3],t3,t4);}
else{
/* csi.scm: 615  loop2 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3077(t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k3085 in loop2 in k3066 in loop1 in k3038 in k3154 in descseq in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3090,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[6],C_fix(1)))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(2));
t5=(C_truep(t4)?lf[199]:lf[200]);
/* csi.scm: 609  fprintf */
t6=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,((C_word*)t0)[2],lf[201],t3,t5);}
else{
/* csi.scm: 612  newline */
t3=*((C_word*)lf[202]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}}

/* k3088 in k3085 in loop2 in k3066 in loop1 in k3038 in k3154 in descseq in k3029 in ##csi#describe in k3023 in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* csi.scm: 613  loop1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3045(t3,((C_word*)t0)[2],t2);}

/* ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2831r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2831r(t0,t1,t2);}}

static void C_ccall f_2831r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2839,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_2839(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
/* csi.scm: 522  current-output-port */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 522  with-output-to-port */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 524  gc */
t3=C_retrieve(lf[190]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 525  ##sys#symbol-table-info */
t3=C_retrieve(lf[189]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 526  memory-statistics */
t3=C_retrieve(lf[188]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2853,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 528  printf */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[187]);}

/* k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2871,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3003,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3007,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3011,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[186]),C_retrieve(lf[20]));}

/* k3009 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 536  sort */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[185]+1));}

/* k3005 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 536  chop */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k3001 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2969 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2970,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2974,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 531  display */
t4=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[184]);}

/* k2972 in a2969 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2979,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a2978 in k2972 in a2969 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2979,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2987,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
/* csi.scm: 534  make-string */
t7=*((C_word*)lf[183]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t6,C_make_character(32));}

/* k2985 in a2978 in k2972 in a2969 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 534  printf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[182],((C_word*)t0)[2],t1);}

/* k2869 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2874,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2899,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 548  machine-type */
t4=C_retrieve(lf[181]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2897 in k2869 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2899,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(3));
t3=(C_truep(t2)?lf[170]:lf[171]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2907,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 550  software-type */
t5=C_retrieve(lf[180]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2905 in k2897 in k2869 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2911,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 551  software-version */
t3=C_retrieve(lf[179]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2909 in k2905 in k2897 in k2869 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2915,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 552  build-platform */
t3=C_retrieve(lf[178]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2913 in k2909 in k2905 in k2897 in k2869 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2919,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
/* csi.scm: 554  shorten */
f_2853(t2,t3);}

/* k2917 in k2913 in k2909 in k2905 in k2897 in k2869 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2923,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(1));
/* csi.scm: 555  shorten */
f_2853(t2,t3);}

/* k2921 in k2917 in k2913 in k2909 in k2905 in k2897 in k2869 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(2));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
t4=(C_word)C_fudge(C_fix(17));
t5=(C_truep(t4)?lf[172]:lf[173]);
t6=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(1));
t7=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(2));
t8=(C_word)C_fudge(C_fix(18));
t9=(C_word)C_i_nequalp(C_fix(1),t8);
t10=(C_truep(t9)?lf[174]:lf[175]);
/* csi.scm: 537  printf */
t11=((C_word*)t0)[9];
((C_proc17)C_retrieve_proc(t11))(17,t11,((C_word*)t0)[8],lf[176],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_retrieve(lf[177]),((C_word*)t0)[2],t1,t2,t3,t5,t6,t7,t10);}

/* k2872 in k2869 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2877,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 562  ##sys#write-char-0 */
t3=C_retrieve(lf[152]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[150]+1));}

/* k2875 in k2872 in k2869 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(14)))){
/* csi.scm: 563  display */
t3=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[169]);}
else{
t3=t2;
f_2880(2,t3,C_SCHEME_UNDEFINED);}}

/* k2878 in k2875 in k2872 in k2869 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(15)))){
/* csi.scm: 564  display */
t3=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[168]);}
else{
t3=t2;
f_2883(2,t3,C_SCHEME_UNDEFINED);}}

/* k2881 in k2878 in k2875 in k2872 in k2869 in k2866 in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* shorten in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_2853(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2853,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2861,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_times(&a,2,t2,C_fix(100));
/* csi.scm: 527  truncate */
t5=*((C_word*)lf[167]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k2859 in shorten in k2849 in k2846 in k2843 in a2840 in k2837 in ##csi#report in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2861,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_divide(&a,2,t1,C_fix(100)));}

/* ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2728,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2732,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 500  open-input-string */
t4=C_retrieve(lf[162]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2737,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2757,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2760,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2762,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 507  call-with-current-continuation */
t6=*((C_word*)lf[161]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* a2761 in k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2762(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2762,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2768,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2780,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 507  with-exception-handler */
t5=C_retrieve(lf[160]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a2779 in a2761 in k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2819,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 507  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2818 in a2779 in a2761 in k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2819r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2819r(t0,t1,t2);}}

static void C_ccall f_2819r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2825,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 507  g681 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2824 in a2818 in a2779 in a2761 in k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2825,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2785 in a2779 in a2761 in k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2794,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 508  read */
t3=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2792 in a2785 in a2779 in a2761 in k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2794,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2796(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* do685 in k2792 in a2785 in a2779 in a2761 in k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_2796(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2796,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 510  reverse */
t4=*((C_word*)lf[159]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2813,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 508  read */
t5=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k2811 in do685 in k2792 in a2785 in a2779 in a2761 in k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2813,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2796(t3,((C_word*)t0)[2],t1,t2);}

/* a2767 in a2761 in k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2768,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2774,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 507  g681 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2773 in a2767 in a2761 in k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2774,2,t0,t1);}
/* csi.scm: 507  ##sys#error */
t2=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[158],((C_word*)t0)[2]);}

/* k2758 in k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2755 in k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2736 in k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2737,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2747,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 504  open-output-string */
t4=C_retrieve(lf[157]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2745 in a2736 in k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2750,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 505  write */
t3=*((C_word*)lf[72]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2748 in k2745 in a2736 in k2730 in ##csi#parse-option-string in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 506  get-output-string */
t2=C_retrieve(lf[156]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* do-unbreak-all in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2708,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2714,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[106],"broken-procedures"));}

/* a2713 in do-unbreak-all in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2714,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t3,C_fix(0),t4));}

/* k2706 in do-unbreak-all in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[106]=C_SCHEME_END_OF_LIST;;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve(lf[15]));}

/* ##csi#traced-procedure-exit in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2413,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2418,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 404  sub1 */
t5=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_retrieve(lf[78]));}

/* k2416 in ##csi#traced-procedure-exit in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2418,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 405  trace-indent */
t4=C_retrieve(lf[148]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2419 in k2416 in ##csi#traced-procedure-exit in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2424,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 406  write */
t3=*((C_word*)lf[72]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2422 in k2419 in k2416 in ##csi#traced-procedure-exit in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 407  display */
t3=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[154]);}

/* k2425 in k2422 in k2419 in k2416 in ##csi#traced-procedure-exit in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2438,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2437 in k2425 in k2422 in k2419 in k2416 in ##csi#traced-procedure-exit in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2438,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2442,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 410  write */
t4=*((C_word*)lf[72]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2440 in a2437 in k2425 in k2422 in k2419 in k2416 in ##csi#traced-procedure-exit in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[149]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(32),*((C_word*)lf[150]+1));}

/* k2428 in k2425 in k2422 in k2419 in k2416 in ##csi#traced-procedure-exit in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2433,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 413  ##sys#write-char-0 */
t3=C_retrieve(lf[152]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[150]+1));}

/* k2431 in k2428 in k2425 in k2422 in k2419 in k2416 in ##csi#traced-procedure-exit in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 414  flush-output */
t2=*((C_word*)lf[151]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##csi#traced-procedure-entry in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2390,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2394,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 396  trace-indent */
t5=C_retrieve(lf[148]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2392 in ##csi#traced-procedure-entry in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 397  add1 */
t3=*((C_word*)lf[153]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[78]));}

/* k2396 in k2392 in ##csi#traced-procedure-entry in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2398,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2401,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* csi.scm: 398  write */
t5=*((C_word*)lf[72]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k2399 in k2396 in k2392 in ##csi#traced-procedure-entry in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2404,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 399  ##sys#write-char-0 */
t3=C_retrieve(lf[152]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[150]+1));}

/* k2402 in k2399 in k2396 in k2392 in ##csi#traced-procedure-entry in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 400  flush-output */
t2=*((C_word*)lf[151]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* ##csi#trace-indent in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2366,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[149]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(124),*((C_word*)lf[150]+1));}

/* k2364 in ##csi#trace-indent in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2366,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2371,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2371(t5,((C_word*)t0)[2],C_retrieve(lf[78]));}

/* do619 in k2364 in ##csi#trace-indent in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_2371(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2371,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2381,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=C_retrieve(lf[149]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(32),*((C_word*)lf[150]+1));}}

/* k2379 in do619 in k2364 in ##csi#trace-indent in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2388,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 390  sub1 */
t3=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2386 in k2379 in do619 in k2364 in ##csi#trace-indent in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2371(t2,((C_word*)t0)[2],t1);}

/* ##csi#del in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2321,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2327,a[2]=t2,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2327(t8,t1,t3);}

/* loop in ##csi#del in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_2327(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2327,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2343,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 379  tst */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k2341 in loop in ##csi#del in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 381  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2327(t4,t2,t3);}}

/* k2351 in k2341 in loop in ##csi#del in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2353,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1783,3,t0,t1,t2);}
t3=C_set_block_item(lf[78],0,C_fix(0));
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 247  exit */
t4=C_retrieve(lf[79]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=t4;
f_1800(t6,(C_word)C_eqp(lf[147],t5));}
else{
t5=t4;
f_1800(t5,C_SCHEME_FALSE);}}}

/* k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_1800(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1800,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1806,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=((C_word*)t0)[13],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* csi.scm: 251  hash-table-ref/default */
t4=C_retrieve(lf[146]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[62],"command-table"),t2,C_SCHEME_FALSE);}
else{
t4=t3;
f_1806(2,t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2296,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2302,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 367  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t2,t3);}}

/* a2301 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2302(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2302r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2302r(t0,t1,t2);}}

static void C_ccall f_2302r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2306,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 368  history-add */
t4=C_retrieve(lf[54]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2304 in a2301 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2295 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2296,2,t0,t1);}
/* csi.scm: 367  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word ab[123],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1812,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(t1);
t4=t3;
((C_proc2)C_retrieve_proc(t4))(2,t4,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[80]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1827,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 258  read */
t4=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[82]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 262  read */
t5=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[83]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1864,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 267  read */
t6=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[14],lf[85]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 271  read */
t7=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[87]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 275  read */
t8=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[88]);
if(C_truep(t7)){
/* csi.scm: 280  report */
t8=C_retrieve(lf[89]);
((C_proc2)C_retrieve_proc(t8))(2,t8,((C_word*)t0)[15]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[90]);
if(C_truep(t8)){
/* csi.scm: 281  exit */
t9=C_retrieve(lf[79]);
((C_proc2)C_retrieve_proc(t9))(2,t9,((C_word*)t0)[15]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[91]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1943,a[2]=t10,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 283  read-line */
t12=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[14],lf[94]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1952,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1977,a[2]=t11,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 287  read-line */
t13=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[98]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1986,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 291  read */
t13=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[102]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2039,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2043,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2047,a[2]=t14,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 295  read-line */
t16=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t16))(2,t16,t15);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[14],lf[113]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2060,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2064,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2068,a[2]=t15,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 296  read-line */
t17=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t17))(2,t17,t16);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[14],lf[117]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2081,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2085,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2089,a[2]=t16,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 297  read-line */
t18=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t18))(2,t18,t17);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[14],lf[122]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2102,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2106,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2110,a[2]=t17,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 298  read-line */
t19=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t19))(2,t19,t18);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[14],lf[124]);
if(C_truep(t16)){
/* csi.scm: 299  do-unbreak-all */
t17=C_retrieve(lf[125]);
((C_proc2)C_retrieve_proc(t17))(2,t17,((C_word*)t0)[15]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[14],lf[126]);
if(C_truep(t17)){
t18=C_set_block_item(lf[127],0,C_SCHEME_FALSE);
t19=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,t18);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[14],lf[128]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2136,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2140,a[2]=t19,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 303  read */
t21=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t21))(2,t21,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[14],lf[129]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[103],"traced-procedures")))){
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2172,a[2]=t20,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* map */
t22=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t21,*((C_word*)lf[131]+1),C_retrieve2(lf[103],"traced-procedures"));}
else{
t21=t20;
f_2149(2,t21,C_SCHEME_UNDEFINED);}}
else{
t20=(C_word)C_eqp(((C_word*)t0)[14],lf[133]);
if(C_truep(t20)){
if(C_truep(C_retrieve(lf[134]))){
t21=C_retrieve(lf[134]);
t22=C_set_block_item(lf[134],0,C_SCHEME_FALSE);
/* csi.scm: 313  ##sys#break-resume */
t23=C_retrieve(lf[135]);
((C_proc3)C_retrieve_proc(t23))(3,t23,((C_word*)t0)[15],t21);}
else{
/* csi.scm: 314  display */
t21=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t21))(3,t21,((C_word*)t0)[15],lf[136]);}}
else{
t21=(C_word)C_eqp(((C_word*)t0)[14],lf[137]);
if(C_truep(t21)){
if(C_truep(C_retrieve(lf[138]))){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_a_i_list(&a,1,C_retrieve(lf[138]));
/* csi.scm: 317  history-add */
t24=C_retrieve(lf[54]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t22,t23);}
else{
t22=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_UNDEFINED);}}
else{
t22=(C_word)C_eqp(((C_word*)t0)[14],lf[139]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 320  read */
t24=((C_word*)t0)[12];
((C_proc2)C_retrieve_proc(t24))(2,t24,t23);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[14],lf[140]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 324  read-line */
t25=((C_word*)t0)[9];
((C_proc2)C_retrieve_proc(t25))(2,t25,t24);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[14],lf[142]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 329  display */
t26=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,lf[144]);}
else{
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2282,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 364  printf */
t26=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t26))(4,t26,t25,lf[145],((C_word*)t0)[2]);}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2280 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[15]));}

/* k2256 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2266,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 355  hash-table-walk */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve2(lf[62],"command-table"),t3);}

/* a2265 in k2256 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2266,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep(t4)){
/* csi.scm: 360  print */
t5=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,C_make_character(32),t4);}
else{
/* csi.scm: 361  print */
t5=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,lf[143],t2);}}

/* k2259 in k2256 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[15]));}

/* k2237 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2242,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 325  system */
t3=C_retrieve(lf[141]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2240 in k2237 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2245,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* csi.scm: 326  history-add */
t4=C_retrieve(lf[54]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2243 in k2240 in k2237 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2214 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2219,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 321  read-line */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2217 in k2214 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2226,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
/* csi.scm: 322  eval */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2224 in k2217 in k2214 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 322  singlestep */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2198 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 318  describe */
t2=C_retrieve(lf[84]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[138]));}

/* k2170 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 306  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[132],t1);}

/* k2147 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2149,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[106],"broken-procedures")))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2162,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[131]+1),C_retrieve2(lf[106],"broken-procedures"));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2160 in k2147 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 308  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[130],t1);}

/* k2138 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 303  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2134 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[127]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2108 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 298  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2104 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[112]+1),t1);}

/* k2100 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2675,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2674 in k2100 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2675,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2679,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 481  macroexpand */
t4=C_retrieve(lf[81]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2677 in a2674 in k2100 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2679,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[106],"broken-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2698,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 486  del */
t6=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,C_retrieve2(lf[106],"broken-procedures"),*((C_word*)lf[115]+1));}
else{
/* csi.scm: 483  ##sys#warn */
t3=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[123],t1);}}

/* k2696 in k2677 in a2674 in k2100 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[106],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2087 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 297  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2083 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[112]+1),t1);}

/* k2079 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2081,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2594,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[106],"broken-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2607,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2606 in k2079 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2607,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2611,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 460  macroexpand */
t4=C_retrieve(lf[81]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2609 in a2606 in k2079 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2611,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[103],"traced-procedures"));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2617,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2656,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 463  ##sys#warn */
t5=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[121],t1);}
else{
t4=t3;
f_2617(t4,C_SCHEME_UNDEFINED);}}

/* k2654 in k2609 in a2606 in k2079 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2656,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2663,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 465  del */
t5=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[4],C_retrieve2(lf[103],"traced-procedures"),*((C_word*)lf[115]+1));}

/* k2661 in k2654 in k2609 in a2606 in k2079 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[103],t1);
t3=((C_word*)t0)[2];
f_2617(t3,t2);}

/* k2615 in k2609 in a2606 in k2079 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_2617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2617,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[106],"broken-procedures"));
t5=C_mutate(&lf[106],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t6));}
else{
/* csi.scm: 467  ##sys#error */
t3=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[120],((C_word*)t0)[3]);}}

/* a2637 in k2615 in k2609 in a2606 in k2079 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2638r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2638r(t0,t1,t2);}}

static void C_ccall f_2638r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2642,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 473  ##sys#break-entry */
t4=C_retrieve(lf[119]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2640 in a2637 in k2615 in k2609 in a2606 in k2079 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2593 in k2079 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2594,3,t0,t1,t2);}
t3=(C_word)C_i_car(C_retrieve(lf[118]));
/* csi.scm: 457  print */
t4=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k2066 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 296  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2062 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[112]+1),t1);}

/* k2058 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2060,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2553,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2552 in k2058 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2553,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2557,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 446  macroexpand */
t4=C_retrieve(lf[81]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2555 in a2552 in k2058 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2557,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[103],"traced-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2576,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 451  del */
t6=C_retrieve(lf[114]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,t2,C_retrieve2(lf[103],"traced-procedures"),*((C_word*)lf[115]+1));}
else{
/* csi.scm: 448  ##sys#warn */
t3=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[116],t1);}}

/* k2574 in k2555 in a2552 in k2058 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[103],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2045 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 295  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2041 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[112]+1),t1);}

/* k2037 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2039,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2459,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[103],"traced-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2472,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2471 in k2037 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2472(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2472,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2476,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 422  macroexpand */
t4=C_retrieve(lf[81]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2474 in a2471 in k2037 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2476,2,t0,t1);}
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[103],"traced-procedures")))){
/* csi.scm: 424  ##sys#warn */
t2=C_retrieve(lf[104]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[105],t1);}
else{
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[106],"broken-procedures")))){
/* csi.scm: 426  ##sys#warn */
t2=C_retrieve(lf[104]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[107]);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[103],"traced-procedures"));
t5=C_mutate(&lf[103],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2515,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t1,C_fix(0),t6));}
else{
/* csi.scm: 429  ##sys#error */
t3=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[110],t1);}}}}

/* a2514 in k2474 in a2471 in k2037 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2515r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2515r(t0,t1,t2);}}

static void C_ccall f_2515r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2519,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 435  traced-procedure-entry */
t4=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2517 in a2514 in k2474 in a2471 in k2037 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2524,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2530,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 436  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2529 in k2517 in a2514 in k2474 in a2471 in k2037 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2530r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2530r(t0,t1,t2);}}

static void C_ccall f_2530r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2534,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 438  traced-procedure-exit */
t4=C_retrieve(lf[108]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k2532 in a2529 in k2517 in a2514 in k2474 in a2471 in k2037 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2523 in k2517 in a2514 in k2474 in a2471 in k2037 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2524,2,t0,t1);}
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2458 in k2037 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2459,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* csi.scm: 419  print */
t4=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k1984 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1991,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2019,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2018 in k1984 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2019r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2019r(t0,t1,t2);}}

static void C_ccall f_2019r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2023,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 293  history-add */
t4=C_retrieve(lf[54]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2021 in a2018 in k1984 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1990 in k1984 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1995,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[101]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1993 in a1990 in k1984 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2000,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2006,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2005 in k1993 in a1990 in k1984 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2006r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2006r(t0,t1,t2);}}

static void C_ccall f_2006r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2010,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2017,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[100]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2015 in a2005 in k1993 in a1990 in k1984 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
t2=C_retrieve(lf[99]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2008 in a2005 in k1993 in a1990 in k1984 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1999 in k1993 in a1990 in k1984 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2000,2,t0,t1);}
/* csi.scm: 292  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1975 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 287  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1950 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1955,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a1959 in k1950 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1960(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1960,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* load-noisily544 */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t2,lf[97],t3);}

/* a1965 in a1959 in k1950 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1966,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1970,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 288  pretty-print */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1968 in a1965 in a1959 in k1950 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 288  print* */
t2=*((C_word*)lf[95]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[96]);}

/* k1953 in k1950 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[15]));}

/* k1941 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 283  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1931 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1936,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[93]),t1);}

/* k1934 in k1931 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[15]));}

/* k1892 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1897,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 276  read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1895 in k1892 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1900,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 277  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1898 in k1895 in k1892 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1903,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 278  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1901 in k1898 in k1895 in k1892 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 279  dump */
t2=C_retrieve(lf[86]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1877 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 272  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1880 in k1877 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 273  dump */
t2=C_retrieve(lf[86]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1862 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 268  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1865 in k1862 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 269  describe */
t2=C_retrieve(lf[84]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1844 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1849,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 263  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1847 in k1844 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 264  pretty-print */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1850 in k1847 in k1844 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[15]));}

/* k1825 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1837,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 259  macroexpand */
t4=C_retrieve(lf[81]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k1835 in k1825 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 259  pretty-print */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1828 in k1825 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[15]));}

/* k1810 in k1804 in k1798 in ##sys#repl-eval-hook in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[15]));}

/* toplevel-command in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1742r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1742r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1742r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1746,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1746(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1746(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1744 in toplevel-command in k1738 in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1746,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[5],lf[64]);
t3=(C_truep(t1)?(C_word)C_i_check_string_2(t1,lf[64]):C_SCHEME_UNDEFINED);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* csi.scm: 226  hash-table-set! */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[2],C_retrieve2(lf[62],"command-table"),((C_word*)t0)[5],t4);}

/* ##sys#read-prompt-hook in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1733,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 217  tty-input? */
t3=C_retrieve(lf[57]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1731 in ##sys#read-prompt-hook in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 217  old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##csi#tty-input? in k1709 in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1713,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csi.scm: 210  ##sys#tty-port? */
t3=C_retrieve(lf[58]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,*((C_word*)lf[59]+1));}}

/* ##csi#history-ref in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1686(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1686,3,t0,t1,t2);}
t3=(C_word)C_i_inexact_to_exact(t2);
t4=(C_word)C_fixnum_greaterp(t3,C_fix(0));
t5=(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(t3,C_retrieve(lf[33])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_vector_ref(C_retrieve(lf[52]),t3));}
else{
/* csi.scm: 202  ##sys#error */
t6=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[56],t2);}}

/* ##csi#history-add in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1647(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1647,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_retrieve(lf[15]):(C_word)C_slot(t2,C_fix(0)));
t5=(C_word)C_block_size(C_retrieve(lf[52]));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1657,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_retrieve(lf[33]),t5))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1671,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_times(C_fix(2),t5);
/* csi.scm: 193  vector-resize */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve(lf[52]),t8);}
else{
t7=t6;
f_1657(t7,C_SCHEME_UNDEFINED);}}

/* k1669 in ##csi#history-add in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[52]+1,t1);
t3=((C_word*)t0)[2];
f_1657(t3,t2);}

/* k1655 in ##csi#history-add in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_1657(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_vector_set(C_retrieve(lf[52]),C_retrieve(lf[33]),((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(C_retrieve(lf[33]),C_fix(1));
t4=C_mutate((C_word*)lf[33]+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##csi#lookup-script-file in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1541(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1541,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1545,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 166  getenv */
t4=C_retrieve(lf[50]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[51]);}

/* k1543 in ##csi#lookup-script-file in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1545,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t4=f_1431(t3);
if(C_truep(t4)){
/* csi.scm: 168  addext */
f_1493(((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t5=((C_word*)t0)[5];
t6=(C_word)C_block_size(t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1520,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=f_1520(t7,C_fix(0));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1569,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t10=((C_word*)t0)[2];
t11=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t12=(C_truep(t10)?(C_word)C_i_foreign_block_argumentp(t10):C_SCHEME_FALSE);
t13=(C_word)C_i_foreign_fixnum_argumentp(C_fix(256));
t14=(C_word)stub488(t11,t12,t13);
/* ##sys#peek-nonnull-c-string */
t15=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t9,t14,C_fix(0));}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 172  addext */
f_1493(t9,((C_word*)t0)[5]);}}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1584 in k1543 in ##csi#lookup-script-file in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1586,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 174  string-append */
t3=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[49],((C_word*)t0)[2]);}}

/* k1590 in k1584 in k1543 in ##csi#lookup-script-file in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1599,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 175  string-split */
t3=C_retrieve(lf[47]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[48]);}

/* k1597 in k1590 in k1584 in k1543 in ##csi#lookup-script-file in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1599,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1601(t5,((C_word*)t0)[2],t1);}

/* loop in k1597 in k1590 in k1584 in k1543 in ##csi#lookup-script-file in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_1601(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1601,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1628,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 177  chop-separator */
t6=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1626 in loop in k1597 in k1590 in k1584 in k1543 in ##csi#lookup-script-file in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 177  string-append */
t2=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1609 in loop in k1597 in k1590 in k1584 in k1543 in ##csi#lookup-script-file in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1614,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 178  addext */
f_1493(t2,t1);}

/* k1612 in k1609 in loop in k1597 in k1590 in k1584 in k1543 in ##csi#lookup-script-file in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 179  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1601(t3,((C_word*)t0)[4],t2);}}

/* k1567 in k1543 in ##csi#lookup-script-file in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1569,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1579,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 171  chop-separator */
t4=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1581 in k1567 in k1543 in ##csi#lookup-script-file in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 171  string-append */
t2=*((C_word*)lf[42]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[45],((C_word*)t0)[2]);}

/* k1577 in k1567 in k1543 in ##csi#lookup-script-file in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 171  addext */
f_1493(((C_word*)t0)[2],t1);}

/* loop in k1543 in ##csi#lookup-script-file in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static C_word C_fcall f_1520(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(C_SCHEME_FALSE);}
else{
t2=f_1431((C_word)C_subchar(((C_word*)t0)[2],t1));
if(C_truep(t2)){
return(t1);}
else{
t3=(C_word)C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* addext in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_fcall f_1493(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1493,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1500,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 155  file-exists? */
t4=C_retrieve(lf[41]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1498 in addext in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1500,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1503,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 157  string-append */
t3=*((C_word*)lf[42]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k1501 in k1498 in addext in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1509,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 158  file-exists? */
t3=C_retrieve(lf[41]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1507 in k1501 in k1498 in addext in k1472 in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##csi#chop-separator in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1443,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1447,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 140  sub1 */
t5=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k1445 in ##csi#chop-separator in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_string_ref(((C_word*)t0)[4],t1);
t3=(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(0)))?f_1431(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
/* csi.scm: 143  substring */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],((C_word*)t0)[4],C_fix(0),t1);}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}}

/* dirseparator? in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static C_word C_fcall f_1431(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(t1,C_make_character(92));
return((C_truep(t2)?t2:(C_word)C_eqp(t1,C_make_character(47))));}

/* ##sys#sharp-number-hook in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1421,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1429,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 129  history-ref */
t5=C_retrieve(lf[34]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1427 in ##sys#sharp-number-hook in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1429,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[32],t1));}

/* ##sys#user-read-hook in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1392,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(41),t2);
t5=(C_truep(t4)?t4:(C_word)C_u_i_char_whitespacep(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1409,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_fixnum_difference(C_retrieve(lf[33]),C_fix(1));
/* csi.scm: 124  history-ref */
t8=C_retrieve(lf[34]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
/* csi.scm: 125  old-hook */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}}

/* k1407 in ##sys#user-read-hook in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1409,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[32],t1));}

/* ##csi#print-banner in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1390,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 113  chicken-version */
t3=C_retrieve(lf[28]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k1388 in ##csi#print-banner in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 113  print */
t2=*((C_word*)lf[26]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[12],t1,lf[27]);}

/* ##csi#print-usage in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1374,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 83   display */
t3=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[24]);}

/* k1372 in ##csi#print-usage in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1377,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 98   display */
t3=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[16]);}

/* k1375 in k1372 in ##csi#print-usage in k1355 in k1352 in k1349 in k1346 in k1343 in k1340 in k1337 in k1334 in k1331 in k1328 in k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1207 in k1204 in k1201 in k1198 in k1195 in k1192 in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 99   display */
t2=*((C_word*)lf[22]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[23]);}

/* assign in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1121,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1125,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   ##sys#check-syntax */
t5=C_retrieve(lf[8]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[9],t2,lf[10]);}

/* k1123 in assign in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1125,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,lf[4]);
t4=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[5],t2,t4));}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t3,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1162,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 52   map */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[7]),((C_word*)t0)[5]);}}}

/* k1160 in k1123 in assign in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1162,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1181,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1183,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 52   map */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],t1);}

/* a1182 in k1160 in k1123 in assign in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1183,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[6],t2,t3));}

/* k1179 in k1160 in k1123 in assign in k1118 in k1115 in k1112 in k1109 in k1106 in k1103 in k1100 in k1097 in k1094 in k1091 in k1088 in k1085 in k1082 in k1079 in k1076 in k1073 in k1070 */
static void C_ccall f_1181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1181,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[3],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[5],((C_word*)t0)[2],t3));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[764] = {
{"toplevelcsi.scm",(void*)C_toplevel},
{"f_1072csi.scm",(void*)f_1072},
{"f_1075csi.scm",(void*)f_1075},
{"f_1078csi.scm",(void*)f_1078},
{"f_1081csi.scm",(void*)f_1081},
{"f_1084csi.scm",(void*)f_1084},
{"f_8723csi.scm",(void*)f_8723},
{"f_8727csi.scm",(void*)f_8727},
{"f_8730csi.scm",(void*)f_8730},
{"f_8733csi.scm",(void*)f_8733},
{"f_8739csi.scm",(void*)f_8739},
{"f_8945csi.scm",(void*)f_8945},
{"f_8925csi.scm",(void*)f_8925},
{"f_8921csi.scm",(void*)f_8921},
{"f_8901csi.scm",(void*)f_8901},
{"f_8764csi.scm",(void*)f_8764},
{"f_8774csi.scm",(void*)f_8774},
{"f_8893csi.scm",(void*)f_8893},
{"f_8777csi.scm",(void*)f_8777},
{"f_8889csi.scm",(void*)f_8889},
{"f_8780csi.scm",(void*)f_8780},
{"f_8811csi.scm",(void*)f_8811},
{"f_8791csi.scm",(void*)f_8791},
{"f_8762csi.scm",(void*)f_8762},
{"f_1087csi.scm",(void*)f_1087},
{"f_8635csi.scm",(void*)f_8635},
{"f_8652csi.scm",(void*)f_8652},
{"f_8655csi.scm",(void*)f_8655},
{"f_8661csi.scm",(void*)f_8661},
{"f_1090csi.scm",(void*)f_1090},
{"f_8594csi.scm",(void*)f_8594},
{"f_8598csi.scm",(void*)f_8598},
{"f_1093csi.scm",(void*)f_1093},
{"f_8578csi.scm",(void*)f_8578},
{"f_8588csi.scm",(void*)f_8588},
{"f_8586csi.scm",(void*)f_8586},
{"f_1096csi.scm",(void*)f_1096},
{"f_8501csi.scm",(void*)f_8501},
{"f_8505csi.scm",(void*)f_8505},
{"f_8573csi.scm",(void*)f_8573},
{"f_8508csi.scm",(void*)f_8508},
{"f_8517csi.scm",(void*)f_8517},
{"f_8564csi.scm",(void*)f_8564},
{"f_8531csi.scm",(void*)f_8531},
{"f_8539csi.scm",(void*)f_8539},
{"f_8541csi.scm",(void*)f_8541},
{"f_8558csi.scm",(void*)f_8558},
{"f_8523csi.scm",(void*)f_8523},
{"f_8515csi.scm",(void*)f_8515},
{"f_1099csi.scm",(void*)f_1099},
{"f_8441csi.scm",(void*)f_8441},
{"f_8445csi.scm",(void*)f_8445},
{"f_1102csi.scm",(void*)f_1102},
{"f_8382csi.scm",(void*)f_8382},
{"f_8386csi.scm",(void*)f_8386},
{"f_8413csi.scm",(void*)f_8413},
{"f_1105csi.scm",(void*)f_1105},
{"f_8208csi.scm",(void*)f_8208},
{"f_8212csi.scm",(void*)f_8212},
{"f_8215csi.scm",(void*)f_8215},
{"f_8376csi.scm",(void*)f_8376},
{"f_8218csi.scm",(void*)f_8218},
{"f_8370csi.scm",(void*)f_8370},
{"f_8221csi.scm",(void*)f_8221},
{"f_8368csi.scm",(void*)f_8368},
{"f_8332csi.scm",(void*)f_8332},
{"f_8346csi.scm",(void*)f_8346},
{"f_8360csi.scm",(void*)f_8360},
{"f_8340csi.scm",(void*)f_8340},
{"f_8336csi.scm",(void*)f_8336},
{"f_8228csi.scm",(void*)f_8228},
{"f_8324csi.scm",(void*)f_8324},
{"f_8300csi.scm",(void*)f_8300},
{"f_8318csi.scm",(void*)f_8318},
{"f_8308csi.scm",(void*)f_8308},
{"f_8304csi.scm",(void*)f_8304},
{"f_8296csi.scm",(void*)f_8296},
{"f_8280csi.scm",(void*)f_8280},
{"f_8256csi.scm",(void*)f_8256},
{"f_8274csi.scm",(void*)f_8274},
{"f_8264csi.scm",(void*)f_8264},
{"f_8260csi.scm",(void*)f_8260},
{"f_8252csi.scm",(void*)f_8252},
{"f_1108csi.scm",(void*)f_1108},
{"f_8113csi.scm",(void*)f_8113},
{"f_8149csi.scm",(void*)f_8149},
{"f_8162csi.scm",(void*)f_8162},
{"f_8120csi.scm",(void*)f_8120},
{"f_1111csi.scm",(void*)f_1111},
{"f_8003csi.scm",(void*)f_8003},
{"f_8007csi.scm",(void*)f_8007},
{"f_8010csi.scm",(void*)f_8010},
{"f_8013csi.scm",(void*)f_8013},
{"f_8016csi.scm",(void*)f_8016},
{"f_8107csi.scm",(void*)f_8107},
{"f_8019csi.scm",(void*)f_8019},
{"f_8101csi.scm",(void*)f_8101},
{"f_8022csi.scm",(void*)f_8022},
{"f_8095csi.scm",(void*)f_8095},
{"f_8099csi.scm",(void*)f_8099},
{"f_8029csi.scm",(void*)f_8029},
{"f_8067csi.scm",(void*)f_8067},
{"f_8065csi.scm",(void*)f_8065},
{"f_1114csi.scm",(void*)f_1114},
{"f_7993csi.scm",(void*)f_7993},
{"f_1117csi.scm",(void*)f_1117},
{"f_7979csi.scm",(void*)f_7979},
{"f_1120csi.scm",(void*)f_1120},
{"f_1194csi.scm",(void*)f_1194},
{"f_1197csi.scm",(void*)f_1197},
{"f_7717csi.scm",(void*)f_7717},
{"f_7721csi.scm",(void*)f_7721},
{"f_7730csi.scm",(void*)f_7730},
{"f_7939csi.scm",(void*)f_7939},
{"f_7952csi.scm",(void*)f_7952},
{"f_7733csi.scm",(void*)f_7733},
{"f_7929csi.scm",(void*)f_7929},
{"f_7937csi.scm",(void*)f_7937},
{"f_7736csi.scm",(void*)f_7736},
{"f_7883csi.scm",(void*)f_7883},
{"f_7916csi.scm",(void*)f_7916},
{"f_7923csi.scm",(void*)f_7923},
{"f_7899csi.scm",(void*)f_7899},
{"f_7748csi.scm",(void*)f_7748},
{"f_7877csi.scm",(void*)f_7877},
{"f_7755csi.scm",(void*)f_7755},
{"f_7757csi.scm",(void*)f_7757},
{"f_7871csi.scm",(void*)f_7871},
{"f_7791csi.scm",(void*)f_7791},
{"f_7845csi.scm",(void*)f_7845},
{"f_7822csi.scm",(void*)f_7822},
{"f_7802csi.scm",(void*)f_7802},
{"f_7777csi.scm",(void*)f_7777},
{"f_7785csi.scm",(void*)f_7785},
{"f_7775csi.scm",(void*)f_7775},
{"f_7737csi.scm",(void*)f_7737},
{"f_7677csi.scm",(void*)f_7677},
{"f_7700csi.scm",(void*)f_7700},
{"f_7704csi.scm",(void*)f_7704},
{"f_7646csi.scm",(void*)f_7646},
{"f_7667csi.scm",(void*)f_7667},
{"f_1200csi.scm",(void*)f_1200},
{"f_7595csi.scm",(void*)f_7595},
{"f_7599csi.scm",(void*)f_7599},
{"f_7610csi.scm",(void*)f_7610},
{"f_7635csi.scm",(void*)f_7635},
{"f_1203csi.scm",(void*)f_1203},
{"f_7475csi.scm",(void*)f_7475},
{"f_7479csi.scm",(void*)f_7479},
{"f_7589csi.scm",(void*)f_7589},
{"f_7587csi.scm",(void*)f_7587},
{"f_7488csi.scm",(void*)f_7488},
{"f_7575csi.scm",(void*)f_7575},
{"f_7583csi.scm",(void*)f_7583},
{"f_7491csi.scm",(void*)f_7491},
{"f_7569csi.scm",(void*)f_7569},
{"f_7511csi.scm",(void*)f_7511},
{"f_7521csi.scm",(void*)f_7521},
{"f_7541csi.scm",(void*)f_7541},
{"f_7547csi.scm",(void*)f_7547},
{"f_7555csi.scm",(void*)f_7555},
{"f_7545csi.scm",(void*)f_7545},
{"f_7519csi.scm",(void*)f_7519},
{"f_7515csi.scm",(void*)f_7515},
{"f_7492csi.scm",(void*)f_7492},
{"f_1206csi.scm",(void*)f_1206},
{"f_7454csi.scm",(void*)f_7454},
{"f_7458csi.scm",(void*)f_7458},
{"f_1209csi.scm",(void*)f_1209},
{"f_7444csi.scm",(void*)f_7444},
{"f_1215csi.scm",(void*)f_1215},
{"f_1224csi.scm",(void*)f_1224},
{"f_1240csi.scm",(void*)f_1240},
{"f_1227csi.scm",(void*)f_1227},
{"f_1288csi.scm",(void*)f_1288},
{"f_7423csi.scm",(void*)f_7423},
{"f_7427csi.scm",(void*)f_7427},
{"f_1291csi.scm",(void*)f_1291},
{"f_7307csi.scm",(void*)f_7307},
{"f_7311csi.scm",(void*)f_7311},
{"f_7320csi.scm",(void*)f_7320},
{"f_7334csi.scm",(void*)f_7334},
{"f_7398csi.scm",(void*)f_7398},
{"f_7380csi.scm",(void*)f_7380},
{"f_7363csi.scm",(void*)f_7363},
{"f_1294csi.scm",(void*)f_1294},
{"f_7208csi.scm",(void*)f_7208},
{"f_7218csi.scm",(void*)f_7218},
{"f_7231csi.scm",(void*)f_7231},
{"f_7247csi.scm",(void*)f_7247},
{"f_7285csi.scm",(void*)f_7285},
{"f_7283csi.scm",(void*)f_7283},
{"f_7275csi.scm",(void*)f_7275},
{"f_7229csi.scm",(void*)f_7229},
{"f_1297csi.scm",(void*)f_1297},
{"f_7119csi.scm",(void*)f_7119},
{"f_7129csi.scm",(void*)f_7129},
{"f_7142csi.scm",(void*)f_7142},
{"f_7158csi.scm",(void*)f_7158},
{"f_7186csi.scm",(void*)f_7186},
{"f_7140csi.scm",(void*)f_7140},
{"f_1300csi.scm",(void*)f_1300},
{"f_6833csi.scm",(void*)f_6833},
{"f_7030csi.scm",(void*)f_7030},
{"f_7033csi.scm",(void*)f_7033},
{"f_7036csi.scm",(void*)f_7036},
{"f_7109csi.scm",(void*)f_7109},
{"f_7117csi.scm",(void*)f_7117},
{"f_7052csi.scm",(void*)f_7052},
{"f_7055csi.scm",(void*)f_7055},
{"f_7058csi.scm",(void*)f_7058},
{"f_7061csi.scm",(void*)f_7061},
{"f_7099csi.scm",(void*)f_7099},
{"f_7107csi.scm",(void*)f_7107},
{"f_7064csi.scm",(void*)f_7064},
{"f_6844csi.scm",(void*)f_6844},
{"f_6848csi.scm",(void*)f_6848},
{"f_6852csi.scm",(void*)f_6852},
{"f_6854csi.scm",(void*)f_6854},
{"f_6899csi.scm",(void*)f_6899},
{"f_6911csi.scm",(void*)f_6911},
{"f_6907csi.scm",(void*)f_6907},
{"f_6875csi.scm",(void*)f_6875},
{"f_7067csi.scm",(void*)f_7067},
{"f_6927csi.scm",(void*)f_6927},
{"f_7027csi.scm",(void*)f_7027},
{"f_6991csi.scm",(void*)f_6991},
{"f_6961csi.scm",(void*)f_6961},
{"f_7070csi.scm",(void*)f_7070},
{"f_7037csi.scm",(void*)f_7037},
{"f_7049csi.scm",(void*)f_7049},
{"f_7045csi.scm",(void*)f_7045},
{"f_1303csi.scm",(void*)f_1303},
{"f_6776csi.scm",(void*)f_6776},
{"f_6780csi.scm",(void*)f_6780},
{"f_1306csi.scm",(void*)f_1306},
{"f_6770csi.scm",(void*)f_6770},
{"f_1309csi.scm",(void*)f_1309},
{"f_6617csi.scm",(void*)f_6617},
{"f_6621csi.scm",(void*)f_6621},
{"f_6624csi.scm",(void*)f_6624},
{"f_6627csi.scm",(void*)f_6627},
{"f_6640csi.scm",(void*)f_6640},
{"f_6690csi.scm",(void*)f_6690},
{"f_6701csi.scm",(void*)f_6701},
{"f_6638csi.scm",(void*)f_6638},
{"f_1312csi.scm",(void*)f_1312},
{"f_6341csi.scm",(void*)f_6341},
{"f_6375csi.scm",(void*)f_6375},
{"f_6378csi.scm",(void*)f_6378},
{"f_6604csi.scm",(void*)f_6604},
{"f_6614csi.scm",(void*)f_6614},
{"f_6602csi.scm",(void*)f_6602},
{"f_6381csi.scm",(void*)f_6381},
{"f_6350csi.scm",(void*)f_6350},
{"f_6364csi.scm",(void*)f_6364},
{"f_6368csi.scm",(void*)f_6368},
{"f_6384csi.scm",(void*)f_6384},
{"f_6387csi.scm",(void*)f_6387},
{"f_6390csi.scm",(void*)f_6390},
{"f_6397csi.scm",(void*)f_6397},
{"f_6411csi.scm",(void*)f_6411},
{"f_6421csi.scm",(void*)f_6421},
{"f_6425csi.scm",(void*)f_6425},
{"f_6435csi.scm",(void*)f_6435},
{"f_6451csi.scm",(void*)f_6451},
{"f_6470csi.scm",(void*)f_6470},
{"f_6526csi.scm",(void*)f_6526},
{"f_6537csi.scm",(void*)f_6537},
{"f_6455csi.scm",(void*)f_6455},
{"f_6468csi.scm",(void*)f_6468},
{"f_6441csi.scm",(void*)f_6441},
{"f_6449csi.scm",(void*)f_6449},
{"f_6439csi.scm",(void*)f_6439},
{"f_6409csi.scm",(void*)f_6409},
{"f_1315csi.scm",(void*)f_1315},
{"f_6284csi.scm",(void*)f_6284},
{"f_6324csi.scm",(void*)f_6324},
{"f_6294csi.scm",(void*)f_6294},
{"f_1318csi.scm",(void*)f_1318},
{"f_6208csi.scm",(void*)f_6208},
{"f_6212csi.scm",(void*)f_6212},
{"f_6215csi.scm",(void*)f_6215},
{"f_1321csi.scm",(void*)f_1321},
{"f_6024csi.scm",(void*)f_6024},
{"f_6028csi.scm",(void*)f_6028},
{"f_6031csi.scm",(void*)f_6031},
{"f_6174csi.scm",(void*)f_6174},
{"f_6170csi.scm",(void*)f_6170},
{"f_6033csi.scm",(void*)f_6033},
{"f_6121csi.scm",(void*)f_6121},
{"f_6119csi.scm",(void*)f_6119},
{"f_6089csi.scm",(void*)f_6089},
{"f_6056csi.scm",(void*)f_6056},
{"f_1324csi.scm",(void*)f_1324},
{"f_5834csi.scm",(void*)f_5834},
{"f_5841csi.scm",(void*)f_5841},
{"f_6015csi.scm",(void*)f_6015},
{"f_6013csi.scm",(void*)f_6013},
{"f_5866csi.scm",(void*)f_5866},
{"f_5892csi.scm",(void*)f_5892},
{"f_5920csi.scm",(void*)f_5920},
{"f_5912csi.scm",(void*)f_5912},
{"f_5904csi.scm",(void*)f_5904},
{"f_5864csi.scm",(void*)f_5864},
{"f_1327csi.scm",(void*)f_1327},
{"f_5825csi.scm",(void*)f_5825},
{"f_5829csi.scm",(void*)f_5829},
{"f_1330csi.scm",(void*)f_1330},
{"f_5806csi.scm",(void*)f_5806},
{"f_5810csi.scm",(void*)f_5810},
{"f_5819csi.scm",(void*)f_5819},
{"f_5817csi.scm",(void*)f_5817},
{"f_1333csi.scm",(void*)f_1333},
{"f_5787csi.scm",(void*)f_5787},
{"f_5791csi.scm",(void*)f_5791},
{"f_5800csi.scm",(void*)f_5800},
{"f_5798csi.scm",(void*)f_5798},
{"f_1336csi.scm",(void*)f_1336},
{"f_5659csi.scm",(void*)f_5659},
{"f_5665csi.scm",(void*)f_5665},
{"f_5746csi.scm",(void*)f_5746},
{"f_5675csi.scm",(void*)f_5675},
{"f_5678csi.scm",(void*)f_5678},
{"f_5684csi.scm",(void*)f_5684},
{"f_5691csi.scm",(void*)f_5691},
{"f_5707csi.scm",(void*)f_5707},
{"f_1339csi.scm",(void*)f_1339},
{"f_5516csi.scm",(void*)f_5516},
{"f_5522csi.scm",(void*)f_5522},
{"f_5634csi.scm",(void*)f_5634},
{"f_5607csi.scm",(void*)f_5607},
{"f_5532csi.scm",(void*)f_5532},
{"f_5535csi.scm",(void*)f_5535},
{"f_5541csi.scm",(void*)f_5541},
{"f_5552csi.scm",(void*)f_5552},
{"f_5568csi.scm",(void*)f_5568},
{"f_1342csi.scm",(void*)f_1342},
{"f_5457csi.scm",(void*)f_5457},
{"f_1345csi.scm",(void*)f_1345},
{"f_5286csi.scm",(void*)f_5286},
{"f_5292csi.scm",(void*)f_5292},
{"f_5366csi.scm",(void*)f_5366},
{"f_5369csi.scm",(void*)f_5369},
{"f_5442csi.scm",(void*)f_5442},
{"f_5435csi.scm",(void*)f_5435},
{"f_5427csi.scm",(void*)f_5427},
{"f_5414csi.scm",(void*)f_5414},
{"f_5393csi.scm",(void*)f_5393},
{"f_5302csi.scm",(void*)f_5302},
{"f_1348csi.scm",(void*)f_1348},
{"f_5235csi.scm",(void*)f_5235},
{"f_1351csi.scm",(void*)f_1351},
{"f_5175csi.scm",(void*)f_5175},
{"f_5185csi.scm",(void*)f_5185},
{"f_5204csi.scm",(void*)f_5204},
{"f_5188csi.scm",(void*)f_5188},
{"f_1354csi.scm",(void*)f_1354},
{"f_1357csi.scm",(void*)f_1357},
{"f_1474csi.scm",(void*)f_1474},
{"f_5169csi.scm",(void*)f_5169},
{"f_1711csi.scm",(void*)f_1711},
{"f_1740csi.scm",(void*)f_1740},
{"f_3025csi.scm",(void*)f_3025},
{"f_5161csi.scm",(void*)f_5161},
{"f_5167csi.scm",(void*)f_5167},
{"f_5164csi.scm",(void*)f_5164},
{"f_4420csi.scm",(void*)f_4420},
{"f_5155csi.scm",(void*)f_5155},
{"f_4424csi.scm",(void*)f_4424},
{"f_5151csi.scm",(void*)f_5151},
{"f_4427csi.scm",(void*)f_4427},
{"f_4430csi.scm",(void*)f_4430},
{"f_4433csi.scm",(void*)f_4433},
{"f_5147csi.scm",(void*)f_5147},
{"f_5134csi.scm",(void*)f_5134},
{"f_5094csi.scm",(void*)f_5094},
{"f_5044csi.scm",(void*)f_5044},
{"f_5047csi.scm",(void*)f_5047},
{"f_5050csi.scm",(void*)f_5050},
{"f_5053csi.scm",(void*)f_5053},
{"f_5062csi.scm",(void*)f_5062},
{"f_4436csi.scm",(void*)f_4436},
{"f_4439csi.scm",(void*)f_4439},
{"f_5038csi.scm",(void*)f_5038},
{"f_4442csi.scm",(void*)f_4442},
{"f_4445csi.scm",(void*)f_4445},
{"f_5029csi.scm",(void*)f_5029},
{"f_5025csi.scm",(void*)f_5025},
{"f_4451csi.scm",(void*)f_4451},
{"f_4603csi.scm",(void*)f_4603},
{"f_5014csi.scm",(void*)f_5014},
{"f_5017csi.scm",(void*)f_5017},
{"f_4606csi.scm",(void*)f_4606},
{"f_5005csi.scm",(void*)f_5005},
{"f_5008csi.scm",(void*)f_5008},
{"f_4609csi.scm",(void*)f_4609},
{"f_5002csi.scm",(void*)f_5002},
{"f_4995csi.scm",(void*)f_4995},
{"f_4612csi.scm",(void*)f_4612},
{"f_4982csi.scm",(void*)f_4982},
{"f_4985csi.scm",(void*)f_4985},
{"f_4615csi.scm",(void*)f_4615},
{"f_4976csi.scm",(void*)f_4976},
{"f_4618csi.scm",(void*)f_4618},
{"f_4961csi.scm",(void*)f_4961},
{"f_4964csi.scm",(void*)f_4964},
{"f_4967csi.scm",(void*)f_4967},
{"f_4621csi.scm",(void*)f_4621},
{"f_4958csi.scm",(void*)f_4958},
{"f_4624csi.scm",(void*)f_4624},
{"f_4954csi.scm",(void*)f_4954},
{"f_4627csi.scm",(void*)f_4627},
{"f_4950csi.scm",(void*)f_4950},
{"f_4938csi.scm",(void*)f_4938},
{"f_4946csi.scm",(void*)f_4946},
{"f_4942csi.scm",(void*)f_4942},
{"f_4934csi.scm",(void*)f_4934},
{"f_4631csi.scm",(void*)f_4631},
{"f_4638csi.scm",(void*)f_4638},
{"f_4641csi.scm",(void*)f_4641},
{"f_4868csi.scm",(void*)f_4868},
{"f_4500csi.scm",(void*)f_4500},
{"f_4506csi.scm",(void*)f_4506},
{"f_4528csi.scm",(void*)f_4528},
{"f_4512csi.scm",(void*)f_4512},
{"f_4515csi.scm",(void*)f_4515},
{"f_4521csi.scm",(void*)f_4521},
{"f_4644csi.scm",(void*)f_4644},
{"f_4649csi.scm",(void*)f_4649},
{"f_4801csi.scm",(void*)f_4801},
{"f_4807csi.scm",(void*)f_4807},
{"f_4822csi.scm",(void*)f_4822},
{"f_4833csi.scm",(void*)f_4833},
{"f_4812csi.scm",(void*)f_4812},
{"f_4820csi.scm",(void*)f_4820},
{"f_4794csi.scm",(void*)f_4794},
{"f_4784csi.scm",(void*)f_4784},
{"f_4768csi.scm",(void*)f_4768},
{"f_4758csi.scm",(void*)f_4758},
{"f_4738csi.scm",(void*)f_4738},
{"f_4722csi.scm",(void*)f_4722},
{"f_4706csi.scm",(void*)f_4706},
{"f_4677csi.scm",(void*)f_4677},
{"f_4662csi.scm",(void*)f_4662},
{"f_4533csi.scm",(void*)f_4533},
{"f_4580csi.scm",(void*)f_4580},
{"f_4537csi.scm",(void*)f_4537},
{"f_4540csi.scm",(void*)f_4540},
{"f_4547csi.scm",(void*)f_4547},
{"f_4549csi.scm",(void*)f_4549},
{"f_4572csi.scm",(void*)f_4572},
{"f_4570csi.scm",(void*)f_4570},
{"f_4559csi.scm",(void*)f_4559},
{"f_4566csi.scm",(void*)f_4566},
{"f_4453csi.scm",(void*)f_4453},
{"f_4459csi.scm",(void*)f_4459},
{"f_4486csi.scm",(void*)f_4486},
{"f_4277csi.scm",(void*)f_4277},
{"f_4283csi.scm",(void*)f_4283},
{"f_4305csi.scm",(void*)f_4305},
{"f_4362csi.scm",(void*)f_4362},
{"f_4355csi.scm",(void*)f_4355},
{"f_4321csi.scm",(void*)f_4321},
{"f_4344csi.scm",(void*)f_4344},
{"f_4334csi.scm",(void*)f_4334},
{"f_4338csi.scm",(void*)f_4338},
{"f_4394csi.scm",(void*)f_4394},
{"f_4220csi.scm",(void*)f_4220},
{"f_4226csi.scm",(void*)f_4226},
{"f_4238csi.scm",(void*)f_4238},
{"f_4161csi.scm",(void*)f_4161},
{"f_4165csi.scm",(void*)f_4165},
{"f_4170csi.scm",(void*)f_4170},
{"f_4199csi.scm",(void*)f_4199},
{"f_4186csi.scm",(void*)f_4186},
{"f_3952csi.scm",(void*)f_3952},
{"f_3984csi.scm",(void*)f_3984},
{"f_4159csi.scm",(void*)f_4159},
{"f_3994csi.scm",(void*)f_3994},
{"f_3997csi.scm",(void*)f_3997},
{"f_4069csi.scm",(void*)f_4069},
{"f_4130csi.scm",(void*)f_4130},
{"f_4152csi.scm",(void*)f_4152},
{"f_4148csi.scm",(void*)f_4148},
{"f_4133csi.scm",(void*)f_4133},
{"f_4088csi.scm",(void*)f_4088},
{"f_4106csi.scm",(void*)f_4106},
{"f_4116csi.scm",(void*)f_4116},
{"f_4000csi.scm",(void*)f_4000},
{"f_4003csi.scm",(void*)f_4003},
{"f_4018csi.scm",(void*)f_4018},
{"f_4031csi.scm",(void*)f_4031},
{"f_4034csi.scm",(void*)f_4034},
{"f_4006csi.scm",(void*)f_4006},
{"f_4009csi.scm",(void*)f_4009},
{"f_3955csi.scm",(void*)f_3955},
{"f_3959csi.scm",(void*)f_3959},
{"f_3975csi.scm",(void*)f_3975},
{"f_3791csi.scm",(void*)f_3791},
{"f_3904csi.scm",(void*)f_3904},
{"f_3899csi.scm",(void*)f_3899},
{"f_3793csi.scm",(void*)f_3793},
{"f_3818csi.scm",(void*)f_3818},
{"f_3861csi.scm",(void*)f_3861},
{"f_3871csi.scm",(void*)f_3871},
{"f_3842csi.scm",(void*)f_3842},
{"f_3825csi.scm",(void*)f_3825},
{"f_3796csi.scm",(void*)f_3796},
{"f_3785csi.scm",(void*)f_3785},
{"f_3027csi.scm",(void*)f_3027},
{"f_3031csi.scm",(void*)f_3031},
{"f_3764csi.scm",(void*)f_3764},
{"f_3159csi.scm",(void*)f_3159},
{"f_3258csi.scm",(void*)f_3258},
{"f_3405csi.scm",(void*)f_3405},
{"f_3433csi.scm",(void*)f_3433},
{"f_3442csi.scm",(void*)f_3442},
{"f_3536csi.scm",(void*)f_3536},
{"f_3670csi.scm",(void*)f_3670},
{"f_3685csi.scm",(void*)f_3685},
{"f_3724csi.scm",(void*)f_3724},
{"f_3713csi.scm",(void*)f_3713},
{"f_3709csi.scm",(void*)f_3709},
{"f_3692csi.scm",(void*)f_3692},
{"f_3603csi.scm",(void*)f_3603},
{"f_3608csi.scm",(void*)f_3608},
{"f_3612csi.scm",(void*)f_3612},
{"f_3621csi.scm",(void*)f_3621},
{"f_3656csi.scm",(void*)f_3656},
{"f_3648csi.scm",(void*)f_3648},
{"f_3631csi.scm",(void*)f_3631},
{"f_3567csi.scm",(void*)f_3567},
{"f_3570csi.scm",(void*)f_3570},
{"f_3575csi.scm",(void*)f_3575},
{"f_3555csi.scm",(void*)f_3555},
{"f_3542csi.scm",(void*)f_3542},
{"f_3530csi.scm",(void*)f_3530},
{"f_3449csi.scm",(void*)f_3449},
{"f_3460csi.scm",(void*)f_3460},
{"f_3424csi.scm",(void*)f_3424},
{"f_3365csi.scm",(void*)f_3365},
{"f_3379csi.scm",(void*)f_3379},
{"f_3375csi.scm",(void*)f_3375},
{"f_3321csi.scm",(void*)f_3321},
{"f_3288csi.scm",(void*)f_3288},
{"f_3301csi.scm",(void*)f_3301},
{"f_3291csi.scm",(void*)f_3291},
{"f_3298csi.scm",(void*)f_3298},
{"f_3228csi.scm",(void*)f_3228},
{"f_3234csi.scm",(void*)f_3234},
{"f_3162csi.scm",(void*)f_3162},
{"f_3033csi.scm",(void*)f_3033},
{"f_3156csi.scm",(void*)f_3156},
{"f_3040csi.scm",(void*)f_3040},
{"f_3045csi.scm",(void*)f_3045},
{"f_3068csi.scm",(void*)f_3068},
{"f_3077csi.scm",(void*)f_3077},
{"f_3141csi.scm",(void*)f_3141},
{"f_3087csi.scm",(void*)f_3087},
{"f_3090csi.scm",(void*)f_3090},
{"f_2831csi.scm",(void*)f_2831},
{"f_2839csi.scm",(void*)f_2839},
{"f_2841csi.scm",(void*)f_2841},
{"f_2845csi.scm",(void*)f_2845},
{"f_2848csi.scm",(void*)f_2848},
{"f_2851csi.scm",(void*)f_2851},
{"f_2868csi.scm",(void*)f_2868},
{"f_3011csi.scm",(void*)f_3011},
{"f_3007csi.scm",(void*)f_3007},
{"f_3003csi.scm",(void*)f_3003},
{"f_2970csi.scm",(void*)f_2970},
{"f_2974csi.scm",(void*)f_2974},
{"f_2979csi.scm",(void*)f_2979},
{"f_2987csi.scm",(void*)f_2987},
{"f_2871csi.scm",(void*)f_2871},
{"f_2899csi.scm",(void*)f_2899},
{"f_2907csi.scm",(void*)f_2907},
{"f_2911csi.scm",(void*)f_2911},
{"f_2915csi.scm",(void*)f_2915},
{"f_2919csi.scm",(void*)f_2919},
{"f_2923csi.scm",(void*)f_2923},
{"f_2874csi.scm",(void*)f_2874},
{"f_2877csi.scm",(void*)f_2877},
{"f_2880csi.scm",(void*)f_2880},
{"f_2883csi.scm",(void*)f_2883},
{"f_2853csi.scm",(void*)f_2853},
{"f_2861csi.scm",(void*)f_2861},
{"f_2728csi.scm",(void*)f_2728},
{"f_2732csi.scm",(void*)f_2732},
{"f_2762csi.scm",(void*)f_2762},
{"f_2780csi.scm",(void*)f_2780},
{"f_2819csi.scm",(void*)f_2819},
{"f_2825csi.scm",(void*)f_2825},
{"f_2786csi.scm",(void*)f_2786},
{"f_2794csi.scm",(void*)f_2794},
{"f_2796csi.scm",(void*)f_2796},
{"f_2813csi.scm",(void*)f_2813},
{"f_2768csi.scm",(void*)f_2768},
{"f_2774csi.scm",(void*)f_2774},
{"f_2760csi.scm",(void*)f_2760},
{"f_2757csi.scm",(void*)f_2757},
{"f_2737csi.scm",(void*)f_2737},
{"f_2747csi.scm",(void*)f_2747},
{"f_2750csi.scm",(void*)f_2750},
{"f_2704csi.scm",(void*)f_2704},
{"f_2714csi.scm",(void*)f_2714},
{"f_2708csi.scm",(void*)f_2708},
{"f_2413csi.scm",(void*)f_2413},
{"f_2418csi.scm",(void*)f_2418},
{"f_2421csi.scm",(void*)f_2421},
{"f_2424csi.scm",(void*)f_2424},
{"f_2427csi.scm",(void*)f_2427},
{"f_2438csi.scm",(void*)f_2438},
{"f_2442csi.scm",(void*)f_2442},
{"f_2430csi.scm",(void*)f_2430},
{"f_2433csi.scm",(void*)f_2433},
{"f_2390csi.scm",(void*)f_2390},
{"f_2394csi.scm",(void*)f_2394},
{"f_2398csi.scm",(void*)f_2398},
{"f_2401csi.scm",(void*)f_2401},
{"f_2404csi.scm",(void*)f_2404},
{"f_2362csi.scm",(void*)f_2362},
{"f_2366csi.scm",(void*)f_2366},
{"f_2371csi.scm",(void*)f_2371},
{"f_2381csi.scm",(void*)f_2381},
{"f_2388csi.scm",(void*)f_2388},
{"f_2321csi.scm",(void*)f_2321},
{"f_2327csi.scm",(void*)f_2327},
{"f_2343csi.scm",(void*)f_2343},
{"f_2353csi.scm",(void*)f_2353},
{"f_1783csi.scm",(void*)f_1783},
{"f_1800csi.scm",(void*)f_1800},
{"f_2302csi.scm",(void*)f_2302},
{"f_2306csi.scm",(void*)f_2306},
{"f_2296csi.scm",(void*)f_2296},
{"f_1806csi.scm",(void*)f_1806},
{"f_2282csi.scm",(void*)f_2282},
{"f_2258csi.scm",(void*)f_2258},
{"f_2266csi.scm",(void*)f_2266},
{"f_2261csi.scm",(void*)f_2261},
{"f_2239csi.scm",(void*)f_2239},
{"f_2242csi.scm",(void*)f_2242},
{"f_2245csi.scm",(void*)f_2245},
{"f_2216csi.scm",(void*)f_2216},
{"f_2219csi.scm",(void*)f_2219},
{"f_2226csi.scm",(void*)f_2226},
{"f_2200csi.scm",(void*)f_2200},
{"f_2172csi.scm",(void*)f_2172},
{"f_2149csi.scm",(void*)f_2149},
{"f_2162csi.scm",(void*)f_2162},
{"f_2140csi.scm",(void*)f_2140},
{"f_2136csi.scm",(void*)f_2136},
{"f_2110csi.scm",(void*)f_2110},
{"f_2106csi.scm",(void*)f_2106},
{"f_2102csi.scm",(void*)f_2102},
{"f_2675csi.scm",(void*)f_2675},
{"f_2679csi.scm",(void*)f_2679},
{"f_2698csi.scm",(void*)f_2698},
{"f_2089csi.scm",(void*)f_2089},
{"f_2085csi.scm",(void*)f_2085},
{"f_2081csi.scm",(void*)f_2081},
{"f_2607csi.scm",(void*)f_2607},
{"f_2611csi.scm",(void*)f_2611},
{"f_2656csi.scm",(void*)f_2656},
{"f_2663csi.scm",(void*)f_2663},
{"f_2617csi.scm",(void*)f_2617},
{"f_2638csi.scm",(void*)f_2638},
{"f_2642csi.scm",(void*)f_2642},
{"f_2594csi.scm",(void*)f_2594},
{"f_2068csi.scm",(void*)f_2068},
{"f_2064csi.scm",(void*)f_2064},
{"f_2060csi.scm",(void*)f_2060},
{"f_2553csi.scm",(void*)f_2553},
{"f_2557csi.scm",(void*)f_2557},
{"f_2576csi.scm",(void*)f_2576},
{"f_2047csi.scm",(void*)f_2047},
{"f_2043csi.scm",(void*)f_2043},
{"f_2039csi.scm",(void*)f_2039},
{"f_2472csi.scm",(void*)f_2472},
{"f_2476csi.scm",(void*)f_2476},
{"f_2515csi.scm",(void*)f_2515},
{"f_2519csi.scm",(void*)f_2519},
{"f_2530csi.scm",(void*)f_2530},
{"f_2534csi.scm",(void*)f_2534},
{"f_2524csi.scm",(void*)f_2524},
{"f_2459csi.scm",(void*)f_2459},
{"f_1986csi.scm",(void*)f_1986},
{"f_2019csi.scm",(void*)f_2019},
{"f_2023csi.scm",(void*)f_2023},
{"f_1991csi.scm",(void*)f_1991},
{"f_1995csi.scm",(void*)f_1995},
{"f_2006csi.scm",(void*)f_2006},
{"f_2017csi.scm",(void*)f_2017},
{"f_2010csi.scm",(void*)f_2010},
{"f_2000csi.scm",(void*)f_2000},
{"f_1977csi.scm",(void*)f_1977},
{"f_1952csi.scm",(void*)f_1952},
{"f_1960csi.scm",(void*)f_1960},
{"f_1966csi.scm",(void*)f_1966},
{"f_1970csi.scm",(void*)f_1970},
{"f_1955csi.scm",(void*)f_1955},
{"f_1943csi.scm",(void*)f_1943},
{"f_1933csi.scm",(void*)f_1933},
{"f_1936csi.scm",(void*)f_1936},
{"f_1894csi.scm",(void*)f_1894},
{"f_1897csi.scm",(void*)f_1897},
{"f_1900csi.scm",(void*)f_1900},
{"f_1903csi.scm",(void*)f_1903},
{"f_1879csi.scm",(void*)f_1879},
{"f_1882csi.scm",(void*)f_1882},
{"f_1864csi.scm",(void*)f_1864},
{"f_1867csi.scm",(void*)f_1867},
{"f_1846csi.scm",(void*)f_1846},
{"f_1849csi.scm",(void*)f_1849},
{"f_1852csi.scm",(void*)f_1852},
{"f_1827csi.scm",(void*)f_1827},
{"f_1837csi.scm",(void*)f_1837},
{"f_1830csi.scm",(void*)f_1830},
{"f_1812csi.scm",(void*)f_1812},
{"f_1742csi.scm",(void*)f_1742},
{"f_1746csi.scm",(void*)f_1746},
{"f_1726csi.scm",(void*)f_1726},
{"f_1733csi.scm",(void*)f_1733},
{"f_1713csi.scm",(void*)f_1713},
{"f_1686csi.scm",(void*)f_1686},
{"f_1647csi.scm",(void*)f_1647},
{"f_1671csi.scm",(void*)f_1671},
{"f_1657csi.scm",(void*)f_1657},
{"f_1541csi.scm",(void*)f_1541},
{"f_1545csi.scm",(void*)f_1545},
{"f_1586csi.scm",(void*)f_1586},
{"f_1592csi.scm",(void*)f_1592},
{"f_1599csi.scm",(void*)f_1599},
{"f_1601csi.scm",(void*)f_1601},
{"f_1628csi.scm",(void*)f_1628},
{"f_1611csi.scm",(void*)f_1611},
{"f_1614csi.scm",(void*)f_1614},
{"f_1569csi.scm",(void*)f_1569},
{"f_1583csi.scm",(void*)f_1583},
{"f_1579csi.scm",(void*)f_1579},
{"f_1520csi.scm",(void*)f_1520},
{"f_1493csi.scm",(void*)f_1493},
{"f_1500csi.scm",(void*)f_1500},
{"f_1503csi.scm",(void*)f_1503},
{"f_1509csi.scm",(void*)f_1509},
{"f_1443csi.scm",(void*)f_1443},
{"f_1447csi.scm",(void*)f_1447},
{"f_1431csi.scm",(void*)f_1431},
{"f_1421csi.scm",(void*)f_1421},
{"f_1429csi.scm",(void*)f_1429},
{"f_1392csi.scm",(void*)f_1392},
{"f_1409csi.scm",(void*)f_1409},
{"f_1382csi.scm",(void*)f_1382},
{"f_1390csi.scm",(void*)f_1390},
{"f_1370csi.scm",(void*)f_1370},
{"f_1374csi.scm",(void*)f_1374},
{"f_1377csi.scm",(void*)f_1377},
{"f_1121csi.scm",(void*)f_1121},
{"f_1125csi.scm",(void*)f_1125},
{"f_1162csi.scm",(void*)f_1162},
{"f_1183csi.scm",(void*)f_1183},
{"f_1181csi.scm",(void*)f_1181},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
